# IPython log file

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Tue, 01 Dec 2020 09:57:19
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 09:57:19
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 09:57:20
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 09:57:21
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x174755f50a0>
# Tue, 01 Dec 2020 09:57:31
query3_2 = '''
    PUT YOUR QUERY HERE
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 09:59:34
query3_2 = SELECT DISTINCT
C.cID
C.cName("")

FROM Customer AS C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.cID = C.cID

WHERE SL.Date = '2018' AND P.Date = '2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 09:59:44
query3_2 = 
SELECT 
C.cID
C.cName("")

FROM Customer AS C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.cID = C.cID

WHERE SL.Date = '2018' AND P.Date = '2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 09:59:47
query3_2 = 
SELECT 
C.cID
C.cName("")

FROM Customer AS C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.cID = C.cID

WHERE SL.Date = '2018' AND P.Date = '2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 09:59:58
query3_2 = SELECT DISTINCT
C.cID
C.cName("")

FROM Customer AS C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.cID = C.cID

WHERE SL.Date = '2018' AND P.Date = '2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 10:00:02
query3_2 = SELECT 
C.cID
C.cName("")

FROM Customer AS C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.cID = C.cID

WHERE SL.Date = '2018' AND P.Date = '2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 10:00:06
query3_2 = SELECT 
C.cID
C.cName("")

FROM Customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.cID = C.cID

WHERE SL.Date = '2018' AND P.Date = '2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 10:00:52
query3_2 = SELECT 
C.cID
C.cName("")

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.cID = C.cID

WHERE SL.Date = '2018' AND P.Date = '2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:01:51
query3_2 = ''' 

SELECT 
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.cID = C.cID

WHERE SL.Date = '2018' AND P.Date = '2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:02:08
query3_2 = ''' 

SELECT 
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.cID = C.cID

'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID  cName
#[Out]# 0       1    Sem
#[Out]# 1       1    Sem
#[Out]# 2       1    Sem
#[Out]# 3       1    Sem
#[Out]# 4       1    Sem
#[Out]# 5       1    Sem
#[Out]# 6       1    Sem
#[Out]# 7       1    Sem
#[Out]# 8       1    Sem
#[Out]# 9       1    Sem
#[Out]# 10      1    Sem
#[Out]# 11      1    Sem
#[Out]# 12      1    Sem
#[Out]# 13      1    Sem
#[Out]# 14      1    Sem
#[Out]# 15      1    Sem
#[Out]# 16      1    Sem
#[Out]# 17      1    Sem
#[Out]# 18      1    Sem
#[Out]# 19      1    Sem
#[Out]# 20      1    Sem
#[Out]# 21      1    Sem
#[Out]# 22      1    Sem
#[Out]# 23      1    Sem
#[Out]# 24      1    Sem
#[Out]# 25      1    Sem
#[Out]# 26      1    Sem
#[Out]# 27      1    Sem
#[Out]# 28      1    Sem
#[Out]# 29      1    Sem
#[Out]# ...   ...    ...
#[Out]# 2297  179   Juul
#[Out]# 2298  179   Juul
#[Out]# 2299  179   Juul
#[Out]# 2300  179   Juul
#[Out]# 2301  179   Juul
#[Out]# 2302  179   Juul
#[Out]# 2303  179   Juul
#[Out]# 2304  179   Juul
#[Out]# 2305  179   Juul
#[Out]# 2306  180  Merel
#[Out]# 2307  180  Merel
#[Out]# 2308  180  Merel
#[Out]# 2309  180  Merel
#[Out]# 2310  180  Merel
#[Out]# 2311  180  Merel
#[Out]# 2312  180  Merel
#[Out]# 2313  180  Merel
#[Out]# 2314  180  Merel
#[Out]# 2315  181   Liva
#[Out]# 2316  181   Liva
#[Out]# 2317  181   Liva
#[Out]# 2318  181   Liva
#[Out]# 2319  181   Liva
#[Out]# 2320  181   Liva
#[Out]# 2321  181   Liva
#[Out]# 2322  181   Liva
#[Out]# 2323  181   Liva
#[Out]# 2324  181   Liva
#[Out]# 2325  181   Liva
#[Out]# 2326  181   Liva
#[Out]# 
#[Out]# [2327 rows x 2 columns]
# Tue, 01 Dec 2020 11:03:12
query3_2 = ''' 

SELECT 
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      1    Sem
#[Out]# 2      1    Sem
#[Out]# 3      1    Sem
#[Out]# 4      1    Sem
#[Out]# 5      1    Sem
#[Out]# 6      1    Sem
#[Out]# 7      1    Sem
#[Out]# 8      2  Lucas
#[Out]# 9      2  Lucas
#[Out]# 10     2  Lucas
#[Out]# 11     2  Lucas
#[Out]# 12     2  Lucas
#[Out]# 13     3   Finn
#[Out]# 14     3   Finn
#[Out]# 15     3   Finn
#[Out]# 16     5   Levi
#[Out]# 17     5   Levi
#[Out]# 18     5   Levi
#[Out]# 19     5   Levi
#[Out]# 20     5   Levi
#[Out]# 21     5   Levi
#[Out]# 22     7   Bram
#[Out]# 23     7   Bram
#[Out]# 24     7   Bram
#[Out]# 25     7   Bram
#[Out]# 26     7   Bram
#[Out]# 27     7   Bram
#[Out]# 28     8   Liam
#[Out]# 29     8   Liam
#[Out]# ..   ...    ...
#[Out]# 462  176  Amira
#[Out]# 463  176  Amira
#[Out]# 464  176  Amira
#[Out]# 465  176  Amira
#[Out]# 466  176  Amira
#[Out]# 467  176  Amira
#[Out]# 468  176  Amira
#[Out]# 469  176  Amira
#[Out]# 470  178   Elif
#[Out]# 471  178   Elif
#[Out]# 472  179   Juul
#[Out]# 473  179   Juul
#[Out]# 474  179   Juul
#[Out]# 475  179   Juul
#[Out]# 476  179   Juul
#[Out]# 477  179   Juul
#[Out]# 478  180  Merel
#[Out]# 479  180  Merel
#[Out]# 480  180  Merel
#[Out]# 481  181   Liva
#[Out]# 482  181   Liva
#[Out]# 483  181   Liva
#[Out]# 484  181   Liva
#[Out]# 485  183  Nikki
#[Out]# 486  183  Nikki
#[Out]# 487  183  Nikki
#[Out]# 488  183  Nikki
#[Out]# 489  183  Nikki
#[Out]# 490  183  Nikki
#[Out]# 491  183  Nikki
#[Out]# 
#[Out]# [492 rows x 2 columns]
# Tue, 01 Dec 2020 11:04:02
query3_2 = ''' 

SELECT 
C.cID
,C.cName
,SL.date

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date
#[Out]# 0      1    Sem  2018-08-20
#[Out]# 1      1    Sem  2018-08-20
#[Out]# 2      1    Sem  2018-08-20
#[Out]# 3      1    Sem  2018-08-20
#[Out]# 4      1    Sem  2018-08-20
#[Out]# 5      1    Sem  2018-08-20
#[Out]# 6      1    Sem  2018-08-20
#[Out]# 7      1    Sem  2018-08-21
#[Out]# 8      2  Lucas  2018-08-17
#[Out]# 9      2  Lucas  2018-08-16
#[Out]# 10     2  Lucas  2018-08-17
#[Out]# 11     2  Lucas  2018-08-16
#[Out]# 12     2  Lucas  2018-08-17
#[Out]# 13     3   Finn  2018-08-19
#[Out]# 14     3   Finn  2018-08-18
#[Out]# 15     3   Finn  2018-08-18
#[Out]# 16     5   Levi  2018-08-22
#[Out]# 17     5   Levi  2018-08-17
#[Out]# 18     5   Levi  2018-08-23
#[Out]# 19     5   Levi  2018-08-23
#[Out]# 20     5   Levi  2018-08-23
#[Out]# 21     5   Levi  2018-08-22
#[Out]# 22     7   Bram  2018-08-23
#[Out]# 23     7   Bram  2018-08-25
#[Out]# 24     7   Bram  2018-08-24
#[Out]# 25     7   Bram  2018-08-23
#[Out]# 26     7   Bram  2018-08-23
#[Out]# 27     7   Bram  2018-08-26
#[Out]# 28     8   Liam  2018-08-16
#[Out]# 29     8   Liam  2018-08-16
#[Out]# ..   ...    ...         ...
#[Out]# 462  176  Amira  2018-08-25
#[Out]# 463  176  Amira  2018-08-22
#[Out]# 464  176  Amira  2018-08-26
#[Out]# 465  176  Amira  2018-08-25
#[Out]# 466  176  Amira  2018-08-25
#[Out]# 467  176  Amira  2018-08-25
#[Out]# 468  176  Amira  2018-08-25
#[Out]# 469  176  Amira  2018-08-25
#[Out]# 470  178   Elif  2018-08-27
#[Out]# 471  178   Elif  2018-08-27
#[Out]# 472  179   Juul  2018-08-22
#[Out]# 473  179   Juul  2018-08-24
#[Out]# 474  179   Juul  2018-08-24
#[Out]# 475  179   Juul  2018-08-22
#[Out]# 476  179   Juul  2018-08-24
#[Out]# 477  179   Juul  2018-08-22
#[Out]# 478  180  Merel  2018-08-27
#[Out]# 479  180  Merel  2018-08-26
#[Out]# 480  180  Merel  2018-08-26
#[Out]# 481  181   Liva  2018-08-27
#[Out]# 482  181   Liva  2018-08-24
#[Out]# 483  181   Liva  2018-08-27
#[Out]# 484  181   Liva  2018-08-24
#[Out]# 485  183  Nikki  2018-08-19
#[Out]# 486  183  Nikki  2018-08-22
#[Out]# 487  183  Nikki  2018-08-20
#[Out]# 488  183  Nikki  2018-08-21
#[Out]# 489  183  Nikki  2018-08-22
#[Out]# 490  183  Nikki  2018-08-21
#[Out]# 491  183  Nikki  2018-08-22
#[Out]# 
#[Out]# [492 rows x 3 columns]
# Tue, 01 Dec 2020 11:04:57
query3_2 = ''' 

SELECT 
C.cID
,C.cName
,SL.date
,P.date

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date        date
#[Out]# 0      1    Sem  2018-08-20  2018-08-20
#[Out]# 1      1    Sem  2018-08-20  2018-08-20
#[Out]# 2      1    Sem  2018-08-20  2018-08-20
#[Out]# 3      1    Sem  2018-08-20  2018-08-20
#[Out]# 4      1    Sem  2018-08-20  2018-08-20
#[Out]# 5      1    Sem  2018-08-20  2018-08-20
#[Out]# 6      1    Sem  2018-08-20  2018-08-20
#[Out]# 7      1    Sem  2018-08-20  2018-08-20
#[Out]# 8      1    Sem  2018-08-20  2018-08-20
#[Out]# 9      1    Sem  2018-08-20  2018-08-20
#[Out]# 10     1    Sem  2018-08-20  2018-08-20
#[Out]# 11     1    Sem  2018-08-20  2018-08-20
#[Out]# 12     1    Sem  2018-08-20  2018-08-20
#[Out]# 13     1    Sem  2018-08-20  2018-08-20
#[Out]# 14     1    Sem  2018-08-20  2018-08-20
#[Out]# 15     1    Sem  2018-08-20  2018-08-20
#[Out]# 16     1    Sem  2018-08-20  2018-08-20
#[Out]# 17     1    Sem  2018-08-20  2018-08-20
#[Out]# 18     1    Sem  2018-08-20  2018-08-20
#[Out]# 19     1    Sem  2018-08-20  2018-08-20
#[Out]# 20     1    Sem  2018-08-20  2018-08-20
#[Out]# 21     1    Sem  2018-08-20  2018-08-20
#[Out]# 22     1    Sem  2018-08-20  2018-08-20
#[Out]# 23     1    Sem  2018-08-20  2018-08-20
#[Out]# 24     1    Sem  2018-08-20  2018-08-20
#[Out]# 25     1    Sem  2018-08-20  2018-08-20
#[Out]# 26     1    Sem  2018-08-20  2018-08-20
#[Out]# 27     1    Sem  2018-08-20  2018-08-20
#[Out]# 28     1    Sem  2018-08-20  2018-08-20
#[Out]# 29     1    Sem  2018-08-20  2018-08-20
#[Out]# ..   ...    ...         ...         ...
#[Out]# 946  176  Amira  2018-08-26  2018-08-26
#[Out]# 947  178   Elif  2018-08-27  2018-08-27
#[Out]# 948  178   Elif  2018-08-27  2018-08-27
#[Out]# 949  178   Elif  2018-08-27  2018-08-27
#[Out]# 950  178   Elif  2018-08-27  2018-08-27
#[Out]# 951  179   Juul  2018-08-24  2018-08-24
#[Out]# 952  179   Juul  2018-08-24  2018-08-24
#[Out]# 953  179   Juul  2018-08-24  2018-08-24
#[Out]# 954  179   Juul  2018-08-24  2018-08-24
#[Out]# 955  179   Juul  2018-08-24  2018-08-24
#[Out]# 956  179   Juul  2018-08-24  2018-08-24
#[Out]# 957  179   Juul  2018-08-24  2018-08-24
#[Out]# 958  179   Juul  2018-08-24  2018-08-24
#[Out]# 959  179   Juul  2018-08-24  2018-08-24
#[Out]# 960  179   Juul  2018-08-22  2018-08-22
#[Out]# 961  179   Juul  2018-08-22  2018-08-22
#[Out]# 962  179   Juul  2018-08-22  2018-08-22
#[Out]# 963  179   Juul  2018-08-22  2018-08-22
#[Out]# 964  179   Juul  2018-08-22  2018-08-22
#[Out]# 965  179   Juul  2018-08-22  2018-08-22
#[Out]# 966  180  Merel  2018-08-26  2018-08-26
#[Out]# 967  180  Merel  2018-08-26  2018-08-26
#[Out]# 968  180  Merel  2018-08-27  2018-08-27
#[Out]# 969  180  Merel  2018-08-27  2018-08-27
#[Out]# 970  181   Liva  2018-08-24  2018-08-24
#[Out]# 971  181   Liva  2018-08-24  2018-08-24
#[Out]# 972  181   Liva  2018-08-24  2018-08-24
#[Out]# 973  181   Liva  2018-08-24  2018-08-24
#[Out]# 974  181   Liva  2018-08-27  2018-08-27
#[Out]# 975  181   Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [976 rows x 4 columns]
# Tue, 01 Dec 2020 11:05:16
query3_2 = ''' 

SELECT 
C.cID
,C.cName
,SL.date

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID


'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date
#[Out]# 0      1    Sem  2018-08-20
#[Out]# 1      1    Sem  2018-08-20
#[Out]# 2      1    Sem  2018-08-20
#[Out]# 3      1    Sem  2018-08-20
#[Out]# 4      1    Sem  2018-08-20
#[Out]# 5      1    Sem  2018-08-20
#[Out]# 6      1    Sem  2018-08-20
#[Out]# 7      1    Sem  2018-08-21
#[Out]# 8      2  Lucas  2018-08-17
#[Out]# 9      2  Lucas  2018-08-16
#[Out]# 10     2  Lucas  2018-08-17
#[Out]# 11     2  Lucas  2018-08-16
#[Out]# 12     2  Lucas  2018-08-17
#[Out]# 13     3   Finn  2018-08-19
#[Out]# 14     3   Finn  2018-08-18
#[Out]# 15     3   Finn  2018-08-18
#[Out]# 16     5   Levi  2018-08-22
#[Out]# 17     5   Levi  2018-08-17
#[Out]# 18     5   Levi  2018-08-23
#[Out]# 19     5   Levi  2018-08-23
#[Out]# 20     5   Levi  2018-08-23
#[Out]# 21     5   Levi  2018-08-22
#[Out]# 22     7   Bram  2018-08-23
#[Out]# 23     7   Bram  2018-08-25
#[Out]# 24     7   Bram  2018-08-24
#[Out]# 25     7   Bram  2018-08-23
#[Out]# 26     7   Bram  2018-08-23
#[Out]# 27     7   Bram  2018-08-26
#[Out]# 28     8   Liam  2018-08-16
#[Out]# 29     8   Liam  2018-08-16
#[Out]# ..   ...    ...         ...
#[Out]# 462  176  Amira  2018-08-25
#[Out]# 463  176  Amira  2018-08-22
#[Out]# 464  176  Amira  2018-08-26
#[Out]# 465  176  Amira  2018-08-25
#[Out]# 466  176  Amira  2018-08-25
#[Out]# 467  176  Amira  2018-08-25
#[Out]# 468  176  Amira  2018-08-25
#[Out]# 469  176  Amira  2018-08-25
#[Out]# 470  178   Elif  2018-08-27
#[Out]# 471  178   Elif  2018-08-27
#[Out]# 472  179   Juul  2018-08-22
#[Out]# 473  179   Juul  2018-08-24
#[Out]# 474  179   Juul  2018-08-24
#[Out]# 475  179   Juul  2018-08-22
#[Out]# 476  179   Juul  2018-08-24
#[Out]# 477  179   Juul  2018-08-22
#[Out]# 478  180  Merel  2018-08-27
#[Out]# 479  180  Merel  2018-08-26
#[Out]# 480  180  Merel  2018-08-26
#[Out]# 481  181   Liva  2018-08-27
#[Out]# 482  181   Liva  2018-08-24
#[Out]# 483  181   Liva  2018-08-27
#[Out]# 484  181   Liva  2018-08-24
#[Out]# 485  183  Nikki  2018-08-19
#[Out]# 486  183  Nikki  2018-08-22
#[Out]# 487  183  Nikki  2018-08-20
#[Out]# 488  183  Nikki  2018-08-21
#[Out]# 489  183  Nikki  2018-08-22
#[Out]# 490  183  Nikki  2018-08-21
#[Out]# 491  183  Nikki  2018-08-22
#[Out]# 
#[Out]# [492 rows x 3 columns]
# Tue, 01 Dec 2020 11:05:48
query3_2 = ''' 

SELECT 
C.cID
,C.cName
,SL.date
,P.date

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date        date
#[Out]# 0      1    Sem  2018-08-20  2018-08-20
#[Out]# 1      1    Sem  2018-08-20  2018-08-20
#[Out]# 2      1    Sem  2018-08-20  2018-08-20
#[Out]# 3      1    Sem  2018-08-20  2018-08-20
#[Out]# 4      1    Sem  2018-08-20  2018-08-20
#[Out]# 5      1    Sem  2018-08-20  2018-08-20
#[Out]# 6      1    Sem  2018-08-20  2018-08-20
#[Out]# 7      1    Sem  2018-08-20  2018-08-20
#[Out]# 8      1    Sem  2018-08-20  2018-08-20
#[Out]# 9      1    Sem  2018-08-20  2018-08-20
#[Out]# 10     1    Sem  2018-08-20  2018-08-20
#[Out]# 11     1    Sem  2018-08-20  2018-08-20
#[Out]# 12     1    Sem  2018-08-20  2018-08-20
#[Out]# 13     1    Sem  2018-08-20  2018-08-20
#[Out]# 14     1    Sem  2018-08-20  2018-08-20
#[Out]# 15     1    Sem  2018-08-20  2018-08-20
#[Out]# 16     1    Sem  2018-08-20  2018-08-20
#[Out]# 17     1    Sem  2018-08-20  2018-08-20
#[Out]# 18     1    Sem  2018-08-20  2018-08-20
#[Out]# 19     1    Sem  2018-08-20  2018-08-20
#[Out]# 20     1    Sem  2018-08-20  2018-08-20
#[Out]# 21     1    Sem  2018-08-20  2018-08-20
#[Out]# 22     1    Sem  2018-08-20  2018-08-20
#[Out]# 23     1    Sem  2018-08-20  2018-08-20
#[Out]# 24     1    Sem  2018-08-20  2018-08-20
#[Out]# 25     1    Sem  2018-08-20  2018-08-20
#[Out]# 26     1    Sem  2018-08-20  2018-08-20
#[Out]# 27     1    Sem  2018-08-20  2018-08-20
#[Out]# 28     1    Sem  2018-08-20  2018-08-20
#[Out]# 29     1    Sem  2018-08-20  2018-08-20
#[Out]# ..   ...    ...         ...         ...
#[Out]# 946  176  Amira  2018-08-26  2018-08-26
#[Out]# 947  178   Elif  2018-08-27  2018-08-27
#[Out]# 948  178   Elif  2018-08-27  2018-08-27
#[Out]# 949  178   Elif  2018-08-27  2018-08-27
#[Out]# 950  178   Elif  2018-08-27  2018-08-27
#[Out]# 951  179   Juul  2018-08-24  2018-08-24
#[Out]# 952  179   Juul  2018-08-24  2018-08-24
#[Out]# 953  179   Juul  2018-08-24  2018-08-24
#[Out]# 954  179   Juul  2018-08-24  2018-08-24
#[Out]# 955  179   Juul  2018-08-24  2018-08-24
#[Out]# 956  179   Juul  2018-08-24  2018-08-24
#[Out]# 957  179   Juul  2018-08-24  2018-08-24
#[Out]# 958  179   Juul  2018-08-24  2018-08-24
#[Out]# 959  179   Juul  2018-08-24  2018-08-24
#[Out]# 960  179   Juul  2018-08-22  2018-08-22
#[Out]# 961  179   Juul  2018-08-22  2018-08-22
#[Out]# 962  179   Juul  2018-08-22  2018-08-22
#[Out]# 963  179   Juul  2018-08-22  2018-08-22
#[Out]# 964  179   Juul  2018-08-22  2018-08-22
#[Out]# 965  179   Juul  2018-08-22  2018-08-22
#[Out]# 966  180  Merel  2018-08-26  2018-08-26
#[Out]# 967  180  Merel  2018-08-26  2018-08-26
#[Out]# 968  180  Merel  2018-08-27  2018-08-27
#[Out]# 969  180  Merel  2018-08-27  2018-08-27
#[Out]# 970  181   Liva  2018-08-24  2018-08-24
#[Out]# 971  181   Liva  2018-08-24  2018-08-24
#[Out]# 972  181   Liva  2018-08-24  2018-08-24
#[Out]# 973  181   Liva  2018-08-24  2018-08-24
#[Out]# 974  181   Liva  2018-08-27  2018-08-27
#[Out]# 975  181   Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [976 rows x 4 columns]
# Tue, 01 Dec 2020 11:05:56
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName
,SL.date
,P.date

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName        date        date
#[Out]# 0      1       Sem  2018-08-20  2018-08-20
#[Out]# 1      1       Sem  2018-08-21  2018-08-21
#[Out]# 2      2     Lucas  2018-08-16  2018-08-16
#[Out]# 3      2     Lucas  2018-08-17  2018-08-17
#[Out]# 4      3      Finn  2018-08-18  2018-08-18
#[Out]# 5      3      Finn  2018-08-19  2018-08-19
#[Out]# 6      5      Levi  2018-08-17  2018-08-17
#[Out]# 7      5      Levi  2018-08-22  2018-08-22
#[Out]# 8      5      Levi  2018-08-23  2018-08-23
#[Out]# 9      7      Bram  2018-08-23  2018-08-23
#[Out]# 10     7      Bram  2018-08-24  2018-08-24
#[Out]# 11     7      Bram  2018-08-25  2018-08-25
#[Out]# 12     7      Bram  2018-08-26  2018-08-26
#[Out]# 13     8      Liam  2018-08-16  2018-08-16
#[Out]# 14    10       Sam  2018-08-27  2018-08-27
#[Out]# 15    11     Thijs  2018-08-25  2018-08-25
#[Out]# 16    13     James  2018-08-17  2018-08-17
#[Out]# 17    13     James  2018-08-25  2018-08-25
#[Out]# 18    13     James  2018-08-26  2018-08-26
#[Out]# 19    13     James  2018-08-27  2018-08-27
#[Out]# 20    15      Noud  2018-08-27  2018-08-27
#[Out]# 21    17       Dex  2018-08-19  2018-08-19
#[Out]# 22    18      Hugo  2018-08-16  2018-08-16
#[Out]# 23    18      Hugo  2018-08-18  2018-08-18
#[Out]# 24    19      Lars  2018-08-17  2018-08-17
#[Out]# 25    19      Lars  2018-08-18  2018-08-18
#[Out]# 26    20      Gijs  2018-08-17  2018-08-17
#[Out]# 27    20      Gijs  2018-08-18  2018-08-18
#[Out]# 28    21  Benjamin  2018-08-15  2018-08-15
#[Out]# 29    22      Mats  2018-08-27  2018-08-27
#[Out]# ..   ...       ...         ...         ...
#[Out]# 156  165     Hanna  2018-08-23  2018-08-23
#[Out]# 157  165     Hanna  2018-08-24  2018-08-24
#[Out]# 158  167    Veerle  2018-08-18  2018-08-18
#[Out]# 159  167    Veerle  2018-08-19  2018-08-19
#[Out]# 160  167    Veerle  2018-08-20  2018-08-20
#[Out]# 161  167    Veerle  2018-08-21  2018-08-21
#[Out]# 162  167    Veerle  2018-08-15  2018-08-15
#[Out]# 163  168      Kiki  2018-08-16  2018-08-16
#[Out]# 164  169      Lily  2018-08-16  2018-08-16
#[Out]# 165  169      Lily  2018-08-17  2018-08-17
#[Out]# 166  169      Lily  2018-08-18  2018-08-18
#[Out]# 167  169      Lily  2018-08-19  2018-08-19
#[Out]# 168  169      Lily  2018-08-20  2018-08-20
#[Out]# 169  169      Lily  2018-08-26  2018-08-26
#[Out]# 170  169      Lily  2018-08-27  2018-08-27
#[Out]# 171  170      Iris  2018-08-16  2018-08-16
#[Out]# 172  171     Tessa  2018-08-20  2018-08-20
#[Out]# 173  172      Lana  2018-08-27  2018-08-27
#[Out]# 174  172      Lana  2018-08-24  2018-08-24
#[Out]# 175  175       Sam  2018-08-19  2018-08-19
#[Out]# 176  176     Amira  2018-08-22  2018-08-22
#[Out]# 177  176     Amira  2018-08-25  2018-08-25
#[Out]# 178  176     Amira  2018-08-26  2018-08-26
#[Out]# 179  178      Elif  2018-08-27  2018-08-27
#[Out]# 180  179      Juul  2018-08-24  2018-08-24
#[Out]# 181  179      Juul  2018-08-22  2018-08-22
#[Out]# 182  180     Merel  2018-08-26  2018-08-26
#[Out]# 183  180     Merel  2018-08-27  2018-08-27
#[Out]# 184  181      Liva  2018-08-24  2018-08-24
#[Out]# 185  181      Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [186 rows x 4 columns]
# Tue, 01 Dec 2020 11:06:11
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 11:06:30
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN stores AS S ON S.sID = P.sID 

WHERE S.NAME <> 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 11:06:51
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN store AS S ON S.sID = P.sID 

WHERE S.NAME <> 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 11:07:12
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN store AS S ON S.sID = P.sID 

WHERE S.sNAME <> 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      7      Bram
#[Out]# 7      8      Liam
#[Out]# 8     10       Sam
#[Out]# 9     11     Thijs
#[Out]# 10    13     James
#[Out]# 11    15      Noud
#[Out]# 12    16    Julian
#[Out]# 13    17       Dex
#[Out]# 14    18      Hugo
#[Out]# 15    19      Lars
#[Out]# 16    20      Gijs
#[Out]# 17    21  Benjamin
#[Out]# 18    22      Mats
#[Out]# 19    24      Luca
#[Out]# 20    25     Mason
#[Out]# 21    26    Jayden
#[Out]# 22    27       Tim
#[Out]# 23    28      Siem
#[Out]# 24    29     Ruben
#[Out]# 25    30      Teun
#[Out]# 26    31   Olivier
#[Out]# 27    33      Sven
#[Out]# 28    34     David
#[Out]# 29    35     Stijn
#[Out]# ..   ...       ...
#[Out]# 102  147    Isabel
#[Out]# 103  149     Lizzy
#[Out]# 104  151      Jill
#[Out]# 105  152      Anne
#[Out]# 106  157      Puck
#[Out]# 107  159     Fenne
#[Out]# 108  161     Floor
#[Out]# 109  162     Elena
#[Out]# 110  163      Cato
#[Out]# 111  165     Hanna
#[Out]# 112  167    Veerle
#[Out]# 113  168      Kiki
#[Out]# 114  169      Lily
#[Out]# 115  170      Iris
#[Out]# 116  171     Tessa
#[Out]# 117  172      Lana
#[Out]# 118  175       Sam
#[Out]# 119  176     Amira
#[Out]# 120  177     Eline
#[Out]# 121  178      Elif
#[Out]# 122  179      Juul
#[Out]# 123  180     Merel
#[Out]# 124  181      Liva
#[Out]# 125  182   Johanna
#[Out]# 126  184     Wilko
#[Out]# 127  185      Nick
#[Out]# 128  186    Angela
#[Out]# 129  188      Pino
#[Out]# 130  189      Koen
#[Out]# 131  190    Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 11:08:16
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName
,s.sName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN store AS S ON S.sID = P.sID 

--WHERE S.sNAME <> 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName        sName
#[Out]# 0      0     Noah       Sligro
#[Out]# 1      1      Sem       Sligro
#[Out]# 2      1      Sem         Lidl
#[Out]# 3      1      Sem    Hoogvliet
#[Out]# 4      1      Sem         Dirk
#[Out]# 5      1      Sem  Albert Hein
#[Out]# 6      2    Lucas         Lidl
#[Out]# 7      2    Lucas         Coop
#[Out]# 8      2    Lucas       Sligro
#[Out]# 9      3     Finn       Sligro
#[Out]# 10     3     Finn         Dirk
#[Out]# 11     3     Finn  Albert Hein
#[Out]# 12     4     Daan       Sligro
#[Out]# 13     4     Daan        Jumbo
#[Out]# 14     4     Daan    Hoogvliet
#[Out]# 15     4     Daan         Coop
#[Out]# 16     4     Daan  Albert Hein
#[Out]# 17     5     Levi    Hoogvliet
#[Out]# 18     5     Levi         Coop
#[Out]# 19     5     Levi         Lidl
#[Out]# 20     6    Milan         None
#[Out]# 21     7     Bram       Sligro
#[Out]# 22     7     Bram  Albert Hein
#[Out]# 23     7     Bram         Lidl
#[Out]# 24     7     Bram    Hoogvliet
#[Out]# 25     8     Liam         Coop
#[Out]# 26     9   Thomas         None
#[Out]# 27    10      Sam         Coop
#[Out]# 28    11    Thijs         Coop
#[Out]# 29    12     Adam         None
#[Out]# ..   ...      ...          ...
#[Out]# 362  176    Amira         Coop
#[Out]# 363  176    Amira         Lidl
#[Out]# 364  177    Eline  Albert Hein
#[Out]# 365  177    Eline         Coop
#[Out]# 366  177    Eline    Hoogvliet
#[Out]# 367  178     Elif         Coop
#[Out]# 368  178     Elif       Sligro
#[Out]# 369  179     Juul  Albert Hein
#[Out]# 370  179     Juul         Lidl
#[Out]# 371  179     Juul         Coop
#[Out]# 372  179     Juul         Dirk
#[Out]# 373  180    Merel         Coop
#[Out]# 374  180    Merel        Jumbo
#[Out]# 375  181     Liva         Coop
#[Out]# 376  181     Liva       Sligro
#[Out]# 377  182  Johanna    Hoogvliet
#[Out]# 378  182  Johanna       Sligro
#[Out]# 379  183    Nikki         None
#[Out]# 380  184    Wilko         Coop
#[Out]# 381  185     Nick        Jumbo
#[Out]# 382  186   Angela        Jumbo
#[Out]# 383  188     Pino        Jumbo
#[Out]# 384  189     Koen        Jumbo
#[Out]# 385  190   Kostas         Coop
#[Out]# 386  190   Kostas    Hoogvliet
#[Out]# 387  190   Kostas        Jumbo
#[Out]# 388  190   Kostas       Sligro
#[Out]# 389  190   Kostas  Albert Hein
#[Out]# 390  190   Kostas         Lidl
#[Out]# 391  190   Kostas         Dirk
#[Out]# 
#[Out]# [392 rows x 3 columns]
# Tue, 01 Dec 2020 11:08:38
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName
,s.sName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN store AS S ON S.sID = P.sID 

WHERE S.sNAME <> 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName        sName
#[Out]# 0      0     Noah       Sligro
#[Out]# 1      1      Sem       Sligro
#[Out]# 2      1      Sem         Lidl
#[Out]# 3      1      Sem    Hoogvliet
#[Out]# 4      1      Sem         Dirk
#[Out]# 5      1      Sem  Albert Hein
#[Out]# 6      2    Lucas         Lidl
#[Out]# 7      2    Lucas       Sligro
#[Out]# 8      3     Finn       Sligro
#[Out]# 9      3     Finn         Dirk
#[Out]# 10     3     Finn  Albert Hein
#[Out]# 11     4     Daan       Sligro
#[Out]# 12     4     Daan        Jumbo
#[Out]# 13     4     Daan    Hoogvliet
#[Out]# 14     4     Daan  Albert Hein
#[Out]# 15     5     Levi    Hoogvliet
#[Out]# 16     5     Levi         Lidl
#[Out]# 17     7     Bram       Sligro
#[Out]# 18     7     Bram  Albert Hein
#[Out]# 19     7     Bram         Lidl
#[Out]# 20     7     Bram    Hoogvliet
#[Out]# 21    13    James    Hoogvliet
#[Out]# 22    13    James  Albert Hein
#[Out]# 23    13    James         Dirk
#[Out]# 24    13    James         Lidl
#[Out]# 25    13    James       Sligro
#[Out]# 26    15     Noud  Albert Hein
#[Out]# 27    16   Julian         Lidl
#[Out]# 28    16   Julian  Albert Hein
#[Out]# 29    16   Julian    Hoogvliet
#[Out]# ..   ...      ...          ...
#[Out]# 230  170     Iris  Albert Hein
#[Out]# 231  170     Iris    Hoogvliet
#[Out]# 232  170     Iris         Lidl
#[Out]# 233  171    Tessa  Albert Hein
#[Out]# 234  171    Tessa        Jumbo
#[Out]# 235  172     Lana        Jumbo
#[Out]# 236  175      Sam         Lidl
#[Out]# 237  175      Sam       Sligro
#[Out]# 238  176    Amira    Hoogvliet
#[Out]# 239  176    Amira         Lidl
#[Out]# 240  177    Eline  Albert Hein
#[Out]# 241  177    Eline    Hoogvliet
#[Out]# 242  178     Elif       Sligro
#[Out]# 243  179     Juul  Albert Hein
#[Out]# 244  179     Juul         Lidl
#[Out]# 245  179     Juul         Dirk
#[Out]# 246  180    Merel        Jumbo
#[Out]# 247  181     Liva       Sligro
#[Out]# 248  182  Johanna    Hoogvliet
#[Out]# 249  182  Johanna       Sligro
#[Out]# 250  185     Nick        Jumbo
#[Out]# 251  186   Angela        Jumbo
#[Out]# 252  188     Pino        Jumbo
#[Out]# 253  189     Koen        Jumbo
#[Out]# 254  190   Kostas    Hoogvliet
#[Out]# 255  190   Kostas        Jumbo
#[Out]# 256  190   Kostas       Sligro
#[Out]# 257  190   Kostas  Albert Hein
#[Out]# 258  190   Kostas         Lidl
#[Out]# 259  190   Kostas         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]
# Tue, 01 Dec 2020 11:16:20
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName
,s.sName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN store AS S ON S.sID = P.sID 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName        sName
#[Out]# 0      0     Noah       Sligro
#[Out]# 1      1      Sem       Sligro
#[Out]# 2      1      Sem         Lidl
#[Out]# 3      1      Sem    Hoogvliet
#[Out]# 4      1      Sem         Dirk
#[Out]# 5      1      Sem  Albert Hein
#[Out]# 6      2    Lucas         Lidl
#[Out]# 7      2    Lucas         Coop
#[Out]# 8      2    Lucas       Sligro
#[Out]# 9      3     Finn       Sligro
#[Out]# 10     3     Finn         Dirk
#[Out]# 11     3     Finn  Albert Hein
#[Out]# 12     4     Daan       Sligro
#[Out]# 13     4     Daan        Jumbo
#[Out]# 14     4     Daan    Hoogvliet
#[Out]# 15     4     Daan         Coop
#[Out]# 16     4     Daan  Albert Hein
#[Out]# 17     5     Levi    Hoogvliet
#[Out]# 18     5     Levi         Coop
#[Out]# 19     5     Levi         Lidl
#[Out]# 20     6    Milan         None
#[Out]# 21     7     Bram       Sligro
#[Out]# 22     7     Bram  Albert Hein
#[Out]# 23     7     Bram         Lidl
#[Out]# 24     7     Bram    Hoogvliet
#[Out]# 25     8     Liam         Coop
#[Out]# 26     9   Thomas         None
#[Out]# 27    10      Sam         Coop
#[Out]# 28    11    Thijs         Coop
#[Out]# 29    12     Adam         None
#[Out]# ..   ...      ...          ...
#[Out]# 362  176    Amira         Coop
#[Out]# 363  176    Amira         Lidl
#[Out]# 364  177    Eline  Albert Hein
#[Out]# 365  177    Eline         Coop
#[Out]# 366  177    Eline    Hoogvliet
#[Out]# 367  178     Elif         Coop
#[Out]# 368  178     Elif       Sligro
#[Out]# 369  179     Juul  Albert Hein
#[Out]# 370  179     Juul         Lidl
#[Out]# 371  179     Juul         Coop
#[Out]# 372  179     Juul         Dirk
#[Out]# 373  180    Merel         Coop
#[Out]# 374  180    Merel        Jumbo
#[Out]# 375  181     Liva         Coop
#[Out]# 376  181     Liva       Sligro
#[Out]# 377  182  Johanna    Hoogvliet
#[Out]# 378  182  Johanna       Sligro
#[Out]# 379  183    Nikki         None
#[Out]# 380  184    Wilko         Coop
#[Out]# 381  185     Nick        Jumbo
#[Out]# 382  186   Angela        Jumbo
#[Out]# 383  188     Pino        Jumbo
#[Out]# 384  189     Koen        Jumbo
#[Out]# 385  190   Kostas         Coop
#[Out]# 386  190   Kostas    Hoogvliet
#[Out]# 387  190   Kostas        Jumbo
#[Out]# 388  190   Kostas       Sligro
#[Out]# 389  190   Kostas  Albert Hein
#[Out]# 390  190   Kostas         Lidl
#[Out]# 391  190   Kostas         Dirk
#[Out]# 
#[Out]# [392 rows x 3 columns]
# Tue, 01 Dec 2020 11:16:25
query3_3 = '''
SELECT 
C.cID
,C.cName
,s.sName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN store AS S ON S.sID = P.sID 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem       Sligro
#[Out]# 2      1     Sem         Lidl
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem         Dirk
#[Out]# 5      1     Sem  Albert Hein
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas         Coop
#[Out]# 10     2   Lucas       Sligro
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn       Sligro
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn  Albert Hein
#[Out]# 16     4    Daan       Sligro
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan    Hoogvliet
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan  Albert Hein
#[Out]# 21     4    Daan         Coop
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Coop
#[Out]# 24     5    Levi    Hoogvliet
#[Out]# 25     5    Levi         Lidl
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi         Coop
#[Out]# 28     6   Milan         None
#[Out]# 29     7    Bram       Sligro
#[Out]# ..   ...     ...          ...
#[Out]# 537  190  Kostas         Coop
#[Out]# 538  190  Kostas         Lidl
#[Out]# 539  190  Kostas         Lidl
#[Out]# 540  190  Kostas        Jumbo
#[Out]# 541  190  Kostas    Hoogvliet
#[Out]# 542  190  Kostas       Sligro
#[Out]# 543  190  Kostas    Hoogvliet
#[Out]# 544  190  Kostas  Albert Hein
#[Out]# 545  190  Kostas       Sligro
#[Out]# 546  190  Kostas         Coop
#[Out]# 547  190  Kostas  Albert Hein
#[Out]# 548  190  Kostas         Coop
#[Out]# 549  190  Kostas         Lidl
#[Out]# 550  190  Kostas         Coop
#[Out]# 551  190  Kostas    Hoogvliet
#[Out]# 552  190  Kostas    Hoogvliet
#[Out]# 553  190  Kostas       Sligro
#[Out]# 554  190  Kostas         Coop
#[Out]# 555  190  Kostas         Lidl
#[Out]# 556  190  Kostas         Coop
#[Out]# 557  190  Kostas         Dirk
#[Out]# 558  190  Kostas         Coop
#[Out]# 559  190  Kostas        Jumbo
#[Out]# 560  190  Kostas         Dirk
#[Out]# 561  190  Kostas         Dirk
#[Out]# 562  190  Kostas        Jumbo
#[Out]# 563  190  Kostas         Lidl
#[Out]# 564  190  Kostas         Lidl
#[Out]# 565  190  Kostas        Jumbo
#[Out]# 566  190  Kostas        Jumbo
#[Out]# 
#[Out]# [567 rows x 3 columns]
# Tue, 01 Dec 2020 11:16:45
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName
,s.sName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN store AS S ON S.sID = P.sID 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName        sName
#[Out]# 0      0     Noah       Sligro
#[Out]# 1      1      Sem       Sligro
#[Out]# 2      1      Sem         Lidl
#[Out]# 3      1      Sem    Hoogvliet
#[Out]# 4      1      Sem         Dirk
#[Out]# 5      1      Sem  Albert Hein
#[Out]# 6      2    Lucas         Lidl
#[Out]# 7      2    Lucas         Coop
#[Out]# 8      2    Lucas       Sligro
#[Out]# 9      3     Finn       Sligro
#[Out]# 10     3     Finn         Dirk
#[Out]# 11     3     Finn  Albert Hein
#[Out]# 12     4     Daan       Sligro
#[Out]# 13     4     Daan        Jumbo
#[Out]# 14     4     Daan    Hoogvliet
#[Out]# 15     4     Daan         Coop
#[Out]# 16     4     Daan  Albert Hein
#[Out]# 17     5     Levi    Hoogvliet
#[Out]# 18     5     Levi         Coop
#[Out]# 19     5     Levi         Lidl
#[Out]# 20     6    Milan         None
#[Out]# 21     7     Bram       Sligro
#[Out]# 22     7     Bram  Albert Hein
#[Out]# 23     7     Bram         Lidl
#[Out]# 24     7     Bram    Hoogvliet
#[Out]# 25     8     Liam         Coop
#[Out]# 26     9   Thomas         None
#[Out]# 27    10      Sam         Coop
#[Out]# 28    11    Thijs         Coop
#[Out]# 29    12     Adam         None
#[Out]# ..   ...      ...          ...
#[Out]# 362  176    Amira         Coop
#[Out]# 363  176    Amira         Lidl
#[Out]# 364  177    Eline  Albert Hein
#[Out]# 365  177    Eline         Coop
#[Out]# 366  177    Eline    Hoogvliet
#[Out]# 367  178     Elif         Coop
#[Out]# 368  178     Elif       Sligro
#[Out]# 369  179     Juul  Albert Hein
#[Out]# 370  179     Juul         Lidl
#[Out]# 371  179     Juul         Coop
#[Out]# 372  179     Juul         Dirk
#[Out]# 373  180    Merel         Coop
#[Out]# 374  180    Merel        Jumbo
#[Out]# 375  181     Liva         Coop
#[Out]# 376  181     Liva       Sligro
#[Out]# 377  182  Johanna    Hoogvliet
#[Out]# 378  182  Johanna       Sligro
#[Out]# 379  183    Nikki         None
#[Out]# 380  184    Wilko         Coop
#[Out]# 381  185     Nick        Jumbo
#[Out]# 382  186   Angela        Jumbo
#[Out]# 383  188     Pino        Jumbo
#[Out]# 384  189     Koen        Jumbo
#[Out]# 385  190   Kostas         Coop
#[Out]# 386  190   Kostas    Hoogvliet
#[Out]# 387  190   Kostas        Jumbo
#[Out]# 388  190   Kostas       Sligro
#[Out]# 389  190   Kostas  Albert Hein
#[Out]# 390  190   Kostas         Lidl
#[Out]# 391  190   Kostas         Dirk
#[Out]# 
#[Out]# [392 rows x 3 columns]
# Tue, 01 Dec 2020 11:18:38
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName
,s.sName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN store AS S ON S.sID = P.sID 

WHERE S.sName <> 'coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName        sName
#[Out]# 0      0     Noah       Sligro
#[Out]# 1      1      Sem       Sligro
#[Out]# 2      1      Sem         Lidl
#[Out]# 3      1      Sem    Hoogvliet
#[Out]# 4      1      Sem         Dirk
#[Out]# 5      1      Sem  Albert Hein
#[Out]# 6      2    Lucas         Lidl
#[Out]# 7      2    Lucas         Coop
#[Out]# 8      2    Lucas       Sligro
#[Out]# 9      3     Finn       Sligro
#[Out]# 10     3     Finn         Dirk
#[Out]# 11     3     Finn  Albert Hein
#[Out]# 12     4     Daan       Sligro
#[Out]# 13     4     Daan        Jumbo
#[Out]# 14     4     Daan    Hoogvliet
#[Out]# 15     4     Daan         Coop
#[Out]# 16     4     Daan  Albert Hein
#[Out]# 17     5     Levi    Hoogvliet
#[Out]# 18     5     Levi         Coop
#[Out]# 19     5     Levi         Lidl
#[Out]# 20     7     Bram       Sligro
#[Out]# 21     7     Bram  Albert Hein
#[Out]# 22     7     Bram         Lidl
#[Out]# 23     7     Bram    Hoogvliet
#[Out]# 24     8     Liam         Coop
#[Out]# 25    10      Sam         Coop
#[Out]# 26    11    Thijs         Coop
#[Out]# 27    13    James    Hoogvliet
#[Out]# 28    13    James  Albert Hein
#[Out]# 29    13    James         Dirk
#[Out]# ..   ...      ...          ...
#[Out]# 304  176    Amira    Hoogvliet
#[Out]# 305  176    Amira         Coop
#[Out]# 306  176    Amira         Lidl
#[Out]# 307  177    Eline  Albert Hein
#[Out]# 308  177    Eline         Coop
#[Out]# 309  177    Eline    Hoogvliet
#[Out]# 310  178     Elif         Coop
#[Out]# 311  178     Elif       Sligro
#[Out]# 312  179     Juul  Albert Hein
#[Out]# 313  179     Juul         Lidl
#[Out]# 314  179     Juul         Coop
#[Out]# 315  179     Juul         Dirk
#[Out]# 316  180    Merel         Coop
#[Out]# 317  180    Merel        Jumbo
#[Out]# 318  181     Liva         Coop
#[Out]# 319  181     Liva       Sligro
#[Out]# 320  182  Johanna    Hoogvliet
#[Out]# 321  182  Johanna       Sligro
#[Out]# 322  184    Wilko         Coop
#[Out]# 323  185     Nick        Jumbo
#[Out]# 324  186   Angela        Jumbo
#[Out]# 325  188     Pino        Jumbo
#[Out]# 326  189     Koen        Jumbo
#[Out]# 327  190   Kostas         Coop
#[Out]# 328  190   Kostas    Hoogvliet
#[Out]# 329  190   Kostas        Jumbo
#[Out]# 330  190   Kostas       Sligro
#[Out]# 331  190   Kostas  Albert Hein
#[Out]# 332  190   Kostas         Lidl
#[Out]# 333  190   Kostas         Dirk
#[Out]# 
#[Out]# [334 rows x 3 columns]
# Tue, 01 Dec 2020 11:18:53
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName
,s.sName

FROM Customer AS C
LEFT JOIN purchase AS P ON P.cId = C.cID
LEFT JOIN store AS S ON S.sID = P.sID 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName        sName
#[Out]# 0      0     Noah       Sligro
#[Out]# 1      1      Sem       Sligro
#[Out]# 2      1      Sem         Lidl
#[Out]# 3      1      Sem    Hoogvliet
#[Out]# 4      1      Sem         Dirk
#[Out]# 5      1      Sem  Albert Hein
#[Out]# 6      2    Lucas         Lidl
#[Out]# 7      2    Lucas         Coop
#[Out]# 8      2    Lucas       Sligro
#[Out]# 9      3     Finn       Sligro
#[Out]# 10     3     Finn         Dirk
#[Out]# 11     3     Finn  Albert Hein
#[Out]# 12     4     Daan       Sligro
#[Out]# 13     4     Daan        Jumbo
#[Out]# 14     4     Daan    Hoogvliet
#[Out]# 15     4     Daan         Coop
#[Out]# 16     4     Daan  Albert Hein
#[Out]# 17     5     Levi    Hoogvliet
#[Out]# 18     5     Levi         Coop
#[Out]# 19     5     Levi         Lidl
#[Out]# 20     6    Milan         None
#[Out]# 21     7     Bram       Sligro
#[Out]# 22     7     Bram  Albert Hein
#[Out]# 23     7     Bram         Lidl
#[Out]# 24     7     Bram    Hoogvliet
#[Out]# 25     8     Liam         Coop
#[Out]# 26     9   Thomas         None
#[Out]# 27    10      Sam         Coop
#[Out]# 28    11    Thijs         Coop
#[Out]# 29    12     Adam         None
#[Out]# ..   ...      ...          ...
#[Out]# 362  176    Amira         Coop
#[Out]# 363  176    Amira         Lidl
#[Out]# 364  177    Eline  Albert Hein
#[Out]# 365  177    Eline         Coop
#[Out]# 366  177    Eline    Hoogvliet
#[Out]# 367  178     Elif         Coop
#[Out]# 368  178     Elif       Sligro
#[Out]# 369  179     Juul  Albert Hein
#[Out]# 370  179     Juul         Lidl
#[Out]# 371  179     Juul         Coop
#[Out]# 372  179     Juul         Dirk
#[Out]# 373  180    Merel         Coop
#[Out]# 374  180    Merel        Jumbo
#[Out]# 375  181     Liva         Coop
#[Out]# 376  181     Liva       Sligro
#[Out]# 377  182  Johanna    Hoogvliet
#[Out]# 378  182  Johanna       Sligro
#[Out]# 379  183    Nikki         None
#[Out]# 380  184    Wilko         Coop
#[Out]# 381  185     Nick        Jumbo
#[Out]# 382  186   Angela        Jumbo
#[Out]# 383  188     Pino        Jumbo
#[Out]# 384  189     Koen        Jumbo
#[Out]# 385  190   Kostas         Coop
#[Out]# 386  190   Kostas    Hoogvliet
#[Out]# 387  190   Kostas        Jumbo
#[Out]# 388  190   Kostas       Sligro
#[Out]# 389  190   Kostas  Albert Hein
#[Out]# 390  190   Kostas         Lidl
#[Out]# 391  190   Kostas         Dirk
#[Out]# 
#[Out]# [392 rows x 3 columns]
# Tue, 01 Dec 2020 14:08:11
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 14:08:26
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018-07%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 14:08:30
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018-03%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 14:08:34
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018-02%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 14:08:37
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 14:08:46
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName
,P.date

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName        date
#[Out]# 0      1       Sem  2018-08-20
#[Out]# 1      1       Sem  2018-08-21
#[Out]# 2      2     Lucas  2018-08-16
#[Out]# 3      2     Lucas  2018-08-17
#[Out]# 4      3      Finn  2018-08-18
#[Out]# 5      3      Finn  2018-08-19
#[Out]# 6      5      Levi  2018-08-17
#[Out]# 7      5      Levi  2018-08-22
#[Out]# 8      5      Levi  2018-08-23
#[Out]# 9      7      Bram  2018-08-23
#[Out]# 10     7      Bram  2018-08-24
#[Out]# 11     7      Bram  2018-08-25
#[Out]# 12     7      Bram  2018-08-26
#[Out]# 13     8      Liam  2018-08-16
#[Out]# 14    10       Sam  2018-08-27
#[Out]# 15    11     Thijs  2018-08-25
#[Out]# 16    13     James  2018-08-17
#[Out]# 17    13     James  2018-08-25
#[Out]# 18    13     James  2018-08-26
#[Out]# 19    13     James  2018-08-27
#[Out]# 20    15      Noud  2018-08-27
#[Out]# 21    17       Dex  2018-08-19
#[Out]# 22    18      Hugo  2018-08-16
#[Out]# 23    18      Hugo  2018-08-18
#[Out]# 24    19      Lars  2018-08-17
#[Out]# 25    19      Lars  2018-08-18
#[Out]# 26    20      Gijs  2018-08-17
#[Out]# 27    20      Gijs  2018-08-18
#[Out]# 28    21  Benjamin  2018-08-15
#[Out]# 29    22      Mats  2018-08-27
#[Out]# ..   ...       ...         ...
#[Out]# 156  165     Hanna  2018-08-23
#[Out]# 157  165     Hanna  2018-08-24
#[Out]# 158  167    Veerle  2018-08-18
#[Out]# 159  167    Veerle  2018-08-19
#[Out]# 160  167    Veerle  2018-08-20
#[Out]# 161  167    Veerle  2018-08-21
#[Out]# 162  167    Veerle  2018-08-15
#[Out]# 163  168      Kiki  2018-08-16
#[Out]# 164  169      Lily  2018-08-16
#[Out]# 165  169      Lily  2018-08-17
#[Out]# 166  169      Lily  2018-08-18
#[Out]# 167  169      Lily  2018-08-19
#[Out]# 168  169      Lily  2018-08-20
#[Out]# 169  169      Lily  2018-08-26
#[Out]# 170  169      Lily  2018-08-27
#[Out]# 171  170      Iris  2018-08-16
#[Out]# 172  171     Tessa  2018-08-20
#[Out]# 173  172      Lana  2018-08-27
#[Out]# 174  172      Lana  2018-08-24
#[Out]# 175  175       Sam  2018-08-19
#[Out]# 176  176     Amira  2018-08-22
#[Out]# 177  176     Amira  2018-08-25
#[Out]# 178  176     Amira  2018-08-26
#[Out]# 179  178      Elif  2018-08-27
#[Out]# 180  179      Juul  2018-08-24
#[Out]# 181  179      Juul  2018-08-22
#[Out]# 182  180     Merel  2018-08-26
#[Out]# 183  180     Merel  2018-08-27
#[Out]# 184  181      Liva  2018-08-24
#[Out]# 185  181      Liva  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Tue, 01 Dec 2020 14:08:57
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018-08%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 14:09:02
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 14:09:06
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018-09%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 14:09:10
query3_2 = ''' 

SELECT DISTINCT
C.cID
,C.cName

FROM customer C
INNER JOIN shoppinglist AS SL ON SL.cID = C.cID
INNER JOIN purchase AS P ON P.date = SL.date AND P.cID = C.cID

WHERE p.Date like '%2018%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 14:35:50
query3_2 = ''' 

SELECT *

FROM customer,purchase

'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID   cName     street     city  tID  cID  sID  pID        date  \
#[Out]# 0        0    Noah  Koestraat  Utrecht    0    0    3   10  2018-08-22   
#[Out]# 1        0    Noah  Koestraat  Utrecht    1    1   23   14  2018-08-20   
#[Out]# 2        0    Noah  Koestraat  Utrecht    2    1    3   16  2018-08-20   
#[Out]# 3        0    Noah  Koestraat  Utrecht    3    1   17    9  2018-08-20   
#[Out]# 4        0    Noah  Koestraat  Utrecht    4    1   32   25  2018-08-20   
#[Out]# 5        0    Noah  Koestraat  Utrecht    5    1   16   26  2018-08-20   
#[Out]# 6        0    Noah  Koestraat  Utrecht    6    1   46   11  2018-08-21   
#[Out]# 7        0    Noah  Koestraat  Utrecht    7    1   36   27  2018-08-21   
#[Out]# 8        0    Noah  Koestraat  Utrecht    8    2   12   20  2018-08-16   
#[Out]# 9        0    Noah  Koestraat  Utrecht    9    2   39    9  2018-08-17   
#[Out]# 10       0    Noah  Koestraat  Utrecht   10    2   13    4  2018-08-17   
#[Out]# 11       0    Noah  Koestraat  Utrecht   11    2   51   13  2018-08-17   
#[Out]# 12       0    Noah  Koestraat  Utrecht   12    2   47   22  2018-08-17   
#[Out]# 13       0    Noah  Koestraat  Utrecht   13    3   44   14  2018-08-18   
#[Out]# 14       0    Noah  Koestraat  Utrecht   14    3   30   26  2018-08-19   
#[Out]# 15       0    Noah  Koestraat  Utrecht   15    3   29    9  2018-08-19   
#[Out]# 16       0    Noah  Koestraat  Utrecht   16    4   17    8  2018-08-24   
#[Out]# 17       0    Noah  Koestraat  Utrecht   17    4   10   27  2018-08-24   
#[Out]# 18       0    Noah  Koestraat  Utrecht   18    4   53   12  2018-08-25   
#[Out]# 19       0    Noah  Koestraat  Utrecht   19    4   21    6  2018-08-24   
#[Out]# 20       0    Noah  Koestraat  Utrecht   20    4    7   13  2018-08-25   
#[Out]# 21       0    Noah  Koestraat  Utrecht   21    4   44   26  2018-08-25   
#[Out]# 22       0    Noah  Koestraat  Utrecht   22    5    4   14  2018-08-17   
#[Out]# 23       0    Noah  Koestraat  Utrecht   23    5   36   28  2018-08-22   
#[Out]# 24       0    Noah  Koestraat  Utrecht   24    5   55    6  2018-08-23   
#[Out]# 25       0    Noah  Koestraat  Utrecht   25    5   51   22  2018-08-23   
#[Out]# 26       0    Noah  Koestraat  Utrecht   26    5    6   16  2018-08-23   
#[Out]# 27       0    Noah  Koestraat  Utrecht   27    5   17   19  2018-08-23   
#[Out]# 28       0    Noah  Koestraat  Utrecht   28    7    3   19  2018-08-23   
#[Out]# 29       0    Noah  Koestraat  Utrecht   29    7   12    2  2018-08-23   
#[Out]# ...    ...     ...        ...      ...  ...  ...  ...  ...         ...   
#[Out]# 96680  190  Kostas   Eindeweg  Utrecht  818  190   34   28  2018-08-20   
#[Out]# 96681  190  Kostas   Eindeweg  Utrecht  819  190   35   27  2018-08-15   
#[Out]# 96682  190  Kostas   Eindeweg  Utrecht  820  190   36    5  2018-08-23   
#[Out]# 96683  190  Kostas   Eindeweg  Utrecht  821  190   37   28  2018-08-15   
#[Out]# 96684  190  Kostas   Eindeweg  Utrecht  822  190   38    7  2018-08-24   
#[Out]# 96685  190  Kostas   Eindeweg  Utrecht  823  190   39    0  2018-08-25   
#[Out]# 96686  190  Kostas   Eindeweg  Utrecht  824  190   40   11  2018-08-15   
#[Out]# 96687  190  Kostas   Eindeweg  Utrecht  825  190   41    6  2018-08-15   
#[Out]# 96688  190  Kostas   Eindeweg  Utrecht  826  190   42   19  2018-08-22   
#[Out]# 96689  190  Kostas   Eindeweg  Utrecht  827  190   43   17  2018-08-17   
#[Out]# 96690  190  Kostas   Eindeweg  Utrecht  828  190   44    9  2018-08-18   
#[Out]# 96691  190  Kostas   Eindeweg  Utrecht  829  190   45   11  2018-08-19   
#[Out]# 96692  190  Kostas   Eindeweg  Utrecht  830  190   46   22  2018-08-25   
#[Out]# 96693  190  Kostas   Eindeweg  Utrecht  831  190   47   17  2018-08-17   
#[Out]# 96694  190  Kostas   Eindeweg  Utrecht  832  190   48   20  2018-08-26   
#[Out]# 96695  190  Kostas   Eindeweg  Utrecht  833  190   49   11  2018-08-17   
#[Out]# 96696  190  Kostas   Eindeweg  Utrecht  834  190   50   21  2018-08-22   
#[Out]# 96697  190  Kostas   Eindeweg  Utrecht  835  190   51   23  2018-08-19   
#[Out]# 96698  190  Kostas   Eindeweg  Utrecht  836  190   52   23  2018-08-15   
#[Out]# 96699  190  Kostas   Eindeweg  Utrecht  837  190   53    8  2018-08-18   
#[Out]# 96700  190  Kostas   Eindeweg  Utrecht  838  190   54    0  2018-08-25   
#[Out]# 96701  190  Kostas   Eindeweg  Utrecht  839  190   55    8  2018-08-18   
#[Out]# 96702  190  Kostas   Eindeweg  Utrecht  840  190   56   11  2018-08-15   
#[Out]# 96703  190  Kostas   Eindeweg  Utrecht  841  190   57   15  2018-08-22   
#[Out]# 96704  190  Kostas   Eindeweg  Utrecht  842  190   58    2  2018-08-19   
#[Out]# 96705  190  Kostas   Eindeweg  Utrecht  843  190   59   17  2018-08-26   
#[Out]# 96706  190  Kostas   Eindeweg  Utrecht  844  190   60    5  2018-08-27   
#[Out]# 96707  190  Kostas   Eindeweg  Utrecht  845  190   61   19  2018-08-23   
#[Out]# 96708  190  Kostas   Eindeweg  Utrecht  846  190   62    9  2018-08-16   
#[Out]# 96709  190  Kostas   Eindeweg  Utrecht  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#        quantity  price  
#[Out]# 0             1   0.45  
#[Out]# 1             2   4.65  
#[Out]# 2             3   1.60  
#[Out]# 3             2   1.25  
#[Out]# 4             4   3.95  
#[Out]# 5             4   2.75  
#[Out]# 6             8   0.90  
#[Out]# 7             6   9.10  
#[Out]# 8             1   2.45  
#[Out]# 9             7   1.35  
#[Out]# 10            6   1.10  
#[Out]# 11            4   3.70  
#[Out]# 12            1   1.55  
#[Out]# 13            2   4.30  
#[Out]# 14            2   2.75  
#[Out]# 15            6   1.45  
#[Out]# 16            2   4.15  
#[Out]# 17            9   9.05  
#[Out]# 18            5  13.60  
#[Out]# 19            2   1.05  
#[Out]# 20            9   3.05  
#[Out]# 21            4   2.75  
#[Out]# 22            6   4.70  
#[Out]# 23            6   8.25  
#[Out]# 24            9   1.10  
#[Out]# 25            2   1.55  
#[Out]# 26            2   1.85  
#[Out]# 27            1   2.20  
#[Out]# 28            2   2.10  
#[Out]# 29            6   1.70  
#[Out]# ...         ...    ...  
#[Out]# 96680         4   2.80  
#[Out]# 96681         5   0.50  
#[Out]# 96682         3   2.55  
#[Out]# 96683         4   0.65  
#[Out]# 96684         4   0.70  
#[Out]# 96685         4   3.70  
#[Out]# 96686         2   3.50  
#[Out]# 96687         5   2.95  
#[Out]# 96688         5   2.75  
#[Out]# 96689         7   1.50  
#[Out]# 96690         5   0.85  
#[Out]# 96691         2   3.55  
#[Out]# 96692         4   2.60  
#[Out]# 96693         4   3.25  
#[Out]# 96694         6   4.30  
#[Out]# 96695         3   3.05  
#[Out]# 96696         6   4.05  
#[Out]# 96697         1   1.50  
#[Out]# 96698         5   2.50  
#[Out]# 96699         4   3.95  
#[Out]# 96700         6   3.50  
#[Out]# 96701         7   2.95  
#[Out]# 96702         4   1.60  
#[Out]# 96703         5   3.25  
#[Out]# 96704         7   0.75  
#[Out]# 96705         2   3.80  
#[Out]# 96706         6   4.35  
#[Out]# 96707         5   2.85  
#[Out]# 96708         2   3.15  
#[Out]# 96709         1   3.30  
#[Out]# 
#[Out]# [96710 rows x 11 columns]
# Tue, 01 Dec 2020 14:36:15
query3_2 = ''' 

SELECT *

FROM customer,purchase AS P

WHERE P.date like '%2018%'

'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID     cName                street       city  tID  cID  sID  pID  \
#[Out]# 0        0      Noah             Koestraat    Utrecht    0    0    3   10   
#[Out]# 1        1       Sem      Rozemarijnstraat      Breda    0    0    3   10   
#[Out]# 2        2     Lucas      Oude Leliestraat  Amsterdam    0    0    3   10   
#[Out]# 3        3      Finn         Stationsplein      Breda    0    0    3   10   
#[Out]# 4        4      Daan          Kalverstraat  Amsterdam    0    0    3   10   
#[Out]# 5        5      Levi        Gasthuisstraat    Utrecht    0    0    3   10   
#[Out]# 6        6     Milan           Parallelweg    Utrecht    0    0    3   10   
#[Out]# 7        7      Bram          Schoolstraat  Eindhoven    0    0    3   10   
#[Out]# 8        8      Liam         Rijsbergseweg      Breda    0    0    3   10   
#[Out]# 9        9    Thomas           Parallelweg  Amsterdam    0    0    3   10   
#[Out]# 10      10       Sam           Langestraat    Tilburg    0    0    3   10   
#[Out]# 11      11     Thijs             Koestraat    Tilburg    0    0    3   10   
#[Out]# 12      12      Adam           Nieuwstraat  Eindhoven    0    0    3   10   
#[Out]# 13      13     James       Sint Annastraat      Breda    0    0    3   10   
#[Out]# 14      14       Max             Eikenlaan    Tilburg    0    0    3   10   
#[Out]# 15      15      Noud          Koningshoeve    Tilburg    0    0    3   10   
#[Out]# 16      16    Julian  Prins Bernhardstraat  Eindhoven    0    0    3   10   
#[Out]# 17      17       Dex          Kasteeldreef    Tilburg    0    0    3   10   
#[Out]# 18      18      Hugo          Kasteeldreef    Tilburg    0    0    3   10   
#[Out]# 19      19      Lars         Rijsbergseweg      Breda    0    0    3   10   
#[Out]# 20      20      Gijs            Heiligeweg  Amsterdam    0    0    3   10   
#[Out]# 21      21  Benjamin           Stationsweg    Tilburg    0    0    3   10   
#[Out]# 22      22      Mats           Molenstraat  Eindhoven    0    0    3   10   
#[Out]# 23      23       Jan       Sint Annastraat      Breda    0    0    3   10   
#[Out]# 24      24      Luca          Kasteeldreef    Tilburg    0    0    3   10   
#[Out]# 25      25     Mason          Keizerstraat  Rotterdam    0    0    3   10   
#[Out]# 26      26    Jayden          Schoolstraat  Eindhoven    0    0    3   10   
#[Out]# 27      27       Tim             Koestraat    Utrecht    0    0    3   10   
#[Out]# 28      28      Siem           Langestraat    Tilburg    0    0    3   10   
#[Out]# 29      29     Ruben              Hofplein  Rotterdam    0    0    3   10   
#[Out]# ...    ...       ...                   ...        ...  ...  ...  ...  ...   
#[Out]# 96680  160      Lara           Langestraat    Tilburg  847  190   63   18   
#[Out]# 96681  161     Floor             Eikenlaan    Tilburg  847  190   63   18   
#[Out]# 96682  162     Elena            Bergselaan  Rotterdam  847  190   63   18   
#[Out]# 96683  163      Cato          Kastanjelaan    Tilburg  847  190   63   18   
#[Out]# 96684  164       Evy      Rozemarijnstraat      Breda  847  190   63   18   
#[Out]# 96685  165     Hanna             Eikenlaan    Tilburg  847  190   63   18   
#[Out]# 96686  166   Rosalie           Stationsweg  Eindhoven  847  190   63   18   
#[Out]# 96687  167    Veerle        Ginnekenstraat      Breda  847  190   63   18   
#[Out]# 96688  168      Kiki          Keizerstraat  Rotterdam  847  190   63   18   
#[Out]# 96689  169      Lily        Gasthuisstraat    Utrecht  847  190   63   18   
#[Out]# 96690  170      Iris          Kastanjelaan  Eindhoven  847  190   63   18   
#[Out]# 96691  171     Tessa           Haringvliet  Rotterdam  847  190   63   18   
#[Out]# 96692  172      Lana             Eikenlaan    Tilburg  847  190   63   18   
#[Out]# 96693  173     Livia      Vierwindenstraat      Breda  847  190   63   18   
#[Out]# 96694  174      Romy           Parallelweg  Eindhoven  847  190   63   18   
#[Out]# 96695  175       Sam             Bredalaan  Eindhoven  847  190   63   18   
#[Out]# 96696  176     Amira           Parallelweg  Amsterdam  847  190   63   18   
#[Out]# 96697  177     Eline          Kalverstraat  Amsterdam  847  190   63   18   
#[Out]# 96698  178      Elif           Parallelweg    Utrecht  847  190   63   18   
#[Out]# 96699  179      Juul        Wilhelminapark    Tilburg  847  190   63   18   
#[Out]# 96700  180     Merel          Kalverstraat  Amsterdam  847  190   63   18   
#[Out]# 96701  181      Liva           Fredriklaan  Eindhoven  847  190   63   18   
#[Out]# 96702  182   Johanna         Beatrixstraat  Eindhoven  847  190   63   18   
#[Out]# 96703  183     Nikki         Julianastraat    Utrecht  847  190   63   18   
#[Out]# 96704  184     Wilko          Onbekendeweg  Eindhoven  847  190   63   18   
#[Out]# 96705  185      Nick                Verweg  Eindhoven  847  190   63   18   
#[Out]# 96706  186    Angela              Dichtweg  Eindhoven  847  190   63   18   
#[Out]# 96707  188      Pino            Maanstraat  Rotterdam  847  190   63   18   
#[Out]# 96708  189      Koen              Akkerweg        Oss  847  190   63   18   
#[Out]# 96709  190    Kostas              Eindeweg    Utrecht  847  190   63   18   
#[Out]# 
#[Out]#              date  quantity  price  
#[Out]# 0      2018-08-22         1   0.45  
#[Out]# 1      2018-08-22         1   0.45  
#[Out]# 2      2018-08-22         1   0.45  
#[Out]# 3      2018-08-22         1   0.45  
#[Out]# 4      2018-08-22         1   0.45  
#[Out]# 5      2018-08-22         1   0.45  
#[Out]# 6      2018-08-22         1   0.45  
#[Out]# 7      2018-08-22         1   0.45  
#[Out]# 8      2018-08-22         1   0.45  
#[Out]# 9      2018-08-22         1   0.45  
#[Out]# 10     2018-08-22         1   0.45  
#[Out]# 11     2018-08-22         1   0.45  
#[Out]# 12     2018-08-22         1   0.45  
#[Out]# 13     2018-08-22         1   0.45  
#[Out]# 14     2018-08-22         1   0.45  
#[Out]# 15     2018-08-22         1   0.45  
#[Out]# 16     2018-08-22         1   0.45  
#[Out]# 17     2018-08-22         1   0.45  
#[Out]# 18     2018-08-22         1   0.45  
#[Out]# 19     2018-08-22         1   0.45  
#[Out]# 20     2018-08-22         1   0.45  
#[Out]# 21     2018-08-22         1   0.45  
#[Out]# 22     2018-08-22         1   0.45  
#[Out]# 23     2018-08-22         1   0.45  
#[Out]# 24     2018-08-22         1   0.45  
#[Out]# 25     2018-08-22         1   0.45  
#[Out]# 26     2018-08-22         1   0.45  
#[Out]# 27     2018-08-22         1   0.45  
#[Out]# 28     2018-08-22         1   0.45  
#[Out]# 29     2018-08-22         1   0.45  
#[Out]# ...           ...       ...    ...  
#[Out]# 96680  2018-08-21         1   3.30  
#[Out]# 96681  2018-08-21         1   3.30  
#[Out]# 96682  2018-08-21         1   3.30  
#[Out]# 96683  2018-08-21         1   3.30  
#[Out]# 96684  2018-08-21         1   3.30  
#[Out]# 96685  2018-08-21         1   3.30  
#[Out]# 96686  2018-08-21         1   3.30  
#[Out]# 96687  2018-08-21         1   3.30  
#[Out]# 96688  2018-08-21         1   3.30  
#[Out]# 96689  2018-08-21         1   3.30  
#[Out]# 96690  2018-08-21         1   3.30  
#[Out]# 96691  2018-08-21         1   3.30  
#[Out]# 96692  2018-08-21         1   3.30  
#[Out]# 96693  2018-08-21         1   3.30  
#[Out]# 96694  2018-08-21         1   3.30  
#[Out]# 96695  2018-08-21         1   3.30  
#[Out]# 96696  2018-08-21         1   3.30  
#[Out]# 96697  2018-08-21         1   3.30  
#[Out]# 96698  2018-08-21         1   3.30  
#[Out]# 96699  2018-08-21         1   3.30  
#[Out]# 96700  2018-08-21         1   3.30  
#[Out]# 96701  2018-08-21         1   3.30  
#[Out]# 96702  2018-08-21         1   3.30  
#[Out]# 96703  2018-08-21         1   3.30  
#[Out]# 96704  2018-08-21         1   3.30  
#[Out]# 96705  2018-08-21         1   3.30  
#[Out]# 96706  2018-08-21         1   3.30  
#[Out]# 96707  2018-08-21         1   3.30  
#[Out]# 96708  2018-08-21         1   3.30  
#[Out]# 96709  2018-08-21         1   3.30  
#[Out]# 
#[Out]# [96710 rows x 11 columns]
# Tue, 01 Dec 2020 14:36:29
query3_2 = ''' 

SELECT *

FROM customer,purchase AS P,shoppinglist as SL

WHERE P.date like '%2018%'

'''

pd.read_sql_query(query3_2, conn)

# IPython log file

# Tue, 01 Dec 2020 14:38:45
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 14:38:47
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 01 Dec 2020 14:39:00
query3_2 = ''' 

SELECT *

FROM customer


'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName                street       city
#[Out]# 0      0      Noah             Koestraat    Utrecht
#[Out]# 1      1       Sem      Rozemarijnstraat      Breda
#[Out]# 2      2     Lucas      Oude Leliestraat  Amsterdam
#[Out]# 3      3      Finn         Stationsplein      Breda
#[Out]# 4      4      Daan          Kalverstraat  Amsterdam
#[Out]# 5      5      Levi        Gasthuisstraat    Utrecht
#[Out]# 6      6     Milan           Parallelweg    Utrecht
#[Out]# 7      7      Bram          Schoolstraat  Eindhoven
#[Out]# 8      8      Liam         Rijsbergseweg      Breda
#[Out]# 9      9    Thomas           Parallelweg  Amsterdam
#[Out]# 10    10       Sam           Langestraat    Tilburg
#[Out]# 11    11     Thijs             Koestraat    Tilburg
#[Out]# 12    12      Adam           Nieuwstraat  Eindhoven
#[Out]# 13    13     James       Sint Annastraat      Breda
#[Out]# 14    14       Max             Eikenlaan    Tilburg
#[Out]# 15    15      Noud          Koningshoeve    Tilburg
#[Out]# 16    16    Julian  Prins Bernhardstraat  Eindhoven
#[Out]# 17    17       Dex          Kasteeldreef    Tilburg
#[Out]# 18    18      Hugo          Kasteeldreef    Tilburg
#[Out]# 19    19      Lars         Rijsbergseweg      Breda
#[Out]# 20    20      Gijs            Heiligeweg  Amsterdam
#[Out]# 21    21  Benjamin           Stationsweg    Tilburg
#[Out]# 22    22      Mats           Molenstraat  Eindhoven
#[Out]# 23    23       Jan       Sint Annastraat      Breda
#[Out]# 24    24      Luca          Kasteeldreef    Tilburg
#[Out]# 25    25     Mason          Keizerstraat  Rotterdam
#[Out]# 26    26    Jayden          Schoolstraat  Eindhoven
#[Out]# 27    27       Tim             Koestraat    Utrecht
#[Out]# 28    28      Siem           Langestraat    Tilburg
#[Out]# 29    29     Ruben              Hofplein  Rotterdam
#[Out]# ..   ...       ...                   ...        ...
#[Out]# 160  160      Lara           Langestraat    Tilburg
#[Out]# 161  161     Floor             Eikenlaan    Tilburg
#[Out]# 162  162     Elena            Bergselaan  Rotterdam
#[Out]# 163  163      Cato          Kastanjelaan    Tilburg
#[Out]# 164  164       Evy      Rozemarijnstraat      Breda
#[Out]# 165  165     Hanna             Eikenlaan    Tilburg
#[Out]# 166  166   Rosalie           Stationsweg  Eindhoven
#[Out]# 167  167    Veerle        Ginnekenstraat      Breda
#[Out]# 168  168      Kiki          Keizerstraat  Rotterdam
#[Out]# 169  169      Lily        Gasthuisstraat    Utrecht
#[Out]# 170  170      Iris          Kastanjelaan  Eindhoven
#[Out]# 171  171     Tessa           Haringvliet  Rotterdam
#[Out]# 172  172      Lana             Eikenlaan    Tilburg
#[Out]# 173  173     Livia      Vierwindenstraat      Breda
#[Out]# 174  174      Romy           Parallelweg  Eindhoven
#[Out]# 175  175       Sam             Bredalaan  Eindhoven
#[Out]# 176  176     Amira           Parallelweg  Amsterdam
#[Out]# 177  177     Eline          Kalverstraat  Amsterdam
#[Out]# 178  178      Elif           Parallelweg    Utrecht
#[Out]# 179  179      Juul        Wilhelminapark    Tilburg
#[Out]# 180  180     Merel          Kalverstraat  Amsterdam
#[Out]# 181  181      Liva           Fredriklaan  Eindhoven
#[Out]# 182  182   Johanna         Beatrixstraat  Eindhoven
#[Out]# 183  183     Nikki         Julianastraat    Utrecht
#[Out]# 184  184     Wilko          Onbekendeweg  Eindhoven
#[Out]# 185  185      Nick                Verweg  Eindhoven
#[Out]# 186  186    Angela              Dichtweg  Eindhoven
#[Out]# 187  188      Pino            Maanstraat  Rotterdam
#[Out]# 188  189      Koen              Akkerweg        Oss
#[Out]# 189  190    Kostas              Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Tue, 01 Dec 2020 14:40:11
query3_2 = ''' 

SELECT *

FROM customer,shoppinglist


'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID   cName     street     city  cID  pID  quantity        date
#[Out]# 0        0    Noah  Koestraat  Utrecht    1   14         2  2018-08-20
#[Out]# 1        0    Noah  Koestraat  Utrecht    1   16         3  2018-08-20
#[Out]# 2        0    Noah  Koestraat  Utrecht    1    9         2  2018-08-20
#[Out]# 3        0    Noah  Koestraat  Utrecht    1   25         4  2018-08-20
#[Out]# 4        0    Noah  Koestraat  Utrecht    1   21         6  2018-08-20
#[Out]# 5        0    Noah  Koestraat  Utrecht    1   26         4  2018-08-20
#[Out]# 6        0    Noah  Koestraat  Utrecht    1   11         8  2018-08-20
#[Out]# 7        0    Noah  Koestraat  Utrecht    1   27         6  2018-08-21
#[Out]# 8        0    Noah  Koestraat  Utrecht    2   20         4  2018-08-16
#[Out]# 9        0    Noah  Koestraat  Utrecht    2    9         7  2018-08-16
#[Out]# 10       0    Noah  Koestraat  Utrecht    2    4         6  2018-08-17
#[Out]# 11       0    Noah  Koestraat  Utrecht    2   13         4  2018-08-17
#[Out]# 12       0    Noah  Koestraat  Utrecht    2   22         1  2018-08-17
#[Out]# 13       0    Noah  Koestraat  Utrecht    3   14         2  2018-08-18
#[Out]# 14       0    Noah  Koestraat  Utrecht    3   26         2  2018-08-18
#[Out]# 15       0    Noah  Koestraat  Utrecht    3    9         6  2018-08-19
#[Out]# 16       0    Noah  Koestraat  Utrecht    5   14         6  2018-08-17
#[Out]# 17       0    Noah  Koestraat  Utrecht    5   28         6  2018-08-22
#[Out]# 18       0    Noah  Koestraat  Utrecht    5    6         9  2018-08-22
#[Out]# 19       0    Noah  Koestraat  Utrecht    5   22         2  2018-08-23
#[Out]# 20       0    Noah  Koestraat  Utrecht    5   16         2  2018-08-23
#[Out]# 21       0    Noah  Koestraat  Utrecht    5   19         1  2018-08-23
#[Out]# 22       0    Noah  Koestraat  Utrecht    7   19         2  2018-08-23
#[Out]# 23       0    Noah  Koestraat  Utrecht    7    2         6  2018-08-23
#[Out]# 24       0    Noah  Koestraat  Utrecht    7   16         4  2018-08-23
#[Out]# 25       0    Noah  Koestraat  Utrecht    7   12         2  2018-08-24
#[Out]# 26       0    Noah  Koestraat  Utrecht    7    6         4  2018-08-25
#[Out]# 27       0    Noah  Koestraat  Utrecht    7   20         6  2018-08-26
#[Out]# 28       0    Noah  Koestraat  Utrecht    8   10         9  2018-08-16
#[Out]# 29       0    Noah  Koestraat  Utrecht    8    6         7  2018-08-16
#[Out]# ...    ...     ...        ...      ...  ...  ...       ...         ...
#[Out]# 93450  190  Kostas   Eindeweg  Utrecht  176    4         7  2018-08-22
#[Out]# 93451  190  Kostas   Eindeweg  Utrecht  176   24         9  2018-08-25
#[Out]# 93452  190  Kostas   Eindeweg  Utrecht  176   13         7  2018-08-25
#[Out]# 93453  190  Kostas   Eindeweg  Utrecht  176    0         2  2018-08-25
#[Out]# 93454  190  Kostas   Eindeweg  Utrecht  176   14         2  2018-08-25
#[Out]# 93455  190  Kostas   Eindeweg  Utrecht  176   11         6  2018-08-25
#[Out]# 93456  190  Kostas   Eindeweg  Utrecht  176   21         8  2018-08-25
#[Out]# 93457  190  Kostas   Eindeweg  Utrecht  176    5         9  2018-08-26
#[Out]# 93458  190  Kostas   Eindeweg  Utrecht  178   25         9  2018-08-27
#[Out]# 93459  190  Kostas   Eindeweg  Utrecht  178   24         1  2018-08-27
#[Out]# 93460  190  Kostas   Eindeweg  Utrecht  179   14         5  2018-08-24
#[Out]# 93461  190  Kostas   Eindeweg  Utrecht  179   11         3  2018-08-24
#[Out]# 93462  190  Kostas   Eindeweg  Utrecht  179   17         2  2018-08-24
#[Out]# 93463  190  Kostas   Eindeweg  Utrecht  179   27         8  2018-08-22
#[Out]# 93464  190  Kostas   Eindeweg  Utrecht  179   16         9  2018-08-22
#[Out]# 93465  190  Kostas   Eindeweg  Utrecht  179   10         7  2018-08-22
#[Out]# 93466  190  Kostas   Eindeweg  Utrecht  180   26         3  2018-08-26
#[Out]# 93467  190  Kostas   Eindeweg  Utrecht  180   13         8  2018-08-26
#[Out]# 93468  190  Kostas   Eindeweg  Utrecht  180   10         3  2018-08-27
#[Out]# 93469  190  Kostas   Eindeweg  Utrecht  181   26         4  2018-08-24
#[Out]# 93470  190  Kostas   Eindeweg  Utrecht  181    6         3  2018-08-24
#[Out]# 93471  190  Kostas   Eindeweg  Utrecht  181   21         5  2018-08-27
#[Out]# 93472  190  Kostas   Eindeweg  Utrecht  181    5         3  2018-08-27
#[Out]# 93473  190  Kostas   Eindeweg  Utrecht  183    5         7  2018-08-19
#[Out]# 93474  190  Kostas   Eindeweg  Utrecht  183   10         2  2018-08-20
#[Out]# 93475  190  Kostas   Eindeweg  Utrecht  183   12         9  2018-08-21
#[Out]# 93476  190  Kostas   Eindeweg  Utrecht  183   18         8  2018-08-21
#[Out]# 93477  190  Kostas   Eindeweg  Utrecht  183    6         3  2018-08-22
#[Out]# 93478  190  Kostas   Eindeweg  Utrecht  183   14         7  2018-08-22
#[Out]# 93479  190  Kostas   Eindeweg  Utrecht  183   25         4  2018-08-22
#[Out]# 
#[Out]# [93480 rows x 8 columns]
# Tue, 01 Dec 2020 14:40:48
query3_2 = ''' 

SELECT *

FROM customer AS C, shoppinglist AS SL

WHERE C.cId = SL.cID


'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName            street       city  cID  pID  quantity        date
#[Out]# 0      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20
#[Out]# 1      1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20
#[Out]# 2      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20
#[Out]# 3      1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20
#[Out]# 4      1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20
#[Out]# 5      1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20
#[Out]# 6      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20
#[Out]# 7      1    Sem  Rozemarijnstraat      Breda    1   27         6  2018-08-21
#[Out]# 8      2  Lucas  Oude Leliestraat  Amsterdam    2   20         4  2018-08-16
#[Out]# 9      2  Lucas  Oude Leliestraat  Amsterdam    2    9         7  2018-08-16
#[Out]# 10     2  Lucas  Oude Leliestraat  Amsterdam    2    4         6  2018-08-17
#[Out]# 11     2  Lucas  Oude Leliestraat  Amsterdam    2   13         4  2018-08-17
#[Out]# 12     2  Lucas  Oude Leliestraat  Amsterdam    2   22         1  2018-08-17
#[Out]# 13     3   Finn     Stationsplein      Breda    3   14         2  2018-08-18
#[Out]# 14     3   Finn     Stationsplein      Breda    3   26         2  2018-08-18
#[Out]# 15     3   Finn     Stationsplein      Breda    3    9         6  2018-08-19
#[Out]# 16     5   Levi    Gasthuisstraat    Utrecht    5   14         6  2018-08-17
#[Out]# 17     5   Levi    Gasthuisstraat    Utrecht    5   28         6  2018-08-22
#[Out]# 18     5   Levi    Gasthuisstraat    Utrecht    5    6         9  2018-08-22
#[Out]# 19     5   Levi    Gasthuisstraat    Utrecht    5   22         2  2018-08-23
#[Out]# 20     5   Levi    Gasthuisstraat    Utrecht    5   16         2  2018-08-23
#[Out]# 21     5   Levi    Gasthuisstraat    Utrecht    5   19         1  2018-08-23
#[Out]# 22     7   Bram      Schoolstraat  Eindhoven    7   19         2  2018-08-23
#[Out]# 23     7   Bram      Schoolstraat  Eindhoven    7    2         6  2018-08-23
#[Out]# 24     7   Bram      Schoolstraat  Eindhoven    7   16         4  2018-08-23
#[Out]# 25     7   Bram      Schoolstraat  Eindhoven    7   12         2  2018-08-24
#[Out]# 26     7   Bram      Schoolstraat  Eindhoven    7    6         4  2018-08-25
#[Out]# 27     7   Bram      Schoolstraat  Eindhoven    7   20         6  2018-08-26
#[Out]# 28     8   Liam     Rijsbergseweg      Breda    8   10         9  2018-08-16
#[Out]# 29     8   Liam     Rijsbergseweg      Breda    8    6         7  2018-08-16
#[Out]# ..   ...    ...               ...        ...  ...  ...       ...         ...
#[Out]# 462  176  Amira       Parallelweg  Amsterdam  176    4         7  2018-08-22
#[Out]# 463  176  Amira       Parallelweg  Amsterdam  176   24         9  2018-08-25
#[Out]# 464  176  Amira       Parallelweg  Amsterdam  176   13         7  2018-08-25
#[Out]# 465  176  Amira       Parallelweg  Amsterdam  176    0         2  2018-08-25
#[Out]# 466  176  Amira       Parallelweg  Amsterdam  176   14         2  2018-08-25
#[Out]# 467  176  Amira       Parallelweg  Amsterdam  176   11         6  2018-08-25
#[Out]# 468  176  Amira       Parallelweg  Amsterdam  176   21         8  2018-08-25
#[Out]# 469  176  Amira       Parallelweg  Amsterdam  176    5         9  2018-08-26
#[Out]# 470  178   Elif       Parallelweg    Utrecht  178   25         9  2018-08-27
#[Out]# 471  178   Elif       Parallelweg    Utrecht  178   24         1  2018-08-27
#[Out]# 472  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24
#[Out]# 473  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24
#[Out]# 474  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24
#[Out]# 475  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22
#[Out]# 476  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22
#[Out]# 477  179   Juul    Wilhelminapark    Tilburg  179   10         7  2018-08-22
#[Out]# 478  180  Merel      Kalverstraat  Amsterdam  180   26         3  2018-08-26
#[Out]# 479  180  Merel      Kalverstraat  Amsterdam  180   13         8  2018-08-26
#[Out]# 480  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27
#[Out]# 481  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24
#[Out]# 482  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24
#[Out]# 483  181   Liva       Fredriklaan  Eindhoven  181   21         5  2018-08-27
#[Out]# 484  181   Liva       Fredriklaan  Eindhoven  181    5         3  2018-08-27
#[Out]# 485  183  Nikki     Julianastraat    Utrecht  183    5         7  2018-08-19
#[Out]# 486  183  Nikki     Julianastraat    Utrecht  183   10         2  2018-08-20
#[Out]# 487  183  Nikki     Julianastraat    Utrecht  183   12         9  2018-08-21
#[Out]# 488  183  Nikki     Julianastraat    Utrecht  183   18         8  2018-08-21
#[Out]# 489  183  Nikki     Julianastraat    Utrecht  183    6         3  2018-08-22
#[Out]# 490  183  Nikki     Julianastraat    Utrecht  183   14         7  2018-08-22
#[Out]# 491  183  Nikki     Julianastraat    Utrecht  183   25         4  2018-08-22
#[Out]# 
#[Out]# [492 rows x 8 columns]
# Tue, 01 Dec 2020 14:41:30
query3_2 = ''' 

SELECT DISTINCT

FROM customer AS C, shoppinglist AS SL

WHERE C.cId = SL.cID


'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 14:41:36
query3_2 = ''' 

SELECT DISTINCT
*

FROM customer AS C, shoppinglist AS SL

WHERE C.cId = SL.cID


'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName            street       city  cID  pID  quantity        date
#[Out]# 0      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20
#[Out]# 1      1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20
#[Out]# 2      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20
#[Out]# 3      1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20
#[Out]# 4      1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20
#[Out]# 5      1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20
#[Out]# 6      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20
#[Out]# 7      1    Sem  Rozemarijnstraat      Breda    1   27         6  2018-08-21
#[Out]# 8      2  Lucas  Oude Leliestraat  Amsterdam    2   20         4  2018-08-16
#[Out]# 9      2  Lucas  Oude Leliestraat  Amsterdam    2    9         7  2018-08-16
#[Out]# 10     2  Lucas  Oude Leliestraat  Amsterdam    2    4         6  2018-08-17
#[Out]# 11     2  Lucas  Oude Leliestraat  Amsterdam    2   13         4  2018-08-17
#[Out]# 12     2  Lucas  Oude Leliestraat  Amsterdam    2   22         1  2018-08-17
#[Out]# 13     3   Finn     Stationsplein      Breda    3   14         2  2018-08-18
#[Out]# 14     3   Finn     Stationsplein      Breda    3   26         2  2018-08-18
#[Out]# 15     3   Finn     Stationsplein      Breda    3    9         6  2018-08-19
#[Out]# 16     5   Levi    Gasthuisstraat    Utrecht    5   14         6  2018-08-17
#[Out]# 17     5   Levi    Gasthuisstraat    Utrecht    5   28         6  2018-08-22
#[Out]# 18     5   Levi    Gasthuisstraat    Utrecht    5    6         9  2018-08-22
#[Out]# 19     5   Levi    Gasthuisstraat    Utrecht    5   22         2  2018-08-23
#[Out]# 20     5   Levi    Gasthuisstraat    Utrecht    5   16         2  2018-08-23
#[Out]# 21     5   Levi    Gasthuisstraat    Utrecht    5   19         1  2018-08-23
#[Out]# 22     7   Bram      Schoolstraat  Eindhoven    7   19         2  2018-08-23
#[Out]# 23     7   Bram      Schoolstraat  Eindhoven    7    2         6  2018-08-23
#[Out]# 24     7   Bram      Schoolstraat  Eindhoven    7   16         4  2018-08-23
#[Out]# 25     7   Bram      Schoolstraat  Eindhoven    7   12         2  2018-08-24
#[Out]# 26     7   Bram      Schoolstraat  Eindhoven    7    6         4  2018-08-25
#[Out]# 27     7   Bram      Schoolstraat  Eindhoven    7   20         6  2018-08-26
#[Out]# 28     8   Liam     Rijsbergseweg      Breda    8   10         9  2018-08-16
#[Out]# 29     8   Liam     Rijsbergseweg      Breda    8    6         7  2018-08-16
#[Out]# ..   ...    ...               ...        ...  ...  ...       ...         ...
#[Out]# 462  176  Amira       Parallelweg  Amsterdam  176    4         7  2018-08-22
#[Out]# 463  176  Amira       Parallelweg  Amsterdam  176   24         9  2018-08-25
#[Out]# 464  176  Amira       Parallelweg  Amsterdam  176   13         7  2018-08-25
#[Out]# 465  176  Amira       Parallelweg  Amsterdam  176    0         2  2018-08-25
#[Out]# 466  176  Amira       Parallelweg  Amsterdam  176   14         2  2018-08-25
#[Out]# 467  176  Amira       Parallelweg  Amsterdam  176   11         6  2018-08-25
#[Out]# 468  176  Amira       Parallelweg  Amsterdam  176   21         8  2018-08-25
#[Out]# 469  176  Amira       Parallelweg  Amsterdam  176    5         9  2018-08-26
#[Out]# 470  178   Elif       Parallelweg    Utrecht  178   25         9  2018-08-27
#[Out]# 471  178   Elif       Parallelweg    Utrecht  178   24         1  2018-08-27
#[Out]# 472  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24
#[Out]# 473  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24
#[Out]# 474  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24
#[Out]# 475  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22
#[Out]# 476  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22
#[Out]# 477  179   Juul    Wilhelminapark    Tilburg  179   10         7  2018-08-22
#[Out]# 478  180  Merel      Kalverstraat  Amsterdam  180   26         3  2018-08-26
#[Out]# 479  180  Merel      Kalverstraat  Amsterdam  180   13         8  2018-08-26
#[Out]# 480  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27
#[Out]# 481  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24
#[Out]# 482  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24
#[Out]# 483  181   Liva       Fredriklaan  Eindhoven  181   21         5  2018-08-27
#[Out]# 484  181   Liva       Fredriklaan  Eindhoven  181    5         3  2018-08-27
#[Out]# 485  183  Nikki     Julianastraat    Utrecht  183    5         7  2018-08-19
#[Out]# 486  183  Nikki     Julianastraat    Utrecht  183   10         2  2018-08-20
#[Out]# 487  183  Nikki     Julianastraat    Utrecht  183   12         9  2018-08-21
#[Out]# 488  183  Nikki     Julianastraat    Utrecht  183   18         8  2018-08-21
#[Out]# 489  183  Nikki     Julianastraat    Utrecht  183    6         3  2018-08-22
#[Out]# 490  183  Nikki     Julianastraat    Utrecht  183   14         7  2018-08-22
#[Out]# 491  183  Nikki     Julianastraat    Utrecht  183   25         4  2018-08-22
#[Out]# 
#[Out]# [492 rows x 8 columns]
# Tue, 01 Dec 2020 14:42:15
query3_2 = ''' 

SELECT DISTINCT
*

FROM customer AS C
INNER JOIN shoppinglist AS SL ON SL.cId = C.cId



'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName            street       city  cID  pID  quantity        date
#[Out]# 0      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20
#[Out]# 1      1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20
#[Out]# 2      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20
#[Out]# 3      1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20
#[Out]# 4      1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20
#[Out]# 5      1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20
#[Out]# 6      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20
#[Out]# 7      1    Sem  Rozemarijnstraat      Breda    1   27         6  2018-08-21
#[Out]# 8      2  Lucas  Oude Leliestraat  Amsterdam    2   20         4  2018-08-16
#[Out]# 9      2  Lucas  Oude Leliestraat  Amsterdam    2    9         7  2018-08-16
#[Out]# 10     2  Lucas  Oude Leliestraat  Amsterdam    2    4         6  2018-08-17
#[Out]# 11     2  Lucas  Oude Leliestraat  Amsterdam    2   13         4  2018-08-17
#[Out]# 12     2  Lucas  Oude Leliestraat  Amsterdam    2   22         1  2018-08-17
#[Out]# 13     3   Finn     Stationsplein      Breda    3   14         2  2018-08-18
#[Out]# 14     3   Finn     Stationsplein      Breda    3   26         2  2018-08-18
#[Out]# 15     3   Finn     Stationsplein      Breda    3    9         6  2018-08-19
#[Out]# 16     5   Levi    Gasthuisstraat    Utrecht    5   14         6  2018-08-17
#[Out]# 17     5   Levi    Gasthuisstraat    Utrecht    5   28         6  2018-08-22
#[Out]# 18     5   Levi    Gasthuisstraat    Utrecht    5    6         9  2018-08-22
#[Out]# 19     5   Levi    Gasthuisstraat    Utrecht    5   22         2  2018-08-23
#[Out]# 20     5   Levi    Gasthuisstraat    Utrecht    5   16         2  2018-08-23
#[Out]# 21     5   Levi    Gasthuisstraat    Utrecht    5   19         1  2018-08-23
#[Out]# 22     7   Bram      Schoolstraat  Eindhoven    7   19         2  2018-08-23
#[Out]# 23     7   Bram      Schoolstraat  Eindhoven    7    2         6  2018-08-23
#[Out]# 24     7   Bram      Schoolstraat  Eindhoven    7   16         4  2018-08-23
#[Out]# 25     7   Bram      Schoolstraat  Eindhoven    7   12         2  2018-08-24
#[Out]# 26     7   Bram      Schoolstraat  Eindhoven    7    6         4  2018-08-25
#[Out]# 27     7   Bram      Schoolstraat  Eindhoven    7   20         6  2018-08-26
#[Out]# 28     8   Liam     Rijsbergseweg      Breda    8   10         9  2018-08-16
#[Out]# 29     8   Liam     Rijsbergseweg      Breda    8    6         7  2018-08-16
#[Out]# ..   ...    ...               ...        ...  ...  ...       ...         ...
#[Out]# 462  176  Amira       Parallelweg  Amsterdam  176    4         7  2018-08-22
#[Out]# 463  176  Amira       Parallelweg  Amsterdam  176   24         9  2018-08-25
#[Out]# 464  176  Amira       Parallelweg  Amsterdam  176   13         7  2018-08-25
#[Out]# 465  176  Amira       Parallelweg  Amsterdam  176    0         2  2018-08-25
#[Out]# 466  176  Amira       Parallelweg  Amsterdam  176   14         2  2018-08-25
#[Out]# 467  176  Amira       Parallelweg  Amsterdam  176   11         6  2018-08-25
#[Out]# 468  176  Amira       Parallelweg  Amsterdam  176   21         8  2018-08-25
#[Out]# 469  176  Amira       Parallelweg  Amsterdam  176    5         9  2018-08-26
#[Out]# 470  178   Elif       Parallelweg    Utrecht  178   25         9  2018-08-27
#[Out]# 471  178   Elif       Parallelweg    Utrecht  178   24         1  2018-08-27
#[Out]# 472  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24
#[Out]# 473  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24
#[Out]# 474  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24
#[Out]# 475  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22
#[Out]# 476  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22
#[Out]# 477  179   Juul    Wilhelminapark    Tilburg  179   10         7  2018-08-22
#[Out]# 478  180  Merel      Kalverstraat  Amsterdam  180   26         3  2018-08-26
#[Out]# 479  180  Merel      Kalverstraat  Amsterdam  180   13         8  2018-08-26
#[Out]# 480  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27
#[Out]# 481  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24
#[Out]# 482  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24
#[Out]# 483  181   Liva       Fredriklaan  Eindhoven  181   21         5  2018-08-27
#[Out]# 484  181   Liva       Fredriklaan  Eindhoven  181    5         3  2018-08-27
#[Out]# 485  183  Nikki     Julianastraat    Utrecht  183    5         7  2018-08-19
#[Out]# 486  183  Nikki     Julianastraat    Utrecht  183   10         2  2018-08-20
#[Out]# 487  183  Nikki     Julianastraat    Utrecht  183   12         9  2018-08-21
#[Out]# 488  183  Nikki     Julianastraat    Utrecht  183   18         8  2018-08-21
#[Out]# 489  183  Nikki     Julianastraat    Utrecht  183    6         3  2018-08-22
#[Out]# 490  183  Nikki     Julianastraat    Utrecht  183   14         7  2018-08-22
#[Out]# 491  183  Nikki     Julianastraat    Utrecht  183   25         4  2018-08-22
#[Out]# 
#[Out]# [492 rows x 8 columns]
# Tue, 01 Dec 2020 14:42:36
query3_2 = ''' 

SELECT DISTINCT
*

FROM customer AS C
INNER JOIN shoppinglist AS SL ON SL.cId = C.cId

WHERE SL.Date like '%2018%'



'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName            street       city  cID  pID  quantity        date
#[Out]# 0      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20
#[Out]# 1      1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20
#[Out]# 2      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20
#[Out]# 3      1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20
#[Out]# 4      1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20
#[Out]# 5      1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20
#[Out]# 6      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20
#[Out]# 7      1    Sem  Rozemarijnstraat      Breda    1   27         6  2018-08-21
#[Out]# 8      2  Lucas  Oude Leliestraat  Amsterdam    2   20         4  2018-08-16
#[Out]# 9      2  Lucas  Oude Leliestraat  Amsterdam    2    9         7  2018-08-16
#[Out]# 10     2  Lucas  Oude Leliestraat  Amsterdam    2    4         6  2018-08-17
#[Out]# 11     2  Lucas  Oude Leliestraat  Amsterdam    2   13         4  2018-08-17
#[Out]# 12     2  Lucas  Oude Leliestraat  Amsterdam    2   22         1  2018-08-17
#[Out]# 13     3   Finn     Stationsplein      Breda    3   14         2  2018-08-18
#[Out]# 14     3   Finn     Stationsplein      Breda    3   26         2  2018-08-18
#[Out]# 15     3   Finn     Stationsplein      Breda    3    9         6  2018-08-19
#[Out]# 16     5   Levi    Gasthuisstraat    Utrecht    5   14         6  2018-08-17
#[Out]# 17     5   Levi    Gasthuisstraat    Utrecht    5   28         6  2018-08-22
#[Out]# 18     5   Levi    Gasthuisstraat    Utrecht    5    6         9  2018-08-22
#[Out]# 19     5   Levi    Gasthuisstraat    Utrecht    5   22         2  2018-08-23
#[Out]# 20     5   Levi    Gasthuisstraat    Utrecht    5   16         2  2018-08-23
#[Out]# 21     5   Levi    Gasthuisstraat    Utrecht    5   19         1  2018-08-23
#[Out]# 22     7   Bram      Schoolstraat  Eindhoven    7   19         2  2018-08-23
#[Out]# 23     7   Bram      Schoolstraat  Eindhoven    7    2         6  2018-08-23
#[Out]# 24     7   Bram      Schoolstraat  Eindhoven    7   16         4  2018-08-23
#[Out]# 25     7   Bram      Schoolstraat  Eindhoven    7   12         2  2018-08-24
#[Out]# 26     7   Bram      Schoolstraat  Eindhoven    7    6         4  2018-08-25
#[Out]# 27     7   Bram      Schoolstraat  Eindhoven    7   20         6  2018-08-26
#[Out]# 28     8   Liam     Rijsbergseweg      Breda    8   10         9  2018-08-16
#[Out]# 29     8   Liam     Rijsbergseweg      Breda    8    6         7  2018-08-16
#[Out]# ..   ...    ...               ...        ...  ...  ...       ...         ...
#[Out]# 462  176  Amira       Parallelweg  Amsterdam  176    4         7  2018-08-22
#[Out]# 463  176  Amira       Parallelweg  Amsterdam  176   24         9  2018-08-25
#[Out]# 464  176  Amira       Parallelweg  Amsterdam  176   13         7  2018-08-25
#[Out]# 465  176  Amira       Parallelweg  Amsterdam  176    0         2  2018-08-25
#[Out]# 466  176  Amira       Parallelweg  Amsterdam  176   14         2  2018-08-25
#[Out]# 467  176  Amira       Parallelweg  Amsterdam  176   11         6  2018-08-25
#[Out]# 468  176  Amira       Parallelweg  Amsterdam  176   21         8  2018-08-25
#[Out]# 469  176  Amira       Parallelweg  Amsterdam  176    5         9  2018-08-26
#[Out]# 470  178   Elif       Parallelweg    Utrecht  178   25         9  2018-08-27
#[Out]# 471  178   Elif       Parallelweg    Utrecht  178   24         1  2018-08-27
#[Out]# 472  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24
#[Out]# 473  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24
#[Out]# 474  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24
#[Out]# 475  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22
#[Out]# 476  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22
#[Out]# 477  179   Juul    Wilhelminapark    Tilburg  179   10         7  2018-08-22
#[Out]# 478  180  Merel      Kalverstraat  Amsterdam  180   26         3  2018-08-26
#[Out]# 479  180  Merel      Kalverstraat  Amsterdam  180   13         8  2018-08-26
#[Out]# 480  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27
#[Out]# 481  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24
#[Out]# 482  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24
#[Out]# 483  181   Liva       Fredriklaan  Eindhoven  181   21         5  2018-08-27
#[Out]# 484  181   Liva       Fredriklaan  Eindhoven  181    5         3  2018-08-27
#[Out]# 485  183  Nikki     Julianastraat    Utrecht  183    5         7  2018-08-19
#[Out]# 486  183  Nikki     Julianastraat    Utrecht  183   10         2  2018-08-20
#[Out]# 487  183  Nikki     Julianastraat    Utrecht  183   12         9  2018-08-21
#[Out]# 488  183  Nikki     Julianastraat    Utrecht  183   18         8  2018-08-21
#[Out]# 489  183  Nikki     Julianastraat    Utrecht  183    6         3  2018-08-22
#[Out]# 490  183  Nikki     Julianastraat    Utrecht  183   14         7  2018-08-22
#[Out]# 491  183  Nikki     Julianastraat    Utrecht  183   25         4  2018-08-22
#[Out]# 
#[Out]# [492 rows x 8 columns]
# Tue, 01 Dec 2020 14:42:58
query3_2 = ''' 

SELECT DISTINCT
*

FROM customer AS C
INNER JOIN shoppinglist AS SL ON SL.cId = C.cId
INNER JOIN purchase AS P ON P.cID = C.cId

WHERE SL.Date like '%2018%'



'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID  cName            street       city  cID  pID  quantity        date  \
#[Out]# 0       1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 1       1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 2       1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 3       1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 4       1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 5       1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 6       1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 7       1    Sem  Rozemarijnstraat      Breda    1   27         6  2018-08-21   
#[Out]# 8       1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 9       1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 10      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 11      1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 12      1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 13      1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 14      1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 15      1    Sem  Rozemarijnstraat      Breda    1   27         6  2018-08-21   
#[Out]# 16      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 17      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 18      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 19      1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 20      1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 21      1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 22      1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 23      1    Sem  Rozemarijnstraat      Breda    1   27         6  2018-08-21   
#[Out]# 24      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 25      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 26      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 27      1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 28      1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 29      1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# ...   ...    ...               ...        ...  ...  ...       ...         ...   
#[Out]# 2297  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22   
#[Out]# 2298  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24   
#[Out]# 2299  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22   
#[Out]# 2300  179   Juul    Wilhelminapark    Tilburg  179   10         7  2018-08-22   
#[Out]# 2301  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24   
#[Out]# 2302  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24   
#[Out]# 2303  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22   
#[Out]# 2304  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24   
#[Out]# 2305  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22   
#[Out]# 2306  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27   
#[Out]# 2307  180  Merel      Kalverstraat  Amsterdam  180   13         8  2018-08-26   
#[Out]# 2308  180  Merel      Kalverstraat  Amsterdam  180   26         3  2018-08-26   
#[Out]# 2309  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27   
#[Out]# 2310  180  Merel      Kalverstraat  Amsterdam  180   13         8  2018-08-26   
#[Out]# 2311  180  Merel      Kalverstraat  Amsterdam  180   26         3  2018-08-26   
#[Out]# 2312  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27   
#[Out]# 2313  180  Merel      Kalverstraat  Amsterdam  180   13         8  2018-08-26   
#[Out]# 2314  180  Merel      Kalverstraat  Amsterdam  180   26         3  2018-08-26   
#[Out]# 2315  181   Liva       Fredriklaan  Eindhoven  181    5         3  2018-08-27   
#[Out]# 2316  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24   
#[Out]# 2317  181   Liva       Fredriklaan  Eindhoven  181   21         5  2018-08-27   
#[Out]# 2318  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24   
#[Out]# 2319  181   Liva       Fredriklaan  Eindhoven  181    5         3  2018-08-27   
#[Out]# 2320  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24   
#[Out]# 2321  181   Liva       Fredriklaan  Eindhoven  181   21         5  2018-08-27   
#[Out]# 2322  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24   
#[Out]# 2323  181   Liva       Fredriklaan  Eindhoven  181    5         3  2018-08-27   
#[Out]# 2324  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24   
#[Out]# 2325  181   Liva       Fredriklaan  Eindhoven  181   21         5  2018-08-27   
#[Out]# 2326  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24   
#[Out]# 
#[Out]#       tID  cID  sID  pID        date  quantity  price  
#[Out]# 0       1    1   23   14  2018-08-20         2   4.65  
#[Out]# 1       1    1   23   14  2018-08-20         2   4.65  
#[Out]# 2       1    1   23   14  2018-08-20         2   4.65  
#[Out]# 3       1    1   23   14  2018-08-20         2   4.65  
#[Out]# 4       1    1   23   14  2018-08-20         2   4.65  
#[Out]# 5       1    1   23   14  2018-08-20         2   4.65  
#[Out]# 6       1    1   23   14  2018-08-20         2   4.65  
#[Out]# 7       1    1   23   14  2018-08-20         2   4.65  
#[Out]# 8       2    1    3   16  2018-08-20         3   1.60  
#[Out]# 9       2    1    3   16  2018-08-20         3   1.60  
#[Out]# 10      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 11      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 12      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 13      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 14      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 15      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 16      3    1   17    9  2018-08-20         2   1.25  
#[Out]# 17      3    1   17    9  2018-08-20         2   1.25  
#[Out]# 18      3    1   17    9  2018-08-20         2   1.25  
#[Out]# 19      3    1   17    9  2018-08-20         2   1.25  
#[Out]# 20      3    1   17    9  2018-08-20         2   1.25  
#[Out]# 21      3    1   17    9  2018-08-20         2   1.25  
#[Out]# 22      3    1   17    9  2018-08-20         2   1.25  
#[Out]# 23      3    1   17    9  2018-08-20         2   1.25  
#[Out]# 24      4    1   32   25  2018-08-20         4   3.95  
#[Out]# 25      4    1   32   25  2018-08-20         4   3.95  
#[Out]# 26      4    1   32   25  2018-08-20         4   3.95  
#[Out]# 27      4    1   32   25  2018-08-20         4   3.95  
#[Out]# 28      4    1   32   25  2018-08-20         4   3.95  
#[Out]# 29      4    1   32   25  2018-08-20         4   3.95  
#[Out]# ...   ...  ...  ...  ...         ...       ...    ...  
#[Out]# 2297  464  179   35   16  2018-08-22         9   1.85  
#[Out]# 2298  464  179   35   16  2018-08-22         9   1.85  
#[Out]# 2299  464  179   35   16  2018-08-22         9   1.85  
#[Out]# 2300  465  179   45   10  2018-08-23         7   0.45  
#[Out]# 2301  465  179   45   10  2018-08-23         7   0.45  
#[Out]# 2302  465  179   45   10  2018-08-23         7   0.45  
#[Out]# 2303  465  179   45   10  2018-08-23         7   0.45  
#[Out]# 2304  465  179   45   10  2018-08-23         7   0.45  
#[Out]# 2305  465  179   45   10  2018-08-23         7   0.45  
#[Out]# 2306  466  180   34   26  2018-08-26         3   3.10  
#[Out]# 2307  466  180   34   26  2018-08-26         3   3.10  
#[Out]# 2308  466  180   34   26  2018-08-26         3   3.10  
#[Out]# 2309  467  180   34   13  2018-08-27         8   4.05  
#[Out]# 2310  467  180   34   13  2018-08-27         8   4.05  
#[Out]# 2311  467  180   34   13  2018-08-27         8   4.05  
#[Out]# 2312  468  180   56   10  2018-08-27         3   0.60  
#[Out]# 2313  468  180   56   10  2018-08-27         3   0.60  
#[Out]# 2314  468  180   56   10  2018-08-27         3   0.60  
#[Out]# 2315  469  181    6   26  2018-08-24         4   2.70  
#[Out]# 2316  469  181    6   26  2018-08-24         4   2.70  
#[Out]# 2317  469  181    6   26  2018-08-24         4   2.70  
#[Out]# 2318  469  181    6   26  2018-08-24         4   2.70  
#[Out]# 2319  470  181   45    6  2018-08-24         3   0.90  
#[Out]# 2320  470  181   45    6  2018-08-24         3   0.90  
#[Out]# 2321  470  181   45    6  2018-08-24         3   0.90  
#[Out]# 2322  470  181   45    6  2018-08-24         3   0.90  
#[Out]# 2323  471  181   27   21  2018-08-27         5   2.00  
#[Out]# 2324  471  181   27   21  2018-08-27         5   2.00  
#[Out]# 2325  471  181   27   21  2018-08-27         5   2.00  
#[Out]# 2326  471  181   27   21  2018-08-27         5   2.00  
#[Out]# 
#[Out]# [2327 rows x 15 columns]
# Tue, 01 Dec 2020 14:43:18
query3_2 = ''' 

SELECT DISTINCT
*

FROM customer AS C
INNER JOIN shoppinglist AS SL ON SL.cId = C.cId
INNER JOIN purchase AS P ON P.cID = C.cId AND P.Date = SL.Date

WHERE SL.Date like '%2018%'



'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName            street       city  cID  pID  quantity        date  \
#[Out]# 0      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 1      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 2      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 3      1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 4      1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 5      1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 6      1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 7      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 8      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 9      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 10     1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 11     1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 12     1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 13     1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 14     1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 15     1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 16     1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 17     1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 18     1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 19     1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 20     1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 21     1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 22     1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 23     1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 24     1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 25     1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 26     1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 27     1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 28     1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 29     1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# ..   ...    ...               ...        ...  ...  ...       ...         ...   
#[Out]# 946  176  Amira       Parallelweg  Amsterdam  176    5         9  2018-08-26   
#[Out]# 947  178   Elif       Parallelweg    Utrecht  178   24         1  2018-08-27   
#[Out]# 948  178   Elif       Parallelweg    Utrecht  178   25         9  2018-08-27   
#[Out]# 949  178   Elif       Parallelweg    Utrecht  178   24         1  2018-08-27   
#[Out]# 950  178   Elif       Parallelweg    Utrecht  178   25         9  2018-08-27   
#[Out]# 951  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24   
#[Out]# 952  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24   
#[Out]# 953  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24   
#[Out]# 954  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24   
#[Out]# 955  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24   
#[Out]# 956  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24   
#[Out]# 957  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24   
#[Out]# 958  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24   
#[Out]# 959  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24   
#[Out]# 960  179   Juul    Wilhelminapark    Tilburg  179   10         7  2018-08-22   
#[Out]# 961  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22   
#[Out]# 962  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22   
#[Out]# 963  179   Juul    Wilhelminapark    Tilburg  179   10         7  2018-08-22   
#[Out]# 964  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22   
#[Out]# 965  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22   
#[Out]# 966  180  Merel      Kalverstraat  Amsterdam  180   13         8  2018-08-26   
#[Out]# 967  180  Merel      Kalverstraat  Amsterdam  180   26         3  2018-08-26   
#[Out]# 968  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27   
#[Out]# 969  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27   
#[Out]# 970  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24   
#[Out]# 971  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24   
#[Out]# 972  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24   
#[Out]# 973  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24   
#[Out]# 974  181   Liva       Fredriklaan  Eindhoven  181    5         3  2018-08-27   
#[Out]# 975  181   Liva       Fredriklaan  Eindhoven  181   21         5  2018-08-27   
#[Out]# 
#[Out]#      tID  cID  sID  pID        date  quantity  price  
#[Out]# 0      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 2      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 3      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 4      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 5      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 6      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 7      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 8      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 9      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 10     2    1    3   16  2018-08-20         3   1.60  
#[Out]# 11     2    1    3   16  2018-08-20         3   1.60  
#[Out]# 12     2    1    3   16  2018-08-20         3   1.60  
#[Out]# 13     2    1    3   16  2018-08-20         3   1.60  
#[Out]# 14     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 15     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 16     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 17     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 18     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 19     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 20     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 21     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 22     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 23     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 24     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 25     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 26     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 27     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 28     5    1   16   26  2018-08-20         4   2.75  
#[Out]# 29     5    1   16   26  2018-08-20         4   2.75  
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  
#[Out]# 946  452  176    6    5  2018-08-26         9   0.50  
#[Out]# 947  458  178   34   25  2018-08-27         9   3.60  
#[Out]# 948  458  178   34   25  2018-08-27         9   3.60  
#[Out]# 949  459  178   39   24  2018-08-27         1   3.90  
#[Out]# 950  459  178   39   24  2018-08-27         1   3.90  
#[Out]# 951  460  179   25   14  2018-08-24         5   3.70  
#[Out]# 952  460  179   25   14  2018-08-24         5   3.70  
#[Out]# 953  460  179   25   14  2018-08-24         5   3.70  
#[Out]# 954  461  179   24   11  2018-08-24         3   0.85  
#[Out]# 955  461  179   24   11  2018-08-24         3   0.85  
#[Out]# 956  461  179   24   11  2018-08-24         3   0.85  
#[Out]# 957  462  179   57   17  2018-08-24         2   2.40  
#[Out]# 958  462  179   57   17  2018-08-24         2   2.40  
#[Out]# 959  462  179   57   17  2018-08-24         2   2.40  
#[Out]# 960  463  179   43   27  2018-08-22         8   9.00  
#[Out]# 961  463  179   43   27  2018-08-22         8   9.00  
#[Out]# 962  463  179   43   27  2018-08-22         8   9.00  
#[Out]# 963  464  179   35   16  2018-08-22         9   1.85  
#[Out]# 964  464  179   35   16  2018-08-22         9   1.85  
#[Out]# 965  464  179   35   16  2018-08-22         9   1.85  
#[Out]# 966  466  180   34   26  2018-08-26         3   3.10  
#[Out]# 967  466  180   34   26  2018-08-26         3   3.10  
#[Out]# 968  467  180   34   13  2018-08-27         8   4.05  
#[Out]# 969  468  180   56   10  2018-08-27         3   0.60  
#[Out]# 970  469  181    6   26  2018-08-24         4   2.70  
#[Out]# 971  469  181    6   26  2018-08-24         4   2.70  
#[Out]# 972  470  181   45    6  2018-08-24         3   0.90  
#[Out]# 973  470  181   45    6  2018-08-24         3   0.90  
#[Out]# 974  471  181   27   21  2018-08-27         5   2.00  
#[Out]# 975  471  181   27   21  2018-08-27         5   2.00  
#[Out]# 
#[Out]# [976 rows x 15 columns]
# Tue, 01 Dec 2020 14:43:39
query3_2 = ''' 

SELECT DISTINCT
C.cID
,c.cName

FROM customer AS C
INNER JOIN shoppinglist AS SL ON SL.cId = C.cId
INNER JOIN purchase AS P ON P.cID = C.cId AND P.Date = SL.Date

WHERE SL.Date like '%2018%'



'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 14:44:47
query3_2 = ''' 

SELECT DISTINCT
*

FROM customer AS C, shoppinglist AS SL, purchase as P

WHERE
SL.Date like '%2018%'
AND c.cId = Sl.cId



'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cID  cName            street     city  cID  pID  quantity        date  \
#[Out]# 0         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 1         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 2         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 3         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 4         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 5         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 6         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 7         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 8         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 9         1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 10        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 11        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 12        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 13        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 14        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 15        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 16        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 17        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 18        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 19        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 20        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 21        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 22        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 23        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 24        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 25        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 26        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 27        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 28        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# 29        1    Sem  Rozemarijnstraat    Breda    1    9         2  2018-08-20   
#[Out]# ...     ...    ...               ...      ...  ...  ...       ...         ...   
#[Out]# 250398  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250399  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250400  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250401  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250402  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250403  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250404  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250405  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250406  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250407  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250408  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250409  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250410  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250411  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250412  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250413  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250414  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250415  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250416  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250417  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250418  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250419  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250420  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250421  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250422  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250423  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250424  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250425  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250426  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 250427  183  Nikki     Julianastraat  Utrecht  183   25         4  2018-08-22   
#[Out]# 
#[Out]#         tID  cID  sID  pID        date  quantity  price  
#[Out]# 0         0    0    3   10  2018-08-22         1   0.45  
#[Out]# 1         1    1   23   14  2018-08-20         2   4.65  
#[Out]# 2         2    1    3   16  2018-08-20         3   1.60  
#[Out]# 3         3    1   17    9  2018-08-20         2   1.25  
#[Out]# 4         4    1   32   25  2018-08-20         4   3.95  
#[Out]# 5         5    1   16   26  2018-08-20         4   2.75  
#[Out]# 6         6    1   46   11  2018-08-21         8   0.90  
#[Out]# 7         7    1   36   27  2018-08-21         6   9.10  
#[Out]# 8         8    2   12   20  2018-08-16         1   2.45  
#[Out]# 9         9    2   39    9  2018-08-17         7   1.35  
#[Out]# 10       10    2   13    4  2018-08-17         6   1.10  
#[Out]# 11       11    2   51   13  2018-08-17         4   3.70  
#[Out]# 12       12    2   47   22  2018-08-17         1   1.55  
#[Out]# 13       13    3   44   14  2018-08-18         2   4.30  
#[Out]# 14       14    3   30   26  2018-08-19         2   2.75  
#[Out]# 15       15    3   29    9  2018-08-19         6   1.45  
#[Out]# 16       16    4   17    8  2018-08-24         2   4.15  
#[Out]# 17       17    4   10   27  2018-08-24         9   9.05  
#[Out]# 18       18    4   53   12  2018-08-25         5  13.60  
#[Out]# 19       19    4   21    6  2018-08-24         2   1.05  
#[Out]# 20       20    4    7   13  2018-08-25         9   3.05  
#[Out]# 21       21    4   44   26  2018-08-25         4   2.75  
#[Out]# 22       22    5    4   14  2018-08-17         6   4.70  
#[Out]# 23       23    5   36   28  2018-08-22         6   8.25  
#[Out]# 24       24    5   55    6  2018-08-23         9   1.10  
#[Out]# 25       25    5   51   22  2018-08-23         2   1.55  
#[Out]# 26       26    5    6   16  2018-08-23         2   1.85  
#[Out]# 27       27    5   17   19  2018-08-23         1   2.20  
#[Out]# 28       28    7    3   19  2018-08-23         2   2.10  
#[Out]# 29       29    7   12    2  2018-08-23         6   1.70  
#[Out]# ...     ...  ...  ...  ...         ...       ...    ...  
#[Out]# 250398  818  190   34   28  2018-08-20         4   2.80  
#[Out]# 250399  819  190   35   27  2018-08-15         5   0.50  
#[Out]# 250400  820  190   36    5  2018-08-23         3   2.55  
#[Out]# 250401  821  190   37   28  2018-08-15         4   0.65  
#[Out]# 250402  822  190   38    7  2018-08-24         4   0.70  
#[Out]# 250403  823  190   39    0  2018-08-25         4   3.70  
#[Out]# 250404  824  190   40   11  2018-08-15         2   3.50  
#[Out]# 250405  825  190   41    6  2018-08-15         5   2.95  
#[Out]# 250406  826  190   42   19  2018-08-22         5   2.75  
#[Out]# 250407  827  190   43   17  2018-08-17         7   1.50  
#[Out]# 250408  828  190   44    9  2018-08-18         5   0.85  
#[Out]# 250409  829  190   45   11  2018-08-19         2   3.55  
#[Out]# 250410  830  190   46   22  2018-08-25         4   2.60  
#[Out]# 250411  831  190   47   17  2018-08-17         4   3.25  
#[Out]# 250412  832  190   48   20  2018-08-26         6   4.30  
#[Out]# 250413  833  190   49   11  2018-08-17         3   3.05  
#[Out]# 250414  834  190   50   21  2018-08-22         6   4.05  
#[Out]# 250415  835  190   51   23  2018-08-19         1   1.50  
#[Out]# 250416  836  190   52   23  2018-08-15         5   2.50  
#[Out]# 250417  837  190   53    8  2018-08-18         4   3.95  
#[Out]# 250418  838  190   54    0  2018-08-25         6   3.50  
#[Out]# 250419  839  190   55    8  2018-08-18         7   2.95  
#[Out]# 250420  840  190   56   11  2018-08-15         4   1.60  
#[Out]# 250421  841  190   57   15  2018-08-22         5   3.25  
#[Out]# 250422  842  190   58    2  2018-08-19         7   0.75  
#[Out]# 250423  843  190   59   17  2018-08-26         2   3.80  
#[Out]# 250424  844  190   60    5  2018-08-27         6   4.35  
#[Out]# 250425  845  190   61   19  2018-08-23         5   2.85  
#[Out]# 250426  846  190   62    9  2018-08-16         2   3.15  
#[Out]# 250427  847  190   63   18  2018-08-21         1   3.30  
#[Out]# 
#[Out]# [250428 rows x 15 columns]
# Tue, 01 Dec 2020 14:45:12
query3_2 = ''' 

SELECT DISTINCT
*

FROM customer AS C, shoppinglist AS SL, purchase as P

WHERE
SL.Date like '%2018%'
AND c.cId = Sl.cId 
AND c.cId = P.cId
AND P.Date = SL.Date



'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName            street       city  cID  pID  quantity        date  \
#[Out]# 0      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 1      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 2      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 3      1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 4      1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 5      1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 6      1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 7      1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 8      1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 9      1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 10     1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 11     1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 12     1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 13     1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 14     1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 15     1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 16     1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 17     1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 18     1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 19     1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 20     1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 21     1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 22     1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# 23     1    Sem  Rozemarijnstraat      Breda    1   14         2  2018-08-20   
#[Out]# 24     1    Sem  Rozemarijnstraat      Breda    1   16         3  2018-08-20   
#[Out]# 25     1    Sem  Rozemarijnstraat      Breda    1   21         6  2018-08-20   
#[Out]# 26     1    Sem  Rozemarijnstraat      Breda    1   25         4  2018-08-20   
#[Out]# 27     1    Sem  Rozemarijnstraat      Breda    1   26         4  2018-08-20   
#[Out]# 28     1    Sem  Rozemarijnstraat      Breda    1    9         2  2018-08-20   
#[Out]# 29     1    Sem  Rozemarijnstraat      Breda    1   11         8  2018-08-20   
#[Out]# ..   ...    ...               ...        ...  ...  ...       ...         ...   
#[Out]# 946  176  Amira       Parallelweg  Amsterdam  176    5         9  2018-08-26   
#[Out]# 947  178   Elif       Parallelweg    Utrecht  178   24         1  2018-08-27   
#[Out]# 948  178   Elif       Parallelweg    Utrecht  178   25         9  2018-08-27   
#[Out]# 949  178   Elif       Parallelweg    Utrecht  178   24         1  2018-08-27   
#[Out]# 950  178   Elif       Parallelweg    Utrecht  178   25         9  2018-08-27   
#[Out]# 951  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24   
#[Out]# 952  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24   
#[Out]# 953  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24   
#[Out]# 954  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24   
#[Out]# 955  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24   
#[Out]# 956  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24   
#[Out]# 957  179   Juul    Wilhelminapark    Tilburg  179   11         3  2018-08-24   
#[Out]# 958  179   Juul    Wilhelminapark    Tilburg  179   14         5  2018-08-24   
#[Out]# 959  179   Juul    Wilhelminapark    Tilburg  179   17         2  2018-08-24   
#[Out]# 960  179   Juul    Wilhelminapark    Tilburg  179   10         7  2018-08-22   
#[Out]# 961  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22   
#[Out]# 962  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22   
#[Out]# 963  179   Juul    Wilhelminapark    Tilburg  179   10         7  2018-08-22   
#[Out]# 964  179   Juul    Wilhelminapark    Tilburg  179   16         9  2018-08-22   
#[Out]# 965  179   Juul    Wilhelminapark    Tilburg  179   27         8  2018-08-22   
#[Out]# 966  180  Merel      Kalverstraat  Amsterdam  180   13         8  2018-08-26   
#[Out]# 967  180  Merel      Kalverstraat  Amsterdam  180   26         3  2018-08-26   
#[Out]# 968  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27   
#[Out]# 969  180  Merel      Kalverstraat  Amsterdam  180   10         3  2018-08-27   
#[Out]# 970  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24   
#[Out]# 971  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24   
#[Out]# 972  181   Liva       Fredriklaan  Eindhoven  181    6         3  2018-08-24   
#[Out]# 973  181   Liva       Fredriklaan  Eindhoven  181   26         4  2018-08-24   
#[Out]# 974  181   Liva       Fredriklaan  Eindhoven  181    5         3  2018-08-27   
#[Out]# 975  181   Liva       Fredriklaan  Eindhoven  181   21         5  2018-08-27   
#[Out]# 
#[Out]#      tID  cID  sID  pID        date  quantity  price  
#[Out]# 0      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 2      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 3      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 4      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 5      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 6      1    1   23   14  2018-08-20         2   4.65  
#[Out]# 7      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 8      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 9      2    1    3   16  2018-08-20         3   1.60  
#[Out]# 10     2    1    3   16  2018-08-20         3   1.60  
#[Out]# 11     2    1    3   16  2018-08-20         3   1.60  
#[Out]# 12     2    1    3   16  2018-08-20         3   1.60  
#[Out]# 13     2    1    3   16  2018-08-20         3   1.60  
#[Out]# 14     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 15     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 16     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 17     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 18     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 19     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 20     3    1   17    9  2018-08-20         2   1.25  
#[Out]# 21     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 22     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 23     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 24     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 25     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 26     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 27     4    1   32   25  2018-08-20         4   3.95  
#[Out]# 28     5    1   16   26  2018-08-20         4   2.75  
#[Out]# 29     5    1   16   26  2018-08-20         4   2.75  
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  
#[Out]# 946  452  176    6    5  2018-08-26         9   0.50  
#[Out]# 947  458  178   34   25  2018-08-27         9   3.60  
#[Out]# 948  458  178   34   25  2018-08-27         9   3.60  
#[Out]# 949  459  178   39   24  2018-08-27         1   3.90  
#[Out]# 950  459  178   39   24  2018-08-27         1   3.90  
#[Out]# 951  460  179   25   14  2018-08-24         5   3.70  
#[Out]# 952  460  179   25   14  2018-08-24         5   3.70  
#[Out]# 953  460  179   25   14  2018-08-24         5   3.70  
#[Out]# 954  461  179   24   11  2018-08-24         3   0.85  
#[Out]# 955  461  179   24   11  2018-08-24         3   0.85  
#[Out]# 956  461  179   24   11  2018-08-24         3   0.85  
#[Out]# 957  462  179   57   17  2018-08-24         2   2.40  
#[Out]# 958  462  179   57   17  2018-08-24         2   2.40  
#[Out]# 959  462  179   57   17  2018-08-24         2   2.40  
#[Out]# 960  463  179   43   27  2018-08-22         8   9.00  
#[Out]# 961  463  179   43   27  2018-08-22         8   9.00  
#[Out]# 962  463  179   43   27  2018-08-22         8   9.00  
#[Out]# 963  464  179   35   16  2018-08-22         9   1.85  
#[Out]# 964  464  179   35   16  2018-08-22         9   1.85  
#[Out]# 965  464  179   35   16  2018-08-22         9   1.85  
#[Out]# 966  466  180   34   26  2018-08-26         3   3.10  
#[Out]# 967  466  180   34   26  2018-08-26         3   3.10  
#[Out]# 968  467  180   34   13  2018-08-27         8   4.05  
#[Out]# 969  468  180   56   10  2018-08-27         3   0.60  
#[Out]# 970  469  181    6   26  2018-08-24         4   2.70  
#[Out]# 971  469  181    6   26  2018-08-24         4   2.70  
#[Out]# 972  470  181   45    6  2018-08-24         3   0.90  
#[Out]# 973  470  181   45    6  2018-08-24         3   0.90  
#[Out]# 974  471  181   27   21  2018-08-27         5   2.00  
#[Out]# 975  471  181   27   21  2018-08-27         5   2.00  
#[Out]# 
#[Out]# [976 rows x 15 columns]
# Tue, 01 Dec 2020 14:45:27
query3_2 = ''' 

SELECT DISTINCT
C.cID
,c.cName

FROM customer AS C, shoppinglist AS SL, purchase as P

WHERE
SL.Date like '%2018%'
AND c.cId = Sl.cId 
AND c.cId = P.cId
AND P.Date = SL.Date



'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 14:45:36
query3_2 = ''' 

SELECT DISTINCT
C.cID
,c.cName

FROM customer AS C
INNER JOIN shoppinglist AS SL ON SL.cId = C.cId
INNER JOIN purchase AS P ON P.cID = C.cId AND P.Date = SL.Date

WHERE SL.Date like '%2018%'



'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 14:46:06
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName
,s.sName

FROM Customer AS C
 


'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 14:46:11
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName


FROM Customer AS C
 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 14:46:47
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName


FROM Customer AS C, Purchase AS P


WHERE c.cId = P.cID
 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      7      Bram
#[Out]# 7      8      Liam
#[Out]# 8     10       Sam
#[Out]# 9     11     Thijs
#[Out]# 10    13     James
#[Out]# 11    15      Noud
#[Out]# 12    16    Julian
#[Out]# 13    17       Dex
#[Out]# 14    18      Hugo
#[Out]# 15    19      Lars
#[Out]# 16    20      Gijs
#[Out]# 17    21  Benjamin
#[Out]# 18    22      Mats
#[Out]# 19    24      Luca
#[Out]# 20    25     Mason
#[Out]# 21    26    Jayden
#[Out]# 22    27       Tim
#[Out]# 23    28      Siem
#[Out]# 24    29     Ruben
#[Out]# 25    30      Teun
#[Out]# 26    31   Olivier
#[Out]# 27    33      Sven
#[Out]# 28    34     David
#[Out]# 29    35     Stijn
#[Out]# ..   ...       ...
#[Out]# 102  147    Isabel
#[Out]# 103  149     Lizzy
#[Out]# 104  151      Jill
#[Out]# 105  152      Anne
#[Out]# 106  157      Puck
#[Out]# 107  159     Fenne
#[Out]# 108  161     Floor
#[Out]# 109  162     Elena
#[Out]# 110  163      Cato
#[Out]# 111  165     Hanna
#[Out]# 112  167    Veerle
#[Out]# 113  168      Kiki
#[Out]# 114  169      Lily
#[Out]# 115  170      Iris
#[Out]# 116  171     Tessa
#[Out]# 117  172      Lana
#[Out]# 118  175       Sam
#[Out]# 119  176     Amira
#[Out]# 120  177     Eline
#[Out]# 121  178      Elif
#[Out]# 122  179      Juul
#[Out]# 123  180     Merel
#[Out]# 124  181      Liva
#[Out]# 125  182   Johanna
#[Out]# 126  184     Wilko
#[Out]# 127  185      Nick
#[Out]# 128  186    Angela
#[Out]# 129  188      Pino
#[Out]# 130  189      Koen
#[Out]# 131  190    Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 14:47:05
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId


FROM Customer AS C, Purchase AS P


WHERE c.cId = P.cID
 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID
#[Out]# 0      0    Noah    3
#[Out]# 1      1     Sem   23
#[Out]# 2      1     Sem    3
#[Out]# 3      1     Sem   17
#[Out]# 4      1     Sem   32
#[Out]# 5      1     Sem   16
#[Out]# 6      1     Sem   46
#[Out]# 7      1     Sem   36
#[Out]# 8      2   Lucas   12
#[Out]# 9      2   Lucas   39
#[Out]# 10     2   Lucas   13
#[Out]# 11     2   Lucas   51
#[Out]# 12     2   Lucas   47
#[Out]# 13     3    Finn   44
#[Out]# 14     3    Finn   30
#[Out]# 15     3    Finn   29
#[Out]# 16     4    Daan   17
#[Out]# 17     4    Daan   10
#[Out]# 18     4    Daan   53
#[Out]# 19     4    Daan   21
#[Out]# 20     4    Daan    7
#[Out]# 21     4    Daan   44
#[Out]# 22     5    Levi    4
#[Out]# 23     5    Levi   36
#[Out]# 24     5    Levi   55
#[Out]# 25     5    Levi   51
#[Out]# 26     5    Levi    6
#[Out]# 27     5    Levi   17
#[Out]# 28     7    Bram    3
#[Out]# 29     7    Bram   12
#[Out]# ..   ...     ...  ...
#[Out]# 479  190  Kostas   34
#[Out]# 480  190  Kostas   35
#[Out]# 481  190  Kostas   36
#[Out]# 482  190  Kostas   37
#[Out]# 483  190  Kostas   38
#[Out]# 484  190  Kostas   39
#[Out]# 485  190  Kostas   40
#[Out]# 486  190  Kostas   41
#[Out]# 487  190  Kostas   42
#[Out]# 488  190  Kostas   43
#[Out]# 489  190  Kostas   44
#[Out]# 490  190  Kostas   45
#[Out]# 491  190  Kostas   46
#[Out]# 492  190  Kostas   47
#[Out]# 493  190  Kostas   48
#[Out]# 494  190  Kostas   49
#[Out]# 495  190  Kostas   50
#[Out]# 496  190  Kostas   51
#[Out]# 497  190  Kostas   52
#[Out]# 498  190  Kostas   53
#[Out]# 499  190  Kostas   54
#[Out]# 500  190  Kostas   55
#[Out]# 501  190  Kostas   56
#[Out]# 502  190  Kostas   57
#[Out]# 503  190  Kostas   58
#[Out]# 504  190  Kostas   59
#[Out]# 505  190  Kostas   60
#[Out]# 506  190  Kostas   61
#[Out]# 507  190  Kostas   62
#[Out]# 508  190  Kostas   63
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 14:48:21
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId


FROM Customer AS C, Purchase AS P, store AS S


WHERE c.cID = P.cID 
AND P.sID = S.sID
 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID
#[Out]# 0      0    Noah    3
#[Out]# 1      1     Sem   23
#[Out]# 2      1     Sem    3
#[Out]# 3      1     Sem   17
#[Out]# 4      1     Sem   32
#[Out]# 5      1     Sem   16
#[Out]# 6      1     Sem   46
#[Out]# 7      1     Sem   36
#[Out]# 8      2   Lucas   12
#[Out]# 9      2   Lucas   39
#[Out]# 10     2   Lucas   13
#[Out]# 11     2   Lucas   51
#[Out]# 12     2   Lucas   47
#[Out]# 13     3    Finn   44
#[Out]# 14     3    Finn   30
#[Out]# 15     3    Finn   29
#[Out]# 16     4    Daan   17
#[Out]# 17     4    Daan   10
#[Out]# 18     4    Daan   53
#[Out]# 19     4    Daan   21
#[Out]# 20     4    Daan    7
#[Out]# 21     4    Daan   44
#[Out]# 22     5    Levi    4
#[Out]# 23     5    Levi   36
#[Out]# 24     5    Levi   55
#[Out]# 25     5    Levi   51
#[Out]# 26     5    Levi    6
#[Out]# 27     5    Levi   17
#[Out]# 28     7    Bram    3
#[Out]# 29     7    Bram   12
#[Out]# ..   ...     ...  ...
#[Out]# 479  190  Kostas   34
#[Out]# 480  190  Kostas   35
#[Out]# 481  190  Kostas   36
#[Out]# 482  190  Kostas   37
#[Out]# 483  190  Kostas   38
#[Out]# 484  190  Kostas   39
#[Out]# 485  190  Kostas   40
#[Out]# 486  190  Kostas   41
#[Out]# 487  190  Kostas   42
#[Out]# 488  190  Kostas   43
#[Out]# 489  190  Kostas   44
#[Out]# 490  190  Kostas   45
#[Out]# 491  190  Kostas   46
#[Out]# 492  190  Kostas   47
#[Out]# 493  190  Kostas   48
#[Out]# 494  190  Kostas   49
#[Out]# 495  190  Kostas   50
#[Out]# 496  190  Kostas   51
#[Out]# 497  190  Kostas   52
#[Out]# 498  190  Kostas   53
#[Out]# 499  190  Kostas   54
#[Out]# 500  190  Kostas   55
#[Out]# 501  190  Kostas   56
#[Out]# 502  190  Kostas   57
#[Out]# 503  190  Kostas   58
#[Out]# 504  190  Kostas   59
#[Out]# 505  190  Kostas   60
#[Out]# 506  190  Kostas   61
#[Out]# 507  190  Kostas   62
#[Out]# 508  190  Kostas   63
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 14:48:31
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName


FROM Customer AS C, Purchase AS P, store AS S


WHERE c.cID = P.cID 
AND P.sID = S.sID
 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 14:50:21
query3_4 = '''
    SELECT *
    FROM stores
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 14:50:26
query3_4 = '''
    SELECT *
    FROM store
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     0         Coop      Kalverstraat  Amsterdam
#[Out]# 1     1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 5     5       Sligro     Stationsplein      Breda
#[Out]# 6     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 7     7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 8     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 9     9  Albert Hein         Koestraat    Tilburg
#[Out]# 10   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 11   11  Albert Hein          Hofplein  Rotterdam
#[Out]# 12   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 13   13         Coop         Koestraat    Tilburg
#[Out]# 14   14         Coop     Keizersgracht  Amsterdam
#[Out]# 15   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 16   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 17   17    Hoogvliet        Kerkstraat  Eindhoven
#[Out]# 18   18       Sligro       Parallelweg    Tilburg
#[Out]# 19   19         Coop       Karrestraat      Breda
#[Out]# 20   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 21   21         Coop      Kasteeldreef    Tilburg
#[Out]# 22   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 23   23         Dirk     Stationsplein      Breda
#[Out]# 24   24  Albert Hein     Stationsplein      Breda
#[Out]# 25   25  Albert Hein     Stationsplein      Breda
#[Out]# 26   26    Hoogvliet   Sint Annastraat      Breda
#[Out]# 27   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 28   28    Hoogvliet         Koestraat    Tilburg
#[Out]# 29   29       Sligro      Marnixstraat  Amsterdam
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   34         Coop          Bierkaai  Amsterdam
#[Out]# 35   35         Lidl     Julianastraat    Utrecht
#[Out]# 36   36         Lidl     Julianastraat  Eindhoven
#[Out]# 37   37        Jumbo          Molenweg  Eindhoven
#[Out]# 38   38    Hoogvliet          Hofplein  Rotterdam
#[Out]# 39   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 40   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 41   41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 42   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 43   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 44   44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 45   45         Coop      Kasteeldreef    Tilburg
#[Out]# 46   46         Lidl        Bergselaan  Rotterdam
#[Out]# 47   47         Coop     Julianastraat  Rotterdam
#[Out]# 48   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 49   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 50   50       Sligro     Stationsplein      Breda
#[Out]# 51   51         Coop       Parallelweg    Utrecht
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   53         Coop        Hoogstraat    Utrecht
#[Out]# 54   54         Dirk     Julianastraat  Eindhoven
#[Out]# 55   55         Coop   Sint Annastraat      Breda
#[Out]# 56   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 57   57         Dirk       Molenstraat  Eindhoven
#[Out]# 58   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 59   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60         Lidl      Pannekoekweg      Breda
#[Out]# 61   61         Lidl      Pannekoekweg      Breda
#[Out]# 62   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63        Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Tue, 01 Dec 2020 14:51:57
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID


WHERE 

 
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 14:52:06
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID


WHERE 1=1

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 14:52:24
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE NOT EXISTS sName = 'coop'

 
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 14:53:28
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE NOT EXISTS 
    (SELECT sName  FROM store where sName= 'coop')

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 14:53:46
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE NOT EXISTS 
    (SELECT sName  FROM store where sName= 'coop')

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 14:54:17
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE NOT EXISTS 
    (SELECT sId  FROM store where sName= 'coop')

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 14:54:24
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE EXISTS 
    (SELECT sId  FROM store where sName= 'coop')

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sID, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 14:54:36
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE NOT EXISTS 
    (SELECT sName  FROM store where sName= 'coop')

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 14:54:39
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE  EXISTS 
    (SELECT sName  FROM store where sName= 'coop')

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sID, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 14:54:53
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE  EXISTS 
    (SELECT sName  FROM store where sName= 'Coop')

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 14:55:05
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE  EXISTS 
    (SELECT sName  FROM store where sName= 'coop')

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sID, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 14:55:15
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE NOT EXISTS 
    (SELECT sName  FROM store where sName= 'Coop')

 
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sID, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 14:56:51
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName NOT LIKE '%coop%'


 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     3    Finn   44  Albert Hein
#[Out]# 11     3    Finn   30         Dirk
#[Out]# 12     3    Finn   29       Sligro
#[Out]# 13     4    Daan   17    Hoogvliet
#[Out]# 14     4    Daan   10        Jumbo
#[Out]# 15     4    Daan    7       Sligro
#[Out]# 16     4    Daan   44  Albert Hein
#[Out]# 17     5    Levi    4    Hoogvliet
#[Out]# 18     5    Levi   36         Lidl
#[Out]# 19     5    Levi   17    Hoogvliet
#[Out]# 20     7    Bram    3       Sligro
#[Out]# 21     7    Bram   12         Lidl
#[Out]# 22     7    Bram   11  Albert Hein
#[Out]# 23     7    Bram   32  Albert Hein
#[Out]# 24     7    Bram   38    Hoogvliet
#[Out]# 25     7    Bram   42       Sligro
#[Out]# 26    13   James   33         Dirk
#[Out]# 27    13   James    4    Hoogvliet
#[Out]# 28    13   James   36         Lidl
#[Out]# 29    13   James   33         Dirk
#[Out]# ..   ...     ...  ...          ...
#[Out]# 347  190  Kostas   26    Hoogvliet
#[Out]# 348  190  Kostas   27       Sligro
#[Out]# 349  190  Kostas   28    Hoogvliet
#[Out]# 350  190  Kostas   29       Sligro
#[Out]# 351  190  Kostas   30         Dirk
#[Out]# 352  190  Kostas   32  Albert Hein
#[Out]# 353  190  Kostas   33         Dirk
#[Out]# 354  190  Kostas   35         Lidl
#[Out]# 355  190  Kostas   36         Lidl
#[Out]# 356  190  Kostas   37        Jumbo
#[Out]# 357  190  Kostas   38    Hoogvliet
#[Out]# 358  190  Kostas   39       Sligro
#[Out]# 359  190  Kostas   40    Hoogvliet
#[Out]# 360  190  Kostas   41  Albert Hein
#[Out]# 361  190  Kostas   42       Sligro
#[Out]# 362  190  Kostas   44  Albert Hein
#[Out]# 363  190  Kostas   46         Lidl
#[Out]# 364  190  Kostas   48    Hoogvliet
#[Out]# 365  190  Kostas   49    Hoogvliet
#[Out]# 366  190  Kostas   50       Sligro
#[Out]# 367  190  Kostas   52         Lidl
#[Out]# 368  190  Kostas   54         Dirk
#[Out]# 369  190  Kostas   56        Jumbo
#[Out]# 370  190  Kostas   57         Dirk
#[Out]# 371  190  Kostas   58         Dirk
#[Out]# 372  190  Kostas   59        Jumbo
#[Out]# 373  190  Kostas   60         Lidl
#[Out]# 374  190  Kostas   61         Lidl
#[Out]# 375  190  Kostas   62        Jumbo
#[Out]# 376  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [377 rows x 4 columns]
# Tue, 01 Dec 2020 14:57:04
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName NOT LIKE 'coop'


 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     3    Finn   44  Albert Hein
#[Out]# 11     3    Finn   30         Dirk
#[Out]# 12     3    Finn   29       Sligro
#[Out]# 13     4    Daan   17    Hoogvliet
#[Out]# 14     4    Daan   10        Jumbo
#[Out]# 15     4    Daan    7       Sligro
#[Out]# 16     4    Daan   44  Albert Hein
#[Out]# 17     5    Levi    4    Hoogvliet
#[Out]# 18     5    Levi   36         Lidl
#[Out]# 19     5    Levi   17    Hoogvliet
#[Out]# 20     7    Bram    3       Sligro
#[Out]# 21     7    Bram   12         Lidl
#[Out]# 22     7    Bram   11  Albert Hein
#[Out]# 23     7    Bram   32  Albert Hein
#[Out]# 24     7    Bram   38    Hoogvliet
#[Out]# 25     7    Bram   42       Sligro
#[Out]# 26    13   James   33         Dirk
#[Out]# 27    13   James    4    Hoogvliet
#[Out]# 28    13   James   36         Lidl
#[Out]# 29    13   James   33         Dirk
#[Out]# ..   ...     ...  ...          ...
#[Out]# 347  190  Kostas   26    Hoogvliet
#[Out]# 348  190  Kostas   27       Sligro
#[Out]# 349  190  Kostas   28    Hoogvliet
#[Out]# 350  190  Kostas   29       Sligro
#[Out]# 351  190  Kostas   30         Dirk
#[Out]# 352  190  Kostas   32  Albert Hein
#[Out]# 353  190  Kostas   33         Dirk
#[Out]# 354  190  Kostas   35         Lidl
#[Out]# 355  190  Kostas   36         Lidl
#[Out]# 356  190  Kostas   37        Jumbo
#[Out]# 357  190  Kostas   38    Hoogvliet
#[Out]# 358  190  Kostas   39       Sligro
#[Out]# 359  190  Kostas   40    Hoogvliet
#[Out]# 360  190  Kostas   41  Albert Hein
#[Out]# 361  190  Kostas   42       Sligro
#[Out]# 362  190  Kostas   44  Albert Hein
#[Out]# 363  190  Kostas   46         Lidl
#[Out]# 364  190  Kostas   48    Hoogvliet
#[Out]# 365  190  Kostas   49    Hoogvliet
#[Out]# 366  190  Kostas   50       Sligro
#[Out]# 367  190  Kostas   52         Lidl
#[Out]# 368  190  Kostas   54         Dirk
#[Out]# 369  190  Kostas   56        Jumbo
#[Out]# 370  190  Kostas   57         Dirk
#[Out]# 371  190  Kostas   58         Dirk
#[Out]# 372  190  Kostas   59        Jumbo
#[Out]# 373  190  Kostas   60         Lidl
#[Out]# 374  190  Kostas   61         Lidl
#[Out]# 375  190  Kostas   62        Jumbo
#[Out]# 376  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [377 rows x 4 columns]
# Tue, 01 Dec 2020 14:57:11
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE 1=1


 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 15:00:31
query3_3 = '''
(SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID
)
EXCEPT 
(SELECT )



 
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:00:48
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 15:02:47
query3_3 = '''
SELECT 
C.cID
,C.cName
,P.sId
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName = 'Coop'

'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName  sID sName
#[Out]# 0      2     Lucas   13  Coop
#[Out]# 1      2     Lucas   51  Coop
#[Out]# 2      2     Lucas   47  Coop
#[Out]# 3      4      Daan   53  Coop
#[Out]# 4      4      Daan   21  Coop
#[Out]# 5      5      Levi   55  Coop
#[Out]# 6      5      Levi   51  Coop
#[Out]# 7      5      Levi    6  Coop
#[Out]# 8      8      Liam   43  Coop
#[Out]# 9      8      Liam   51  Coop
#[Out]# 10    10       Sam   34  Coop
#[Out]# 11    11     Thijs    0  Coop
#[Out]# 12    16    Julian   14  Coop
#[Out]# 13    16    Julian   31  Coop
#[Out]# 14    16    Julian   55  Coop
#[Out]# 15    16    Julian   13  Coop
#[Out]# 16    17       Dex   51  Coop
#[Out]# 17    18      Hugo    6  Coop
#[Out]# 18    20      Gijs   21  Coop
#[Out]# 19    21  Benjamin   47  Coop
#[Out]# 20    24      Luca    0  Coop
#[Out]# 21    24      Luca   45  Coop
#[Out]# 22    24      Luca   14  Coop
#[Out]# 23    26    Jayden   21  Coop
#[Out]# 24    27       Tim   47  Coop
#[Out]# 25    27       Tim   34  Coop
#[Out]# 26    27       Tim   34  Coop
#[Out]# 27    28      Siem   43  Coop
#[Out]# 28    29     Ruben   43  Coop
#[Out]# 29    33      Sven   34  Coop
#[Out]# ..   ...       ...  ...   ...
#[Out]# 102  169      Lily   43  Coop
#[Out]# 103  169      Lily   55  Coop
#[Out]# 104  172      Lana    0  Coop
#[Out]# 105  176     Amira   19  Coop
#[Out]# 106  176     Amira    6  Coop
#[Out]# 107  177     Eline   47  Coop
#[Out]# 108  177     Eline   34  Coop
#[Out]# 109  177     Eline   51  Coop
#[Out]# 110  178      Elif   34  Coop
#[Out]# 111  179      Juul   43  Coop
#[Out]# 112  179      Juul   45  Coop
#[Out]# 113  180     Merel   34  Coop
#[Out]# 114  180     Merel   34  Coop
#[Out]# 115  181      Liva    6  Coop
#[Out]# 116  181      Liva   45  Coop
#[Out]# 117  184     Wilko    0  Coop
#[Out]# 118  190    Kostas    0  Coop
#[Out]# 119  190    Kostas    6  Coop
#[Out]# 120  190    Kostas   13  Coop
#[Out]# 121  190    Kostas   14  Coop
#[Out]# 122  190    Kostas   19  Coop
#[Out]# 123  190    Kostas   21  Coop
#[Out]# 124  190    Kostas   31  Coop
#[Out]# 125  190    Kostas   34  Coop
#[Out]# 126  190    Kostas   43  Coop
#[Out]# 127  190    Kostas   45  Coop
#[Out]# 128  190    Kostas   47  Coop
#[Out]# 129  190    Kostas   51  Coop
#[Out]# 130  190    Kostas   53  Coop
#[Out]# 131  190    Kostas   55  Coop
#[Out]# 
#[Out]# [132 rows x 4 columns]
# Tue, 01 Dec 2020 15:03:09
query3_3 = '''
SELECT 
C.cID

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName = 'Coop'

'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID
#[Out]# 0      2
#[Out]# 1      2
#[Out]# 2      2
#[Out]# 3      4
#[Out]# 4      4
#[Out]# 5      5
#[Out]# 6      5
#[Out]# 7      5
#[Out]# 8      8
#[Out]# 9      8
#[Out]# 10    10
#[Out]# 11    11
#[Out]# 12    16
#[Out]# 13    16
#[Out]# 14    16
#[Out]# 15    16
#[Out]# 16    17
#[Out]# 17    18
#[Out]# 18    20
#[Out]# 19    21
#[Out]# 20    24
#[Out]# 21    24
#[Out]# 22    24
#[Out]# 23    26
#[Out]# 24    27
#[Out]# 25    27
#[Out]# 26    27
#[Out]# 27    28
#[Out]# 28    29
#[Out]# 29    33
#[Out]# ..   ...
#[Out]# 102  169
#[Out]# 103  169
#[Out]# 104  172
#[Out]# 105  176
#[Out]# 106  176
#[Out]# 107  177
#[Out]# 108  177
#[Out]# 109  177
#[Out]# 110  178
#[Out]# 111  179
#[Out]# 112  179
#[Out]# 113  180
#[Out]# 114  180
#[Out]# 115  181
#[Out]# 116  181
#[Out]# 117  184
#[Out]# 118  190
#[Out]# 119  190
#[Out]# 120  190
#[Out]# 121  190
#[Out]# 122  190
#[Out]# 123  190
#[Out]# 124  190
#[Out]# 125  190
#[Out]# 126  190
#[Out]# 127  190
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 
#[Out]# [132 rows x 1 columns]
# Tue, 01 Dec 2020 15:03:16
query3_3 = '''
SELECT 
C.cID
,C.cName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName = 'Coop'

'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      2     Lucas
#[Out]# 1      2     Lucas
#[Out]# 2      2     Lucas
#[Out]# 3      4      Daan
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      5      Levi
#[Out]# 7      5      Levi
#[Out]# 8      8      Liam
#[Out]# 9      8      Liam
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    16    Julian
#[Out]# 13    16    Julian
#[Out]# 14    16    Julian
#[Out]# 15    16    Julian
#[Out]# 16    17       Dex
#[Out]# 17    18      Hugo
#[Out]# 18    20      Gijs
#[Out]# 19    21  Benjamin
#[Out]# 20    24      Luca
#[Out]# 21    24      Luca
#[Out]# 22    24      Luca
#[Out]# 23    26    Jayden
#[Out]# 24    27       Tim
#[Out]# 25    27       Tim
#[Out]# 26    27       Tim
#[Out]# 27    28      Siem
#[Out]# 28    29     Ruben
#[Out]# 29    33      Sven
#[Out]# ..   ...       ...
#[Out]# 102  169      Lily
#[Out]# 103  169      Lily
#[Out]# 104  172      Lana
#[Out]# 105  176     Amira
#[Out]# 106  176     Amira
#[Out]# 107  177     Eline
#[Out]# 108  177     Eline
#[Out]# 109  177     Eline
#[Out]# 110  178      Elif
#[Out]# 111  179      Juul
#[Out]# 112  179      Juul
#[Out]# 113  180     Merel
#[Out]# 114  180     Merel
#[Out]# 115  181      Liva
#[Out]# 116  181      Liva
#[Out]# 117  184     Wilko
#[Out]# 118  190    Kostas
#[Out]# 119  190    Kostas
#[Out]# 120  190    Kostas
#[Out]# 121  190    Kostas
#[Out]# 122  190    Kostas
#[Out]# 123  190    Kostas
#[Out]# 124  190    Kostas
#[Out]# 125  190    Kostas
#[Out]# 126  190    Kostas
#[Out]# 127  190    Kostas
#[Out]# 128  190    Kostas
#[Out]# 129  190    Kostas
#[Out]# 130  190    Kostas
#[Out]# 131  190    Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 15:03:22
query3_3 = '''
SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName = 'Coop'

'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID      cName
#[Out]# 0     2      Lucas
#[Out]# 1     4       Daan
#[Out]# 2     5       Levi
#[Out]# 3     8       Liam
#[Out]# 4    10        Sam
#[Out]# 5    11      Thijs
#[Out]# 6    16     Julian
#[Out]# 7    17        Dex
#[Out]# 8    18       Hugo
#[Out]# 9    20       Gijs
#[Out]# 10   21   Benjamin
#[Out]# 11   24       Luca
#[Out]# 12   26     Jayden
#[Out]# 13   27        Tim
#[Out]# 14   28       Siem
#[Out]# 15   29      Ruben
#[Out]# 16   33       Sven
#[Out]# 17   35      Stijn
#[Out]# 18   39       Jack
#[Out]# 19   42       Tijn
#[Out]# 20   51       Ties
#[Out]# 21   55      Aiden
#[Out]# 22   57     Nathan
#[Out]# 23   59       Joep
#[Out]# 24   67      Rayan
#[Out]# 25   71       Dean
#[Out]# 26   75       Jace
#[Out]# 27   76  Alexander
#[Out]# 28   78       Mick
#[Out]# 29   82      Dylan
#[Out]# ..  ...        ...
#[Out]# 44  116      Lieke
#[Out]# 45  118       Lisa
#[Out]# 46  122       Elin
#[Out]# 47  123      Milou
#[Out]# 48  124      Sofie
#[Out]# 49  127      Emily
#[Out]# 50  129      Esmee
#[Out]# 51  131        Amy
#[Out]# 52  133     Sophia
#[Out]# 53  134       Ella
#[Out]# 54  135      Sofia
#[Out]# 55  139      Elise
#[Out]# 56  144        Ivy
#[Out]# 57  147     Isabel
#[Out]# 58  151       Jill
#[Out]# 59  152       Anne
#[Out]# 60  161      Floor
#[Out]# 61  162      Elena
#[Out]# 62  163       Cato
#[Out]# 63  165      Hanna
#[Out]# 64  169       Lily
#[Out]# 65  172       Lana
#[Out]# 66  176      Amira
#[Out]# 67  177      Eline
#[Out]# 68  178       Elif
#[Out]# 69  179       Juul
#[Out]# 70  180      Merel
#[Out]# 71  181       Liva
#[Out]# 72  184      Wilko
#[Out]# 73  190     Kostas
#[Out]# 
#[Out]# [74 rows x 2 columns]
# Tue, 01 Dec 2020 15:04:27
query3_3 = '''
(SELECT 
c.cID
,c.cName
FROM Customer AS C

)



'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:04:37
query3_3 = '''
SELECT 
c.cID
,c.cName
FROM Customer AS C




'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:04:51
query3_3 = '''
(SELECT 
c.cID
,c.cName
FROM Customer AS C)
EXCEPT
(SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName = 'Coop')





'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:07:06
query3_3 = '''
(SELECT 
c.cID
,c.cName
FROM Customer AS C)
EXCEPT
(SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C, purchase AS P, store AS S

WHERE sName = 'Coop'
AND P.cID = c.cID
AND P.sID = S.sID)





'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:08:10
query3_3 = '''
(SELECT 
c.cID
FROM Customer AS C)
EXCEPT
(SELECT DISTINCT
C.cID
FROM Customer AS C, purchase AS P, store AS S
WHERE sName = 'Coop'
AND P.cID = c.cID
AND P.sID = S.sID)





'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:08:16
query3_3 = '''
(SELECT 
c.cID
,c.cName
FROM Customer AS C)
EXCEPT
(SELECT DISTINCT
C.cID
,C.cName
FROM Customer AS C, purchase AS P, store AS S
WHERE sName = 'Coop'
AND P.cID = c.cID
AND P.sID = S.sID)





'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:08:40
query3_3 = '''
SELECT 
c.cID
,c.cName
FROM Customer AS C






'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:10:14
query3_3 = '''
SELECT 
c.cID
,c.cName
FROM Customer AS C

WHERE C.cID, c.cName NOT IN (SELECT DISTINCT
C.cID
,C.cName
FROM Customer AS C, purchase AS P, store AS S
WHERE sName = 'Coop'
AND P.cID = c.cID
AND P.sID = S.sID)






'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:11:37
query3_3 = '''
SELECT 
c.cID
,c.cName
FROM Customer AS C






'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:12:56
query3_3 = '''
SELECT 
c.cID
,c.cName
FROM Customer AS C
WHERE NOT EXISTS (SELECT DISTINCT
C.cID
,C.cName
FROM Customer AS C, purchase AS P, store AS S
WHERE sName = 'Coop'
AND P.cID = c.cID
AND P.sID = S.sID)

'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 15:13:06
query3_3 = '''
SELECT 
c.cID
,c.cName
FROM Customer AS C
WHERE EXISTS (SELECT DISTINCT
C.cID
,C.cName
FROM Customer AS C, purchase AS P, store AS S
WHERE sName = 'Coop'
AND P.cID = c.cID
AND P.sID = S.sID)

'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:13:13
query3_3 = '''
SELECT 
c.cID
,c.cName
FROM Customer AS C


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:13:41
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    
    FROM Customer AS C
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:15:12
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      1     Sem
#[Out]# 3      1     Sem
#[Out]# 4      1     Sem
#[Out]# 5      1     Sem
#[Out]# 6      1     Sem
#[Out]# 7      1     Sem
#[Out]# 8      2   Lucas
#[Out]# 9      2   Lucas
#[Out]# 10     2   Lucas
#[Out]# 11     2   Lucas
#[Out]# 12     2   Lucas
#[Out]# 13     3    Finn
#[Out]# 14     3    Finn
#[Out]# 15     3    Finn
#[Out]# 16     4    Daan
#[Out]# 17     4    Daan
#[Out]# 18     4    Daan
#[Out]# 19     4    Daan
#[Out]# 20     4    Daan
#[Out]# 21     4    Daan
#[Out]# 22     5    Levi
#[Out]# 23     5    Levi
#[Out]# 24     5    Levi
#[Out]# 25     5    Levi
#[Out]# 26     5    Levi
#[Out]# 27     5    Levi
#[Out]# 28     7    Bram
#[Out]# 29     7    Bram
#[Out]# ..   ...     ...
#[Out]# 479  190  Kostas
#[Out]# 480  190  Kostas
#[Out]# 481  190  Kostas
#[Out]# 482  190  Kostas
#[Out]# 483  190  Kostas
#[Out]# 484  190  Kostas
#[Out]# 485  190  Kostas
#[Out]# 486  190  Kostas
#[Out]# 487  190  Kostas
#[Out]# 488  190  Kostas
#[Out]# 489  190  Kostas
#[Out]# 490  190  Kostas
#[Out]# 491  190  Kostas
#[Out]# 492  190  Kostas
#[Out]# 493  190  Kostas
#[Out]# 494  190  Kostas
#[Out]# 495  190  Kostas
#[Out]# 496  190  Kostas
#[Out]# 497  190  Kostas
#[Out]# 498  190  Kostas
#[Out]# 499  190  Kostas
#[Out]# 500  190  Kostas
#[Out]# 501  190  Kostas
#[Out]# 502  190  Kostas
#[Out]# 503  190  Kostas
#[Out]# 504  190  Kostas
#[Out]# 505  190  Kostas
#[Out]# 506  190  Kostas
#[Out]# 507  190  Kostas
#[Out]# 508  190  Kostas
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Tue, 01 Dec 2020 15:15:27
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,S.sName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem         Dirk
#[Out]# 2      1     Sem       Sligro
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem  Albert Hein
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas       Sligro
#[Out]# 10     2   Lucas         Coop
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn  Albert Hein
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn       Sligro
#[Out]# 16     4    Daan    Hoogvliet
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan         Coop
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan       Sligro
#[Out]# 21     4    Daan  Albert Hein
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Lidl
#[Out]# 24     5    Levi         Coop
#[Out]# 25     5    Levi         Coop
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi    Hoogvliet
#[Out]# 28     7    Bram       Sligro
#[Out]# 29     7    Bram         Lidl
#[Out]# ..   ...     ...          ...
#[Out]# 479  190  Kostas         Coop
#[Out]# 480  190  Kostas         Lidl
#[Out]# 481  190  Kostas         Lidl
#[Out]# 482  190  Kostas        Jumbo
#[Out]# 483  190  Kostas    Hoogvliet
#[Out]# 484  190  Kostas       Sligro
#[Out]# 485  190  Kostas    Hoogvliet
#[Out]# 486  190  Kostas  Albert Hein
#[Out]# 487  190  Kostas       Sligro
#[Out]# 488  190  Kostas         Coop
#[Out]# 489  190  Kostas  Albert Hein
#[Out]# 490  190  Kostas         Coop
#[Out]# 491  190  Kostas         Lidl
#[Out]# 492  190  Kostas         Coop
#[Out]# 493  190  Kostas    Hoogvliet
#[Out]# 494  190  Kostas    Hoogvliet
#[Out]# 495  190  Kostas       Sligro
#[Out]# 496  190  Kostas         Coop
#[Out]# 497  190  Kostas         Lidl
#[Out]# 498  190  Kostas         Coop
#[Out]# 499  190  Kostas         Dirk
#[Out]# 500  190  Kostas         Coop
#[Out]# 501  190  Kostas        Jumbo
#[Out]# 502  190  Kostas         Dirk
#[Out]# 503  190  Kostas         Dirk
#[Out]# 504  190  Kostas        Jumbo
#[Out]# 505  190  Kostas         Lidl
#[Out]# 506  190  Kostas         Lidl
#[Out]# 507  190  Kostas        Jumbo
#[Out]# 508  190  Kostas        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 15:16:35
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,S.sName
    ,P.tId
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName        sName  tID
#[Out]# 0      0    Noah       Sligro    0
#[Out]# 1      1     Sem         Dirk    1
#[Out]# 2      1     Sem       Sligro    2
#[Out]# 3      1     Sem    Hoogvliet    3
#[Out]# 4      1     Sem  Albert Hein    4
#[Out]# 5      1     Sem         Lidl    5
#[Out]# 6      1     Sem         Lidl    6
#[Out]# 7      1     Sem         Lidl    7
#[Out]# 8      2   Lucas         Lidl    8
#[Out]# 9      2   Lucas       Sligro    9
#[Out]# 10     2   Lucas         Coop   10
#[Out]# 11     2   Lucas         Coop   11
#[Out]# 12     2   Lucas         Coop   12
#[Out]# 13     3    Finn  Albert Hein   13
#[Out]# 14     3    Finn         Dirk   14
#[Out]# 15     3    Finn       Sligro   15
#[Out]# 16     4    Daan    Hoogvliet   16
#[Out]# 17     4    Daan        Jumbo   17
#[Out]# 18     4    Daan         Coop   18
#[Out]# 19     4    Daan         Coop   19
#[Out]# 20     4    Daan       Sligro   20
#[Out]# 21     4    Daan  Albert Hein   21
#[Out]# 22     5    Levi    Hoogvliet   22
#[Out]# 23     5    Levi         Lidl   23
#[Out]# 24     5    Levi         Coop   24
#[Out]# 25     5    Levi         Coop   25
#[Out]# 26     5    Levi         Coop   26
#[Out]# 27     5    Levi    Hoogvliet   27
#[Out]# 28     7    Bram       Sligro   28
#[Out]# 29     7    Bram         Lidl   29
#[Out]# ..   ...     ...          ...  ...
#[Out]# 479  190  Kostas         Coop  818
#[Out]# 480  190  Kostas         Lidl  819
#[Out]# 481  190  Kostas         Lidl  820
#[Out]# 482  190  Kostas        Jumbo  821
#[Out]# 483  190  Kostas    Hoogvliet  822
#[Out]# 484  190  Kostas       Sligro  823
#[Out]# 485  190  Kostas    Hoogvliet  824
#[Out]# 486  190  Kostas  Albert Hein  825
#[Out]# 487  190  Kostas       Sligro  826
#[Out]# 488  190  Kostas         Coop  827
#[Out]# 489  190  Kostas  Albert Hein  828
#[Out]# 490  190  Kostas         Coop  829
#[Out]# 491  190  Kostas         Lidl  830
#[Out]# 492  190  Kostas         Coop  831
#[Out]# 493  190  Kostas    Hoogvliet  832
#[Out]# 494  190  Kostas    Hoogvliet  833
#[Out]# 495  190  Kostas       Sligro  834
#[Out]# 496  190  Kostas         Coop  835
#[Out]# 497  190  Kostas         Lidl  836
#[Out]# 498  190  Kostas         Coop  837
#[Out]# 499  190  Kostas         Dirk  838
#[Out]# 500  190  Kostas         Coop  839
#[Out]# 501  190  Kostas        Jumbo  840
#[Out]# 502  190  Kostas         Dirk  841
#[Out]# 503  190  Kostas         Dirk  842
#[Out]# 504  190  Kostas        Jumbo  843
#[Out]# 505  190  Kostas         Lidl  844
#[Out]# 506  190  Kostas         Lidl  845
#[Out]# 507  190  Kostas        Jumbo  846
#[Out]# 508  190  Kostas        Jumbo  847
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 15:16:45
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,S.sName
    ,S.sId
    ,P.tId
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName        sName  sID  tID
#[Out]# 0      0    Noah       Sligro    3    0
#[Out]# 1      1     Sem         Dirk   23    1
#[Out]# 2      1     Sem       Sligro    3    2
#[Out]# 3      1     Sem    Hoogvliet   17    3
#[Out]# 4      1     Sem  Albert Hein   32    4
#[Out]# 5      1     Sem         Lidl   16    5
#[Out]# 6      1     Sem         Lidl   46    6
#[Out]# 7      1     Sem         Lidl   36    7
#[Out]# 8      2   Lucas         Lidl   12    8
#[Out]# 9      2   Lucas       Sligro   39    9
#[Out]# 10     2   Lucas         Coop   13   10
#[Out]# 11     2   Lucas         Coop   51   11
#[Out]# 12     2   Lucas         Coop   47   12
#[Out]# 13     3    Finn  Albert Hein   44   13
#[Out]# 14     3    Finn         Dirk   30   14
#[Out]# 15     3    Finn       Sligro   29   15
#[Out]# 16     4    Daan    Hoogvliet   17   16
#[Out]# 17     4    Daan        Jumbo   10   17
#[Out]# 18     4    Daan         Coop   53   18
#[Out]# 19     4    Daan         Coop   21   19
#[Out]# 20     4    Daan       Sligro    7   20
#[Out]# 21     4    Daan  Albert Hein   44   21
#[Out]# 22     5    Levi    Hoogvliet    4   22
#[Out]# 23     5    Levi         Lidl   36   23
#[Out]# 24     5    Levi         Coop   55   24
#[Out]# 25     5    Levi         Coop   51   25
#[Out]# 26     5    Levi         Coop    6   26
#[Out]# 27     5    Levi    Hoogvliet   17   27
#[Out]# 28     7    Bram       Sligro    3   28
#[Out]# 29     7    Bram         Lidl   12   29
#[Out]# ..   ...     ...          ...  ...  ...
#[Out]# 479  190  Kostas         Coop   34  818
#[Out]# 480  190  Kostas         Lidl   35  819
#[Out]# 481  190  Kostas         Lidl   36  820
#[Out]# 482  190  Kostas        Jumbo   37  821
#[Out]# 483  190  Kostas    Hoogvliet   38  822
#[Out]# 484  190  Kostas       Sligro   39  823
#[Out]# 485  190  Kostas    Hoogvliet   40  824
#[Out]# 486  190  Kostas  Albert Hein   41  825
#[Out]# 487  190  Kostas       Sligro   42  826
#[Out]# 488  190  Kostas         Coop   43  827
#[Out]# 489  190  Kostas  Albert Hein   44  828
#[Out]# 490  190  Kostas         Coop   45  829
#[Out]# 491  190  Kostas         Lidl   46  830
#[Out]# 492  190  Kostas         Coop   47  831
#[Out]# 493  190  Kostas    Hoogvliet   48  832
#[Out]# 494  190  Kostas    Hoogvliet   49  833
#[Out]# 495  190  Kostas       Sligro   50  834
#[Out]# 496  190  Kostas         Coop   51  835
#[Out]# 497  190  Kostas         Lidl   52  836
#[Out]# 498  190  Kostas         Coop   53  837
#[Out]# 499  190  Kostas         Dirk   54  838
#[Out]# 500  190  Kostas         Coop   55  839
#[Out]# 501  190  Kostas        Jumbo   56  840
#[Out]# 502  190  Kostas         Dirk   57  841
#[Out]# 503  190  Kostas         Dirk   58  842
#[Out]# 504  190  Kostas        Jumbo   59  843
#[Out]# 505  190  Kostas         Lidl   60  844
#[Out]# 506  190  Kostas         Lidl   61  845
#[Out]# 507  190  Kostas        Jumbo   62  846
#[Out]# 508  190  Kostas        Jumbo   63  847
#[Out]# 
#[Out]# [509 rows x 5 columns]
# Tue, 01 Dec 2020 15:18:59
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,S.sName
    ,S.sId
    ,P.tId
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID AND S.sName like '%Sligro%'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID    cName   sName  sID  tID
#[Out]# 0     0     Noah  Sligro    3    0
#[Out]# 1     1      Sem  Sligro    3    2
#[Out]# 2     2    Lucas  Sligro   39    9
#[Out]# 3     3     Finn  Sligro   29   15
#[Out]# 4     4     Daan  Sligro    7   20
#[Out]# 5     7     Bram  Sligro    3   28
#[Out]# 6     7     Bram  Sligro   42   33
#[Out]# 7    13    James  Sligro   50   42
#[Out]# 8    16   Julian  Sligro   50   48
#[Out]# 9    16   Julian  Sligro   27   53
#[Out]# 10   18     Hugo  Sligro   29   60
#[Out]# 11   19     Lars  Sligro    3   64
#[Out]# 12   20     Gijs  Sligro   29   67
#[Out]# 13   22     Mats  Sligro   27   74
#[Out]# 14   27      Tim  Sligro   42   89
#[Out]# 15   29    Ruben  Sligro   29   94
#[Out]# 16   30     Teun  Sligro    7   96
#[Out]# 17   31  Olivier  Sligro   42   98
#[Out]# 18   31  Olivier  Sligro   39   99
#[Out]# 19   33     Sven  Sligro   39  100
#[Out]# 20   33     Sven  Sligro   29  108
#[Out]# 21   41    Quinn  Sligro    3  129
#[Out]# 22   43      Tom  Sligro   50  134
#[Out]# 23   44    Jason  Sligro   42  136
#[Out]# 24   44    Jason  Sligro    5  137
#[Out]# 25   51     Ties  Sligro   18  157
#[Out]# 26   52   Willem  Sligro    3  160
#[Out]# 27   52   Willem  Sligro   27  161
#[Out]# 28   57   Nathan  Sligro   29  165
#[Out]# 29   58    Jurre  Sligro   42  168
#[Out]# ..  ...      ...     ...  ...  ...
#[Out]# 56  109     Lynn  Sligro   29  289
#[Out]# 57  116    Lieke  Sligro   29  306
#[Out]# 58  124    Sofie  Sligro   18  329
#[Out]# 59  126     Lina  Sligro    7  335
#[Out]# 60  127    Emily  Sligro    3  336
#[Out]# 61  134     Ella  Sligro    7  348
#[Out]# 62  137     Lena  Sligro   29  351
#[Out]# 63  152     Anne  Sligro   42  370
#[Out]# 64  161    Floor  Sligro    3  390
#[Out]# 65  161    Floor  Sligro   18  391
#[Out]# 66  162    Elena  Sligro   18  397
#[Out]# 67  167   Veerle  Sligro   39  416
#[Out]# 68  167   Veerle  Sligro   18  418
#[Out]# 69  167   Veerle  Sligro    3  421
#[Out]# 70  167   Veerle  Sligro   50  424
#[Out]# 71  169     Lily  Sligro   18  428
#[Out]# 72  175      Sam  Sligro   27  445
#[Out]# 73  178     Elif  Sligro   39  459
#[Out]# 74  181     Liva  Sligro   27  471
#[Out]# 75  182  Johanna  Sligro    5  473
#[Out]# 76  182  Johanna  Sligro    5  473
#[Out]# 77  190   Kostas  Sligro    3  787
#[Out]# 78  190   Kostas  Sligro    5  789
#[Out]# 79  190   Kostas  Sligro    7  791
#[Out]# 80  190   Kostas  Sligro   18  802
#[Out]# 81  190   Kostas  Sligro   27  811
#[Out]# 82  190   Kostas  Sligro   29  813
#[Out]# 83  190   Kostas  Sligro   39  823
#[Out]# 84  190   Kostas  Sligro   42  826
#[Out]# 85  190   Kostas  Sligro   50  834
#[Out]# 
#[Out]# [86 rows x 5 columns]
# Tue, 01 Dec 2020 15:21:09
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID AND S.sName like '%Sligro%'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID    cName
#[Out]# 0     0     Noah
#[Out]# 1     1      Sem
#[Out]# 2     2    Lucas
#[Out]# 3     3     Finn
#[Out]# 4     4     Daan
#[Out]# 5     7     Bram
#[Out]# 6     7     Bram
#[Out]# 7    13    James
#[Out]# 8    16   Julian
#[Out]# 9    16   Julian
#[Out]# 10   18     Hugo
#[Out]# 11   19     Lars
#[Out]# 12   20     Gijs
#[Out]# 13   22     Mats
#[Out]# 14   27      Tim
#[Out]# 15   29    Ruben
#[Out]# 16   30     Teun
#[Out]# 17   31  Olivier
#[Out]# 18   31  Olivier
#[Out]# 19   33     Sven
#[Out]# 20   33     Sven
#[Out]# 21   41    Quinn
#[Out]# 22   43      Tom
#[Out]# 23   44    Jason
#[Out]# 24   44    Jason
#[Out]# 25   51     Ties
#[Out]# 26   52   Willem
#[Out]# 27   52   Willem
#[Out]# 28   57   Nathan
#[Out]# 29   58    Jurre
#[Out]# ..  ...      ...
#[Out]# 56  109     Lynn
#[Out]# 57  116    Lieke
#[Out]# 58  124    Sofie
#[Out]# 59  126     Lina
#[Out]# 60  127    Emily
#[Out]# 61  134     Ella
#[Out]# 62  137     Lena
#[Out]# 63  152     Anne
#[Out]# 64  161    Floor
#[Out]# 65  161    Floor
#[Out]# 66  162    Elena
#[Out]# 67  167   Veerle
#[Out]# 68  167   Veerle
#[Out]# 69  167   Veerle
#[Out]# 70  167   Veerle
#[Out]# 71  169     Lily
#[Out]# 72  175      Sam
#[Out]# 73  178     Elif
#[Out]# 74  181     Liva
#[Out]# 75  182  Johanna
#[Out]# 76  182  Johanna
#[Out]# 77  190   Kostas
#[Out]# 78  190   Kostas
#[Out]# 79  190   Kostas
#[Out]# 80  190   Kostas
#[Out]# 81  190   Kostas
#[Out]# 82  190   Kostas
#[Out]# 83  190   Kostas
#[Out]# 84  190   Kostas
#[Out]# 85  190   Kostas
#[Out]# 
#[Out]# [86 rows x 2 columns]
# Tue, 01 Dec 2020 15:22:38
query3_4 = '''
SELECY * FROM store
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 15:22:44
query3_4 = '''
SELECT * FROM store
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     0         Coop      Kalverstraat  Amsterdam
#[Out]# 1     1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 5     5       Sligro     Stationsplein      Breda
#[Out]# 6     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 7     7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 8     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 9     9  Albert Hein         Koestraat    Tilburg
#[Out]# 10   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 11   11  Albert Hein          Hofplein  Rotterdam
#[Out]# 12   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 13   13         Coop         Koestraat    Tilburg
#[Out]# 14   14         Coop     Keizersgracht  Amsterdam
#[Out]# 15   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 16   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 17   17    Hoogvliet        Kerkstraat  Eindhoven
#[Out]# 18   18       Sligro       Parallelweg    Tilburg
#[Out]# 19   19         Coop       Karrestraat      Breda
#[Out]# 20   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 21   21         Coop      Kasteeldreef    Tilburg
#[Out]# 22   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 23   23         Dirk     Stationsplein      Breda
#[Out]# 24   24  Albert Hein     Stationsplein      Breda
#[Out]# 25   25  Albert Hein     Stationsplein      Breda
#[Out]# 26   26    Hoogvliet   Sint Annastraat      Breda
#[Out]# 27   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 28   28    Hoogvliet         Koestraat    Tilburg
#[Out]# 29   29       Sligro      Marnixstraat  Amsterdam
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   34         Coop          Bierkaai  Amsterdam
#[Out]# 35   35         Lidl     Julianastraat    Utrecht
#[Out]# 36   36         Lidl     Julianastraat  Eindhoven
#[Out]# 37   37        Jumbo          Molenweg  Eindhoven
#[Out]# 38   38    Hoogvliet          Hofplein  Rotterdam
#[Out]# 39   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 40   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 41   41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 42   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 43   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 44   44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 45   45         Coop      Kasteeldreef    Tilburg
#[Out]# 46   46         Lidl        Bergselaan  Rotterdam
#[Out]# 47   47         Coop     Julianastraat  Rotterdam
#[Out]# 48   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 49   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 50   50       Sligro     Stationsplein      Breda
#[Out]# 51   51         Coop       Parallelweg    Utrecht
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   53         Coop        Hoogstraat    Utrecht
#[Out]# 54   54         Dirk     Julianastraat  Eindhoven
#[Out]# 55   55         Coop   Sint Annastraat      Breda
#[Out]# 56   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 57   57         Dirk       Molenstraat  Eindhoven
#[Out]# 58   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 59   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60         Lidl      Pannekoekweg      Breda
#[Out]# 61   61         Lidl      Pannekoekweg      Breda
#[Out]# 62   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63        Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Tue, 01 Dec 2020 15:24:25
query3_4 = '''
(SELECT DISTINCT
C.cID
,C.cName
FROM Customer AS C, purchase AS P, store AS S
WHERE sName = 'Coop'
AND P.cID = c.cID
AND P.sID = S.sID)

    SELECT 
    C.cID
    ,C.cName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID AND S.sName like '%Sligro%' 
    AND S.sName NOT LIKE '%Coop%' 
    AND S.sName NOT LIKE '%Jumbo%'
    AND S.sName NOT LIKE '%Hoogvliet%'
    AND S.sName NOT LIKE '%Albert%'
    AND S.sName NOT LIKE '%Lidl%'
    AND S.sName NOT LIKE '%Dirk%'
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 15:25:00
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID AND S.sName like '%Sligro%' 
    AND S.sName NOT LIKE '%Coop%' 
    AND S.sName NOT LIKE '%Jumbo%'
    AND S.sName NOT LIKE '%Hoogvliet%'
    AND S.sName NOT LIKE '%Albert%'
    AND S.sName NOT LIKE '%Lidl%'
    AND S.sName NOT LIKE '%Dirk%'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID    cName
#[Out]# 0     0     Noah
#[Out]# 1     1      Sem
#[Out]# 2     2    Lucas
#[Out]# 3     3     Finn
#[Out]# 4     4     Daan
#[Out]# 5     7     Bram
#[Out]# 6     7     Bram
#[Out]# 7    13    James
#[Out]# 8    16   Julian
#[Out]# 9    16   Julian
#[Out]# 10   18     Hugo
#[Out]# 11   19     Lars
#[Out]# 12   20     Gijs
#[Out]# 13   22     Mats
#[Out]# 14   27      Tim
#[Out]# 15   29    Ruben
#[Out]# 16   30     Teun
#[Out]# 17   31  Olivier
#[Out]# 18   31  Olivier
#[Out]# 19   33     Sven
#[Out]# 20   33     Sven
#[Out]# 21   41    Quinn
#[Out]# 22   43      Tom
#[Out]# 23   44    Jason
#[Out]# 24   44    Jason
#[Out]# 25   51     Ties
#[Out]# 26   52   Willem
#[Out]# 27   52   Willem
#[Out]# 28   57   Nathan
#[Out]# 29   58    Jurre
#[Out]# ..  ...      ...
#[Out]# 56  109     Lynn
#[Out]# 57  116    Lieke
#[Out]# 58  124    Sofie
#[Out]# 59  126     Lina
#[Out]# 60  127    Emily
#[Out]# 61  134     Ella
#[Out]# 62  137     Lena
#[Out]# 63  152     Anne
#[Out]# 64  161    Floor
#[Out]# 65  161    Floor
#[Out]# 66  162    Elena
#[Out]# 67  167   Veerle
#[Out]# 68  167   Veerle
#[Out]# 69  167   Veerle
#[Out]# 70  167   Veerle
#[Out]# 71  169     Lily
#[Out]# 72  175      Sam
#[Out]# 73  178     Elif
#[Out]# 74  181     Liva
#[Out]# 75  182  Johanna
#[Out]# 76  182  Johanna
#[Out]# 77  190   Kostas
#[Out]# 78  190   Kostas
#[Out]# 79  190   Kostas
#[Out]# 80  190   Kostas
#[Out]# 81  190   Kostas
#[Out]# 82  190   Kostas
#[Out]# 83  190   Kostas
#[Out]# 84  190   Kostas
#[Out]# 85  190   Kostas
#[Out]# 
#[Out]# [86 rows x 2 columns]
# Tue, 01 Dec 2020 15:25:18
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID AND S.sName like '%Sligro%' 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID    cName
#[Out]# 0     0     Noah
#[Out]# 1     1      Sem
#[Out]# 2     2    Lucas
#[Out]# 3     3     Finn
#[Out]# 4     4     Daan
#[Out]# 5     7     Bram
#[Out]# 6     7     Bram
#[Out]# 7    13    James
#[Out]# 8    16   Julian
#[Out]# 9    16   Julian
#[Out]# 10   18     Hugo
#[Out]# 11   19     Lars
#[Out]# 12   20     Gijs
#[Out]# 13   22     Mats
#[Out]# 14   27      Tim
#[Out]# 15   29    Ruben
#[Out]# 16   30     Teun
#[Out]# 17   31  Olivier
#[Out]# 18   31  Olivier
#[Out]# 19   33     Sven
#[Out]# 20   33     Sven
#[Out]# 21   41    Quinn
#[Out]# 22   43      Tom
#[Out]# 23   44    Jason
#[Out]# 24   44    Jason
#[Out]# 25   51     Ties
#[Out]# 26   52   Willem
#[Out]# 27   52   Willem
#[Out]# 28   57   Nathan
#[Out]# 29   58    Jurre
#[Out]# ..  ...      ...
#[Out]# 56  109     Lynn
#[Out]# 57  116    Lieke
#[Out]# 58  124    Sofie
#[Out]# 59  126     Lina
#[Out]# 60  127    Emily
#[Out]# 61  134     Ella
#[Out]# 62  137     Lena
#[Out]# 63  152     Anne
#[Out]# 64  161    Floor
#[Out]# 65  161    Floor
#[Out]# 66  162    Elena
#[Out]# 67  167   Veerle
#[Out]# 68  167   Veerle
#[Out]# 69  167   Veerle
#[Out]# 70  167   Veerle
#[Out]# 71  169     Lily
#[Out]# 72  175      Sam
#[Out]# 73  178     Elif
#[Out]# 74  181     Liva
#[Out]# 75  182  Johanna
#[Out]# 76  182  Johanna
#[Out]# 77  190   Kostas
#[Out]# 78  190   Kostas
#[Out]# 79  190   Kostas
#[Out]# 80  190   Kostas
#[Out]# 81  190   Kostas
#[Out]# 82  190   Kostas
#[Out]# 83  190   Kostas
#[Out]# 84  190   Kostas
#[Out]# 85  190   Kostas
#[Out]# 
#[Out]# [86 rows x 2 columns]
# Tue, 01 Dec 2020 15:27:01
query3_3 = '''
WITH AllCustomers AS(
SELECT 
c.cID
,c.cName
FROM Customer AS C)

SELECT * FROM AllCustomers


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:27:48
query3_3 = '''
WITH AllCustomers AS(
SELECT 
c.cID
,c.cName
FROM Customer AS C)

,CustomerWithoutKumar AS (
SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName = 'Coop')


SELECT * CustomerWithoutKumar 
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:28:13
query3_3 = '''
WITH AllCustomers AS(
SELECT 
c.cID
,c.cName
FROM Customer AS C)

,CustomerWithoutKumar (
SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName = 'Coop')


SELECT * CustomerWithoutKumar 
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:28:57
query3_3 = '''
WITH AllCustomers AS(
SELECT 
c.cID
,c.cName
FROM Customer AS C),

CustomerWithoutKumar AS (
SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE sName = 'Coop')


SELECT * CustomerWithoutKumar 
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:29:15
query3_3 = '''

SELECT 
c.cID
,c.cName
FROM Customer AS C


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:29:30
query3_3 = '''

SELECT DISTINCT
C.cID
,C.cName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE 1=1


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      7      Bram
#[Out]# 7      8      Liam
#[Out]# 8     10       Sam
#[Out]# 9     11     Thijs
#[Out]# 10    13     James
#[Out]# 11    15      Noud
#[Out]# 12    16    Julian
#[Out]# 13    17       Dex
#[Out]# 14    18      Hugo
#[Out]# 15    19      Lars
#[Out]# 16    20      Gijs
#[Out]# 17    21  Benjamin
#[Out]# 18    22      Mats
#[Out]# 19    24      Luca
#[Out]# 20    25     Mason
#[Out]# 21    26    Jayden
#[Out]# 22    27       Tim
#[Out]# 23    28      Siem
#[Out]# 24    29     Ruben
#[Out]# 25    30      Teun
#[Out]# 26    31   Olivier
#[Out]# 27    33      Sven
#[Out]# 28    34     David
#[Out]# 29    35     Stijn
#[Out]# ..   ...       ...
#[Out]# 102  147    Isabel
#[Out]# 103  149     Lizzy
#[Out]# 104  151      Jill
#[Out]# 105  152      Anne
#[Out]# 106  157      Puck
#[Out]# 107  159     Fenne
#[Out]# 108  161     Floor
#[Out]# 109  162     Elena
#[Out]# 110  163      Cato
#[Out]# 111  165     Hanna
#[Out]# 112  167    Veerle
#[Out]# 113  168      Kiki
#[Out]# 114  169      Lily
#[Out]# 115  170      Iris
#[Out]# 116  171     Tessa
#[Out]# 117  172      Lana
#[Out]# 118  175       Sam
#[Out]# 119  176     Amira
#[Out]# 120  177     Eline
#[Out]# 121  178      Elif
#[Out]# 122  179      Juul
#[Out]# 123  180     Merel
#[Out]# 124  181      Liva
#[Out]# 125  182   Johanna
#[Out]# 126  184     Wilko
#[Out]# 127  185      Nick
#[Out]# 128  186    Angela
#[Out]# 129  188      Pino
#[Out]# 130  189      Koen
#[Out]# 131  190    Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 15:29:46
query3_3 = '''

SELECT DISTINCT
C.cID
,C.cName
,S.sName

FROM Customer AS C
INNER JOIN Purchase AS P ON P.cID = c.cID
INNER JOIN store AS S ON P.sID = S.sID

WHERE 1=1


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName        sName
#[Out]# 0      0     Noah       Sligro
#[Out]# 1      1      Sem         Dirk
#[Out]# 2      1      Sem       Sligro
#[Out]# 3      1      Sem    Hoogvliet
#[Out]# 4      1      Sem  Albert Hein
#[Out]# 5      1      Sem         Lidl
#[Out]# 6      2    Lucas         Lidl
#[Out]# 7      2    Lucas       Sligro
#[Out]# 8      2    Lucas         Coop
#[Out]# 9      3     Finn  Albert Hein
#[Out]# 10     3     Finn         Dirk
#[Out]# 11     3     Finn       Sligro
#[Out]# 12     4     Daan    Hoogvliet
#[Out]# 13     4     Daan        Jumbo
#[Out]# 14     4     Daan         Coop
#[Out]# 15     4     Daan       Sligro
#[Out]# 16     4     Daan  Albert Hein
#[Out]# 17     5     Levi    Hoogvliet
#[Out]# 18     5     Levi         Lidl
#[Out]# 19     5     Levi         Coop
#[Out]# 20     7     Bram       Sligro
#[Out]# 21     7     Bram         Lidl
#[Out]# 22     7     Bram  Albert Hein
#[Out]# 23     7     Bram    Hoogvliet
#[Out]# 24     8     Liam         Coop
#[Out]# 25    10      Sam         Coop
#[Out]# 26    11    Thijs         Coop
#[Out]# 27    13    James         Dirk
#[Out]# 28    13    James    Hoogvliet
#[Out]# 29    13    James         Lidl
#[Out]# ..   ...      ...          ...
#[Out]# 304  176    Amira         Lidl
#[Out]# 305  176    Amira         Coop
#[Out]# 306  176    Amira    Hoogvliet
#[Out]# 307  177    Eline         Coop
#[Out]# 308  177    Eline    Hoogvliet
#[Out]# 309  177    Eline  Albert Hein
#[Out]# 310  178     Elif         Coop
#[Out]# 311  178     Elif       Sligro
#[Out]# 312  179     Juul  Albert Hein
#[Out]# 313  179     Juul         Dirk
#[Out]# 314  179     Juul         Coop
#[Out]# 315  179     Juul         Lidl
#[Out]# 316  180    Merel         Coop
#[Out]# 317  180    Merel        Jumbo
#[Out]# 318  181     Liva         Coop
#[Out]# 319  181     Liva       Sligro
#[Out]# 320  182  Johanna    Hoogvliet
#[Out]# 321  182  Johanna       Sligro
#[Out]# 322  184    Wilko         Coop
#[Out]# 323  185     Nick        Jumbo
#[Out]# 324  186   Angela        Jumbo
#[Out]# 325  188     Pino        Jumbo
#[Out]# 326  189     Koen        Jumbo
#[Out]# 327  190   Kostas         Coop
#[Out]# 328  190   Kostas    Hoogvliet
#[Out]# 329  190   Kostas        Jumbo
#[Out]# 330  190   Kostas       Sligro
#[Out]# 331  190   Kostas  Albert Hein
#[Out]# 332  190   Kostas         Lidl
#[Out]# 333  190   Kostas         Dirk
#[Out]# 
#[Out]# [334 rows x 3 columns]
# Tue, 01 Dec 2020 15:30:17
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID  
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      1     Sem
#[Out]# 3      1     Sem
#[Out]# 4      1     Sem
#[Out]# 5      1     Sem
#[Out]# 6      1     Sem
#[Out]# 7      1     Sem
#[Out]# 8      2   Lucas
#[Out]# 9      2   Lucas
#[Out]# 10     2   Lucas
#[Out]# 11     2   Lucas
#[Out]# 12     2   Lucas
#[Out]# 13     3    Finn
#[Out]# 14     3    Finn
#[Out]# 15     3    Finn
#[Out]# 16     4    Daan
#[Out]# 17     4    Daan
#[Out]# 18     4    Daan
#[Out]# 19     4    Daan
#[Out]# 20     4    Daan
#[Out]# 21     4    Daan
#[Out]# 22     5    Levi
#[Out]# 23     5    Levi
#[Out]# 24     5    Levi
#[Out]# 25     5    Levi
#[Out]# 26     5    Levi
#[Out]# 27     5    Levi
#[Out]# 28     7    Bram
#[Out]# 29     7    Bram
#[Out]# ..   ...     ...
#[Out]# 479  190  Kostas
#[Out]# 480  190  Kostas
#[Out]# 481  190  Kostas
#[Out]# 482  190  Kostas
#[Out]# 483  190  Kostas
#[Out]# 484  190  Kostas
#[Out]# 485  190  Kostas
#[Out]# 486  190  Kostas
#[Out]# 487  190  Kostas
#[Out]# 488  190  Kostas
#[Out]# 489  190  Kostas
#[Out]# 490  190  Kostas
#[Out]# 491  190  Kostas
#[Out]# 492  190  Kostas
#[Out]# 493  190  Kostas
#[Out]# 494  190  Kostas
#[Out]# 495  190  Kostas
#[Out]# 496  190  Kostas
#[Out]# 497  190  Kostas
#[Out]# 498  190  Kostas
#[Out]# 499  190  Kostas
#[Out]# 500  190  Kostas
#[Out]# 501  190  Kostas
#[Out]# 502  190  Kostas
#[Out]# 503  190  Kostas
#[Out]# 504  190  Kostas
#[Out]# 505  190  Kostas
#[Out]# 506  190  Kostas
#[Out]# 507  190  Kostas
#[Out]# 508  190  Kostas
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Tue, 01 Dec 2020 15:36:35
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    ,S.sName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sID = S.sID  
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem         Dirk
#[Out]# 2      1     Sem       Sligro
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem  Albert Hein
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas       Sligro
#[Out]# 10     2   Lucas         Coop
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn  Albert Hein
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn       Sligro
#[Out]# 16     4    Daan    Hoogvliet
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan         Coop
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan       Sligro
#[Out]# 21     4    Daan  Albert Hein
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Lidl
#[Out]# 24     5    Levi         Coop
#[Out]# 25     5    Levi         Coop
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi    Hoogvliet
#[Out]# 28     7    Bram       Sligro
#[Out]# 29     7    Bram         Lidl
#[Out]# ..   ...     ...          ...
#[Out]# 479  190  Kostas         Coop
#[Out]# 480  190  Kostas         Lidl
#[Out]# 481  190  Kostas         Lidl
#[Out]# 482  190  Kostas        Jumbo
#[Out]# 483  190  Kostas    Hoogvliet
#[Out]# 484  190  Kostas       Sligro
#[Out]# 485  190  Kostas    Hoogvliet
#[Out]# 486  190  Kostas  Albert Hein
#[Out]# 487  190  Kostas       Sligro
#[Out]# 488  190  Kostas         Coop
#[Out]# 489  190  Kostas  Albert Hein
#[Out]# 490  190  Kostas         Coop
#[Out]# 491  190  Kostas         Lidl
#[Out]# 492  190  Kostas         Coop
#[Out]# 493  190  Kostas    Hoogvliet
#[Out]# 494  190  Kostas    Hoogvliet
#[Out]# 495  190  Kostas       Sligro
#[Out]# 496  190  Kostas         Coop
#[Out]# 497  190  Kostas         Lidl
#[Out]# 498  190  Kostas         Coop
#[Out]# 499  190  Kostas         Dirk
#[Out]# 500  190  Kostas         Coop
#[Out]# 501  190  Kostas        Jumbo
#[Out]# 502  190  Kostas         Dirk
#[Out]# 503  190  Kostas         Dirk
#[Out]# 504  190  Kostas        Jumbo
#[Out]# 505  190  Kostas         Lidl
#[Out]# 506  190  Kostas         Lidl
#[Out]# 507  190  Kostas        Jumbo
#[Out]# 508  190  Kostas        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 15:45:20
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    ,S.sName
    
    FROM Customer AS C, purchase AS P
    
    WHERE P.cID = C.cID  
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 15:45:28
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    
    FROM Customer AS C, purchase AS P
    
    WHERE P.cID = C.cID  
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName  sID
#[Out]# 0      0    Noah    3
#[Out]# 1      1     Sem   23
#[Out]# 2      1     Sem    3
#[Out]# 3      1     Sem   17
#[Out]# 4      1     Sem   32
#[Out]# 5      1     Sem   16
#[Out]# 6      1     Sem   46
#[Out]# 7      1     Sem   36
#[Out]# 8      2   Lucas   12
#[Out]# 9      2   Lucas   39
#[Out]# 10     2   Lucas   13
#[Out]# 11     2   Lucas   51
#[Out]# 12     2   Lucas   47
#[Out]# 13     3    Finn   44
#[Out]# 14     3    Finn   30
#[Out]# 15     3    Finn   29
#[Out]# 16     4    Daan   17
#[Out]# 17     4    Daan   10
#[Out]# 18     4    Daan   53
#[Out]# 19     4    Daan   21
#[Out]# 20     4    Daan    7
#[Out]# 21     4    Daan   44
#[Out]# 22     5    Levi    4
#[Out]# 23     5    Levi   36
#[Out]# 24     5    Levi   55
#[Out]# 25     5    Levi   51
#[Out]# 26     5    Levi    6
#[Out]# 27     5    Levi   17
#[Out]# 28     7    Bram    3
#[Out]# 29     7    Bram   12
#[Out]# ..   ...     ...  ...
#[Out]# 479  190  Kostas   34
#[Out]# 480  190  Kostas   35
#[Out]# 481  190  Kostas   36
#[Out]# 482  190  Kostas   37
#[Out]# 483  190  Kostas   38
#[Out]# 484  190  Kostas   39
#[Out]# 485  190  Kostas   40
#[Out]# 486  190  Kostas   41
#[Out]# 487  190  Kostas   42
#[Out]# 488  190  Kostas   43
#[Out]# 489  190  Kostas   44
#[Out]# 490  190  Kostas   45
#[Out]# 491  190  Kostas   46
#[Out]# 492  190  Kostas   47
#[Out]# 493  190  Kostas   48
#[Out]# 494  190  Kostas   49
#[Out]# 495  190  Kostas   50
#[Out]# 496  190  Kostas   51
#[Out]# 497  190  Kostas   52
#[Out]# 498  190  Kostas   53
#[Out]# 499  190  Kostas   54
#[Out]# 500  190  Kostas   55
#[Out]# 501  190  Kostas   56
#[Out]# 502  190  Kostas   57
#[Out]# 503  190  Kostas   58
#[Out]# 504  190  Kostas   59
#[Out]# 505  190  Kostas   60
#[Out]# 506  190  Kostas   61
#[Out]# 507  190  Kostas   62
#[Out]# 508  190  Kostas   63
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 15:47:30
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    
    FROM Customer AS C, purchase AS P
    
    WHERE P.cID = C.cID AND P.sId IN (SELECT s.sID 
                                        FROM store 
                                        WHERE sName like '%Coop%')
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 15:47:49
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    
    FROM Customer AS C, purchase AS P
    
    WHERE P.cID = C.cID AND P.sId IN (SELECT s.sID 
                                        FROM store S
                                        WHERE sName like '%Coop%')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID     cName  sID
#[Out]# 0      2     Lucas   13
#[Out]# 1      2     Lucas   51
#[Out]# 2      2     Lucas   47
#[Out]# 3      4      Daan   53
#[Out]# 4      4      Daan   21
#[Out]# 5      5      Levi   55
#[Out]# 6      5      Levi   51
#[Out]# 7      5      Levi    6
#[Out]# 8      8      Liam   43
#[Out]# 9      8      Liam   51
#[Out]# 10    10       Sam   34
#[Out]# 11    11     Thijs    0
#[Out]# 12    16    Julian   14
#[Out]# 13    16    Julian   31
#[Out]# 14    16    Julian   55
#[Out]# 15    16    Julian   13
#[Out]# 16    17       Dex   51
#[Out]# 17    18      Hugo    6
#[Out]# 18    20      Gijs   21
#[Out]# 19    21  Benjamin   47
#[Out]# 20    24      Luca    0
#[Out]# 21    24      Luca   45
#[Out]# 22    24      Luca   14
#[Out]# 23    26    Jayden   21
#[Out]# 24    27       Tim   47
#[Out]# 25    27       Tim   34
#[Out]# 26    27       Tim   34
#[Out]# 27    28      Siem   43
#[Out]# 28    29     Ruben   43
#[Out]# 29    33      Sven   34
#[Out]# ..   ...       ...  ...
#[Out]# 102  169      Lily   43
#[Out]# 103  169      Lily   55
#[Out]# 104  172      Lana    0
#[Out]# 105  176     Amira   19
#[Out]# 106  176     Amira    6
#[Out]# 107  177     Eline   47
#[Out]# 108  177     Eline   34
#[Out]# 109  177     Eline   51
#[Out]# 110  178      Elif   34
#[Out]# 111  179      Juul   43
#[Out]# 112  179      Juul   45
#[Out]# 113  180     Merel   34
#[Out]# 114  180     Merel   34
#[Out]# 115  181      Liva    6
#[Out]# 116  181      Liva   45
#[Out]# 117  184     Wilko    0
#[Out]# 118  190    Kostas    0
#[Out]# 119  190    Kostas    6
#[Out]# 120  190    Kostas   13
#[Out]# 121  190    Kostas   14
#[Out]# 122  190    Kostas   19
#[Out]# 123  190    Kostas   21
#[Out]# 124  190    Kostas   31
#[Out]# 125  190    Kostas   34
#[Out]# 126  190    Kostas   43
#[Out]# 127  190    Kostas   45
#[Out]# 128  190    Kostas   47
#[Out]# 129  190    Kostas   51
#[Out]# 130  190    Kostas   53
#[Out]# 131  190    Kostas   55
#[Out]# 
#[Out]# [132 rows x 3 columns]
# Tue, 01 Dec 2020 15:56:16
query3_3 = '''

    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    
    FROM Customer AS C, purchase AS P
    
    WHERE P.cID = C.cID


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName  sID
#[Out]# 0      0    Noah    3
#[Out]# 1      1     Sem   23
#[Out]# 2      1     Sem    3
#[Out]# 3      1     Sem   17
#[Out]# 4      1     Sem   32
#[Out]# 5      1     Sem   16
#[Out]# 6      1     Sem   46
#[Out]# 7      1     Sem   36
#[Out]# 8      2   Lucas   12
#[Out]# 9      2   Lucas   39
#[Out]# 10     2   Lucas   13
#[Out]# 11     2   Lucas   51
#[Out]# 12     2   Lucas   47
#[Out]# 13     3    Finn   44
#[Out]# 14     3    Finn   30
#[Out]# 15     3    Finn   29
#[Out]# 16     4    Daan   17
#[Out]# 17     4    Daan   10
#[Out]# 18     4    Daan   53
#[Out]# 19     4    Daan   21
#[Out]# 20     4    Daan    7
#[Out]# 21     4    Daan   44
#[Out]# 22     5    Levi    4
#[Out]# 23     5    Levi   36
#[Out]# 24     5    Levi   55
#[Out]# 25     5    Levi   51
#[Out]# 26     5    Levi    6
#[Out]# 27     5    Levi   17
#[Out]# 28     7    Bram    3
#[Out]# 29     7    Bram   12
#[Out]# ..   ...     ...  ...
#[Out]# 479  190  Kostas   34
#[Out]# 480  190  Kostas   35
#[Out]# 481  190  Kostas   36
#[Out]# 482  190  Kostas   37
#[Out]# 483  190  Kostas   38
#[Out]# 484  190  Kostas   39
#[Out]# 485  190  Kostas   40
#[Out]# 486  190  Kostas   41
#[Out]# 487  190  Kostas   42
#[Out]# 488  190  Kostas   43
#[Out]# 489  190  Kostas   44
#[Out]# 490  190  Kostas   45
#[Out]# 491  190  Kostas   46
#[Out]# 492  190  Kostas   47
#[Out]# 493  190  Kostas   48
#[Out]# 494  190  Kostas   49
#[Out]# 495  190  Kostas   50
#[Out]# 496  190  Kostas   51
#[Out]# 497  190  Kostas   52
#[Out]# 498  190  Kostas   53
#[Out]# 499  190  Kostas   54
#[Out]# 500  190  Kostas   55
#[Out]# 501  190  Kostas   56
#[Out]# 502  190  Kostas   57
#[Out]# 503  190  Kostas   58
#[Out]# 504  190  Kostas   59
#[Out]# 505  190  Kostas   60
#[Out]# 506  190  Kostas   61
#[Out]# 507  190  Kostas   62
#[Out]# 508  190  Kostas   63
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 15:57:35
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    ,S.sName
    
    FROM Customer AS C, purchase AS P
    
    WHERE P.cID = C.cID AND P.sId IN (SELECT s.sID 
                                        FROM store S
                                        WHERE sName like '%Coop%')
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 15:57:42
query3_4 = '''

    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    
    FROM Customer AS C, purchase AS P
    
    WHERE P.cID = C.cID AND P.sId IN (SELECT s.sID 
                                        FROM store S
                                        WHERE sName like '%Coop%')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID     cName  sID
#[Out]# 0      2     Lucas   13
#[Out]# 1      2     Lucas   51
#[Out]# 2      2     Lucas   47
#[Out]# 3      4      Daan   53
#[Out]# 4      4      Daan   21
#[Out]# 5      5      Levi   55
#[Out]# 6      5      Levi   51
#[Out]# 7      5      Levi    6
#[Out]# 8      8      Liam   43
#[Out]# 9      8      Liam   51
#[Out]# 10    10       Sam   34
#[Out]# 11    11     Thijs    0
#[Out]# 12    16    Julian   14
#[Out]# 13    16    Julian   31
#[Out]# 14    16    Julian   55
#[Out]# 15    16    Julian   13
#[Out]# 16    17       Dex   51
#[Out]# 17    18      Hugo    6
#[Out]# 18    20      Gijs   21
#[Out]# 19    21  Benjamin   47
#[Out]# 20    24      Luca    0
#[Out]# 21    24      Luca   45
#[Out]# 22    24      Luca   14
#[Out]# 23    26    Jayden   21
#[Out]# 24    27       Tim   47
#[Out]# 25    27       Tim   34
#[Out]# 26    27       Tim   34
#[Out]# 27    28      Siem   43
#[Out]# 28    29     Ruben   43
#[Out]# 29    33      Sven   34
#[Out]# ..   ...       ...  ...
#[Out]# 102  169      Lily   43
#[Out]# 103  169      Lily   55
#[Out]# 104  172      Lana    0
#[Out]# 105  176     Amira   19
#[Out]# 106  176     Amira    6
#[Out]# 107  177     Eline   47
#[Out]# 108  177     Eline   34
#[Out]# 109  177     Eline   51
#[Out]# 110  178      Elif   34
#[Out]# 111  179      Juul   43
#[Out]# 112  179      Juul   45
#[Out]# 113  180     Merel   34
#[Out]# 114  180     Merel   34
#[Out]# 115  181      Liva    6
#[Out]# 116  181      Liva   45
#[Out]# 117  184     Wilko    0
#[Out]# 118  190    Kostas    0
#[Out]# 119  190    Kostas    6
#[Out]# 120  190    Kostas   13
#[Out]# 121  190    Kostas   14
#[Out]# 122  190    Kostas   19
#[Out]# 123  190    Kostas   21
#[Out]# 124  190    Kostas   31
#[Out]# 125  190    Kostas   34
#[Out]# 126  190    Kostas   43
#[Out]# 127  190    Kostas   45
#[Out]# 128  190    Kostas   47
#[Out]# 129  190    Kostas   51
#[Out]# 130  190    Kostas   53
#[Out]# 131  190    Kostas   55
#[Out]# 
#[Out]# [132 rows x 3 columns]
# Tue, 01 Dec 2020 17:28:16
query3_3 = '''

    SELECT 
    C.cID
    ,C.cName
    
    FROM Customer AS C


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 17:32:32
query3_3 = '''

    SELECT C.cID,C.cName 
    FROM Customer AS C, purchase AS P
    WHERE P.cId = C.cID


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      1     Sem
#[Out]# 3      1     Sem
#[Out]# 4      1     Sem
#[Out]# 5      1     Sem
#[Out]# 6      1     Sem
#[Out]# 7      1     Sem
#[Out]# 8      2   Lucas
#[Out]# 9      2   Lucas
#[Out]# 10     2   Lucas
#[Out]# 11     2   Lucas
#[Out]# 12     2   Lucas
#[Out]# 13     3    Finn
#[Out]# 14     3    Finn
#[Out]# 15     3    Finn
#[Out]# 16     4    Daan
#[Out]# 17     4    Daan
#[Out]# 18     4    Daan
#[Out]# 19     4    Daan
#[Out]# 20     4    Daan
#[Out]# 21     4    Daan
#[Out]# 22     5    Levi
#[Out]# 23     5    Levi
#[Out]# 24     5    Levi
#[Out]# 25     5    Levi
#[Out]# 26     5    Levi
#[Out]# 27     5    Levi
#[Out]# 28     7    Bram
#[Out]# 29     7    Bram
#[Out]# ..   ...     ...
#[Out]# 479  190  Kostas
#[Out]# 480  190  Kostas
#[Out]# 481  190  Kostas
#[Out]# 482  190  Kostas
#[Out]# 483  190  Kostas
#[Out]# 484  190  Kostas
#[Out]# 485  190  Kostas
#[Out]# 486  190  Kostas
#[Out]# 487  190  Kostas
#[Out]# 488  190  Kostas
#[Out]# 489  190  Kostas
#[Out]# 490  190  Kostas
#[Out]# 491  190  Kostas
#[Out]# 492  190  Kostas
#[Out]# 493  190  Kostas
#[Out]# 494  190  Kostas
#[Out]# 495  190  Kostas
#[Out]# 496  190  Kostas
#[Out]# 497  190  Kostas
#[Out]# 498  190  Kostas
#[Out]# 499  190  Kostas
#[Out]# 500  190  Kostas
#[Out]# 501  190  Kostas
#[Out]# 502  190  Kostas
#[Out]# 503  190  Kostas
#[Out]# 504  190  Kostas
#[Out]# 505  190  Kostas
#[Out]# 506  190  Kostas
#[Out]# 507  190  Kostas
#[Out]# 508  190  Kostas
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Tue, 01 Dec 2020 17:33:52
query3_3 = '''

    SELECT C.cID,C.cName 
    FROM Customer AS C, purchase AS P, store AS S
    WHERE P.cId = C.cID, P.sID = S.sID


'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 17:34:02
query3_3 = '''

    SELECT C.cID,C.cName 
    FROM Customer AS C, purchase AS P, store AS S
    WHERE P.cId = C.cID AND P.sID = S.sID


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      1     Sem
#[Out]# 3      1     Sem
#[Out]# 4      1     Sem
#[Out]# 5      1     Sem
#[Out]# 6      1     Sem
#[Out]# 7      1     Sem
#[Out]# 8      2   Lucas
#[Out]# 9      2   Lucas
#[Out]# 10     2   Lucas
#[Out]# 11     2   Lucas
#[Out]# 12     2   Lucas
#[Out]# 13     3    Finn
#[Out]# 14     3    Finn
#[Out]# 15     3    Finn
#[Out]# 16     4    Daan
#[Out]# 17     4    Daan
#[Out]# 18     4    Daan
#[Out]# 19     4    Daan
#[Out]# 20     4    Daan
#[Out]# 21     4    Daan
#[Out]# 22     5    Levi
#[Out]# 23     5    Levi
#[Out]# 24     5    Levi
#[Out]# 25     5    Levi
#[Out]# 26     5    Levi
#[Out]# 27     5    Levi
#[Out]# 28     7    Bram
#[Out]# 29     7    Bram
#[Out]# ..   ...     ...
#[Out]# 479  190  Kostas
#[Out]# 480  190  Kostas
#[Out]# 481  190  Kostas
#[Out]# 482  190  Kostas
#[Out]# 483  190  Kostas
#[Out]# 484  190  Kostas
#[Out]# 485  190  Kostas
#[Out]# 486  190  Kostas
#[Out]# 487  190  Kostas
#[Out]# 488  190  Kostas
#[Out]# 489  190  Kostas
#[Out]# 490  190  Kostas
#[Out]# 491  190  Kostas
#[Out]# 492  190  Kostas
#[Out]# 493  190  Kostas
#[Out]# 494  190  Kostas
#[Out]# 495  190  Kostas
#[Out]# 496  190  Kostas
#[Out]# 497  190  Kostas
#[Out]# 498  190  Kostas
#[Out]# 499  190  Kostas
#[Out]# 500  190  Kostas
#[Out]# 501  190  Kostas
#[Out]# 502  190  Kostas
#[Out]# 503  190  Kostas
#[Out]# 504  190  Kostas
#[Out]# 505  190  Kostas
#[Out]# 506  190  Kostas
#[Out]# 507  190  Kostas
#[Out]# 508  190  Kostas
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Tue, 01 Dec 2020 17:34:09
query3_3 = '''

    SELECT C.cID,C.cName,sName 
    FROM Customer AS C, purchase AS P, store AS S
    WHERE P.cId = C.cID AND P.sID = S.sID


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem         Dirk
#[Out]# 2      1     Sem       Sligro
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem  Albert Hein
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas       Sligro
#[Out]# 10     2   Lucas         Coop
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn  Albert Hein
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn       Sligro
#[Out]# 16     4    Daan    Hoogvliet
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan         Coop
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan       Sligro
#[Out]# 21     4    Daan  Albert Hein
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Lidl
#[Out]# 24     5    Levi         Coop
#[Out]# 25     5    Levi         Coop
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi    Hoogvliet
#[Out]# 28     7    Bram       Sligro
#[Out]# 29     7    Bram         Lidl
#[Out]# ..   ...     ...          ...
#[Out]# 479  190  Kostas         Coop
#[Out]# 480  190  Kostas         Lidl
#[Out]# 481  190  Kostas         Lidl
#[Out]# 482  190  Kostas        Jumbo
#[Out]# 483  190  Kostas    Hoogvliet
#[Out]# 484  190  Kostas       Sligro
#[Out]# 485  190  Kostas    Hoogvliet
#[Out]# 486  190  Kostas  Albert Hein
#[Out]# 487  190  Kostas       Sligro
#[Out]# 488  190  Kostas         Coop
#[Out]# 489  190  Kostas  Albert Hein
#[Out]# 490  190  Kostas         Coop
#[Out]# 491  190  Kostas         Lidl
#[Out]# 492  190  Kostas         Coop
#[Out]# 493  190  Kostas    Hoogvliet
#[Out]# 494  190  Kostas    Hoogvliet
#[Out]# 495  190  Kostas       Sligro
#[Out]# 496  190  Kostas         Coop
#[Out]# 497  190  Kostas         Lidl
#[Out]# 498  190  Kostas         Coop
#[Out]# 499  190  Kostas         Dirk
#[Out]# 500  190  Kostas         Coop
#[Out]# 501  190  Kostas        Jumbo
#[Out]# 502  190  Kostas         Dirk
#[Out]# 503  190  Kostas         Dirk
#[Out]# 504  190  Kostas        Jumbo
#[Out]# 505  190  Kostas         Lidl
#[Out]# 506  190  Kostas         Lidl
#[Out]# 507  190  Kostas        Jumbo
#[Out]# 508  190  Kostas        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 17:34:43
query3_3 = '''

    SELECT C.cID,C.cName,sName 
    FROM Customer AS C, purchase AS P, store AS S
    WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName like '%Coop%'


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName sName
#[Out]# 0      2     Lucas  Coop
#[Out]# 1      2     Lucas  Coop
#[Out]# 2      2     Lucas  Coop
#[Out]# 3      4      Daan  Coop
#[Out]# 4      4      Daan  Coop
#[Out]# 5      5      Levi  Coop
#[Out]# 6      5      Levi  Coop
#[Out]# 7      5      Levi  Coop
#[Out]# 8      8      Liam  Coop
#[Out]# 9      8      Liam  Coop
#[Out]# 10    10       Sam  Coop
#[Out]# 11    11     Thijs  Coop
#[Out]# 12    16    Julian  Coop
#[Out]# 13    16    Julian  Coop
#[Out]# 14    16    Julian  Coop
#[Out]# 15    16    Julian  Coop
#[Out]# 16    17       Dex  Coop
#[Out]# 17    18      Hugo  Coop
#[Out]# 18    20      Gijs  Coop
#[Out]# 19    21  Benjamin  Coop
#[Out]# 20    24      Luca  Coop
#[Out]# 21    24      Luca  Coop
#[Out]# 22    24      Luca  Coop
#[Out]# 23    26    Jayden  Coop
#[Out]# 24    27       Tim  Coop
#[Out]# 25    27       Tim  Coop
#[Out]# 26    27       Tim  Coop
#[Out]# 27    28      Siem  Coop
#[Out]# 28    29     Ruben  Coop
#[Out]# 29    33      Sven  Coop
#[Out]# ..   ...       ...   ...
#[Out]# 102  169      Lily  Coop
#[Out]# 103  169      Lily  Coop
#[Out]# 104  172      Lana  Coop
#[Out]# 105  176     Amira  Coop
#[Out]# 106  176     Amira  Coop
#[Out]# 107  177     Eline  Coop
#[Out]# 108  177     Eline  Coop
#[Out]# 109  177     Eline  Coop
#[Out]# 110  178      Elif  Coop
#[Out]# 111  179      Juul  Coop
#[Out]# 112  179      Juul  Coop
#[Out]# 113  180     Merel  Coop
#[Out]# 114  180     Merel  Coop
#[Out]# 115  181      Liva  Coop
#[Out]# 116  181      Liva  Coop
#[Out]# 117  184     Wilko  Coop
#[Out]# 118  190    Kostas  Coop
#[Out]# 119  190    Kostas  Coop
#[Out]# 120  190    Kostas  Coop
#[Out]# 121  190    Kostas  Coop
#[Out]# 122  190    Kostas  Coop
#[Out]# 123  190    Kostas  Coop
#[Out]# 124  190    Kostas  Coop
#[Out]# 125  190    Kostas  Coop
#[Out]# 126  190    Kostas  Coop
#[Out]# 127  190    Kostas  Coop
#[Out]# 128  190    Kostas  Coop
#[Out]# 129  190    Kostas  Coop
#[Out]# 130  190    Kostas  Coop
#[Out]# 131  190    Kostas  Coop
#[Out]# 
#[Out]# [132 rows x 3 columns]
# Tue, 01 Dec 2020 17:35:27
query3_3 = '''

        
    SELECT C.cID,C.cName FROM Customer AS C
    EXCEPT
    SELECT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName like '%Coop%'


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 17:41:36
query3_3 = '''

        
    SELECT DISTINCT C.cID,C.cName FROM Customer AS C
    EXCEPT
    SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName like '%Coop%'


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 17:42:28
query3_4 = '''

    SELECT DISTINCT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID 

'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID    cName        sName
#[Out]# 0      0     Noah       Sligro
#[Out]# 1      1      Sem         Dirk
#[Out]# 2      1      Sem       Sligro
#[Out]# 3      1      Sem    Hoogvliet
#[Out]# 4      1      Sem  Albert Hein
#[Out]# 5      1      Sem         Lidl
#[Out]# 6      2    Lucas         Lidl
#[Out]# 7      2    Lucas       Sligro
#[Out]# 8      2    Lucas         Coop
#[Out]# 9      3     Finn  Albert Hein
#[Out]# 10     3     Finn         Dirk
#[Out]# 11     3     Finn       Sligro
#[Out]# 12     4     Daan    Hoogvliet
#[Out]# 13     4     Daan        Jumbo
#[Out]# 14     4     Daan         Coop
#[Out]# 15     4     Daan       Sligro
#[Out]# 16     4     Daan  Albert Hein
#[Out]# 17     5     Levi    Hoogvliet
#[Out]# 18     5     Levi         Lidl
#[Out]# 19     5     Levi         Coop
#[Out]# 20     7     Bram       Sligro
#[Out]# 21     7     Bram         Lidl
#[Out]# 22     7     Bram  Albert Hein
#[Out]# 23     7     Bram    Hoogvliet
#[Out]# 24     8     Liam         Coop
#[Out]# 25    10      Sam         Coop
#[Out]# 26    11    Thijs         Coop
#[Out]# 27    13    James         Dirk
#[Out]# 28    13    James    Hoogvliet
#[Out]# 29    13    James         Lidl
#[Out]# ..   ...      ...          ...
#[Out]# 304  176    Amira         Lidl
#[Out]# 305  176    Amira         Coop
#[Out]# 306  176    Amira    Hoogvliet
#[Out]# 307  177    Eline         Coop
#[Out]# 308  177    Eline    Hoogvliet
#[Out]# 309  177    Eline  Albert Hein
#[Out]# 310  178     Elif         Coop
#[Out]# 311  178     Elif       Sligro
#[Out]# 312  179     Juul  Albert Hein
#[Out]# 313  179     Juul         Dirk
#[Out]# 314  179     Juul         Coop
#[Out]# 315  179     Juul         Lidl
#[Out]# 316  180    Merel         Coop
#[Out]# 317  180    Merel        Jumbo
#[Out]# 318  181     Liva         Coop
#[Out]# 319  181     Liva       Sligro
#[Out]# 320  182  Johanna    Hoogvliet
#[Out]# 321  182  Johanna       Sligro
#[Out]# 322  184    Wilko         Coop
#[Out]# 323  185     Nick        Jumbo
#[Out]# 324  186   Angela        Jumbo
#[Out]# 325  188     Pino        Jumbo
#[Out]# 326  189     Koen        Jumbo
#[Out]# 327  190   Kostas         Coop
#[Out]# 328  190   Kostas    Hoogvliet
#[Out]# 329  190   Kostas        Jumbo
#[Out]# 330  190   Kostas       Sligro
#[Out]# 331  190   Kostas  Albert Hein
#[Out]# 332  190   Kostas         Lidl
#[Out]# 333  190   Kostas         Dirk
#[Out]# 
#[Out]# [334 rows x 3 columns]
# Tue, 01 Dec 2020 17:43:02
query3_4 = '''

    SELECT  C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID 

'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem         Dirk
#[Out]# 2      1     Sem       Sligro
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem  Albert Hein
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas       Sligro
#[Out]# 10     2   Lucas         Coop
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn  Albert Hein
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn       Sligro
#[Out]# 16     4    Daan    Hoogvliet
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan         Coop
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan       Sligro
#[Out]# 21     4    Daan  Albert Hein
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Lidl
#[Out]# 24     5    Levi         Coop
#[Out]# 25     5    Levi         Coop
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi    Hoogvliet
#[Out]# 28     7    Bram       Sligro
#[Out]# 29     7    Bram         Lidl
#[Out]# ..   ...     ...          ...
#[Out]# 479  190  Kostas         Coop
#[Out]# 480  190  Kostas         Lidl
#[Out]# 481  190  Kostas         Lidl
#[Out]# 482  190  Kostas        Jumbo
#[Out]# 483  190  Kostas    Hoogvliet
#[Out]# 484  190  Kostas       Sligro
#[Out]# 485  190  Kostas    Hoogvliet
#[Out]# 486  190  Kostas  Albert Hein
#[Out]# 487  190  Kostas       Sligro
#[Out]# 488  190  Kostas         Coop
#[Out]# 489  190  Kostas  Albert Hein
#[Out]# 490  190  Kostas         Coop
#[Out]# 491  190  Kostas         Lidl
#[Out]# 492  190  Kostas         Coop
#[Out]# 493  190  Kostas    Hoogvliet
#[Out]# 494  190  Kostas    Hoogvliet
#[Out]# 495  190  Kostas       Sligro
#[Out]# 496  190  Kostas         Coop
#[Out]# 497  190  Kostas         Lidl
#[Out]# 498  190  Kostas         Coop
#[Out]# 499  190  Kostas         Dirk
#[Out]# 500  190  Kostas         Coop
#[Out]# 501  190  Kostas        Jumbo
#[Out]# 502  190  Kostas         Dirk
#[Out]# 503  190  Kostas         Dirk
#[Out]# 504  190  Kostas        Jumbo
#[Out]# 505  190  Kostas         Lidl
#[Out]# 506  190  Kostas         Lidl
#[Out]# 507  190  Kostas        Jumbo
#[Out]# 508  190  Kostas        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 17:46:43
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID AND sName = 'Sligro'

'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID    cName   sName
#[Out]# 0     0     Noah  Sligro
#[Out]# 1     1      Sem  Sligro
#[Out]# 2     2    Lucas  Sligro
#[Out]# 3     3     Finn  Sligro
#[Out]# 4     4     Daan  Sligro
#[Out]# 5     7     Bram  Sligro
#[Out]# 6     7     Bram  Sligro
#[Out]# 7    13    James  Sligro
#[Out]# 8    16   Julian  Sligro
#[Out]# 9    16   Julian  Sligro
#[Out]# 10   18     Hugo  Sligro
#[Out]# 11   19     Lars  Sligro
#[Out]# 12   20     Gijs  Sligro
#[Out]# 13   22     Mats  Sligro
#[Out]# 14   27      Tim  Sligro
#[Out]# 15   29    Ruben  Sligro
#[Out]# 16   30     Teun  Sligro
#[Out]# 17   31  Olivier  Sligro
#[Out]# 18   31  Olivier  Sligro
#[Out]# 19   33     Sven  Sligro
#[Out]# 20   33     Sven  Sligro
#[Out]# 21   41    Quinn  Sligro
#[Out]# 22   43      Tom  Sligro
#[Out]# 23   44    Jason  Sligro
#[Out]# 24   44    Jason  Sligro
#[Out]# 25   51     Ties  Sligro
#[Out]# 26   52   Willem  Sligro
#[Out]# 27   52   Willem  Sligro
#[Out]# 28   57   Nathan  Sligro
#[Out]# 29   58    Jurre  Sligro
#[Out]# ..  ...      ...     ...
#[Out]# 56  109     Lynn  Sligro
#[Out]# 57  116    Lieke  Sligro
#[Out]# 58  124    Sofie  Sligro
#[Out]# 59  126     Lina  Sligro
#[Out]# 60  127    Emily  Sligro
#[Out]# 61  134     Ella  Sligro
#[Out]# 62  137     Lena  Sligro
#[Out]# 63  152     Anne  Sligro
#[Out]# 64  161    Floor  Sligro
#[Out]# 65  161    Floor  Sligro
#[Out]# 66  162    Elena  Sligro
#[Out]# 67  167   Veerle  Sligro
#[Out]# 68  167   Veerle  Sligro
#[Out]# 69  167   Veerle  Sligro
#[Out]# 70  167   Veerle  Sligro
#[Out]# 71  169     Lily  Sligro
#[Out]# 72  175      Sam  Sligro
#[Out]# 73  178     Elif  Sligro
#[Out]# 74  181     Liva  Sligro
#[Out]# 75  182  Johanna  Sligro
#[Out]# 76  182  Johanna  Sligro
#[Out]# 77  190   Kostas  Sligro
#[Out]# 78  190   Kostas  Sligro
#[Out]# 79  190   Kostas  Sligro
#[Out]# 80  190   Kostas  Sligro
#[Out]# 81  190   Kostas  Sligro
#[Out]# 82  190   Kostas  Sligro
#[Out]# 83  190   Kostas  Sligro
#[Out]# 84  190   Kostas  Sligro
#[Out]# 85  190   Kostas  Sligro
#[Out]# 
#[Out]# [86 rows x 3 columns]
# Tue, 01 Dec 2020 17:47:08
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID 

'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem         Dirk
#[Out]# 2      1     Sem       Sligro
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem  Albert Hein
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas       Sligro
#[Out]# 10     2   Lucas         Coop
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn  Albert Hein
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn       Sligro
#[Out]# 16     4    Daan    Hoogvliet
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan         Coop
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan       Sligro
#[Out]# 21     4    Daan  Albert Hein
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Lidl
#[Out]# 24     5    Levi         Coop
#[Out]# 25     5    Levi         Coop
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi    Hoogvliet
#[Out]# 28     7    Bram       Sligro
#[Out]# 29     7    Bram         Lidl
#[Out]# ..   ...     ...          ...
#[Out]# 479  190  Kostas         Coop
#[Out]# 480  190  Kostas         Lidl
#[Out]# 481  190  Kostas         Lidl
#[Out]# 482  190  Kostas        Jumbo
#[Out]# 483  190  Kostas    Hoogvliet
#[Out]# 484  190  Kostas       Sligro
#[Out]# 485  190  Kostas    Hoogvliet
#[Out]# 486  190  Kostas  Albert Hein
#[Out]# 487  190  Kostas       Sligro
#[Out]# 488  190  Kostas         Coop
#[Out]# 489  190  Kostas  Albert Hein
#[Out]# 490  190  Kostas         Coop
#[Out]# 491  190  Kostas         Lidl
#[Out]# 492  190  Kostas         Coop
#[Out]# 493  190  Kostas    Hoogvliet
#[Out]# 494  190  Kostas    Hoogvliet
#[Out]# 495  190  Kostas       Sligro
#[Out]# 496  190  Kostas         Coop
#[Out]# 497  190  Kostas         Lidl
#[Out]# 498  190  Kostas         Coop
#[Out]# 499  190  Kostas         Dirk
#[Out]# 500  190  Kostas         Coop
#[Out]# 501  190  Kostas        Jumbo
#[Out]# 502  190  Kostas         Dirk
#[Out]# 503  190  Kostas         Dirk
#[Out]# 504  190  Kostas        Jumbo
#[Out]# 505  190  Kostas         Lidl
#[Out]# 506  190  Kostas         Lidl
#[Out]# 507  190  Kostas        Jumbo
#[Out]# 508  190  Kostas        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 17:49:06
query3_3 = '''

        
    SELECT DISTINCT C.cID,C.cName FROM Customer AS C
    EXCEPT
    SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName like '%Sligro%'


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      5      Levi
#[Out]# 1      6     Milan
#[Out]# 2      8      Liam
#[Out]# 3      9    Thomas
#[Out]# 4     10       Sam
#[Out]# 5     11     Thijs
#[Out]# 6     12      Adam
#[Out]# 7     14       Max
#[Out]# 8     15      Noud
#[Out]# 9     17       Dex
#[Out]# 10    21  Benjamin
#[Out]# 11    23       Jan
#[Out]# 12    24      Luca
#[Out]# 13    25     Mason
#[Out]# 14    26    Jayden
#[Out]# 15    28      Siem
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    35     Stijn
#[Out]# 19    36      Boaz
#[Out]# 20    37      Guus
#[Out]# 21    38    Floris
#[Out]# 22    39      Jack
#[Out]# 23    40      Jens
#[Out]# 24    42      Tijn
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 101  150     Julie
#[Out]# 102  151      Jill
#[Out]# 103  153     Amber
#[Out]# 104  154    Benthe
#[Out]# 105  155     Linde
#[Out]# 106  156      Luna
#[Out]# 107  157      Puck
#[Out]# 108  158      Rosa
#[Out]# 109  159     Fenne
#[Out]# 110  160      Lara
#[Out]# 111  163      Cato
#[Out]# 112  164       Evy
#[Out]# 113  165     Hanna
#[Out]# 114  166   Rosalie
#[Out]# 115  168      Kiki
#[Out]# 116  170      Iris
#[Out]# 117  171     Tessa
#[Out]# 118  172      Lana
#[Out]# 119  173     Livia
#[Out]# 120  174      Romy
#[Out]# 121  176     Amira
#[Out]# 122  177     Eline
#[Out]# 123  179      Juul
#[Out]# 124  180     Merel
#[Out]# 125  183     Nikki
#[Out]# 126  184     Wilko
#[Out]# 127  185      Nick
#[Out]# 128  186    Angela
#[Out]# 129  188      Pino
#[Out]# 130  189      Koen
#[Out]# 
#[Out]# [131 rows x 2 columns]
# Tue, 01 Dec 2020 17:49:15
query3_3 = '''

        
    SELECT DISTINCT C.cID,C.cName FROM Customer AS C
    EXCEPT
    SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName like '%Coop%'


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 17:51:46
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    

'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 17:51:58
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID 

'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem         Dirk
#[Out]# 2      1     Sem       Sligro
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem  Albert Hein
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas       Sligro
#[Out]# 10     2   Lucas         Coop
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn  Albert Hein
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn       Sligro
#[Out]# 16     4    Daan    Hoogvliet
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan         Coop
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan       Sligro
#[Out]# 21     4    Daan  Albert Hein
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Lidl
#[Out]# 24     5    Levi         Coop
#[Out]# 25     5    Levi         Coop
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi    Hoogvliet
#[Out]# 28     7    Bram       Sligro
#[Out]# 29     7    Bram         Lidl
#[Out]# ..   ...     ...          ...
#[Out]# 479  190  Kostas         Coop
#[Out]# 480  190  Kostas         Lidl
#[Out]# 481  190  Kostas         Lidl
#[Out]# 482  190  Kostas        Jumbo
#[Out]# 483  190  Kostas    Hoogvliet
#[Out]# 484  190  Kostas       Sligro
#[Out]# 485  190  Kostas    Hoogvliet
#[Out]# 486  190  Kostas  Albert Hein
#[Out]# 487  190  Kostas       Sligro
#[Out]# 488  190  Kostas         Coop
#[Out]# 489  190  Kostas  Albert Hein
#[Out]# 490  190  Kostas         Coop
#[Out]# 491  190  Kostas         Lidl
#[Out]# 492  190  Kostas         Coop
#[Out]# 493  190  Kostas    Hoogvliet
#[Out]# 494  190  Kostas    Hoogvliet
#[Out]# 495  190  Kostas       Sligro
#[Out]# 496  190  Kostas         Coop
#[Out]# 497  190  Kostas         Lidl
#[Out]# 498  190  Kostas         Coop
#[Out]# 499  190  Kostas         Dirk
#[Out]# 500  190  Kostas         Coop
#[Out]# 501  190  Kostas        Jumbo
#[Out]# 502  190  Kostas         Dirk
#[Out]# 503  190  Kostas         Dirk
#[Out]# 504  190  Kostas        Jumbo
#[Out]# 505  190  Kostas         Lidl
#[Out]# 506  190  Kostas         Lidl
#[Out]# 507  190  Kostas        Jumbo
#[Out]# 508  190  Kostas        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 17:52:56
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID AND NOT EXISTS 
                                            (SELECT sName FROM store AS S1 
                                                WHERE sName NOT LIKE '%Sligro%')

'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 17:53:06
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID AND NOT EXISTS 
                                            (SELECT sName FROM store AS S1 
                                                WHERE sName NOT LIKE '%sligro%')

'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 17:53:46
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE  NOT EXISTS 
                                            (SELECT sName FROM store AS S1 
                                                WHERE sName NOT LIKE '%sligro%')

'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 17:53:53
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE  NOT EXISTS 
                                            (SELECT sName FROM store AS S1 
                                                WHERE sName NOT LIKE '%Coop%')

'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 17:54:00
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem         Dirk
#[Out]# 2      1     Sem       Sligro
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem  Albert Hein
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas       Sligro
#[Out]# 10     2   Lucas         Coop
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn  Albert Hein
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn       Sligro
#[Out]# 16     4    Daan    Hoogvliet
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan         Coop
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan       Sligro
#[Out]# 21     4    Daan  Albert Hein
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Lidl
#[Out]# 24     5    Levi         Coop
#[Out]# 25     5    Levi         Coop
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi    Hoogvliet
#[Out]# 28     7    Bram       Sligro
#[Out]# 29     7    Bram         Lidl
#[Out]# ..   ...     ...          ...
#[Out]# 479  190  Kostas         Coop
#[Out]# 480  190  Kostas         Lidl
#[Out]# 481  190  Kostas         Lidl
#[Out]# 482  190  Kostas        Jumbo
#[Out]# 483  190  Kostas    Hoogvliet
#[Out]# 484  190  Kostas       Sligro
#[Out]# 485  190  Kostas    Hoogvliet
#[Out]# 486  190  Kostas  Albert Hein
#[Out]# 487  190  Kostas       Sligro
#[Out]# 488  190  Kostas         Coop
#[Out]# 489  190  Kostas  Albert Hein
#[Out]# 490  190  Kostas         Coop
#[Out]# 491  190  Kostas         Lidl
#[Out]# 492  190  Kostas         Coop
#[Out]# 493  190  Kostas    Hoogvliet
#[Out]# 494  190  Kostas    Hoogvliet
#[Out]# 495  190  Kostas       Sligro
#[Out]# 496  190  Kostas         Coop
#[Out]# 497  190  Kostas         Lidl
#[Out]# 498  190  Kostas         Coop
#[Out]# 499  190  Kostas         Dirk
#[Out]# 500  190  Kostas         Coop
#[Out]# 501  190  Kostas        Jumbo
#[Out]# 502  190  Kostas         Dirk
#[Out]# 503  190  Kostas         Dirk
#[Out]# 504  190  Kostas        Jumbo
#[Out]# 505  190  Kostas         Lidl
#[Out]# 506  190  Kostas         Lidl
#[Out]# 507  190  Kostas        Jumbo
#[Out]# 508  190  Kostas        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 17:57:07
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE '%Sligro
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 17:57:13
query3_4 = '''

    SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE '%Sligro%'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      1     Sem         Dirk
#[Out]# 1      1     Sem    Hoogvliet
#[Out]# 2      1     Sem  Albert Hein
#[Out]# 3      1     Sem         Lidl
#[Out]# 4      1     Sem         Lidl
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      2   Lucas         Lidl
#[Out]# 7      2   Lucas         Coop
#[Out]# 8      2   Lucas         Coop
#[Out]# 9      2   Lucas         Coop
#[Out]# 10     3    Finn  Albert Hein
#[Out]# 11     3    Finn         Dirk
#[Out]# 12     4    Daan    Hoogvliet
#[Out]# 13     4    Daan        Jumbo
#[Out]# 14     4    Daan         Coop
#[Out]# 15     4    Daan         Coop
#[Out]# 16     4    Daan  Albert Hein
#[Out]# 17     5    Levi    Hoogvliet
#[Out]# 18     5    Levi         Lidl
#[Out]# 19     5    Levi         Coop
#[Out]# 20     5    Levi         Coop
#[Out]# 21     5    Levi         Coop
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     7    Bram         Lidl
#[Out]# 24     7    Bram  Albert Hein
#[Out]# 25     7    Bram  Albert Hein
#[Out]# 26     7    Bram    Hoogvliet
#[Out]# 27     8    Liam         Coop
#[Out]# 28     8    Liam         Coop
#[Out]# 29    10     Sam         Coop
#[Out]# ..   ...     ...          ...
#[Out]# 393  190  Kostas         Coop
#[Out]# 394  190  Kostas  Albert Hein
#[Out]# 395  190  Kostas         Dirk
#[Out]# 396  190  Kostas         Coop
#[Out]# 397  190  Kostas         Lidl
#[Out]# 398  190  Kostas         Lidl
#[Out]# 399  190  Kostas        Jumbo
#[Out]# 400  190  Kostas    Hoogvliet
#[Out]# 401  190  Kostas    Hoogvliet
#[Out]# 402  190  Kostas  Albert Hein
#[Out]# 403  190  Kostas         Coop
#[Out]# 404  190  Kostas  Albert Hein
#[Out]# 405  190  Kostas         Coop
#[Out]# 406  190  Kostas         Lidl
#[Out]# 407  190  Kostas         Coop
#[Out]# 408  190  Kostas    Hoogvliet
#[Out]# 409  190  Kostas    Hoogvliet
#[Out]# 410  190  Kostas         Coop
#[Out]# 411  190  Kostas         Lidl
#[Out]# 412  190  Kostas         Coop
#[Out]# 413  190  Kostas         Dirk
#[Out]# 414  190  Kostas         Coop
#[Out]# 415  190  Kostas        Jumbo
#[Out]# 416  190  Kostas         Dirk
#[Out]# 417  190  Kostas         Dirk
#[Out]# 418  190  Kostas        Jumbo
#[Out]# 419  190  Kostas         Lidl
#[Out]# 420  190  Kostas         Lidl
#[Out]# 421  190  Kostas        Jumbo
#[Out]# 422  190  Kostas        Jumbo
#[Out]# 
#[Out]# [423 rows x 3 columns]
# Tue, 01 Dec 2020 17:58:09
query3_4 = '''

    SELECT DISTINCT C.cID,C.cName ROM Customer AS C, purchase AS P, store AS S ERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE '%Sligro%'
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 17:58:41
query3_4 = '''

    SELECT DISTINCT C.cID,C.cName, 
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE '%Sligro%'
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 17:58:50
query3_4 = '''

    SELECT DISTINCT C.cID,C.cName 
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE '%Sligro%'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      4      Daan
#[Out]# 4      5      Levi
#[Out]# 5      7      Bram
#[Out]# 6      8      Liam
#[Out]# 7     10       Sam
#[Out]# 8     11     Thijs
#[Out]# 9     13     James
#[Out]# 10    15      Noud
#[Out]# 11    16    Julian
#[Out]# 12    17       Dex
#[Out]# 13    18      Hugo
#[Out]# 14    19      Lars
#[Out]# 15    20      Gijs
#[Out]# 16    21  Benjamin
#[Out]# 17    22      Mats
#[Out]# 18    24      Luca
#[Out]# 19    25     Mason
#[Out]# 20    26    Jayden
#[Out]# 21    27       Tim
#[Out]# 22    28      Siem
#[Out]# 23    29     Ruben
#[Out]# 24    30      Teun
#[Out]# 25    33      Sven
#[Out]# 26    34     David
#[Out]# 27    35     Stijn
#[Out]# 28    37      Guus
#[Out]# 29    38    Floris
#[Out]# ..   ...       ...
#[Out]# 96   147    Isabel
#[Out]# 97   149     Lizzy
#[Out]# 98   151      Jill
#[Out]# 99   152      Anne
#[Out]# 100  157      Puck
#[Out]# 101  159     Fenne
#[Out]# 102  161     Floor
#[Out]# 103  162     Elena
#[Out]# 104  163      Cato
#[Out]# 105  165     Hanna
#[Out]# 106  167    Veerle
#[Out]# 107  168      Kiki
#[Out]# 108  169      Lily
#[Out]# 109  170      Iris
#[Out]# 110  171     Tessa
#[Out]# 111  172      Lana
#[Out]# 112  175       Sam
#[Out]# 113  176     Amira
#[Out]# 114  177     Eline
#[Out]# 115  178      Elif
#[Out]# 116  179      Juul
#[Out]# 117  180     Merel
#[Out]# 118  181      Liva
#[Out]# 119  182   Johanna
#[Out]# 120  184     Wilko
#[Out]# 121  185      Nick
#[Out]# 122  186    Angela
#[Out]# 123  188      Pino
#[Out]# 124  189      Koen
#[Out]# 125  190    Kostas
#[Out]# 
#[Out]# [126 rows x 2 columns]
# Tue, 01 Dec 2020 17:59:03
query3_4 = '''

   SELECT C.cID,C.cName, sName
    FROM Customer AS C, purchase AS P, store AS S 
    WHERE P.cId = C.cID AND P.sID = S.sID AND sName = 'Sligro'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID    cName   sName
#[Out]# 0     0     Noah  Sligro
#[Out]# 1     1      Sem  Sligro
#[Out]# 2     2    Lucas  Sligro
#[Out]# 3     3     Finn  Sligro
#[Out]# 4     4     Daan  Sligro
#[Out]# 5     7     Bram  Sligro
#[Out]# 6     7     Bram  Sligro
#[Out]# 7    13    James  Sligro
#[Out]# 8    16   Julian  Sligro
#[Out]# 9    16   Julian  Sligro
#[Out]# 10   18     Hugo  Sligro
#[Out]# 11   19     Lars  Sligro
#[Out]# 12   20     Gijs  Sligro
#[Out]# 13   22     Mats  Sligro
#[Out]# 14   27      Tim  Sligro
#[Out]# 15   29    Ruben  Sligro
#[Out]# 16   30     Teun  Sligro
#[Out]# 17   31  Olivier  Sligro
#[Out]# 18   31  Olivier  Sligro
#[Out]# 19   33     Sven  Sligro
#[Out]# 20   33     Sven  Sligro
#[Out]# 21   41    Quinn  Sligro
#[Out]# 22   43      Tom  Sligro
#[Out]# 23   44    Jason  Sligro
#[Out]# 24   44    Jason  Sligro
#[Out]# 25   51     Ties  Sligro
#[Out]# 26   52   Willem  Sligro
#[Out]# 27   52   Willem  Sligro
#[Out]# 28   57   Nathan  Sligro
#[Out]# 29   58    Jurre  Sligro
#[Out]# ..  ...      ...     ...
#[Out]# 56  109     Lynn  Sligro
#[Out]# 57  116    Lieke  Sligro
#[Out]# 58  124    Sofie  Sligro
#[Out]# 59  126     Lina  Sligro
#[Out]# 60  127    Emily  Sligro
#[Out]# 61  134     Ella  Sligro
#[Out]# 62  137     Lena  Sligro
#[Out]# 63  152     Anne  Sligro
#[Out]# 64  161    Floor  Sligro
#[Out]# 65  161    Floor  Sligro
#[Out]# 66  162    Elena  Sligro
#[Out]# 67  167   Veerle  Sligro
#[Out]# 68  167   Veerle  Sligro
#[Out]# 69  167   Veerle  Sligro
#[Out]# 70  167   Veerle  Sligro
#[Out]# 71  169     Lily  Sligro
#[Out]# 72  175      Sam  Sligro
#[Out]# 73  178     Elif  Sligro
#[Out]# 74  181     Liva  Sligro
#[Out]# 75  182  Johanna  Sligro
#[Out]# 76  182  Johanna  Sligro
#[Out]# 77  190   Kostas  Sligro
#[Out]# 78  190   Kostas  Sligro
#[Out]# 79  190   Kostas  Sligro
#[Out]# 80  190   Kostas  Sligro
#[Out]# 81  190   Kostas  Sligro
#[Out]# 82  190   Kostas  Sligro
#[Out]# 83  190   Kostas  Sligro
#[Out]# 84  190   Kostas  Sligro
#[Out]# 85  190   Kostas  Sligro
#[Out]# 
#[Out]# [86 rows x 3 columns]
# Tue, 01 Dec 2020 18:00:00
query3_4 = '''

   SELECT DISTINCT C.cID,C.cName, sName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND sName = 'Sligro'
   EXCEPT
   SELECT DISTINCT C.cID FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE '%Sligro%'
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 18:00:30
query3_4 = '''

   SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND sName = 'Sligro'
   EXCEPT
   SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE '%Sligro%'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID    cName
#[Out]# 0    0     Noah
#[Out]# 1   31  Olivier
#[Out]# 2   64     Stan
#[Out]# 3   84   Casper
#[Out]# 4   90     Lenn
#[Out]# 5  137     Lena
# Tue, 01 Dec 2020 18:00:41
query3_4 = '''

   SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND sName = 'Sligro'
   EXCEPT
   SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE 'Sligro'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID    cName
#[Out]# 0    0     Noah
#[Out]# 1   31  Olivier
#[Out]# 2   64     Stan
#[Out]# 3   84   Casper
#[Out]# 4   90     Lenn
#[Out]# 5  137     Lena
# Tue, 01 Dec 2020 18:01:25
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    
    FROM Customer AS C, purchase AS P
    
    WHERE P.cID = C.cID AND P.sId = S.sID

'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 18:01:33
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sId = S.sID

'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName  sID
#[Out]# 0      0    Noah    3
#[Out]# 1      1     Sem   23
#[Out]# 2      1     Sem    3
#[Out]# 3      1     Sem   17
#[Out]# 4      1     Sem   32
#[Out]# 5      1     Sem   16
#[Out]# 6      1     Sem   46
#[Out]# 7      1     Sem   36
#[Out]# 8      2   Lucas   12
#[Out]# 9      2   Lucas   39
#[Out]# 10     2   Lucas   13
#[Out]# 11     2   Lucas   51
#[Out]# 12     2   Lucas   47
#[Out]# 13     3    Finn   44
#[Out]# 14     3    Finn   30
#[Out]# 15     3    Finn   29
#[Out]# 16     4    Daan   17
#[Out]# 17     4    Daan   10
#[Out]# 18     4    Daan   53
#[Out]# 19     4    Daan   21
#[Out]# 20     4    Daan    7
#[Out]# 21     4    Daan   44
#[Out]# 22     5    Levi    4
#[Out]# 23     5    Levi   36
#[Out]# 24     5    Levi   55
#[Out]# 25     5    Levi   51
#[Out]# 26     5    Levi    6
#[Out]# 27     5    Levi   17
#[Out]# 28     7    Bram    3
#[Out]# 29     7    Bram   12
#[Out]# ..   ...     ...  ...
#[Out]# 479  190  Kostas   34
#[Out]# 480  190  Kostas   35
#[Out]# 481  190  Kostas   36
#[Out]# 482  190  Kostas   37
#[Out]# 483  190  Kostas   38
#[Out]# 484  190  Kostas   39
#[Out]# 485  190  Kostas   40
#[Out]# 486  190  Kostas   41
#[Out]# 487  190  Kostas   42
#[Out]# 488  190  Kostas   43
#[Out]# 489  190  Kostas   44
#[Out]# 490  190  Kostas   45
#[Out]# 491  190  Kostas   46
#[Out]# 492  190  Kostas   47
#[Out]# 493  190  Kostas   48
#[Out]# 494  190  Kostas   49
#[Out]# 495  190  Kostas   50
#[Out]# 496  190  Kostas   51
#[Out]# 497  190  Kostas   52
#[Out]# 498  190  Kostas   53
#[Out]# 499  190  Kostas   54
#[Out]# 500  190  Kostas   55
#[Out]# 501  190  Kostas   56
#[Out]# 502  190  Kostas   57
#[Out]# 503  190  Kostas   58
#[Out]# 504  190  Kostas   59
#[Out]# 505  190  Kostas   60
#[Out]# 506  190  Kostas   61
#[Out]# 507  190  Kostas   62
#[Out]# 508  190  Kostas   63
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 18:01:45
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    ,S.sName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sId = S.sID

'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 18:02:03
query3_4 = '''
SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND sName = 'Sligro'
   EXCEPT
   SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE 'Sligro'

'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID    cName
#[Out]# 0    0     Noah
#[Out]# 1   31  Olivier
#[Out]# 2   64     Stan
#[Out]# 3   84   Casper
#[Out]# 4   90     Lenn
#[Out]# 5  137     Lena
# Tue, 01 Dec 2020 18:02:14
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    ,S.sName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sId = S.sID

'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName  sID        sName
#[Out]# 0      0    Noah    3       Sligro
#[Out]# 1      1     Sem   23         Dirk
#[Out]# 2      1     Sem    3       Sligro
#[Out]# 3      1     Sem   17    Hoogvliet
#[Out]# 4      1     Sem   32  Albert Hein
#[Out]# 5      1     Sem   16         Lidl
#[Out]# 6      1     Sem   46         Lidl
#[Out]# 7      1     Sem   36         Lidl
#[Out]# 8      2   Lucas   12         Lidl
#[Out]# 9      2   Lucas   39       Sligro
#[Out]# 10     2   Lucas   13         Coop
#[Out]# 11     2   Lucas   51         Coop
#[Out]# 12     2   Lucas   47         Coop
#[Out]# 13     3    Finn   44  Albert Hein
#[Out]# 14     3    Finn   30         Dirk
#[Out]# 15     3    Finn   29       Sligro
#[Out]# 16     4    Daan   17    Hoogvliet
#[Out]# 17     4    Daan   10        Jumbo
#[Out]# 18     4    Daan   53         Coop
#[Out]# 19     4    Daan   21         Coop
#[Out]# 20     4    Daan    7       Sligro
#[Out]# 21     4    Daan   44  Albert Hein
#[Out]# 22     5    Levi    4    Hoogvliet
#[Out]# 23     5    Levi   36         Lidl
#[Out]# 24     5    Levi   55         Coop
#[Out]# 25     5    Levi   51         Coop
#[Out]# 26     5    Levi    6         Coop
#[Out]# 27     5    Levi   17    Hoogvliet
#[Out]# 28     7    Bram    3       Sligro
#[Out]# 29     7    Bram   12         Lidl
#[Out]# ..   ...     ...  ...          ...
#[Out]# 479  190  Kostas   34         Coop
#[Out]# 480  190  Kostas   35         Lidl
#[Out]# 481  190  Kostas   36         Lidl
#[Out]# 482  190  Kostas   37        Jumbo
#[Out]# 483  190  Kostas   38    Hoogvliet
#[Out]# 484  190  Kostas   39       Sligro
#[Out]# 485  190  Kostas   40    Hoogvliet
#[Out]# 486  190  Kostas   41  Albert Hein
#[Out]# 487  190  Kostas   42       Sligro
#[Out]# 488  190  Kostas   43         Coop
#[Out]# 489  190  Kostas   44  Albert Hein
#[Out]# 490  190  Kostas   45         Coop
#[Out]# 491  190  Kostas   46         Lidl
#[Out]# 492  190  Kostas   47         Coop
#[Out]# 493  190  Kostas   48    Hoogvliet
#[Out]# 494  190  Kostas   49    Hoogvliet
#[Out]# 495  190  Kostas   50       Sligro
#[Out]# 496  190  Kostas   51         Coop
#[Out]# 497  190  Kostas   52         Lidl
#[Out]# 498  190  Kostas   53         Coop
#[Out]# 499  190  Kostas   54         Dirk
#[Out]# 500  190  Kostas   55         Coop
#[Out]# 501  190  Kostas   56        Jumbo
#[Out]# 502  190  Kostas   57         Dirk
#[Out]# 503  190  Kostas   58         Dirk
#[Out]# 504  190  Kostas   59        Jumbo
#[Out]# 505  190  Kostas   60         Lidl
#[Out]# 506  190  Kostas   61         Lidl
#[Out]# 507  190  Kostas   62        Jumbo
#[Out]# 508  190  Kostas   63        Jumbo
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 01 Dec 2020 18:02:39
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    ,S.sName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sId = S.sID AND cID IN (0,31,64,84,90,137)

'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 18:02:47
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    ,S.sName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sId = S.sID AND C.cID IN (0,31,64,84,90,137)

'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID    cName  sID   sName
#[Out]# 0    0     Noah    3  Sligro
#[Out]# 1   31  Olivier   42  Sligro
#[Out]# 2   31  Olivier   39  Sligro
#[Out]# 3   64     Stan   29  Sligro
#[Out]# 4   64     Stan    5  Sligro
#[Out]# 5   84   Casper   18  Sligro
#[Out]# 6   84   Casper   18  Sligro
#[Out]# 7   90     Lenn    7  Sligro
#[Out]# 8  137     Lena   29  Sligro
# Tue, 01 Dec 2020 18:03:01
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    ,S.sName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sId = S.sID AND C.cID IN (0,31,64,84,90,137,6)

'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID    cName  sID   sName
#[Out]# 0    0     Noah    3  Sligro
#[Out]# 1   31  Olivier   42  Sligro
#[Out]# 2   31  Olivier   39  Sligro
#[Out]# 3   64     Stan   29  Sligro
#[Out]# 4   64     Stan    5  Sligro
#[Out]# 5   84   Casper   18  Sligro
#[Out]# 6   84   Casper   18  Sligro
#[Out]# 7   90     Lenn    7  Sligro
#[Out]# 8  137     Lena   29  Sligro
# Tue, 01 Dec 2020 18:03:04
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    ,S.sName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sId = S.sID AND C.cID IN (0,31,64,84,90,137,6)

'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID    cName  sID   sName
#[Out]# 0    0     Noah    3  Sligro
#[Out]# 1   31  Olivier   42  Sligro
#[Out]# 2   31  Olivier   39  Sligro
#[Out]# 3   64     Stan   29  Sligro
#[Out]# 4   64     Stan    5  Sligro
#[Out]# 5   84   Casper   18  Sligro
#[Out]# 6   84   Casper   18  Sligro
#[Out]# 7   90     Lenn    7  Sligro
#[Out]# 8  137     Lena   29  Sligro
# Tue, 01 Dec 2020 18:03:08
query3_4 = '''
    SELECT 
    C.cID
    ,C.cName
    ,P.sID
    ,S.sName
    
    FROM Customer AS C, purchase AS P, store AS S
    
    WHERE P.cID = C.cID AND P.sId = S.sID AND C.cID IN (0,31,64,84,90,137,33)

'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID    cName  sID      sName
#[Out]# 0     0     Noah    3     Sligro
#[Out]# 1    31  Olivier   42     Sligro
#[Out]# 2    31  Olivier   39     Sligro
#[Out]# 3    33     Sven   39     Sligro
#[Out]# 4    33     Sven   57       Dirk
#[Out]# 5    33     Sven   54       Dirk
#[Out]# 6    33     Sven   17  Hoogvliet
#[Out]# 7    33     Sven   36       Lidl
#[Out]# 8    33     Sven   23       Dirk
#[Out]# 9    33     Sven   34       Coop
#[Out]# 10   33     Sven   26  Hoogvliet
#[Out]# 11   33     Sven   29     Sligro
#[Out]# 12   64     Stan   29     Sligro
#[Out]# 13   64     Stan    5     Sligro
#[Out]# 14   84   Casper   18     Sligro
#[Out]# 15   84   Casper   18     Sligro
#[Out]# 16   90     Lenn    7     Sligro
#[Out]# 17  137     Lena   29     Sligro
# Tue, 01 Dec 2020 18:03:31
query3_4 = '''
   SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND sName = 'Sligro'
   EXCEPT
   SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName NOT LIKE 'Sligro'

'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID    cName
#[Out]# 0    0     Noah
#[Out]# 1   31  Olivier
#[Out]# 2   64     Stan
#[Out]# 3   84   Casper
#[Out]# 4   90     Lenn
#[Out]# 5  137     Lena
# Tue, 01 Dec 2020 18:09:45
query3_3 = '''

        
    SELECT DISTINCT C.cID,C.cName FROM Customer AS C
    EXCEPT
    SELECT DISTINCT C.cID,C.cName FROM Customer AS C, purchase AS P, store AS S WHERE P.cId = C.cID AND P.sID = S.sID AND S.sName like 'Coop'


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 18:11:42
query3_2 = ''' 

SELECT c.cID, c.cName, p.pID, p.pName

FROM customer c, product p

WHERE (c.cID, p.pID) NOT IN (

               SELECT pu.cID, pu.pID

               FROM purchase pu

)



'''

pd.read_sql_query(query3_2, conn)


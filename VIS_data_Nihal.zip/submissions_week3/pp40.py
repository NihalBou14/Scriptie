# IPython log file

# Mon, 30 Nov 2020 16:21:56
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 16:22:49
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7f3b14e761f0>
# Mon, 30 Nov 2020 16:23:34
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Mon, 30 Nov 2020 16:26:25
query3_2 = '''
    SELECT cName, cID
    FROM customer
'''
# Mon, 30 Nov 2020 16:26:26
vis.visualize(query3_2, schema)
# Mon, 30 Nov 2020 16:26:32
pd.read_sql_query(query3_2, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 16:27:13
query3_2 = '''
    SELECT cName, cID
    FROM customer, shoppinglist, purchase
'''
# Mon, 30 Nov 2020 16:27:15
pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 16:27:40
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
'''
# Mon, 30 Nov 2020 16:27:42
pd.read_sql_query(query3_2, conn)

# IPython log file

# Mon, 30 Nov 2020 16:33:49
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 16:33:54
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 16:33:57
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 16:34:18
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer c
'''
# Mon, 30 Nov 2020 16:34:20
pd.read_sql_query(query3_2, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 16:34:27
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer c, shoppinglist AS s, purchase AS p
'''
# Mon, 30 Nov 2020 16:34:29
pd.read_sql_query(query3_2, conn)

# IPython log file

# Mon, 30 Nov 2020 16:34:52
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 16:35:05
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer c, shoppinglist s, purchase p
'''
# Mon, 30 Nov 2020 16:35:06
pd.read_sql_query(query3_2, conn)

# IPython log file

# Mon, 30 Nov 2020 16:36:38
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 16:36:43
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Mon, 30 Nov 2020 16:41:47
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT *
    FROM shoppinglist, purchase p
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#         cID  pID  quantity        date  tID  cID  sID  pID        date  \
#[Out]# 0         1   14         2  2018-08-20    0    0    3   10  2018-08-22   
#[Out]# 1         1   14         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 2         1   14         2  2018-08-20    2    1    3   16  2018-08-20   
#[Out]# 3         1   14         2  2018-08-20    3    1   17    9  2018-08-20   
#[Out]# 4         1   14         2  2018-08-20    4    1   32   25  2018-08-20   
#[Out]# ...     ...  ...       ...         ...  ...  ...  ...  ...         ...   
#[Out]# 250423  183   25         4  2018-08-22  843  190   59   17  2018-08-26   
#[Out]# 250424  183   25         4  2018-08-22  844  190   60    5  2018-08-27   
#[Out]# 250425  183   25         4  2018-08-22  845  190   61   19  2018-08-23   
#[Out]# 250426  183   25         4  2018-08-22  846  190   62    9  2018-08-16   
#[Out]# 250427  183   25         4  2018-08-22  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#         quantity  price  
#[Out]# 0              1   0.45  
#[Out]# 1              2   4.65  
#[Out]# 2              3   1.60  
#[Out]# 3              2   1.25  
#[Out]# 4              4   3.95  
#[Out]# ...          ...    ...  
#[Out]# 250423         2   3.80  
#[Out]# 250424         6   4.35  
#[Out]# 250425         5   2.85  
#[Out]# 250426         2   3.15  
#[Out]# 250427         1   3.30  
#[Out]# 
#[Out]# [250428 rows x 11 columns]
# Mon, 30 Nov 2020 16:42:34
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT *
    FROM shoppinglist s, purchase p
    WHERE s.date == p.date
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#        cID  pID  quantity        date  tID  cID  sID  pID        date  \
#[Out]# 0        1   14         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 1        1   14         2  2018-08-20    2    1    3   16  2018-08-20   
#[Out]# 2        1   14         2  2018-08-20    3    1   17    9  2018-08-20   
#[Out]# 3        1   14         2  2018-08-20    4    1   32   25  2018-08-20   
#[Out]# 4        1   14         2  2018-08-20    5    1   16   26  2018-08-20   
#[Out]# ...    ...  ...       ...         ...  ...  ...  ...  ...         ...   
#[Out]# 19427  183   25         4  2018-08-22  795  190   11    9  2018-08-22   
#[Out]# 19428  183   25         4  2018-08-22  810  190   26   21  2018-08-22   
#[Out]# 19429  183   25         4  2018-08-22  826  190   42   19  2018-08-22   
#[Out]# 19430  183   25         4  2018-08-22  834  190   50   21  2018-08-22   
#[Out]# 19431  183   25         4  2018-08-22  841  190   57   15  2018-08-22   
#[Out]# 
#[Out]#        quantity  price  
#[Out]# 0             2   4.65  
#[Out]# 1             3   1.60  
#[Out]# 2             2   1.25  
#[Out]# 3             4   3.95  
#[Out]# 4             4   2.75  
#[Out]# ...         ...    ...  
#[Out]# 19427         5   3.00  
#[Out]# 19428         7   0.60  
#[Out]# 19429         5   2.75  
#[Out]# 19430         6   4.05  
#[Out]# 19431         5   3.25  
#[Out]# 
#[Out]# [19432 rows x 11 columns]
# Mon, 30 Nov 2020 16:43:49
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT *
    FROM shoppinglist s, purchase p
    WHERE s.date == p.date AND p.date ~* "^2018%"
'''
pd.read_sql_query(query_sp_list, conn)
# Mon, 30 Nov 2020 16:44:21
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT *
    FROM shoppinglist s, purchase p
    WHERE s.date == p.date AND p.date LIKE "^2018"
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, pID, quantity, date, tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Mon, 30 Nov 2020 16:44:30
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT *
    FROM shoppinglist s, purchase p
    WHERE s.date == p.date AND (p.date LIKE "^2018")
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, pID, quantity, date, tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Mon, 30 Nov 2020 16:44:43
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT *
    FROM shoppinglist s, purchase p
    WHERE s.date == p.date AND (p.date LIKE "2018%")
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#        cID  pID  quantity        date  tID  cID  sID  pID        date  \
#[Out]# 0        5    6         9  2018-08-22    0    0    3   10  2018-08-22   
#[Out]# 1        5   28         6  2018-08-22    0    0    3   10  2018-08-22   
#[Out]# 2       59   22         1  2018-08-22    0    0    3   10  2018-08-22   
#[Out]# 3       64    9         7  2018-08-22    0    0    3   10  2018-08-22   
#[Out]# 4       72   10         5  2018-08-22    0    0    3   10  2018-08-22   
#[Out]# ...    ...  ...       ...         ...  ...  ...  ...  ...         ...   
#[Out]# 19427  162   14         3  2018-08-21  847  190   63   18  2018-08-21   
#[Out]# 19428  162   18         6  2018-08-21  847  190   63   18  2018-08-21   
#[Out]# 19429  167    0         8  2018-08-21  847  190   63   18  2018-08-21   
#[Out]# 19430  183   12         9  2018-08-21  847  190   63   18  2018-08-21   
#[Out]# 19431  183   18         8  2018-08-21  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#        quantity  price  
#[Out]# 0             1   0.45  
#[Out]# 1             1   0.45  
#[Out]# 2             1   0.45  
#[Out]# 3             1   0.45  
#[Out]# 4             1   0.45  
#[Out]# ...         ...    ...  
#[Out]# 19427         1   3.30  
#[Out]# 19428         1   3.30  
#[Out]# 19429         1   3.30  
#[Out]# 19430         1   3.30  
#[Out]# 19431         1   3.30  
#[Out]# 
#[Out]# [19432 rows x 11 columns]
# Mon, 30 Nov 2020 16:45:25
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT *
    FROM shoppinglist s, purchase p
    WHERE s.date == p.date 
        AND (p.date LIKE "2018%")
        AND s.cID == p.cID
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#      cID  pID  quantity        date  tID  cID  sID  pID        date  quantity  \
#[Out]# 0      1    9         2  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 1      1   11         8  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 2      1   14         2  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 3      1   16         3  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 4      1   21         6  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# ..   ...  ...       ...         ...  ...  ...  ...  ...         ...       ...   
#[Out]# 971  181   26         4  2018-08-24  469  181    6   26  2018-08-24         4   
#[Out]# 972  181    6         3  2018-08-24  470  181   45    6  2018-08-24         3   
#[Out]# 973  181   26         4  2018-08-24  470  181   45    6  2018-08-24         3   
#[Out]# 974  181    5         3  2018-08-27  471  181   27   21  2018-08-27         5   
#[Out]# 975  181   21         5  2018-08-27  471  181   27   21  2018-08-27         5   
#[Out]# 
#[Out]#      price  
#[Out]# 0     4.65  
#[Out]# 1     4.65  
#[Out]# 2     4.65  
#[Out]# 3     4.65  
#[Out]# 4     4.65  
#[Out]# ..     ...  
#[Out]# 971   2.70  
#[Out]# 972   0.90  
#[Out]# 973   0.90  
#[Out]# 974   2.00  
#[Out]# 975   2.00  
#[Out]# 
#[Out]# [976 rows x 11 columns]
# Mon, 30 Nov 2020 16:45:55
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT *
    FROM shoppinglist s, purchase p, customer c
    WHERE s.date == p.date 
        AND (p.date LIKE "2018%")
        AND s.cID == p.cID
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#         cID  pID  quantity        date  tID  cID  sID  pID        date  \
#[Out]# 0         1    9         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 1         1    9         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 2         1    9         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 3         1    9         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 4         1    9         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# ...     ...  ...       ...         ...  ...  ...  ...  ...         ...   
#[Out]# 185435  181   21         5  2018-08-27  471  181   27   21  2018-08-27   
#[Out]# 185436  181   21         5  2018-08-27  471  181   27   21  2018-08-27   
#[Out]# 185437  181   21         5  2018-08-27  471  181   27   21  2018-08-27   
#[Out]# 185438  181   21         5  2018-08-27  471  181   27   21  2018-08-27   
#[Out]# 185439  181   21         5  2018-08-27  471  181   27   21  2018-08-27   
#[Out]# 
#[Out]#         quantity  price  cID   cName            street       city  
#[Out]# 0              2   4.65    0    Noah         Koestraat    Utrecht  
#[Out]# 1              2   4.65    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 2              2   4.65    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 3              2   4.65    3    Finn     Stationsplein      Breda  
#[Out]# 4              2   4.65    4    Daan      Kalverstraat  Amsterdam  
#[Out]# ...          ...    ...  ...     ...               ...        ...  
#[Out]# 185435         5   2.00  185    Nick            Verweg  Eindhoven  
#[Out]# 185436         5   2.00  186  Angela          Dichtweg  Eindhoven  
#[Out]# 185437         5   2.00  188    Pino        Maanstraat  Rotterdam  
#[Out]# 185438         5   2.00  189    Koen          Akkerweg        Oss  
#[Out]# 185439         5   2.00  190  Kostas          Eindeweg    Utrecht  
#[Out]# 
#[Out]# [185440 rows x 15 columns]
# Mon, 30 Nov 2020 16:46:40
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT *
    FROM shoppinglist s, purchase p, customer c
    WHERE s.date == p.date 
        AND (p.date LIKE "2018%")
        AND s.cID == p.cID
        AND s.cID == c.cID
        AND p.cID == c.cID
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#      cID  pID  quantity        date  tID  cID  sID  pID        date  quantity  \
#[Out]# 0      1    9         2  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 1      1   11         8  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 2      1   14         2  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 3      1   16         3  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 4      1   21         6  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# ..   ...  ...       ...         ...  ...  ...  ...  ...         ...       ...   
#[Out]# 971  181   26         4  2018-08-24  469  181    6   26  2018-08-24         4   
#[Out]# 972  181    6         3  2018-08-24  470  181   45    6  2018-08-24         3   
#[Out]# 973  181   26         4  2018-08-24  470  181   45    6  2018-08-24         3   
#[Out]# 974  181    5         3  2018-08-27  471  181   27   21  2018-08-27         5   
#[Out]# 975  181   21         5  2018-08-27  471  181   27   21  2018-08-27         5   
#[Out]# 
#[Out]#      price  cID cName            street       city  
#[Out]# 0     4.65    1   Sem  Rozemarijnstraat      Breda  
#[Out]# 1     4.65    1   Sem  Rozemarijnstraat      Breda  
#[Out]# 2     4.65    1   Sem  Rozemarijnstraat      Breda  
#[Out]# 3     4.65    1   Sem  Rozemarijnstraat      Breda  
#[Out]# 4     4.65    1   Sem  Rozemarijnstraat      Breda  
#[Out]# ..     ...  ...   ...               ...        ...  
#[Out]# 971   2.70  181  Liva       Fredriklaan  Eindhoven  
#[Out]# 972   0.90  181  Liva       Fredriklaan  Eindhoven  
#[Out]# 973   0.90  181  Liva       Fredriklaan  Eindhoven  
#[Out]# 974   2.00  181  Liva       Fredriklaan  Eindhoven  
#[Out]# 975   2.00  181  Liva       Fredriklaan  Eindhoven  
#[Out]# 
#[Out]# [976 rows x 15 columns]
# Mon, 30 Nov 2020 16:48:09
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT c.cName, c.cID
    FROM shoppinglist s, purchase p, customer c
    WHERE s.date == p.date 
        AND (p.date LIKE "2018%")
        AND s.cID == p.cID
        AND s.cID == c.cID
        AND p.cID == c.cID
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#     cName  cID
#[Out]# 0     Sem    1
#[Out]# 1     Sem    1
#[Out]# 2     Sem    1
#[Out]# 3     Sem    1
#[Out]# 4     Sem    1
#[Out]# ..    ...  ...
#[Out]# 971  Liva  181
#[Out]# 972  Liva  181
#[Out]# 973  Liva  181
#[Out]# 974  Liva  181
#[Out]# 975  Liva  181
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Mon, 30 Nov 2020 16:49:21
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT c.cName, c.cID
    FROM shoppinglist s, purchase p, customer c
    WHERE s.date == p.date 
        AND (p.date LIKE "2018%")
        AND s.cID == p.cID
        AND s.cID == c.cID
        AND p.cID == c.cID
'''
pd.read_sql_query(query_sp_list, conn)
vis.visualize(query_sp_list, schema)
# Mon, 30 Nov 2020 16:49:31
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT c.cName, c.cID
    FROM shoppinglist s, purchase p, customer c
    WHERE s.date == p.date 
        AND (p.date LIKE "2018%")
        AND s.cID == p.cID
        AND s.cID == c.cID
        AND p.cID == c.cID
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#     cName  cID
#[Out]# 0     Sem    1
#[Out]# 1     Sem    1
#[Out]# 2     Sem    1
#[Out]# 3     Sem    1
#[Out]# 4     Sem    1
#[Out]# ..    ...  ...
#[Out]# 971  Liva  181
#[Out]# 972  Liva  181
#[Out]# 973  Liva  181
#[Out]# 974  Liva  181
#[Out]# 975  Liva  181
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Mon, 30 Nov 2020 16:49:35
vis.visualize(query_sp_list, schema)
# Mon, 30 Nov 2020 16:50:29
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT c.cName, c.cID
    FROM shoppinglist s, purchase p, customer c
    WHERE s.date LIKE p.date 
        AND (p.date LIKE "2018%")
        AND s.cID == p.cID
        AND s.cID == c.cID
        AND p.cID == c.cID
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#     cName  cID
#[Out]# 0     Sem    1
#[Out]# 1     Sem    1
#[Out]# 2     Sem    1
#[Out]# 3     Sem    1
#[Out]# 4     Sem    1
#[Out]# ..    ...  ...
#[Out]# 971  Liva  181
#[Out]# 972  Liva  181
#[Out]# 973  Liva  181
#[Out]# 974  Liva  181
#[Out]# 975  Liva  181
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Mon, 30 Nov 2020 16:51:28
# shoppinglist and purchase on same date
query_sp_list = '''
    SELECT DISTINCT c.cName, c.cID
    FROM shoppinglist s, purchase p, customer c
    WHERE s.date LIKE p.date 
        AND (p.date LIKE "2018%")
        AND s.cID == p.cID
        AND s.cID == c.cID
        AND p.cID == c.cID
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 16:53:43
query_check_inner = '''
    SELECT *
    FROM shoppinglist INNER JOIN purchase
'''
# Mon, 30 Nov 2020 16:53:52
query_check_inner = '''
    SELECT *
    FROM shoppinglist INNER JOIN purchase
'''
pd.read_sql_query(query_check_inner, conn)
#[Out]#         cID  pID  quantity        date  tID  cID  sID  pID        date  \
#[Out]# 0         1   14         2  2018-08-20    0    0    3   10  2018-08-22   
#[Out]# 1         1   14         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 2         1   14         2  2018-08-20    2    1    3   16  2018-08-20   
#[Out]# 3         1   14         2  2018-08-20    3    1   17    9  2018-08-20   
#[Out]# 4         1   14         2  2018-08-20    4    1   32   25  2018-08-20   
#[Out]# ...     ...  ...       ...         ...  ...  ...  ...  ...         ...   
#[Out]# 250423  183   25         4  2018-08-22  843  190   59   17  2018-08-26   
#[Out]# 250424  183   25         4  2018-08-22  844  190   60    5  2018-08-27   
#[Out]# 250425  183   25         4  2018-08-22  845  190   61   19  2018-08-23   
#[Out]# 250426  183   25         4  2018-08-22  846  190   62    9  2018-08-16   
#[Out]# 250427  183   25         4  2018-08-22  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#         quantity  price  
#[Out]# 0              1   0.45  
#[Out]# 1              2   4.65  
#[Out]# 2              3   1.60  
#[Out]# 3              2   1.25  
#[Out]# 4              4   3.95  
#[Out]# ...          ...    ...  
#[Out]# 250423         2   3.80  
#[Out]# 250424         6   4.35  
#[Out]# 250425         5   2.85  
#[Out]# 250426         2   3.15  
#[Out]# 250427         1   3.30  
#[Out]# 
#[Out]# [250428 rows x 11 columns]
# Mon, 30 Nov 2020 16:54:28
query_check_inner = '''
    SELECT *
    FROM shoppinglist INNER JOIN purchase
        ON shoppinglist.cID = purchase.cID
'''
pd.read_sql_query(query_check_inner, conn)
#[Out]#       cID  pID  quantity        date  tID  cID  sID  pID        date  \
#[Out]# 0       1    9         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 1       1   11         8  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 2       1   14         2  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 3       1   16         3  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# 4       1   21         6  2018-08-20    1    1   23   14  2018-08-20   
#[Out]# ...   ...  ...       ...         ...  ...  ...  ...  ...         ...   
#[Out]# 2322  181   26         4  2018-08-24  470  181   45    6  2018-08-24   
#[Out]# 2323  181    5         3  2018-08-27  471  181   27   21  2018-08-27   
#[Out]# 2324  181    6         3  2018-08-24  471  181   27   21  2018-08-27   
#[Out]# 2325  181   21         5  2018-08-27  471  181   27   21  2018-08-27   
#[Out]# 2326  181   26         4  2018-08-24  471  181   27   21  2018-08-27   
#[Out]# 
#[Out]#       quantity  price  
#[Out]# 0            2   4.65  
#[Out]# 1            2   4.65  
#[Out]# 2            2   4.65  
#[Out]# 3            2   4.65  
#[Out]# 4            2   4.65  
#[Out]# ...        ...    ...  
#[Out]# 2322         3   0.90  
#[Out]# 2323         5   2.00  
#[Out]# 2324         5   2.00  
#[Out]# 2325         5   2.00  
#[Out]# 2326         5   2.00  
#[Out]# 
#[Out]# [2327 rows x 11 columns]
# Mon, 30 Nov 2020 16:55:09
query_check_inner = '''
    SELECT *
    FROM shoppinglist s INNER JOIN purchase p
        ON s.cID = p.cID
    WHERE s.date LIKE p.date
'''
pd.read_sql_query(query_check_inner, conn)
#[Out]#      cID  pID  quantity        date  tID  cID  sID  pID        date  quantity  \
#[Out]# 0      1    9         2  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 1      1   11         8  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 2      1   14         2  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 3      1   16         3  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# 4      1   21         6  2018-08-20    1    1   23   14  2018-08-20         2   
#[Out]# ..   ...  ...       ...         ...  ...  ...  ...  ...         ...       ...   
#[Out]# 971  181   26         4  2018-08-24  469  181    6   26  2018-08-24         4   
#[Out]# 972  181    6         3  2018-08-24  470  181   45    6  2018-08-24         3   
#[Out]# 973  181   26         4  2018-08-24  470  181   45    6  2018-08-24         3   
#[Out]# 974  181    5         3  2018-08-27  471  181   27   21  2018-08-27         5   
#[Out]# 975  181   21         5  2018-08-27  471  181   27   21  2018-08-27         5   
#[Out]# 
#[Out]#      price  
#[Out]# 0     4.65  
#[Out]# 1     4.65  
#[Out]# 2     4.65  
#[Out]# 3     4.65  
#[Out]# 4     4.65  
#[Out]# ..     ...  
#[Out]# 971   2.70  
#[Out]# 972   0.90  
#[Out]# 973   0.90  
#[Out]# 974   2.00  
#[Out]# 975   2.00  
#[Out]# 
#[Out]# [976 rows x 11 columns]
# Mon, 30 Nov 2020 16:56:25
query_check_inner = '''
    SELECT c.cID, c.cName
    FROM customer, (
        SELECT *
        FROM shoppinglist s INNER JOIN purchase p
            ON s.cID = p.cID
        WHERE s.date LIKE p.date
                    )
'''
pd.read_sql_query(query_check_inner, conn)
# Mon, 30 Nov 2020 16:56:34
query_check_inner = '''
    SELECT c.cID, c.cName
    FROM customer c, (
        SELECT *
        FROM shoppinglist s INNER JOIN purchase p
            ON s.cID = p.cID
        WHERE s.date LIKE p.date
                    )
'''
pd.read_sql_query(query_check_inner, conn)
#[Out]#         cID   cName
#[Out]# 0         0    Noah
#[Out]# 1         1     Sem
#[Out]# 2         2   Lucas
#[Out]# 3         3    Finn
#[Out]# 4         4    Daan
#[Out]# ...     ...     ...
#[Out]# 185435  185    Nick
#[Out]# 185436  186  Angela
#[Out]# 185437  188    Pino
#[Out]# 185438  189    Koen
#[Out]# 185439  190  Kostas
#[Out]# 
#[Out]# [185440 rows x 2 columns]
# Mon, 30 Nov 2020 16:57:40
query_check_inner = '''
    SELECT c.cID, c.cName
    FROM customer c, (
        SELECT s.cID
        FROM shoppinglist s INNER JOIN purchase p
            ON s.cID = p.cID
        WHERE s.date LIKE p.date
                    )
    WHERE s.cID = c.cID 
'''
pd.read_sql_query(query_check_inner, conn)
# Mon, 30 Nov 2020 16:57:50
query_check_inner = '''
    SELECT c.cID, c.cName
    FROM customer c, (
        SELECT s.cID
        FROM shoppinglist s INNER JOIN purchase p
            ON s.cID = p.cID
        WHERE s.date LIKE p.date
                    ) sp
    WHERE sp.cID = c.cID 
'''
pd.read_sql_query(query_check_inner, conn)
#[Out]#      cID cName
#[Out]# 0      1   Sem
#[Out]# 1      1   Sem
#[Out]# 2      1   Sem
#[Out]# 3      1   Sem
#[Out]# 4      1   Sem
#[Out]# ..   ...   ...
#[Out]# 971  181  Liva
#[Out]# 972  181  Liva
#[Out]# 973  181  Liva
#[Out]# 974  181  Liva
#[Out]# 975  181  Liva
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Mon, 30 Nov 2020 16:58:00
query_check_inner = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, (
        SELECT s.cID
        FROM shoppinglist s INNER JOIN purchase p
            ON s.cID = p.cID
        WHERE s.date LIKE p.date
                    ) sp
    WHERE sp.cID = c.cID 
'''
pd.read_sql_query(query_check_inner, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 16:58:55
query3_2 = '''
    SELECT *
    FROM customer c
    
'''
# Mon, 30 Nov 2020 16:59:00
vis.visualize(query3_2, schema)
# Mon, 30 Nov 2020 16:59:03
pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName            street       city
#[Out]# 0      0    Noah         Koestraat    Utrecht
#[Out]# 1      1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 3      3    Finn     Stationsplein      Breda
#[Out]# 4      4    Daan      Kalverstraat  Amsterdam
#[Out]# ..   ...     ...               ...        ...
#[Out]# 185  185    Nick            Verweg  Eindhoven
#[Out]# 186  186  Angela          Dichtweg  Eindhoven
#[Out]# 187  188    Pino        Maanstraat  Rotterdam
#[Out]# 188  189    Koen          Akkerweg        Oss
#[Out]# 189  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Mon, 30 Nov 2020 17:00:04
# first approach 
query_sp_list = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, (
        SELECT s.cID
        FROM shoppinglist s INNER JOIN purchase p
            ON s.cID = p.cID
        WHERE s.date LIKE p.date
                    ) sp
    WHERE sp.cID = c.cID
'''
pd.read_sql_query(query_sp_list, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 17:00:15
vis.visualize(query3_2, schema)
# Mon, 30 Nov 2020 17:00:41
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, (
        SELECT s.cID
        FROM shoppinglist s INNER JOIN purchase p
            ON s.cID = p.cID
        WHERE s.date LIKE p.date
                    ) sp
    WHERE sp.cID = c.cID 
'''
# Mon, 30 Nov 2020 17:00:55
vis.visualize(query3_2, schema)
# Mon, 30 Nov 2020 17:02:08
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]

# IPython log file

# Tue, 01 Dec 2020 12:44:05
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 12:44:09
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 12:47:59
query3_3 = '''
    SELECT * 
    FROM purchase
'''
# Tue, 01 Dec 2020 12:48:03
pd.read_sql_query(query3_3, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Tue, 01 Dec 2020 12:48:57
query3_3 = '''
    SELECT * 
    FROM purchase, store
'''
# Tue, 01 Dec 2020 12:48:59
pd.read_sql_query(query3_3, conn)
#[Out]#        tID  cID  sID  pID        date  quantity  price  sID      sName  \
#[Out]# 0        0    0    3   10  2018-08-22         1   0.45    0       Coop   
#[Out]# 1        0    0    3   10  2018-08-22         1   0.45    1  Hoogvliet   
#[Out]# 2        0    0    3   10  2018-08-22         1   0.45    2      Jumbo   
#[Out]# 3        0    0    3   10  2018-08-22         1   0.45    3     Sligro   
#[Out]# 4        0    0    3   10  2018-08-22         1   0.45    4  Hoogvliet   
#[Out]# ...    ...  ...  ...  ...         ...       ...    ...  ...        ...   
#[Out]# 32571  847  190   63   18  2018-08-21         1   3.30   59      Jumbo   
#[Out]# 32572  847  190   63   18  2018-08-21         1   3.30   60       Lidl   
#[Out]# 32573  847  190   63   18  2018-08-21         1   3.30   61       Lidl   
#[Out]# 32574  847  190   63   18  2018-08-21         1   3.30   62      Jumbo   
#[Out]# 32575  847  190   63   18  2018-08-21         1   3.30   63      Jumbo   
#[Out]# 
#[Out]#                  street       city  
#[Out]# 0          Kalverstraat  Amsterdam  
#[Out]# 1      Rozemarijnstraat      Breda  
#[Out]# 2        Stadhoudersweg  Rotterdam  
#[Out]# 3        Stadhoudersweg  Rotterdam  
#[Out]# 4           Molenstraat  Eindhoven  
#[Out]# ...                 ...        ...  
#[Out]# 32571  Rozemarijnstraat      Breda  
#[Out]# 32572      Pannekoekweg      Breda  
#[Out]# 32573      Pannekoekweg      Breda  
#[Out]# 32574     Poffertjesweg  Eindhoven  
#[Out]# 32575     Stationstraat        Oss  
#[Out]# 
#[Out]# [32576 rows x 11 columns]
# Tue, 01 Dec 2020 12:50:25
query3_3 = '''
    SELECT * 
    FROM purchase p INNER JOIN store s
        ON p.sID = s.sID
'''
# Tue, 01 Dec 2020 12:50:27
pd.read_sql_query(query3_3, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  sID        sName  \
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45    3       Sligro   
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65   23         Dirk   
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60    3       Sligro   
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25   17    Hoogvliet   
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95   32  Albert Hein   
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  ...          ...   
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80   59        Jumbo   
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35   60         Lidl   
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85   61         Lidl   
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15   62        Jumbo   
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30   63        Jumbo   
#[Out]# 
#[Out]#                street       city  
#[Out]# 0      Stadhoudersweg  Rotterdam  
#[Out]# 1       Stationsplein      Breda  
#[Out]# 2      Stadhoudersweg  Rotterdam  
#[Out]# 3          Kerkstraat  Eindhoven  
#[Out]# 4          Hoogstraat    Utrecht  
#[Out]# ..                ...        ...  
#[Out]# 504  Rozemarijnstraat      Breda  
#[Out]# 505      Pannekoekweg      Breda  
#[Out]# 506      Pannekoekweg      Breda  
#[Out]# 507     Poffertjesweg  Eindhoven  
#[Out]# 508     Stationstraat        Oss  
#[Out]# 
#[Out]# [509 rows x 11 columns]
# Tue, 01 Dec 2020 12:51:15
pd.read_sql_query('''SELECT * FROM purchase''', conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Tue, 01 Dec 2020 12:53:22
pd.read_sql_query('''SELECT cID, cName FROM purchase''', conn)
# Tue, 01 Dec 2020 12:53:31
pd.read_sql_query('''SELECT cID FROM purchase''', conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# ..   ...
#[Out]# 504  190
#[Out]# 505  190
#[Out]# 506  190
#[Out]# 507  190
#[Out]# 508  190
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Tue, 01 Dec 2020 12:53:37
pd.read_sql_query('''SELECT DISTINCT cID FROM purchase''', conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 127  185
#[Out]# 128  186
#[Out]# 129  188
#[Out]# 130  189
#[Out]# 131  190
#[Out]# 
#[Out]# [132 rows x 1 columns]
# Tue, 01 Dec 2020 12:53:50
pd.read_sql_query('''SELECT DISTINCT cID FROM customer''', conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 12:54:04
pd.read_sql_query('''SELECT DISTINCT cID, cName FROM customer''', conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 12:57:08
pd.read_sql_query('''SELECT DISTINCT c.cID, c.cName FROM customer c WHERE c.cID NOT IN (SELECT DISTINCT p.cID FROM purchase p) ''', conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Tue, 01 Dec 2020 12:58:31
query_no_purchases = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM customer c 
    WHERE c.cID NOT IN 
    (SELECT DISTINCT p.cID FROM purchase p)
    '''
pd.read_sql_query(query_no_purchases, conn)
vis.visualize(query_no_purchases, schema)
# Tue, 01 Dec 2020 12:59:41
query_no_purchases = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM customer c 
    WHERE c.cID NOT IN 
    (SELECT DISTINCT p.cID FROM purchase p) OR
    '''
pd.read_sql_query(query_no_purchases, conn)
# Tue, 01 Dec 2020 13:02:31
query_no_purchases = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM customer c 
    WHERE c.cID NOT IN 
    (SELECT DISTINCT p.cID FROM purchase p) OR
    (SELECT p2.cID 
        FROM purchase p2 INNER JOIN store s
            ON p2.sID = s.sID
        WHERE s.sName = "Jumbo")
    '''
pd.read_sql_query(query_no_purchases, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 13:02:40
vis.visualize(query_no_purchases, schema)
# Tue, 01 Dec 2020 13:02:54
query_no_purchases = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM customer c 
    WHERE c.cID NOT IN 
    (SELECT DISTINCT p.cID FROM purchase p) OR
    (SELECT p2.cID 
        FROM purchase p2 INNER JOIN store s
            ON p2.sID = s.sID
        WHERE s.sName LIKE "Jumbo")
    '''
pd.read_sql_query(query_no_purchases, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 13:02:57
vis.visualize(query_no_purchases, schema)
# Tue, 01 Dec 2020 13:04:53
query_no_purchases = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM customer c 
    WHERE c.cID NOT IN 
    (SELECT DISTINCT p.cID FROM purchase p)
    '''
pd.read_sql_query(query_no_purchases, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Tue, 01 Dec 2020 13:05:00
vis.visualize(query_no_purchases, schema)
# Tue, 01 Dec 2020 13:06:22
query_nopurchase_jumbo = '''
    SELECT * FROM store
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0     0       Coop      Kalverstraat  Amsterdam
#[Out]# 1     1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59   59      Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60       Lidl      Pannekoekweg      Breda
#[Out]# 61   61       Lidl      Pannekoekweg      Breda
#[Out]# 62   62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63      Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Tue, 01 Dec 2020 13:06:51
query_nopurchase_jumbo = '''
    SELECT * FROM store s INNER JOIN purchase p ON s.sID = p.sID
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      sID        sName            street       city  tID  cID  sID  pID  \
#[Out]# 0      3       Sligro    Stadhoudersweg  Rotterdam    0    0    3   10   
#[Out]# 1     23         Dirk     Stationsplein      Breda    1    1   23   14   
#[Out]# 2      3       Sligro    Stadhoudersweg  Rotterdam    2    1    3   16   
#[Out]# 3     17    Hoogvliet        Kerkstraat  Eindhoven    3    1   17    9   
#[Out]# 4     32  Albert Hein        Hoogstraat    Utrecht    4    1   32   25   
#[Out]# ..   ...          ...               ...        ...  ...  ...  ...  ...   
#[Out]# 504   59        Jumbo  Rozemarijnstraat      Breda  843  190   59   17   
#[Out]# 505   60         Lidl      Pannekoekweg      Breda  844  190   60    5   
#[Out]# 506   61         Lidl      Pannekoekweg      Breda  845  190   61   19   
#[Out]# 507   62        Jumbo     Poffertjesweg  Eindhoven  846  190   62    9   
#[Out]# 508   63        Jumbo     Stationstraat        Oss  847  190   63   18   
#[Out]# 
#[Out]#            date  quantity  price  
#[Out]# 0    2018-08-22         1   0.45  
#[Out]# 1    2018-08-20         2   4.65  
#[Out]# 2    2018-08-20         3   1.60  
#[Out]# 3    2018-08-20         2   1.25  
#[Out]# 4    2018-08-20         4   3.95  
#[Out]# ..          ...       ...    ...  
#[Out]# 504  2018-08-26         2   3.80  
#[Out]# 505  2018-08-27         6   4.35  
#[Out]# 506  2018-08-23         5   2.85  
#[Out]# 507  2018-08-16         2   3.15  
#[Out]# 508  2018-08-21         1   3.30  
#[Out]# 
#[Out]# [509 rows x 11 columns]
# Tue, 01 Dec 2020 13:07:22
query_nopurchase_jumbo = '''
    SELECT * FROM purchase
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Tue, 01 Dec 2020 13:07:27
query_nopurchase_jumbo = '''
    SELECT * FROM store s INNER JOIN purchase p ON s.sID = p.sID
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      sID        sName            street       city  tID  cID  sID  pID  \
#[Out]# 0      3       Sligro    Stadhoudersweg  Rotterdam    0    0    3   10   
#[Out]# 1     23         Dirk     Stationsplein      Breda    1    1   23   14   
#[Out]# 2      3       Sligro    Stadhoudersweg  Rotterdam    2    1    3   16   
#[Out]# 3     17    Hoogvliet        Kerkstraat  Eindhoven    3    1   17    9   
#[Out]# 4     32  Albert Hein        Hoogstraat    Utrecht    4    1   32   25   
#[Out]# ..   ...          ...               ...        ...  ...  ...  ...  ...   
#[Out]# 504   59        Jumbo  Rozemarijnstraat      Breda  843  190   59   17   
#[Out]# 505   60         Lidl      Pannekoekweg      Breda  844  190   60    5   
#[Out]# 506   61         Lidl      Pannekoekweg      Breda  845  190   61   19   
#[Out]# 507   62        Jumbo     Poffertjesweg  Eindhoven  846  190   62    9   
#[Out]# 508   63        Jumbo     Stationstraat        Oss  847  190   63   18   
#[Out]# 
#[Out]#            date  quantity  price  
#[Out]# 0    2018-08-22         1   0.45  
#[Out]# 1    2018-08-20         2   4.65  
#[Out]# 2    2018-08-20         3   1.60  
#[Out]# 3    2018-08-20         2   1.25  
#[Out]# 4    2018-08-20         4   3.95  
#[Out]# ..          ...       ...    ...  
#[Out]# 504  2018-08-26         2   3.80  
#[Out]# 505  2018-08-27         6   4.35  
#[Out]# 506  2018-08-23         5   2.85  
#[Out]# 507  2018-08-16         2   3.15  
#[Out]# 508  2018-08-21         1   3.30  
#[Out]# 
#[Out]# [509 rows x 11 columns]
# Tue, 01 Dec 2020 13:07:49
query_nopurchase_jumbo = '''
    SELECT * FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo"
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      sID        sName           street       city  tID  cID  sID  pID  \
#[Out]# 0      3       Sligro   Stadhoudersweg  Rotterdam    0    0    3   10   
#[Out]# 1     23         Dirk    Stationsplein      Breda    1    1   23   14   
#[Out]# 2      3       Sligro   Stadhoudersweg  Rotterdam    2    1    3   16   
#[Out]# 3     17    Hoogvliet       Kerkstraat  Eindhoven    3    1   17    9   
#[Out]# 4     32  Albert Hein       Hoogstraat    Utrecht    4    1   32   25   
#[Out]# ..   ...          ...              ...        ...  ...  ...  ...  ...   
#[Out]# 459   55         Coop  Sint Annastraat      Breda  839  190   55    8   
#[Out]# 460   57         Dirk      Molenstraat  Eindhoven  841  190   57   15   
#[Out]# 461   58         Dirk     Keizerstraat  Rotterdam  842  190   58    2   
#[Out]# 462   60         Lidl     Pannekoekweg      Breda  844  190   60    5   
#[Out]# 463   61         Lidl     Pannekoekweg      Breda  845  190   61   19   
#[Out]# 
#[Out]#            date  quantity  price  
#[Out]# 0    2018-08-22         1   0.45  
#[Out]# 1    2018-08-20         2   4.65  
#[Out]# 2    2018-08-20         3   1.60  
#[Out]# 3    2018-08-20         2   1.25  
#[Out]# 4    2018-08-20         4   3.95  
#[Out]# ..          ...       ...    ...  
#[Out]# 459  2018-08-18         7   2.95  
#[Out]# 460  2018-08-22         5   3.25  
#[Out]# 461  2018-08-19         7   0.75  
#[Out]# 462  2018-08-27         6   4.35  
#[Out]# 463  2018-08-23         5   2.85  
#[Out]# 
#[Out]# [464 rows x 11 columns]
# Tue, 01 Dec 2020 13:07:56
query_nopurchase_jumbo = '''
    SELECT * FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Lidl"
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      sID        sName            street       city  tID  cID  sID  pID  \
#[Out]# 0      3       Sligro    Stadhoudersweg  Rotterdam    0    0    3   10   
#[Out]# 1     23         Dirk     Stationsplein      Breda    1    1   23   14   
#[Out]# 2      3       Sligro    Stadhoudersweg  Rotterdam    2    1    3   16   
#[Out]# 3     17    Hoogvliet        Kerkstraat  Eindhoven    3    1   17    9   
#[Out]# 4     32  Albert Hein        Hoogstraat    Utrecht    4    1   32   25   
#[Out]# ..   ...          ...               ...        ...  ...  ...  ...  ...   
#[Out]# 440   57         Dirk       Molenstraat  Eindhoven  841  190   57   15   
#[Out]# 441   58         Dirk      Keizerstraat  Rotterdam  842  190   58    2   
#[Out]# 442   59        Jumbo  Rozemarijnstraat      Breda  843  190   59   17   
#[Out]# 443   62        Jumbo     Poffertjesweg  Eindhoven  846  190   62    9   
#[Out]# 444   63        Jumbo     Stationstraat        Oss  847  190   63   18   
#[Out]# 
#[Out]#            date  quantity  price  
#[Out]# 0    2018-08-22         1   0.45  
#[Out]# 1    2018-08-20         2   4.65  
#[Out]# 2    2018-08-20         3   1.60  
#[Out]# 3    2018-08-20         2   1.25  
#[Out]# 4    2018-08-20         4   3.95  
#[Out]# ..          ...       ...    ...  
#[Out]# 440  2018-08-22         5   3.25  
#[Out]# 441  2018-08-19         7   0.75  
#[Out]# 442  2018-08-26         2   3.80  
#[Out]# 443  2018-08-16         2   3.15  
#[Out]# 444  2018-08-21         1   3.30  
#[Out]# 
#[Out]# [445 rows x 11 columns]
# Tue, 01 Dec 2020 13:08:02
query_nopurchase_jumbo = '''
    SELECT * FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo"
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      sID        sName           street       city  tID  cID  sID  pID  \
#[Out]# 0      3       Sligro   Stadhoudersweg  Rotterdam    0    0    3   10   
#[Out]# 1     23         Dirk    Stationsplein      Breda    1    1   23   14   
#[Out]# 2      3       Sligro   Stadhoudersweg  Rotterdam    2    1    3   16   
#[Out]# 3     17    Hoogvliet       Kerkstraat  Eindhoven    3    1   17    9   
#[Out]# 4     32  Albert Hein       Hoogstraat    Utrecht    4    1   32   25   
#[Out]# ..   ...          ...              ...        ...  ...  ...  ...  ...   
#[Out]# 459   55         Coop  Sint Annastraat      Breda  839  190   55    8   
#[Out]# 460   57         Dirk      Molenstraat  Eindhoven  841  190   57   15   
#[Out]# 461   58         Dirk     Keizerstraat  Rotterdam  842  190   58    2   
#[Out]# 462   60         Lidl     Pannekoekweg      Breda  844  190   60    5   
#[Out]# 463   61         Lidl     Pannekoekweg      Breda  845  190   61   19   
#[Out]# 
#[Out]#            date  quantity  price  
#[Out]# 0    2018-08-22         1   0.45  
#[Out]# 1    2018-08-20         2   4.65  
#[Out]# 2    2018-08-20         3   1.60  
#[Out]# 3    2018-08-20         2   1.25  
#[Out]# 4    2018-08-20         4   3.95  
#[Out]# ..          ...       ...    ...  
#[Out]# 459  2018-08-18         7   2.95  
#[Out]# 460  2018-08-22         5   3.25  
#[Out]# 461  2018-08-19         7   0.75  
#[Out]# 462  2018-08-27         6   4.35  
#[Out]# 463  2018-08-23         5   2.85  
#[Out]# 
#[Out]# [464 rows x 11 columns]
# Tue, 01 Dec 2020 13:08:44
query_nopurchase_jumbo = '''
    SELECT cID FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo"
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# ..   ...
#[Out]# 459  190
#[Out]# 460  190
#[Out]# 461  190
#[Out]# 462  190
#[Out]# 463  190
#[Out]# 
#[Out]# [464 rows x 1 columns]
# Tue, 01 Dec 2020 13:08:56
query_nopurchase_jumbo = '''
    SELECT DISTINCT cID FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo"
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 119  180
#[Out]# 120  181
#[Out]# 121  182
#[Out]# 122  184
#[Out]# 123  190
#[Out]# 
#[Out]# [124 rows x 1 columns]
# Tue, 01 Dec 2020 13:11:48
query_nopurchase_jumbo = '''
    SELECT DISTINCT mix.cID FROM (SELECT DISTINCT cID FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo" AS mix)
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
# Tue, 01 Dec 2020 13:11:54
query_nopurchase_jumbo = '''
    SELECT DISTINCT mix.cID FROM (SELECT DISTINCT cID FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo" mix)
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
# Tue, 01 Dec 2020 13:12:08
query_nopurchase_jumbo = '''
    SELECT DISTINCT cID FROM (SELECT DISTINCT cID FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo")
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 119  180
#[Out]# 120  181
#[Out]# 121  182
#[Out]# 122  184
#[Out]# 123  190
#[Out]# 
#[Out]# [124 rows x 1 columns]
# Tue, 01 Dec 2020 13:13:07
query_nopurchase_jumbo = '''
    SELECT DISTINCT cID FROM (SELECT DISTINCT cID FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo") stores INNER JOIN customer c ON stores.cID LIKE c.cID
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
# Tue, 01 Dec 2020 13:13:34
query_nopurchase_jumbo = '''
    SELECT DISTINCT stores.cID FROM (SELECT DISTINCT cID FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo") stores INNER JOIN customer c ON stores.cID LIKE c.cID
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 119  180
#[Out]# 120  181
#[Out]# 121  182
#[Out]# 122  184
#[Out]# 123  190
#[Out]# 
#[Out]# [124 rows x 1 columns]
# Tue, 01 Dec 2020 13:13:41
query_nopurchase_jumbo = '''
    SELECT DISTINCT stores.cID, c.cName FROM (SELECT DISTINCT cID FROM store s INNER JOIN purchase p ON s.sID = p.sID
    WHERE sName NOT LIKE "Jumbo") stores INNER JOIN customer c ON stores.cID LIKE c.cID
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      4     Daan
#[Out]# ..   ...      ...
#[Out]# 119  180    Merel
#[Out]# 120  181     Liva
#[Out]# 121  182  Johanna
#[Out]# 122  184    Wilko
#[Out]# 123  190   Kostas
#[Out]# 
#[Out]# [124 rows x 2 columns]
# Tue, 01 Dec 2020 13:14:38
query_nopurchase_jumbo = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM (SELECT DISTINCT cID 
          FROM store s INNER JOIN purchase p 
          ON s.sID = p.sID
          WHERE sName NOT LIKE "Jumbo") stores 
              INNER JOIN customer c 
              ON stores.cID LIKE c.cID
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      4     Daan
#[Out]# ..   ...      ...
#[Out]# 119  180    Merel
#[Out]# 120  181     Liva
#[Out]# 121  182  Johanna
#[Out]# 122  184    Wilko
#[Out]# 123  190   Kostas
#[Out]# 
#[Out]# [124 rows x 2 columns]
# Tue, 01 Dec 2020 13:15:44
query_nopurchase_jumbo = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM (SELECT DISTINCT cID 
          FROM store s INNER JOIN purchase p 
          ON s.sID = p.sID
          WHERE sName NOT LIKE "Jumbo") stores 
              INNER JOIN customer c 
              ON stores.cID LIKE c.cID
    UNION
    SELECT DISTINCT c.cID, c.cName 
    FROM customer c 
    WHERE c.cID NOT IN 
    (SELECT DISTINCT p.cID FROM purchase p)
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      4     Daan
#[Out]# ..   ...      ...
#[Out]# 177  181     Liva
#[Out]# 178  182  Johanna
#[Out]# 179  183    Nikki
#[Out]# 180  184    Wilko
#[Out]# 181  190   Kostas
#[Out]# 
#[Out]# [182 rows x 2 columns]
# Tue, 01 Dec 2020 13:15:56
query_nopurchase_jumbo = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM (SELECT DISTINCT cID 
          FROM store s INNER JOIN purchase p 
          ON s.sID = p.sID
          WHERE sName NOT LIKE "Jumbo") stores 
              INNER JOIN customer c 
              ON stores.cID LIKE c.cID
    
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      4     Daan
#[Out]# ..   ...      ...
#[Out]# 119  180    Merel
#[Out]# 120  181     Liva
#[Out]# 121  182  Johanna
#[Out]# 122  184    Wilko
#[Out]# 123  190   Kostas
#[Out]# 
#[Out]# [124 rows x 2 columns]
# Tue, 01 Dec 2020 13:16:04
query_no_purchases = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM customer c 
    WHERE c.cID NOT IN 
    (SELECT DISTINCT p.cID FROM purchase p)
    '''
pd.read_sql_query(query_no_purchases, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Tue, 01 Dec 2020 13:16:30
query_nopurchase_jumbo = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM (SELECT DISTINCT cID 
          FROM store s INNER JOIN purchase p 
          ON s.sID = p.sID
          WHERE sName NOT LIKE "Jumbo") stores 
              INNER JOIN customer c 
              ON stores.cID LIKE c.cID
    UNION
    SELECT DISTINCT c.cID, c.cName 
    FROM customer c 
    WHERE c.cID NOT IN 
    (SELECT DISTINCT p.cID FROM purchase p)
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      4     Daan
#[Out]# ..   ...      ...
#[Out]# 177  181     Liva
#[Out]# 178  182  Johanna
#[Out]# 179  183    Nikki
#[Out]# 180  184    Wilko
#[Out]# 181  190   Kostas
#[Out]# 
#[Out]# [182 rows x 2 columns]
# Tue, 01 Dec 2020 14:24:42
query_jumbo = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM (SELECT DISTINCT cID 
          FROM store s INNER JOIN purchase p 
          ON s.sID = p.sID
          WHERE sName LIKE "Jumbo") stores 
              INNER JOIN customer c 
              ON stores.cID LIKE c.cID
              '''
pd.read_sql_query(query_jumbo, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Tue, 01 Dec 2020 14:26:09
vis.visualize(query_no_purchases, schema)
# Tue, 01 Dec 2020 14:26:20
vis.visualize(query_nopurchase_jumbo, schema)
# Tue, 01 Dec 2020 14:27:21
query_nopurchase_jumbo = '''
    SELECT DISTINCT c.cID, c.cName 
    FROM (SELECT DISTINCT cID 
          FROM store s INNER JOIN purchase p 
          ON s.sID = p.sID
          WHERE sName NOT LIKE "Jumbo") stores 
              INNER JOIN customer c 
              ON stores.cID LIKE c.cID
    UNION
    SELECT DISTINCT c.cID, c.cName 
    FROM customer c 
    WHERE c.cID NOT IN 
    (SELECT DISTINCT p.cID FROM purchase p)
'''
pd.read_sql_query(query_nopurchase_jumbo, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      4     Daan
#[Out]# ..   ...      ...
#[Out]# 177  181     Liva
#[Out]# 178  182  Johanna
#[Out]# 179  183    Nikki
#[Out]# 180  184    Wilko
#[Out]# 181  190   Kostas
#[Out]# 
#[Out]# [182 rows x 2 columns]
# Tue, 01 Dec 2020 14:27:27
vis.visualize(query_nopurchase_jumbo, schema)
# Tue, 01 Dec 2020 14:29:44
query_5 = '''
    SELECT c.cID, c.cName, p.pID, p.pName
    FROM customer c, product p
    WHERE (c.cID, p.pID) 
    NOT IN (SELECT pu.cID, pu.pID
            FROM purchase pu)
'''
pd.read_sql_query(query_5, conn)
#[Out]#       cID   cName  pID            pName
#[Out]# 0       0    Noah    0      Cashew Nuts
#[Out]# 1       0    Noah    1       Mixed Nuts
#[Out]# 2       0    Noah    2         Potatoes
#[Out]# 3       0    Noah    3     Green Pepper
#[Out]# 4       0    Noah    4           Onions
#[Out]# ...   ...     ...  ...              ...
#[Out]# 5607  190  Kostas   16             Rice
#[Out]# 5608  190  Kostas   24          Oranges
#[Out]# 5609  190  Kostas   29           Salmon
#[Out]# 5610  190  Kostas   30          Ketchup
#[Out]# 5611  190  Kostas   31  French baguette
#[Out]# 
#[Out]# [5612 rows x 4 columns]
# Tue, 01 Dec 2020 14:30:42
query_5 = '''
    SELECT c.cID, c.cName, p.pID, p.pName
    FROM customer c, product p
    
'''
pd.read_sql_query(query_5, conn)
#[Out]#       cID   cName  pID            pName
#[Out]# 0       0    Noah    0      Cashew Nuts
#[Out]# 1       0    Noah    1       Mixed Nuts
#[Out]# 2       0    Noah    2         Potatoes
#[Out]# 3       0    Noah    3     Green Pepper
#[Out]# 4       0    Noah    4           Onions
#[Out]# ...   ...     ...  ...              ...
#[Out]# 6075  190  Kostas   27            Pizza
#[Out]# 6076  190  Kostas   28          Lasanga
#[Out]# 6077  190  Kostas   29           Salmon
#[Out]# 6078  190  Kostas   30          Ketchup
#[Out]# 6079  190  Kostas   31  French baguette
#[Out]# 
#[Out]# [6080 rows x 4 columns]
# Tue, 01 Dec 2020 14:31:15
query_5 = '''
    SELECT c.cID, c.cName, p.pID, p.pName
    FROM customer c, product p
    WHERE (c.cID, p.pID) 
    NOT IN (SELECT pu.cID, pu.pID
            FROM purchase pu)
'''
pd.read_sql_query('''SELECT pu.cID, pu.pID
            FROM purchase pu''', conn)
#[Out]#      cID  pID
#[Out]# 0      0   10
#[Out]# 1      1   14
#[Out]# 2      1   16
#[Out]# 3      1    9
#[Out]# 4      1   25
#[Out]# ..   ...  ...
#[Out]# 504  190   17
#[Out]# 505  190    5
#[Out]# 506  190   19
#[Out]# 507  190    9
#[Out]# 508  190   18
#[Out]# 
#[Out]# [509 rows x 2 columns]


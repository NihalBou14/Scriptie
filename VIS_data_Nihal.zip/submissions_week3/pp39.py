# IPython log file

# Sat, 28 Nov 2020 22:03:10
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:05:57
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Sat, 28 Nov 2020 22:05:59
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:06:02
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1a76d7d3f80>
# Sat, 28 Nov 2020 22:06:30
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:06:43
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x000001A76D7D3F80>
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Sat, 28 Nov 2020 22:06:48
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:06:52
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Sat, 28 Nov 2020 22:06:53
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Sat, 28 Nov 2020 22:07:18
query3_2 = '''
    PUT YOUR QUERY HERE
'''
# Sat, 28 Nov 2020 22:07:36
query3_2 = '''
    SELECT * FROM customer
'''
# Sat, 28 Nov 2020 22:07:36
vis.visualize(query3_2, schema)
# Sat, 28 Nov 2020 22:07:43
pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName            street       city
#[Out]# 0      0    Noah         Koestraat    Utrecht
#[Out]# 1      1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 3      3    Finn     Stationsplein      Breda
#[Out]# 4      4    Daan      Kalverstraat  Amsterdam
#[Out]# ..   ...     ...               ...        ...
#[Out]# 185  185    Nick            Verweg  Eindhoven
#[Out]# 186  186  Angela          Dichtweg  Eindhoven
#[Out]# 187  188    Pino        Maanstraat  Rotterdam
#[Out]# 188  189    Koen          Akkerweg        Oss
#[Out]# 189  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Sat, 28 Nov 2020 22:27:41
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID AND c.cID = p.cID AND p.date LIKE '%2018%' AND p.date = s.date
'''
# Sat, 28 Nov 2020 22:27:41
vis.visualize(query3_2, schema)
# Sat, 28 Nov 2020 22:27:45
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sat, 28 Nov 2020 22:41:16
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 181
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0  181  2018-08-27
#[Out]# 1  181  2018-08-24
#[Out]# 2  181  2018-08-27
#[Out]# 3  181  2018-08-24
# Sat, 28 Nov 2020 23:17:01
query3_3 = '''
    SELECT DISTINCT cID, cName 
    FROM customer 
    WHERE cID NOT IN (
        SELECT c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID AND s.sID = p.sID AND s.sName='Jumbo');
'''
# Sat, 28 Nov 2020 23:17:01
vis.visualize(query3_3, schema)
# Sat, 28 Nov 2020 23:17:15
pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# ..   ...      ...
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]

# IPython log file

# Sun, 29 Nov 2020 11:21:45
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 29 Nov 2020 11:21:46
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Sun, 29 Nov 2020 11:21:53
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Sun, 29 Nov 2020 11:21:55
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID AND c.cID = p.cID AND p.date LIKE '%2018%' AND p.date = s.date
'''
# Sun, 29 Nov 2020 11:21:55
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 11:21:58
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 11:21:59
query3_3 = '''
    SELECT DISTINCT cID, cName 
    FROM customer 
    WHERE cID NOT IN (
        SELECT c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID AND s.sID = p.sID AND s.sName='Kumar');
'''
# Sun, 29 Nov 2020 11:22:01
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 11:22:04
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 11:22:07
query3_4 = '''
SELECT DISTINCT c1.cID, c1.cName 
FROM customer as c1, purchase as p1, store as s1
WHERE c1.cID = p1.cID AND s1.sID = p1.sID AND s1.sName = 'Jumbo'
AND c1.cID NOT IN (
SELECT c.cID 
FROM customer as c, purchase as p, store as s
WHERE c.cID = p.cID AND s.sID = p.sID AND s.sName != 'Jumbo')
'''
# Sun, 29 Nov 2020 11:22:08
vis.visualize(query3_4, schema)
# Sun, 29 Nov 2020 11:22:12
pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen


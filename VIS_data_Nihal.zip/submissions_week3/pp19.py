# IPython log file

# Wed, 02 Dec 2020 09:10:50
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 09:11:03
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x28c8e58db90>
# Wed, 02 Dec 2020 09:16:37
query3_2 = '''
    SELECT c.cID, c.cName
FROM customer as c, shoppinglist as s, purchase as p
WHERE c.cID=s.cID, c.cID=p.pID, p.date=s.date, p.date=_2018
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:23:09
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE EXCEPT (SELECT c.cID
             FROM customer as c, purchase as p, store as s
             WHERE c.cID=p.cID, p.sID=s.sID, s.sName="Kumar")
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 09:23:19
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE 
EXCEPT (SELECT c.cID
             FROM customer as c, purchase as p, store as s
             WHERE c.cID=p.cID, p.sID=s.sID, s.sName="Kumar")
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 09:23:34
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE 
EXCEPT (SELECT c.cID
        FROM customer as c, purchase as p, store as s
             WHERE c.cID=p.cID, p.sID=s.sID, s.sName="Kumar")
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 09:25:57
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
EXCEPT (SELECT c.cID
        FROM customer as c, purchase as p, store as s
             WHERE c.cID=p.cID, p.sID=s.sID, s.sName="Kumar")
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 09:26:22
query3_2 = '''
SELECT c.cID, c.cName
FROM customer as c, shoppinglist as s, purchase as p
WHERE c.cID=s.cID, c.cID=p.pID, p.date=s.date, p.date=2018
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:28:14
query3_2 = '''
SELECT c.cID, c.cName
FROM customer as c, shoppinglist as s, purchase as p
WHERE c.cID=s.cID, c.cID=p.pID, p.date=s.date, p.date="2018"
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:28:15
query3_2 = '''
SELECT c.cID, c.cName
FROM customer as c, shoppinglist as s, purchase as p
WHERE c.cID=s.cID, c.cID=p.pID, p.date=s.date, p.date="2018"
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:28:13
query3_2 = '''
SELECT c.cID, c.cName
FROM customer as c, shoppinglist as s, purchase as p
WHERE c.cID=s.cID, c.cID=p.pID, p.date=s.date, p.date="2018";
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:28:23
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID, customer.cID=purchase.pID, purchase.date=shoppinglist.date, purchase.date="2018";
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:28:54
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.pID AND purchase.date=shoppinglist.date AND purchase.date="2018";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:30:18
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
EXCEPT (SELECT c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Kumar")
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:30:33
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
NOT IN (SELECT c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Kumar")
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:30:49
query3_4 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE NOT IN (SELECT c.cID
             FROM customer as c, purchase as p, store as s
             WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName!="Kumar")
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:31:58
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.pID AND purchase.date=shoppinglist.date AND purchase.date="*2018";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:32:03
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.pID AND purchase.date=shoppinglist.date AND purchase.date="%2018";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:32:05
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.pID AND purchase.date=shoppinglist.date AND purchase.date="_2018";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:32:48
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
NOT IN SELECT c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Kumar"
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:33:46
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
NOT IN 
SELECT c.cID
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Kumar"
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:34:12
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.cID AND purchase.date=shoppinglist.date AND purchase.date="_2018";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:34:44
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.cID AND purchase.date=shoppinglist.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      1    Sem
#[Out]# 2      1    Sem
#[Out]# 3      1    Sem
#[Out]# 4      1    Sem
#[Out]# 5      1    Sem
#[Out]# 6      1    Sem
#[Out]# 7      1    Sem
#[Out]# 8      1    Sem
#[Out]# 9      1    Sem
#[Out]# 10     1    Sem
#[Out]# 11     1    Sem
#[Out]# 12     1    Sem
#[Out]# 13     1    Sem
#[Out]# 14     1    Sem
#[Out]# 15     1    Sem
#[Out]# 16     1    Sem
#[Out]# 17     1    Sem
#[Out]# 18     1    Sem
#[Out]# 19     1    Sem
#[Out]# 20     1    Sem
#[Out]# 21     1    Sem
#[Out]# 22     1    Sem
#[Out]# 23     1    Sem
#[Out]# 24     1    Sem
#[Out]# 25     1    Sem
#[Out]# 26     1    Sem
#[Out]# 27     1    Sem
#[Out]# 28     1    Sem
#[Out]# 29     1    Sem
#[Out]# ..   ...    ...
#[Out]# 946  176  Amira
#[Out]# 947  178   Elif
#[Out]# 948  178   Elif
#[Out]# 949  178   Elif
#[Out]# 950  178   Elif
#[Out]# 951  179   Juul
#[Out]# 952  179   Juul
#[Out]# 953  179   Juul
#[Out]# 954  179   Juul
#[Out]# 955  179   Juul
#[Out]# 956  179   Juul
#[Out]# 957  179   Juul
#[Out]# 958  179   Juul
#[Out]# 959  179   Juul
#[Out]# 960  179   Juul
#[Out]# 961  179   Juul
#[Out]# 962  179   Juul
#[Out]# 963  179   Juul
#[Out]# 964  179   Juul
#[Out]# 965  179   Juul
#[Out]# 966  180  Merel
#[Out]# 967  180  Merel
#[Out]# 968  180  Merel
#[Out]# 969  180  Merel
#[Out]# 970  181   Liva
#[Out]# 971  181   Liva
#[Out]# 972  181   Liva
#[Out]# 973  181   Liva
#[Out]# 974  181   Liva
#[Out]# 975  181   Liva
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Wed, 02 Dec 2020 12:35:24
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.cID AND purchase.date=shoppinglist.date AND shoppinglist.date=2018;
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:35:31
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.cID AND purchase.date=shoppinglist.date AND shoppinglist.date="2018";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:35:32
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.cID AND purchase.date=shoppinglist.date AND shoppinglist.date="2018";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:39:41
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s

'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cID   cName
#[Out]# 0          0    Noah
#[Out]# 1          0    Noah
#[Out]# 2          0    Noah
#[Out]# 3          0    Noah
#[Out]# 4          0    Noah
#[Out]# 5          0    Noah
#[Out]# 6          0    Noah
#[Out]# 7          0    Noah
#[Out]# 8          0    Noah
#[Out]# 9          0    Noah
#[Out]# 10         0    Noah
#[Out]# 11         0    Noah
#[Out]# 12         0    Noah
#[Out]# 13         0    Noah
#[Out]# 14         0    Noah
#[Out]# 15         0    Noah
#[Out]# 16         0    Noah
#[Out]# 17         0    Noah
#[Out]# 18         0    Noah
#[Out]# 19         0    Noah
#[Out]# 20         0    Noah
#[Out]# 21         0    Noah
#[Out]# 22         0    Noah
#[Out]# 23         0    Noah
#[Out]# 24         0    Noah
#[Out]# 25         0    Noah
#[Out]# 26         0    Noah
#[Out]# 27         0    Noah
#[Out]# 28         0    Noah
#[Out]# 29         0    Noah
#[Out]# ...      ...     ...
#[Out]# 6189410  190  Kostas
#[Out]# 6189411  190  Kostas
#[Out]# 6189412  190  Kostas
#[Out]# 6189413  190  Kostas
#[Out]# 6189414  190  Kostas
#[Out]# 6189415  190  Kostas
#[Out]# 6189416  190  Kostas
#[Out]# 6189417  190  Kostas
#[Out]# 6189418  190  Kostas
#[Out]# 6189419  190  Kostas
#[Out]# 6189420  190  Kostas
#[Out]# 6189421  190  Kostas
#[Out]# 6189422  190  Kostas
#[Out]# 6189423  190  Kostas
#[Out]# 6189424  190  Kostas
#[Out]# 6189425  190  Kostas
#[Out]# 6189426  190  Kostas
#[Out]# 6189427  190  Kostas
#[Out]# 6189428  190  Kostas
#[Out]# 6189429  190  Kostas
#[Out]# 6189430  190  Kostas
#[Out]# 6189431  190  Kostas
#[Out]# 6189432  190  Kostas
#[Out]# 6189433  190  Kostas
#[Out]# 6189434  190  Kostas
#[Out]# 6189435  190  Kostas
#[Out]# 6189436  190  Kostas
#[Out]# 6189437  190  Kostas
#[Out]# 6189438  190  Kostas
#[Out]# 6189439  190  Kostas
#[Out]# 
#[Out]# [6189440 rows x 2 columns]
# Wed, 02 Dec 2020 12:40:06
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
NOT IN 
SELECT c.cID
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Kumar"

'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:40:18
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
NOT IN 
SELECT c.cID
FROM customer as c, purchase as p, store as s


'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:40:34
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE NOT IN 
SELECT c.cID
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Kumar"

'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:40:38
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
NOT IN 
SELECT c.cID
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Kumar"

'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:41:31
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE c.cID NOT IN 
(SELECT c.cID
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Kumar")

'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cID   cName
#[Out]# 0          0    Noah
#[Out]# 1          0    Noah
#[Out]# 2          0    Noah
#[Out]# 3          0    Noah
#[Out]# 4          0    Noah
#[Out]# 5          0    Noah
#[Out]# 6          0    Noah
#[Out]# 7          0    Noah
#[Out]# 8          0    Noah
#[Out]# 9          0    Noah
#[Out]# 10         0    Noah
#[Out]# 11         0    Noah
#[Out]# 12         0    Noah
#[Out]# 13         0    Noah
#[Out]# 14         0    Noah
#[Out]# 15         0    Noah
#[Out]# 16         0    Noah
#[Out]# 17         0    Noah
#[Out]# 18         0    Noah
#[Out]# 19         0    Noah
#[Out]# 20         0    Noah
#[Out]# 21         0    Noah
#[Out]# 22         0    Noah
#[Out]# 23         0    Noah
#[Out]# 24         0    Noah
#[Out]# 25         0    Noah
#[Out]# 26         0    Noah
#[Out]# 27         0    Noah
#[Out]# 28         0    Noah
#[Out]# 29         0    Noah
#[Out]# ...      ...     ...
#[Out]# 6189410  190  Kostas
#[Out]# 6189411  190  Kostas
#[Out]# 6189412  190  Kostas
#[Out]# 6189413  190  Kostas
#[Out]# 6189414  190  Kostas
#[Out]# 6189415  190  Kostas
#[Out]# 6189416  190  Kostas
#[Out]# 6189417  190  Kostas
#[Out]# 6189418  190  Kostas
#[Out]# 6189419  190  Kostas
#[Out]# 6189420  190  Kostas
#[Out]# 6189421  190  Kostas
#[Out]# 6189422  190  Kostas
#[Out]# 6189423  190  Kostas
#[Out]# 6189424  190  Kostas
#[Out]# 6189425  190  Kostas
#[Out]# 6189426  190  Kostas
#[Out]# 6189427  190  Kostas
#[Out]# 6189428  190  Kostas
#[Out]# 6189429  190  Kostas
#[Out]# 6189430  190  Kostas
#[Out]# 6189431  190  Kostas
#[Out]# 6189432  190  Kostas
#[Out]# 6189433  190  Kostas
#[Out]# 6189434  190  Kostas
#[Out]# 6189435  190  Kostas
#[Out]# 6189436  190  Kostas
#[Out]# 6189437  190  Kostas
#[Out]# 6189438  190  Kostas
#[Out]# 6189439  190  Kostas
#[Out]# 
#[Out]# [6189440 rows x 2 columns]
# Wed, 02 Dec 2020 12:41:50
query3_4 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE c.cID NOT IN (SELECT c.cID
             FROM customer as c, purchase as p, store as s
             WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName!="Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#          cID  cName
#[Out]# 0          6  Milan
#[Out]# 1          6  Milan
#[Out]# 2          6  Milan
#[Out]# 3          6  Milan
#[Out]# 4          6  Milan
#[Out]# 5          6  Milan
#[Out]# 6          6  Milan
#[Out]# 7          6  Milan
#[Out]# 8          6  Milan
#[Out]# 9          6  Milan
#[Out]# 10         6  Milan
#[Out]# 11         6  Milan
#[Out]# 12         6  Milan
#[Out]# 13         6  Milan
#[Out]# 14         6  Milan
#[Out]# 15         6  Milan
#[Out]# 16         6  Milan
#[Out]# 17         6  Milan
#[Out]# 18         6  Milan
#[Out]# 19         6  Milan
#[Out]# 20         6  Milan
#[Out]# 21         6  Milan
#[Out]# 22         6  Milan
#[Out]# 23         6  Milan
#[Out]# 24         6  Milan
#[Out]# 25         6  Milan
#[Out]# 26         6  Milan
#[Out]# 27         6  Milan
#[Out]# 28         6  Milan
#[Out]# 29         6  Milan
#[Out]# ...      ...    ...
#[Out]# 1889378  183  Nikki
#[Out]# 1889379  183  Nikki
#[Out]# 1889380  183  Nikki
#[Out]# 1889381  183  Nikki
#[Out]# 1889382  183  Nikki
#[Out]# 1889383  183  Nikki
#[Out]# 1889384  183  Nikki
#[Out]# 1889385  183  Nikki
#[Out]# 1889386  183  Nikki
#[Out]# 1889387  183  Nikki
#[Out]# 1889388  183  Nikki
#[Out]# 1889389  183  Nikki
#[Out]# 1889390  183  Nikki
#[Out]# 1889391  183  Nikki
#[Out]# 1889392  183  Nikki
#[Out]# 1889393  183  Nikki
#[Out]# 1889394  183  Nikki
#[Out]# 1889395  183  Nikki
#[Out]# 1889396  183  Nikki
#[Out]# 1889397  183  Nikki
#[Out]# 1889398  183  Nikki
#[Out]# 1889399  183  Nikki
#[Out]# 1889400  183  Nikki
#[Out]# 1889401  183  Nikki
#[Out]# 1889402  183  Nikki
#[Out]# 1889403  183  Nikki
#[Out]# 1889404  183  Nikki
#[Out]# 1889405  183  Nikki
#[Out]# 1889406  183  Nikki
#[Out]# 1889407  183  Nikki
#[Out]# 
#[Out]# [1889408 rows x 2 columns]
# Wed, 02 Dec 2020 12:42:41
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE c.cID NOT IN 
(SELECT c.cID
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Lidl")

'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cID cName
#[Out]# 0          0  Noah
#[Out]# 1          0  Noah
#[Out]# 2          0  Noah
#[Out]# 3          0  Noah
#[Out]# 4          0  Noah
#[Out]# 5          0  Noah
#[Out]# 6          0  Noah
#[Out]# 7          0  Noah
#[Out]# 8          0  Noah
#[Out]# 9          0  Noah
#[Out]# 10         0  Noah
#[Out]# 11         0  Noah
#[Out]# 12         0  Noah
#[Out]# 13         0  Noah
#[Out]# 14         0  Noah
#[Out]# 15         0  Noah
#[Out]# 16         0  Noah
#[Out]# 17         0  Noah
#[Out]# 18         0  Noah
#[Out]# 19         0  Noah
#[Out]# 20         0  Noah
#[Out]# 21         0  Noah
#[Out]# 22         0  Noah
#[Out]# 23         0  Noah
#[Out]# 24         0  Noah
#[Out]# 25         0  Noah
#[Out]# 26         0  Noah
#[Out]# 27         0  Noah
#[Out]# 28         0  Noah
#[Out]# 29         0  Noah
#[Out]# ...      ...   ...
#[Out]# 4918946  189  Koen
#[Out]# 4918947  189  Koen
#[Out]# 4918948  189  Koen
#[Out]# 4918949  189  Koen
#[Out]# 4918950  189  Koen
#[Out]# 4918951  189  Koen
#[Out]# 4918952  189  Koen
#[Out]# 4918953  189  Koen
#[Out]# 4918954  189  Koen
#[Out]# 4918955  189  Koen
#[Out]# 4918956  189  Koen
#[Out]# 4918957  189  Koen
#[Out]# 4918958  189  Koen
#[Out]# 4918959  189  Koen
#[Out]# 4918960  189  Koen
#[Out]# 4918961  189  Koen
#[Out]# 4918962  189  Koen
#[Out]# 4918963  189  Koen
#[Out]# 4918964  189  Koen
#[Out]# 4918965  189  Koen
#[Out]# 4918966  189  Koen
#[Out]# 4918967  189  Koen
#[Out]# 4918968  189  Koen
#[Out]# 4918969  189  Koen
#[Out]# 4918970  189  Koen
#[Out]# 4918971  189  Koen
#[Out]# 4918972  189  Koen
#[Out]# 4918973  189  Koen
#[Out]# 4918974  189  Koen
#[Out]# 4918975  189  Koen
#[Out]# 
#[Out]# [4918976 rows x 2 columns]
# Wed, 02 Dec 2020 12:42:55
query3_4 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE c.cID NOT IN (SELECT c.cID
             FROM customer as c, purchase as p, store as s
             WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName!="Coop")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#          cID  cName
#[Out]# 0          6  Milan
#[Out]# 1          6  Milan
#[Out]# 2          6  Milan
#[Out]# 3          6  Milan
#[Out]# 4          6  Milan
#[Out]# 5          6  Milan
#[Out]# 6          6  Milan
#[Out]# 7          6  Milan
#[Out]# 8          6  Milan
#[Out]# 9          6  Milan
#[Out]# 10         6  Milan
#[Out]# 11         6  Milan
#[Out]# 12         6  Milan
#[Out]# 13         6  Milan
#[Out]# 14         6  Milan
#[Out]# 15         6  Milan
#[Out]# 16         6  Milan
#[Out]# 17         6  Milan
#[Out]# 18         6  Milan
#[Out]# 19         6  Milan
#[Out]# 20         6  Milan
#[Out]# 21         6  Milan
#[Out]# 22         6  Milan
#[Out]# 23         6  Milan
#[Out]# 24         6  Milan
#[Out]# 25         6  Milan
#[Out]# 26         6  Milan
#[Out]# 27         6  Milan
#[Out]# 28         6  Milan
#[Out]# 29         6  Milan
#[Out]# ...      ...    ...
#[Out]# 2345442  184  Wilko
#[Out]# 2345443  184  Wilko
#[Out]# 2345444  184  Wilko
#[Out]# 2345445  184  Wilko
#[Out]# 2345446  184  Wilko
#[Out]# 2345447  184  Wilko
#[Out]# 2345448  184  Wilko
#[Out]# 2345449  184  Wilko
#[Out]# 2345450  184  Wilko
#[Out]# 2345451  184  Wilko
#[Out]# 2345452  184  Wilko
#[Out]# 2345453  184  Wilko
#[Out]# 2345454  184  Wilko
#[Out]# 2345455  184  Wilko
#[Out]# 2345456  184  Wilko
#[Out]# 2345457  184  Wilko
#[Out]# 2345458  184  Wilko
#[Out]# 2345459  184  Wilko
#[Out]# 2345460  184  Wilko
#[Out]# 2345461  184  Wilko
#[Out]# 2345462  184  Wilko
#[Out]# 2345463  184  Wilko
#[Out]# 2345464  184  Wilko
#[Out]# 2345465  184  Wilko
#[Out]# 2345466  184  Wilko
#[Out]# 2345467  184  Wilko
#[Out]# 2345468  184  Wilko
#[Out]# 2345469  184  Wilko
#[Out]# 2345470  184  Wilko
#[Out]# 2345471  184  Wilko
#[Out]# 
#[Out]# [2345472 rows x 2 columns]
# Wed, 02 Dec 2020 12:43:19
query3_4 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE c.cID NOT IN (SELECT c.cID
             FROM customer as c, purchase as p, store as s
             WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName!="Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#          cID  cName
#[Out]# 0          6  Milan
#[Out]# 1          6  Milan
#[Out]# 2          6  Milan
#[Out]# 3          6  Milan
#[Out]# 4          6  Milan
#[Out]# 5          6  Milan
#[Out]# 6          6  Milan
#[Out]# 7          6  Milan
#[Out]# 8          6  Milan
#[Out]# 9          6  Milan
#[Out]# 10         6  Milan
#[Out]# 11         6  Milan
#[Out]# 12         6  Milan
#[Out]# 13         6  Milan
#[Out]# 14         6  Milan
#[Out]# 15         6  Milan
#[Out]# 16         6  Milan
#[Out]# 17         6  Milan
#[Out]# 18         6  Milan
#[Out]# 19         6  Milan
#[Out]# 20         6  Milan
#[Out]# 21         6  Milan
#[Out]# 22         6  Milan
#[Out]# 23         6  Milan
#[Out]# 24         6  Milan
#[Out]# 25         6  Milan
#[Out]# 26         6  Milan
#[Out]# 27         6  Milan
#[Out]# 28         6  Milan
#[Out]# 29         6  Milan
#[Out]# ...      ...    ...
#[Out]# 1889378  183  Nikki
#[Out]# 1889379  183  Nikki
#[Out]# 1889380  183  Nikki
#[Out]# 1889381  183  Nikki
#[Out]# 1889382  183  Nikki
#[Out]# 1889383  183  Nikki
#[Out]# 1889384  183  Nikki
#[Out]# 1889385  183  Nikki
#[Out]# 1889386  183  Nikki
#[Out]# 1889387  183  Nikki
#[Out]# 1889388  183  Nikki
#[Out]# 1889389  183  Nikki
#[Out]# 1889390  183  Nikki
#[Out]# 1889391  183  Nikki
#[Out]# 1889392  183  Nikki
#[Out]# 1889393  183  Nikki
#[Out]# 1889394  183  Nikki
#[Out]# 1889395  183  Nikki
#[Out]# 1889396  183  Nikki
#[Out]# 1889397  183  Nikki
#[Out]# 1889398  183  Nikki
#[Out]# 1889399  183  Nikki
#[Out]# 1889400  183  Nikki
#[Out]# 1889401  183  Nikki
#[Out]# 1889402  183  Nikki
#[Out]# 1889403  183  Nikki
#[Out]# 1889404  183  Nikki
#[Out]# 1889405  183  Nikki
#[Out]# 1889406  183  Nikki
#[Out]# 1889407  183  Nikki
#[Out]# 
#[Out]# [1889408 rows x 2 columns]
# Wed, 02 Dec 2020 12:44:37
query3_3 = '''
SELECT c.cID, c.cName
FROM customer as c, purchase as p, store as s
WHERE c.cID NOT IN 
(SELECT c.cID
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.sName="Kumar");

'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cID   cName
#[Out]# 0          0    Noah
#[Out]# 1          0    Noah
#[Out]# 2          0    Noah
#[Out]# 3          0    Noah
#[Out]# 4          0    Noah
#[Out]# 5          0    Noah
#[Out]# 6          0    Noah
#[Out]# 7          0    Noah
#[Out]# 8          0    Noah
#[Out]# 9          0    Noah
#[Out]# 10         0    Noah
#[Out]# 11         0    Noah
#[Out]# 12         0    Noah
#[Out]# 13         0    Noah
#[Out]# 14         0    Noah
#[Out]# 15         0    Noah
#[Out]# 16         0    Noah
#[Out]# 17         0    Noah
#[Out]# 18         0    Noah
#[Out]# 19         0    Noah
#[Out]# 20         0    Noah
#[Out]# 21         0    Noah
#[Out]# 22         0    Noah
#[Out]# 23         0    Noah
#[Out]# 24         0    Noah
#[Out]# 25         0    Noah
#[Out]# 26         0    Noah
#[Out]# 27         0    Noah
#[Out]# 28         0    Noah
#[Out]# 29         0    Noah
#[Out]# ...      ...     ...
#[Out]# 6189410  190  Kostas
#[Out]# 6189411  190  Kostas
#[Out]# 6189412  190  Kostas
#[Out]# 6189413  190  Kostas
#[Out]# 6189414  190  Kostas
#[Out]# 6189415  190  Kostas
#[Out]# 6189416  190  Kostas
#[Out]# 6189417  190  Kostas
#[Out]# 6189418  190  Kostas
#[Out]# 6189419  190  Kostas
#[Out]# 6189420  190  Kostas
#[Out]# 6189421  190  Kostas
#[Out]# 6189422  190  Kostas
#[Out]# 6189423  190  Kostas
#[Out]# 6189424  190  Kostas
#[Out]# 6189425  190  Kostas
#[Out]# 6189426  190  Kostas
#[Out]# 6189427  190  Kostas
#[Out]# 6189428  190  Kostas
#[Out]# 6189429  190  Kostas
#[Out]# 6189430  190  Kostas
#[Out]# 6189431  190  Kostas
#[Out]# 6189432  190  Kostas
#[Out]# 6189433  190  Kostas
#[Out]# 6189434  190  Kostas
#[Out]# 6189435  190  Kostas
#[Out]# 6189436  190  Kostas
#[Out]# 6189437  190  Kostas
#[Out]# 6189438  190  Kostas
#[Out]# 6189439  190  Kostas
#[Out]# 
#[Out]# [6189440 rows x 2 columns]
# Wed, 02 Dec 2020 12:46:44
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.cID AND purchase.date=shoppinglist.date AND purchase.date="%2018%";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:49:55
query3_2 = '''
SELECT customer.cID, customer.cName
FROM customer, shoppinglist, purchase
WHERE customer.cID=shoppinglist.cID AND customer.cID=purchase.cID AND purchase.date=shoppinglist.date AND purchase.date LIKE "%2018%";
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      1    Sem
#[Out]# 2      1    Sem
#[Out]# 3      1    Sem
#[Out]# 4      1    Sem
#[Out]# 5      1    Sem
#[Out]# 6      1    Sem
#[Out]# 7      1    Sem
#[Out]# 8      1    Sem
#[Out]# 9      1    Sem
#[Out]# 10     1    Sem
#[Out]# 11     1    Sem
#[Out]# 12     1    Sem
#[Out]# 13     1    Sem
#[Out]# 14     1    Sem
#[Out]# 15     1    Sem
#[Out]# 16     1    Sem
#[Out]# 17     1    Sem
#[Out]# 18     1    Sem
#[Out]# 19     1    Sem
#[Out]# 20     1    Sem
#[Out]# 21     1    Sem
#[Out]# 22     1    Sem
#[Out]# 23     1    Sem
#[Out]# 24     1    Sem
#[Out]# 25     1    Sem
#[Out]# 26     1    Sem
#[Out]# 27     1    Sem
#[Out]# 28     1    Sem
#[Out]# 29     1    Sem
#[Out]# ..   ...    ...
#[Out]# 946  176  Amira
#[Out]# 947  178   Elif
#[Out]# 948  178   Elif
#[Out]# 949  178   Elif
#[Out]# 950  178   Elif
#[Out]# 951  179   Juul
#[Out]# 952  179   Juul
#[Out]# 953  179   Juul
#[Out]# 954  179   Juul
#[Out]# 955  179   Juul
#[Out]# 956  179   Juul
#[Out]# 957  179   Juul
#[Out]# 958  179   Juul
#[Out]# 959  179   Juul
#[Out]# 960  179   Juul
#[Out]# 961  179   Juul
#[Out]# 962  179   Juul
#[Out]# 963  179   Juul
#[Out]# 964  179   Juul
#[Out]# 965  179   Juul
#[Out]# 966  180  Merel
#[Out]# 967  180  Merel
#[Out]# 968  180  Merel
#[Out]# 969  180  Merel
#[Out]# 970  181   Liva
#[Out]# 971  181   Liva
#[Out]# 972  181   Liva
#[Out]# 973  181   Liva
#[Out]# 974  181   Liva
#[Out]# 975  181   Liva
#[Out]# 
#[Out]# [976 rows x 2 columns]

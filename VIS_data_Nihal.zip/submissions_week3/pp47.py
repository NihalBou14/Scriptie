# IPython log file

# Sun, 29 Nov 2020 15:30:58
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 29 Nov 2020 15:31:11
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1977eb9d490>
# Sun, 29 Nov 2020 15:31:30
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Sun, 29 Nov 2020 15:44:48
query3_2 = '''
    SELECT * 
    FROM customer AS c 
    WHERE city = "Amsterdam" OR city = "Utrecht"
'''
# Sun, 29 Nov 2020 15:44:49
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 15:45:02
query3_2 = '''
    SELECT c.cName 
FROM customer AS c, purchase AS p 
WHERE p.cID = c.cID;
'''
# Sun, 29 Nov 2020 15:45:03
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 15:45:16
query3_2 = '''
    SELECT c.cName 
FROM customer AS c 
WHERE EXISTS (
    SELECT pr.pID 
    FROM purchase AS p, product AS pr 
    WHERE p.cID = c.cID 
    AND p.pID = pr.pID 
    AND pr.pID < 10);

'''
# Sun, 29 Nov 2020 15:45:18
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 17:35:11
query3_2 = '''
    select distinct cName, cID
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = p.date
'''
# Sun, 29 Nov 2020 17:35:11
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 17:35:29
pd.read_sql_query(query3_2, conn)
# Sun, 29 Nov 2020 17:35:48
query3_2 = '''
    select distinct c.cName, c.cID
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = p.date
'''
# Sun, 29 Nov 2020 17:35:49
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 17:35:50
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 17:42:32
query3_3 = '''
    select distinct c.cName, c.cID
    from customer as c
    where c.cID not in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName = "Jumbo")
'''
# Sun, 29 Nov 2020 17:42:33
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 17:42:51
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 17:45:13
# Note: just throwing an exploration query in here to get an idea of the dataset size
query3_4 = '''
    select cID
    from customer
'''
# Sun, 29 Nov 2020 17:45:13
vis.visualize(query3_4, schema)
# Sun, 29 Nov 2020 17:45:14
pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Sun, 29 Nov 2020 17:45:35
query3_3 = '''
    select distinct c.cName, c.cID
    from customer as c
    where c.cID not in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName = "Niet bestaande naam")
'''
# Sun, 29 Nov 2020 17:45:36
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 17:45:42
query3_3 = '''
    select distinct c.cName, c.cID
    from customer as c
    where c.cID not in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName = "Jumbo")
'''
# Sun, 29 Nov 2020 17:45:43
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 17:50:43
query3_3 = '''
    select distinct c.cName, c.cID
    from customer as c
    where c.cID not in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName = "Kumar")
'''
# Sun, 29 Nov 2020 17:50:44
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 17:56:21
# Note to self: "at least one at Jumbo and never at not Jumbo"
query3_4 = '''
    select c.cID, c.cName
    from customer as c
    where c.cID in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName = "Jumbo")
    and c.cID not in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName != "Jumbo")
'''
# Sun, 29 Nov 2020 17:56:21
vis.visualize(query3_4, schema)
# Sun, 29 Nov 2020 17:56:34
pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Sun, 29 Nov 2020 17:57:59
# Note to self: "at least one at Jumbo and never at not Jumbo"
query3_4 = '''
    select distinct c.cID, c.cName
    from customer as c
    where c.cID in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName = "Jumbo")
    and c.cID not in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName != "Jumbo")
'''
# Sun, 29 Nov 2020 17:58:03
pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Sun, 29 Nov 2020 18:02:42
# Note to self: "at least one at Jumbo and never at not Jumbo"
query3_4 = '''
    select distinct c.cID, c.cName
    from customer as c
    where c.cID in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName = "Kumar")
    and c.cID not in
        (select p.cID
         from purchase as p, store as s
         where p.sID = s.sID and s.sName != "Kumar")
'''
# Sun, 29 Nov 2020 18:02:43
vis.visualize(query3_4, schema)
# Sun, 29 Nov 2020 18:02:44
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sun, 29 Nov 2020 18:04:36
query3_2 = '''
    select distinct c.cName, c.cID
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = p.date and s.date = "%2018"
'''
# Sun, 29 Nov 2020 18:04:40
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Sun, 29 Nov 2020 18:06:09
query3_2 = '''
    select distinct c.cName, c.cID
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = p.date and s.date = "%2018%"
'''
# Sun, 29 Nov 2020 18:06:10
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Sun, 29 Nov 2020 18:06:35
query3_2 = '''
    select distinct c.cName, c.cID
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = p.date and p.date = "%2018%"
'''
# Sun, 29 Nov 2020 18:06:37
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Sun, 29 Nov 2020 18:10:18
# Why are there suddenly no results whatsoever when adding the "same date in 2018"?
query3_2 = '''
    select distinct c.cName, c.cID, s.date
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = "%2018%"
'''
# Sun, 29 Nov 2020 18:10:20
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, date]
#[Out]# Index: []
# Sun, 29 Nov 2020 19:44:43
# Why are there suddenly no results whatsoever when adding the "same date in 2018"?
# Breaks even without s.date = p.date???

query3_2 = '''
    select distinct c.cName, c.cID, s.date
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = p.date and s.date = "2018%"
'''
# Sun, 29 Nov 2020 19:44:44
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 19:44:45
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, date]
#[Out]# Index: []
# Sun, 29 Nov 2020 19:45:57
# Why are there suddenly no results whatsoever when adding the "same date in 2018"?
# Breaks even without s.date = p.date???

query3_2 = '''
    select distinct c.cName, c.cID
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = p.date and s.date = '2018%'
'''
# Sun, 29 Nov 2020 19:45:58
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 19:45:58
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Sun, 29 Nov 2020 19:46:26
# Why are there suddenly no results whatsoever when adding the "same date in 2018"?
# Breaks even without s.date = p.date???

query3_2 = '''
    select distinct c.cName, c.cID
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = p.date and s.date like '%2018%'
'''
# Sun, 29 Nov 2020 19:46:27
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 19:46:27
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 19:46:37
# Why are there suddenly no results whatsoever when adding the "same date in 2018"?
# Breaks even without s.date = p.date???

query3_2 = '''
    select distinct c.cName, c.cID
    from customer as c, shoppinglist as s, purchase as p
    where c.cID = s.cID and c.cID = p.cID
        and s.date = p.date
'''
# Sun, 29 Nov 2020 19:46:39
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]


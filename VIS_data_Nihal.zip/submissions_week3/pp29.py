# IPython log file

# Tue, 01 Dec 2020 12:00:18
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Tue, 01 Dec 2020 12:00:24
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 12:00:27
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1f0c3822b90>
# Tue, 01 Dec 2020 12:09:51
query3_2 = '''
    SELECT cName, cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and 
        s.date = '%2018% and'
        (EXISTS (SELECT *
            FROM purchase p
            WHERE c.cID = p.cID and 
            s.date = p.date))
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 12:10:04
query3_2 = '''
    SELECT cName, cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and 
        s.date = '%2018% and
        (EXISTS (SELECT *
            FROM purchase p
            WHERE c.cID = p.cID and 
            s.date = p.date))
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 12:10:36
query3_2 = '''
    SELECT cName, cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and 
        s.date = '%2018%' and
        (EXISTS (SELECT *
            FROM purchase p
            WHERE c.cID = p.cID and 
            s.date = p.date))
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 12:10:59
query3_2 = '''
    SELECT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and 
        s.date = '%2018%' and
        (EXISTS (SELECT *
            FROM purchase p
            WHERE c.cID = p.cID and 
            s.date = p.date))
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 12:11:28
query3_2 = '''
    SELECT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and 
        s.date = '2018%' and
        (EXISTS (SELECT *
            FROM purchase p
            WHERE c.cID = p.cID and 
            s.date = p.date))
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 12:11:52
query3_2 = '''
    SELECT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and 
        s.date = '2018%' and
        
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 12:11:56
query3_2 = '''
    SELECT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and 
        s.date = '2018%' 
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 12:12:10
query3_2 = '''
    SELECT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and 
        s.date = '%2018%' 
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 12:13:45
query3_2 = '''
    SELECT cName, c.cID
    FROM customer c, shoppinglist s
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1        Noah    0
#[Out]# 2        Noah    0
#[Out]# 3        Noah    0
#[Out]# 4        Noah    0
#[Out]# 5        Noah    0
#[Out]# 6        Noah    0
#[Out]# 7        Noah    0
#[Out]# 8        Noah    0
#[Out]# 9        Noah    0
#[Out]# 10       Noah    0
#[Out]# 11       Noah    0
#[Out]# 12       Noah    0
#[Out]# 13       Noah    0
#[Out]# 14       Noah    0
#[Out]# 15       Noah    0
#[Out]# 16       Noah    0
#[Out]# 17       Noah    0
#[Out]# 18       Noah    0
#[Out]# 19       Noah    0
#[Out]# 20       Noah    0
#[Out]# 21       Noah    0
#[Out]# 22       Noah    0
#[Out]# 23       Noah    0
#[Out]# 24       Noah    0
#[Out]# 25       Noah    0
#[Out]# 26       Noah    0
#[Out]# 27       Noah    0
#[Out]# 28       Noah    0
#[Out]# 29       Noah    0
#[Out]# ...       ...  ...
#[Out]# 93450  Kostas  190
#[Out]# 93451  Kostas  190
#[Out]# 93452  Kostas  190
#[Out]# 93453  Kostas  190
#[Out]# 93454  Kostas  190
#[Out]# 93455  Kostas  190
#[Out]# 93456  Kostas  190
#[Out]# 93457  Kostas  190
#[Out]# 93458  Kostas  190
#[Out]# 93459  Kostas  190
#[Out]# 93460  Kostas  190
#[Out]# 93461  Kostas  190
#[Out]# 93462  Kostas  190
#[Out]# 93463  Kostas  190
#[Out]# 93464  Kostas  190
#[Out]# 93465  Kostas  190
#[Out]# 93466  Kostas  190
#[Out]# 93467  Kostas  190
#[Out]# 93468  Kostas  190
#[Out]# 93469  Kostas  190
#[Out]# 93470  Kostas  190
#[Out]# 93471  Kostas  190
#[Out]# 93472  Kostas  190
#[Out]# 93473  Kostas  190
#[Out]# 93474  Kostas  190
#[Out]# 93475  Kostas  190
#[Out]# 93476  Kostas  190
#[Out]# 93477  Kostas  190
#[Out]# 93478  Kostas  190
#[Out]# 93479  Kostas  190
#[Out]# 
#[Out]# [93480 rows x 2 columns]
# Tue, 01 Dec 2020 12:14:02
query3_2 = '''
    SELECT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID ' 
        
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 12:14:05
query3_2 = '''
    SELECT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID 
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1      Sem    1
#[Out]# 2      Sem    1
#[Out]# 3      Sem    1
#[Out]# 4      Sem    1
#[Out]# 5      Sem    1
#[Out]# 6      Sem    1
#[Out]# 7      Sem    1
#[Out]# 8    Lucas    2
#[Out]# 9    Lucas    2
#[Out]# 10   Lucas    2
#[Out]# 11   Lucas    2
#[Out]# 12   Lucas    2
#[Out]# 13    Finn    3
#[Out]# 14    Finn    3
#[Out]# 15    Finn    3
#[Out]# 16    Levi    5
#[Out]# 17    Levi    5
#[Out]# 18    Levi    5
#[Out]# 19    Levi    5
#[Out]# 20    Levi    5
#[Out]# 21    Levi    5
#[Out]# 22    Bram    7
#[Out]# 23    Bram    7
#[Out]# 24    Bram    7
#[Out]# 25    Bram    7
#[Out]# 26    Bram    7
#[Out]# 27    Bram    7
#[Out]# 28    Liam    8
#[Out]# 29    Liam    8
#[Out]# ..     ...  ...
#[Out]# 462  Amira  176
#[Out]# 463  Amira  176
#[Out]# 464  Amira  176
#[Out]# 465  Amira  176
#[Out]# 466  Amira  176
#[Out]# 467  Amira  176
#[Out]# 468  Amira  176
#[Out]# 469  Amira  176
#[Out]# 470   Elif  178
#[Out]# 471   Elif  178
#[Out]# 472   Juul  179
#[Out]# 473   Juul  179
#[Out]# 474   Juul  179
#[Out]# 475   Juul  179
#[Out]# 476   Juul  179
#[Out]# 477   Juul  179
#[Out]# 478  Merel  180
#[Out]# 479  Merel  180
#[Out]# 480  Merel  180
#[Out]# 481   Liva  181
#[Out]# 482   Liva  181
#[Out]# 483   Liva  181
#[Out]# 484   Liva  181
#[Out]# 485  Nikki  183
#[Out]# 486  Nikki  183
#[Out]# 487  Nikki  183
#[Out]# 488  Nikki  183
#[Out]# 489  Nikki  183
#[Out]# 490  Nikki  183
#[Out]# 491  Nikki  183
#[Out]# 
#[Out]# [492 rows x 2 columns]
# Tue, 01 Dec 2020 12:14:15
query3_2 = '''
    SELECT cName, c.cID, date
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID 
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-20
#[Out]# 2      Sem    1  2018-08-20
#[Out]# 3      Sem    1  2018-08-20
#[Out]# 4      Sem    1  2018-08-20
#[Out]# 5      Sem    1  2018-08-20
#[Out]# 6      Sem    1  2018-08-20
#[Out]# 7      Sem    1  2018-08-21
#[Out]# 8    Lucas    2  2018-08-17
#[Out]# 9    Lucas    2  2018-08-16
#[Out]# 10   Lucas    2  2018-08-17
#[Out]# 11   Lucas    2  2018-08-16
#[Out]# 12   Lucas    2  2018-08-17
#[Out]# 13    Finn    3  2018-08-19
#[Out]# 14    Finn    3  2018-08-18
#[Out]# 15    Finn    3  2018-08-18
#[Out]# 16    Levi    5  2018-08-22
#[Out]# 17    Levi    5  2018-08-17
#[Out]# 18    Levi    5  2018-08-23
#[Out]# 19    Levi    5  2018-08-23
#[Out]# 20    Levi    5  2018-08-23
#[Out]# 21    Levi    5  2018-08-22
#[Out]# 22    Bram    7  2018-08-23
#[Out]# 23    Bram    7  2018-08-25
#[Out]# 24    Bram    7  2018-08-24
#[Out]# 25    Bram    7  2018-08-23
#[Out]# 26    Bram    7  2018-08-23
#[Out]# 27    Bram    7  2018-08-26
#[Out]# 28    Liam    8  2018-08-16
#[Out]# 29    Liam    8  2018-08-16
#[Out]# ..     ...  ...         ...
#[Out]# 462  Amira  176  2018-08-25
#[Out]# 463  Amira  176  2018-08-22
#[Out]# 464  Amira  176  2018-08-26
#[Out]# 465  Amira  176  2018-08-25
#[Out]# 466  Amira  176  2018-08-25
#[Out]# 467  Amira  176  2018-08-25
#[Out]# 468  Amira  176  2018-08-25
#[Out]# 469  Amira  176  2018-08-25
#[Out]# 470   Elif  178  2018-08-27
#[Out]# 471   Elif  178  2018-08-27
#[Out]# 472   Juul  179  2018-08-22
#[Out]# 473   Juul  179  2018-08-24
#[Out]# 474   Juul  179  2018-08-24
#[Out]# 475   Juul  179  2018-08-22
#[Out]# 476   Juul  179  2018-08-24
#[Out]# 477   Juul  179  2018-08-22
#[Out]# 478  Merel  180  2018-08-27
#[Out]# 479  Merel  180  2018-08-26
#[Out]# 480  Merel  180  2018-08-26
#[Out]# 481   Liva  181  2018-08-27
#[Out]# 482   Liva  181  2018-08-24
#[Out]# 483   Liva  181  2018-08-27
#[Out]# 484   Liva  181  2018-08-24
#[Out]# 485  Nikki  183  2018-08-19
#[Out]# 486  Nikki  183  2018-08-22
#[Out]# 487  Nikki  183  2018-08-20
#[Out]# 488  Nikki  183  2018-08-21
#[Out]# 489  Nikki  183  2018-08-22
#[Out]# 490  Nikki  183  2018-08-21
#[Out]# 491  Nikki  183  2018-08-22
#[Out]# 
#[Out]# [492 rows x 3 columns]
# Tue, 01 Dec 2020 12:14:39
query3_2 = '''
    SELECT cName, c.cID, date
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date = '2018%'
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, date]
#[Out]# Index: []
# Tue, 01 Dec 2020 12:14:42
query3_2 = '''
    SELECT cName, c.cID, date
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date = '2018'
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, date]
#[Out]# Index: []
# Tue, 01 Dec 2020 12:15:22
query3_2 = '''
    SELECT cName, c.cID, date
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date LIKE '%2018%'
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-20
#[Out]# 2      Sem    1  2018-08-20
#[Out]# 3      Sem    1  2018-08-20
#[Out]# 4      Sem    1  2018-08-20
#[Out]# 5      Sem    1  2018-08-20
#[Out]# 6      Sem    1  2018-08-20
#[Out]# 7      Sem    1  2018-08-21
#[Out]# 8    Lucas    2  2018-08-17
#[Out]# 9    Lucas    2  2018-08-16
#[Out]# 10   Lucas    2  2018-08-17
#[Out]# 11   Lucas    2  2018-08-16
#[Out]# 12   Lucas    2  2018-08-17
#[Out]# 13    Finn    3  2018-08-19
#[Out]# 14    Finn    3  2018-08-18
#[Out]# 15    Finn    3  2018-08-18
#[Out]# 16    Levi    5  2018-08-22
#[Out]# 17    Levi    5  2018-08-17
#[Out]# 18    Levi    5  2018-08-23
#[Out]# 19    Levi    5  2018-08-23
#[Out]# 20    Levi    5  2018-08-23
#[Out]# 21    Levi    5  2018-08-22
#[Out]# 22    Bram    7  2018-08-23
#[Out]# 23    Bram    7  2018-08-25
#[Out]# 24    Bram    7  2018-08-24
#[Out]# 25    Bram    7  2018-08-23
#[Out]# 26    Bram    7  2018-08-23
#[Out]# 27    Bram    7  2018-08-26
#[Out]# 28    Liam    8  2018-08-16
#[Out]# 29    Liam    8  2018-08-16
#[Out]# ..     ...  ...         ...
#[Out]# 462  Amira  176  2018-08-25
#[Out]# 463  Amira  176  2018-08-22
#[Out]# 464  Amira  176  2018-08-26
#[Out]# 465  Amira  176  2018-08-25
#[Out]# 466  Amira  176  2018-08-25
#[Out]# 467  Amira  176  2018-08-25
#[Out]# 468  Amira  176  2018-08-25
#[Out]# 469  Amira  176  2018-08-25
#[Out]# 470   Elif  178  2018-08-27
#[Out]# 471   Elif  178  2018-08-27
#[Out]# 472   Juul  179  2018-08-22
#[Out]# 473   Juul  179  2018-08-24
#[Out]# 474   Juul  179  2018-08-24
#[Out]# 475   Juul  179  2018-08-22
#[Out]# 476   Juul  179  2018-08-24
#[Out]# 477   Juul  179  2018-08-22
#[Out]# 478  Merel  180  2018-08-27
#[Out]# 479  Merel  180  2018-08-26
#[Out]# 480  Merel  180  2018-08-26
#[Out]# 481   Liva  181  2018-08-27
#[Out]# 482   Liva  181  2018-08-24
#[Out]# 483   Liva  181  2018-08-27
#[Out]# 484   Liva  181  2018-08-24
#[Out]# 485  Nikki  183  2018-08-19
#[Out]# 486  Nikki  183  2018-08-22
#[Out]# 487  Nikki  183  2018-08-20
#[Out]# 488  Nikki  183  2018-08-21
#[Out]# 489  Nikki  183  2018-08-22
#[Out]# 490  Nikki  183  2018-08-21
#[Out]# 491  Nikki  183  2018-08-22
#[Out]# 
#[Out]# [492 rows x 3 columns]
# Tue, 01 Dec 2020 12:16:37
query3_2 = '''
    SELECT cName, c.cID, date
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date LIKE '%2018%' and 
        (EXISTS (SELECT * 
                FROM purchase p
                WHERE c.cID = p.cID and
                s.date = p.date))
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-20
#[Out]# 2      Sem    1  2018-08-20
#[Out]# 3      Sem    1  2018-08-20
#[Out]# 4      Sem    1  2018-08-20
#[Out]# 5      Sem    1  2018-08-20
#[Out]# 6      Sem    1  2018-08-20
#[Out]# 7      Sem    1  2018-08-21
#[Out]# 8    Lucas    2  2018-08-17
#[Out]# 9    Lucas    2  2018-08-16
#[Out]# 10   Lucas    2  2018-08-17
#[Out]# 11   Lucas    2  2018-08-16
#[Out]# 12   Lucas    2  2018-08-17
#[Out]# 13    Finn    3  2018-08-19
#[Out]# 14    Finn    3  2018-08-18
#[Out]# 15    Finn    3  2018-08-18
#[Out]# 16    Levi    5  2018-08-22
#[Out]# 17    Levi    5  2018-08-17
#[Out]# 18    Levi    5  2018-08-23
#[Out]# 19    Levi    5  2018-08-23
#[Out]# 20    Levi    5  2018-08-23
#[Out]# 21    Levi    5  2018-08-22
#[Out]# 22    Bram    7  2018-08-23
#[Out]# 23    Bram    7  2018-08-25
#[Out]# 24    Bram    7  2018-08-24
#[Out]# 25    Bram    7  2018-08-23
#[Out]# 26    Bram    7  2018-08-23
#[Out]# 27    Bram    7  2018-08-26
#[Out]# 28    Liam    8  2018-08-16
#[Out]# 29    Liam    8  2018-08-16
#[Out]# ..     ...  ...         ...
#[Out]# 359   Iris  170  2018-08-16
#[Out]# 360  Tessa  171  2018-08-20
#[Out]# 361  Tessa  171  2018-08-20
#[Out]# 362   Lana  172  2018-08-27
#[Out]# 363   Lana  172  2018-08-24
#[Out]# 364    Sam  175  2018-08-19
#[Out]# 365    Sam  175  2018-08-19
#[Out]# 366  Amira  176  2018-08-25
#[Out]# 367  Amira  176  2018-08-22
#[Out]# 368  Amira  176  2018-08-26
#[Out]# 369  Amira  176  2018-08-25
#[Out]# 370  Amira  176  2018-08-25
#[Out]# 371  Amira  176  2018-08-25
#[Out]# 372  Amira  176  2018-08-25
#[Out]# 373  Amira  176  2018-08-25
#[Out]# 374   Elif  178  2018-08-27
#[Out]# 375   Elif  178  2018-08-27
#[Out]# 376   Juul  179  2018-08-22
#[Out]# 377   Juul  179  2018-08-24
#[Out]# 378   Juul  179  2018-08-24
#[Out]# 379   Juul  179  2018-08-22
#[Out]# 380   Juul  179  2018-08-24
#[Out]# 381   Juul  179  2018-08-22
#[Out]# 382  Merel  180  2018-08-27
#[Out]# 383  Merel  180  2018-08-26
#[Out]# 384  Merel  180  2018-08-26
#[Out]# 385   Liva  181  2018-08-27
#[Out]# 386   Liva  181  2018-08-24
#[Out]# 387   Liva  181  2018-08-27
#[Out]# 388   Liva  181  2018-08-24
#[Out]# 
#[Out]# [389 rows x 3 columns]
# Tue, 01 Dec 2020 12:17:28
query3_2 = '''
    SELECT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date LIKE '%2018%' and 
        (EXISTS (SELECT * 
                FROM purchase p
                WHERE c.cID = p.cID and
                s.date = p.date))
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1      Sem    1
#[Out]# 2      Sem    1
#[Out]# 3      Sem    1
#[Out]# 4      Sem    1
#[Out]# 5      Sem    1
#[Out]# 6      Sem    1
#[Out]# 7      Sem    1
#[Out]# 8    Lucas    2
#[Out]# 9    Lucas    2
#[Out]# 10   Lucas    2
#[Out]# 11   Lucas    2
#[Out]# 12   Lucas    2
#[Out]# 13    Finn    3
#[Out]# 14    Finn    3
#[Out]# 15    Finn    3
#[Out]# 16    Levi    5
#[Out]# 17    Levi    5
#[Out]# 18    Levi    5
#[Out]# 19    Levi    5
#[Out]# 20    Levi    5
#[Out]# 21    Levi    5
#[Out]# 22    Bram    7
#[Out]# 23    Bram    7
#[Out]# 24    Bram    7
#[Out]# 25    Bram    7
#[Out]# 26    Bram    7
#[Out]# 27    Bram    7
#[Out]# 28    Liam    8
#[Out]# 29    Liam    8
#[Out]# ..     ...  ...
#[Out]# 359   Iris  170
#[Out]# 360  Tessa  171
#[Out]# 361  Tessa  171
#[Out]# 362   Lana  172
#[Out]# 363   Lana  172
#[Out]# 364    Sam  175
#[Out]# 365    Sam  175
#[Out]# 366  Amira  176
#[Out]# 367  Amira  176
#[Out]# 368  Amira  176
#[Out]# 369  Amira  176
#[Out]# 370  Amira  176
#[Out]# 371  Amira  176
#[Out]# 372  Amira  176
#[Out]# 373  Amira  176
#[Out]# 374   Elif  178
#[Out]# 375   Elif  178
#[Out]# 376   Juul  179
#[Out]# 377   Juul  179
#[Out]# 378   Juul  179
#[Out]# 379   Juul  179
#[Out]# 380   Juul  179
#[Out]# 381   Juul  179
#[Out]# 382  Merel  180
#[Out]# 383  Merel  180
#[Out]# 384  Merel  180
#[Out]# 385   Liva  181
#[Out]# 386   Liva  181
#[Out]# 387   Liva  181
#[Out]# 388   Liva  181
#[Out]# 
#[Out]# [389 rows x 2 columns]
# Tue, 01 Dec 2020 12:24:56
query3_2 = '''
    SELECT cName, c.cID, date
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date LIKE '%2018%' and 
        (EXISTS (SELECT * 
                FROM purchase p
                WHERE c.cID = p.cID and
                s.date = p.date))
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-20
#[Out]# 2      Sem    1  2018-08-20
#[Out]# 3      Sem    1  2018-08-20
#[Out]# 4      Sem    1  2018-08-20
#[Out]# 5      Sem    1  2018-08-20
#[Out]# 6      Sem    1  2018-08-20
#[Out]# 7      Sem    1  2018-08-21
#[Out]# 8    Lucas    2  2018-08-17
#[Out]# 9    Lucas    2  2018-08-16
#[Out]# 10   Lucas    2  2018-08-17
#[Out]# 11   Lucas    2  2018-08-16
#[Out]# 12   Lucas    2  2018-08-17
#[Out]# 13    Finn    3  2018-08-19
#[Out]# 14    Finn    3  2018-08-18
#[Out]# 15    Finn    3  2018-08-18
#[Out]# 16    Levi    5  2018-08-22
#[Out]# 17    Levi    5  2018-08-17
#[Out]# 18    Levi    5  2018-08-23
#[Out]# 19    Levi    5  2018-08-23
#[Out]# 20    Levi    5  2018-08-23
#[Out]# 21    Levi    5  2018-08-22
#[Out]# 22    Bram    7  2018-08-23
#[Out]# 23    Bram    7  2018-08-25
#[Out]# 24    Bram    7  2018-08-24
#[Out]# 25    Bram    7  2018-08-23
#[Out]# 26    Bram    7  2018-08-23
#[Out]# 27    Bram    7  2018-08-26
#[Out]# 28    Liam    8  2018-08-16
#[Out]# 29    Liam    8  2018-08-16
#[Out]# ..     ...  ...         ...
#[Out]# 359   Iris  170  2018-08-16
#[Out]# 360  Tessa  171  2018-08-20
#[Out]# 361  Tessa  171  2018-08-20
#[Out]# 362   Lana  172  2018-08-27
#[Out]# 363   Lana  172  2018-08-24
#[Out]# 364    Sam  175  2018-08-19
#[Out]# 365    Sam  175  2018-08-19
#[Out]# 366  Amira  176  2018-08-25
#[Out]# 367  Amira  176  2018-08-22
#[Out]# 368  Amira  176  2018-08-26
#[Out]# 369  Amira  176  2018-08-25
#[Out]# 370  Amira  176  2018-08-25
#[Out]# 371  Amira  176  2018-08-25
#[Out]# 372  Amira  176  2018-08-25
#[Out]# 373  Amira  176  2018-08-25
#[Out]# 374   Elif  178  2018-08-27
#[Out]# 375   Elif  178  2018-08-27
#[Out]# 376   Juul  179  2018-08-22
#[Out]# 377   Juul  179  2018-08-24
#[Out]# 378   Juul  179  2018-08-24
#[Out]# 379   Juul  179  2018-08-22
#[Out]# 380   Juul  179  2018-08-24
#[Out]# 381   Juul  179  2018-08-22
#[Out]# 382  Merel  180  2018-08-27
#[Out]# 383  Merel  180  2018-08-26
#[Out]# 384  Merel  180  2018-08-26
#[Out]# 385   Liva  181  2018-08-27
#[Out]# 386   Liva  181  2018-08-24
#[Out]# 387   Liva  181  2018-08-27
#[Out]# 388   Liva  181  2018-08-24
#[Out]# 
#[Out]# [389 rows x 3 columns]
# Tue, 01 Dec 2020 12:25:01
query3_2 = '''
    SELECT cName, c.cID, date
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date LIKE '%2018%' and 
        (EXISTS (SELECT * 
                FROM purchase p
                WHERE c.cID = p.cID and
                s.date != p.date))
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-20
#[Out]# 2      Sem    1  2018-08-20
#[Out]# 3      Sem    1  2018-08-20
#[Out]# 4      Sem    1  2018-08-20
#[Out]# 5      Sem    1  2018-08-20
#[Out]# 6      Sem    1  2018-08-20
#[Out]# 7      Sem    1  2018-08-21
#[Out]# 8    Lucas    2  2018-08-17
#[Out]# 9    Lucas    2  2018-08-16
#[Out]# 10   Lucas    2  2018-08-17
#[Out]# 11   Lucas    2  2018-08-16
#[Out]# 12   Lucas    2  2018-08-17
#[Out]# 13    Finn    3  2018-08-19
#[Out]# 14    Finn    3  2018-08-18
#[Out]# 15    Finn    3  2018-08-18
#[Out]# 16    Levi    5  2018-08-22
#[Out]# 17    Levi    5  2018-08-17
#[Out]# 18    Levi    5  2018-08-23
#[Out]# 19    Levi    5  2018-08-23
#[Out]# 20    Levi    5  2018-08-23
#[Out]# 21    Levi    5  2018-08-22
#[Out]# 22    Bram    7  2018-08-23
#[Out]# 23    Bram    7  2018-08-25
#[Out]# 24    Bram    7  2018-08-24
#[Out]# 25    Bram    7  2018-08-23
#[Out]# 26    Bram    7  2018-08-23
#[Out]# 27    Bram    7  2018-08-26
#[Out]# 28    Liam    8  2018-08-15
#[Out]# 29   James   13  2018-08-17
#[Out]# ..     ...  ...         ...
#[Out]# 333   Lily  169  2018-08-27
#[Out]# 334   Lily  169  2018-08-15
#[Out]# 335   Lily  169  2018-08-18
#[Out]# 336   Lily  169  2018-08-19
#[Out]# 337   Lily  169  2018-08-16
#[Out]# 338   Lana  172  2018-08-27
#[Out]# 339   Lana  172  2018-08-24
#[Out]# 340    Sam  175  2018-08-19
#[Out]# 341    Sam  175  2018-08-19
#[Out]# 342  Amira  176  2018-08-25
#[Out]# 343  Amira  176  2018-08-22
#[Out]# 344  Amira  176  2018-08-26
#[Out]# 345  Amira  176  2018-08-25
#[Out]# 346  Amira  176  2018-08-25
#[Out]# 347  Amira  176  2018-08-25
#[Out]# 348  Amira  176  2018-08-25
#[Out]# 349  Amira  176  2018-08-25
#[Out]# 350   Juul  179  2018-08-22
#[Out]# 351   Juul  179  2018-08-24
#[Out]# 352   Juul  179  2018-08-24
#[Out]# 353   Juul  179  2018-08-22
#[Out]# 354   Juul  179  2018-08-24
#[Out]# 355   Juul  179  2018-08-22
#[Out]# 356  Merel  180  2018-08-27
#[Out]# 357  Merel  180  2018-08-26
#[Out]# 358  Merel  180  2018-08-26
#[Out]# 359   Liva  181  2018-08-27
#[Out]# 360   Liva  181  2018-08-24
#[Out]# 361   Liva  181  2018-08-27
#[Out]# 362   Liva  181  2018-08-24
#[Out]# 
#[Out]# [363 rows x 3 columns]
# Tue, 01 Dec 2020 12:25:16
query3_2 = '''
    SELECT cName, c.cID, date
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date LIKE '%2018%' and 
        (EXISTS (SELECT * 
                FROM purchase p
                WHERE c.cID = p.cID and
                s.date = p.date))
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-20
#[Out]# 2      Sem    1  2018-08-20
#[Out]# 3      Sem    1  2018-08-20
#[Out]# 4      Sem    1  2018-08-20
#[Out]# 5      Sem    1  2018-08-20
#[Out]# 6      Sem    1  2018-08-20
#[Out]# 7      Sem    1  2018-08-21
#[Out]# 8    Lucas    2  2018-08-17
#[Out]# 9    Lucas    2  2018-08-16
#[Out]# 10   Lucas    2  2018-08-17
#[Out]# 11   Lucas    2  2018-08-16
#[Out]# 12   Lucas    2  2018-08-17
#[Out]# 13    Finn    3  2018-08-19
#[Out]# 14    Finn    3  2018-08-18
#[Out]# 15    Finn    3  2018-08-18
#[Out]# 16    Levi    5  2018-08-22
#[Out]# 17    Levi    5  2018-08-17
#[Out]# 18    Levi    5  2018-08-23
#[Out]# 19    Levi    5  2018-08-23
#[Out]# 20    Levi    5  2018-08-23
#[Out]# 21    Levi    5  2018-08-22
#[Out]# 22    Bram    7  2018-08-23
#[Out]# 23    Bram    7  2018-08-25
#[Out]# 24    Bram    7  2018-08-24
#[Out]# 25    Bram    7  2018-08-23
#[Out]# 26    Bram    7  2018-08-23
#[Out]# 27    Bram    7  2018-08-26
#[Out]# 28    Liam    8  2018-08-16
#[Out]# 29    Liam    8  2018-08-16
#[Out]# ..     ...  ...         ...
#[Out]# 359   Iris  170  2018-08-16
#[Out]# 360  Tessa  171  2018-08-20
#[Out]# 361  Tessa  171  2018-08-20
#[Out]# 362   Lana  172  2018-08-27
#[Out]# 363   Lana  172  2018-08-24
#[Out]# 364    Sam  175  2018-08-19
#[Out]# 365    Sam  175  2018-08-19
#[Out]# 366  Amira  176  2018-08-25
#[Out]# 367  Amira  176  2018-08-22
#[Out]# 368  Amira  176  2018-08-26
#[Out]# 369  Amira  176  2018-08-25
#[Out]# 370  Amira  176  2018-08-25
#[Out]# 371  Amira  176  2018-08-25
#[Out]# 372  Amira  176  2018-08-25
#[Out]# 373  Amira  176  2018-08-25
#[Out]# 374   Elif  178  2018-08-27
#[Out]# 375   Elif  178  2018-08-27
#[Out]# 376   Juul  179  2018-08-22
#[Out]# 377   Juul  179  2018-08-24
#[Out]# 378   Juul  179  2018-08-24
#[Out]# 379   Juul  179  2018-08-22
#[Out]# 380   Juul  179  2018-08-24
#[Out]# 381   Juul  179  2018-08-22
#[Out]# 382  Merel  180  2018-08-27
#[Out]# 383  Merel  180  2018-08-26
#[Out]# 384  Merel  180  2018-08-26
#[Out]# 385   Liva  181  2018-08-27
#[Out]# 386   Liva  181  2018-08-24
#[Out]# 387   Liva  181  2018-08-27
#[Out]# 388   Liva  181  2018-08-24
#[Out]# 
#[Out]# [389 rows x 3 columns]
# Tue, 01 Dec 2020 12:28:37
query3_2 = '''
    SELECT cName, c.cID, date, pID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date LIKE '%2018%' and 
        (EXISTS (SELECT * 
                FROM purchase p
                WHERE c.cID = p.cID and
                s.date = p.date))
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date  pID
#[Out]# 0      Sem    1  2018-08-20    9
#[Out]# 1      Sem    1  2018-08-20   11
#[Out]# 2      Sem    1  2018-08-20   14
#[Out]# 3      Sem    1  2018-08-20   16
#[Out]# 4      Sem    1  2018-08-20   21
#[Out]# 5      Sem    1  2018-08-20   25
#[Out]# 6      Sem    1  2018-08-20   26
#[Out]# 7      Sem    1  2018-08-21   27
#[Out]# 8    Lucas    2  2018-08-17    4
#[Out]# 9    Lucas    2  2018-08-16    9
#[Out]# 10   Lucas    2  2018-08-17   13
#[Out]# 11   Lucas    2  2018-08-16   20
#[Out]# 12   Lucas    2  2018-08-17   22
#[Out]# 13    Finn    3  2018-08-19    9
#[Out]# 14    Finn    3  2018-08-18   14
#[Out]# 15    Finn    3  2018-08-18   26
#[Out]# 16    Levi    5  2018-08-22    6
#[Out]# 17    Levi    5  2018-08-17   14
#[Out]# 18    Levi    5  2018-08-23   16
#[Out]# 19    Levi    5  2018-08-23   19
#[Out]# 20    Levi    5  2018-08-23   22
#[Out]# 21    Levi    5  2018-08-22   28
#[Out]# 22    Bram    7  2018-08-23    2
#[Out]# 23    Bram    7  2018-08-25    6
#[Out]# 24    Bram    7  2018-08-24   12
#[Out]# 25    Bram    7  2018-08-23   16
#[Out]# 26    Bram    7  2018-08-23   19
#[Out]# 27    Bram    7  2018-08-26   20
#[Out]# 28    Liam    8  2018-08-16    3
#[Out]# 29    Liam    8  2018-08-16    6
#[Out]# ..     ...  ...         ...  ...
#[Out]# 359   Iris  170  2018-08-16   28
#[Out]# 360  Tessa  171  2018-08-20    3
#[Out]# 361  Tessa  171  2018-08-20   21
#[Out]# 362   Lana  172  2018-08-27    4
#[Out]# 363   Lana  172  2018-08-24   16
#[Out]# 364    Sam  175  2018-08-19   21
#[Out]# 365    Sam  175  2018-08-19   28
#[Out]# 366  Amira  176  2018-08-25    0
#[Out]# 367  Amira  176  2018-08-22    4
#[Out]# 368  Amira  176  2018-08-26    5
#[Out]# 369  Amira  176  2018-08-25   11
#[Out]# 370  Amira  176  2018-08-25   13
#[Out]# 371  Amira  176  2018-08-25   14
#[Out]# 372  Amira  176  2018-08-25   21
#[Out]# 373  Amira  176  2018-08-25   24
#[Out]# 374   Elif  178  2018-08-27   24
#[Out]# 375   Elif  178  2018-08-27   25
#[Out]# 376   Juul  179  2018-08-22   10
#[Out]# 377   Juul  179  2018-08-24   11
#[Out]# 378   Juul  179  2018-08-24   14
#[Out]# 379   Juul  179  2018-08-22   16
#[Out]# 380   Juul  179  2018-08-24   17
#[Out]# 381   Juul  179  2018-08-22   27
#[Out]# 382  Merel  180  2018-08-27   10
#[Out]# 383  Merel  180  2018-08-26   13
#[Out]# 384  Merel  180  2018-08-26   26
#[Out]# 385   Liva  181  2018-08-27    5
#[Out]# 386   Liva  181  2018-08-24    6
#[Out]# 387   Liva  181  2018-08-27   21
#[Out]# 388   Liva  181  2018-08-24   26
#[Out]# 
#[Out]# [389 rows x 4 columns]
# Tue, 01 Dec 2020 12:30:03
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID and
        date LIKE '%2018%' and 
        (EXISTS (SELECT * 
                FROM purchase p
                WHERE c.cID = p.cID and
                s.date = p.date))
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 12:31:02
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID AND
        date LIKE '%2018%' AND
        (EXISTS (SELECT * 
                FROM purchase p
                WHERE c.cID = p.cID AND
                p.date LIKE '%2018%' AND
                s.date = p.date))
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 12:31:38
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, shoppinglist s
    WHERE c.cID = s.cID AND
        date LIKE '%2018%' AND
        (EXISTS (SELECT * 
                FROM purchase p
                WHERE c.cID = p.cID AND
                s.date = p.date))
        
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 13:28:45
query3_3 = '''
    SELECT DISTINCT c.cID, cName
    FROM customer c
    EXCEPT 
        SELECT customer.cID, cName
        FROM customer, store s, purchase p
        WHERE s.sName = 'Kumar' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 13:29:06
query3_3 = '''

        SELECT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE s.sName = 'Kumar' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 13:30:07
query3_3 = '''

        SELECT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem         Dirk
#[Out]# 2      1     Sem       Sligro
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem  Albert Hein
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas       Sligro
#[Out]# 10     2   Lucas         Coop
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn  Albert Hein
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn       Sligro
#[Out]# 16     4    Daan    Hoogvliet
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan         Coop
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan       Sligro
#[Out]# 21     4    Daan  Albert Hein
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Lidl
#[Out]# 24     5    Levi         Coop
#[Out]# 25     5    Levi         Coop
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi    Hoogvliet
#[Out]# 28     7    Bram       Sligro
#[Out]# 29     7    Bram         Lidl
#[Out]# ..   ...     ...          ...
#[Out]# 479  190  Kostas         Coop
#[Out]# 480  190  Kostas         Lidl
#[Out]# 481  190  Kostas         Lidl
#[Out]# 482  190  Kostas        Jumbo
#[Out]# 483  190  Kostas    Hoogvliet
#[Out]# 484  190  Kostas       Sligro
#[Out]# 485  190  Kostas    Hoogvliet
#[Out]# 486  190  Kostas  Albert Hein
#[Out]# 487  190  Kostas       Sligro
#[Out]# 488  190  Kostas         Coop
#[Out]# 489  190  Kostas  Albert Hein
#[Out]# 490  190  Kostas         Coop
#[Out]# 491  190  Kostas         Lidl
#[Out]# 492  190  Kostas         Coop
#[Out]# 493  190  Kostas    Hoogvliet
#[Out]# 494  190  Kostas    Hoogvliet
#[Out]# 495  190  Kostas       Sligro
#[Out]# 496  190  Kostas         Coop
#[Out]# 497  190  Kostas         Lidl
#[Out]# 498  190  Kostas         Coop
#[Out]# 499  190  Kostas         Dirk
#[Out]# 500  190  Kostas         Coop
#[Out]# 501  190  Kostas        Jumbo
#[Out]# 502  190  Kostas         Dirk
#[Out]# 503  190  Kostas         Dirk
#[Out]# 504  190  Kostas        Jumbo
#[Out]# 505  190  Kostas         Lidl
#[Out]# 506  190  Kostas         Lidl
#[Out]# 507  190  Kostas        Jumbo
#[Out]# 508  190  Kostas        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 13:30:21
query3_3 = '''

        SELECT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'Kumar' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 13:31:19
query3_3 = '''

        SELECT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'Kumar' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 13:31:28
query3_3 = '''

        SELECT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName        sName
#[Out]# 0      0    Noah       Sligro
#[Out]# 1      1     Sem         Dirk
#[Out]# 2      1     Sem       Sligro
#[Out]# 3      1     Sem    Hoogvliet
#[Out]# 4      1     Sem  Albert Hein
#[Out]# 5      1     Sem         Lidl
#[Out]# 6      1     Sem         Lidl
#[Out]# 7      1     Sem         Lidl
#[Out]# 8      2   Lucas         Lidl
#[Out]# 9      2   Lucas       Sligro
#[Out]# 10     2   Lucas         Coop
#[Out]# 11     2   Lucas         Coop
#[Out]# 12     2   Lucas         Coop
#[Out]# 13     3    Finn  Albert Hein
#[Out]# 14     3    Finn         Dirk
#[Out]# 15     3    Finn       Sligro
#[Out]# 16     4    Daan    Hoogvliet
#[Out]# 17     4    Daan        Jumbo
#[Out]# 18     4    Daan         Coop
#[Out]# 19     4    Daan         Coop
#[Out]# 20     4    Daan       Sligro
#[Out]# 21     4    Daan  Albert Hein
#[Out]# 22     5    Levi    Hoogvliet
#[Out]# 23     5    Levi         Lidl
#[Out]# 24     5    Levi         Coop
#[Out]# 25     5    Levi         Coop
#[Out]# 26     5    Levi         Coop
#[Out]# 27     5    Levi    Hoogvliet
#[Out]# 28     7    Bram       Sligro
#[Out]# 29     7    Bram         Lidl
#[Out]# ..   ...     ...          ...
#[Out]# 479  190  Kostas         Coop
#[Out]# 480  190  Kostas         Lidl
#[Out]# 481  190  Kostas         Lidl
#[Out]# 482  190  Kostas        Jumbo
#[Out]# 483  190  Kostas    Hoogvliet
#[Out]# 484  190  Kostas       Sligro
#[Out]# 485  190  Kostas    Hoogvliet
#[Out]# 486  190  Kostas  Albert Hein
#[Out]# 487  190  Kostas       Sligro
#[Out]# 488  190  Kostas         Coop
#[Out]# 489  190  Kostas  Albert Hein
#[Out]# 490  190  Kostas         Coop
#[Out]# 491  190  Kostas         Lidl
#[Out]# 492  190  Kostas         Coop
#[Out]# 493  190  Kostas    Hoogvliet
#[Out]# 494  190  Kostas    Hoogvliet
#[Out]# 495  190  Kostas       Sligro
#[Out]# 496  190  Kostas         Coop
#[Out]# 497  190  Kostas         Lidl
#[Out]# 498  190  Kostas         Coop
#[Out]# 499  190  Kostas         Dirk
#[Out]# 500  190  Kostas         Coop
#[Out]# 501  190  Kostas        Jumbo
#[Out]# 502  190  Kostas         Dirk
#[Out]# 503  190  Kostas         Dirk
#[Out]# 504  190  Kostas        Jumbo
#[Out]# 505  190  Kostas         Lidl
#[Out]# 506  190  Kostas         Lidl
#[Out]# 507  190  Kostas        Jumbo
#[Out]# 508  190  Kostas        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 01 Dec 2020 13:31:43
query3_3 = '''

        SELECT DISTINCT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName        sName
#[Out]# 0      0     Noah       Sligro
#[Out]# 1      1      Sem         Dirk
#[Out]# 2      1      Sem       Sligro
#[Out]# 3      1      Sem    Hoogvliet
#[Out]# 4      1      Sem  Albert Hein
#[Out]# 5      1      Sem         Lidl
#[Out]# 6      2    Lucas         Lidl
#[Out]# 7      2    Lucas       Sligro
#[Out]# 8      2    Lucas         Coop
#[Out]# 9      3     Finn  Albert Hein
#[Out]# 10     3     Finn         Dirk
#[Out]# 11     3     Finn       Sligro
#[Out]# 12     4     Daan    Hoogvliet
#[Out]# 13     4     Daan        Jumbo
#[Out]# 14     4     Daan         Coop
#[Out]# 15     4     Daan       Sligro
#[Out]# 16     4     Daan  Albert Hein
#[Out]# 17     5     Levi    Hoogvliet
#[Out]# 18     5     Levi         Lidl
#[Out]# 19     5     Levi         Coop
#[Out]# 20     7     Bram       Sligro
#[Out]# 21     7     Bram         Lidl
#[Out]# 22     7     Bram  Albert Hein
#[Out]# 23     7     Bram    Hoogvliet
#[Out]# 24     8     Liam         Coop
#[Out]# 25    10      Sam         Coop
#[Out]# 26    11    Thijs         Coop
#[Out]# 27    13    James         Dirk
#[Out]# 28    13    James    Hoogvliet
#[Out]# 29    13    James         Lidl
#[Out]# ..   ...      ...          ...
#[Out]# 304  176    Amira         Lidl
#[Out]# 305  176    Amira         Coop
#[Out]# 306  176    Amira    Hoogvliet
#[Out]# 307  177    Eline         Coop
#[Out]# 308  177    Eline    Hoogvliet
#[Out]# 309  177    Eline  Albert Hein
#[Out]# 310  178     Elif         Coop
#[Out]# 311  178     Elif       Sligro
#[Out]# 312  179     Juul  Albert Hein
#[Out]# 313  179     Juul         Dirk
#[Out]# 314  179     Juul         Coop
#[Out]# 315  179     Juul         Lidl
#[Out]# 316  180    Merel         Coop
#[Out]# 317  180    Merel        Jumbo
#[Out]# 318  181     Liva         Coop
#[Out]# 319  181     Liva       Sligro
#[Out]# 320  182  Johanna    Hoogvliet
#[Out]# 321  182  Johanna       Sligro
#[Out]# 322  184    Wilko         Coop
#[Out]# 323  185     Nick        Jumbo
#[Out]# 324  186   Angela        Jumbo
#[Out]# 325  188     Pino        Jumbo
#[Out]# 326  189     Koen        Jumbo
#[Out]# 327  190   Kostas         Coop
#[Out]# 328  190   Kostas    Hoogvliet
#[Out]# 329  190   Kostas        Jumbo
#[Out]# 330  190   Kostas       Sligro
#[Out]# 331  190   Kostas  Albert Hein
#[Out]# 332  190   Kostas         Lidl
#[Out]# 333  190   Kostas         Dirk
#[Out]# 
#[Out]# [334 rows x 3 columns]
# Tue, 01 Dec 2020 13:32:00
query3_3 = '''

        SELECT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'dirk' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName sName
#[Out]# 0     1       Sem  Dirk
#[Out]# 1     3      Finn  Dirk
#[Out]# 2    13     James  Dirk
#[Out]# 3    13     James  Dirk
#[Out]# 4    30      Teun  Dirk
#[Out]# 5    33      Sven  Dirk
#[Out]# 6    33      Sven  Dirk
#[Out]# 7    33      Sven  Dirk
#[Out]# 8    39      Jack  Dirk
#[Out]# 9    41     Quinn  Dirk
#[Out]# 10   45      Ryan  Dirk
#[Out]# 11   59      Joep  Dirk
#[Out]# 12   60  Mohammed  Dirk
#[Out]# 13   70       Kai  Dirk
#[Out]# 14   72      Dani  Dirk
#[Out]# 15   75      Jace  Dirk
#[Out]# 16   86      Stef  Dirk
#[Out]# 17   91   Thijmen  Dirk
#[Out]# 18   92     Jelte  Dirk
#[Out]# 19   95      Emma  Dirk
#[Out]# 20   97    Sophie  Dirk
#[Out]# 21  100      Sara  Dirk
#[Out]# 22  108      Noor  Dirk
#[Out]# 23  116     Lieke  Dirk
#[Out]# 24  122      Elin  Dirk
#[Out]# 25  124     Sofie  Dirk
#[Out]# 26  124     Sofie  Dirk
#[Out]# 27  145      Fien  Dirk
#[Out]# 28  147    Isabel  Dirk
#[Out]# 29  149     Lizzy  Dirk
#[Out]# 30  162     Elena  Dirk
#[Out]# 31  163      Cato  Dirk
#[Out]# 32  167    Veerle  Dirk
#[Out]# 33  169      Lily  Dirk
#[Out]# 34  179      Juul  Dirk
#[Out]# 35  190    Kostas  Dirk
#[Out]# 36  190    Kostas  Dirk
#[Out]# 37  190    Kostas  Dirk
#[Out]# 38  190    Kostas  Dirk
#[Out]# 39  190    Kostas  Dirk
#[Out]# 40  190    Kostas  Dirk
# Tue, 01 Dec 2020 13:32:14
query3_3 = '''

        SELECT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'kumar' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 13:32:40
query3_3 = '''

        SELECT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'coop' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName sName
#[Out]# 0      2     Lucas  Coop
#[Out]# 1      2     Lucas  Coop
#[Out]# 2      2     Lucas  Coop
#[Out]# 3      4      Daan  Coop
#[Out]# 4      4      Daan  Coop
#[Out]# 5      5      Levi  Coop
#[Out]# 6      5      Levi  Coop
#[Out]# 7      5      Levi  Coop
#[Out]# 8      8      Liam  Coop
#[Out]# 9      8      Liam  Coop
#[Out]# 10    10       Sam  Coop
#[Out]# 11    11     Thijs  Coop
#[Out]# 12    16    Julian  Coop
#[Out]# 13    16    Julian  Coop
#[Out]# 14    16    Julian  Coop
#[Out]# 15    16    Julian  Coop
#[Out]# 16    17       Dex  Coop
#[Out]# 17    18      Hugo  Coop
#[Out]# 18    20      Gijs  Coop
#[Out]# 19    21  Benjamin  Coop
#[Out]# 20    24      Luca  Coop
#[Out]# 21    24      Luca  Coop
#[Out]# 22    24      Luca  Coop
#[Out]# 23    26    Jayden  Coop
#[Out]# 24    27       Tim  Coop
#[Out]# 25    27       Tim  Coop
#[Out]# 26    27       Tim  Coop
#[Out]# 27    28      Siem  Coop
#[Out]# 28    29     Ruben  Coop
#[Out]# 29    33      Sven  Coop
#[Out]# ..   ...       ...   ...
#[Out]# 102  169      Lily  Coop
#[Out]# 103  169      Lily  Coop
#[Out]# 104  172      Lana  Coop
#[Out]# 105  176     Amira  Coop
#[Out]# 106  176     Amira  Coop
#[Out]# 107  177     Eline  Coop
#[Out]# 108  177     Eline  Coop
#[Out]# 109  177     Eline  Coop
#[Out]# 110  178      Elif  Coop
#[Out]# 111  179      Juul  Coop
#[Out]# 112  179      Juul  Coop
#[Out]# 113  180     Merel  Coop
#[Out]# 114  180     Merel  Coop
#[Out]# 115  181      Liva  Coop
#[Out]# 116  181      Liva  Coop
#[Out]# 117  184     Wilko  Coop
#[Out]# 118  190    Kostas  Coop
#[Out]# 119  190    Kostas  Coop
#[Out]# 120  190    Kostas  Coop
#[Out]# 121  190    Kostas  Coop
#[Out]# 122  190    Kostas  Coop
#[Out]# 123  190    Kostas  Coop
#[Out]# 124  190    Kostas  Coop
#[Out]# 125  190    Kostas  Coop
#[Out]# 126  190    Kostas  Coop
#[Out]# 127  190    Kostas  Coop
#[Out]# 128  190    Kostas  Coop
#[Out]# 129  190    Kostas  Coop
#[Out]# 130  190    Kostas  Coop
#[Out]# 131  190    Kostas  Coop
#[Out]# 
#[Out]# [132 rows x 3 columns]
# Tue, 01 Dec 2020 13:32:50
query3_3 = '''

        SELECT DISTINCT customer.cID, cName, s.sName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'coop' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID      cName sName
#[Out]# 0     2      Lucas  Coop
#[Out]# 1     4       Daan  Coop
#[Out]# 2     5       Levi  Coop
#[Out]# 3     8       Liam  Coop
#[Out]# 4    10        Sam  Coop
#[Out]# 5    11      Thijs  Coop
#[Out]# 6    16     Julian  Coop
#[Out]# 7    17        Dex  Coop
#[Out]# 8    18       Hugo  Coop
#[Out]# 9    20       Gijs  Coop
#[Out]# 10   21   Benjamin  Coop
#[Out]# 11   24       Luca  Coop
#[Out]# 12   26     Jayden  Coop
#[Out]# 13   27        Tim  Coop
#[Out]# 14   28       Siem  Coop
#[Out]# 15   29      Ruben  Coop
#[Out]# 16   33       Sven  Coop
#[Out]# 17   35      Stijn  Coop
#[Out]# 18   39       Jack  Coop
#[Out]# 19   42       Tijn  Coop
#[Out]# 20   51       Ties  Coop
#[Out]# 21   55      Aiden  Coop
#[Out]# 22   57     Nathan  Coop
#[Out]# 23   59       Joep  Coop
#[Out]# 24   67      Rayan  Coop
#[Out]# 25   71       Dean  Coop
#[Out]# 26   75       Jace  Coop
#[Out]# 27   76  Alexander  Coop
#[Out]# 28   78       Mick  Coop
#[Out]# 29   82      Dylan  Coop
#[Out]# ..  ...        ...   ...
#[Out]# 44  116      Lieke  Coop
#[Out]# 45  118       Lisa  Coop
#[Out]# 46  122       Elin  Coop
#[Out]# 47  123      Milou  Coop
#[Out]# 48  124      Sofie  Coop
#[Out]# 49  127      Emily  Coop
#[Out]# 50  129      Esmee  Coop
#[Out]# 51  131        Amy  Coop
#[Out]# 52  133     Sophia  Coop
#[Out]# 53  134       Ella  Coop
#[Out]# 54  135      Sofia  Coop
#[Out]# 55  139      Elise  Coop
#[Out]# 56  144        Ivy  Coop
#[Out]# 57  147     Isabel  Coop
#[Out]# 58  151       Jill  Coop
#[Out]# 59  152       Anne  Coop
#[Out]# 60  161      Floor  Coop
#[Out]# 61  162      Elena  Coop
#[Out]# 62  163       Cato  Coop
#[Out]# 63  165      Hanna  Coop
#[Out]# 64  169       Lily  Coop
#[Out]# 65  172       Lana  Coop
#[Out]# 66  176      Amira  Coop
#[Out]# 67  177      Eline  Coop
#[Out]# 68  178       Elif  Coop
#[Out]# 69  179       Juul  Coop
#[Out]# 70  180      Merel  Coop
#[Out]# 71  181       Liva  Coop
#[Out]# 72  184      Wilko  Coop
#[Out]# 73  190     Kostas  Coop
#[Out]# 
#[Out]# [74 rows x 3 columns]
# Tue, 01 Dec 2020 13:33:19
query3_3 = '''
    SELECT DISTINCT c.cID, cName
    FROM customer c
    EXCEPT 
        SELECT customer.cID, cName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'Kumar' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 13:33:30
query3_3 = '''
    SELECT DISTINCT c.cID, cName
    FROM customer c
    EXCEPT 
        SELECT customer.cID, cName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'Coop' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 13:33:57
query3_3 = '''
    
        SELECT customer.cID, cName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'Coop' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      2     Lucas
#[Out]# 1      2     Lucas
#[Out]# 2      2     Lucas
#[Out]# 3      4      Daan
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      5      Levi
#[Out]# 7      5      Levi
#[Out]# 8      8      Liam
#[Out]# 9      8      Liam
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    16    Julian
#[Out]# 13    16    Julian
#[Out]# 14    16    Julian
#[Out]# 15    16    Julian
#[Out]# 16    17       Dex
#[Out]# 17    18      Hugo
#[Out]# 18    20      Gijs
#[Out]# 19    21  Benjamin
#[Out]# 20    24      Luca
#[Out]# 21    24      Luca
#[Out]# 22    24      Luca
#[Out]# 23    26    Jayden
#[Out]# 24    27       Tim
#[Out]# 25    27       Tim
#[Out]# 26    27       Tim
#[Out]# 27    28      Siem
#[Out]# 28    29     Ruben
#[Out]# 29    33      Sven
#[Out]# ..   ...       ...
#[Out]# 102  169      Lily
#[Out]# 103  169      Lily
#[Out]# 104  172      Lana
#[Out]# 105  176     Amira
#[Out]# 106  176     Amira
#[Out]# 107  177     Eline
#[Out]# 108  177     Eline
#[Out]# 109  177     Eline
#[Out]# 110  178      Elif
#[Out]# 111  179      Juul
#[Out]# 112  179      Juul
#[Out]# 113  180     Merel
#[Out]# 114  180     Merel
#[Out]# 115  181      Liva
#[Out]# 116  181      Liva
#[Out]# 117  184     Wilko
#[Out]# 118  190    Kostas
#[Out]# 119  190    Kostas
#[Out]# 120  190    Kostas
#[Out]# 121  190    Kostas
#[Out]# 122  190    Kostas
#[Out]# 123  190    Kostas
#[Out]# 124  190    Kostas
#[Out]# 125  190    Kostas
#[Out]# 126  190    Kostas
#[Out]# 127  190    Kostas
#[Out]# 128  190    Kostas
#[Out]# 129  190    Kostas
#[Out]# 130  190    Kostas
#[Out]# 131  190    Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 13:34:11
query3_3 = '''
    SELECT DISTINCT c.cID, cName
    FROM customer c
    EXCEPT 
        SELECT customer.cID, cName
        FROM customer, store s, purchase p
        WHERE s.sName LIKE 'Coop' AND 
            p.sID = s.sID AND
            p.cID = customer.cID
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 13:43:21
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0       Lucas    2
#[Out]# 1        Daan    4
#[Out]# 2        Levi    5
#[Out]# 3        Liam    8
#[Out]# 4         Sam   10
#[Out]# 5       Thijs   11
#[Out]# 6      Julian   16
#[Out]# 7         Dex   17
#[Out]# 8        Hugo   18
#[Out]# 9        Gijs   20
#[Out]# 10   Benjamin   21
#[Out]# 11       Luca   24
#[Out]# 12     Jayden   26
#[Out]# 13        Tim   27
#[Out]# 14       Siem   28
#[Out]# 15      Ruben   29
#[Out]# 16       Sven   33
#[Out]# 17      Stijn   35
#[Out]# 18       Jack   39
#[Out]# 19       Tijn   42
#[Out]# 20       Ties   51
#[Out]# 21      Aiden   55
#[Out]# 22     Nathan   57
#[Out]# 23       Joep   59
#[Out]# 24      Rayan   67
#[Out]# 25       Dean   71
#[Out]# 26       Jace   75
#[Out]# 27  Alexander   76
#[Out]# 28       Mick   78
#[Out]# 29      Dylan   82
#[Out]# ..        ...  ...
#[Out]# 44      Lieke  116
#[Out]# 45       Lisa  118
#[Out]# 46       Elin  122
#[Out]# 47      Milou  123
#[Out]# 48      Sofie  124
#[Out]# 49      Emily  127
#[Out]# 50      Esmee  129
#[Out]# 51        Amy  131
#[Out]# 52     Sophia  133
#[Out]# 53       Ella  134
#[Out]# 54      Sofia  135
#[Out]# 55      Elise  139
#[Out]# 56        Ivy  144
#[Out]# 57     Isabel  147
#[Out]# 58       Jill  151
#[Out]# 59       Anne  152
#[Out]# 60      Floor  161
#[Out]# 61      Elena  162
#[Out]# 62       Cato  163
#[Out]# 63      Hanna  165
#[Out]# 64       Lily  169
#[Out]# 65       Lana  172
#[Out]# 66      Amira  176
#[Out]# 67      Eline  177
#[Out]# 68       Elif  178
#[Out]# 69       Juul  179
#[Out]# 70      Merel  180
#[Out]# 71       Liva  181
#[Out]# 72      Wilko  184
#[Out]# 73     Kostas  190
#[Out]# 
#[Out]# [74 rows x 2 columns]
# Tue, 01 Dec 2020 13:43:28
query3_4 = '''
    SELECT DISTINCT cName, c.cID, sName
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID sName
#[Out]# 0       Lucas    2  Coop
#[Out]# 1        Daan    4  Coop
#[Out]# 2        Levi    5  Coop
#[Out]# 3        Liam    8  Coop
#[Out]# 4         Sam   10  Coop
#[Out]# 5       Thijs   11  Coop
#[Out]# 6      Julian   16  Coop
#[Out]# 7         Dex   17  Coop
#[Out]# 8        Hugo   18  Coop
#[Out]# 9        Gijs   20  Coop
#[Out]# 10   Benjamin   21  Coop
#[Out]# 11       Luca   24  Coop
#[Out]# 12     Jayden   26  Coop
#[Out]# 13        Tim   27  Coop
#[Out]# 14       Siem   28  Coop
#[Out]# 15      Ruben   29  Coop
#[Out]# 16       Sven   33  Coop
#[Out]# 17      Stijn   35  Coop
#[Out]# 18       Jack   39  Coop
#[Out]# 19       Tijn   42  Coop
#[Out]# 20       Ties   51  Coop
#[Out]# 21      Aiden   55  Coop
#[Out]# 22     Nathan   57  Coop
#[Out]# 23       Joep   59  Coop
#[Out]# 24      Rayan   67  Coop
#[Out]# 25       Dean   71  Coop
#[Out]# 26       Jace   75  Coop
#[Out]# 27  Alexander   76  Coop
#[Out]# 28       Mick   78  Coop
#[Out]# 29      Dylan   82  Coop
#[Out]# ..        ...  ...   ...
#[Out]# 44      Lieke  116  Coop
#[Out]# 45       Lisa  118  Coop
#[Out]# 46       Elin  122  Coop
#[Out]# 47      Milou  123  Coop
#[Out]# 48      Sofie  124  Coop
#[Out]# 49      Emily  127  Coop
#[Out]# 50      Esmee  129  Coop
#[Out]# 51        Amy  131  Coop
#[Out]# 52     Sophia  133  Coop
#[Out]# 53       Ella  134  Coop
#[Out]# 54      Sofia  135  Coop
#[Out]# 55      Elise  139  Coop
#[Out]# 56        Ivy  144  Coop
#[Out]# 57     Isabel  147  Coop
#[Out]# 58       Jill  151  Coop
#[Out]# 59       Anne  152  Coop
#[Out]# 60      Floor  161  Coop
#[Out]# 61      Elena  162  Coop
#[Out]# 62       Cato  163  Coop
#[Out]# 63      Hanna  165  Coop
#[Out]# 64       Lily  169  Coop
#[Out]# 65       Lana  172  Coop
#[Out]# 66      Amira  176  Coop
#[Out]# 67      Eline  177  Coop
#[Out]# 68       Elif  178  Coop
#[Out]# 69       Juul  179  Coop
#[Out]# 70      Merel  180  Coop
#[Out]# 71       Liva  181  Coop
#[Out]# 72      Wilko  184  Coop
#[Out]# 73     Kostas  190  Coop
#[Out]# 
#[Out]# [74 rows x 3 columns]
# Tue, 01 Dec 2020 13:43:46
query3_4 = '''
    SELECT DISTINCT cName, c.cID, sName, p.pID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID sName  pID
#[Out]# 0       Lucas    2  Coop    4
#[Out]# 1       Lucas    2  Coop   13
#[Out]# 2       Lucas    2  Coop   22
#[Out]# 3        Daan    4  Coop   12
#[Out]# 4        Daan    4  Coop    6
#[Out]# 5        Levi    5  Coop    6
#[Out]# 6        Levi    5  Coop   22
#[Out]# 7        Levi    5  Coop   16
#[Out]# 8        Liam    8  Coop    6
#[Out]# 9        Liam    8  Coop    8
#[Out]# 10        Sam   10  Coop   24
#[Out]# 11      Thijs   11  Coop   14
#[Out]# 12     Julian   16  Coop   21
#[Out]# 13     Julian   16  Coop   23
#[Out]# 14     Julian   16  Coop   16
#[Out]# 15     Julian   16  Coop    7
#[Out]# 16        Dex   17  Coop   14
#[Out]# 17       Hugo   18  Coop    8
#[Out]# 18       Gijs   20  Coop    0
#[Out]# 19   Benjamin   21  Coop   27
#[Out]# 20       Luca   24  Coop   16
#[Out]# 21       Luca   24  Coop   10
#[Out]# 22       Luca   24  Coop    0
#[Out]# 23     Jayden   26  Coop   23
#[Out]# 24        Tim   27  Coop    2
#[Out]# 25        Tim   27  Coop   13
#[Out]# 26        Tim   27  Coop   22
#[Out]# 27       Siem   28  Coop   11
#[Out]# 28      Ruben   29  Coop    7
#[Out]# 29       Sven   33  Coop    2
#[Out]# ..        ...  ...   ...  ...
#[Out]# 97      Elena  162  Coop   25
#[Out]# 98      Elena  162  Coop    2
#[Out]# 99       Cato  163  Coop    0
#[Out]# 100      Cato  163  Coop   10
#[Out]# 101     Hanna  165  Coop   10
#[Out]# 102      Lily  169  Coop    1
#[Out]# 103      Lily  169  Coop   13
#[Out]# 104      Lana  172  Coop   16
#[Out]# 105     Amira  176  Coop   11
#[Out]# 106     Amira  176  Coop    5
#[Out]# 107     Eline  177  Coop   18
#[Out]# 108     Eline  177  Coop   26
#[Out]# 109     Eline  177  Coop    4
#[Out]# 110      Elif  178  Coop   25
#[Out]# 111      Juul  179  Coop   27
#[Out]# 112      Juul  179  Coop   10
#[Out]# 113     Merel  180  Coop   26
#[Out]# 114     Merel  180  Coop   13
#[Out]# 115      Liva  181  Coop   26
#[Out]# 116      Liva  181  Coop    6
#[Out]# 117     Wilko  184  Coop    0
#[Out]# 118    Kostas  190  Coop   27
#[Out]# 119    Kostas  190  Coop   10
#[Out]# 120    Kostas  190  Coop    0
#[Out]# 121    Kostas  190  Coop   15
#[Out]# 122    Kostas  190  Coop   23
#[Out]# 123    Kostas  190  Coop   17
#[Out]# 124    Kostas  190  Coop   28
#[Out]# 125    Kostas  190  Coop   11
#[Out]# 126    Kostas  190  Coop    8
#[Out]# 
#[Out]# [127 rows x 4 columns]
# Tue, 01 Dec 2020 13:44:08
query3_4 = '''
    SELECT DISTINCT cName, c.cID, sName, p.ID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Coop'
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 13:44:11
query3_4 = '''
    SELECT DISTINCT cName, c.cID, sName, p.tID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID sName  tID
#[Out]# 0       Lucas    2  Coop   10
#[Out]# 1       Lucas    2  Coop   11
#[Out]# 2       Lucas    2  Coop   12
#[Out]# 3        Daan    4  Coop   18
#[Out]# 4        Daan    4  Coop   19
#[Out]# 5        Levi    5  Coop   24
#[Out]# 6        Levi    5  Coop   25
#[Out]# 7        Levi    5  Coop   26
#[Out]# 8        Liam    8  Coop   34
#[Out]# 9        Liam    8  Coop   35
#[Out]# 10        Sam   10  Coop   36
#[Out]# 11      Thijs   11  Coop   37
#[Out]# 12     Julian   16  Coop   49
#[Out]# 13     Julian   16  Coop   52
#[Out]# 14     Julian   16  Coop   54
#[Out]# 15     Julian   16  Coop   56
#[Out]# 16        Dex   17  Coop   58
#[Out]# 17       Hugo   18  Coop   62
#[Out]# 18       Gijs   20  Coop   68
#[Out]# 19   Benjamin   21  Coop   72
#[Out]# 20       Luca   24  Coop   76
#[Out]# 21       Luca   24  Coop   79
#[Out]# 22       Luca   24  Coop   81
#[Out]# 23     Jayden   26  Coop   85
#[Out]# 24        Tim   27  Coop   88
#[Out]# 25        Tim   27  Coop   90
#[Out]# 26        Tim   27  Coop   91
#[Out]# 27       Siem   28  Coop   92
#[Out]# 28      Ruben   29  Coop   93
#[Out]# 29       Sven   33  Coop  106
#[Out]# ..        ...  ...   ...  ...
#[Out]# 101      Lily  169  Coop  430
#[Out]# 102      Lily  169  Coop  435
#[Out]# 103      Lana  172  Coop  444
#[Out]# 104     Amira  176  Coop  450
#[Out]# 105     Amira  176  Coop  452
#[Out]# 106     Eline  177  Coop  453
#[Out]# 107     Eline  177  Coop  456
#[Out]# 108     Eline  177  Coop  457
#[Out]# 109      Elif  178  Coop  458
#[Out]# 110      Juul  179  Coop  463
#[Out]# 111      Juul  179  Coop  465
#[Out]# 112     Merel  180  Coop  466
#[Out]# 113     Merel  180  Coop  467
#[Out]# 114      Liva  181  Coop  469
#[Out]# 115      Liva  181  Coop  470
#[Out]# 116     Wilko  184  Coop  777
#[Out]# 117    Kostas  190  Coop  784
#[Out]# 118    Kostas  190  Coop  790
#[Out]# 119    Kostas  190  Coop  797
#[Out]# 120    Kostas  190  Coop  798
#[Out]# 121    Kostas  190  Coop  803
#[Out]# 122    Kostas  190  Coop  805
#[Out]# 123    Kostas  190  Coop  815
#[Out]# 124    Kostas  190  Coop  818
#[Out]# 125    Kostas  190  Coop  827
#[Out]# 126    Kostas  190  Coop  829
#[Out]# 127    Kostas  190  Coop  831
#[Out]# 128    Kostas  190  Coop  835
#[Out]# 129    Kostas  190  Coop  837
#[Out]# 130    Kostas  190  Coop  839
#[Out]# 
#[Out]# [131 rows x 4 columns]
# Tue, 01 Dec 2020 13:44:24
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0       Lucas    2
#[Out]# 1        Daan    4
#[Out]# 2        Levi    5
#[Out]# 3        Liam    8
#[Out]# 4         Sam   10
#[Out]# 5       Thijs   11
#[Out]# 6      Julian   16
#[Out]# 7         Dex   17
#[Out]# 8        Hugo   18
#[Out]# 9        Gijs   20
#[Out]# 10   Benjamin   21
#[Out]# 11       Luca   24
#[Out]# 12     Jayden   26
#[Out]# 13        Tim   27
#[Out]# 14       Siem   28
#[Out]# 15      Ruben   29
#[Out]# 16       Sven   33
#[Out]# 17      Stijn   35
#[Out]# 18       Jack   39
#[Out]# 19       Tijn   42
#[Out]# 20       Ties   51
#[Out]# 21      Aiden   55
#[Out]# 22     Nathan   57
#[Out]# 23       Joep   59
#[Out]# 24      Rayan   67
#[Out]# 25       Dean   71
#[Out]# 26       Jace   75
#[Out]# 27  Alexander   76
#[Out]# 28       Mick   78
#[Out]# 29      Dylan   82
#[Out]# ..        ...  ...
#[Out]# 44      Lieke  116
#[Out]# 45       Lisa  118
#[Out]# 46       Elin  122
#[Out]# 47      Milou  123
#[Out]# 48      Sofie  124
#[Out]# 49      Emily  127
#[Out]# 50      Esmee  129
#[Out]# 51        Amy  131
#[Out]# 52     Sophia  133
#[Out]# 53       Ella  134
#[Out]# 54      Sofia  135
#[Out]# 55      Elise  139
#[Out]# 56        Ivy  144
#[Out]# 57     Isabel  147
#[Out]# 58       Jill  151
#[Out]# 59       Anne  152
#[Out]# 60      Floor  161
#[Out]# 61      Elena  162
#[Out]# 62       Cato  163
#[Out]# 63      Hanna  165
#[Out]# 64       Lily  169
#[Out]# 65       Lana  172
#[Out]# 66      Amira  176
#[Out]# 67      Eline  177
#[Out]# 68       Elif  178
#[Out]# 69       Juul  179
#[Out]# 70      Merel  180
#[Out]# 71       Liva  181
#[Out]# 72      Wilko  184
#[Out]# 73     Kostas  190
#[Out]# 
#[Out]# [74 rows x 2 columns]
# Tue, 01 Dec 2020 13:47:41
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Coop' AND 
        (c.cID) NOT IN (SELECT cID 
                        FROM purchase t
                        WHERE t.sID != s.sID )
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0         Sam   10
#[Out]# 1       Thijs   11
#[Out]# 2      Jayden   26
#[Out]# 3        Siem   28
#[Out]# 4   Alexander   76
#[Out]# 5       Joris   88
#[Out]# 6        Anna   99
#[Out]# 7       Lotte  103
#[Out]# 8         Amy  131
#[Out]# 9       Sofia  135
#[Out]# 10      Wilko  184
# Tue, 01 Dec 2020 13:48:28
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Jumbo' AND 
        (c.cID) NOT IN (SELECT cID 
                        FROM purchase t
                        WHERE t.sID != s.sID )
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
# Tue, 01 Dec 2020 13:52:15
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Jumbo' AND 
        (c.cID) NOT IN (SELECT cID 
                        FROM purchase t, store k
                        WHERE t.sID = k.sID AND
                            NOT k.sName LIKE s.sName)
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Tue, 01 Dec 2020 13:52:39
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Jumbo' AND 
        (c.cID) NOT IN (SELECT cID 
                        FROM purchase t, store k
                        WHERE t.sID = k.sID AND
                             k.sName LIKE s.sName)
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 13:52:50
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer c, store s, purchase p
    WHERE p.cID = c.cID AND
        p.sID = s.sID AND
        s.sName LIKE 'Jumbo' AND 
        (c.cID) NOT IN (SELECT cID 
                        FROM purchase t, store k
                        WHERE t.sID = k.sID AND
                            NOT k.sName LIKE s.sName)
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Tue, 01 Dec 2020 13:53:28
query3_4 = '''
SELECT DISTINCT cName, c.cID
FROM customer c, store s, purchase p
WHERE p.cID = c.cID AND
    p.sID = s.sID AND
    s.sName LIKE 'Jumbo' AND 
    (c.cID) NOT IN (SELECT cID 
                    FROM purchase t, store k
                    WHERE t.sID = k.sID AND
                        NOT k.sName LIKE s.sName)
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189

   Bud1                                                                       _ w e e k 3                                          
 l o g s _ w e e k 3dsclbool                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 @                                              @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   E                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          DSDB                                 `                                                     @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          

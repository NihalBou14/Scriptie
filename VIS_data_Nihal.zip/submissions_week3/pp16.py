# IPython log file

# Sat, 28 Nov 2020 14:52:55
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 14:52:58
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1aa9041bf10>
# Sat, 28 Nov 2020 14:53:15
query3_2 = '''
SELECT c.cID, c.cName
FROM customer c, shoppinglist s, purchase p
WHERE c.cID = s.cID AND p.cID = c.cID AND p.date = s.date AND s.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID cName
#[Out]# 0      1   Sem
#[Out]# 1      1   Sem
#[Out]# 2      1   Sem
#[Out]# 3      1   Sem
#[Out]# 4      1   Sem
#[Out]# ..   ...   ...
#[Out]# 971  181  Liva
#[Out]# 972  181  Liva
#[Out]# 973  181  Liva
#[Out]# 974  181  Liva
#[Out]# 975  181  Liva
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Sat, 28 Nov 2020 14:53:46
query3_2 = '''
SELECT DISTINCT c.cID, c.cName
FROM customer c, shoppinglist s, purchase p
WHERE c.cID = s.cID AND p.cID = c.cID AND p.date = s.date AND s.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sat, 28 Nov 2020 14:54:05
query3_2 = '''
SELECT DISTINCT c.cID, c.cName, p.date, s.date
FROM customer c, shoppinglist s, purchase p
WHERE c.cID = s.cID AND p.cID = c.cID AND p.date = s.date AND s.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date        date
#[Out]# 0      1    Sem  2018-08-20  2018-08-20
#[Out]# 1      1    Sem  2018-08-21  2018-08-21
#[Out]# 2      2  Lucas  2018-08-16  2018-08-16
#[Out]# 3      2  Lucas  2018-08-17  2018-08-17
#[Out]# 4      3   Finn  2018-08-18  2018-08-18
#[Out]# ..   ...    ...         ...         ...
#[Out]# 181  179   Juul  2018-08-22  2018-08-22
#[Out]# 182  180  Merel  2018-08-26  2018-08-26
#[Out]# 183  180  Merel  2018-08-27  2018-08-27
#[Out]# 184  181   Liva  2018-08-24  2018-08-24
#[Out]# 185  181   Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [186 rows x 4 columns]
# Sat, 28 Nov 2020 14:54:12
query3_2 = '''
SELECT DISTINCT c.cID, c.cName
FROM customer c, shoppinglist s, purchase p
WHERE c.cID = s.cID AND p.cID = c.cID AND p.date = s.date AND s.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sat, 28 Nov 2020 14:55:20
query3_2 = '''
SELECT DISTINCT c.cName, c.cID
FROM customer c, shoppinglist s, purchase p
WHERE c.cID = s.cID AND p.cID = c.cID AND p.date = s.date AND s.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sat, 28 Nov 2020 14:58:06
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p store s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 14:58:20
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Abel   62
#[Out]# 1      Adam   12
#[Out]# 2     Amber  153
#[Out]# 3    Angela  186
#[Out]# 4    Benthe  154
#[Out]# ..      ...  ...
#[Out]# 111  Veerle  167
#[Out]# 112    Vera  140
#[Out]# 113   Vince   32
#[Out]# 114  Willem   52
#[Out]# 115    Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Sat, 28 Nov 2020 14:59:07
query3_3 = '''
SELECT c.cName, c.cID, s.sName
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 14:59:23
query3_3 = '''
SELECT c.cName, c.cID, s.sName
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID
EXCEPT
SELECT c.cName, c.cID, s.sName
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID      sName
#[Out]# 0       Amira  176  Hoogvliet
#[Out]# 1       Amira  176       Lidl
#[Out]# 2      Angela  186      Jumbo
#[Out]# 3        Anne  152     Sligro
#[Out]# 4    Benjamin   21  Hoogvliet
#[Out]# ..        ...  ...        ...
#[Out]# 255    Willem   52      Jumbo
#[Out]# 256    Willem   52     Sligro
#[Out]# 257      Xavi   47      Jumbo
#[Out]# 258      Yara  112      Jumbo
#[Out]# 259      Yara  112       Lidl
#[Out]# 
#[Out]# [260 rows x 3 columns]
# Sat, 28 Nov 2020 14:59:32
query3_3 = '''
SELECT c.cName, c.cID, s.sName
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID
EXCEPT
SELECT c.cName, c.cID, s.sName
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID      sName
#[Out]# 0        Aiden   55       Coop
#[Out]# 1    Alexander   76       Coop
#[Out]# 2        Amira  176       Coop
#[Out]# 3        Amira  176  Hoogvliet
#[Out]# 4        Amira  176       Lidl
#[Out]# ..         ...  ...        ...
#[Out]# 294     Veerle  167     Sligro
#[Out]# 295      Wilko  184       Coop
#[Out]# 296     Willem   52     Sligro
#[Out]# 297       Yara  112       Coop
#[Out]# 298       Yara  112       Lidl
#[Out]# 
#[Out]# [299 rows x 3 columns]
# Sat, 28 Nov 2020 14:59:43
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sat, 28 Nov 2020 15:02:29
query3_4 = '''
SELECT UNIQUE c.cName, c.cID
FROM customer c, purchase p, shop s
WHERE c.cID = p.cId AND p.sID = s.sID AND s.sName = 'Coop'
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, shop s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName != 'Coop'
'''

pd.read_sql_query(query3_4, conn)
# Sat, 28 Nov 2020 15:02:37
query3_4 = '''
SELECT c.cName, c.cID
FROM customer c, purchase p, shop s
WHERE c.cID = p.cId AND p.sID = s.sID AND s.sName = 'Coop'
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, shop s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName != 'Coop'
'''

pd.read_sql_query(query3_4, conn)
# Sat, 28 Nov 2020 15:02:54
query3_4 = '''
SELECT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cId AND p.sID = s.sID AND s.sName = 'Coop'
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName != 'Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0       Aiden   55
#[Out]# 1   Alexander   76
#[Out]# 2         Amy  131
#[Out]# 3        Anna   99
#[Out]# 4      Jayden   26
#[Out]# 5        Jill  151
#[Out]# 6       Joris   88
#[Out]# 7        Liam    8
#[Out]# 8       Lotte  103
#[Out]# 9         Sam   10
#[Out]# 10       Siem   28
#[Out]# 11      Sofia  135
#[Out]# 12      Thijs   11
#[Out]# 13      Wilko  184
# Sat, 28 Nov 2020 15:11:30
query3_4 = '''
SELECT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cId AND p.sID = s.sID AND s.sName = 'Coop'

'''

pd.read_sql_query(query3_4, conn)
#[Out]#       cName  cID
#[Out]# 0     Lucas    2
#[Out]# 1     Lucas    2
#[Out]# 2     Lucas    2
#[Out]# 3      Daan    4
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 127  Kostas  190
#[Out]# 128  Kostas  190
#[Out]# 129  Kostas  190
#[Out]# 130  Kostas  190
#[Out]# 131  Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Sat, 28 Nov 2020 15:11:45
query3_4 = '''
SELECT c.cName, c.cID, p.pId
FROM customer c, purchase p, store s
WHERE c.cID = p.cId AND p.sID = s.sID AND s.sName = 'Coop'

'''

pd.read_sql_query(query3_4, conn)
#[Out]#       cName  cID  pID
#[Out]# 0     Lucas    2    4
#[Out]# 1     Lucas    2   13
#[Out]# 2     Lucas    2   22
#[Out]# 3      Daan    4   12
#[Out]# 4      Daan    4    6
#[Out]# ..      ...  ...  ...
#[Out]# 127  Kostas  190   11
#[Out]# 128  Kostas  190   17
#[Out]# 129  Kostas  190   23
#[Out]# 130  Kostas  190    8
#[Out]# 131  Kostas  190    8
#[Out]# 
#[Out]# [132 rows x 3 columns]
# Sat, 28 Nov 2020 15:12:46
query3_4 = '''
SELECT c.cName, c.cID, p.pId, s.sId
FROM customer c, purchase p, store s
WHERE c.cID = p.cId AND p.sID = s.sID AND s.sName = 'Coop'

'''

pd.read_sql_query(query3_4, conn)
#[Out]#       cName  cID  pID  sID
#[Out]# 0     Lucas    2    4   13
#[Out]# 1     Lucas    2   13   51
#[Out]# 2     Lucas    2   22   47
#[Out]# 3      Daan    4   12   53
#[Out]# 4      Daan    4    6   21
#[Out]# ..      ...  ...  ...  ...
#[Out]# 127  Kostas  190   11   45
#[Out]# 128  Kostas  190   17   47
#[Out]# 129  Kostas  190   23   51
#[Out]# 130  Kostas  190    8   53
#[Out]# 131  Kostas  190    8   55
#[Out]# 
#[Out]# [132 rows x 4 columns]
# Sat, 28 Nov 2020 15:13:30
query3_4 = '''
SELECT c.cName, c.cID, p.pId, s.sId, s.sName
FROM customer c, purchase p, store s
WHERE c.cID = p.cId AND p.sID = s.sID AND s.sName = 'Coop'

'''

pd.read_sql_query(query3_4, conn)
#[Out]#       cName  cID  pID  sID sName
#[Out]# 0     Lucas    2    4   13  Coop
#[Out]# 1     Lucas    2   13   51  Coop
#[Out]# 2     Lucas    2   22   47  Coop
#[Out]# 3      Daan    4   12   53  Coop
#[Out]# 4      Daan    4    6   21  Coop
#[Out]# ..      ...  ...  ...  ...   ...
#[Out]# 127  Kostas  190   11   45  Coop
#[Out]# 128  Kostas  190   17   47  Coop
#[Out]# 129  Kostas  190   23   51  Coop
#[Out]# 130  Kostas  190    8   53  Coop
#[Out]# 131  Kostas  190    8   55  Coop
#[Out]# 
#[Out]# [132 rows x 5 columns]
# Sat, 28 Nov 2020 16:53:44
query3_4 = '''
SELECT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cId AND p.sID = s.sID AND s.sName = 'Coop'
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName != 'Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0       Aiden   55
#[Out]# 1   Alexander   76
#[Out]# 2         Amy  131
#[Out]# 3        Anna   99
#[Out]# 4      Jayden   26
#[Out]# 5        Jill  151
#[Out]# 6       Joris   88
#[Out]# 7        Liam    8
#[Out]# 8       Lotte  103
#[Out]# 9         Sam   10
#[Out]# 10       Siem   28
#[Out]# 11      Sofia  135
#[Out]# 12      Thijs   11
#[Out]# 13      Wilko  184


# IPython log file

# Mon, 30 Nov 2020 14:01:30
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 14:01:36
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x23f1f74a420>
# Mon, 30 Nov 2020 14:02:33
query3_2 = '''
    SELECT cName, city FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName       city
#[Out]# 0      Noah    Utrecht
#[Out]# 1       Sem      Breda
#[Out]# 2     Lucas  Amsterdam
#[Out]# 3      Finn      Breda
#[Out]# 4      Daan  Amsterdam
#[Out]# ..      ...        ...
#[Out]# 185    Nick  Eindhoven
#[Out]# 186  Angela  Eindhoven
#[Out]# 187    Pino  Rotterdam
#[Out]# 188    Koen        Oss
#[Out]# 189  Kostas    Utrecht
#[Out]# 
#[Out]# [190 rows x 2 columns]

# IPython log file

# Tue, 01 Dec 2020 15:19:37
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 15:19:39
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 01 Dec 2020 15:19:48
query3_2 = '''
    SELECT cName, city FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName       city
#[Out]# 0      Noah    Utrecht
#[Out]# 1       Sem      Breda
#[Out]# 2     Lucas  Amsterdam
#[Out]# 3      Finn      Breda
#[Out]# 4      Daan  Amsterdam
#[Out]# ..      ...        ...
#[Out]# 185    Nick  Eindhoven
#[Out]# 186  Angela  Eindhoven
#[Out]# 187    Pino  Rotterdam
#[Out]# 188    Koen        Oss
#[Out]# 189  Kostas    Utrecht
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:33:48
query3_2 = '''
    SELECT cName, city FROM customer, shoppinglist
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName     city
#[Out]# 0        Noah  Utrecht
#[Out]# 1        Noah  Utrecht
#[Out]# 2        Noah  Utrecht
#[Out]# 3        Noah  Utrecht
#[Out]# 4        Noah  Utrecht
#[Out]# ...       ...      ...
#[Out]# 93475  Kostas  Utrecht
#[Out]# 93476  Kostas  Utrecht
#[Out]# 93477  Kostas  Utrecht
#[Out]# 93478  Kostas  Utrecht
#[Out]# 93479  Kostas  Utrecht
#[Out]# 
#[Out]# [93480 rows x 2 columns]
# Tue, 01 Dec 2020 15:34:28
query3_2 = '''
    SELECT cName, city FROM customer, shoppinglist, purchase WHERE purchase.date = shoppinglist.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#           cName     city
#[Out]# 0          Noah  Utrecht
#[Out]# 1          Noah  Utrecht
#[Out]# 2          Noah  Utrecht
#[Out]# 3          Noah  Utrecht
#[Out]# 4          Noah  Utrecht
#[Out]# ...         ...      ...
#[Out]# 3692075  Kostas  Utrecht
#[Out]# 3692076  Kostas  Utrecht
#[Out]# 3692077  Kostas  Utrecht
#[Out]# 3692078  Kostas  Utrecht
#[Out]# 3692079  Kostas  Utrecht
#[Out]# 
#[Out]# [3692080 rows x 2 columns]
# Tue, 01 Dec 2020 15:35:00
query3_2 = '''
    SELECT cName, city FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName       city
#[Out]# 0      Noah    Utrecht
#[Out]# 1       Sem      Breda
#[Out]# 2     Lucas  Amsterdam
#[Out]# 3      Finn      Breda
#[Out]# 4      Daan  Amsterdam
#[Out]# ..      ...        ...
#[Out]# 185    Nick  Eindhoven
#[Out]# 186  Angela  Eindhoven
#[Out]# 187    Pino  Rotterdam
#[Out]# 188    Koen        Oss
#[Out]# 189  Kostas    Utrecht
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 15:35:54
query3_2 = '''
    SELECT DISTINCT cName FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName
#[Out]# 0      Noah
#[Out]# 1       Sem
#[Out]# 2     Lucas
#[Out]# 3      Finn
#[Out]# 4      Daan
#[Out]# ..      ...
#[Out]# 184    Nick
#[Out]# 185  Angela
#[Out]# 186    Pino
#[Out]# 187    Koen
#[Out]# 188  Kostas
#[Out]# 
#[Out]# [189 rows x 1 columns]
# Tue, 01 Dec 2020 15:36:22
query3_2 = '''
    SELECT cName FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName
#[Out]# 0      Noah
#[Out]# 1       Sem
#[Out]# 2     Lucas
#[Out]# 3      Finn
#[Out]# 4      Daan
#[Out]# ..      ...
#[Out]# 185    Nick
#[Out]# 186  Angela
#[Out]# 187    Pino
#[Out]# 188    Koen
#[Out]# 189  Kostas
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 15:36:40
query3_2 = '''
    SELECT cID FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 15:36:47
query3_2 = '''
    SELECT DISTINCT cID FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 15:37:04
query3_2 = '''
    SELECT DISTINCT FROM customer
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 15:37:15
query3_2 = '''
    SELECT DISTINCT cName FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName
#[Out]# 0      Noah
#[Out]# 1       Sem
#[Out]# 2     Lucas
#[Out]# 3      Finn
#[Out]# 4      Daan
#[Out]# ..      ...
#[Out]# 184    Nick
#[Out]# 185  Angela
#[Out]# 186    Pino
#[Out]# 187    Koen
#[Out]# 188  Kostas
#[Out]# 
#[Out]# [189 rows x 1 columns]
# Tue, 01 Dec 2020 15:46:28
query3_2 = '''
    SELECT DISTINCT cName FROM customer WHERE cID > 100
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName
#[Out]# 0      Eva
#[Out]# 1      Evi
#[Out]# 2    Lotte
#[Out]# 3      Liv
#[Out]# 4     Nora
#[Out]# ..     ...
#[Out]# 84    Nick
#[Out]# 85  Angela
#[Out]# 86    Pino
#[Out]# 87    Koen
#[Out]# 88  Kostas
#[Out]# 
#[Out]# [89 rows x 1 columns]
# Tue, 01 Dec 2020 15:46:47
query3_2 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID > 100
'''

pd.read_sql_query(query3_2, conn)
#[Out]#     cID   cName
#[Out]# 0   101     Eva
#[Out]# 1   102     Evi
#[Out]# 2   103   Lotte
#[Out]# 3   104     Liv
#[Out]# 4   105    Nora
#[Out]# ..  ...     ...
#[Out]# 84  185    Nick
#[Out]# 85  186  Angela
#[Out]# 86  188    Pino
#[Out]# 87  189    Koen
#[Out]# 88  190  Kostas
#[Out]# 
#[Out]# [89 rows x 2 columns]
# Tue, 01 Dec 2020 15:50:10
query3_2 = '''
    SELECT DISTINCT cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 15:50:37
query3_2 = '''
    SELECT DISTINCT cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName
#[Out]# 0      Sem
#[Out]# 1    Lucas
#[Out]# 2     Finn
#[Out]# 3     Levi
#[Out]# 4     Bram
#[Out]# ..     ...
#[Out]# 106  Amira
#[Out]# 107   Elif
#[Out]# 108   Juul
#[Out]# 109  Merel
#[Out]# 110   Liva
#[Out]# 
#[Out]# [111 rows x 1 columns]
# Tue, 01 Dec 2020 15:51:28
query3_2 = '''
    SELECT DISTINCT customer.cID, shoppinglist.cID, purchase.cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cID  cID  cName
#[Out]# 0      1    1    1    Sem
#[Out]# 1      2    2    2  Lucas
#[Out]# 2      3    3    3   Finn
#[Out]# 3      5    5    5   Levi
#[Out]# 4      7    7    7   Bram
#[Out]# ..   ...  ...  ...    ...
#[Out]# 107  176  176  176  Amira
#[Out]# 108  178  178  178   Elif
#[Out]# 109  179  179  179   Juul
#[Out]# 110  180  180  180  Merel
#[Out]# 111  181  181  181   Liva
#[Out]# 
#[Out]# [112 rows x 4 columns]
# Tue, 01 Dec 2020 15:52:08
query3_2 = '''
    SELECT customer.cID, shoppinglist.cID, purchase.cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID  cID  cID cName
#[Out]# 0       1    1    1   Sem
#[Out]# 1       1    1    1   Sem
#[Out]# 2       1    1    1   Sem
#[Out]# 3       1    1    1   Sem
#[Out]# 4       1    1    1   Sem
#[Out]# ...   ...  ...  ...   ...
#[Out]# 2322  181  181  181  Liva
#[Out]# 2323  181  181  181  Liva
#[Out]# 2324  181  181  181  Liva
#[Out]# 2325  181  181  181  Liva
#[Out]# 2326  181  181  181  Liva
#[Out]# 
#[Out]# [2327 rows x 4 columns]
# Tue, 01 Dec 2020 15:52:37
query3_2 = '''
    SELECT customer.cID, shoppinglist.cID, purchase.cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    and shoppinglist.date = purchase.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cID  cID cName
#[Out]# 0      1    1    1   Sem
#[Out]# 1      1    1    1   Sem
#[Out]# 2      1    1    1   Sem
#[Out]# 3      1    1    1   Sem
#[Out]# 4      1    1    1   Sem
#[Out]# ..   ...  ...  ...   ...
#[Out]# 971  181  181  181  Liva
#[Out]# 972  181  181  181  Liva
#[Out]# 973  181  181  181  Liva
#[Out]# 974  181  181  181  Liva
#[Out]# 975  181  181  181  Liva
#[Out]# 
#[Out]# [976 rows x 4 columns]
# Tue, 01 Dec 2020 15:53:03
query3_2 = '''
    SELECT DISTINCT customer.cID, shoppinglist.cID, purchase.cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cID  cID  cName
#[Out]# 0      1    1    1    Sem
#[Out]# 1      2    2    2  Lucas
#[Out]# 2      3    3    3   Finn
#[Out]# 3      5    5    5   Levi
#[Out]# 4      7    7    7   Bram
#[Out]# ..   ...  ...  ...    ...
#[Out]# 107  176  176  176  Amira
#[Out]# 108  178  178  178   Elif
#[Out]# 109  179  179  179   Juul
#[Out]# 110  180  180  180  Merel
#[Out]# 111  181  181  181   Liva
#[Out]# 
#[Out]# [112 rows x 4 columns]
# Tue, 01 Dec 2020 15:53:10
query3_2 = '''
    SELECT DISTINCT customer.cID, shoppinglist.cID, purchase.cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    and shoppinglist.date = purchase.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cID  cID  cName
#[Out]# 0      1    1    1    Sem
#[Out]# 1      2    2    2  Lucas
#[Out]# 2      3    3    3   Finn
#[Out]# 3      5    5    5   Levi
#[Out]# 4      7    7    7   Bram
#[Out]# ..   ...  ...  ...    ...
#[Out]# 99   176  176  176  Amira
#[Out]# 100  178  178  178   Elif
#[Out]# 101  179  179  179   Juul
#[Out]# 102  180  180  180  Merel
#[Out]# 103  181  181  181   Liva
#[Out]# 
#[Out]# [104 rows x 4 columns]
# Tue, 01 Dec 2020 15:55:28
query3_2 = '''
    SELECT DISTINCT customer.cID, shoppinglist.cID, purchase.cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    and shoppinglist.date = purchase.date and purchase.date LIKE "%2015%"
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cID, cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 15:55:34
query3_2 = '''
    SELECT DISTINCT customer.cID, shoppinglist.cID, purchase.cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    and shoppinglist.date = purchase.date and purchase.date LIKE "%2018%"
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cID  cID  cName
#[Out]# 0      1    1    1    Sem
#[Out]# 1      2    2    2  Lucas
#[Out]# 2      3    3    3   Finn
#[Out]# 3      5    5    5   Levi
#[Out]# 4      7    7    7   Bram
#[Out]# ..   ...  ...  ...    ...
#[Out]# 99   176  176  176  Amira
#[Out]# 100  178  178  178   Elif
#[Out]# 101  179  179  179   Juul
#[Out]# 102  180  180  180  Merel
#[Out]# 103  181  181  181   Liva
#[Out]# 
#[Out]# [104 rows x 4 columns]
# Tue, 01 Dec 2020 15:56:13
query3_2 = '''
    SELECT DISTINCT customer.cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    and shoppinglist.date = purchase.date and purchase.date LIKE "%2018%"
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 16:00:59
query3_2 = '''
    SELECT DISTINCT customer.cID, cName purchase.date, shoppinglist.date FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    and shoppinglist.date = purchase.date and purchase.date LIKE "%2018%"
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 16:01:08
query3_2 = '''
    SELECT DISTINCT customer.cID, cName, purchase.date, shoppinglist.date FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    and shoppinglist.date = purchase.date and purchase.date LIKE "%2018%"
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date        date
#[Out]# 0      1    Sem  2018-08-20  2018-08-20
#[Out]# 1      1    Sem  2018-08-21  2018-08-21
#[Out]# 2      2  Lucas  2018-08-16  2018-08-16
#[Out]# 3      2  Lucas  2018-08-17  2018-08-17
#[Out]# 4      3   Finn  2018-08-18  2018-08-18
#[Out]# ..   ...    ...         ...         ...
#[Out]# 181  179   Juul  2018-08-22  2018-08-22
#[Out]# 182  180  Merel  2018-08-26  2018-08-26
#[Out]# 183  180  Merel  2018-08-27  2018-08-27
#[Out]# 184  181   Liva  2018-08-24  2018-08-24
#[Out]# 185  181   Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [186 rows x 4 columns]
# Tue, 01 Dec 2020 16:01:49
query3_2 = '''
    SELECT DISTINCT customer.cID, cName FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    and shoppinglist.date = purchase.date and purchase.date LIKE "%2018%"
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 16:16:23
query3_2 = '''
    SELECT DISTINCT cName, customer.cID FROM customer, shoppinglist, purchase 
    WHERE customer.cID = shoppinglist.cID and shoppinglist.cID = purchase.cID
    and shoppinglist.date = purchase.date and purchase.date LIKE "%2018%"
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 16:19:00
query3_3 = '''
    SELECT DISTINCT cname, customer.cID FROM customer, purchase WHERE
    customer.cID = purchase.cID and purchase.sID = 'Lidl'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 16:20:13
query3_3 = '''
    SELECT DISTINCT cname, customer.cID FROM customer, purchase, store WHERE
    customer.cID = purchase.cID and purchase.sID = store.sID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 127    Nick  185
#[Out]# 128  Angela  186
#[Out]# 129    Pino  188
#[Out]# 130    Koen  189
#[Out]# 131  Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 16:20:55
query3_3 = '''
    SELECT DISTINCT cname, customer.cID FROM customer, purchase, store WHERE
    customer.cID = purchase.cID and purchase.sID = store.sID and
    store.sName = 'Lidl'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0        Sem    1
#[Out]# 1      Lucas    2
#[Out]# 2       Levi    5
#[Out]# 3       Bram    7
#[Out]# 4      James   13
#[Out]# 5     Julian   16
#[Out]# 6       Lars   19
#[Out]# 7       Luca   24
#[Out]# 8      Mason   25
#[Out]# 9       Sven   33
#[Out]# 10      Guus   37
#[Out]# 11      Jens   40
#[Out]# 12      Tijn   42
#[Out]# 13       Tom   43
#[Out]# 14      Ties   51
#[Out]# 15    Nathan   57
#[Out]# 16     Jurre   58
#[Out]# 17      Joep   59
#[Out]# 18  Mohammed   60
#[Out]# 19     Dylan   82
#[Out]# 20      Stef   86
#[Out]# 21   Thijmen   91
#[Out]# 22     Jelte   92
#[Out]# 23      Emma   95
#[Out]# 24      Noor  108
#[Out]# 25      Yara  112
#[Out]# 26     Milou  123
#[Out]# 27     Sofie  124
#[Out]# 28      Puck  157
#[Out]# 29     Fenne  159
#[Out]# 30     Floor  161
#[Out]# 31      Cato  163
#[Out]# 32     Hanna  165
#[Out]# 33      Lily  169
#[Out]# 34      Iris  170
#[Out]# 35       Sam  175
#[Out]# 36     Amira  176
#[Out]# 37      Juul  179
#[Out]# 38    Kostas  190
# Tue, 01 Dec 2020 16:26:11
query3_3 = '''
    SELECT DISTINCT cname, customer.cID, store.sName FROM customer, purchase, store 
    WHERE NOT EXISTS
    (SELECT  FROM customed, purchase, store WHERE customer.cID = purchase.cID and
    purchase.sID = store.sID and
    store.sName = 'Lidl')
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 16:26:34
query3_3 = '''
    SELECT DISTINCT cname, customer.cID, store.sName FROM customer, purchase, store 
    WHERE NOT EXISTS
    (SELECT  FROM customer, purchase, store WHERE customer.cID = purchase.cID and
    purchase.sID = store.sID and
    store.sName = 'Lidl')
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 16:27:47
query3_3 = '''
    SELECT DISTINCT cname, customer.cID FROM customer 
    WHERE NOT EXISTS
    (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID and
    purchase.sID = store.sID and
    store.sName = 'Lidl')
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 16:28:03
query3_3 = '''
    SELECT DISTINCT cname, customer.cID FROM customer 
    WHERE NOT EXISTS
    (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID and
    purchase.sID = store.sID and
    store.sName = 'Coop')
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 16:28:22
query3_3 = '''
    SELECT DISTINCT cname, customer.cID FROM customer, purchase, store 
    WHERE NOT EXISTS
    (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID and
    purchase.sID = store.sID and
    store.sName = 'Coop')
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 16:31:22
query3_3 = '''
    SELECT DISTINCT cname, cID FROM customer 
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer WHERE customer.cID >2)
'''

pd.read_sql_query(query3_3, conn)
#[Out]#    cName  cID
#[Out]# 0   Noah    0
#[Out]# 1    Sem    1
#[Out]# 2  Lucas    2
# Tue, 01 Dec 2020 16:31:52
query3_3 = '''
    SELECT DISTINCT cname, cID FROM customer 
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID >2)
'''

pd.read_sql_query(query3_3, conn)
#[Out]#    cName  cID
#[Out]# 0   Noah    0
#[Out]# 1    Sem    1
#[Out]# 2  Lucas    2
# Tue, 01 Dec 2020 16:32:33
query3_3 = '''
    SELECT DISTINCT cname, cID FROM customer 
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID)
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0      Milan    6
#[Out]# 1     Thomas    9
#[Out]# 2       Adam   12
#[Out]# 3        Max   14
#[Out]# 4        Jan   23
#[Out]# 5      Vince   32
#[Out]# 6       Boaz   36
#[Out]# 7      Fedde   46
#[Out]# 8       Tygo   48
#[Out]# 9        Cas   49
#[Out]# 10       Pim   50
#[Out]# 11       Job   53
#[Out]# 12       Jax   54
#[Out]# 13    Tobias   56
#[Out]# 14    Morris   61
#[Out]# 15      Abel   62
#[Out]# 16    Pepijn   65
#[Out]# 17      Owen   73
#[Out]# 18    Samuel   74
#[Out]# 19    Joshua   79
#[Out]# 20     Simon   81
#[Out]# 21     Melle   83
#[Out]# 22     Jelle   87
#[Out]# 23  Johannes   89
#[Out]# 24     Oscar   93
#[Out]# 25     Julia   98
#[Out]# 26       Eva  101
#[Out]# 27       Evi  102
#[Out]# 28      Nora  105
#[Out]# 29     Fleur  106
#[Out]# 30    Olivia  107
#[Out]# 31      Maud  114
#[Out]# 32      Nova  115
#[Out]# 33      Roos  117
#[Out]# 34     Sarah  120
#[Out]# 35       Isa  121
#[Out]# 36       Noa  125
#[Out]# 37     Sanne  130
#[Out]# 38    Hannah  132
#[Out]# 39     Maria  138
#[Out]# 40      Vera  140
#[Out]# 41       Mia  141
#[Out]# 42        Bo  142
#[Out]# 43     Naomi  143
#[Out]# 44     Norah  146
#[Out]# 45  Isabella  148
#[Out]# 46     Julie  150
#[Out]# 47     Amber  153
#[Out]# 48    Benthe  154
#[Out]# 49     Linde  155
#[Out]# 50      Luna  156
#[Out]# 51      Rosa  158
#[Out]# 52      Lara  160
#[Out]# 53       Evy  164
#[Out]# 54   Rosalie  166
#[Out]# 55     Livia  173
#[Out]# 56      Romy  174
#[Out]# 57     Nikki  183
# Tue, 01 Dec 2020 16:33:38
query3_3 = '''
    SELECT DISTINCT cname, cID, store.sName FROM customer, store
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID
    and store.sName = 'Lidl')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cName  cID        sName
#[Out]# 0     Noah    0         Coop
#[Out]# 1     Noah    0    Hoogvliet
#[Out]# 2     Noah    0        Jumbo
#[Out]# 3     Noah    0       Sligro
#[Out]# 4     Noah    0  Albert Hein
#[Out]# ...    ...  ...          ...
#[Out]# 1052  Koen  189        Jumbo
#[Out]# 1053  Koen  189       Sligro
#[Out]# 1054  Koen  189  Albert Hein
#[Out]# 1055  Koen  189         Lidl
#[Out]# 1056  Koen  189         Dirk
#[Out]# 
#[Out]# [1057 rows x 3 columns]
# Tue, 01 Dec 2020 16:34:15
query3_3 = '''
    SELECT DISTINCT cname, cID FROM customer, store
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID
    and store.sName = 'Lidl')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1      Finn    3
#[Out]# 2      Daan    4
#[Out]# 3     Milan    6
#[Out]# 4      Liam    8
#[Out]# ..      ...  ...
#[Out]# 146   Wilko  184
#[Out]# 147    Nick  185
#[Out]# 148  Angela  186
#[Out]# 149    Pino  188
#[Out]# 150    Koen  189
#[Out]# 
#[Out]# [151 rows x 2 columns]
# Tue, 01 Dec 2020 16:34:26
query3_3 = '''
    SELECT DISTINCT cname, cID FROM customer, store
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID
    and store.sName = 'Jumbo')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 16:34:34
query3_3 = '''
    SELECT DISTINCT cname, cID FROM customer, store
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID
    and store.sName = 'Coop')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 16:34:55
query3_3 = '''
    SELECT DISTINCT cname, cID FROM customer, store
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID
    and store.sName = 'Dirk')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1     Lucas    2
#[Out]# 2      Daan    4
#[Out]# 3      Levi    5
#[Out]# 4     Milan    6
#[Out]# ..      ...  ...
#[Out]# 153   Wilko  184
#[Out]# 154    Nick  185
#[Out]# 155  Angela  186
#[Out]# 156    Pino  188
#[Out]# 157    Koen  189
#[Out]# 
#[Out]# [158 rows x 2 columns]
# Tue, 01 Dec 2020 16:35:42
query3_3 = '''
    SELECT DISTINCT cname, cID FROM customer, store
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID
    and store.sName = 'Kumar')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 16:35:46
query3_3 = '''
    SELECT DISTINCT cname, cID FROM customer, store
    WHERE cID NOT IN
    (SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID
    and store.sName = 'Kumar')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 16:41:43
query3_4 = '''
    SELECT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID
    and store.sName = 'Lidl'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     1
#[Out]# 2     1
#[Out]# 3     2
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 59  190
#[Out]# 60  190
#[Out]# 61  190
#[Out]# 62  190
#[Out]# 63  190
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 01 Dec 2020 16:42:10
query3_4 = '''
    SELECT DISTINCT customer.cID FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID and purchase.sID = store.sID
    and store.sName = 'Lidl'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     5
#[Out]# 3     7
#[Out]# 4    13
#[Out]# 5    16
#[Out]# 6    19
#[Out]# 7    24
#[Out]# 8    25
#[Out]# 9    33
#[Out]# 10   37
#[Out]# 11   40
#[Out]# 12   42
#[Out]# 13   43
#[Out]# 14   51
#[Out]# 15   57
#[Out]# 16   58
#[Out]# 17   59
#[Out]# 18   60
#[Out]# 19   82
#[Out]# 20   86
#[Out]# 21   91
#[Out]# 22   92
#[Out]# 23   95
#[Out]# 24  108
#[Out]# 25  112
#[Out]# 26  123
#[Out]# 27  124
#[Out]# 28  157
#[Out]# 29  159
#[Out]# 30  161
#[Out]# 31  163
#[Out]# 32  165
#[Out]# 33  169
#[Out]# 34  170
#[Out]# 35  175
#[Out]# 36  176
#[Out]# 37  179
#[Out]# 38  190
# Tue, 01 Dec 2020 16:45:31
query3_4 = '''
    SELECT customer.cID, cName FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName = 'Lidl' 
    and cID NOT IN(
    SELECT customer.cID 
    FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName != 'Lidl')
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 16:45:47
query3_4 = '''
    SELECT customer.cID, cName FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName = 'Lidl' 
    and customer.cID NOT IN(
    SELECT customer.cID 
    FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName != 'Lidl')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  cName
#[Out]# 0   25  Mason
# Tue, 01 Dec 2020 16:49:39
query3_4 = '''
    SELECT customer.cID, cName FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName = 'Lidl' 
    and customer.cID NOT IN(
    SELECT customer.cID 
    FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName != 'Coop')
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 16:49:55
query3_4 = '''
    SELECT customer.cID, cName FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName = 'Coop' 
    and customer.cID NOT IN(
    SELECT customer.cID 
    FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName != 'Coop')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID      cName
#[Out]# 0     8       Liam
#[Out]# 1     8       Liam
#[Out]# 2    10        Sam
#[Out]# 3    11      Thijs
#[Out]# 4    26     Jayden
#[Out]# 5    28       Siem
#[Out]# 6    55      Aiden
#[Out]# 7    55      Aiden
#[Out]# 8    76  Alexander
#[Out]# 9    88      Joris
#[Out]# 10   99       Anna
#[Out]# 11  103      Lotte
#[Out]# 12  131        Amy
#[Out]# 13  135      Sofia
#[Out]# 14  151       Jill
#[Out]# 15  151       Jill
#[Out]# 16  184      Wilko
# Tue, 01 Dec 2020 16:50:15
query3_4 = '''
    SELECT DISTINCT customer.cID, cName FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName = 'Coop' 
    and customer.cID NOT IN(
    SELECT customer.cID 
    FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName != 'Coop')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID      cName
#[Out]# 0     8       Liam
#[Out]# 1    10        Sam
#[Out]# 2    11      Thijs
#[Out]# 3    26     Jayden
#[Out]# 4    28       Siem
#[Out]# 5    55      Aiden
#[Out]# 6    76  Alexander
#[Out]# 7    88      Joris
#[Out]# 8    99       Anna
#[Out]# 9   103      Lotte
#[Out]# 10  131        Amy
#[Out]# 11  135      Sofia
#[Out]# 12  151       Jill
#[Out]# 13  184      Wilko
# Tue, 01 Dec 2020 16:50:44
query3_4 = '''
    SELECT DISTINCT customer.cID, cName FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName = 'Coop' 
    and customer.cID NOT IN(
    SELECT customer.cID 
    FROM customer, purchase, store 
    WHERE customer.cID = purchase.cID 
    and purchase.sID = store.sID
    and store.sName = 'Coop')
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []


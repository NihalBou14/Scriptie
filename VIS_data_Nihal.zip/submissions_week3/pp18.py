# IPython log file

# Mon, 30 Nov 2020 15:30:44
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 15:31:18
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1640bf14e30>
# Wed, 02 Dec 2020 08:58:24
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x000001640BF14E30>
# Wed, 02 Dec 2020 08:58:25
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x000001640BF14E30>
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Wed, 02 Dec 2020 08:58:29
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 08:58:33
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 08:58:39
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x000001640BF14E30>
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 08:58:43
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 08:58:49
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 08:58:52
query3_2 = '''
    select * from shoppinglist;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  pID  quantity        date
#[Out]# 0      1   14         2  2018-08-20
#[Out]# 1      1   16         3  2018-08-20
#[Out]# 2      1    9         2  2018-08-20
#[Out]# 3      1   25         4  2018-08-20
#[Out]# 4      1   21         6  2018-08-20
#[Out]# 5      1   26         4  2018-08-20
#[Out]# 6      1   11         8  2018-08-20
#[Out]# 7      1   27         6  2018-08-21
#[Out]# 8      2   20         4  2018-08-16
#[Out]# 9      2    9         7  2018-08-16
#[Out]# 10     2    4         6  2018-08-17
#[Out]# 11     2   13         4  2018-08-17
#[Out]# 12     2   22         1  2018-08-17
#[Out]# 13     3   14         2  2018-08-18
#[Out]# 14     3   26         2  2018-08-18
#[Out]# 15     3    9         6  2018-08-19
#[Out]# 16     5   14         6  2018-08-17
#[Out]# 17     5   28         6  2018-08-22
#[Out]# 18     5    6         9  2018-08-22
#[Out]# 19     5   22         2  2018-08-23
#[Out]# 20     5   16         2  2018-08-23
#[Out]# 21     5   19         1  2018-08-23
#[Out]# 22     7   19         2  2018-08-23
#[Out]# 23     7    2         6  2018-08-23
#[Out]# 24     7   16         4  2018-08-23
#[Out]# 25     7   12         2  2018-08-24
#[Out]# 26     7    6         4  2018-08-25
#[Out]# 27     7   20         6  2018-08-26
#[Out]# 28     8   10         9  2018-08-16
#[Out]# 29     8    6         7  2018-08-16
#[Out]# ..   ...  ...       ...         ...
#[Out]# 462  176    4         7  2018-08-22
#[Out]# 463  176   24         9  2018-08-25
#[Out]# 464  176   13         7  2018-08-25
#[Out]# 465  176    0         2  2018-08-25
#[Out]# 466  176   14         2  2018-08-25
#[Out]# 467  176   11         6  2018-08-25
#[Out]# 468  176   21         8  2018-08-25
#[Out]# 469  176    5         9  2018-08-26
#[Out]# 470  178   25         9  2018-08-27
#[Out]# 471  178   24         1  2018-08-27
#[Out]# 472  179   14         5  2018-08-24
#[Out]# 473  179   11         3  2018-08-24
#[Out]# 474  179   17         2  2018-08-24
#[Out]# 475  179   27         8  2018-08-22
#[Out]# 476  179   16         9  2018-08-22
#[Out]# 477  179   10         7  2018-08-22
#[Out]# 478  180   26         3  2018-08-26
#[Out]# 479  180   13         8  2018-08-26
#[Out]# 480  180   10         3  2018-08-27
#[Out]# 481  181   26         4  2018-08-24
#[Out]# 482  181    6         3  2018-08-24
#[Out]# 483  181   21         5  2018-08-27
#[Out]# 484  181    5         3  2018-08-27
#[Out]# 485  183    5         7  2018-08-19
#[Out]# 486  183   10         2  2018-08-20
#[Out]# 487  183   12         9  2018-08-21
#[Out]# 488  183   18         8  2018-08-21
#[Out]# 489  183    6         3  2018-08-22
#[Out]# 490  183   14         7  2018-08-22
#[Out]# 491  183   25         4  2018-08-22
#[Out]# 
#[Out]# [492 rows x 4 columns]
# Wed, 02 Dec 2020 09:13:17
query3_2 = '''
    select cID, cName
    from customer
    where cID in (
        select l.cID
        from shoppinglist l, purchase p
        where l.cID = p.cID
              l.date = p.date
              l.date = '2018-*-*'              
    )
    ;
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:20:11
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID
              l.date = p.date
              l.date = '2018-*-*';
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:20:23
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID
              ;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID
#[Out]# 0       1
#[Out]# 1       1
#[Out]# 2       1
#[Out]# 3       1
#[Out]# 4       1
#[Out]# 5       1
#[Out]# 6       1
#[Out]# 7       1
#[Out]# 8       1
#[Out]# 9       1
#[Out]# 10      1
#[Out]# 11      1
#[Out]# 12      1
#[Out]# 13      1
#[Out]# 14      1
#[Out]# 15      1
#[Out]# 16      1
#[Out]# 17      1
#[Out]# 18      1
#[Out]# 19      1
#[Out]# 20      1
#[Out]# 21      1
#[Out]# 22      1
#[Out]# 23      1
#[Out]# 24      1
#[Out]# 25      1
#[Out]# 26      1
#[Out]# 27      1
#[Out]# 28      1
#[Out]# 29      1
#[Out]# ...   ...
#[Out]# 2297  179
#[Out]# 2298  179
#[Out]# 2299  179
#[Out]# 2300  179
#[Out]# 2301  179
#[Out]# 2302  179
#[Out]# 2303  179
#[Out]# 2304  179
#[Out]# 2305  179
#[Out]# 2306  180
#[Out]# 2307  180
#[Out]# 2308  180
#[Out]# 2309  180
#[Out]# 2310  180
#[Out]# 2311  180
#[Out]# 2312  180
#[Out]# 2313  180
#[Out]# 2314  180
#[Out]# 2315  181
#[Out]# 2316  181
#[Out]# 2317  181
#[Out]# 2318  181
#[Out]# 2319  181
#[Out]# 2320  181
#[Out]# 2321  181
#[Out]# 2322  181
#[Out]# 2323  181
#[Out]# 2324  181
#[Out]# 2325  181
#[Out]# 2326  181
#[Out]# 
#[Out]# [2327 rows x 1 columns]
# Wed, 02 Dec 2020 09:20:50
print(json.dumps(yapf_reformat(u"query3_2 = '''\n     select l.cID\n     from shoppinglist l, purchase p\n        where l.cID = p.cID\n              l.date = p.date\n;\n'''\n\npd.read_sql_query(query3_2, conn)")))
# Wed, 02 Dec 2020 09:20:51
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID
              l.date = p.date
;
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:20:59
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID
              l.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:21:33
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID
              l.date = '2018-*-*';
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:21:45
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID,
              l.date = p.date,
              l.date = '2018-*-*';
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:22:09
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID,
              l.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:22:56
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID
        and   l.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# 5      1
#[Out]# 6      1
#[Out]# 7      1
#[Out]# 8      1
#[Out]# 9      1
#[Out]# 10     1
#[Out]# 11     1
#[Out]# 12     1
#[Out]# 13     1
#[Out]# 14     1
#[Out]# 15     1
#[Out]# 16     1
#[Out]# 17     1
#[Out]# 18     1
#[Out]# 19     1
#[Out]# 20     1
#[Out]# 21     1
#[Out]# 22     1
#[Out]# 23     1
#[Out]# 24     1
#[Out]# 25     1
#[Out]# 26     1
#[Out]# 27     1
#[Out]# 28     1
#[Out]# 29     1
#[Out]# ..   ...
#[Out]# 946  176
#[Out]# 947  178
#[Out]# 948  178
#[Out]# 949  178
#[Out]# 950  178
#[Out]# 951  179
#[Out]# 952  179
#[Out]# 953  179
#[Out]# 954  179
#[Out]# 955  179
#[Out]# 956  179
#[Out]# 957  179
#[Out]# 958  179
#[Out]# 959  179
#[Out]# 960  179
#[Out]# 961  179
#[Out]# 962  179
#[Out]# 963  179
#[Out]# 964  179
#[Out]# 965  179
#[Out]# 966  180
#[Out]# 967  180
#[Out]# 968  180
#[Out]# 969  180
#[Out]# 970  181
#[Out]# 971  181
#[Out]# 972  181
#[Out]# 973  181
#[Out]# 974  181
#[Out]# 975  181
#[Out]# 
#[Out]# [976 rows x 1 columns]
# Wed, 02 Dec 2020 09:23:15
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID
        and   l.date = p.date
        and   l.date = '2018-*-*';
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Wed, 02 Dec 2020 09:24:08
query3_2 = '''
     select l.cID
     from shoppinglist l, purchase p
        where l.cID = p.cID
        and   l.date = p.date
        and   l.date = '2018%';
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Wed, 02 Dec 2020 09:24:56
query3_2 = '''
     select l.cID,l.date
     from shoppinglist l, purchase p
        where l.cID = p.cID
        and   l.date = p.date
        and   l.date = '2018%';
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Wed, 02 Dec 2020 09:25:01
query3_2 = '''
     select l.cID,l.date
     from shoppinglist l, purchase p
        where l.cID = p.cID
        and   l.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID        date
#[Out]# 0      1  2018-08-20
#[Out]# 1      1  2018-08-20
#[Out]# 2      1  2018-08-20
#[Out]# 3      1  2018-08-20
#[Out]# 4      1  2018-08-20
#[Out]# 5      1  2018-08-20
#[Out]# 6      1  2018-08-20
#[Out]# 7      1  2018-08-20
#[Out]# 8      1  2018-08-20
#[Out]# 9      1  2018-08-20
#[Out]# 10     1  2018-08-20
#[Out]# 11     1  2018-08-20
#[Out]# 12     1  2018-08-20
#[Out]# 13     1  2018-08-20
#[Out]# 14     1  2018-08-20
#[Out]# 15     1  2018-08-20
#[Out]# 16     1  2018-08-20
#[Out]# 17     1  2018-08-20
#[Out]# 18     1  2018-08-20
#[Out]# 19     1  2018-08-20
#[Out]# 20     1  2018-08-20
#[Out]# 21     1  2018-08-20
#[Out]# 22     1  2018-08-20
#[Out]# 23     1  2018-08-20
#[Out]# 24     1  2018-08-20
#[Out]# 25     1  2018-08-20
#[Out]# 26     1  2018-08-20
#[Out]# 27     1  2018-08-20
#[Out]# 28     1  2018-08-20
#[Out]# 29     1  2018-08-20
#[Out]# ..   ...         ...
#[Out]# 946  176  2018-08-26
#[Out]# 947  178  2018-08-27
#[Out]# 948  178  2018-08-27
#[Out]# 949  178  2018-08-27
#[Out]# 950  178  2018-08-27
#[Out]# 951  179  2018-08-24
#[Out]# 952  179  2018-08-24
#[Out]# 953  179  2018-08-24
#[Out]# 954  179  2018-08-24
#[Out]# 955  179  2018-08-24
#[Out]# 956  179  2018-08-24
#[Out]# 957  179  2018-08-24
#[Out]# 958  179  2018-08-24
#[Out]# 959  179  2018-08-24
#[Out]# 960  179  2018-08-22
#[Out]# 961  179  2018-08-22
#[Out]# 962  179  2018-08-22
#[Out]# 963  179  2018-08-22
#[Out]# 964  179  2018-08-22
#[Out]# 965  179  2018-08-22
#[Out]# 966  180  2018-08-26
#[Out]# 967  180  2018-08-26
#[Out]# 968  180  2018-08-27
#[Out]# 969  180  2018-08-27
#[Out]# 970  181  2018-08-24
#[Out]# 971  181  2018-08-24
#[Out]# 972  181  2018-08-24
#[Out]# 973  181  2018-08-24
#[Out]# 974  181  2018-08-27
#[Out]# 975  181  2018-08-27
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Wed, 02 Dec 2020 09:25:21
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.cID = p.cID
        and   l.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID        date        date
#[Out]# 0      1  2018-08-20  2018-08-20
#[Out]# 1      1  2018-08-20  2018-08-20
#[Out]# 2      1  2018-08-20  2018-08-20
#[Out]# 3      1  2018-08-20  2018-08-20
#[Out]# 4      1  2018-08-20  2018-08-20
#[Out]# 5      1  2018-08-20  2018-08-20
#[Out]# 6      1  2018-08-20  2018-08-20
#[Out]# 7      1  2018-08-20  2018-08-20
#[Out]# 8      1  2018-08-20  2018-08-20
#[Out]# 9      1  2018-08-20  2018-08-20
#[Out]# 10     1  2018-08-20  2018-08-20
#[Out]# 11     1  2018-08-20  2018-08-20
#[Out]# 12     1  2018-08-20  2018-08-20
#[Out]# 13     1  2018-08-20  2018-08-20
#[Out]# 14     1  2018-08-20  2018-08-20
#[Out]# 15     1  2018-08-20  2018-08-20
#[Out]# 16     1  2018-08-20  2018-08-20
#[Out]# 17     1  2018-08-20  2018-08-20
#[Out]# 18     1  2018-08-20  2018-08-20
#[Out]# 19     1  2018-08-20  2018-08-20
#[Out]# 20     1  2018-08-20  2018-08-20
#[Out]# 21     1  2018-08-20  2018-08-20
#[Out]# 22     1  2018-08-20  2018-08-20
#[Out]# 23     1  2018-08-20  2018-08-20
#[Out]# 24     1  2018-08-20  2018-08-20
#[Out]# 25     1  2018-08-20  2018-08-20
#[Out]# 26     1  2018-08-20  2018-08-20
#[Out]# 27     1  2018-08-20  2018-08-20
#[Out]# 28     1  2018-08-20  2018-08-20
#[Out]# 29     1  2018-08-20  2018-08-20
#[Out]# ..   ...         ...         ...
#[Out]# 946  176  2018-08-26  2018-08-26
#[Out]# 947  178  2018-08-27  2018-08-27
#[Out]# 948  178  2018-08-27  2018-08-27
#[Out]# 949  178  2018-08-27  2018-08-27
#[Out]# 950  178  2018-08-27  2018-08-27
#[Out]# 951  179  2018-08-24  2018-08-24
#[Out]# 952  179  2018-08-24  2018-08-24
#[Out]# 953  179  2018-08-24  2018-08-24
#[Out]# 954  179  2018-08-24  2018-08-24
#[Out]# 955  179  2018-08-24  2018-08-24
#[Out]# 956  179  2018-08-24  2018-08-24
#[Out]# 957  179  2018-08-24  2018-08-24
#[Out]# 958  179  2018-08-24  2018-08-24
#[Out]# 959  179  2018-08-24  2018-08-24
#[Out]# 960  179  2018-08-22  2018-08-22
#[Out]# 961  179  2018-08-22  2018-08-22
#[Out]# 962  179  2018-08-22  2018-08-22
#[Out]# 963  179  2018-08-22  2018-08-22
#[Out]# 964  179  2018-08-22  2018-08-22
#[Out]# 965  179  2018-08-22  2018-08-22
#[Out]# 966  180  2018-08-26  2018-08-26
#[Out]# 967  180  2018-08-26  2018-08-26
#[Out]# 968  180  2018-08-27  2018-08-27
#[Out]# 969  180  2018-08-27  2018-08-27
#[Out]# 970  181  2018-08-24  2018-08-24
#[Out]# 971  181  2018-08-24  2018-08-24
#[Out]# 972  181  2018-08-24  2018-08-24
#[Out]# 973  181  2018-08-24  2018-08-24
#[Out]# 974  181  2018-08-27  2018-08-27
#[Out]# 975  181  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [976 rows x 3 columns]
# Wed, 02 Dec 2020 09:26:09
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.cID = p.cID
        and   l.date = p.date = "2018%";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date, date]
#[Out]# Index: []
# Wed, 02 Dec 2020 09:26:20
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.cID = p.cID
        and   l.date = p.date = "2018-%-%";
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date, date]
#[Out]# Index: []
# Wed, 02 Dec 2020 09:27:08
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.date like '2018-10-%'';
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:27:27
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.date like '2018-10-%';
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date, date]
#[Out]# Index: []
# Wed, 02 Dec 2020 09:27:30
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.date like '2018-10-24';
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date, date]
#[Out]# Index: []
# Wed, 02 Dec 2020 09:27:43
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        ;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cID        date        date
#[Out]# 0         1  2018-08-20  2018-08-22
#[Out]# 1         1  2018-08-20  2018-08-22
#[Out]# 2         1  2018-08-20  2018-08-22
#[Out]# 3         1  2018-08-20  2018-08-22
#[Out]# 4         1  2018-08-20  2018-08-22
#[Out]# 5         1  2018-08-20  2018-08-22
#[Out]# 6         1  2018-08-20  2018-08-22
#[Out]# 7         1  2018-08-21  2018-08-22
#[Out]# 8         2  2018-08-17  2018-08-22
#[Out]# 9         2  2018-08-16  2018-08-22
#[Out]# 10        2  2018-08-17  2018-08-22
#[Out]# 11        2  2018-08-16  2018-08-22
#[Out]# 12        2  2018-08-17  2018-08-22
#[Out]# 13        3  2018-08-19  2018-08-22
#[Out]# 14        3  2018-08-18  2018-08-22
#[Out]# 15        3  2018-08-18  2018-08-22
#[Out]# 16        5  2018-08-22  2018-08-22
#[Out]# 17        5  2018-08-17  2018-08-22
#[Out]# 18        5  2018-08-23  2018-08-22
#[Out]# 19        5  2018-08-23  2018-08-22
#[Out]# 20        5  2018-08-23  2018-08-22
#[Out]# 21        5  2018-08-22  2018-08-22
#[Out]# 22        7  2018-08-23  2018-08-22
#[Out]# 23        7  2018-08-25  2018-08-22
#[Out]# 24        7  2018-08-24  2018-08-22
#[Out]# 25        7  2018-08-23  2018-08-22
#[Out]# 26        7  2018-08-23  2018-08-22
#[Out]# 27        7  2018-08-26  2018-08-22
#[Out]# 28        8  2018-08-16  2018-08-22
#[Out]# 29        8  2018-08-16  2018-08-22
#[Out]# ...     ...         ...         ...
#[Out]# 250398  176  2018-08-25  2018-08-21
#[Out]# 250399  176  2018-08-22  2018-08-21
#[Out]# 250400  176  2018-08-26  2018-08-21
#[Out]# 250401  176  2018-08-25  2018-08-21
#[Out]# 250402  176  2018-08-25  2018-08-21
#[Out]# 250403  176  2018-08-25  2018-08-21
#[Out]# 250404  176  2018-08-25  2018-08-21
#[Out]# 250405  176  2018-08-25  2018-08-21
#[Out]# 250406  178  2018-08-27  2018-08-21
#[Out]# 250407  178  2018-08-27  2018-08-21
#[Out]# 250408  179  2018-08-22  2018-08-21
#[Out]# 250409  179  2018-08-24  2018-08-21
#[Out]# 250410  179  2018-08-24  2018-08-21
#[Out]# 250411  179  2018-08-22  2018-08-21
#[Out]# 250412  179  2018-08-24  2018-08-21
#[Out]# 250413  179  2018-08-22  2018-08-21
#[Out]# 250414  180  2018-08-27  2018-08-21
#[Out]# 250415  180  2018-08-26  2018-08-21
#[Out]# 250416  180  2018-08-26  2018-08-21
#[Out]# 250417  181  2018-08-27  2018-08-21
#[Out]# 250418  181  2018-08-24  2018-08-21
#[Out]# 250419  181  2018-08-27  2018-08-21
#[Out]# 250420  181  2018-08-24  2018-08-21
#[Out]# 250421  183  2018-08-19  2018-08-21
#[Out]# 250422  183  2018-08-22  2018-08-21
#[Out]# 250423  183  2018-08-20  2018-08-21
#[Out]# 250424  183  2018-08-21  2018-08-21
#[Out]# 250425  183  2018-08-22  2018-08-21
#[Out]# 250426  183  2018-08-21  2018-08-21
#[Out]# 250427  183  2018-08-22  2018-08-21
#[Out]# 
#[Out]# [250428 rows x 3 columns]
# Wed, 02 Dec 2020 09:27:59
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.date like '2018-08-24';
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID        date        date
#[Out]# 0        7  2018-08-24  2018-08-22
#[Out]# 1       29  2018-08-24  2018-08-22
#[Out]# 2       29  2018-08-24  2018-08-22
#[Out]# 3       46  2018-08-24  2018-08-22
#[Out]# 4       52  2018-08-24  2018-08-22
#[Out]# 5       59  2018-08-24  2018-08-22
#[Out]# 6       68  2018-08-24  2018-08-22
#[Out]# 7       71  2018-08-24  2018-08-22
#[Out]# 8       71  2018-08-24  2018-08-22
#[Out]# 9       71  2018-08-24  2018-08-22
#[Out]# 10      82  2018-08-24  2018-08-22
#[Out]# 11      83  2018-08-24  2018-08-22
#[Out]# 12      87  2018-08-24  2018-08-22
#[Out]# 13      88  2018-08-24  2018-08-22
#[Out]# 14      92  2018-08-24  2018-08-22
#[Out]# 15      95  2018-08-24  2018-08-22
#[Out]# 16      95  2018-08-24  2018-08-22
#[Out]# 17      97  2018-08-24  2018-08-22
#[Out]# 18     102  2018-08-24  2018-08-22
#[Out]# 19     112  2018-08-24  2018-08-22
#[Out]# 20     116  2018-08-24  2018-08-22
#[Out]# 21     116  2018-08-24  2018-08-22
#[Out]# 22     119  2018-08-24  2018-08-22
#[Out]# 23     119  2018-08-24  2018-08-22
#[Out]# 24     123  2018-08-24  2018-08-22
#[Out]# 25     123  2018-08-24  2018-08-22
#[Out]# 26     147  2018-08-24  2018-08-22
#[Out]# 27     147  2018-08-24  2018-08-22
#[Out]# 28     149  2018-08-24  2018-08-22
#[Out]# 29     149  2018-08-24  2018-08-22
#[Out]# ...    ...         ...         ...
#[Out]# 20330   82  2018-08-24  2018-08-21
#[Out]# 20331   83  2018-08-24  2018-08-21
#[Out]# 20332   87  2018-08-24  2018-08-21
#[Out]# 20333   88  2018-08-24  2018-08-21
#[Out]# 20334   92  2018-08-24  2018-08-21
#[Out]# 20335   95  2018-08-24  2018-08-21
#[Out]# 20336   95  2018-08-24  2018-08-21
#[Out]# 20337   97  2018-08-24  2018-08-21
#[Out]# 20338  102  2018-08-24  2018-08-21
#[Out]# 20339  112  2018-08-24  2018-08-21
#[Out]# 20340  116  2018-08-24  2018-08-21
#[Out]# 20341  116  2018-08-24  2018-08-21
#[Out]# 20342  119  2018-08-24  2018-08-21
#[Out]# 20343  119  2018-08-24  2018-08-21
#[Out]# 20344  123  2018-08-24  2018-08-21
#[Out]# 20345  123  2018-08-24  2018-08-21
#[Out]# 20346  147  2018-08-24  2018-08-21
#[Out]# 20347  147  2018-08-24  2018-08-21
#[Out]# 20348  149  2018-08-24  2018-08-21
#[Out]# 20349  149  2018-08-24  2018-08-21
#[Out]# 20350  162  2018-08-24  2018-08-21
#[Out]# 20351  165  2018-08-24  2018-08-21
#[Out]# 20352  165  2018-08-24  2018-08-21
#[Out]# 20353  165  2018-08-24  2018-08-21
#[Out]# 20354  172  2018-08-24  2018-08-21
#[Out]# 20355  179  2018-08-24  2018-08-21
#[Out]# 20356  179  2018-08-24  2018-08-21
#[Out]# 20357  179  2018-08-24  2018-08-21
#[Out]# 20358  181  2018-08-24  2018-08-21
#[Out]# 20359  181  2018-08-24  2018-08-21
#[Out]# 
#[Out]# [20360 rows x 3 columns]
# Wed, 02 Dec 2020 09:28:10
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.date like '2018-08-%';
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cID        date        date
#[Out]# 0         1  2018-08-20  2018-08-22
#[Out]# 1         1  2018-08-20  2018-08-22
#[Out]# 2         1  2018-08-20  2018-08-22
#[Out]# 3         1  2018-08-20  2018-08-22
#[Out]# 4         1  2018-08-20  2018-08-22
#[Out]# 5         1  2018-08-20  2018-08-22
#[Out]# 6         1  2018-08-20  2018-08-22
#[Out]# 7         1  2018-08-21  2018-08-22
#[Out]# 8         2  2018-08-17  2018-08-22
#[Out]# 9         2  2018-08-16  2018-08-22
#[Out]# 10        2  2018-08-17  2018-08-22
#[Out]# 11        2  2018-08-16  2018-08-22
#[Out]# 12        2  2018-08-17  2018-08-22
#[Out]# 13        3  2018-08-19  2018-08-22
#[Out]# 14        3  2018-08-18  2018-08-22
#[Out]# 15        3  2018-08-18  2018-08-22
#[Out]# 16        5  2018-08-22  2018-08-22
#[Out]# 17        5  2018-08-17  2018-08-22
#[Out]# 18        5  2018-08-23  2018-08-22
#[Out]# 19        5  2018-08-23  2018-08-22
#[Out]# 20        5  2018-08-23  2018-08-22
#[Out]# 21        5  2018-08-22  2018-08-22
#[Out]# 22        7  2018-08-23  2018-08-22
#[Out]# 23        7  2018-08-25  2018-08-22
#[Out]# 24        7  2018-08-24  2018-08-22
#[Out]# 25        7  2018-08-23  2018-08-22
#[Out]# 26        7  2018-08-23  2018-08-22
#[Out]# 27        7  2018-08-26  2018-08-22
#[Out]# 28        8  2018-08-16  2018-08-22
#[Out]# 29        8  2018-08-16  2018-08-22
#[Out]# ...     ...         ...         ...
#[Out]# 250398  176  2018-08-25  2018-08-21
#[Out]# 250399  176  2018-08-22  2018-08-21
#[Out]# 250400  176  2018-08-26  2018-08-21
#[Out]# 250401  176  2018-08-25  2018-08-21
#[Out]# 250402  176  2018-08-25  2018-08-21
#[Out]# 250403  176  2018-08-25  2018-08-21
#[Out]# 250404  176  2018-08-25  2018-08-21
#[Out]# 250405  176  2018-08-25  2018-08-21
#[Out]# 250406  178  2018-08-27  2018-08-21
#[Out]# 250407  178  2018-08-27  2018-08-21
#[Out]# 250408  179  2018-08-22  2018-08-21
#[Out]# 250409  179  2018-08-24  2018-08-21
#[Out]# 250410  179  2018-08-24  2018-08-21
#[Out]# 250411  179  2018-08-22  2018-08-21
#[Out]# 250412  179  2018-08-24  2018-08-21
#[Out]# 250413  179  2018-08-22  2018-08-21
#[Out]# 250414  180  2018-08-27  2018-08-21
#[Out]# 250415  180  2018-08-26  2018-08-21
#[Out]# 250416  180  2018-08-26  2018-08-21
#[Out]# 250417  181  2018-08-27  2018-08-21
#[Out]# 250418  181  2018-08-24  2018-08-21
#[Out]# 250419  181  2018-08-27  2018-08-21
#[Out]# 250420  181  2018-08-24  2018-08-21
#[Out]# 250421  183  2018-08-19  2018-08-21
#[Out]# 250422  183  2018-08-22  2018-08-21
#[Out]# 250423  183  2018-08-20  2018-08-21
#[Out]# 250424  183  2018-08-21  2018-08-21
#[Out]# 250425  183  2018-08-22  2018-08-21
#[Out]# 250426  183  2018-08-21  2018-08-21
#[Out]# 250427  183  2018-08-22  2018-08-21
#[Out]# 
#[Out]# [250428 rows x 3 columns]
# Wed, 02 Dec 2020 09:28:27
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.date like '2018-%-%';
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cID        date        date
#[Out]# 0         1  2018-08-20  2018-08-22
#[Out]# 1         1  2018-08-20  2018-08-22
#[Out]# 2         1  2018-08-20  2018-08-22
#[Out]# 3         1  2018-08-20  2018-08-22
#[Out]# 4         1  2018-08-20  2018-08-22
#[Out]# 5         1  2018-08-20  2018-08-22
#[Out]# 6         1  2018-08-20  2018-08-22
#[Out]# 7         1  2018-08-21  2018-08-22
#[Out]# 8         2  2018-08-17  2018-08-22
#[Out]# 9         2  2018-08-16  2018-08-22
#[Out]# 10        2  2018-08-17  2018-08-22
#[Out]# 11        2  2018-08-16  2018-08-22
#[Out]# 12        2  2018-08-17  2018-08-22
#[Out]# 13        3  2018-08-19  2018-08-22
#[Out]# 14        3  2018-08-18  2018-08-22
#[Out]# 15        3  2018-08-18  2018-08-22
#[Out]# 16        5  2018-08-22  2018-08-22
#[Out]# 17        5  2018-08-17  2018-08-22
#[Out]# 18        5  2018-08-23  2018-08-22
#[Out]# 19        5  2018-08-23  2018-08-22
#[Out]# 20        5  2018-08-23  2018-08-22
#[Out]# 21        5  2018-08-22  2018-08-22
#[Out]# 22        7  2018-08-23  2018-08-22
#[Out]# 23        7  2018-08-25  2018-08-22
#[Out]# 24        7  2018-08-24  2018-08-22
#[Out]# 25        7  2018-08-23  2018-08-22
#[Out]# 26        7  2018-08-23  2018-08-22
#[Out]# 27        7  2018-08-26  2018-08-22
#[Out]# 28        8  2018-08-16  2018-08-22
#[Out]# 29        8  2018-08-16  2018-08-22
#[Out]# ...     ...         ...         ...
#[Out]# 250398  176  2018-08-25  2018-08-21
#[Out]# 250399  176  2018-08-22  2018-08-21
#[Out]# 250400  176  2018-08-26  2018-08-21
#[Out]# 250401  176  2018-08-25  2018-08-21
#[Out]# 250402  176  2018-08-25  2018-08-21
#[Out]# 250403  176  2018-08-25  2018-08-21
#[Out]# 250404  176  2018-08-25  2018-08-21
#[Out]# 250405  176  2018-08-25  2018-08-21
#[Out]# 250406  178  2018-08-27  2018-08-21
#[Out]# 250407  178  2018-08-27  2018-08-21
#[Out]# 250408  179  2018-08-22  2018-08-21
#[Out]# 250409  179  2018-08-24  2018-08-21
#[Out]# 250410  179  2018-08-24  2018-08-21
#[Out]# 250411  179  2018-08-22  2018-08-21
#[Out]# 250412  179  2018-08-24  2018-08-21
#[Out]# 250413  179  2018-08-22  2018-08-21
#[Out]# 250414  180  2018-08-27  2018-08-21
#[Out]# 250415  180  2018-08-26  2018-08-21
#[Out]# 250416  180  2018-08-26  2018-08-21
#[Out]# 250417  181  2018-08-27  2018-08-21
#[Out]# 250418  181  2018-08-24  2018-08-21
#[Out]# 250419  181  2018-08-27  2018-08-21
#[Out]# 250420  181  2018-08-24  2018-08-21
#[Out]# 250421  183  2018-08-19  2018-08-21
#[Out]# 250422  183  2018-08-22  2018-08-21
#[Out]# 250423  183  2018-08-20  2018-08-21
#[Out]# 250424  183  2018-08-21  2018-08-21
#[Out]# 250425  183  2018-08-22  2018-08-21
#[Out]# 250426  183  2018-08-21  2018-08-21
#[Out]# 250427  183  2018-08-22  2018-08-21
#[Out]# 
#[Out]# [250428 rows x 3 columns]
# Wed, 02 Dec 2020 09:29:01
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.date like '2018-%-%' and
              l.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID        date        date
#[Out]# 0        1  2018-08-20  2018-08-20
#[Out]# 1        1  2018-08-20  2018-08-20
#[Out]# 2        1  2018-08-20  2018-08-20
#[Out]# 3        1  2018-08-20  2018-08-20
#[Out]# 4        1  2018-08-20  2018-08-20
#[Out]# 5        1  2018-08-20  2018-08-20
#[Out]# 6        1  2018-08-20  2018-08-20
#[Out]# 7        1  2018-08-20  2018-08-20
#[Out]# 8        1  2018-08-20  2018-08-20
#[Out]# 9        1  2018-08-20  2018-08-20
#[Out]# 10       1  2018-08-20  2018-08-20
#[Out]# 11       1  2018-08-20  2018-08-20
#[Out]# 12       1  2018-08-20  2018-08-20
#[Out]# 13       1  2018-08-20  2018-08-20
#[Out]# 14       1  2018-08-20  2018-08-20
#[Out]# 15       1  2018-08-20  2018-08-20
#[Out]# 16       1  2018-08-20  2018-08-20
#[Out]# 17       1  2018-08-20  2018-08-20
#[Out]# 18       1  2018-08-20  2018-08-20
#[Out]# 19       1  2018-08-20  2018-08-20
#[Out]# 20       1  2018-08-20  2018-08-20
#[Out]# 21       1  2018-08-20  2018-08-20
#[Out]# 22       1  2018-08-20  2018-08-20
#[Out]# 23       1  2018-08-20  2018-08-20
#[Out]# 24       1  2018-08-20  2018-08-20
#[Out]# 25       1  2018-08-20  2018-08-20
#[Out]# 26       1  2018-08-20  2018-08-20
#[Out]# 27       1  2018-08-20  2018-08-20
#[Out]# 28       1  2018-08-20  2018-08-20
#[Out]# 29       1  2018-08-20  2018-08-20
#[Out]# ...    ...         ...         ...
#[Out]# 19402  183  2018-08-22  2018-08-22
#[Out]# 19403  183  2018-08-22  2018-08-22
#[Out]# 19404  183  2018-08-22  2018-08-22
#[Out]# 19405  183  2018-08-22  2018-08-22
#[Out]# 19406  183  2018-08-22  2018-08-22
#[Out]# 19407  183  2018-08-22  2018-08-22
#[Out]# 19408  183  2018-08-22  2018-08-22
#[Out]# 19409  183  2018-08-22  2018-08-22
#[Out]# 19410  183  2018-08-22  2018-08-22
#[Out]# 19411  183  2018-08-22  2018-08-22
#[Out]# 19412  183  2018-08-22  2018-08-22
#[Out]# 19413  183  2018-08-22  2018-08-22
#[Out]# 19414  183  2018-08-22  2018-08-22
#[Out]# 19415  183  2018-08-22  2018-08-22
#[Out]# 19416  183  2018-08-22  2018-08-22
#[Out]# 19417  183  2018-08-22  2018-08-22
#[Out]# 19418  183  2018-08-22  2018-08-22
#[Out]# 19419  183  2018-08-22  2018-08-22
#[Out]# 19420  183  2018-08-22  2018-08-22
#[Out]# 19421  183  2018-08-22  2018-08-22
#[Out]# 19422  183  2018-08-22  2018-08-22
#[Out]# 19423  183  2018-08-22  2018-08-22
#[Out]# 19424  183  2018-08-22  2018-08-22
#[Out]# 19425  183  2018-08-22  2018-08-22
#[Out]# 19426  183  2018-08-22  2018-08-22
#[Out]# 19427  183  2018-08-22  2018-08-22
#[Out]# 19428  183  2018-08-22  2018-08-22
#[Out]# 19429  183  2018-08-22  2018-08-22
#[Out]# 19430  183  2018-08-22  2018-08-22
#[Out]# 19431  183  2018-08-22  2018-08-22
#[Out]# 
#[Out]# [19432 rows x 3 columns]
# Wed, 02 Dec 2020 09:29:19
query3_2 = '''
     select l.cID,l.date, p.date
     from shoppinglist l, purchase p
        where l.date like '2018-%-%' and
              l.date = p.date and
              l.cID = p.cID;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID        date        date
#[Out]# 0      1  2018-08-20  2018-08-20
#[Out]# 1      1  2018-08-20  2018-08-20
#[Out]# 2      1  2018-08-20  2018-08-20
#[Out]# 3      1  2018-08-20  2018-08-20
#[Out]# 4      1  2018-08-20  2018-08-20
#[Out]# 5      1  2018-08-20  2018-08-20
#[Out]# 6      1  2018-08-20  2018-08-20
#[Out]# 7      1  2018-08-20  2018-08-20
#[Out]# 8      1  2018-08-20  2018-08-20
#[Out]# 9      1  2018-08-20  2018-08-20
#[Out]# 10     1  2018-08-20  2018-08-20
#[Out]# 11     1  2018-08-20  2018-08-20
#[Out]# 12     1  2018-08-20  2018-08-20
#[Out]# 13     1  2018-08-20  2018-08-20
#[Out]# 14     1  2018-08-20  2018-08-20
#[Out]# 15     1  2018-08-20  2018-08-20
#[Out]# 16     1  2018-08-20  2018-08-20
#[Out]# 17     1  2018-08-20  2018-08-20
#[Out]# 18     1  2018-08-20  2018-08-20
#[Out]# 19     1  2018-08-20  2018-08-20
#[Out]# 20     1  2018-08-20  2018-08-20
#[Out]# 21     1  2018-08-20  2018-08-20
#[Out]# 22     1  2018-08-20  2018-08-20
#[Out]# 23     1  2018-08-20  2018-08-20
#[Out]# 24     1  2018-08-20  2018-08-20
#[Out]# 25     1  2018-08-20  2018-08-20
#[Out]# 26     1  2018-08-20  2018-08-20
#[Out]# 27     1  2018-08-20  2018-08-20
#[Out]# 28     1  2018-08-20  2018-08-20
#[Out]# 29     1  2018-08-20  2018-08-20
#[Out]# ..   ...         ...         ...
#[Out]# 946  176  2018-08-26  2018-08-26
#[Out]# 947  178  2018-08-27  2018-08-27
#[Out]# 948  178  2018-08-27  2018-08-27
#[Out]# 949  178  2018-08-27  2018-08-27
#[Out]# 950  178  2018-08-27  2018-08-27
#[Out]# 951  179  2018-08-24  2018-08-24
#[Out]# 952  179  2018-08-24  2018-08-24
#[Out]# 953  179  2018-08-24  2018-08-24
#[Out]# 954  179  2018-08-24  2018-08-24
#[Out]# 955  179  2018-08-24  2018-08-24
#[Out]# 956  179  2018-08-24  2018-08-24
#[Out]# 957  179  2018-08-24  2018-08-24
#[Out]# 958  179  2018-08-24  2018-08-24
#[Out]# 959  179  2018-08-24  2018-08-24
#[Out]# 960  179  2018-08-22  2018-08-22
#[Out]# 961  179  2018-08-22  2018-08-22
#[Out]# 962  179  2018-08-22  2018-08-22
#[Out]# 963  179  2018-08-22  2018-08-22
#[Out]# 964  179  2018-08-22  2018-08-22
#[Out]# 965  179  2018-08-22  2018-08-22
#[Out]# 966  180  2018-08-26  2018-08-26
#[Out]# 967  180  2018-08-26  2018-08-26
#[Out]# 968  180  2018-08-27  2018-08-27
#[Out]# 969  180  2018-08-27  2018-08-27
#[Out]# 970  181  2018-08-24  2018-08-24
#[Out]# 971  181  2018-08-24  2018-08-24
#[Out]# 972  181  2018-08-24  2018-08-24
#[Out]# 973  181  2018-08-24  2018-08-24
#[Out]# 974  181  2018-08-27  2018-08-27
#[Out]# 975  181  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [976 rows x 3 columns]
# Wed, 02 Dec 2020 09:29:56
query3_2 = '''
    select cID, cName
    from customer
    where cID in (
         select l.cID,l.date, p.date
         from shoppinglist l, purchase p
            where l.date like '2018-%-%' and
                  l.date = p.date and
                  l.cID = p.cID);
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 09:30:47
query3_2 = '''
    select cID, cName
    from customer
    where cID in (
         select l.cID
         from shoppinglist l, purchase p
            where l.date like '2018-%-%' and
                  l.date = p.date and
                  l.cID = p.cID
    );
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Wed, 02 Dec 2020 09:53:02
print(json.dumps(yapf_reformat(u"query3_2 = '''\n    select cID, cName\n    from customer\n    where cID in (\n         select l.cID\n         from shoppinglist l, purchase p\n            where l.date like '2018-%-%' and\n                  l.date = p.date and\n                  l.cID = p.cID\n    );\n'''\n\npd.read_sql_query(query3_2, conn)")))
# Wed, 02 Dec 2020 09:53:03
print(json.dumps(yapf_reformat(u"query3_2 = '''\n    select cID, cName\n    from customer\n    where cID in (\n         select l.cID\n         from shoppinglist l, purchase p\n            where l.date like '2018-%-%' and\n                  l.date = p.date and\n                  l.cID = p.cID\n    );\n'''\n\npd.read_sql_query(query3_2, conn)")))
# Wed, 02 Dec 2020 09:53:03
print(json.dumps(yapf_reformat(u"query3_2 = '''\n    select cID, cName\n    from customer\n    where cID in (\n         select l.cID\n         from shoppinglist l, purchase p\n            where l.date like '2018-%-%' and\n                  l.date = p.date and\n                  l.cID = p.cID\n    );\n'''\n\npd.read_sql_query(query3_2, conn)")))
# Wed, 02 Dec 2020 10:00:17
query3_3 = '''
    select sID
    from purchase
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      sID
#[Out]# 0      3
#[Out]# 1     23
#[Out]# 2      3
#[Out]# 3     17
#[Out]# 4     32
#[Out]# 5     16
#[Out]# 6     46
#[Out]# 7     36
#[Out]# 8     12
#[Out]# 9     39
#[Out]# 10    13
#[Out]# 11    51
#[Out]# 12    47
#[Out]# 13    44
#[Out]# 14    30
#[Out]# 15    29
#[Out]# 16    17
#[Out]# 17    10
#[Out]# 18    53
#[Out]# 19    21
#[Out]# 20     7
#[Out]# 21    44
#[Out]# 22     4
#[Out]# 23    36
#[Out]# 24    55
#[Out]# 25    51
#[Out]# 26     6
#[Out]# 27    17
#[Out]# 28     3
#[Out]# 29    12
#[Out]# ..   ...
#[Out]# 479   34
#[Out]# 480   35
#[Out]# 481   36
#[Out]# 482   37
#[Out]# 483   38
#[Out]# 484   39
#[Out]# 485   40
#[Out]# 486   41
#[Out]# 487   42
#[Out]# 488   43
#[Out]# 489   44
#[Out]# 490   45
#[Out]# 491   46
#[Out]# 492   47
#[Out]# 493   48
#[Out]# 494   49
#[Out]# 495   50
#[Out]# 496   51
#[Out]# 497   52
#[Out]# 498   53
#[Out]# 499   54
#[Out]# 500   55
#[Out]# 501   56
#[Out]# 502   57
#[Out]# 503   58
#[Out]# 504   59
#[Out]# 505   60
#[Out]# 506   61
#[Out]# 507   62
#[Out]# 508   63
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Wed, 02 Dec 2020 10:01:05
query3_3 = '''
    select s.sID, s.sName
    from store s;
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# 5     5       Sligro
#[Out]# 6     6         Coop
#[Out]# 7     7       Sligro
#[Out]# 8     8  Albert Hein
#[Out]# 9     9  Albert Hein
#[Out]# 10   10        Jumbo
#[Out]# 11   11  Albert Hein
#[Out]# 12   12         Lidl
#[Out]# 13   13         Coop
#[Out]# 14   14         Coop
#[Out]# 15   15         Lidl
#[Out]# 16   16         Lidl
#[Out]# 17   17    Hoogvliet
#[Out]# 18   18       Sligro
#[Out]# 19   19         Coop
#[Out]# 20   20        Jumbo
#[Out]# 21   21         Coop
#[Out]# 22   22         Lidl
#[Out]# 23   23         Dirk
#[Out]# 24   24  Albert Hein
#[Out]# 25   25  Albert Hein
#[Out]# 26   26    Hoogvliet
#[Out]# 27   27       Sligro
#[Out]# 28   28    Hoogvliet
#[Out]# 29   29       Sligro
#[Out]# ..  ...          ...
#[Out]# 34   34         Coop
#[Out]# 35   35         Lidl
#[Out]# 36   36         Lidl
#[Out]# 37   37        Jumbo
#[Out]# 38   38    Hoogvliet
#[Out]# 39   39       Sligro
#[Out]# 40   40    Hoogvliet
#[Out]# 41   41  Albert Hein
#[Out]# 42   42       Sligro
#[Out]# 43   43         Coop
#[Out]# 44   44  Albert Hein
#[Out]# 45   45         Coop
#[Out]# 46   46         Lidl
#[Out]# 47   47         Coop
#[Out]# 48   48    Hoogvliet
#[Out]# 49   49    Hoogvliet
#[Out]# 50   50       Sligro
#[Out]# 51   51         Coop
#[Out]# 52   52         Lidl
#[Out]# 53   53         Coop
#[Out]# 54   54         Dirk
#[Out]# 55   55         Coop
#[Out]# 56   56        Jumbo
#[Out]# 57   57         Dirk
#[Out]# 58   58         Dirk
#[Out]# 59   59        Jumbo
#[Out]# 60   60         Lidl
#[Out]# 61   61         Lidl
#[Out]# 62   62        Jumbo
#[Out]# 63   63        Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 02 Dec 2020 10:01:24
query3_3 = '''
    select *
    from store s;
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     0         Coop      Kalverstraat  Amsterdam
#[Out]# 1     1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 5     5       Sligro     Stationsplein      Breda
#[Out]# 6     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 7     7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 8     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 9     9  Albert Hein         Koestraat    Tilburg
#[Out]# 10   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 11   11  Albert Hein          Hofplein  Rotterdam
#[Out]# 12   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 13   13         Coop         Koestraat    Tilburg
#[Out]# 14   14         Coop     Keizersgracht  Amsterdam
#[Out]# 15   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 16   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 17   17    Hoogvliet        Kerkstraat  Eindhoven
#[Out]# 18   18       Sligro       Parallelweg    Tilburg
#[Out]# 19   19         Coop       Karrestraat      Breda
#[Out]# 20   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 21   21         Coop      Kasteeldreef    Tilburg
#[Out]# 22   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 23   23         Dirk     Stationsplein      Breda
#[Out]# 24   24  Albert Hein     Stationsplein      Breda
#[Out]# 25   25  Albert Hein     Stationsplein      Breda
#[Out]# 26   26    Hoogvliet   Sint Annastraat      Breda
#[Out]# 27   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 28   28    Hoogvliet         Koestraat    Tilburg
#[Out]# 29   29       Sligro      Marnixstraat  Amsterdam
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   34         Coop          Bierkaai  Amsterdam
#[Out]# 35   35         Lidl     Julianastraat    Utrecht
#[Out]# 36   36         Lidl     Julianastraat  Eindhoven
#[Out]# 37   37        Jumbo          Molenweg  Eindhoven
#[Out]# 38   38    Hoogvliet          Hofplein  Rotterdam
#[Out]# 39   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 40   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 41   41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 42   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 43   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 44   44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 45   45         Coop      Kasteeldreef    Tilburg
#[Out]# 46   46         Lidl        Bergselaan  Rotterdam
#[Out]# 47   47         Coop     Julianastraat  Rotterdam
#[Out]# 48   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 49   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 50   50       Sligro     Stationsplein      Breda
#[Out]# 51   51         Coop       Parallelweg    Utrecht
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   53         Coop        Hoogstraat    Utrecht
#[Out]# 54   54         Dirk     Julianastraat  Eindhoven
#[Out]# 55   55         Coop   Sint Annastraat      Breda
#[Out]# 56   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 57   57         Dirk       Molenstraat  Eindhoven
#[Out]# 58   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 59   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60         Lidl      Pannekoekweg      Breda
#[Out]# 61   61         Lidl      Pannekoekweg      Breda
#[Out]# 62   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63        Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Wed, 02 Dec 2020 10:03:59
query3_3 = '''
    select cID,cName
    from customer
    where cID not in (
        select cID
        from purchase);
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Wed, 02 Dec 2020 10:13:23
query3_3 = '''
    select cID,cName
    from customer
    where cID not in (
        select cID
        from purchase p, store s
        where p.sID = s.sID and
              s.sName = 'Coop');
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Wed, 02 Dec 2020 10:18:14
query3_4 = '''
    select cID,cName
    frome customer
    where cID in()
        select cID
        from purchase p, store s
        where p.sID = s.sID and
              s.sName = 'Kumar'
              and cid not in (
              
      select cid
      from purchase p, store s
      where p.sid = s.sid
      and s.sname!='kumar')
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 10:18:53
query3_4 = '''
    select cID,cName
    frome customer
    where cID in (
        select cID
        from purchase p, store s
        where p.sID = s.sID and
              s.sName = 'Kumar'
              and cid not in (
                  select cid
      from purchase p, store s
      where p.sid = s.sid
      and s.sname!='kumar')                  
    );              
      
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 10:19:49
query3_4 = '''
    select cID,cName
    frome customer
    where cID in (
        select cID
        from purchase p, store s
        where p.sID = s.sID and
              s.sName = 'Kumar'
              and cID not in (
                  select cID
      from purchase p, store s
      where p.sID = s.sID
      and s.sName!='kumar')                  
    );              
      
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 10:20:16
query3_4 = '''
    select cID,cName
    frome customer
    where cID in (
        select cID
        from purchase p, store s
        where p.sID = s.sID and
              s.sName = 'Kumar'
                              
    );              
      
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 10:20:27
query3_4 = '''
    select cID,cName
    frome customer
    ;              
      
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 10:20:46
query3_4 = '''
    select cID,cName
    from customer
    where cID in (
        select cID
        from purchase p, store s
        where p.sID = s.sID and
              s.sName = 'Kumar'
              and cID not in (
                  select cID
      from purchase p, store s
      where p.sID = s.sID
      and s.sName!='kumar')                  
    );              
      
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 10:22:02
query3_4 = '''
    select cID,cName
    from customer
    where cID in (
        select cID
        from purchase p, store s
        where p.sID = s.sID and
              s.sName = 'Coop'
              and cID not in (
                  select cID
      from purchase p, store s
      where p.sID = s.sID
      and s.sName!='Coop')                  
    );            
      
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID      cName
#[Out]# 0     8       Liam
#[Out]# 1    10        Sam
#[Out]# 2    11      Thijs
#[Out]# 3    26     Jayden
#[Out]# 4    28       Siem
#[Out]# 5    55      Aiden
#[Out]# 6    76  Alexander
#[Out]# 7    88      Joris
#[Out]# 8    99       Anna
#[Out]# 9   103      Lotte
#[Out]# 10  131        Amy
#[Out]# 11  135      Sofia
#[Out]# 12  151       Jill
#[Out]# 13  184      Wilko
# Wed, 02 Dec 2020 10:26:31
print(json.dumps(yapf_reformat(u"query3_3 = '''\n    select cID,cName\n    from customer\n    where cID not in (\n        select cID\n        from purchase p, store s\n        where p.sID = s.sID and\n              s.sName = 'Kumar');\n'''\n\npd.read_sql_query(query3_3, conn)")))
# Wed, 02 Dec 2020 10:26:32
print(json.dumps(yapf_reformat(u"query3_3 = '''\n    select cID,cName\n    from customer\n    where cID not in (\n        select cID\n        from purchase p, store s\n        where p.sID = s.sID and\n              s.sName = 'Kumar');\n'''\n\npd.read_sql_query(query3_3, conn)")))
# Wed, 02 Dec 2020 10:54:59
query3_3 = '''
    select cID,cName
    from customer
    where cID not in (
        select cID
        from purchase p, store s
        where p.sID = s.sID and
              s.sName = 'Coop');
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Wed, 02 Dec 2020 10:55:25
query3_4 = '''
    select cID,cName
    from customer
    where cID in (
        select cID
        from purchase p, store s
        where p.sID = s.sID and
              s.sName = 'Coop'
              and cID not in (
                  select cID
      from purchase p, store s
      where p.sID = s.sID
      and s.sName!='Coop')                  
    );            
      
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID      cName
#[Out]# 0     8       Liam
#[Out]# 1    10        Sam
#[Out]# 2    11      Thijs
#[Out]# 3    26     Jayden
#[Out]# 4    28       Siem
#[Out]# 5    55      Aiden
#[Out]# 6    76  Alexander
#[Out]# 7    88      Joris
#[Out]# 8    99       Anna
#[Out]# 9   103      Lotte
#[Out]# 10  131        Amy
#[Out]# 11  135      Sofia
#[Out]# 12  151       Jill
#[Out]# 13  184      Wilko


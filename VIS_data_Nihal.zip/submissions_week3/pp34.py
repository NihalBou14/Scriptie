# IPython log file

# Tue, 01 Dec 2020 20:40:49
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 20:40:50
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x248cef98110>
# Tue, 01 Dec 2020 20:40:55
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 20:43:09
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x00000248CEF98110>
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 20:43:10
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 20:43:11
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 01 Dec 2020 20:43:13
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 20:43:39
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x00000248CEF98110>
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)

# IPython log file


# IPython log file

# Tue, 01 Dec 2020 20:48:14
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 20:48:16
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 01 Dec 2020 20:48:17
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 21:01:08
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)

# IPython log file

# Tue, 01 Dec 2020 21:01:52
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

# Wed, 02 Dec 2020 11:03:13
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 11:03:14
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 11:03:14
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Wed, 02 Dec 2020 11:04:02
query3_2 = '''
SELECT DISTINCT customer.cID, customer.cNAME
FROM customer, shoppinglist, purchase
WHERE customer.cID = shoppinglist.cID AND customer.cID = purchase.cID AND shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date and (purchase.date like '%2018%')'''
# Wed, 02 Dec 2020 11:04:02
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:04:03
pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Wed, 02 Dec 2020 11:05:53
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN
SELECT DISTINCT customer.cID, customer.cName
FROM customer, purchase, store
WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = 'Jumbo''''
# Wed, 02 Dec 2020 11:05:53
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:06:09
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN
SELECT DISTINCT customer.cID, customer.cName
FROM customer, purchase, store
WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = 'Jumbo'
'''
# Wed, 02 Dec 2020 11:06:11
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:06:11
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 11:07:29
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN:
SELECT DISTINCT customer.cID, customer.cName
FROM customer, purchase, store
WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = 'Jumbo': '''
# Wed, 02 Dec 2020 11:07:29
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:07:29
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 11:07:50
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN
SELECT DISTINCT customer.cID, customer.cName
FROM customer, purchase, store
WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = 'Jumbo' '''
# Wed, 02 Dec 2020 11:07:50
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:07:50
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 11:09:11
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN
(SELECT DISTINCT customer.cID, customer.cName
FROM customer, purchase, store
WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = 'Jumbo') 
'''
# Wed, 02 Dec 2020 11:09:12
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:09:12
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 11:09:32
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID, cName NOT IN
(SELECT DISTINCT customer.cID, customer.cName
FROM customer, purchase, store
WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = 'Jumbo') 
'''
# Wed, 02 Dec 2020 11:09:33
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:09:33
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 11:09:46
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID cName NOT IN
(SELECT DISTINCT customer.cID, customer.cName
FROM customer, purchase, store
WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = 'Jumbo') 
'''
# Wed, 02 Dec 2020 11:09:47
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:09:47
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 11:09:59
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN
(SELECT DISTINCT customer.cID, customer.cName
FROM customer, purchase, store
WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = 'Jumbo') 
'''
# Wed, 02 Dec 2020 11:09:59
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:10:00
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 11:10:31
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN
(SELECT DISTINCT customer.cID
FROM customer, purchase, store
WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = 'Jumbo') 
'''
# Wed, 02 Dec 2020 11:10:31
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:10:32
pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Wed, 02 Dec 2020 11:12:54
query3_4 = '''
SELECT DISTINCT c1.cID, c1.cName
FROM customer AS c1, purchase AS p1, store AS s1 
WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Jumbo' AND  c1.cID NOT IN
(SELECT DISTINCT c1.cID
FROM customer AS c1, purchase AS p1, store AS s1 
WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName != 'Jumbo')
'''
# Wed, 02 Dec 2020 11:12:54
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 11:12:54
pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen


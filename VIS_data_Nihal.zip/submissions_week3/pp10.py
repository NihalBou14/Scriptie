# IPython log file

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Tue, 01 Dec 2020 09:30:14
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 09:30:22
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x19cd66b10a0>
# Tue, 01 Dec 2020 11:38:08
query3_2 = SELECT DISTINCT cName, cID FROM customer, shoppinglist as s, purchase as p WHERE s.date = p.date AND p.date = '%2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:38:19
query3_2 = SELECT DISTINCT cName, cID FROM customer, shoppinglist as s, purchase as p WHERE s.date == p.date AND p.date = '%2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:38:24
query3_2 = SELECT DISTINCT cName, cID FROM customer, shoppinglist as s, purchase as p WHERE s.date == p.date AND p.date == '%2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:40:01
query3_2 = SELECT DISTINCT cName, cID FROM customer, shoppinglist, purchase WHERE shoppinglist.date = purchase.date AND purchase.date = '%2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:40:53
query3_2 = SELECT DISTINCT cName, cID 
FROM customer, shoppinglist, purchase 
WHERE shoppinglist.date = purchase.date AND purchase.date = '%2018'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:41:31
query3_2 = '''SELECT DISTINCT cName, cID 
FROM customer, shoppinglist, purchase 
WHERE shoppinglist.date = purchase.date AND purchase.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:43:20
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist as s, purchase as p
WHERE s.date = p.date AND p.date = '%2018' AND p.cID = c.cID AND p.cID = s.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:44:14
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist as s, purchase as p
WHERE s.date = p.date AND p.date = '%2018' AND p.cID = c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:44:18
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist as s, purchase as p
WHERE s.date = p.date AND p.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:44:29
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist as s, purchase as p

'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 11:45:05
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist as s, purchase as p
WHERE p.cID = c.cID AND p.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:45:34
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist as s, purchase as p
WHERE c.cID = p.cID AND p.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:48:06
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist JOIN purchase as j
WHERE c.cID = j.cID AND j.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:49:53
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist JOIN purchase as j
WHERE c.cID = j.cID AND j.date = '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:50:23
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist as s, purchase as p
WHERE p.cID = c.cID AND p.date = '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:50:39
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist as s, purchase as p
WHERE p.cID = c.cID AND p.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 11:51:03
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist as s, purchase as p
WHERE s.date = p.date AND p.date LIKE '%2018' AND p.cID = c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:51:38
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist JOIN purchase
WHERE p.cID = c.cID AND p.date LIKE '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:51:51
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist JOIN purchase
WHERE p.cID = c.cID AND p.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:52:02
query3_2 = '''SELECT DISTINCT c.cName, c.cID 
FROM customer as c, shoppinglist JOIN purchase as j
WHERE j.cID = c.cID AND j.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 11:57:17
query3_2 = '''SELECT DISTINCT c.cName, c.cID
FROM customer as c, shoppinglist as s
WHERE c.cID = s.cID AND s.date LIKE '%2018%'
UNION
SELECT DISTINCT c.cName, c.cID
FROM customer as c, purchase as p
WHERE c.cID = p.cID AND p.date LIKE '%2018%'

'''
#SELECT DISTINCT c.cName, c.cID 
#FROM customer as c, shoppinglist JOIN purchase as j
#WHERE j.cID = c.cID AND j.date LIKE '%2018%'

pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1        Aiden   55
#[Out]# 2    Alexander   76
#[Out]# 3        Amira  176
#[Out]# 4          Amy  131
#[Out]# 5       Angela  186
#[Out]# 6         Anna   99
#[Out]# 7         Anne  152
#[Out]# 8     Benjamin   21
#[Out]# 9       Benthe  154
#[Out]# 10        Boaz   36
#[Out]# 11       Boris   68
#[Out]# 12        Bram    7
#[Out]# 13      Casper   84
#[Out]# 14        Cato  163
#[Out]# 15        Daan    4
#[Out]# 16        Dani   72
#[Out]# 17       David   34
#[Out]# 18        Dean   71
#[Out]# 19         Dex   17
#[Out]# 20       Dylan   82
#[Out]# 21       Elena  162
#[Out]# 22        Elif  178
#[Out]# 23        Elin  122
#[Out]# 24       Eline  177
#[Out]# 25       Elise  139
#[Out]# 26        Ella  134
#[Out]# 27       Emily  127
#[Out]# 28        Emma   95
#[Out]# 29       Esmee  129
#[Out]# ..         ...  ...
#[Out]# 123       Saar  110
#[Out]# 124        Sam   10
#[Out]# 125        Sam  175
#[Out]# 126     Samuel   74
#[Out]# 127       Sara  100
#[Out]# 128        Sem    1
#[Out]# 129       Senn   63
#[Out]# 130       Siem   28
#[Out]# 131      Sofia  135
#[Out]# 132      Sofie  124
#[Out]# 133     Sophia  133
#[Out]# 134     Sophie   97
#[Out]# 135       Stan   64
#[Out]# 136       Stef   86
#[Out]# 137      Stijn   35
#[Out]# 138       Sven   33
#[Out]# 139       Tess   96
#[Out]# 140      Tessa  171
#[Out]# 141       Teun   30
#[Out]# 142    Thijmen   91
#[Out]# 143      Thijs   11
#[Out]# 144       Ties   51
#[Out]# 145       Tijn   42
#[Out]# 146        Tim   27
#[Out]# 147        Tom   43
#[Out]# 148     Veerle  167
#[Out]# 149      Wilko  184
#[Out]# 150     Willem   52
#[Out]# 151       Xavi   47
#[Out]# 152       Yara  112
#[Out]# 
#[Out]# [153 rows x 2 columns]
# Tue, 01 Dec 2020 11:57:48
query3_2 = '''SELECT DISTINCT c.cName, c.cID
FROM customer as c, shoppinglist as s
WHERE c.cID = s.cID AND s.date LIKE '%2018%'
UNION DISTINCT
SELECT DISTINCT c.cName, c.cID
FROM customer as c, purchase as p
WHERE c.cID = p.cID AND p.date LIKE '%2018%'

'''
#SELECT DISTINCT c.cName, c.cID 
#FROM customer as c, shoppinglist JOIN purchase as j
#WHERE j.cID = c.cID AND j.date LIKE '%2018%'

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:57:56
query3_2 = '''SELECT DISTINCT c.cName, c.cID
FROM customer as c, shoppinglist as s
WHERE c.cID = s.cID AND s.date LIKE '%2018%'
UNION
SELECT DISTINCT c.cName, c.cID
FROM customer as c, purchase as p
WHERE c.cID = p.cID AND p.date LIKE '%2018%'

'''
#SELECT DISTINCT c.cName, c.cID 
#FROM customer as c, shoppinglist JOIN purchase as j
#WHERE j.cID = c.cID AND j.date LIKE '%2018%'

pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1        Aiden   55
#[Out]# 2    Alexander   76
#[Out]# 3        Amira  176
#[Out]# 4          Amy  131
#[Out]# 5       Angela  186
#[Out]# 6         Anna   99
#[Out]# 7         Anne  152
#[Out]# 8     Benjamin   21
#[Out]# 9       Benthe  154
#[Out]# 10        Boaz   36
#[Out]# 11       Boris   68
#[Out]# 12        Bram    7
#[Out]# 13      Casper   84
#[Out]# 14        Cato  163
#[Out]# 15        Daan    4
#[Out]# 16        Dani   72
#[Out]# 17       David   34
#[Out]# 18        Dean   71
#[Out]# 19         Dex   17
#[Out]# 20       Dylan   82
#[Out]# 21       Elena  162
#[Out]# 22        Elif  178
#[Out]# 23        Elin  122
#[Out]# 24       Eline  177
#[Out]# 25       Elise  139
#[Out]# 26        Ella  134
#[Out]# 27       Emily  127
#[Out]# 28        Emma   95
#[Out]# 29       Esmee  129
#[Out]# ..         ...  ...
#[Out]# 123       Saar  110
#[Out]# 124        Sam   10
#[Out]# 125        Sam  175
#[Out]# 126     Samuel   74
#[Out]# 127       Sara  100
#[Out]# 128        Sem    1
#[Out]# 129       Senn   63
#[Out]# 130       Siem   28
#[Out]# 131      Sofia  135
#[Out]# 132      Sofie  124
#[Out]# 133     Sophia  133
#[Out]# 134     Sophie   97
#[Out]# 135       Stan   64
#[Out]# 136       Stef   86
#[Out]# 137      Stijn   35
#[Out]# 138       Sven   33
#[Out]# 139       Tess   96
#[Out]# 140      Tessa  171
#[Out]# 141       Teun   30
#[Out]# 142    Thijmen   91
#[Out]# 143      Thijs   11
#[Out]# 144       Ties   51
#[Out]# 145       Tijn   42
#[Out]# 146        Tim   27
#[Out]# 147        Tom   43
#[Out]# 148     Veerle  167
#[Out]# 149      Wilko  184
#[Out]# 150     Willem   52
#[Out]# 151       Xavi   47
#[Out]# 152       Yara  112
#[Out]# 
#[Out]# [153 rows x 2 columns]
# Tue, 01 Dec 2020 12:00:13
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer, purchase
    WHERE sID = 'Coop' AND p.cID != c.cID
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 12:00:39
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE sID = 'Coop' AND p.cID != c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 12:01:29
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE sID = 'Lidl' AND p.cID != c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 12:01:40
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE p.sID = 'Lidl' AND p.cID != c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 12:02:10
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.sID = s.sID AND p.cID != c.cID AND s.sName = 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 12:05:20
query3_2 = '''SELECT DISTINCT c.cName, c.cID
FROM customer as c, shoppinglist as s
WHERE c.cID = s.cID AND s.date LIKE '%2018%'
INTERSECT
SELECT DISTINCT c.cName, c.cID
FROM customer as c, purchase as p
WHERE c.cID = p.cID AND p.date LIKE '%2018%'

'''
#SELECT DISTINCT c.cName, c.cID 
#FROM customer as c, shoppinglist JOIN purchase as j
#WHERE j.cID = c.cID AND j.date LIKE '%2018%'

pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# 5         Anne  152
#[Out]# 6     Benjamin   21
#[Out]# 7        Boris   68
#[Out]# 8         Bram    7
#[Out]# 9       Casper   84
#[Out]# 10        Cato  163
#[Out]# 11        Dani   72
#[Out]# 12       David   34
#[Out]# 13        Dean   71
#[Out]# 14         Dex   17
#[Out]# 15       Dylan   82
#[Out]# 16       Elena  162
#[Out]# 17        Elif  178
#[Out]# 18        Elin  122
#[Out]# 19        Ella  134
#[Out]# 20       Emily  127
#[Out]# 21        Emma   95
#[Out]# 22       Femke  136
#[Out]# 23       Fenna  113
#[Out]# 24       Fenne  159
#[Out]# 25        Fien  145
#[Out]# 26        Finn    3
#[Out]# 27       Floor  161
#[Out]# 28      Floris   38
#[Out]# 29        Gijs   20
#[Out]# ..         ...  ...
#[Out]# 82       Rayan   67
#[Out]# 83       Ruben   29
#[Out]# 84        Ryan   45
#[Out]# 85        Saar  110
#[Out]# 86         Sam   10
#[Out]# 87         Sam  175
#[Out]# 88        Sara  100
#[Out]# 89         Sem    1
#[Out]# 90        Senn   63
#[Out]# 91        Siem   28
#[Out]# 92       Sofie  124
#[Out]# 93      Sophia  133
#[Out]# 94      Sophie   97
#[Out]# 95        Stan   64
#[Out]# 96        Stef   86
#[Out]# 97       Stijn   35
#[Out]# 98        Sven   33
#[Out]# 99        Tess   96
#[Out]# 100      Tessa  171
#[Out]# 101       Teun   30
#[Out]# 102    Thijmen   91
#[Out]# 103      Thijs   11
#[Out]# 104       Ties   51
#[Out]# 105       Tijn   42
#[Out]# 106        Tim   27
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Tue, 01 Dec 2020 12:06:31
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, store as s, purchase as p
    WHERE s.sName = 'Coop' AND p.quantity>1 AND p.cID = c.cID AND p.sID = s.sID
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     2     Lucas
#[Out]# 1     4      Daan
#[Out]# 2     5      Levi
#[Out]# 3     8      Liam
#[Out]# 4    10       Sam
#[Out]# 5    11     Thijs
#[Out]# 6    16    Julian
#[Out]# 7    17       Dex
#[Out]# 8    18      Hugo
#[Out]# 9    20      Gijs
#[Out]# 10   21  Benjamin
#[Out]# 11   24      Luca
#[Out]# 12   26    Jayden
#[Out]# 13   27       Tim
#[Out]# 14   28      Siem
#[Out]# 15   29     Ruben
#[Out]# 16   33      Sven
#[Out]# 17   35     Stijn
#[Out]# 18   39      Jack
#[Out]# 19   42      Tijn
#[Out]# 20   51      Ties
#[Out]# 21   55     Aiden
#[Out]# 22   57    Nathan
#[Out]# 23   59      Joep
#[Out]# 24   67     Rayan
#[Out]# 25   71      Dean
#[Out]# 26   75      Jace
#[Out]# 27   78      Mick
#[Out]# 28   82     Dylan
#[Out]# 29   91   Thijmen
#[Out]# ..  ...       ...
#[Out]# 37  113     Fenna
#[Out]# 38  116     Lieke
#[Out]# 39  122      Elin
#[Out]# 40  123     Milou
#[Out]# 41  124     Sofie
#[Out]# 42  127     Emily
#[Out]# 43  129     Esmee
#[Out]# 44  131       Amy
#[Out]# 45  133    Sophia
#[Out]# 46  134      Ella
#[Out]# 47  135     Sofia
#[Out]# 48  139     Elise
#[Out]# 49  144       Ivy
#[Out]# 50  147    Isabel
#[Out]# 51  151      Jill
#[Out]# 52  152      Anne
#[Out]# 53  161     Floor
#[Out]# 54  162     Elena
#[Out]# 55  163      Cato
#[Out]# 56  165     Hanna
#[Out]# 57  169      Lily
#[Out]# 58  172      Lana
#[Out]# 59  176     Amira
#[Out]# 60  177     Eline
#[Out]# 61  178      Elif
#[Out]# 62  179      Juul
#[Out]# 63  180     Merel
#[Out]# 64  181      Liva
#[Out]# 65  184     Wilko
#[Out]# 66  190    Kostas
#[Out]# 
#[Out]# [67 rows x 2 columns]
# Tue, 01 Dec 2020 12:07:17
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, store as s, purchase as p
    WHERE s.sName = 'Coop' AND p.quantity>1 AND p.cID = c.cID AND p.sID = s.sID
    INTERSECT
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, store as s, purchase as p
    WHERE s.sName != 'Coop' AND p.quantity<1 AND p.cID = c.cID AND p.sID = s.sID
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []

# IPython log file

query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, store as s, purchase as p
    WHERE s.sName = 'Coop' AND p.quantity>1 AND p.cID = c.cID AND p.sID = s.sID
    UNION
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, store as s, purchase as p
    WHERE s.sName != 'Coop' AND p.quantity<1 AND p.cID = c.cID AND p.sID = s.sID
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 08:22:00
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 08:22:02
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 08:22:10
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, store as s, purchase as p
    WHERE s.sName = 'Coop' AND p.quantity>1 AND p.cID = c.cID AND p.sID = s.sID
    UNION
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, store as s, purchase as p
    WHERE s.sName != 'Coop' AND p.quantity<1 AND p.cID = c.cID AND p.sID = s.sID
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     2     Lucas
#[Out]# 1     4      Daan
#[Out]# 2     5      Levi
#[Out]# 3     8      Liam
#[Out]# 4    10       Sam
#[Out]# 5    11     Thijs
#[Out]# 6    16    Julian
#[Out]# 7    17       Dex
#[Out]# 8    18      Hugo
#[Out]# 9    20      Gijs
#[Out]# 10   21  Benjamin
#[Out]# 11   24      Luca
#[Out]# 12   26    Jayden
#[Out]# 13   27       Tim
#[Out]# 14   28      Siem
#[Out]# 15   29     Ruben
#[Out]# 16   33      Sven
#[Out]# 17   35     Stijn
#[Out]# 18   39      Jack
#[Out]# 19   42      Tijn
#[Out]# 20   51      Ties
#[Out]# 21   55     Aiden
#[Out]# 22   57    Nathan
#[Out]# 23   59      Joep
#[Out]# 24   67     Rayan
#[Out]# 25   71      Dean
#[Out]# 26   75      Jace
#[Out]# 27   78      Mick
#[Out]# 28   82     Dylan
#[Out]# 29   91   Thijmen
#[Out]# ..  ...       ...
#[Out]# 37  113     Fenna
#[Out]# 38  116     Lieke
#[Out]# 39  122      Elin
#[Out]# 40  123     Milou
#[Out]# 41  124     Sofie
#[Out]# 42  127     Emily
#[Out]# 43  129     Esmee
#[Out]# 44  131       Amy
#[Out]# 45  133    Sophia
#[Out]# 46  134      Ella
#[Out]# 47  135     Sofia
#[Out]# 48  139     Elise
#[Out]# 49  144       Ivy
#[Out]# 50  147    Isabel
#[Out]# 51  151      Jill
#[Out]# 52  152      Anne
#[Out]# 53  161     Floor
#[Out]# 54  162     Elena
#[Out]# 55  163      Cato
#[Out]# 56  165     Hanna
#[Out]# 57  169      Lily
#[Out]# 58  172      Lana
#[Out]# 59  176     Amira
#[Out]# 60  177     Eline
#[Out]# 61  178      Elif
#[Out]# 62  179      Juul
#[Out]# 63  180     Merel
#[Out]# 64  181      Liva
#[Out]# 65  184     Wilko
#[Out]# 66  190    Kostas
#[Out]# 
#[Out]# [67 rows x 2 columns]

   Bud1            %                       l o g sdsclbool                   dsclbool                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             @                                              @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   E   %                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       DSDB                             `                                                     @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              

# IPython log file

# Tue, 01 Dec 2020 12:30:36
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 12:30:38
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1ed6d61d0a0>
# Tue, 01 Dec 2020 12:32:35
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 12:33:36
query3_2 = '''
    SELECT cName
    FROM customer
    WHERE city = 'Utrecht'
'''
# Tue, 01 Dec 2020 12:33:38
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 12:33:44
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 12:34:02
query3_2 = '''
    SELECT cName
    FROM customer
    WHERE city ="Utrecht"
'''
# Tue, 01 Dec 2020 12:34:02
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 13:21:31
query3_2 = '''
    SELECT *
    FROM customer
    WHERE city ="Utrecht"
'''
# Tue, 01 Dec 2020 13:21:33
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 13:21:40
query3_2 = '''
    SELECT cName
    FROM customer
    WHERE city ="Utrecht"
'''
# Tue, 01 Dec 2020 13:21:42
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 13:21:48
pd.read_sql_query(query3_2, conn)
#[Out]#        cName
#[Out]# 0       Noah
#[Out]# 1       Levi
#[Out]# 2      Milan
#[Out]# 3        Tim
#[Out]# 4      Stijn
#[Out]# 5      Quinn
#[Out]# 6       Ryan
#[Out]# 7       Xavi
#[Out]# 8        Job
#[Out]# 9        Jax
#[Out]# 10     Aiden
#[Out]# 11  Mohammed
#[Out]# 12    Pepijn
#[Out]# 13      Roan
#[Out]# 14     Hidde
#[Out]# 15    Pieter
#[Out]# 16     Jelle
#[Out]# 17     Oscar
#[Out]# 18     Julia
#[Out]# 19       Eva
#[Out]# 20       Evi
#[Out]# 21     Fleur
#[Out]# 22      Roos
#[Out]# 23      Nina
#[Out]# 24     Esmee
#[Out]# 25     Sofia
#[Out]# 26      Lena
#[Out]# 27    Isabel
#[Out]# 28      Anne
#[Out]# 29    Benthe
#[Out]# 30      Luna
#[Out]# 31     Fenne
#[Out]# 32      Lily
#[Out]# 33      Elif
#[Out]# 34     Nikki
#[Out]# 35    Kostas
# Tue, 01 Dec 2020 14:14:35
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c AND shoppinglist AS sl AND purchase AS p
    WHERE c.cID = sl.cID AND c.cID = p.cID
'''
# Tue, 01 Dec 2020 14:14:38
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:14:51
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 14:15:03
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c, shoppinglist AS sl, purchase AS p
    WHERE c.cID = sl.cID AND c.cID = p.cID
'''
# Tue, 01 Dec 2020 14:15:05
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:15:10
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 14:16:07
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 14:16:18
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl, purchase AS p
    WHERE c.cID = sl.cID AND c.cID = p.cID
'''
# Tue, 01 Dec 2020 14:16:18
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:16:21
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 107  Amira  176
#[Out]# 108   Elif  178
#[Out]# 109   Juul  179
#[Out]# 110  Merel  180
#[Out]# 111   Liva  181
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Tue, 01 Dec 2020 14:18:54
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl, purchase AS p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date
'''
# Tue, 01 Dec 2020 14:18:55
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:19:01
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 14:24:40
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE %2018%
'''
# Tue, 01 Dec 2020 14:24:42
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:26:37
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE '%2018%''
'''
# Tue, 01 Dec 2020 14:26:38
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:26:52
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE '2018%''
'''
# Tue, 01 Dec 2020 14:26:54
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:27:13
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 14:27:15
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:27:27
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 128   Elif  178
#[Out]# 129   Juul  179
#[Out]# 130  Merel  180
#[Out]# 131   Liva  181
#[Out]# 132  Nikki  183
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 01 Dec 2020 14:28:48
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    INTERSECT SELECT DISTINCT cName, c.cID
    FROM purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 14:28:49
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:29:20
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    INTERSECT 
    SELECT DISTINCT cName, c.cID
    FROM purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 14:29:21
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:30:48
query3_2 = '''
    SELECT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    INTERSECT 
    SELECT cName, c.cID
    FROM purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 14:30:50
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:30:52
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 14:31:06
query3_2 = '''
    SELECT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    INTERSECT 
    SELECT c.cName, c.cID
    FROM purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 14:31:06
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:31:07
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 14:31:28
query3_2 = '''
    SELECT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    INTERSECT 
    SELECT cName, c.cID
   FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 14:31:29
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:31:30
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Tue, 01 Dec 2020 14:31:48
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    INTERSECT 
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 14:31:49
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 14:31:49
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Tue, 01 Dec 2020 15:12:52
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    AND
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 15:12:53
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 15:12:54
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 15:13:02
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    INTERSECT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 15:13:03
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 15:13:03
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Tue, 01 Dec 2020 15:14:16
query3_2 = '''
    (SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%")
    INTERSECT
    (SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%")
'''
# Tue, 01 Dec 2020 15:14:17
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 15:14:20
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 15:14:28
query3_2 = '''
    (SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%")
    /
    (SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%")
'''
# Tue, 01 Dec 2020 15:14:28
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 15:14:29
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 15:14:36
query3_2 = '''
    (SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%")
    /*
    (SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%")
'''
# Tue, 01 Dec 2020 15:14:36
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 15:14:48
query3_2 = '''
    (SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%")
    INTERSECT
    (SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%")
'''
# Tue, 01 Dec 2020 15:14:49
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 15:14:51
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 15:15:08
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    INTERSECT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Tue, 01 Dec 2020 15:15:08
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 15:15:09
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Tue, 01 Dec 2020 15:21:16
query3_3 = '''
    SELECT cName, cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.ID = p.ID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Tue, 01 Dec 2020 15:21:16
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 15:21:18
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:21:26
query3_3 = '''
    SELECT c.cName, cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.ID = p.ID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Tue, 01 Dec 2020 15:21:27
query3_3 = '''
    SELECT c.cName, cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.ID = p.ID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Tue, 01 Dec 2020 15:21:32
query3_3 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.ID = p.ID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Tue, 01 Dec 2020 15:21:32
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 15:21:33
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:21:44
query3_3 = '''
    SELECT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.ID = p.ID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Tue, 01 Dec 2020 15:21:45
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 15:21:46
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:21:54
query3_3 = '''
    SELECT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.ID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Tue, 01 Dec 2020 15:21:55
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 15:21:55
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 15:21:59
query3_3 = '''
    SELECT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Tue, 01 Dec 2020 15:22:00
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 15:22:00
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0     Lucas    2
#[Out]# 1     Lucas    2
#[Out]# 2     Lucas    2
#[Out]# 3      Daan    4
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 127  Kostas  190
#[Out]# 128  Kostas  190
#[Out]# 129  Kostas  190
#[Out]# 130  Kostas  190
#[Out]# 131  Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]

# IPython log file

# Wed, 02 Dec 2020 09:46:52
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 09:46:54
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 09:46:58
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Wed, 02 Dec 2020 09:47:02
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "2018%"
    INTERSECT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "2018%"
'''
# Wed, 02 Dec 2020 09:47:03
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 09:47:04
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 09:49:26
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 09:49:29
query3_3 = '''
    SELECT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Wed, 02 Dec 2020 09:49:29
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 09:49:30
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0     Lucas    2
#[Out]# 1     Lucas    2
#[Out]# 2     Lucas    2
#[Out]# 3      Daan    4
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 127  Kostas  190
#[Out]# 128  Kostas  190
#[Out]# 129  Kostas  190
#[Out]# 130  Kostas  190
#[Out]# 131  Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Wed, 02 Dec 2020 09:49:42
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Wed, 02 Dec 2020 09:49:42
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 09:49:43
pd.read_sql_query(query3_3, conn)
#[Out]#      cName  cID
#[Out]# 0    Lucas    2
#[Out]# 1     Daan    4
#[Out]# 2     Levi    5
#[Out]# 3     Liam    8
#[Out]# 4      Sam   10
#[Out]# ..     ...  ...
#[Out]# 69    Juul  179
#[Out]# 70   Merel  180
#[Out]# 71    Liva  181
#[Out]# 72   Wilko  184
#[Out]# 73  Kostas  190
#[Out]# 
#[Out]# [74 rows x 2 columns]
# Wed, 02 Dec 2020 09:50:34
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.cID AND p.sID = s.sID
    EXCEPT
    SELECT DISTINCT cName, c.CID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Wed, 02 Dec 2020 09:50:34
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 09:50:35
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0     Angela  186
#[Out]# 1      Boris   68
#[Out]# 2       Bram    7
#[Out]# 3     Casper   84
#[Out]# 4       Dani   72
#[Out]# 5      David   34
#[Out]# 6       Emma   95
#[Out]# 7      Femke  136
#[Out]# 8      Fenne  159
#[Out]# 9       Fien  145
#[Out]# 10      Finn    3
#[Out]# 11    Floris   38
#[Out]# 12      Guus   37
#[Out]# 13     Hidde   77
#[Out]# 14      Iris  170
#[Out]# 15     James   13
#[Out]# 16   Jasmijn  128
#[Out]# 17     Jason   44
#[Out]# 18      Jens   40
#[Out]# 19   Johanna  182
#[Out]# 20     Jurre   58
#[Out]# 21       Kai   70
#[Out]# 22      Kiki  168
#[Out]# 23      Koen  189
#[Out]# 24      Lars   19
#[Out]# 25    Lauren  111
#[Out]# 26      Lena  137
#[Out]# 27      Lenn   90
#[Out]# 28      Lina  126
#[Out]# 29       Liv  104
#[Out]# 30     Lizzy  149
#[Out]# 31      Lynn  109
#[Out]# 32     Mason   25
#[Out]# 33      Mats   22
#[Out]# 34   Mohamed   66
#[Out]# 35  Mohammed   60
#[Out]# 36      Nick  185
#[Out]# 37      Niek   80
#[Out]# 38      Nina  119
#[Out]# 39      Noah    0
#[Out]# 40      Noud   15
#[Out]# 41   Olivier   31
#[Out]# 42      Pino  188
#[Out]# 43      Puck  157
#[Out]# 44     Quinn   41
#[Out]# 45      Roan   69
#[Out]# 46      Ryan   45
#[Out]# 47       Sam  175
#[Out]# 48       Sem    1
#[Out]# 49      Senn   63
#[Out]# 50      Stan   64
#[Out]# 51      Stef   86
#[Out]# 52     Tessa  171
#[Out]# 53      Teun   30
#[Out]# 54       Tom   43
#[Out]# 55    Veerle  167
#[Out]# 56    Willem   52
#[Out]# 57      Xavi   47
# Wed, 02 Dec 2020 09:50:42
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0     Angela  186
#[Out]# 1      Boris   68
#[Out]# 2       Bram    7
#[Out]# 3     Casper   84
#[Out]# 4       Dani   72
#[Out]# 5      David   34
#[Out]# 6       Emma   95
#[Out]# 7      Femke  136
#[Out]# 8      Fenne  159
#[Out]# 9       Fien  145
#[Out]# 10      Finn    3
#[Out]# 11    Floris   38
#[Out]# 12      Guus   37
#[Out]# 13     Hidde   77
#[Out]# 14      Iris  170
#[Out]# 15     James   13
#[Out]# 16   Jasmijn  128
#[Out]# 17     Jason   44
#[Out]# 18      Jens   40
#[Out]# 19   Johanna  182
#[Out]# 20     Jurre   58
#[Out]# 21       Kai   70
#[Out]# 22      Kiki  168
#[Out]# 23      Koen  189
#[Out]# 24      Lars   19
#[Out]# 25    Lauren  111
#[Out]# 26      Lena  137
#[Out]# 27      Lenn   90
#[Out]# 28      Lina  126
#[Out]# 29       Liv  104
#[Out]# 30     Lizzy  149
#[Out]# 31      Lynn  109
#[Out]# 32     Mason   25
#[Out]# 33      Mats   22
#[Out]# 34   Mohamed   66
#[Out]# 35  Mohammed   60
#[Out]# 36      Nick  185
#[Out]# 37      Niek   80
#[Out]# 38      Nina  119
#[Out]# 39      Noah    0
#[Out]# 40      Noud   15
#[Out]# 41   Olivier   31
#[Out]# 42      Pino  188
#[Out]# 43      Puck  157
#[Out]# 44     Quinn   41
#[Out]# 45      Roan   69
#[Out]# 46      Ryan   45
#[Out]# 47       Sam  175
#[Out]# 48       Sem    1
#[Out]# 49      Senn   63
#[Out]# 50      Stan   64
#[Out]# 51      Stef   86
#[Out]# 52     Tessa  171
#[Out]# 53      Teun   30
#[Out]# 54       Tom   43
#[Out]# 55    Veerle  167
#[Out]# 56    Willem   52
#[Out]# 57      Xavi   47
# Wed, 02 Dec 2020 09:51:24
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.cID AND p.sID = s.sID AND cName
    EXCEPT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Wed, 02 Dec 2020 09:51:25
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 09:51:25
pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Wed, 02 Dec 2020 09:54:43
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.cID AND p.sID = s.sID
    EXCEPT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store as s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''
# Wed, 02 Dec 2020 09:54:44
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 09:54:44
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0     Angela  186
#[Out]# 1      Boris   68
#[Out]# 2       Bram    7
#[Out]# 3     Casper   84
#[Out]# 4       Dani   72
#[Out]# 5      David   34
#[Out]# 6       Emma   95
#[Out]# 7      Femke  136
#[Out]# 8      Fenne  159
#[Out]# 9       Fien  145
#[Out]# 10      Finn    3
#[Out]# 11    Floris   38
#[Out]# 12      Guus   37
#[Out]# 13     Hidde   77
#[Out]# 14      Iris  170
#[Out]# 15     James   13
#[Out]# 16   Jasmijn  128
#[Out]# 17     Jason   44
#[Out]# 18      Jens   40
#[Out]# 19   Johanna  182
#[Out]# 20     Jurre   58
#[Out]# 21       Kai   70
#[Out]# 22      Kiki  168
#[Out]# 23      Koen  189
#[Out]# 24      Lars   19
#[Out]# 25    Lauren  111
#[Out]# 26      Lena  137
#[Out]# 27      Lenn   90
#[Out]# 28      Lina  126
#[Out]# 29       Liv  104
#[Out]# 30     Lizzy  149
#[Out]# 31      Lynn  109
#[Out]# 32     Mason   25
#[Out]# 33      Mats   22
#[Out]# 34   Mohamed   66
#[Out]# 35  Mohammed   60
#[Out]# 36      Nick  185
#[Out]# 37      Niek   80
#[Out]# 38      Nina  119
#[Out]# 39      Noah    0
#[Out]# 40      Noud   15
#[Out]# 41   Olivier   31
#[Out]# 42      Pino  188
#[Out]# 43      Puck  157
#[Out]# 44     Quinn   41
#[Out]# 45      Roan   69
#[Out]# 46      Ryan   45
#[Out]# 47       Sam  175
#[Out]# 48       Sem    1
#[Out]# 49      Senn   63
#[Out]# 50      Stan   64
#[Out]# 51      Stef   86
#[Out]# 52     Tessa  171
#[Out]# 53      Teun   30
#[Out]# 54       Tom   43
#[Out]# 55    Veerle  167
#[Out]# 56    Willem   52
#[Out]# 57      Xavi   47
# Wed, 02 Dec 2020 09:54:54
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 09:55:30
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID
    EXCEPT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Coop'
'''
# Wed, 02 Dec 2020 09:55:31
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 09:55:31
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 09:55:45
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Coop'
'''
# Wed, 02 Dec 2020 09:55:46
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 09:55:46
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0     Angela  186
#[Out]# 1      Boris   68
#[Out]# 2       Bram    7
#[Out]# 3     Casper   84
#[Out]# 4       Dani   72
#[Out]# 5      David   34
#[Out]# 6       Emma   95
#[Out]# 7      Femke  136
#[Out]# 8      Fenne  159
#[Out]# 9       Fien  145
#[Out]# 10      Finn    3
#[Out]# 11    Floris   38
#[Out]# 12      Guus   37
#[Out]# 13     Hidde   77
#[Out]# 14      Iris  170
#[Out]# 15     James   13
#[Out]# 16   Jasmijn  128
#[Out]# 17     Jason   44
#[Out]# 18      Jens   40
#[Out]# 19   Johanna  182
#[Out]# 20     Jurre   58
#[Out]# 21       Kai   70
#[Out]# 22      Kiki  168
#[Out]# 23      Koen  189
#[Out]# 24      Lars   19
#[Out]# 25    Lauren  111
#[Out]# 26      Lena  137
#[Out]# 27      Lenn   90
#[Out]# 28      Lina  126
#[Out]# 29       Liv  104
#[Out]# 30     Lizzy  149
#[Out]# 31      Lynn  109
#[Out]# 32     Mason   25
#[Out]# 33      Mats   22
#[Out]# 34   Mohamed   66
#[Out]# 35  Mohammed   60
#[Out]# 36      Nick  185
#[Out]# 37      Niek   80
#[Out]# 38      Nina  119
#[Out]# 39      Noah    0
#[Out]# 40      Noud   15
#[Out]# 41   Olivier   31
#[Out]# 42      Pino  188
#[Out]# 43      Puck  157
#[Out]# 44     Quinn   41
#[Out]# 45      Roan   69
#[Out]# 46      Ryan   45
#[Out]# 47       Sam  175
#[Out]# 48       Sem    1
#[Out]# 49      Senn   63
#[Out]# 50      Stan   64
#[Out]# 51      Stef   86
#[Out]# 52     Tessa  171
#[Out]# 53      Teun   30
#[Out]# 54       Tom   43
#[Out]# 55    Veerle  167
#[Out]# 56    Willem   52
#[Out]# 57      Xavi   47
# Wed, 02 Dec 2020 10:57:40
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 10:57:40
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 10:57:41
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 10:58:46
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date = sl.date
'''
# Wed, 02 Dec 2020 10:58:46
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 10:58:47
pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 10:59:01
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 10:59:02
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 10:59:02
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 11:00:41
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:00:42
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:00:43
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 11:01:15
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 11:01:17
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 11:01:17
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Wed, 02 Dec 2020 11:01:20
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT cName, c.cID
    FROM customer AS c, purchase AS p
    WHERE c.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:01:20
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:01:21
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 11:01:46
query3_2 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT cName, c1.cID
    FROM customer AS c1, purchase AS p1
    WHERE c1.cID = p1.cID AND p1.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:01:46
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:01:47
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 11:01:59
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1
    WHERE c1.cID = p1.cID AND p1.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:02:00
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:02:00
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 11:02:19
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p
    WHERE c1.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:02:20
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:02:20
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 11:03:16
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT c.cName, c1.cID
    FROM customer AS c1, purchase AS p
    WHERE c1.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:03:17
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:03:17
pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:03:26
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName, c1.cID
    FROM customer AS c1, purchase AS p
    WHERE c1.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:03:27
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:03:27
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 11:04:33
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName
    FROM customer AS c1, purchase AS p
    WHERE c1.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:04:33
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:04:34
pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:04:51
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c1, purchase AS p
    WHERE c1.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:04:51
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c1, purchase AS p
    WHERE c1.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:04:53
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName, c.cID
    FROM customer AS c1, purchase AS p
    WHERE c1.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:04:53
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:04:54
pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:04:59
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName, c1.cID
    FROM customer AS c1, purchase AS p
    WHERE c1.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:05:00
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:05:08
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS sl
    WHERE c.cID = sl.cID AND sl.date LIKE "%2018%"
    INTERSECT
    SELECT DISTINCT cName, c1.cID
    FROM customer AS c1, purchase AS p
    WHERE c1.cID = p.cID AND p.date LIKE "%2018%"
'''
# Wed, 02 Dec 2020 11:05:08
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 11:05:09
pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID
#[Out]# 0        Aiden   55
#[Out]# 1    Alexander   76
#[Out]# 2        Amira  176
#[Out]# 3          Amy  131
#[Out]# 4         Anna   99
#[Out]# ..         ...  ...
#[Out]# 107        Tom   43
#[Out]# 108     Veerle  167
#[Out]# 109     Willem   52
#[Out]# 110       Xavi   47
#[Out]# 111       Yara  112
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 11:07:18
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Coop'
'''
# Wed, 02 Dec 2020 11:07:19
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:07:19
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0     Angela  186
#[Out]# 1      Boris   68
#[Out]# 2       Bram    7
#[Out]# 3     Casper   84
#[Out]# 4       Dani   72
#[Out]# 5      David   34
#[Out]# 6       Emma   95
#[Out]# 7      Femke  136
#[Out]# 8      Fenne  159
#[Out]# 9       Fien  145
#[Out]# 10      Finn    3
#[Out]# 11    Floris   38
#[Out]# 12      Guus   37
#[Out]# 13     Hidde   77
#[Out]# 14      Iris  170
#[Out]# 15     James   13
#[Out]# 16   Jasmijn  128
#[Out]# 17     Jason   44
#[Out]# 18      Jens   40
#[Out]# 19   Johanna  182
#[Out]# 20     Jurre   58
#[Out]# 21       Kai   70
#[Out]# 22      Kiki  168
#[Out]# 23      Koen  189
#[Out]# 24      Lars   19
#[Out]# 25    Lauren  111
#[Out]# 26      Lena  137
#[Out]# 27      Lenn   90
#[Out]# 28      Lina  126
#[Out]# 29       Liv  104
#[Out]# 30     Lizzy  149
#[Out]# 31      Lynn  109
#[Out]# 32     Mason   25
#[Out]# 33      Mats   22
#[Out]# 34   Mohamed   66
#[Out]# 35  Mohammed   60
#[Out]# 36      Nick  185
#[Out]# 37      Niek   80
#[Out]# 38      Nina  119
#[Out]# 39      Noah    0
#[Out]# 40      Noud   15
#[Out]# 41   Olivier   31
#[Out]# 42      Pino  188
#[Out]# 43      Puck  157
#[Out]# 44     Quinn   41
#[Out]# 45      Roan   69
#[Out]# 46      Ryan   45
#[Out]# 47       Sam  175
#[Out]# 48       Sem    1
#[Out]# 49      Senn   63
#[Out]# 50      Stan   64
#[Out]# 51      Stef   86
#[Out]# 52     Tessa  171
#[Out]# 53      Teun   30
#[Out]# 54       Tom   43
#[Out]# 55    Veerle  167
#[Out]# 56    Willem   52
#[Out]# 57      Xavi   47
# Wed, 02 Dec 2020 11:08:32
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Jumbo'
'''
# Wed, 02 Dec 2020 11:08:33
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Jumbo'
'''
# Wed, 02 Dec 2020 11:08:33
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:09:23
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Jumbo'
'''
# Wed, 02 Dec 2020 11:09:23
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:09:24
pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Wed, 02 Dec 2020 11:10:11
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Jumbo'
'''
# Wed, 02 Dec 2020 11:10:11
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:10:12
pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Wed, 02 Dec 2020 11:11:46
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Coop'
'''
# Wed, 02 Dec 2020 11:11:47
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:11:47
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Abel   62
#[Out]# 1      Adam   12
#[Out]# 2     Amber  153
#[Out]# 3    Angela  186
#[Out]# 4    Benthe  154
#[Out]# ..      ...  ...
#[Out]# 111  Veerle  167
#[Out]# 112    Vera  140
#[Out]# 113   Vince   32
#[Out]# 114  Willem   52
#[Out]# 115    Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Wed, 02 Dec 2020 11:12:40
query3_3 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName = 'Lidl'
'''
# Wed, 02 Dec 2020 11:12:40
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 11:12:41
pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 146       Vera  140
#[Out]# 147      Vince   32
#[Out]# 148      Wilko  184
#[Out]# 149     Willem   52
#[Out]# 150       Xavi   47
#[Out]# 
#[Out]# [151 rows x 2 columns]
# Wed, 02 Dec 2020 11:18:11
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName='Jumbo'
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName != 'Jumbo'
'''
# Wed, 02 Dec 2020 11:18:12
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 11:18:12
pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0  Angela  186
#[Out]# 1   Femke  136
#[Out]# 2    Koen  189
#[Out]# 3     Liv  104
#[Out]# 4    Nick  185
#[Out]# 5    Pino  188
#[Out]# 6    Senn   63
#[Out]# 7    Xavi   47
# Wed, 02 Dec 2020 11:18:21
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName='Coop'
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName != 'Coop'
'''
# Wed, 02 Dec 2020 11:18:21
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 11:18:22
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0       Aiden   55
#[Out]# 1   Alexander   76
#[Out]# 2         Amy  131
#[Out]# 3        Anna   99
#[Out]# 4      Jayden   26
#[Out]# 5        Jill  151
#[Out]# 6       Joris   88
#[Out]# 7        Liam    8
#[Out]# 8       Lotte  103
#[Out]# 9         Sam   10
#[Out]# 10       Siem   28
#[Out]# 11      Sofia  135
#[Out]# 12      Thijs   11
#[Out]# 13      Wilko  184
# Wed, 02 Dec 2020 11:19:04
query3_4 = '''
    SELECT DISTINCT cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName='Lidl'
    EXCEPT
    SELECT DISTINCT c1.cName, c1.cID
    FROM customer AS c1, purchase AS p1, store AS s1
    WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName != 'Lidl'
'''
# Wed, 02 Dec 2020 11:19:04
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 11:19:04
pd.read_sql_query(query3_4, conn)
#[Out]#    cName  cID
#[Out]# 0  Mason   25


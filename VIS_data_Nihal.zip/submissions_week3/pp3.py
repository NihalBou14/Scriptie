# IPython log file

# Wed, 02 Dec 2020 11:50:38
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 11:50:43
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1b5c6eb4960>
# Wed, 02 Dec 2020 11:51:02
query3_2 = '''
SELECT DISTINCT (cID AND cName) FROM customer

NATURAL JOIN

((SELECT (cID AND date) FROM shoppinglist WHERE date LIKE %2018%) 

NATURAL JOIN 

(SELECT (cID AND date) FROM purchase WHERE date LIKE %2018%))

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:51:40
query3_2 = '''
SELECT DISTINCT (cID AND cName) FROM customer

NATURAL JOIN

((SELECT (cID AND date) FROM shoppinglist WHERE date LIKE %2018%) 

NATURAL JOIN 

(SELECT (cID AND date) FROM purchase WHERE date LIKE %2018%));

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:53:12
query3_2 = '''
SELECT DISTINCT (cID AND cName) FROM customer

NATURAL JOIN

((SELECT (cID AND date) FROM shoppinglist WHERE date LIKE %2018%) 

NATURAL JOIN 

(SELECT (cID AND date) FROM purchase WHERE purchase.date LIKE %2018%));

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:54:42
query3_2 = '''
SELECT DISTINCT (cID AND cName) FROM customer

NATURAL JOIN

((SELECT (cID AND date) FROM shoppinglist WHERE date LIKE %2018%) 

NATURAL JOIN 

(SELECT (cID AND date) FROM purchase WHERE date LIKE '%2018%'));

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:55:47
query3_2 = '''
SELECT DISTINCT (cID AND cName) FROM customer

NATURAL JOIN

((SELECT (cID AND date) FROM shoppinglist WHERE date LIKE %2018%) 

NATURAL JOIN 

(SELECT (cID AND date) FROM purchase ));

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:56:39
query3_2 = '''
SELECT DISTINCT (cID AND cName) FROM customer 
NATURAL JOIN
((SELECT (cID AND date) FROM shoppinglist WHERE date LIKE %2018%) 
NATURAL JOIN 
(SELECT (cID AND date) FROM purchase ));
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:58:55
query3_2 = '''
SELECT DISTINCT (cID AND cName) FROM customer

NATURAL JOIN

((SELECT (cID AND date) FROM shoppinglist WHERE date LIKE %2018%) 

INTERSECT

(SELECT (cID AND date) FROM purchase WHERE date LIKE '%2018%'));

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 11:59:32
query3_2 = '''


((SELECT (cID AND date) FROM shoppinglist WHERE date LIKE %2018%) 

INTERSECT

(SELECT (cID AND date) FROM purchase WHERE date LIKE '%2018%'));

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:00:05
query3_2 = '''


((SELECT cID AND date FROM shoppinglist WHERE date LIKE %2018%) 

INTERSECT

(SELECT cID AND date FROM purchase WHERE date LIKE '%2018%'));

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:00:12
query3_2 = '''


(SELECT cID AND date FROM shoppinglist WHERE date LIKE %2018%) 

INTERSECT

(SELECT cID AND date FROM purchase WHERE date LIKE '%2018%');

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:00:24
query3_2 = '''


SELECT cID AND date FROM shoppinglist WHERE date LIKE %2018%) 

INTERSECT

(SELECT cID AND date FROM purchase WHERE date LIKE '%2018%';

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:00:30
query3_2 = '''


SELECT cID AND date FROM shoppinglist WHERE date LIKE %2018%) 

INTERSECT

(SELECT cID AND date FROM purchase WHERE date LIKE '%2018%';

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:00:49
query3_2 = '''


SELECT cID AND date FROM shoppinglist WHERE date LIKE %2018% 
INTERSECT
SELECT cID AND date FROM purchase WHERE date LIKE '%2018%';

'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:01:42
query3_2 = '''


SELECT cID AND date FROM shoppinglist;

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID AND date
#[Out]# 0               1
#[Out]# 1               1
#[Out]# 2               1
#[Out]# 3               1
#[Out]# 4               1
#[Out]# 5               1
#[Out]# 6               1
#[Out]# 7               1
#[Out]# 8               1
#[Out]# 9               1
#[Out]# 10              1
#[Out]# 11              1
#[Out]# 12              1
#[Out]# 13              1
#[Out]# 14              1
#[Out]# 15              1
#[Out]# 16              1
#[Out]# 17              1
#[Out]# 18              1
#[Out]# 19              1
#[Out]# 20              1
#[Out]# 21              1
#[Out]# 22              1
#[Out]# 23              1
#[Out]# 24              1
#[Out]# 25              1
#[Out]# 26              1
#[Out]# 27              1
#[Out]# 28              1
#[Out]# 29              1
#[Out]# ..            ...
#[Out]# 462             1
#[Out]# 463             1
#[Out]# 464             1
#[Out]# 465             1
#[Out]# 466             1
#[Out]# 467             1
#[Out]# 468             1
#[Out]# 469             1
#[Out]# 470             1
#[Out]# 471             1
#[Out]# 472             1
#[Out]# 473             1
#[Out]# 474             1
#[Out]# 475             1
#[Out]# 476             1
#[Out]# 477             1
#[Out]# 478             1
#[Out]# 479             1
#[Out]# 480             1
#[Out]# 481             1
#[Out]# 482             1
#[Out]# 483             1
#[Out]# 484             1
#[Out]# 485             1
#[Out]# 486             1
#[Out]# 487             1
#[Out]# 488             1
#[Out]# 489             1
#[Out]# 490             1
#[Out]# 491             1
#[Out]# 
#[Out]# [492 rows x 1 columns]
# Wed, 02 Dec 2020 12:01:59
query3_2 = '''


SELECT cID AND date FROM shoppinglist WHERE date LIKE %2018%;
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:02:25
query3_2 = '''


SELECT cID AND date FROM shoppinglist WHERE date LIKE '%2018%';
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID AND date
#[Out]# 0               1
#[Out]# 1               1
#[Out]# 2               1
#[Out]# 3               1
#[Out]# 4               1
#[Out]# 5               1
#[Out]# 6               1
#[Out]# 7               1
#[Out]# 8               1
#[Out]# 9               1
#[Out]# 10              1
#[Out]# 11              1
#[Out]# 12              1
#[Out]# 13              1
#[Out]# 14              1
#[Out]# 15              1
#[Out]# 16              1
#[Out]# 17              1
#[Out]# 18              1
#[Out]# 19              1
#[Out]# 20              1
#[Out]# 21              1
#[Out]# 22              1
#[Out]# 23              1
#[Out]# 24              1
#[Out]# 25              1
#[Out]# 26              1
#[Out]# 27              1
#[Out]# 28              1
#[Out]# 29              1
#[Out]# ..            ...
#[Out]# 462             1
#[Out]# 463             1
#[Out]# 464             1
#[Out]# 465             1
#[Out]# 466             1
#[Out]# 467             1
#[Out]# 468             1
#[Out]# 469             1
#[Out]# 470             1
#[Out]# 471             1
#[Out]# 472             1
#[Out]# 473             1
#[Out]# 474             1
#[Out]# 475             1
#[Out]# 476             1
#[Out]# 477             1
#[Out]# 478             1
#[Out]# 479             1
#[Out]# 480             1
#[Out]# 481             1
#[Out]# 482             1
#[Out]# 483             1
#[Out]# 484             1
#[Out]# 485             1
#[Out]# 486             1
#[Out]# 487             1
#[Out]# 488             1
#[Out]# 489             1
#[Out]# 490             1
#[Out]# 491             1
#[Out]# 
#[Out]# [492 rows x 1 columns]
# Wed, 02 Dec 2020 12:02:34
query3_2 = '''


SELECT cID AND date FROM shoppinglist WHERE date LIKE '%2018%'
INTERSECT
SELECT cID AND date FROM purchase WHERE date LIKE '%2018%';
'''

pd.read_sql_query(query3_2, conn)
#[Out]#    cID AND date
#[Out]# 0             1
# Wed, 02 Dec 2020 12:02:52
query3_2 = '''


SELECT cID,date FROM shoppinglist WHERE date LIKE '%2018%'
INTERSECT
SELECT cID,date FROM purchase WHERE date LIKE '%2018%';
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID        date
#[Out]# 0      1  2018-08-20
#[Out]# 1      1  2018-08-21
#[Out]# 2      2  2018-08-16
#[Out]# 3      2  2018-08-17
#[Out]# 4      3  2018-08-18
#[Out]# 5      3  2018-08-19
#[Out]# 6      5  2018-08-17
#[Out]# 7      5  2018-08-22
#[Out]# 8      5  2018-08-23
#[Out]# 9      7  2018-08-23
#[Out]# 10     7  2018-08-24
#[Out]# 11     7  2018-08-25
#[Out]# 12     7  2018-08-26
#[Out]# 13     8  2018-08-16
#[Out]# 14    10  2018-08-27
#[Out]# 15    11  2018-08-25
#[Out]# 16    13  2018-08-17
#[Out]# 17    13  2018-08-25
#[Out]# 18    13  2018-08-26
#[Out]# 19    13  2018-08-27
#[Out]# 20    15  2018-08-27
#[Out]# 21    17  2018-08-19
#[Out]# 22    18  2018-08-16
#[Out]# 23    18  2018-08-18
#[Out]# 24    19  2018-08-17
#[Out]# 25    19  2018-08-18
#[Out]# 26    20  2018-08-17
#[Out]# 27    20  2018-08-18
#[Out]# 28    21  2018-08-15
#[Out]# 29    22  2018-08-27
#[Out]# ..   ...         ...
#[Out]# 156  165  2018-08-23
#[Out]# 157  165  2018-08-24
#[Out]# 158  167  2018-08-15
#[Out]# 159  167  2018-08-18
#[Out]# 160  167  2018-08-19
#[Out]# 161  167  2018-08-20
#[Out]# 162  167  2018-08-21
#[Out]# 163  168  2018-08-16
#[Out]# 164  169  2018-08-16
#[Out]# 165  169  2018-08-17
#[Out]# 166  169  2018-08-18
#[Out]# 167  169  2018-08-19
#[Out]# 168  169  2018-08-20
#[Out]# 169  169  2018-08-26
#[Out]# 170  169  2018-08-27
#[Out]# 171  170  2018-08-16
#[Out]# 172  171  2018-08-20
#[Out]# 173  172  2018-08-24
#[Out]# 174  172  2018-08-27
#[Out]# 175  175  2018-08-19
#[Out]# 176  176  2018-08-22
#[Out]# 177  176  2018-08-25
#[Out]# 178  176  2018-08-26
#[Out]# 179  178  2018-08-27
#[Out]# 180  179  2018-08-22
#[Out]# 181  179  2018-08-24
#[Out]# 182  180  2018-08-26
#[Out]# 183  180  2018-08-27
#[Out]# 184  181  2018-08-24
#[Out]# 185  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 2 columns]
# Wed, 02 Dec 2020 12:05:18
query3_2 = '''

SELECT cID, cName FROM customer GROUPBY

SELECT cID FROM shoppinglist WHERE date LIKE '%2018%'
INTERSECT
SELECT cID FROM purchase WHERE date LIKE '%2018%';
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:05:35
query3_2 = '''

SELECT cID, cName FROM customer GROUP BY

SELECT cID FROM shoppinglist WHERE date LIKE '%2018%'
INTERSECT
SELECT cID FROM purchase WHERE date LIKE '%2018%';
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:05:51
query3_2 = '''


SELECT cID FROM shoppinglist WHERE date LIKE '%2018%'
INTERSECT
SELECT cID FROM purchase WHERE date LIKE '%2018%';
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      2
#[Out]# 2      3
#[Out]# 3      5
#[Out]# 4      7
#[Out]# 5      8
#[Out]# 6     10
#[Out]# 7     11
#[Out]# 8     13
#[Out]# 9     15
#[Out]# 10    17
#[Out]# 11    18
#[Out]# 12    19
#[Out]# 13    20
#[Out]# 14    21
#[Out]# 15    22
#[Out]# 16    24
#[Out]# 17    25
#[Out]# 18    26
#[Out]# 19    27
#[Out]# 20    28
#[Out]# 21    29
#[Out]# 22    30
#[Out]# 23    31
#[Out]# 24    33
#[Out]# 25    34
#[Out]# 26    35
#[Out]# 27    37
#[Out]# 28    38
#[Out]# 29    39
#[Out]# ..   ...
#[Out]# 82   128
#[Out]# 83   131
#[Out]# 84   133
#[Out]# 85   134
#[Out]# 86   136
#[Out]# 87   137
#[Out]# 88   144
#[Out]# 89   145
#[Out]# 90   147
#[Out]# 91   149
#[Out]# 92   151
#[Out]# 93   152
#[Out]# 94   157
#[Out]# 95   159
#[Out]# 96   161
#[Out]# 97   162
#[Out]# 98   163
#[Out]# 99   165
#[Out]# 100  167
#[Out]# 101  168
#[Out]# 102  169
#[Out]# 103  170
#[Out]# 104  171
#[Out]# 105  172
#[Out]# 106  175
#[Out]# 107  176
#[Out]# 108  178
#[Out]# 109  179
#[Out]# 110  180
#[Out]# 111  181
#[Out]# 
#[Out]# [112 rows x 1 columns]
# Wed, 02 Dec 2020 12:08:03
query3_2 = '''

SELECT cID, cName from customer WHERE cID IN (
SELECT cID FROM shoppinglist WHERE date LIKE '%2018%'
INTERSECT
SELECT cID FROM purchase WHERE date LIKE '%2018%');
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    25     Mason
#[Out]# 18    26    Jayden
#[Out]# 19    27       Tim
#[Out]# 20    28      Siem
#[Out]# 21    29     Ruben
#[Out]# 22    30      Teun
#[Out]# 23    31   Olivier
#[Out]# 24    33      Sven
#[Out]# 25    34     David
#[Out]# 26    35     Stijn
#[Out]# 27    37      Guus
#[Out]# 28    38    Floris
#[Out]# 29    39      Jack
#[Out]# ..   ...       ...
#[Out]# 82   128   Jasmijn
#[Out]# 83   131       Amy
#[Out]# 84   133    Sophia
#[Out]# 85   134      Ella
#[Out]# 86   136     Femke
#[Out]# 87   137      Lena
#[Out]# 88   144       Ivy
#[Out]# 89   145      Fien
#[Out]# 90   147    Isabel
#[Out]# 91   149     Lizzy
#[Out]# 92   151      Jill
#[Out]# 93   152      Anne
#[Out]# 94   157      Puck
#[Out]# 95   159     Fenne
#[Out]# 96   161     Floor
#[Out]# 97   162     Elena
#[Out]# 98   163      Cato
#[Out]# 99   165     Hanna
#[Out]# 100  167    Veerle
#[Out]# 101  168      Kiki
#[Out]# 102  169      Lily
#[Out]# 103  170      Iris
#[Out]# 104  171     Tessa
#[Out]# 105  172      Lana
#[Out]# 106  175       Sam
#[Out]# 107  176     Amira
#[Out]# 108  178      Elif
#[Out]# 109  179      Juul
#[Out]# 110  180     Merel
#[Out]# 111  181      Liva
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 12:12:56
query3_3 = '''
SELECT cID, cName from customer EXCEPT 

SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')

'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:13:09
query3_3 = '''
SELECT cID from customer EXCEPT 

SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')

'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      3
#[Out]# 3      6
#[Out]# 4      7
#[Out]# 5      9
#[Out]# 6     12
#[Out]# 7     13
#[Out]# 8     14
#[Out]# 9     15
#[Out]# 10    19
#[Out]# 11    22
#[Out]# 12    23
#[Out]# 13    25
#[Out]# 14    30
#[Out]# 15    31
#[Out]# 16    32
#[Out]# 17    34
#[Out]# 18    36
#[Out]# 19    37
#[Out]# 20    38
#[Out]# 21    40
#[Out]# 22    41
#[Out]# 23    43
#[Out]# 24    44
#[Out]# 25    45
#[Out]# 26    46
#[Out]# 27    47
#[Out]# 28    48
#[Out]# 29    49
#[Out]# ..   ...
#[Out]# 86   142
#[Out]# 87   143
#[Out]# 88   145
#[Out]# 89   146
#[Out]# 90   148
#[Out]# 91   149
#[Out]# 92   150
#[Out]# 93   153
#[Out]# 94   154
#[Out]# 95   155
#[Out]# 96   156
#[Out]# 97   157
#[Out]# 98   158
#[Out]# 99   159
#[Out]# 100  160
#[Out]# 101  164
#[Out]# 102  166
#[Out]# 103  167
#[Out]# 104  168
#[Out]# 105  170
#[Out]# 106  171
#[Out]# 107  173
#[Out]# 108  174
#[Out]# 109  175
#[Out]# 110  182
#[Out]# 111  183
#[Out]# 112  185
#[Out]# 113  186
#[Out]# 114  188
#[Out]# 115  189
#[Out]# 
#[Out]# [116 rows x 1 columns]
# Wed, 02 Dec 2020 12:13:41
query3_3 = '''
SELECT cID, cName WHERE cID IN (
SELECT cID from customer EXCEPT 

SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop'))

'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:14:28
query3_3 = '''
SELECT cID, cName FROM customer WHERE cID IN (
SELECT cID from customer EXCEPT 

SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop'))

'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Wed, 02 Dec 2020 12:14:50
query3_3 = '''
SELECT cID, cName FROM customer WHERE cID IN (
SELECT cID from customer EXCEPT 
)SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Kumar'))

'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:14:55
query3_3 = '''
SELECT cID, cName FROM customer WHERE cID IN (
SELECT cID from customer EXCEPT 
)SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Kumar')))

'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:15:09
query3_3 = '''
SELECT cID, cName FROM customer WHERE cID IN (
SELECT cID from customer EXCEPT 
(SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Kumar')))

'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:15:12
query3_3 = '''
SELECT cID, cName FROM customer WHERE cID IN (
SELECT cID from customer EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Kumar'))

'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Wed, 02 Dec 2020 12:20:19
query3_4 = '''
SELECT cID, cName FROM customer WHERE cID IN()
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop'))
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop')));
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:20:23
query3_4 = '''
SELECT cID, cName FROM customer WHERE cID IN(
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop'))
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop')));
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:20:32
query3_4 = '''
SELECT cID, cName FROM customer WHERE cID IN
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop'))
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop'))
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:20:35
query3_4 = '''
SELECT cID, cName FROM customer WHERE cID IN
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop'))
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop'));
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:21:37
query3_4 = '''

SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop'))
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop'));
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:21:48
query3_4 = '''

SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     8
#[Out]# 1    10
#[Out]# 2    11
#[Out]# 3    26
#[Out]# 4    28
#[Out]# 5    55
#[Out]# 6    76
#[Out]# 7    88
#[Out]# 8    99
#[Out]# 9   103
#[Out]# 10  131
#[Out]# 11  135
#[Out]# 12  151
#[Out]# 13  184
# Wed, 02 Dec 2020 12:21:56
query3_4 = '''
SELECT cID, cName FROM customer WHERE cID IN
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop');
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:22:19
query3_4 = '''

SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     8
#[Out]# 1    10
#[Out]# 2    11
#[Out]# 3    26
#[Out]# 4    28
#[Out]# 5    55
#[Out]# 6    76
#[Out]# 7    88
#[Out]# 8    99
#[Out]# 9   103
#[Out]# 10  131
#[Out]# 11  135
#[Out]# 12  151
#[Out]# 13  184
# Wed, 02 Dec 2020 12:22:44
query3_4 = '''
SELECT cName, cID FROM customer WHERE cID IN
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop');
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:22:55
query3_4 = '''

SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     8
#[Out]# 1    10
#[Out]# 2    11
#[Out]# 3    26
#[Out]# 4    28
#[Out]# 5    55
#[Out]# 6    76
#[Out]# 7    88
#[Out]# 8    99
#[Out]# 9   103
#[Out]# 10  131
#[Out]# 11  135
#[Out]# 12  151
#[Out]# 13  184
# Wed, 02 Dec 2020 12:23:59
query3_4 = '''
SELECT cName, cID FROM customer WHERE cID IN
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop');
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:24:13
query3_4 = '''
SELECT cName, cID FROM customer WHERE cID IN 
(SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop'));
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Wed, 02 Dec 2020 12:24:39
query3_2 = '''

SELECT cName, cID from customer WHERE cID IN (
SELECT cID FROM shoppinglist WHERE date LIKE '%2018%'
INTERSECT
SELECT cID FROM purchase WHERE date LIKE '%2018%');
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18     Jayden   26
#[Out]# 19        Tim   27
#[Out]# 20       Siem   28
#[Out]# 21      Ruben   29
#[Out]# 22       Teun   30
#[Out]# 23    Olivier   31
#[Out]# 24       Sven   33
#[Out]# 25      David   34
#[Out]# 26      Stijn   35
#[Out]# 27       Guus   37
#[Out]# 28     Floris   38
#[Out]# 29       Jack   39
#[Out]# ..        ...  ...
#[Out]# 82    Jasmijn  128
#[Out]# 83        Amy  131
#[Out]# 84     Sophia  133
#[Out]# 85       Ella  134
#[Out]# 86      Femke  136
#[Out]# 87       Lena  137
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Jill  151
#[Out]# 93       Anne  152
#[Out]# 94       Puck  157
#[Out]# 95      Fenne  159
#[Out]# 96      Floor  161
#[Out]# 97      Elena  162
#[Out]# 98       Cato  163
#[Out]# 99      Hanna  165
#[Out]# 100    Veerle  167
#[Out]# 101      Kiki  168
#[Out]# 102      Lily  169
#[Out]# 103      Iris  170
#[Out]# 104     Tessa  171
#[Out]# 105      Lana  172
#[Out]# 106       Sam  175
#[Out]# 107     Amira  176
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 12:24:42
query3_3 = '''
SELECT cName, cID FROM customer WHERE cID IN (
SELECT cID from customer EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Kumar'))
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Wed, 02 Dec 2020 12:24:45
query3_4 = '''
SELECT cName, cID FROM customer WHERE cID IN 
(SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop'));
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Wed, 02 Dec 2020 12:25:07
query3_2 = '''

SELECT DISTINCT cName, cID from customer WHERE cID IN (
SELECT cID FROM shoppinglist WHERE date LIKE '%2018%'
INTERSECT
SELECT cID FROM purchase WHERE date LIKE '%2018%');
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18     Jayden   26
#[Out]# 19        Tim   27
#[Out]# 20       Siem   28
#[Out]# 21      Ruben   29
#[Out]# 22       Teun   30
#[Out]# 23    Olivier   31
#[Out]# 24       Sven   33
#[Out]# 25      David   34
#[Out]# 26      Stijn   35
#[Out]# 27       Guus   37
#[Out]# 28     Floris   38
#[Out]# 29       Jack   39
#[Out]# ..        ...  ...
#[Out]# 82    Jasmijn  128
#[Out]# 83        Amy  131
#[Out]# 84     Sophia  133
#[Out]# 85       Ella  134
#[Out]# 86      Femke  136
#[Out]# 87       Lena  137
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Jill  151
#[Out]# 93       Anne  152
#[Out]# 94       Puck  157
#[Out]# 95      Fenne  159
#[Out]# 96      Floor  161
#[Out]# 97      Elena  162
#[Out]# 98       Cato  163
#[Out]# 99      Hanna  165
#[Out]# 100    Veerle  167
#[Out]# 101      Kiki  168
#[Out]# 102      Lily  169
#[Out]# 103      Iris  170
#[Out]# 104     Tessa  171
#[Out]# 105      Lana  172
#[Out]# 106       Sam  175
#[Out]# 107     Amira  176
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Wed, 02 Dec 2020 12:25:10
query3_3 = '''
SELECT DISTINCT cName, cID FROM customer WHERE cID IN (
SELECT cID from customer EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Kumar'))
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Wed, 02 Dec 2020 12:25:12
query3_4 = '''
SELECT DISTINCT cName, cID FROM customer WHERE cID IN 
(SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName = 'Coop')
EXCEPT 
SELECT cID from purchase WHERE sID IN 
(SELECT sID from store WHERE sName != 'Coop'));
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184

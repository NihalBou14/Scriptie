# IPython log file

# Tue, 01 Dec 2020 10:48:14
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 10:48:14
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1954f05d8f0>
# Tue, 01 Dec 2020 10:48:30
query3_2 = '''
    PUT YOUR QUERY HERE
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 10:52:27
query3_2 = ''' SELECT c.cName, c.cID FROM customer c, purchase p, shoppinglist s
WHERE p.date=s.date AND p.date LIKE "2018%" AND c.cID = p.cID AND c.cID= s.cID;

'''

pd.read_sql_query(query3_2, conn)
#[Out]#     cName  cID
#[Out]# 0     Sem    1
#[Out]# 1     Sem    1
#[Out]# 2     Sem    1
#[Out]# 3     Sem    1
#[Out]# 4     Sem    1
#[Out]# ..    ...  ...
#[Out]# 971  Liva  181
#[Out]# 972  Liva  181
#[Out]# 973  Liva  181
#[Out]# 974  Liva  181
#[Out]# 975  Liva  181
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Tue, 01 Dec 2020 10:53:06
query3_2 = ''' SELECT DISTINCT c.cName, c.cID  FROM customer c, purchase p, shoppinglist s
WHERE p.date=s.date AND p.date LIKE "2018%" AND c.cID = p.cID AND c.cID= s.cID;

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 10:53:11
query3_2 = ''' SELECT DISTINCT c.cName, c.cID FROM customer c, purchase p, shoppinglist s
WHERE p.date=s.date AND p.date LIKE "2018%" AND c.cID = p.cID AND c.cID= s.cID;

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 11:03:31
query3_3 = ''' SELECT cID FROM customer EXCEPT SELECT cID FROM purchase
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID
#[Out]# 0     6
#[Out]# 1     9
#[Out]# 2    12
#[Out]# 3    14
#[Out]# 4    23
#[Out]# 5    32
#[Out]# 6    36
#[Out]# 7    46
#[Out]# 8    48
#[Out]# 9    49
#[Out]# 10   50
#[Out]# 11   53
#[Out]# 12   54
#[Out]# 13   56
#[Out]# 14   61
#[Out]# 15   62
#[Out]# 16   65
#[Out]# 17   73
#[Out]# 18   74
#[Out]# 19   79
#[Out]# 20   81
#[Out]# 21   83
#[Out]# 22   87
#[Out]# 23   89
#[Out]# 24   93
#[Out]# 25   98
#[Out]# 26  101
#[Out]# 27  102
#[Out]# 28  105
#[Out]# 29  106
#[Out]# 30  107
#[Out]# 31  114
#[Out]# 32  115
#[Out]# 33  117
#[Out]# 34  120
#[Out]# 35  121
#[Out]# 36  125
#[Out]# 37  130
#[Out]# 38  132
#[Out]# 39  138
#[Out]# 40  140
#[Out]# 41  141
#[Out]# 42  142
#[Out]# 43  143
#[Out]# 44  146
#[Out]# 45  148
#[Out]# 46  150
#[Out]# 47  153
#[Out]# 48  154
#[Out]# 49  155
#[Out]# 50  156
#[Out]# 51  158
#[Out]# 52  160
#[Out]# 53  164
#[Out]# 54  166
#[Out]# 55  173
#[Out]# 56  174
#[Out]# 57  183
# Tue, 01 Dec 2020 11:09:58
query3_3 = ''' SELECT cName, cID IN (SELECT cID FROM customer EXCEPT SELECT cID FROM purchase 
UNION SELECT cID FROM customer EXCEPT SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop"))
    
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 11:10:23
query3_3 = ''' SELECT cName, cID WHERE cID IN (SELECT cID FROM customer EXCEPT SELECT cID FROM purchase 
UNION SELECT cID FROM customer EXCEPT SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop"))
    
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 11:10:43
query3_3 = ''' SELECT cName, cID FROM customer WHERE cID IN (SELECT cID FROM customer EXCEPT SELECT cID FROM purchase 
UNION SELECT cID FROM customer EXCEPT SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop"))
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 11:18:10
query3_4 = ''' SELECT cID, cName FROM customer WHERE cID IN 
(SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")) 
EXCEPT SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName != "Coop"))
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 11:18:24
query3_4 = ''' SELECT cID, cName FROM customer WHERE cID IN 
((SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")) 
EXCEPT SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName != "Coop")))
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 11:18:47
query3_4 = ''' SELECT cID, cName FROM customer WHERE cID IN 
((SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
EXCEPT SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName != "Coop"))
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 11:18:53
query3_4 = ''' SELECT cID, cName FROM customer WHERE cID IN 
(SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
EXCEPT SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName != "Coop"))
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID      cName
#[Out]# 0     8       Liam
#[Out]# 1    10        Sam
#[Out]# 2    11      Thijs
#[Out]# 3    26     Jayden
#[Out]# 4    28       Siem
#[Out]# 5    55      Aiden
#[Out]# 6    76  Alexander
#[Out]# 7    88      Joris
#[Out]# 8    99       Anna
#[Out]# 9   103      Lotte
#[Out]# 10  131        Amy
#[Out]# 11  135      Sofia
#[Out]# 12  151       Jill
#[Out]# 13  184      Wilko

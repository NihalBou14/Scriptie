# IPython log file

# Sun, 29 Nov 2020 14:27:06
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 29 Nov 2020 14:27:40
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x18170bb08f0>
# Mon, 30 Nov 2020 10:29:29
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 10:42:26
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x0000018170BB08F0>
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 10:45:13
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 10:45:16
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 10:45:51
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 10:52:02
query3_2 = '''
SELECT cName, city FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName       city
#[Out]# 0      Noah    Utrecht
#[Out]# 1       Sem      Breda
#[Out]# 2     Lucas  Amsterdam
#[Out]# 3      Finn      Breda
#[Out]# 4      Daan  Amsterdam
#[Out]# ..      ...        ...
#[Out]# 185    Nick  Eindhoven
#[Out]# 186  Angela  Eindhoven
#[Out]# 187    Pino  Rotterdam
#[Out]# 188    Koen        Oss
#[Out]# 189  Kostas    Utrecht
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 10:52:38
query3_2 = '''
SELECT cID,cName FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 10:55:24
query3_2 = '''
SELECT cID,cName FROM customer AND shoppinglist WHERE 
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 10:55:30
query3_2 = '''
SELECT cID,cName FROM customer AND shoppinglist
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 10:55:35
query3_2 = '''
SELECT cID,cName FROM customer, shoppinglist
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 10:55:47
query3_2 = '''
SELECT customer.cID,customer.cName FROM customer, shoppinglist
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID   cName
#[Out]# 0        0    Noah
#[Out]# 1        0    Noah
#[Out]# 2        0    Noah
#[Out]# 3        0    Noah
#[Out]# 4        0    Noah
#[Out]# ...    ...     ...
#[Out]# 93475  190  Kostas
#[Out]# 93476  190  Kostas
#[Out]# 93477  190  Kostas
#[Out]# 93478  190  Kostas
#[Out]# 93479  190  Kostas
#[Out]# 
#[Out]# [93480 rows x 2 columns]
# Mon, 30 Nov 2020 10:55:55
query3_2 = '''
SELECT customer.cID,customer.cName FROM customer c, shoppinglist
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 10:56:03
query3_2 = '''
SELECT c.cID,c.cName FROM customer c, shoppinglist
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID   cName
#[Out]# 0        0    Noah
#[Out]# 1        0    Noah
#[Out]# 2        0    Noah
#[Out]# 3        0    Noah
#[Out]# 4        0    Noah
#[Out]# ...    ...     ...
#[Out]# 93475  190  Kostas
#[Out]# 93476  190  Kostas
#[Out]# 93477  190  Kostas
#[Out]# 93478  190  Kostas
#[Out]# 93479  190  Kostas
#[Out]# 
#[Out]# [93480 rows x 2 columns]
# Mon, 30 Nov 2020 10:56:14
query3_2 = '''
SELECT c.cID,c.cName FROM customer c, shoppinglist s, purchase p
'''

pd.read_sql_query(query3_2, conn)

# IPython log file

# Mon, 30 Nov 2020 10:57:06
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 10:57:06
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 10:57:31
query3_2 = '''
SELECT c.cID, c.cName FROM customer c, shoppinglist s, purchase p
'''

pd.read_sql_query(query3_2, conn)

# IPython log file

# Mon, 30 Nov 2020 11:01:46
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Mon, 30 Nov 2020 11:01:53
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 11:01:56
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 11:02:02
query3_2 = '''
SELECT c.cID, c.cName FROM customer c, shoppinglist s, purchase p 
'''

pd.read_sql_query(query3_2, conn)
#[Out]#           cID   cName
#[Out]# 0           0    Noah
#[Out]# 1           0    Noah
#[Out]# 2           0    Noah
#[Out]# 3           0    Noah
#[Out]# 4           0    Noah
#[Out]# ...       ...     ...
#[Out]# 47581315  190  Kostas
#[Out]# 47581316  190  Kostas
#[Out]# 47581317  190  Kostas
#[Out]# 47581318  190  Kostas
#[Out]# 47581319  190  Kostas
#[Out]# 
#[Out]# [47581320 rows x 2 columns]
# Mon, 30 Nov 2020 11:05:15
query3_2 = '''
SELECT c.cID, c.cName FROM customer c
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 11:05:15
query3_2 = '''
SELECT c.cID, c.cName FROM customer c, shoppinglist s, purchase p WHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID cName
#[Out]# 0      1   Sem
#[Out]# 1      1   Sem
#[Out]# 2      1   Sem
#[Out]# 3      1   Sem
#[Out]# 4      1   Sem
#[Out]# ..   ...   ...
#[Out]# 971  181  Liva
#[Out]# 972  181  Liva
#[Out]# 973  181  Liva
#[Out]# 974  181  Liva
#[Out]# 975  181  Liva
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Mon, 30 Nov 2020 11:06:22
query3_2 = '''
SELECT c.cID, c.cName FROM customer c, shoppinglist s, purchase p WHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.date AND s.date like %2018%
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 11:06:45
query3_2 = '''
SELECT c.cID, c.cName FROM customer c, shoppinglist s, purchase p WHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.date AND s.date like '%2018%''
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 11:06:50
query3_2 = '''
SELECT c.cID, c.cName FROM customer c, shoppinglist s, purchase p WHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.date AND s.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID cName
#[Out]# 0      1   Sem
#[Out]# 1      1   Sem
#[Out]# 2      1   Sem
#[Out]# 3      1   Sem
#[Out]# 4      1   Sem
#[Out]# ..   ...   ...
#[Out]# 971  181  Liva
#[Out]# 972  181  Liva
#[Out]# 973  181  Liva
#[Out]# 974  181  Liva
#[Out]# 975  181  Liva
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Mon, 30 Nov 2020 11:07:01
query3_2 = '''
SELECT c.cID, c.cName, s.date FROM customer c, shoppinglist s, purchase p WHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.date AND s.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID cName        date
#[Out]# 0      1   Sem  2018-08-20
#[Out]# 1      1   Sem  2018-08-20
#[Out]# 2      1   Sem  2018-08-20
#[Out]# 3      1   Sem  2018-08-20
#[Out]# 4      1   Sem  2018-08-20
#[Out]# ..   ...   ...         ...
#[Out]# 971  181  Liva  2018-08-24
#[Out]# 972  181  Liva  2018-08-24
#[Out]# 973  181  Liva  2018-08-24
#[Out]# 974  181  Liva  2018-08-27
#[Out]# 975  181  Liva  2018-08-27
#[Out]# 
#[Out]# [976 rows x 3 columns]
# Mon, 30 Nov 2020 11:07:28
query3_2 = '''
SELECT DISTINCT c.cID, c.cName, s.date FROM customer c, shoppinglist s, purchase p WHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.date AND s.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date
#[Out]# 0      1    Sem  2018-08-20
#[Out]# 1      1    Sem  2018-08-21
#[Out]# 2      2  Lucas  2018-08-16
#[Out]# 3      2  Lucas  2018-08-17
#[Out]# 4      3   Finn  2018-08-18
#[Out]# ..   ...    ...         ...
#[Out]# 181  179   Juul  2018-08-22
#[Out]# 182  180  Merel  2018-08-26
#[Out]# 183  180  Merel  2018-08-27
#[Out]# 184  181   Liva  2018-08-24
#[Out]# 185  181   Liva  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Mon, 30 Nov 2020 11:08:11
query3_2 = '''
SELECT DISTINCT c.cID, c.cName, s.date, p.date FROM customer c, shoppinglist s, purchase p WHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.date AND s.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date        date
#[Out]# 0      1    Sem  2018-08-20  2018-08-20
#[Out]# 1      1    Sem  2018-08-21  2018-08-21
#[Out]# 2      2  Lucas  2018-08-16  2018-08-16
#[Out]# 3      2  Lucas  2018-08-17  2018-08-17
#[Out]# 4      3   Finn  2018-08-18  2018-08-18
#[Out]# ..   ...    ...         ...         ...
#[Out]# 181  179   Juul  2018-08-22  2018-08-22
#[Out]# 182  180  Merel  2018-08-26  2018-08-26
#[Out]# 183  180  Merel  2018-08-27  2018-08-27
#[Out]# 184  181   Liva  2018-08-24  2018-08-24
#[Out]# 185  181   Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [186 rows x 4 columns]
# Mon, 30 Nov 2020 11:08:35
query3_2 = '''
SELECT DISTINCT c.cID, c.cName FROM customer c, shoppinglist s, purchase p WHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.date AND s.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 11:11:37
query3_2 = '''
SELECT DISTINCT c.cID, c.cName 
FROM customer c, shoppinglist s, purchase p 
WHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.date AND s.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 11:14:11
query3_2 = '''
SELECT DISTINCT c.cID, c.cName 
FROM customer c, shoppinglist sl, purchase p 
WHERE c.cID=sl.cID AND c.cID=p.cID AND sl.date=p.date AND sl.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 11:14:57
query3_3 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName='Kumar' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, sName]
#[Out]# Index: []
# Mon, 30 Nov 2020 11:15:07
query3_3 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName!='Kumar' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID        sName
#[Out]# 0      Noah    0       Sligro
#[Out]# 1       Sem    1         Dirk
#[Out]# 2       Sem    1       Sligro
#[Out]# 3       Sem    1    Hoogvliet
#[Out]# 4       Sem    1  Albert Hein
#[Out]# ..      ...  ...          ...
#[Out]# 504  Kostas  190        Jumbo
#[Out]# 505  Kostas  190         Lidl
#[Out]# 506  Kostas  190         Lidl
#[Out]# 507  Kostas  190        Jumbo
#[Out]# 508  Kostas  190        Jumbo
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Mon, 30 Nov 2020 11:17:09
query3_3 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName!='Jumbo' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID        sName
#[Out]# 0      Noah    0       Sligro
#[Out]# 1       Sem    1         Dirk
#[Out]# 2       Sem    1       Sligro
#[Out]# 3       Sem    1    Hoogvliet
#[Out]# 4       Sem    1  Albert Hein
#[Out]# ..      ...  ...          ...
#[Out]# 459  Kostas  190         Coop
#[Out]# 460  Kostas  190         Dirk
#[Out]# 461  Kostas  190         Dirk
#[Out]# 462  Kostas  190         Lidl
#[Out]# 463  Kostas  190         Lidl
#[Out]# 
#[Out]# [464 rows x 3 columns]
# Mon, 30 Nov 2020 11:17:13
query3_3 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName='Jumbo' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID  sName
#[Out]# 0       Daan    4  Jumbo
#[Out]# 1       Hugo   18  Jumbo
#[Out]# 2       Lars   19  Jumbo
#[Out]# 3       Lars   19  Jumbo
#[Out]# 4   Benjamin   21  Jumbo
#[Out]# 5       Luca   24  Jumbo
#[Out]# 6        Tim   27  Jumbo
#[Out]# 7       Guus   37  Jumbo
#[Out]# 8     Floris   38  Jumbo
#[Out]# 9       Jens   40  Jumbo
#[Out]# 10      Xavi   47  Jumbo
#[Out]# 11    Willem   52  Jumbo
#[Out]# 12      Joep   59  Jumbo
#[Out]# 13      Senn   63  Jumbo
#[Out]# 14   Mohamed   66  Jumbo
#[Out]# 15     Boris   68  Jumbo
#[Out]# 16      Dani   72  Jumbo
#[Out]# 17      Mick   78  Jumbo
#[Out]# 18    Pieter   85  Jumbo
#[Out]# 19      Stef   86  Jumbo
#[Out]# 20       Liv  104  Jumbo
#[Out]# 21      Lynn  109  Jumbo
#[Out]# 22      Yara  112  Jumbo
#[Out]# 23      Elin  122  Jumbo
#[Out]# 24      Lina  126  Jumbo
#[Out]# 25     Femke  136  Jumbo
#[Out]# 26     Hanna  165  Jumbo
#[Out]# 27    Veerle  167  Jumbo
#[Out]# 28     Tessa  171  Jumbo
#[Out]# 29      Lana  172  Jumbo
#[Out]# 30     Merel  180  Jumbo
#[Out]# 31      Nick  185  Jumbo
#[Out]# 32    Angela  186  Jumbo
#[Out]# 33      Pino  188  Jumbo
#[Out]# 34      Pino  188  Jumbo
#[Out]# 35      Koen  189  Jumbo
#[Out]# 36      Koen  189  Jumbo
#[Out]# 37    Kostas  190  Jumbo
#[Out]# 38    Kostas  190  Jumbo
#[Out]# 39    Kostas  190  Jumbo
#[Out]# 40    Kostas  190  Jumbo
#[Out]# 41    Kostas  190  Jumbo
#[Out]# 42    Kostas  190  Jumbo
#[Out]# 43    Kostas  190  Jumbo
#[Out]# 44    Kostas  190  Jumbo
# Mon, 30 Nov 2020 11:19:54
query3_3 = '''
(SELECT c.cName, c.cID, st.sName) 
EXCEPT
(SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName='Jumbo' AND p.sID=st.sID AND p.cID=c.cID)
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 11:20:16
query3_3 = '''
(SELECT c.cName, c.cID, st.sName 
FROM customer c, store st) 
EXCEPT
(SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName='Jumbo' AND p.sID=st.sID AND p.cID=c.cID)
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 11:20:33
query3_3 = '''
(SELECT c.cName, c.cID, st.sName 
FROM customer c, store st)
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 11:20:44
query3_3 = '''
(SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName='Jumbo' AND p.sID=st.sID AND p.cID=c.cID)
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 11:20:58
query3_3 = '''
SELECT c.cName, c.cID, st.sName 
FROM customer c, store st
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName='Jumbo' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cName  cID        sName
#[Out]# 0     Abel   62  Albert Hein
#[Out]# 1     Abel   62         Coop
#[Out]# 2     Abel   62         Dirk
#[Out]# 3     Abel   62    Hoogvliet
#[Out]# 4     Abel   62        Jumbo
#[Out]# ...    ...  ...          ...
#[Out]# 1290  Yara  112         Coop
#[Out]# 1291  Yara  112         Dirk
#[Out]# 1292  Yara  112    Hoogvliet
#[Out]# 1293  Yara  112         Lidl
#[Out]# 1294  Yara  112       Sligro
#[Out]# 
#[Out]# [1295 rows x 3 columns]
# Mon, 30 Nov 2020 11:21:09
query3_3 = '''
SELECT c.cName, c.cID, st.sName 
FROM customer c, store st
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName!='Jumbo' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cName  cID        sName
#[Out]# 0     Abel   62  Albert Hein
#[Out]# 1     Abel   62         Coop
#[Out]# 2     Abel   62         Dirk
#[Out]# 3     Abel   62    Hoogvliet
#[Out]# 4     Abel   62        Jumbo
#[Out]# ...    ...  ...          ...
#[Out]# 1026  Yara  112  Albert Hein
#[Out]# 1027  Yara  112         Dirk
#[Out]# 1028  Yara  112    Hoogvliet
#[Out]# 1029  Yara  112        Jumbo
#[Out]# 1030  Yara  112       Sligro
#[Out]# 
#[Out]# [1031 rows x 3 columns]
# Mon, 30 Nov 2020 11:21:26
query3_3 = '''
SELECT c.cName, c.cID, st.sName 
FROM customer c, store st
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, purchase p, store st
WHERE st.sName='Jumbo' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cName  cID        sName
#[Out]# 0     Abel   62  Albert Hein
#[Out]# 1     Abel   62         Coop
#[Out]# 2     Abel   62         Dirk
#[Out]# 3     Abel   62    Hoogvliet
#[Out]# 4     Abel   62        Jumbo
#[Out]# ...    ...  ...          ...
#[Out]# 1290  Yara  112         Coop
#[Out]# 1291  Yara  112         Dirk
#[Out]# 1292  Yara  112    Hoogvliet
#[Out]# 1293  Yara  112         Lidl
#[Out]# 1294  Yara  112       Sligro
#[Out]# 
#[Out]# [1295 rows x 3 columns]
# Mon, 30 Nov 2020 11:21:40
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c, store st
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Jumbo' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 11:22:25
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Jumbo' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 11:22:56
query3_3 = '''
SELECT DISTINCT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Jumbo' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 11:25:17
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Kumar' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 11:25:52
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Albert Hein' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 138      Vince   32
#[Out]# 139      Wilko  184
#[Out]# 140     Willem   52
#[Out]# 141       Xavi   47
#[Out]# 142       Yara  112
#[Out]# 
#[Out]# [143 rows x 2 columns]
# Mon, 30 Nov 2020 11:26:01
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Coop' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Abel   62
#[Out]# 1      Adam   12
#[Out]# 2     Amber  153
#[Out]# 3    Angela  186
#[Out]# 4    Benthe  154
#[Out]# ..      ...  ...
#[Out]# 111  Veerle  167
#[Out]# 112    Vera  140
#[Out]# 113   Vince   32
#[Out]# 114  Willem   52
#[Out]# 115    Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Mon, 30 Nov 2020 11:26:06
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Kumar' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 11:26:14
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Abel   62
#[Out]# 1       Adam   12
#[Out]# 2      Amber  153
#[Out]# 3     Benthe  154
#[Out]# 4         Bo  142
#[Out]# 5       Boaz   36
#[Out]# 6        Cas   49
#[Out]# 7        Eva  101
#[Out]# 8        Evi  102
#[Out]# 9        Evy  164
#[Out]# 10     Fedde   46
#[Out]# 11     Fleur  106
#[Out]# 12    Hannah  132
#[Out]# 13       Isa  121
#[Out]# 14  Isabella  148
#[Out]# 15       Jan   23
#[Out]# 16       Jax   54
#[Out]# 17     Jelle   87
#[Out]# 18       Job   53
#[Out]# 19  Johannes   89
#[Out]# 20    Joshua   79
#[Out]# 21     Julia   98
#[Out]# 22     Julie  150
#[Out]# 23      Lara  160
#[Out]# 24     Linde  155
#[Out]# 25     Livia  173
#[Out]# 26      Luna  156
#[Out]# 27     Maria  138
#[Out]# 28      Maud  114
#[Out]# 29       Max   14
#[Out]# 30     Melle   83
#[Out]# 31       Mia  141
#[Out]# 32     Milan    6
#[Out]# 33    Morris   61
#[Out]# 34     Naomi  143
#[Out]# 35     Nikki  183
#[Out]# 36       Noa  125
#[Out]# 37      Nora  105
#[Out]# 38     Norah  146
#[Out]# 39      Nova  115
#[Out]# 40    Olivia  107
#[Out]# 41     Oscar   93
#[Out]# 42      Owen   73
#[Out]# 43    Pepijn   65
#[Out]# 44       Pim   50
#[Out]# 45      Romy  174
#[Out]# 46      Roos  117
#[Out]# 47      Rosa  158
#[Out]# 48   Rosalie  166
#[Out]# 49    Samuel   74
#[Out]# 50     Sanne  130
#[Out]# 51     Sarah  120
#[Out]# 52     Simon   81
#[Out]# 53    Thomas    9
#[Out]# 54    Tobias   56
#[Out]# 55      Tygo   48
#[Out]# 56      Vera  140
#[Out]# 57     Vince   32
# Mon, 30 Nov 2020 11:26:39
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Kumar' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 11:26:53
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Kumaruu' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 11:26:57
query3_3 = '''
SELECT c.cName, c.cID
FROM customer c
EXCEPT
SELECT c.cName, c.cID
FROM customer c, purchase p, store st
WHERE st.sName='Kumar' AND p.sID=st.sID AND p.cID=c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 11:31:00
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID  sName
#[Out]# 0       Daan    4  Jumbo
#[Out]# 1       Hugo   18  Jumbo
#[Out]# 2       Lars   19  Jumbo
#[Out]# 3       Lars   19  Jumbo
#[Out]# 4   Benjamin   21  Jumbo
#[Out]# 5       Luca   24  Jumbo
#[Out]# 6        Tim   27  Jumbo
#[Out]# 7       Guus   37  Jumbo
#[Out]# 8     Floris   38  Jumbo
#[Out]# 9       Jens   40  Jumbo
#[Out]# 10      Xavi   47  Jumbo
#[Out]# 11    Willem   52  Jumbo
#[Out]# 12      Joep   59  Jumbo
#[Out]# 13      Senn   63  Jumbo
#[Out]# 14   Mohamed   66  Jumbo
#[Out]# 15     Boris   68  Jumbo
#[Out]# 16      Dani   72  Jumbo
#[Out]# 17      Mick   78  Jumbo
#[Out]# 18    Pieter   85  Jumbo
#[Out]# 19      Stef   86  Jumbo
#[Out]# 20       Liv  104  Jumbo
#[Out]# 21      Lynn  109  Jumbo
#[Out]# 22      Yara  112  Jumbo
#[Out]# 23      Elin  122  Jumbo
#[Out]# 24      Lina  126  Jumbo
#[Out]# 25     Femke  136  Jumbo
#[Out]# 26     Hanna  165  Jumbo
#[Out]# 27    Veerle  167  Jumbo
#[Out]# 28     Tessa  171  Jumbo
#[Out]# 29      Lana  172  Jumbo
#[Out]# 30     Merel  180  Jumbo
#[Out]# 31      Nick  185  Jumbo
#[Out]# 32    Angela  186  Jumbo
#[Out]# 33      Pino  188  Jumbo
#[Out]# 34      Pino  188  Jumbo
#[Out]# 35      Koen  189  Jumbo
#[Out]# 36      Koen  189  Jumbo
#[Out]# 37    Kostas  190  Jumbo
#[Out]# 38    Kostas  190  Jumbo
#[Out]# 39    Kostas  190  Jumbo
#[Out]# 40    Kostas  190  Jumbo
#[Out]# 41    Kostas  190  Jumbo
#[Out]# 42    Kostas  190  Jumbo
#[Out]# 43    Kostas  190  Jumbo
#[Out]# 44    Kostas  190  Jumbo
# Mon, 30 Nov 2020 11:31:22
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#       cName  cID        sName
#[Out]# 0      Noah    0       Sligro
#[Out]# 1       Sem    1         Dirk
#[Out]# 2       Sem    1       Sligro
#[Out]# 3       Sem    1    Hoogvliet
#[Out]# 4       Sem    1  Albert Hein
#[Out]# ..      ...  ...          ...
#[Out]# 459  Kostas  190         Coop
#[Out]# 460  Kostas  190         Dirk
#[Out]# 461  Kostas  190         Dirk
#[Out]# 462  Kostas  190         Lidl
#[Out]# 463  Kostas  190         Lidl
#[Out]# 
#[Out]# [464 rows x 3 columns]
# Mon, 30 Nov 2020 11:33:22
# Customers who made at least one purhase minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID

EXCEPT

SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID        sName
#[Out]# 0    Aiden   55  Albert Hein
#[Out]# 1    Aiden   55         Dirk
#[Out]# 2    Aiden   55    Hoogvliet
#[Out]# 3    Aiden   55        Jumbo
#[Out]# 4    Aiden   55         Lidl
#[Out]# ..     ...  ...          ...
#[Out]# 620   Yara  112  Albert Hein
#[Out]# 621   Yara  112         Dirk
#[Out]# 622   Yara  112    Hoogvliet
#[Out]# 623   Yara  112        Jumbo
#[Out]# 624   Yara  112       Sligro
#[Out]# 
#[Out]# [625 rows x 3 columns]
# Mon, 30 Nov 2020 11:33:29
# Customers who made at least one purhase minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID

EXCEPT

SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID        sName
#[Out]# 0    Aiden   55  Albert Hein
#[Out]# 1    Aiden   55         Coop
#[Out]# 2    Aiden   55         Dirk
#[Out]# 3    Aiden   55    Hoogvliet
#[Out]# 4    Aiden   55        Jumbo
#[Out]# ..     ...  ...          ...
#[Out]# 884   Yara  112         Coop
#[Out]# 885   Yara  112         Dirk
#[Out]# 886   Yara  112    Hoogvliet
#[Out]# 887   Yara  112         Lidl
#[Out]# 888   Yara  112       Sligro
#[Out]# 
#[Out]# [889 rows x 3 columns]
# Mon, 30 Nov 2020 11:33:34
# Customers who made at least one purhase minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID

EXCEPT

SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID        sName
#[Out]# 0    Aiden   55  Albert Hein
#[Out]# 1    Aiden   55         Coop
#[Out]# 2    Aiden   55         Dirk
#[Out]# 3    Aiden   55    Hoogvliet
#[Out]# 4    Aiden   55        Jumbo
#[Out]# ..     ...  ...          ...
#[Out]# 884   Yara  112         Coop
#[Out]# 885   Yara  112         Dirk
#[Out]# 886   Yara  112    Hoogvliet
#[Out]# 887   Yara  112         Lidl
#[Out]# 888   Yara  112       Sligro
#[Out]# 
#[Out]# [889 rows x 3 columns]
# Mon, 30 Nov 2020 11:33:47
# Customers who made at least one purhase minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID        sName
#[Out]# 0    Aiden   55  Albert Hein
#[Out]# 1    Aiden   55         Coop
#[Out]# 2    Aiden   55         Dirk
#[Out]# 3    Aiden   55    Hoogvliet
#[Out]# 4    Aiden   55        Jumbo
#[Out]# ..     ...  ...          ...
#[Out]# 884   Yara  112         Coop
#[Out]# 885   Yara  112         Dirk
#[Out]# 886   Yara  112    Hoogvliet
#[Out]# 887   Yara  112         Lidl
#[Out]# 888   Yara  112       Sligro
#[Out]# 
#[Out]# [889 rows x 3 columns]
# Mon, 30 Nov 2020 11:34:44
# Customers who made at least one purhase minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND st.sName='Kumar'
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, sName]
#[Out]# Index: []
# Mon, 30 Nov 2020 11:34:50
# Customers who made at least one purhase minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND st.sName='Jumbo'
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID  sName
#[Out]# 0       Aiden   55  Jumbo
#[Out]# 1   Alexander   76  Jumbo
#[Out]# 2       Amira  176  Jumbo
#[Out]# 3         Amy  131  Jumbo
#[Out]# 4        Anna   99  Jumbo
#[Out]# ..        ...  ...    ...
#[Out]# 92      Thijs   11  Jumbo
#[Out]# 93       Ties   51  Jumbo
#[Out]# 94       Tijn   42  Jumbo
#[Out]# 95        Tom   43  Jumbo
#[Out]# 96      Wilko  184  Jumbo
#[Out]# 
#[Out]# [97 rows x 3 columns]
# Mon, 30 Nov 2020 11:35:15
# Customers who made at least one purhase minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND st.sName='Jumbo' AND p.sID=st.sID
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, sName]
#[Out]# Index: []
# Mon, 30 Nov 2020 11:35:27
# Customers who made at least one purhase minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND st.sName='Jumbo' AND p.sID=st.sID
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID  sName
#[Out]# 0     Angela  186  Jumbo
#[Out]# 1   Benjamin   21  Jumbo
#[Out]# 2      Boris   68  Jumbo
#[Out]# 3       Daan    4  Jumbo
#[Out]# 4       Dani   72  Jumbo
#[Out]# 5       Elin  122  Jumbo
#[Out]# 6      Femke  136  Jumbo
#[Out]# 7     Floris   38  Jumbo
#[Out]# 8       Guus   37  Jumbo
#[Out]# 9      Hanna  165  Jumbo
#[Out]# 10      Hugo   18  Jumbo
#[Out]# 11      Jens   40  Jumbo
#[Out]# 12      Joep   59  Jumbo
#[Out]# 13      Koen  189  Jumbo
#[Out]# 14    Kostas  190  Jumbo
#[Out]# 15      Lana  172  Jumbo
#[Out]# 16      Lars   19  Jumbo
#[Out]# 17      Lina  126  Jumbo
#[Out]# 18       Liv  104  Jumbo
#[Out]# 19      Luca   24  Jumbo
#[Out]# 20      Lynn  109  Jumbo
#[Out]# 21     Merel  180  Jumbo
#[Out]# 22      Mick   78  Jumbo
#[Out]# 23   Mohamed   66  Jumbo
#[Out]# 24      Nick  185  Jumbo
#[Out]# 25    Pieter   85  Jumbo
#[Out]# 26      Pino  188  Jumbo
#[Out]# 27      Senn   63  Jumbo
#[Out]# 28      Stef   86  Jumbo
#[Out]# 29     Tessa  171  Jumbo
#[Out]# 30       Tim   27  Jumbo
#[Out]# 31    Veerle  167  Jumbo
#[Out]# 32    Willem   52  Jumbo
#[Out]# 33      Xavi   47  Jumbo
#[Out]# 34      Yara  112  Jumbo
# Mon, 30 Nov 2020 11:37:24
# Customers who only shop at Kumar
# Customers who made at least one purhase at Kumar minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID  sName
#[Out]# 0     Angela  186  Jumbo
#[Out]# 1   Benjamin   21  Jumbo
#[Out]# 2      Boris   68  Jumbo
#[Out]# 3       Daan    4  Jumbo
#[Out]# 4       Dani   72  Jumbo
#[Out]# 5       Elin  122  Jumbo
#[Out]# 6      Femke  136  Jumbo
#[Out]# 7     Floris   38  Jumbo
#[Out]# 8       Guus   37  Jumbo
#[Out]# 9      Hanna  165  Jumbo
#[Out]# 10      Hugo   18  Jumbo
#[Out]# 11      Jens   40  Jumbo
#[Out]# 12      Joep   59  Jumbo
#[Out]# 13      Koen  189  Jumbo
#[Out]# 14    Kostas  190  Jumbo
#[Out]# 15      Lana  172  Jumbo
#[Out]# 16      Lars   19  Jumbo
#[Out]# 17      Lina  126  Jumbo
#[Out]# 18       Liv  104  Jumbo
#[Out]# 19      Luca   24  Jumbo
#[Out]# 20      Lynn  109  Jumbo
#[Out]# 21     Merel  180  Jumbo
#[Out]# 22      Mick   78  Jumbo
#[Out]# 23   Mohamed   66  Jumbo
#[Out]# 24      Nick  185  Jumbo
#[Out]# 25    Pieter   85  Jumbo
#[Out]# 26      Pino  188  Jumbo
#[Out]# 27      Senn   63  Jumbo
#[Out]# 28      Stef   86  Jumbo
#[Out]# 29     Tessa  171  Jumbo
#[Out]# 30       Tim   27  Jumbo
#[Out]# 31    Veerle  167  Jumbo
#[Out]# 32    Willem   52  Jumbo
#[Out]# 33      Xavi   47  Jumbo
#[Out]# 34      Yara  112  Jumbo
# Mon, 30 Nov 2020 11:37:44
# Customers who only shop at Kumar
# Customers who made at least one purhase at Kumar minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Jumbo'
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID  sName
#[Out]# 0     Angela  186  Jumbo
#[Out]# 1   Benjamin   21  Jumbo
#[Out]# 2      Boris   68  Jumbo
#[Out]# 3       Daan    4  Jumbo
#[Out]# 4       Dani   72  Jumbo
#[Out]# 5       Elin  122  Jumbo
#[Out]# 6      Femke  136  Jumbo
#[Out]# 7     Floris   38  Jumbo
#[Out]# 8       Guus   37  Jumbo
#[Out]# 9      Hanna  165  Jumbo
#[Out]# 10      Hugo   18  Jumbo
#[Out]# 11      Jens   40  Jumbo
#[Out]# 12      Joep   59  Jumbo
#[Out]# 13      Koen  189  Jumbo
#[Out]# 14    Kostas  190  Jumbo
#[Out]# 15      Lana  172  Jumbo
#[Out]# 16      Lars   19  Jumbo
#[Out]# 17      Lina  126  Jumbo
#[Out]# 18       Liv  104  Jumbo
#[Out]# 19      Luca   24  Jumbo
#[Out]# 20      Lynn  109  Jumbo
#[Out]# 21     Merel  180  Jumbo
#[Out]# 22      Mick   78  Jumbo
#[Out]# 23   Mohamed   66  Jumbo
#[Out]# 24      Nick  185  Jumbo
#[Out]# 25    Pieter   85  Jumbo
#[Out]# 26      Pino  188  Jumbo
#[Out]# 27      Senn   63  Jumbo
#[Out]# 28      Stef   86  Jumbo
#[Out]# 29     Tessa  171  Jumbo
#[Out]# 30       Tim   27  Jumbo
#[Out]# 31    Veerle  167  Jumbo
#[Out]# 32    Willem   52  Jumbo
#[Out]# 33      Xavi   47  Jumbo
#[Out]# 34      Yara  112  Jumbo
# Mon, 30 Nov 2020 11:38:08
# Customers who only shop at Kumar
# Customers who made at least one purhase at Kumar minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Coop'
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID sName
#[Out]# 0       Aiden   55  Coop
#[Out]# 1   Alexander   76  Coop
#[Out]# 2       Amira  176  Coop
#[Out]# 3         Amy  131  Coop
#[Out]# 4        Anna   99  Coop
#[Out]# ..        ...  ...   ...
#[Out]# 69       Ties   51  Coop
#[Out]# 70       Tijn   42  Coop
#[Out]# 71        Tim   27  Coop
#[Out]# 72      Wilko  184  Coop
#[Out]# 73       Yara  112  Coop
#[Out]# 
#[Out]# [74 rows x 3 columns]
# Mon, 30 Nov 2020 11:38:19
# Customers who only shop at Kumar
# Customers who made at least one purhase at Kumar minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID 
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID        sName
#[Out]# 0    Aiden   55  Albert Hein
#[Out]# 1    Aiden   55         Coop
#[Out]# 2    Aiden   55         Dirk
#[Out]# 3    Aiden   55    Hoogvliet
#[Out]# 4    Aiden   55        Jumbo
#[Out]# ..     ...  ...          ...
#[Out]# 659   Yara  112  Albert Hein
#[Out]# 660   Yara  112         Coop
#[Out]# 661   Yara  112         Dirk
#[Out]# 662   Yara  112    Hoogvliet
#[Out]# 663   Yara  112       Sligro
#[Out]# 
#[Out]# [664 rows x 3 columns]
# Mon, 30 Nov 2020 11:38:40
# Customers who only shop at Kumar
# Customers who made at least one purhase at Kumar minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Coop'
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID sName
#[Out]# 0       Aiden   55  Coop
#[Out]# 1   Alexander   76  Coop
#[Out]# 2       Amira  176  Coop
#[Out]# 3         Amy  131  Coop
#[Out]# 4        Anna   99  Coop
#[Out]# ..        ...  ...   ...
#[Out]# 69       Ties   51  Coop
#[Out]# 70       Tijn   42  Coop
#[Out]# 71        Tim   27  Coop
#[Out]# 72      Wilko  184  Coop
#[Out]# 73       Yara  112  Coop
#[Out]# 
#[Out]# [74 rows x 3 columns]
# Mon, 30 Nov 2020 11:38:46
# Customers who only shop at Kumar
# Customers who made at least one purhase at Kumar minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Coop'
EXCEPT
SELECT c.cName, c.cID, st.sName
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Coop'
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 11:38:53
# Customers who only shop at Kumar
# Customers who made at least one purhase at Kumar minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Coop'
EXCEPT
SELECT c.cName, c.cID
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0       Aiden   55
#[Out]# 1   Alexander   76
#[Out]# 2         Amy  131
#[Out]# 3        Anna   99
#[Out]# 4      Jayden   26
#[Out]# 5        Jill  151
#[Out]# 6       Joris   88
#[Out]# 7        Liam    8
#[Out]# 8       Lotte  103
#[Out]# 9         Sam   10
#[Out]# 10       Siem   28
#[Out]# 11      Sofia  135
#[Out]# 12      Thijs   11
#[Out]# 13      Wilko  184
# Mon, 30 Nov 2020 11:40:12
# Customers who only shop at Kumar
# Customers who made at least one purhase at Kumar minus all customers that made a purchase at a different store than Kumar
query3_4 = '''
SELECT c.cName, c.cID
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName='Kumar'
EXCEPT
SELECT c.cName, c.cID
FROM customer c, store st, purchase p
WHERE p.cID=c.cID AND p.sID=st.sID AND st.sName!='Kumar'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []


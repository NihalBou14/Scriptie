# IPython log file

# Fri, 27 Nov 2020 11:14:55
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Fri, 27 Nov 2020 11:14:56
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1b653e2f810>

# IPython log file

# Fri, 27 Nov 2020 11:17:36
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Fri, 27 Nov 2020 11:17:36
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Fri, 27 Nov 2020 11:19:11
query3_2 = '''
    SELECT cid FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Fri, 27 Nov 2020 11:21:22
query3_2 = '''
    SELECT cid from purchase, shoppinglist WHERE purchase.cid = shoppinglist.cid AND 
    purchase.date = shoppinglist.date AND shoppinglist.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:21:32
query3_2 = '''
    SELECT purchase.cid from purchase, shoppinglist WHERE purchase.cid = shoppinglist.cid AND 
    purchase.date = shoppinglist.date AND shoppinglist.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:21:59
query3_2 = '''
    SELECT from purchase, shoppinglist WHERE purchase UNION shoppinglist AND 
    purchase.date = shoppinglist.date AND shoppinglist.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:22:11
query3_2 = '''
    SELECT cid from purchase, shoppinglist WHERE purchase UNION shoppinglist AND 
    purchase.date = shoppinglist.date AND shoppinglist.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:24:11
query3_2 = '''
    SELECT cid, cname FROM customer UNION purchase UNION shoppinglist where shoppinglist.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:24:24
query3_2 = '''
    SELECT cid, cname FROM customer UNION purchase UNION shoppinglist where shoppinglist.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:24:54
query3_2 = '''
    SELECT cid, cname FROM customer UNION SELECT purchase UNION SELECT shoppinglist where shoppinglist.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:25:09
query3_2 = '''
    SELECT cid, cname FROM customer UNION SELECT purchase UNION SELECT shoppinglist where shoppinglist.date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:25:19
query3_2 = '''
    SELECT cid, cname FROM customer UNION SELECT purchase UNION SELECT shoppinglist WHERE date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:27:19
query3_2 = '''
    SELECT customer.cid, cname FROM customer, purchase, shoppinglist WHERE customer.cid = shoppinglist.cid AND 
    customer.cid = purchase.cid AND purchase.date = shoppinglist.date AND shoppinglist.date = '%2018' 
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:30:17
query3_2 = '''
    SELECT customer.cid, cname FROM customer, purchase, shoppinglist WHERE customer.cid = shoppinglist.cid AND 
    customer.cid = purchase.cid AND purchase.date = shoppinglist.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID cName
#[Out]# 0      1   Sem
#[Out]# 1      1   Sem
#[Out]# 2      1   Sem
#[Out]# 3      1   Sem
#[Out]# 4      1   Sem
#[Out]# ..   ...   ...
#[Out]# 971  181  Liva
#[Out]# 972  181  Liva
#[Out]# 973  181  Liva
#[Out]# 974  181  Liva
#[Out]# 975  181  Liva
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Fri, 27 Nov 2020 11:31:03
query3_2 = '''
    SELECT customer.cid, cname FROM customer, purchase, shoppinglist WHERE customer.cid = shoppinglist.cid = purchase.cid 
    AND purchase.date = shoppinglist.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID   cName
#[Out]# 0       0    Noah
#[Out]# 1       0    Noah
#[Out]# 2       0    Noah
#[Out]# 3       0    Noah
#[Out]# 4       0    Noah
#[Out]# ...   ...     ...
#[Out]# 6864  190  Kostas
#[Out]# 6865  190  Kostas
#[Out]# 6866  190  Kostas
#[Out]# 6867  190  Kostas
#[Out]# 6868  190  Kostas
#[Out]# 
#[Out]# [6869 rows x 2 columns]
# Fri, 27 Nov 2020 11:31:59
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN purchase JOIN shoppinglist WHERE date = '%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:32:23
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN purchase JOIN shoppinglist WHERE 
    shoppinglist.date ='%2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:32:35
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN purchase JOIN shoppinglist
'''

pd.read_sql_query(query3_2, conn)

# IPython log file

# Fri, 27 Nov 2020 11:35:14
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Fri, 27 Nov 2020 11:35:14
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Fri, 27 Nov 2020 11:35:20
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN purchase JOIN shoppinglist WHERE 
    shoppinglist.date ='%2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:35:38
query3_2 = '''
    SELECT customer.cid, cname FROM customer RIGHT JOIN purchase INNER JOIN shoppinglist WHERE 
    shoppinglist.date ='%2018'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:35:52
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN purchase INNER JOIN shoppinglist WHERE 
    shoppinglist.date ='%2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:36:03
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN (purchase JOIN shoppinglist WHERE 
    shoppinglist.date ='%2018')
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:36:16
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN ( purchase JOIN shoppinglist WHERE 
    shoppinglist.date ='%2018' )
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:36:44
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN ( purchase JOIN shoppinglist WHERE 
    shoppinglist.date ='%2018' )
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:37:35
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN purchase JOIN shoppinglist WHERE 
    shoppinglist.date ='%2018' 
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:37:51
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN purchase WHERE 
    purchase.date ='%2018' 
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:38:04
query3_2 = '''
    SELECT customer.cid, cname FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 11:38:11
query3_2 = '''
    SELECT customer.cid, cname FROM customer JOIN purchase
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID   cName
#[Out]# 0        0    Noah
#[Out]# 1        0    Noah
#[Out]# 2        0    Noah
#[Out]# 3        0    Noah
#[Out]# 4        0    Noah
#[Out]# ...    ...     ...
#[Out]# 96705  190  Kostas
#[Out]# 96706  190  Kostas
#[Out]# 96707  190  Kostas
#[Out]# 96708  190  Kostas
#[Out]# 96709  190  Kostas
#[Out]# 
#[Out]# [96710 rows x 2 columns]
# Fri, 27 Nov 2020 11:38:23
query3_2 = '''
    SELECT customer.cid, cname FROM customer INNER JOIN purchase
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID   cName
#[Out]# 0        0    Noah
#[Out]# 1        0    Noah
#[Out]# 2        0    Noah
#[Out]# 3        0    Noah
#[Out]# 4        0    Noah
#[Out]# ...    ...     ...
#[Out]# 96705  190  Kostas
#[Out]# 96706  190  Kostas
#[Out]# 96707  190  Kostas
#[Out]# 96708  190  Kostas
#[Out]# 96709  190  Kostas
#[Out]# 
#[Out]# [96710 rows x 2 columns]
# Fri, 27 Nov 2020 11:38:38
query3_2 = '''
    SELECT customer.cid, cname, date FROM customer INNER JOIN purchase
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID   cName        date
#[Out]# 0        0    Noah  2018-08-22
#[Out]# 1        0    Noah  2018-08-20
#[Out]# 2        0    Noah  2018-08-20
#[Out]# 3        0    Noah  2018-08-20
#[Out]# 4        0    Noah  2018-08-20
#[Out]# ...    ...     ...         ...
#[Out]# 96705  190  Kostas  2018-08-26
#[Out]# 96706  190  Kostas  2018-08-27
#[Out]# 96707  190  Kostas  2018-08-23
#[Out]# 96708  190  Kostas  2018-08-16
#[Out]# 96709  190  Kostas  2018-08-21
#[Out]# 
#[Out]# [96710 rows x 3 columns]
# Fri, 27 Nov 2020 11:39:30
query3_3 = '''
    SELECT date FROM shoppinglist WHERE shoppinglist.date = '%2018'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [date]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:39:35
query3_3 = '''
    SELECT date FROM shoppinglist WHERE shoppinglist.date = '% 2018'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [date]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:39:54
query3_3 = '''
    SELECT date FROM shoppinglist WHERE shoppinglist.date = '2018%'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [date]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:40:09
query3_3 = '''
    SELECT date FROM purchase WHERE date = '2018%'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [date]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:40:30
query3_3 = '''
    SELECT date FROM purchase WHERE date = '2018______'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [date]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:41:13
query3_2 = '''
    SELECT customer.cid, cname, date FROM customer INNER JOIN purchase INNER JOIN shoppinglist WHERE 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:41:39
query3_2 = '''
    SELECT customer.cid, cname, shoppinglist.date FROM customer INNER JOIN purchase INNER JOIN shoppinglist WHERE 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)

# IPython log file

# Fri, 27 Nov 2020 11:43:15
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Fri, 27 Nov 2020 11:43:15
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Fri, 27 Nov 2020 11:43:19
query3_2 = '''
    SELECT customer.cid, cname, shoppinglist.date FROM customer INNER JOIN purchase INNER JOIN shoppinglist WHERE 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)

# IPython log file

query3_2 = '''
    SELECT customer.cid, cname, shoppinglist.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:45:48
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Fri, 27 Nov 2020 11:45:48
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Fri, 27 Nov 2020 11:45:51
query3_2 = '''
    SELECT customer.cid, cname, shoppinglist.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID   cName        date
#[Out]# 0       0    Noah  2018-08-22
#[Out]# 1       0    Noah  2018-08-22
#[Out]# 2       0    Noah  2018-08-22
#[Out]# 3       0    Noah  2018-08-22
#[Out]# 4       0    Noah  2018-08-22
#[Out]# ...   ...     ...         ...
#[Out]# 6864  190  Kostas  2018-08-22
#[Out]# 6865  190  Kostas  2018-08-22
#[Out]# 6866  190  Kostas  2018-08-22
#[Out]# 6867  190  Kostas  2018-08-22
#[Out]# 6868  190  Kostas  2018-08-22
#[Out]# 
#[Out]# [6869 rows x 3 columns]
# Fri, 27 Nov 2020 11:47:42
query3_2 = '''
    SELECT customer.cid, cname, shoppinglist.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID   cName        date
#[Out]# 0       0    Noah  2018-08-22
#[Out]# 1       0    Noah  2018-08-22
#[Out]# 2       0    Noah  2018-08-22
#[Out]# 3       0    Noah  2018-08-22
#[Out]# 4       0    Noah  2018-08-22
#[Out]# ...   ...     ...         ...
#[Out]# 6864  190  Kostas  2018-08-22
#[Out]# 6865  190  Kostas  2018-08-22
#[Out]# 6866  190  Kostas  2018-08-22
#[Out]# 6867  190  Kostas  2018-08-22
#[Out]# 6868  190  Kostas  2018-08-22
#[Out]# 
#[Out]# [6869 rows x 3 columns]
# Fri, 27 Nov 2020 11:47:58
query3_2 = '''
    SELECT DISTINCT customer.cid, cname, shoppinglist.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName        date
#[Out]# 0      0    Noah  2018-08-22
#[Out]# 1      1     Sem  2018-08-20
#[Out]# 2      1     Sem  2018-08-21
#[Out]# 3      1     Sem  2018-08-22
#[Out]# 4      2   Lucas  2018-08-22
#[Out]# ..   ...     ...         ...
#[Out]# 219  185    Nick  2018-08-22
#[Out]# 220  186  Angela  2018-08-22
#[Out]# 221  188    Pino  2018-08-22
#[Out]# 222  189    Koen  2018-08-22
#[Out]# 223  190  Kostas  2018-08-22
#[Out]# 
#[Out]# [224 rows x 3 columns]
# Fri, 27 Nov 2020 11:48:45
query3_2 = '''
    SELECT DISTINCT customer.cid, cname, shoppinglist.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID   cName        date
#[Out]# 0       0    Noah  2018-08-20
#[Out]# 1       0    Noah  2018-08-21
#[Out]# 2       0    Noah  2018-08-17
#[Out]# 3       0    Noah  2018-08-16
#[Out]# 4       0    Noah  2018-08-19
#[Out]# ...   ...     ...         ...
#[Out]# 2845  190  Kostas  2018-08-26
#[Out]# 2846  190  Kostas  2018-08-15
#[Out]# 2847  190  Kostas  2018-08-27
#[Out]# 2848  190  Kostas  2018-08-29
#[Out]# 2849  190  Kostas  2018-08-28
#[Out]# 
#[Out]# [2850 rows x 3 columns]
# Fri, 27 Nov 2020 11:48:50
query3_2 = '''
    SELECT DISTINCT customer.cid, cname, shoppinglist.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName        date
#[Out]# 0      0    Noah  2018-08-22
#[Out]# 1      1     Sem  2018-08-20
#[Out]# 2      1     Sem  2018-08-21
#[Out]# 3      1     Sem  2018-08-22
#[Out]# 4      2   Lucas  2018-08-22
#[Out]# ..   ...     ...         ...
#[Out]# 219  185    Nick  2018-08-22
#[Out]# 220  186  Angela  2018-08-22
#[Out]# 221  188    Pino  2018-08-22
#[Out]# 222  189    Koen  2018-08-22
#[Out]# 223  190  Kostas  2018-08-22
#[Out]# 
#[Out]# [224 rows x 3 columns]
# Fri, 27 Nov 2020 11:50:12
query3_3 = '''
    SELECT customer.cid, cname from customer, purchase, store WHERE customer.cid = purchase.cid AND
'''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 11:53:10
query3_3 = '''
    SELECT customer.cid, cname from customer, purchase, store WHERE customer.cid = purchase.cid AND
    purchase.sid = store.sid AND NOT store.sname = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      1     Sem
#[Out]# 3      1     Sem
#[Out]# 4      1     Sem
#[Out]# ..   ...     ...
#[Out]# 504  190  Kostas
#[Out]# 505  190  Kostas
#[Out]# 506  190  Kostas
#[Out]# 507  190  Kostas
#[Out]# 508  190  Kostas
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Fri, 27 Nov 2020 11:53:16
query3_3 = '''
    SELECT DISTINCT customer.cid, cname from customer, purchase, store WHERE customer.cid = purchase.cid AND
    purchase.sid = store.sid AND NOT store.sname = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 127  185    Nick
#[Out]# 128  186  Angela
#[Out]# 129  188    Pino
#[Out]# 130  189    Koen
#[Out]# 131  190  Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Fri, 27 Nov 2020 11:54:01
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 11:56:00
query3_2 = '''
    SELECT DISTINCT customer.cid, cname, shoppinglist.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName        date
#[Out]# 0      0    Noah  2018-08-22
#[Out]# 1      1     Sem  2018-08-20
#[Out]# 2      1     Sem  2018-08-21
#[Out]# 3      1     Sem  2018-08-22
#[Out]# 4      2   Lucas  2018-08-22
#[Out]# ..   ...     ...         ...
#[Out]# 219  185    Nick  2018-08-22
#[Out]# 220  186  Angela  2018-08-22
#[Out]# 221  188    Pino  2018-08-22
#[Out]# 222  189    Koen  2018-08-22
#[Out]# 223  190  Kostas  2018-08-22
#[Out]# 
#[Out]# [224 rows x 3 columns]
# Fri, 27 Nov 2020 11:56:19
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 11:56:37
query3_4 = '''
    SELECT cid FROM customer
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Fri, 27 Nov 2020 11:57:15
query3_2 = '''
    SELECT DISTINCT customer.cid, cname, shopping.date, purchase.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:57:27
query3_2 = '''
    SELECT DISTINCT customer.cid, cname, shoppinglist.date, purchase.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName        date        date
#[Out]# 0      0    Noah  2018-08-22  2018-08-22
#[Out]# 1      1     Sem  2018-08-20  2018-08-20
#[Out]# 2      1     Sem  2018-08-21  2018-08-21
#[Out]# 3      1     Sem  2018-08-22  2018-08-22
#[Out]# 4      2   Lucas  2018-08-22  2018-08-22
#[Out]# ..   ...     ...         ...         ...
#[Out]# 219  185    Nick  2018-08-22  2018-08-22
#[Out]# 220  186  Angela  2018-08-22  2018-08-22
#[Out]# 221  188    Pino  2018-08-22  2018-08-22
#[Out]# 222  189    Koen  2018-08-22  2018-08-22
#[Out]# 223  190  Kostas  2018-08-22  2018-08-22
#[Out]# 
#[Out]# [224 rows x 4 columns]
# Fri, 27 Nov 2020 12:00:11
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:00:24
query3_2 = '''
    SELECT DISTINCT customer.cid, cname, shoppinglist.date, purchase.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName        date        date
#[Out]# 0      0    Noah  2018-08-22  2018-08-22
#[Out]# 1      1     Sem  2018-08-20  2018-08-20
#[Out]# 2      1     Sem  2018-08-21  2018-08-21
#[Out]# 3      1     Sem  2018-08-22  2018-08-22
#[Out]# 4      2   Lucas  2018-08-22  2018-08-22
#[Out]# ..   ...     ...         ...         ...
#[Out]# 219  185    Nick  2018-08-22  2018-08-22
#[Out]# 220  186  Angela  2018-08-22  2018-08-22
#[Out]# 221  188    Pino  2018-08-22  2018-08-22
#[Out]# 222  189    Koen  2018-08-22  2018-08-22
#[Out]# 223  190  Kostas  2018-08-22  2018-08-22
#[Out]# 
#[Out]# [224 rows x 4 columns]
# Fri, 27 Nov 2020 12:00:42
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:04:42
query3_3 = '''
    SELECT DISTINCT customer.cid, cname from customer, purchase WHERE NOT customer.cid = purchase.cid'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:04:58
query3_3 = '''
    SELECT DISTINCT customer.cid, cname from customer, purchase WHERE customer.cid = purchase.cid'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 127  185    Nick
#[Out]# 128  186  Angela
#[Out]# 129  188    Pino
#[Out]# 130  189    Koen
#[Out]# 131  190  Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Fri, 27 Nov 2020 12:06:03
query3_3 = '''
    SELECT DISTINCT customer.cid, cname from customer, purchase WHERE NOT(customer.cid = purchase.cid)'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:06:15
query3_3 = '''
    SELECT DISTINCT customer.cid, cname from customer, purchase WHERE customer.cid != purchase.cid'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:06:19
query3_3 = '''
    SELECT DISTINCT customer.cid, cname from customer, purchase WHERE customer.cid = purchase.cid'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 127  185    Nick
#[Out]# 128  186  Angela
#[Out]# 129  188    Pino
#[Out]# 130  189    Koen
#[Out]# 131  190  Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Fri, 27 Nov 2020 12:07:52
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid AND customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Fri, 27 Nov 2020 12:08:16
query3_2 = '''
    SELECT DISTINCT customer.cid, cname, shoppinglist.date, purchase.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid AND customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date        date
#[Out]# 0      1    Sem  2018-08-20  2018-08-20
#[Out]# 1      1    Sem  2018-08-21  2018-08-21
#[Out]# 2      2  Lucas  2018-08-16  2018-08-16
#[Out]# 3      2  Lucas  2018-08-17  2018-08-17
#[Out]# 4      3   Finn  2018-08-18  2018-08-18
#[Out]# ..   ...    ...         ...         ...
#[Out]# 181  179   Juul  2018-08-22  2018-08-22
#[Out]# 182  180  Merel  2018-08-26  2018-08-26
#[Out]# 183  180  Merel  2018-08-27  2018-08-27
#[Out]# 184  181   Liva  2018-08-24  2018-08-24
#[Out]# 185  181   Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [186 rows x 4 columns]
# Fri, 27 Nov 2020 12:08:23
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid AND customer.cid = purchase.cid AND shoppinglist.date = purchase.date AND 
    shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Fri, 27 Nov 2020 12:09:49
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid AND customer.cid = purchase.cid AND 
    shoppinglist.date = purchase.date AND shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Fri, 27 Nov 2020 12:14:21
query3_3 = '''
    SELECT cid, cname FROM cid NOT IN (SELECT customer.cid, cname FROM customer, purchase WHERE 
    customer.cid = purchase.cid)'''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:14:36
query3_3 = '''
    SELECT cid, cname FROM cid NOT IN SELECT customer.cid, cname FROM customer, purchase WHERE 
    customer.cid = purchase.cid'''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:15:13
query3_3 = '''
    SELECT cid, cname FROM customer NOT IN SELECT customer.cid, cname FROM customer, purchase WHERE 
    customer.cid = purchase.cid'''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:16:32
query3_3 = '''
    SELECT cid, cname FROM customer NOT SELECT customer.cid, cname FROM customer, purchase WHERE 
    customer.cid = purchase.cid'''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:17:49
query3_3 = '''
    SELECT CID, Cname FROM customer, purchase '''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:18:00
query3_3 = '''
    SELECT customer.CID, Cname FROM customer, purchase '''

pd.read_sql_query(query3_3, conn)
#[Out]#        cID   cName
#[Out]# 0        0    Noah
#[Out]# 1        0    Noah
#[Out]# 2        0    Noah
#[Out]# 3        0    Noah
#[Out]# 4        0    Noah
#[Out]# ...    ...     ...
#[Out]# 96705  190  Kostas
#[Out]# 96706  190  Kostas
#[Out]# 96707  190  Kostas
#[Out]# 96708  190  Kostas
#[Out]# 96709  190  Kostas
#[Out]# 
#[Out]# [96710 rows x 2 columns]
# Fri, 27 Nov 2020 12:19:11
query3_3 = '''
    SELECT customer.CID, Cname FROM custome EXCEPT SELECT customer.cid, cname FROM customer, purchase
    WHERE customer.cid = purchase.cid'''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:19:19
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase
    WHERE customer.cid = purchase.cid'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Fri, 27 Nov 2020 12:20:10
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase
    WHERE customer.cid = purchase.cid UNION customer.cid, cname FROM customer, purchase, store WHERE'''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:25:51
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase
    WHERE customer.cid = purchase.cid UNION customer.cid, cname FROM customer, purchase, store WHERE
    customer.cid = purchase.cid AND purchase.sid = store.sid AND store.name = 'Lidl'
    '''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:26:33
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase
    WHERE customer.cid = purchase.cid 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Fri, 27 Nov 2020 12:29:39
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid AND store.sname = 'Lidl'
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      3    Finn
#[Out]# 2      4    Daan
#[Out]# 3      6   Milan
#[Out]# 4      8    Liam
#[Out]# ..   ...     ...
#[Out]# 146  184   Wilko
#[Out]# 147  185    Nick
#[Out]# 148  186  Angela
#[Out]# 149  188    Pino
#[Out]# 150  189    Koen
#[Out]# 
#[Out]# [151 rows x 2 columns]
# Fri, 27 Nov 2020 12:30:00
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Fri, 27 Nov 2020 12:30:29
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid UNION SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid AND store.sname = 'Lidl'
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID   cName
#[Out]# 0     1     Sem
#[Out]# 1     2   Lucas
#[Out]# 2     5    Levi
#[Out]# 3     6   Milan
#[Out]# 4     7    Bram
#[Out]# ..  ...     ...
#[Out]# 92  175     Sam
#[Out]# 93  176   Amira
#[Out]# 94  179    Juul
#[Out]# 95  183   Nikki
#[Out]# 96  190  Kostas
#[Out]# 
#[Out]# [97 rows x 2 columns]
# Fri, 27 Nov 2020 12:30:49
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid UNION SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid AND store.sname = 'Coop'
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      2   Lucas
#[Out]# 1      4    Daan
#[Out]# 2      5    Levi
#[Out]# 3      6   Milan
#[Out]# 4      8    Liam
#[Out]# ..   ...     ...
#[Out]# 127  180   Merel
#[Out]# 128  181    Liva
#[Out]# 129  183   Nikki
#[Out]# 130  184   Wilko
#[Out]# 131  190  Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Fri, 27 Nov 2020 12:30:52
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid UNION SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid AND store.sname = 'Lidl'
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID   cName
#[Out]# 0     1     Sem
#[Out]# 1     2   Lucas
#[Out]# 2     5    Levi
#[Out]# 3     6   Milan
#[Out]# 4     7    Bram
#[Out]# ..  ...     ...
#[Out]# 92  175     Sam
#[Out]# 93  176   Amira
#[Out]# 94  179    Juul
#[Out]# 95  183   Nikki
#[Out]# 96  190  Kostas
#[Out]# 
#[Out]# [97 rows x 2 columns]
# Fri, 27 Nov 2020 12:31:51
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid AND store.sname = 'Lidl'
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Fri, 27 Nov 2020 12:32:05
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT (SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid) EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid AND store.sname = 'Lidl'
    '''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:32:18
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid AND store.sname = 'Lidl'
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      3    Finn
#[Out]# 2      4    Daan
#[Out]# 3      6   Milan
#[Out]# 4      8    Liam
#[Out]# ..   ...     ...
#[Out]# 146  184   Wilko
#[Out]# 147  185    Nick
#[Out]# 148  186  Angela
#[Out]# 149  188    Pino
#[Out]# 150  189    Koen
#[Out]# 
#[Out]# [151 rows x 2 columns]
# Fri, 27 Nov 2020 12:32:26
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid AND store.sname = 'Lidl' EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Fri, 27 Nov 2020 12:32:43
query3_3 = '''
    SELECT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Fri, 27 Nov 2020 12:33:52
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Fri, 27 Nov 2020 12:34:15
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid AND customer.cid = purchase.cid AND 
    shoppinglist.date = purchase.date AND shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Fri, 27 Nov 2020 12:34:18
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Fri, 27 Nov 2020 12:41:23
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase, 
    store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid AND store.sname = 'Lidl' UNION
    SELECT customer.cid, cname FROM customer EXCEPT SELECT customer.cid, cname FROM customer, purchase
    WHERE purchase.cid = customer.cid
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Fri, 27 Nov 2020 12:48:28
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.name = 'Lidl'
    '''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:48:34
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = 'Lidl'
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      3    Finn
#[Out]# 2      4    Daan
#[Out]# 3      6   Milan
#[Out]# 4      8    Liam
#[Out]# ..   ...     ...
#[Out]# 146  184   Wilko
#[Out]# 147  185    Nick
#[Out]# 148  186  Angela
#[Out]# 149  188    Pino
#[Out]# 150  189    Koen
#[Out]# 
#[Out]# [151 rows x 2 columns]
# Fri, 27 Nov 2020 12:49:49
query3_3 = '''
    SELECT DISTINCT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = 'Lidl' 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     5      Levi
#[Out]# 3     7      Bram
#[Out]# 4    13     James
#[Out]# 5    16    Julian
#[Out]# 6    19      Lars
#[Out]# 7    24      Luca
#[Out]# 8    25     Mason
#[Out]# 9    33      Sven
#[Out]# 10   37      Guus
#[Out]# 11   40      Jens
#[Out]# 12   42      Tijn
#[Out]# 13   43       Tom
#[Out]# 14   51      Ties
#[Out]# 15   57    Nathan
#[Out]# 16   58     Jurre
#[Out]# 17   59      Joep
#[Out]# 18   60  Mohammed
#[Out]# 19   82     Dylan
#[Out]# 20   86      Stef
#[Out]# 21   91   Thijmen
#[Out]# 22   92     Jelte
#[Out]# 23   95      Emma
#[Out]# 24  108      Noor
#[Out]# 25  112      Yara
#[Out]# 26  123     Milou
#[Out]# 27  124     Sofie
#[Out]# 28  157      Puck
#[Out]# 29  159     Fenne
#[Out]# 30  161     Floor
#[Out]# 31  163      Cato
#[Out]# 32  165     Hanna
#[Out]# 33  169      Lily
#[Out]# 34  170      Iris
#[Out]# 35  175       Sam
#[Out]# 36  176     Amira
#[Out]# 37  179      Juul
#[Out]# 38  190    Kostas
# Fri, 27 Nov 2020 12:50:00
query3_3 = '''
    SELECT DISTINCT customer.cid, Cname, store.sname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = 'Lidl' 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName sName
#[Out]# 0     1       Sem  Lidl
#[Out]# 1     2     Lucas  Lidl
#[Out]# 2     5      Levi  Lidl
#[Out]# 3     7      Bram  Lidl
#[Out]# 4    13     James  Lidl
#[Out]# 5    16    Julian  Lidl
#[Out]# 6    19      Lars  Lidl
#[Out]# 7    24      Luca  Lidl
#[Out]# 8    25     Mason  Lidl
#[Out]# 9    33      Sven  Lidl
#[Out]# 10   37      Guus  Lidl
#[Out]# 11   40      Jens  Lidl
#[Out]# 12   42      Tijn  Lidl
#[Out]# 13   43       Tom  Lidl
#[Out]# 14   51      Ties  Lidl
#[Out]# 15   57    Nathan  Lidl
#[Out]# 16   58     Jurre  Lidl
#[Out]# 17   59      Joep  Lidl
#[Out]# 18   60  Mohammed  Lidl
#[Out]# 19   82     Dylan  Lidl
#[Out]# 20   86      Stef  Lidl
#[Out]# 21   91   Thijmen  Lidl
#[Out]# 22   92     Jelte  Lidl
#[Out]# 23   95      Emma  Lidl
#[Out]# 24  108      Noor  Lidl
#[Out]# 25  112      Yara  Lidl
#[Out]# 26  123     Milou  Lidl
#[Out]# 27  124     Sofie  Lidl
#[Out]# 28  157      Puck  Lidl
#[Out]# 29  159     Fenne  Lidl
#[Out]# 30  161     Floor  Lidl
#[Out]# 31  163      Cato  Lidl
#[Out]# 32  165     Hanna  Lidl
#[Out]# 33  169      Lily  Lidl
#[Out]# 34  170      Iris  Lidl
#[Out]# 35  175       Sam  Lidl
#[Out]# 36  176     Amira  Lidl
#[Out]# 37  179      Juul  Lidl
#[Out]# 38  190    Kostas  Lidl
# Fri, 27 Nov 2020 12:50:10
query3_3 = '''
    SELECT DISTINCT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = 'Lidl' 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     5      Levi
#[Out]# 3     7      Bram
#[Out]# 4    13     James
#[Out]# 5    16    Julian
#[Out]# 6    19      Lars
#[Out]# 7    24      Luca
#[Out]# 8    25     Mason
#[Out]# 9    33      Sven
#[Out]# 10   37      Guus
#[Out]# 11   40      Jens
#[Out]# 12   42      Tijn
#[Out]# 13   43       Tom
#[Out]# 14   51      Ties
#[Out]# 15   57    Nathan
#[Out]# 16   58     Jurre
#[Out]# 17   59      Joep
#[Out]# 18   60  Mohammed
#[Out]# 19   82     Dylan
#[Out]# 20   86      Stef
#[Out]# 21   91   Thijmen
#[Out]# 22   92     Jelte
#[Out]# 23   95      Emma
#[Out]# 24  108      Noor
#[Out]# 25  112      Yara
#[Out]# 26  123     Milou
#[Out]# 27  124     Sofie
#[Out]# 28  157      Puck
#[Out]# 29  159     Fenne
#[Out]# 30  161     Floor
#[Out]# 31  163      Cato
#[Out]# 32  165     Hanna
#[Out]# 33  169      Lily
#[Out]# 34  170      Iris
#[Out]# 35  175       Sam
#[Out]# 36  176     Amira
#[Out]# 37  179      Juul
#[Out]# 38  190    Kostas
# Fri, 27 Nov 2020 12:50:43
query3_3 = '''
   SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT DISTINCT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = 'Lidl' 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      3    Finn
#[Out]# 2      4    Daan
#[Out]# 3      6   Milan
#[Out]# 4      8    Liam
#[Out]# ..   ...     ...
#[Out]# 146  184   Wilko
#[Out]# 147  185    Nick
#[Out]# 148  186  Angela
#[Out]# 149  188    Pino
#[Out]# 150  189    Koen
#[Out]# 
#[Out]# [151 rows x 2 columns]
# Fri, 27 Nov 2020 12:51:46
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT DISTINCT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = 'Kumar' 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:52:24
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid AND customer.cid = purchase.cid AND 
    shoppinglist.date = purchase.date AND shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Fri, 27 Nov 2020 12:53:21
query3_2 = '''
    SELECT DISTINCT customer.cid, cname, shoppinglist.date, purchase.date FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid AND customer.cid = purchase.cid AND 
    shoppinglist.date = purchase.date AND shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName        date        date
#[Out]# 0      1    Sem  2018-08-20  2018-08-20
#[Out]# 1      1    Sem  2018-08-21  2018-08-21
#[Out]# 2      2  Lucas  2018-08-16  2018-08-16
#[Out]# 3      2  Lucas  2018-08-17  2018-08-17
#[Out]# 4      3   Finn  2018-08-18  2018-08-18
#[Out]# ..   ...    ...         ...         ...
#[Out]# 181  179   Juul  2018-08-22  2018-08-22
#[Out]# 182  180  Merel  2018-08-26  2018-08-26
#[Out]# 183  180  Merel  2018-08-27  2018-08-27
#[Out]# 184  181   Liva  2018-08-24  2018-08-24
#[Out]# 185  181   Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [186 rows x 4 columns]
# Fri, 27 Nov 2020 12:53:29
query3_2 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, shoppinglist WHERE
    shoppinglist.cid = customer.cid AND customer.cid = purchase.cid AND 
    shoppinglist.date = purchase.date AND shoppinglist.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Fri, 27 Nov 2020 12:54:17
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT DISTINCT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = 'JUmbo' 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:54:21
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT DISTINCT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = 'Jumbo' 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# ..   ...      ...
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Fri, 27 Nov 2020 12:54:25
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT DISTINCT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = '' 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:54:30
query3_3 = '''
    SELECT DISTINCT customer.CID, Cname FROM customer EXCEPT SELECT DISTINCT customer.cid, Cname FROM
    customer, purchase, store WHERE customer.cid = purchase.cid AND purchase.sid = store.sid 
    AND store.sname = 'Kumar' 
    '''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:59:18
query3_4 = '''
    SELECT DISTINCT cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Lidl'
'''

pd.read_sql_query(query3_4, conn)
# Fri, 27 Nov 2020 12:59:29
query3_4 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Lidl'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     5      Levi
#[Out]# 3     7      Bram
#[Out]# 4    13     James
#[Out]# 5    16    Julian
#[Out]# 6    19      Lars
#[Out]# 7    24      Luca
#[Out]# 8    25     Mason
#[Out]# 9    33      Sven
#[Out]# 10   37      Guus
#[Out]# 11   40      Jens
#[Out]# 12   42      Tijn
#[Out]# 13   43       Tom
#[Out]# 14   51      Ties
#[Out]# 15   57    Nathan
#[Out]# 16   58     Jurre
#[Out]# 17   59      Joep
#[Out]# 18   60  Mohammed
#[Out]# 19   82     Dylan
#[Out]# 20   86      Stef
#[Out]# 21   91   Thijmen
#[Out]# 22   92     Jelte
#[Out]# 23   95      Emma
#[Out]# 24  108      Noor
#[Out]# 25  112      Yara
#[Out]# 26  123     Milou
#[Out]# 27  124     Sofie
#[Out]# 28  157      Puck
#[Out]# 29  159     Fenne
#[Out]# 30  161     Floor
#[Out]# 31  163      Cato
#[Out]# 32  165     Hanna
#[Out]# 33  169      Lily
#[Out]# 34  170      Iris
#[Out]# 35  175       Sam
#[Out]# 36  176     Amira
#[Out]# 37  179      Juul
#[Out]# 38  190    Kostas
# Fri, 27 Nov 2020 13:18:41
query3_4 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Lidl' EXCEPT SELECT DISTINCT customer.cid, cname
    FROM customer, purchase, store WHERE customer.cid = purchase.cid AND store.sid = purchase.sid 
    AND NOT store.sname = 'Lidl'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  cName
#[Out]# 0   25  Mason
# Fri, 27 Nov 2020 14:44:20
query3_4 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Lidl' EXCEPT SELECT DISTINCT customer.cid, cname
    FROM customer, purchase, store WHERE customer.cid = purchase.cid AND store.sid = purchase.sid 
    AND NOT store.sname = 'Lidl'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  cName
#[Out]# 0   25  Mason
# Fri, 27 Nov 2020 14:47:37
query3_5 = '''
SELECT DISTINCT store.sid, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND store.sname = 'Lidl' AND customer.cid = 25

'''

pd.read_sql_query(query3_5, conn)
#[Out]#    sID  cID  cName
#[Out]# 0   12   25  Mason
# Fri, 27 Nov 2020 14:48:00
query3_5 = '''
SELECT store.cname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND store.sname = 'Lidl' AND customer.cid = 25

'''

pd.read_sql_query(query3_5, conn)
# Fri, 27 Nov 2020 14:48:04
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND store.sname = 'Lidl' AND customer.cid = 25

'''

pd.read_sql_query(query3_5, conn)
#[Out]#   sName  cID  cName
#[Out]# 0  Lidl   25  Mason
# Fri, 27 Nov 2020 14:48:17
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND customer.cid = 25

'''

pd.read_sql_query(query3_5, conn)
#[Out]#   sName  cID  cName
#[Out]# 0  Lidl   25  Mason
# Fri, 27 Nov 2020 14:49:00
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid 

'''

pd.read_sql_query(query3_5, conn)
#[Out]#            sName  cID   cName
#[Out]# 0         Sligro    0    Noah
#[Out]# 1           Dirk    1     Sem
#[Out]# 2         Sligro    1     Sem
#[Out]# 3      Hoogvliet    1     Sem
#[Out]# 4    Albert Hein    1     Sem
#[Out]# ..           ...  ...     ...
#[Out]# 504        Jumbo  190  Kostas
#[Out]# 505         Lidl  190  Kostas
#[Out]# 506         Lidl  190  Kostas
#[Out]# 507        Jumbo  190  Kostas
#[Out]# 508        Jumbo  190  Kostas
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Fri, 27 Nov 2020 14:49:23
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND store.sname = 'Lidl'

'''

pd.read_sql_query(query3_5, conn)
#[Out]#    sName  cID   cName
#[Out]# 0   Lidl    1     Sem
#[Out]# 1   Lidl    1     Sem
#[Out]# 2   Lidl    1     Sem
#[Out]# 3   Lidl    2   Lucas
#[Out]# 4   Lidl    5    Levi
#[Out]# ..   ...  ...     ...
#[Out]# 59  Lidl  190  Kostas
#[Out]# 60  Lidl  190  Kostas
#[Out]# 61  Lidl  190  Kostas
#[Out]# 62  Lidl  190  Kostas
#[Out]# 63  Lidl  190  Kostas
#[Out]# 
#[Out]# [64 rows x 3 columns]
# Fri, 27 Nov 2020 14:49:36
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND customer.cid = 1

'''

pd.read_sql_query(query3_5, conn)
#[Out]#          sName  cID cName
#[Out]# 0         Dirk    1   Sem
#[Out]# 1       Sligro    1   Sem
#[Out]# 2    Hoogvliet    1   Sem
#[Out]# 3  Albert Hein    1   Sem
#[Out]# 4         Lidl    1   Sem
#[Out]# 5         Lidl    1   Sem
#[Out]# 6         Lidl    1   Sem
# Fri, 27 Nov 2020 14:49:40
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND customer.cid = 2

'''

pd.read_sql_query(query3_5, conn)
#[Out]#     sName  cID  cName
#[Out]# 0    Lidl    2  Lucas
#[Out]# 1  Sligro    2  Lucas
#[Out]# 2    Coop    2  Lucas
#[Out]# 3    Coop    2  Lucas
#[Out]# 4    Coop    2  Lucas
# Fri, 27 Nov 2020 14:49:43
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND customer.cid = 3

'''

pd.read_sql_query(query3_5, conn)
#[Out]#          sName  cID cName
#[Out]# 0  Albert Hein    3  Finn
#[Out]# 1         Dirk    3  Finn
#[Out]# 2       Sligro    3  Finn
# Fri, 27 Nov 2020 14:49:45
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND customer.cid = 4

'''

pd.read_sql_query(query3_5, conn)
#[Out]#          sName  cID cName
#[Out]# 0    Hoogvliet    4  Daan
#[Out]# 1        Jumbo    4  Daan
#[Out]# 2         Coop    4  Daan
#[Out]# 3         Coop    4  Daan
#[Out]# 4       Sligro    4  Daan
#[Out]# 5  Albert Hein    4  Daan
# Fri, 27 Nov 2020 14:49:48
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND customer.cid = 5

'''

pd.read_sql_query(query3_5, conn)
#[Out]#        sName  cID cName
#[Out]# 0  Hoogvliet    5  Levi
#[Out]# 1       Lidl    5  Levi
#[Out]# 2       Coop    5  Levi
#[Out]# 3       Coop    5  Levi
#[Out]# 4       Coop    5  Levi
#[Out]# 5  Hoogvliet    5  Levi
# Fri, 27 Nov 2020 14:49:51
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND customer.cid = 6

'''

pd.read_sql_query(query3_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 14:50:07
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND customer.cid = 6

'''

pd.read_sql_query(query3_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 14:50:12
query3_5 = '''
SELECT store.sname, customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
AND purchase.sid = store.sid AND customer.cid = 7

'''

pd.read_sql_query(query3_5, conn)
#[Out]#          sName  cID cName
#[Out]# 0       Sligro    7  Bram
#[Out]# 1         Lidl    7  Bram
#[Out]# 2  Albert Hein    7  Bram
#[Out]# 3  Albert Hein    7  Bram
#[Out]# 4    Hoogvliet    7  Bram
#[Out]# 5       Sligro    7  Bram
# Fri, 27 Nov 2020 14:50:32
query3_4 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Lidl' EXCEPT SELECT DISTINCT customer.cid, cname
    FROM customer, purchase, store WHERE customer.cid = purchase.cid AND store.sid = purchase.sid 
    AND NOT store.sname = 'Lidl'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  cName
#[Out]# 0   25  Mason
# Fri, 27 Nov 2020 14:50:37
query3_4 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Lidl' EXCEPT SELECT DISTINCT customer.cid, cname
    FROM customer, purchase, store WHERE customer.cid = purchase.cid AND store.sid = purchase.sid 
    AND NOT store.sname = 'Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 14:50:45
query3_4 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Lidl' EXCEPT SELECT DISTINCT customer.cid, cname
    FROM customer, purchase, store WHERE customer.cid = purchase.cid AND store.sid = purchase.sid 
    AND NOT store.sname = 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 14:54:13
query3_4 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Lidl' EXCEPT SELECT DISTINCT customer.cid, cname
    FROM customer, purchase, store WHERE customer.cid = purchase.cid AND store.sid = purchase.sid 
    AND NOT store.sname = 'Albert Heijn'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Fri, 27 Nov 2020 14:54:21
query3_4 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Lidl' EXCEPT SELECT DISTINCT customer.cid, cname
    FROM customer, purchase, store WHERE customer.cid = purchase.cid AND store.sid = purchase.sid 
    AND NOT store.sname = 'Lidl'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  cName
#[Out]# 0   25  Mason
# Fri, 27 Nov 2020 15:05:30
query3_4 = '''
    SELECT DISTINCT customer.cid, cname FROM customer, purchase, store WHERE customer.cid = purchase.cid
    AND purchase.sid = store.sid AND store.sname = 'Kumar' EXCEPT SELECT DISTINCT customer.cid, cname
    FROM customer, purchase, store WHERE customer.cid = purchase.cid AND store.sid = purchase.sid 
    AND NOT store.sname = 'Kumar'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []


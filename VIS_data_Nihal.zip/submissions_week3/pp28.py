# IPython log file

# Tue, 01 Dec 2020 22:55:24
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 23:23:59
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, shoppinglist s, purchase p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 23:24:34
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 23:24:38
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, shoppinglist s, purchase p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 23:24:40
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 23:24:41
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x25438791c70>
# Tue, 01 Dec 2020 23:25:11
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]

# IPython log file

# Tue, 01 Dec 2020 23:27:05
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 23:27:06
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 01 Dec 2020 23:27:22
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 23:28:42
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-21
#[Out]# 2    Lucas    2  2018-08-16
#[Out]# 3    Lucas    2  2018-08-17
#[Out]# 4     Finn    3  2018-08-18
#[Out]# ..     ...  ...         ...
#[Out]# 181   Juul  179  2018-08-22
#[Out]# 182  Merel  180  2018-08-26
#[Out]# 183  Merel  180  2018-08-27
#[Out]# 184   Liva  181  2018-08-24
#[Out]# 185   Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Tue, 01 Dec 2020 23:28:56
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date, p.date
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date        date
#[Out]# 0      Sem    1  2018-08-20  2018-08-20
#[Out]# 1      Sem    1  2018-08-21  2018-08-21
#[Out]# 2    Lucas    2  2018-08-16  2018-08-16
#[Out]# 3    Lucas    2  2018-08-17  2018-08-17
#[Out]# 4     Finn    3  2018-08-18  2018-08-18
#[Out]# ..     ...  ...         ...         ...
#[Out]# 181   Juul  179  2018-08-22  2018-08-22
#[Out]# 182  Merel  180  2018-08-26  2018-08-26
#[Out]# 183  Merel  180  2018-08-27  2018-08-27
#[Out]# 184   Liva  181  2018-08-24  2018-08-24
#[Out]# 185   Liva  181  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [186 rows x 4 columns]
# Tue, 01 Dec 2020 23:29:14
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 23:29:21
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID and s.cID = p.cID and s.date like '2018%' and s.date = p.date;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 23:36:28
query3_3 = '''
    (SELECT DISTINCT c.cName, c.cID
     FROM customer.cID c
     WHERE c.cID NOT IN (SELECT p.cID FROM purchase p));
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 23:36:39
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
     FROM customer.cID c
     WHERE c.cID NOT IN (SELECT p.cID FROM purchase p);
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 23:36:56
query3_3 = '''
    (SELECT DISTINCT c.cName, c.cID
     FROM customer c
     WHERE c.cID NOT IN (SELECT p.cID FROM purchase p));
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 23:37:06
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
     FROM customer c
     WHERE c.cID NOT IN (SELECT p.cID FROM purchase p);
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0      Milan    6
#[Out]# 1     Thomas    9
#[Out]# 2       Adam   12
#[Out]# 3        Max   14
#[Out]# 4        Jan   23
#[Out]# 5      Vince   32
#[Out]# 6       Boaz   36
#[Out]# 7      Fedde   46
#[Out]# 8       Tygo   48
#[Out]# 9        Cas   49
#[Out]# 10       Pim   50
#[Out]# 11       Job   53
#[Out]# 12       Jax   54
#[Out]# 13    Tobias   56
#[Out]# 14    Morris   61
#[Out]# 15      Abel   62
#[Out]# 16    Pepijn   65
#[Out]# 17      Owen   73
#[Out]# 18    Samuel   74
#[Out]# 19    Joshua   79
#[Out]# 20     Simon   81
#[Out]# 21     Melle   83
#[Out]# 22     Jelle   87
#[Out]# 23  Johannes   89
#[Out]# 24     Oscar   93
#[Out]# 25     Julia   98
#[Out]# 26       Eva  101
#[Out]# 27       Evi  102
#[Out]# 28      Nora  105
#[Out]# 29     Fleur  106
#[Out]# 30    Olivia  107
#[Out]# 31      Maud  114
#[Out]# 32      Nova  115
#[Out]# 33      Roos  117
#[Out]# 34     Sarah  120
#[Out]# 35       Isa  121
#[Out]# 36       Noa  125
#[Out]# 37     Sanne  130
#[Out]# 38    Hannah  132
#[Out]# 39     Maria  138
#[Out]# 40      Vera  140
#[Out]# 41       Mia  141
#[Out]# 42        Bo  142
#[Out]# 43     Naomi  143
#[Out]# 44     Norah  146
#[Out]# 45  Isabella  148
#[Out]# 46     Julie  150
#[Out]# 47     Amber  153
#[Out]# 48    Benthe  154
#[Out]# 49     Linde  155
#[Out]# 50      Luna  156
#[Out]# 51      Rosa  158
#[Out]# 52      Lara  160
#[Out]# 53       Evy  164
#[Out]# 54   Rosalie  166
#[Out]# 55     Livia  173
#[Out]# 56      Romy  174
#[Out]# 57     Nikki  183
# Tue, 01 Dec 2020 23:41:37
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c
    WHERE c.cID NOT IN (SELECT p.cID
                        FROM purchase p, store s 
                        WHERE p.sID = s.sID and s.sName = 'Jumbo')
    
    UNION
    
    SELECT DISTINCT c.cName, c.cID
    FROM customer c
    WHERE c.cID NOT IN (SELECT p.cID FROM purchase p);
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 23:42:46
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c
    WHERE c.cID NOT IN (SELECT p.cID
                        FROM purchase p, store s 
                        WHERE p.sID = s.sID and s.sName = 'Jumbo')
    
    UNION
    
    SELECT DISTINCT c.cName, c.cID
    FROM customer c
    WHERE c.cID NOT IN (SELECT p.cID FROM purchase p);
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 23:45:10
query3_3 = '''
SELECT DISTINCT c.cName, c.cID
FROM customer c
WHERE c.cID NOT IN (SELECT p.cID
                    FROM purchase p, store s 
                    WHERE p.sID = s.sID and s.sName = 'Jumbo')
    
UNION
    
SELECT DISTINCT c.cName, c.cID
FROM customer c
WHERE c.cID NOT IN (SELECT p.cID FROM purchase p);
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 23:52:17
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, purchase p
    WHERE c.cID = p.cID and c.cID NOT IN (SELECT p.cID
                                          FROM store s
                                          WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID
#[Out]# 0       Daan    4
#[Out]# 1       Hugo   18
#[Out]# 2       Lars   19
#[Out]# 3   Benjamin   21
#[Out]# 4       Luca   24
#[Out]# 5        Tim   27
#[Out]# 6       Guus   37
#[Out]# 7     Floris   38
#[Out]# 8       Jens   40
#[Out]# 9       Xavi   47
#[Out]# 10    Willem   52
#[Out]# 11      Joep   59
#[Out]# 12      Senn   63
#[Out]# 13   Mohamed   66
#[Out]# 14     Boris   68
#[Out]# 15      Dani   72
#[Out]# 16      Mick   78
#[Out]# 17    Pieter   85
#[Out]# 18      Stef   86
#[Out]# 19       Liv  104
#[Out]# 20      Lynn  109
#[Out]# 21      Yara  112
#[Out]# 22      Elin  122
#[Out]# 23      Lina  126
#[Out]# 24     Femke  136
#[Out]# 25     Hanna  165
#[Out]# 26    Veerle  167
#[Out]# 27     Tessa  171
#[Out]# 28      Lana  172
#[Out]# 29     Merel  180
#[Out]# 30      Nick  185
#[Out]# 31    Angela  186
#[Out]# 32      Pino  188
#[Out]# 33      Koen  189
#[Out]# 34    Kostas  190
# Tue, 01 Dec 2020 23:52:33
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID, p.pID
    FROM customer c, purchase p
    WHERE c.cID = p.cID and c.cID NOT IN (SELECT p.cID
                                          FROM store s
                                          WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID  pID
#[Out]# 0       Daan    4   27
#[Out]# 1       Hugo   18    9
#[Out]# 2       Lars   19    0
#[Out]# 3       Lars   19   15
#[Out]# 4   Benjamin   21   23
#[Out]# 5       Luca   24   13
#[Out]# 6        Tim   27   14
#[Out]# 7       Guus   37   13
#[Out]# 8     Floris   38   25
#[Out]# 9       Jens   40   19
#[Out]# 10      Xavi   47   16
#[Out]# 11    Willem   52    5
#[Out]# 12      Joep   59   21
#[Out]# 13      Senn   63   27
#[Out]# 14   Mohamed   66   24
#[Out]# 15     Boris   68    7
#[Out]# 16      Dani   72   16
#[Out]# 17      Mick   78   13
#[Out]# 18    Pieter   85    2
#[Out]# 19      Stef   86   28
#[Out]# 20       Liv  104   22
#[Out]# 21      Lynn  109   26
#[Out]# 22      Yara  112    3
#[Out]# 23      Elin  122    7
#[Out]# 24      Lina  126   15
#[Out]# 25     Femke  136   28
#[Out]# 26     Hanna  165    1
#[Out]# 27    Veerle  167    7
#[Out]# 28     Tessa  171    3
#[Out]# 29      Lana  172    4
#[Out]# 30     Merel  180   10
#[Out]# 31      Nick  185   29
#[Out]# 32    Angela  186   29
#[Out]# 33      Pino  188   30
#[Out]# 34      Koen  189    7
#[Out]# 35      Koen  189   19
#[Out]# 36    Kostas  190   19
#[Out]# 37    Kostas  190   20
#[Out]# 38    Kostas  190   28
#[Out]# 39    Kostas  190   11
#[Out]# 40    Kostas  190   17
#[Out]# 41    Kostas  190    9
#[Out]# 42    Kostas  190   18
# Tue, 01 Dec 2020 23:53:13
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID, s.sID
    FROM customer c, purchase p
    WHERE c.cID = p.cID and c.cID NOT IN (SELECT p.cID
                                          FROM store s
                                          WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 23:53:31
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID,
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID and c.cID NOT IN (SELECT p.cID
                                          
                                          WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 23:53:35
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID and c.cID NOT IN (SELECT p.cID
                                          
                                          WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 127    Nick  185
#[Out]# 128  Angela  186
#[Out]# 129    Pino  188
#[Out]# 130    Koen  189
#[Out]# 131  Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 23:53:43
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, purchase p
    WHERE c.cID = p.cID and c.cID NOT IN (SELECT p.cID
                                          FROM store s
                                          WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID
#[Out]# 0       Daan    4
#[Out]# 1       Hugo   18
#[Out]# 2       Lars   19
#[Out]# 3   Benjamin   21
#[Out]# 4       Luca   24
#[Out]# 5        Tim   27
#[Out]# 6       Guus   37
#[Out]# 7     Floris   38
#[Out]# 8       Jens   40
#[Out]# 9       Xavi   47
#[Out]# 10    Willem   52
#[Out]# 11      Joep   59
#[Out]# 12      Senn   63
#[Out]# 13   Mohamed   66
#[Out]# 14     Boris   68
#[Out]# 15      Dani   72
#[Out]# 16      Mick   78
#[Out]# 17    Pieter   85
#[Out]# 18      Stef   86
#[Out]# 19       Liv  104
#[Out]# 20      Lynn  109
#[Out]# 21      Yara  112
#[Out]# 22      Elin  122
#[Out]# 23      Lina  126
#[Out]# 24     Femke  136
#[Out]# 25     Hanna  165
#[Out]# 26    Veerle  167
#[Out]# 27     Tessa  171
#[Out]# 28      Lana  172
#[Out]# 29     Merel  180
#[Out]# 30      Nick  185
#[Out]# 31    Angela  186
#[Out]# 32      Pino  188
#[Out]# 33      Koen  189
#[Out]# 34    Kostas  190
# Tue, 01 Dec 2020 23:54:15
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, purchase p
    WHERE c.cID = p.cID and c.cID NOT IN (SELECT p2.cID
                                          FROM store s, purchase p2
                                          WHERE p2.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Tue, 01 Dec 2020 23:57:33
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, purchase p
    WHERE c.cID = p.cID and c.cID NOT IN (SELECT p.cID
                                          FROM store s
                                          WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID
#[Out]# 0       Daan    4
#[Out]# 1       Hugo   18
#[Out]# 2       Lars   19
#[Out]# 3   Benjamin   21
#[Out]# 4       Luca   24
#[Out]# 5        Tim   27
#[Out]# 6       Guus   37
#[Out]# 7     Floris   38
#[Out]# 8       Jens   40
#[Out]# 9       Xavi   47
#[Out]# 10    Willem   52
#[Out]# 11      Joep   59
#[Out]# 12      Senn   63
#[Out]# 13   Mohamed   66
#[Out]# 14     Boris   68
#[Out]# 15      Dani   72
#[Out]# 16      Mick   78
#[Out]# 17    Pieter   85
#[Out]# 18      Stef   86
#[Out]# 19       Liv  104
#[Out]# 20      Lynn  109
#[Out]# 21      Yara  112
#[Out]# 22      Elin  122
#[Out]# 23      Lina  126
#[Out]# 24     Femke  136
#[Out]# 25     Hanna  165
#[Out]# 26    Veerle  167
#[Out]# 27     Tessa  171
#[Out]# 28      Lana  172
#[Out]# 29     Merel  180
#[Out]# 30      Nick  185
#[Out]# 31    Angela  186
#[Out]# 32      Pino  188
#[Out]# 33      Koen  189
#[Out]# 34    Kostas  190
# Wed, 02 Dec 2020 00:04:27
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, purchase p
    WHERE c.cID = p.cID and c.cID NOT IN (SELECT p.cID
                                          FROM store s
                                          WHERE p.sID = s.sID and s.sName != 'Jumbo' and p.cID = c.cID);
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID
#[Out]# 0       Daan    4
#[Out]# 1       Hugo   18
#[Out]# 2       Lars   19
#[Out]# 3   Benjamin   21
#[Out]# 4       Luca   24
#[Out]# 5        Tim   27
#[Out]# 6       Guus   37
#[Out]# 7     Floris   38
#[Out]# 8       Jens   40
#[Out]# 9       Xavi   47
#[Out]# 10    Willem   52
#[Out]# 11      Joep   59
#[Out]# 12      Senn   63
#[Out]# 13   Mohamed   66
#[Out]# 14     Boris   68
#[Out]# 15      Dani   72
#[Out]# 16      Mick   78
#[Out]# 17    Pieter   85
#[Out]# 18      Stef   86
#[Out]# 19       Liv  104
#[Out]# 20      Lynn  109
#[Out]# 21      Yara  112
#[Out]# 22      Elin  122
#[Out]# 23      Lina  126
#[Out]# 24     Femke  136
#[Out]# 25     Hanna  165
#[Out]# 26    Veerle  167
#[Out]# 27     Tessa  171
#[Out]# 28      Lana  172
#[Out]# 29     Merel  180
#[Out]# 30      Nick  185
#[Out]# 31    Angela  186
#[Out]# 32      Pino  188
#[Out]# 33      Koen  189
#[Out]# 34    Kostas  190
# Wed, 02 Dec 2020 00:05:30
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, purchase p1
    WHERE c.cID = p1.cID and c.cID NOT IN (SELECT p2.cID
                                          FROM store s, purchase p2 
                                          WHERE p2.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Wed, 02 Dec 2020 00:09:03
query3_4 = '''

SELECT DISTINCT c.cName, c.cID
FROM customer c, purchase p
WHERE c.cID = p1.cID and c.cID NOT IN (SELECT p.cID
                                      FROM store s, p
                                      WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 00:09:27
query3_4 = '''

SELECT DISTINCT c.cName, c.cID
FROM customer c, purchase p1
WHERE c.cID = p1.cID and c.cID NOT IN (SELECT p2.cID
                                      FROM store s, purchase p2 
                                      WHERE p2.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Wed, 02 Dec 2020 00:15:03
query3_4 = '''

SELECT DISTINCT c.cName, c.cID
FROM customer c
WHERE c.cID NOT IN (SELECT p.cID
                    FROM store s, purchase p 
                    WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID
#[Out]# 0    Milan    6
#[Out]# 1   Thomas    9
#[Out]# 2     Adam   12
#[Out]# 3      Max   14
#[Out]# 4      Jan   23
#[Out]# ..     ...  ...
#[Out]# 61   Nikki  183
#[Out]# 62    Nick  185
#[Out]# 63  Angela  186
#[Out]# 64    Pino  188
#[Out]# 65    Koen  189
#[Out]# 
#[Out]# [66 rows x 2 columns]
# Wed, 02 Dec 2020 00:16:58
query3_4 = '''
SELECT DISTINCT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cID and s.sID = p.sID and s.sName = 'Jumbo'

INTERSECT

SELECT DISTINCT c.cName, c.cID
FROM customer c
WHERE c.cID NOT IN (SELECT p.cID
                    FROM store s, purchase p 
                    WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0  Angela  186
#[Out]# 1   Femke  136
#[Out]# 2    Koen  189
#[Out]# 3     Liv  104
#[Out]# 4    Nick  185
#[Out]# 5    Pino  188
#[Out]# 6    Senn   63
#[Out]# 7    Xavi   47
# Wed, 02 Dec 2020 00:17:21
query3_4 = '''
SELECT DISTINCT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cID and s.sID = p.sID and s.sName = 'Jumbo'

INTERSECT

SELECT DISTINCT c.cName, c.cID
FROM customer c
WHERE c.cID NOT IN (SELECT p.cID
                    FROM store s, purchase p 
                    WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0  Angela  186
#[Out]# 1   Femke  136
#[Out]# 2    Koen  189
#[Out]# 3     Liv  104
#[Out]# 4    Nick  185
#[Out]# 5    Pino  188
#[Out]# 6    Senn   63
#[Out]# 7    Xavi   47
# Wed, 02 Dec 2020 00:17:44
query3_4 = '''
SELECT DISTINCT c.cName, c.cID
FROM customer c, purchase p, store s
WHERE c.cID = p.cID and s.sID = p.sID and s.sName = 'Jumbo'

INTERSECT

SELECT DISTINCT c.cName, c.cID
FROM customer c
WHERE c.cID NOT IN (SELECT p.cID
                    FROM store s, purchase p 
                    WHERE p.sID = s.sID and s.sName != 'Jumbo');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0  Angela  186
#[Out]# 1   Femke  136
#[Out]# 2    Koen  189
#[Out]# 3     Liv  104
#[Out]# 4    Nick  185
#[Out]# 5    Pino  188
#[Out]# 6    Senn   63
#[Out]# 7    Xavi   47


# IPython log file

# Tue, 01 Dec 2020 13:44:24
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 13:44:25
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1e90a98adc0>
# Tue, 01 Dec 2020 13:44:35
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 13:45:21
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x000001E90A98ADC0>
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 13:45:24
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 13:45:25
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 01 Dec 2020 13:45:25
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 13:45:40
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
#db_location = 'shoppingDB.sql'

#f = open(db_location,'r')
#sql = f.read()
#cur.executescript(sql)
# Tue, 01 Dec 2020 13:45:40
# In order to allow for visualization, we need to extract the schema.

#schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 13:47:03
query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID FROM customer, purchase, shoppinglist WHERE
    purchase.date = shoppinglist.date AND purchase.date like "%2018%" AND shoppinglist.cID = customer.cID
'''
# Tue, 01 Dec 2020 13:47:03
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 128   Elif  178
#[Out]# 129   Juul  179
#[Out]# 130  Merel  180
#[Out]# 131   Liva  181
#[Out]# 132  Nikki  183
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 01 Dec 2020 13:47:06
query3_3 = '''
    SELECT customer.cName, customer.cID FROM customer
        EXCEPT
    SELECT customer.cName, customer.cID FROM customer, purchase WHERE customer.cID = purchase.cID
        UNION
    SELECT customer.cName, customer.cID FROM customer, purchase
        EXCEPT 
    SELECT customer.cName, customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName like "Kumar"
'''
# Tue, 01 Dec 2020 13:47:06
pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 13:47:10
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID FROM customer, purchase WHERE customer.cID = purchase.cID
        EXCEPT
    SELECT DISTINCT customer.cName, customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND NOT store.sName = "Kumar"
'''
# Tue, 01 Dec 2020 13:47:11
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []


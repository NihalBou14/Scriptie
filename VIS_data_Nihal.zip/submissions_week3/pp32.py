# IPython log file

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Thu, 26 Nov 2020 22:26:38
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Thu, 26 Nov 2020 22:26:56
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 22:26:58
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7fe9ce3748f0>
# Thu, 26 Nov 2020 22:27:11
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 22:27:15
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 22:28:58
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x7fe9ce3748f0>
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 22:29:14
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 22:29:16
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Thu, 26 Nov 2020 22:29:26
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 22:40:40
query3_2 = '''
    SELECT cID, cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID)
    WHERE sl.date LIKE '%2018');
'''
# Thu, 26 Nov 2020 22:40:42
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 22:44:26
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%';
'''
# Thu, 26 Nov 2020 22:44:27
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 22:44:35
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%';
'''
# Thu, 26 Nov 2020 22:44:36
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 22:44:45
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%';
'''
# Thu, 26 Nov 2020 22:44:46
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 22:44:50
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
'''
# Thu, 26 Nov 2020 22:44:51
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 22:53:09
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
'''
# Thu, 26 Nov 2020 22:53:10
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 22:54:09
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
''
# Thu, 26 Nov 2020 22:54:13
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
''
# Thu, 26 Nov 2020 22:54:14
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 22:54:17
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
''
# Thu, 26 Nov 2020 22:54:17
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 22:54:26
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
'''
# Thu, 26 Nov 2020 22:54:26
vis.visualize(query3_2, schema)

# IPython log file

query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
'''
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 15:19:13
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
'''
# Sun, 29 Nov 2020 15:19:13
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 15:19:21
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
'''
vis.visualize(query3_2, schema)
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
'''
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 15:19:23
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 29 Nov 2020 15:19:26
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Sun, 29 Nov 2020 15:19:28
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Sun, 29 Nov 2020 15:19:30
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Sun, 29 Nov 2020 15:19:33
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
'''
# Sun, 29 Nov 2020 15:19:34
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 15:24:26
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 15:50:37
query3_3 = '''
    (SELECT c.cName, c.cID FROM ((CUSTOMER c
    INNER JOIN purchase p ON c.cID = p.cID)
    INNER JOIN store s ON s.sID = p.sID)
    WHERE s.sName != "Coop"
    union
    SELECT c.cName, c.cID FROM CUSTOMER c
    WHERE c.cID NOT IN 
		(SELECT cID
		 FROM purchase)
    
'''
# Sun, 29 Nov 2020 15:50:38
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 15:50:55
query3_3 = '''
    SELECT c.cName, c.cID FROM ((CUSTOMER c
    INNER JOIN purchase p ON c.cID = p.cID)
    INNER JOIN store s ON s.sID = p.sID)
    WHERE s.sName != "Coop"
    union
    SELECT c.cName, c.cID FROM CUSTOMER c
    WHERE c.cID NOT IN 
		(SELECT cID
		 FROM purchase)
    
'''
# Sun, 29 Nov 2020 15:50:55
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 15:50:57
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Abel   62
#[Out]# 1      Adam   12
#[Out]# 2     Amber  153
#[Out]# 3     Amira  176
#[Out]# 4    Angela  186
#[Out]# ..      ...  ...
#[Out]# 171    Vera  140
#[Out]# 172   Vince   32
#[Out]# 173  Willem   52
#[Out]# 174    Xavi   47
#[Out]# 175    Yara  112
#[Out]# 
#[Out]# [176 rows x 2 columns]
# Sun, 29 Nov 2020 16:03:59
vis.visualize(query3_4, schema)
# Sun, 29 Nov 2020 16:04:03
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID FROM ((CUSTOMER c
    INNER JOIN purchase p ON c.cID = p.cID)
    INNER JOIN store s ON s.sID = p.sID)
    WHERE s.sName NOT IN
        (SELECT sName FROM store
        WHERE sName != "Coop")
     
'''
# Sun, 29 Nov 2020 16:04:04
vis.visualize(query3_4, schema)
# Sun, 29 Nov 2020 16:04:05
pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID
#[Out]# 0    Lucas    2
#[Out]# 1     Daan    4
#[Out]# 2     Levi    5
#[Out]# 3     Liam    8
#[Out]# 4      Sam   10
#[Out]# ..     ...  ...
#[Out]# 69    Juul  179
#[Out]# 70   Merel  180
#[Out]# 71    Liva  181
#[Out]# 72   Wilko  184
#[Out]# 73  Kostas  190
#[Out]# 
#[Out]# [74 rows x 2 columns]
# Sun, 29 Nov 2020 20:22:00
vis.visualize(query3_4, schema)

# IPython log file

# Tue, 01 Dec 2020 13:15:14
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Tue, 01 Dec 2020 13:15:17
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 13:15:19
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 01 Dec 2020 13:15:22
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 13:15:24
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM ((CUSTOMER c
    INNER JOIN shoppingList sl ON sl.cID = c.cID)
    INNER JOIN purchase p ON c.cID = p.cID AND sl.date = p.date)
    WHERE sl.date LIKE '2018%'
'''
# Tue, 01 Dec 2020 13:15:24
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 13:15:25
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 13:18:43
query3_3 = '''
    SELECT c.cName, c.cID FROM ((CUSTOMER c
    INNER JOIN purchase p ON c.cID = p.cID)
    INNER JOIN store s ON s.sID = p.sID)
    WHERE s.sName != "Coop"
    union
    SELECT c.cName, c.cID FROM CUSTOMER c
    WHERE c.cID NOT IN 
		(SELECT cID
		 FROM purchase)
    
'''
# Tue, 01 Dec 2020 13:18:44
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 13:18:45
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Abel   62
#[Out]# 1      Adam   12
#[Out]# 2     Amber  153
#[Out]# 3     Amira  176
#[Out]# 4    Angela  186
#[Out]# ..      ...  ...
#[Out]# 171    Vera  140
#[Out]# 172   Vince   32
#[Out]# 173  Willem   52
#[Out]# 174    Xavi   47
#[Out]# 175    Yara  112
#[Out]# 
#[Out]# [176 rows x 2 columns]
# Tue, 01 Dec 2020 13:18:46
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID FROM ((CUSTOMER c
    INNER JOIN purchase p ON c.cID = p.cID)
    INNER JOIN store s ON s.sID = p.sID)
    WHERE s.sName NOT IN
        (SELECT sName FROM store
        WHERE sName != "Coop")
     
'''
# Tue, 01 Dec 2020 13:18:47
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 13:18:47
pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID
#[Out]# 0    Lucas    2
#[Out]# 1     Daan    4
#[Out]# 2     Levi    5
#[Out]# 3     Liam    8
#[Out]# 4      Sam   10
#[Out]# ..     ...  ...
#[Out]# 69    Juul  179
#[Out]# 70   Merel  180
#[Out]# 71    Liva  181
#[Out]# 72   Wilko  184
#[Out]# 73  Kostas  190
#[Out]# 
#[Out]# [74 rows x 2 columns]

   Bud1            %                       l o g sdsclbool                   dsclbool                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             @                                              @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   E   %                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       DSDB                             `                                                     @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              

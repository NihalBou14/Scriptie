# IPython log file

# Tue, 01 Dec 2020 21:29:36
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 21:33:54
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x19bb3857ab0>
# Tue, 01 Dec 2020 21:42:37
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 21:58:34
query3_2 = '''
        SELECT c.cID, c.cName
        FROM costumer as c, shoppinglist as s, purchase as p
        WHERE s.date = "2018" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        AND c.cID = p.pID;
'''
# Tue, 01 Dec 2020 21:58:36
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 21:58:48
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 22:00:04
query3_2 = '''
        SELECT c.cID, c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date = "2018" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        AND c.cID = p.pID;
'''
# Tue, 01 Dec 2020 22:00:07
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 22:00:09
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 22:04:40
query3_2 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date = "2018" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        AND c.cID = p.pID;
'''
# Tue, 01 Dec 2020 22:04:42
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 22:04:45
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 22:06:23
query3_2 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date LIKE %2018% 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        AND c.cID = p.pID;
'''
# Tue, 01 Dec 2020 22:06:25
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 22:06:44
query3_2 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date LIKE "%2018%" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        AND c.cID = p.pID;
'''
# Tue, 01 Dec 2020 22:06:47
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 22:06:50
pd.read_sql_query(query3_2, conn)
#[Out]#    cID cName
#[Out]# 0    8  Liam
#[Out]# 1   24  Luca
# Tue, 01 Dec 2020 22:09:10
query3_2 = '''
        SELECT c.cID, c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date LIKE "%2018%" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        AND c.cID = p.pID;
'''
# Tue, 01 Dec 2020 22:09:11
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 22:09:14
pd.read_sql_query(query3_2, conn)
#[Out]#    cID cName
#[Out]# 0    8  Liam
#[Out]# 1    8  Liam
#[Out]# 2    8  Liam
#[Out]# 3   24  Luca
#[Out]# 4   24  Luca
#[Out]# 5   24  Luca
# Tue, 01 Dec 2020 22:09:28
query3_2 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date LIKE "%2018%" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        AND c.cID = p.pID;
'''
# Tue, 01 Dec 2020 22:09:30
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 22:09:35
pd.read_sql_query(query3_2, conn)
#[Out]#    cID cName
#[Out]# 0    8  Liam
#[Out]# 1   24  Luca
# Tue, 01 Dec 2020 22:19:36
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN "Coop";
'''
# Tue, 01 Dec 2020 22:19:38
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 22:19:51
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 22:20:59
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN ("Coop");
'''
# Tue, 01 Dec 2020 22:21:01
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 22:21:05
pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 22:22:07
query3_3 = '''
        SELECT COUNT(DISTINCT c.cID, c.cName)
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN ("Coop");
'''
# Tue, 01 Dec 2020 22:22:10
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 22:22:30
query3_3 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN ("Coop");
'''
# Tue, 01 Dec 2020 22:22:32
pd.read_sql_query(query3_3, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                    190  Noah
# Tue, 01 Dec 2020 22:23:20
query3_3 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN ("Jumbo");
'''
# Tue, 01 Dec 2020 22:23:22
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 22:23:25
pd.read_sql_query(query3_3, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                    190  Noah
# Tue, 01 Dec 2020 22:33:15
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN (SELECT DISTINCT c.cID, c.cName
                            FROM customer as c, purchase as p
                            WHERE p.sID NOT IN (DISTINCT c.cID, c.cName
                                                FROM customer as c, purchase as p
                                                WHERE p.sID NOT IN ("Jumbo");););
'''
# Tue, 01 Dec 2020 22:33:18
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 22:33:21
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 22:33:52
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN (SELECT c.cID, c.cName
                            FROM customer as c, purchase as p
                            WHERE p.sID NOT IN (SELECT c.cID, c.cName
                                                FROM customer as c, purchase as p
                                                WHERE p.sID NOT IN ("Jumbo");););
'''
# Tue, 01 Dec 2020 22:33:54
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 22:33:57
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 22:34:07
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN (SELECT c.cID, c.cName
                            FROM customer as c, purchase as p
                            WHERE p.sID NOT IN (SELECT c.cID, c.cName
                                                FROM customer as c, purchase as p
                                                WHERE p.sID NOT IN ("Jumbo")));
'''
# Tue, 01 Dec 2020 22:34:09
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 22:34:16
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 22:35:22
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE c.cID NOT IN (SELECT c.cID, c.cName
                            FROM customer as c, purchase as p
                            WHERE c.cID NOT IN (SELECT c.cID
                                                FROM customer as c, purchase as p
                                                WHERE p.sID NOT IN ("Jumbo")));
'''
# Tue, 01 Dec 2020 22:35:24
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 22:35:28
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 22:35:45
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE c.cID NOT IN (SELECT c.cID
                            FROM customer as c, purchase as p
                            WHERE c.cID NOT IN (SELECT c.cID
                                                FROM customer as c, purchase as p
                                                WHERE p.sID NOT IN ("Jumbo")));
'''
# Tue, 01 Dec 2020 22:35:47
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 22:35:49
pd.read_sql_query(query3_4, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                    190  Noah
# Tue, 01 Dec 2020 22:36:12
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p
        WHERE c.cID NOT IN (SELECT c.cID
                            FROM customer as c, purchase as p
                            WHERE c.cID NOT IN (SELECT c.cID
                                                FROM customer as c, purchase as p
                                                WHERE p.sID NOT IN ("Jumbo")));
'''
# Tue, 01 Dec 2020 22:36:16
pd.read_sql_query(query3_4, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 22:36:32
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE c.cID NOT IN (SELECT c.cID
                            FROM customer as c, purchase as p
                            WHERE c.cID NOT IN (SELECT c.cID
                                                FROM customer as c, purchase as p
                                                WHERE p.sID NOT IN ("Jumbo")));
'''
# Tue, 01 Dec 2020 22:36:36
pd.read_sql_query(query3_4, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                    190  Noah
# Tue, 01 Dec 2020 23:02:31
query3_3 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN ("Jumbo")
        AND c.cID = p.cID;
'''
# Tue, 01 Dec 2020 23:02:33
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 23:02:37
pd.read_sql_query(query3_3, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                    132  Noah
# Tue, 01 Dec 2020 23:03:00
query3_3 = '''
        SELECT COUNT(DISTINCT c.cID), COUNT(c.cName)
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN ("Jumbo")
        AND c.cID = p.cID;
'''
# Tue, 01 Dec 2020 23:03:02
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 23:03:06
pd.read_sql_query(query3_3, conn)
#[Out]#    COUNT(DISTINCT c.cID)  COUNT(c.cName)
#[Out]# 0                    132             509
# Tue, 01 Dec 2020 23:03:41
query3_3 = '''
        SELECT COUNT(DISTINCT c.cID, c.cName)
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN ("Jumbo")
        AND c.cID = p.cID;
'''
# Tue, 01 Dec 2020 23:03:43
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 23:03:46
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 23:03:52
query3_3 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN ("Jumbo")
        AND c.cID = p.cID;
'''
# Tue, 01 Dec 2020 23:03:54
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 23:03:58
pd.read_sql_query(query3_3, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                    132  Noah
# Tue, 01 Dec 2020 23:04:09
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN ("Jumbo")
        AND c.cID = p.cID;
'''
# Tue, 01 Dec 2020 23:04:14
pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      7      Bram
#[Out]# 7      8      Liam
#[Out]# 8     10       Sam
#[Out]# 9     11     Thijs
#[Out]# 10    13     James
#[Out]# 11    15      Noud
#[Out]# 12    16    Julian
#[Out]# 13    17       Dex
#[Out]# 14    18      Hugo
#[Out]# 15    19      Lars
#[Out]# 16    20      Gijs
#[Out]# 17    21  Benjamin
#[Out]# 18    22      Mats
#[Out]# 19    24      Luca
#[Out]# 20    25     Mason
#[Out]# 21    26    Jayden
#[Out]# 22    27       Tim
#[Out]# 23    28      Siem
#[Out]# 24    29     Ruben
#[Out]# 25    30      Teun
#[Out]# 26    31   Olivier
#[Out]# 27    33      Sven
#[Out]# 28    34     David
#[Out]# 29    35     Stijn
#[Out]# ..   ...       ...
#[Out]# 102  147    Isabel
#[Out]# 103  149     Lizzy
#[Out]# 104  151      Jill
#[Out]# 105  152      Anne
#[Out]# 106  157      Puck
#[Out]# 107  159     Fenne
#[Out]# 108  161     Floor
#[Out]# 109  162     Elena
#[Out]# 110  163      Cato
#[Out]# 111  165     Hanna
#[Out]# 112  167    Veerle
#[Out]# 113  168      Kiki
#[Out]# 114  169      Lily
#[Out]# 115  170      Iris
#[Out]# 116  171     Tessa
#[Out]# 117  172      Lana
#[Out]# 118  175       Sam
#[Out]# 119  176     Amira
#[Out]# 120  177     Eline
#[Out]# 121  178      Elif
#[Out]# 122  179      Juul
#[Out]# 123  180     Merel
#[Out]# 124  181      Liva
#[Out]# 125  182   Johanna
#[Out]# 126  184     Wilko
#[Out]# 127  185      Nick
#[Out]# 128  186    Angela
#[Out]# 129  188      Pino
#[Out]# 130  189      Koen
#[Out]# 131  190    Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 23:05:18
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE c.cID NOT IN (SELECT c.cID
                            FROM customer as c, purchase as p
                            WHERE c.cID NOT IN (SELECT c.cID
                                                FROM customer as c, purchase as p
                                                WHERE p.sID NOT IN ("Jumbo")
                                                AND p.cID = c.cID));
'''
# Tue, 01 Dec 2020 23:05:20
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 23:05:24
pd.read_sql_query(query3_4, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                    132  Noah
# Tue, 01 Dec 2020 23:17:00
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p
        WHERE (c.cID, p.sID) NOT IN (
        SELECT s.sID
        FROM store as s
        WHERE s.sID = "Jumbo")
        AND c.cID = p.cID;
'''
# Tue, 01 Dec 2020 23:17:03
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 23:17:13
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 23:18:26
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN (
        SELECT s.sID
        FROM store as s
        WHERE s.sID = "Jumbo")
        AND c.cID = p.cID;
'''
# Tue, 01 Dec 2020 23:18:29
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 23:18:32
pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      7      Bram
#[Out]# 7      8      Liam
#[Out]# 8     10       Sam
#[Out]# 9     11     Thijs
#[Out]# 10    13     James
#[Out]# 11    15      Noud
#[Out]# 12    16    Julian
#[Out]# 13    17       Dex
#[Out]# 14    18      Hugo
#[Out]# 15    19      Lars
#[Out]# 16    20      Gijs
#[Out]# 17    21  Benjamin
#[Out]# 18    22      Mats
#[Out]# 19    24      Luca
#[Out]# 20    25     Mason
#[Out]# 21    26    Jayden
#[Out]# 22    27       Tim
#[Out]# 23    28      Siem
#[Out]# 24    29     Ruben
#[Out]# 25    30      Teun
#[Out]# 26    31   Olivier
#[Out]# 27    33      Sven
#[Out]# 28    34     David
#[Out]# 29    35     Stijn
#[Out]# ..   ...       ...
#[Out]# 102  147    Isabel
#[Out]# 103  149     Lizzy
#[Out]# 104  151      Jill
#[Out]# 105  152      Anne
#[Out]# 106  157      Puck
#[Out]# 107  159     Fenne
#[Out]# 108  161     Floor
#[Out]# 109  162     Elena
#[Out]# 110  163      Cato
#[Out]# 111  165     Hanna
#[Out]# 112  167    Veerle
#[Out]# 113  168      Kiki
#[Out]# 114  169      Lily
#[Out]# 115  170      Iris
#[Out]# 116  171     Tessa
#[Out]# 117  172      Lana
#[Out]# 118  175       Sam
#[Out]# 119  176     Amira
#[Out]# 120  177     Eline
#[Out]# 121  178      Elif
#[Out]# 122  179      Juul
#[Out]# 123  180     Merel
#[Out]# 124  181      Liva
#[Out]# 125  182   Johanna
#[Out]# 126  184     Wilko
#[Out]# 127  185      Nick
#[Out]# 128  186    Angela
#[Out]# 129  188      Pino
#[Out]# 130  189      Koen
#[Out]# 131  190    Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]

# IPython log file

# Wed, 02 Dec 2020 10:05:42
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 10:05:42
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# IPython log file

# Wed, 02 Dec 2020 10:07:54
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 10:07:58
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 10:08:22
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Wed, 02 Dec 2020 10:08:27
query3_2 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date LIKE "%2018%" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        AND c.cID = p.pID;
'''
# Wed, 02 Dec 2020 10:08:31
vis.visualize(query3_2, schema)
# Wed, 02 Dec 2020 10:08:35
pd.read_sql_query(query3_2, conn)
#[Out]#    cID cName
#[Out]# 0    8  Liam
#[Out]# 1   24  Luca
# Wed, 02 Dec 2020 10:08:39
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p
        WHERE p.sID NOT IN (
        SELECT s.sID
        FROM store as s
        WHERE s.sID = "Jumbo")
        AND c.cID = p.cID;
'''
# Wed, 02 Dec 2020 10:08:42
vis.visualize(query3_3, schema)
# Wed, 02 Dec 2020 10:08:47
pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      7      Bram
#[Out]# 7      8      Liam
#[Out]# 8     10       Sam
#[Out]# 9     11     Thijs
#[Out]# 10    13     James
#[Out]# 11    15      Noud
#[Out]# 12    16    Julian
#[Out]# 13    17       Dex
#[Out]# 14    18      Hugo
#[Out]# 15    19      Lars
#[Out]# 16    20      Gijs
#[Out]# 17    21  Benjamin
#[Out]# 18    22      Mats
#[Out]# 19    24      Luca
#[Out]# 20    25     Mason
#[Out]# 21    26    Jayden
#[Out]# 22    27       Tim
#[Out]# 23    28      Siem
#[Out]# 24    29     Ruben
#[Out]# 25    30      Teun
#[Out]# 26    31   Olivier
#[Out]# 27    33      Sven
#[Out]# 28    34     David
#[Out]# 29    35     Stijn
#[Out]# ..   ...       ...
#[Out]# 102  147    Isabel
#[Out]# 103  149     Lizzy
#[Out]# 104  151      Jill
#[Out]# 105  152      Anne
#[Out]# 106  157      Puck
#[Out]# 107  159     Fenne
#[Out]# 108  161     Floor
#[Out]# 109  162     Elena
#[Out]# 110  163      Cato
#[Out]# 111  165     Hanna
#[Out]# 112  167    Veerle
#[Out]# 113  168      Kiki
#[Out]# 114  169      Lily
#[Out]# 115  170      Iris
#[Out]# 116  171     Tessa
#[Out]# 117  172      Lana
#[Out]# 118  175       Sam
#[Out]# 119  176     Amira
#[Out]# 120  177     Eline
#[Out]# 121  178      Elif
#[Out]# 122  179      Juul
#[Out]# 123  180     Merel
#[Out]# 124  181      Liva
#[Out]# 125  182   Johanna
#[Out]# 126  184     Wilko
#[Out]# 127  185      Nick
#[Out]# 128  186    Angela
#[Out]# 129  188      Pino
#[Out]# 130  189      Koen
#[Out]# 131  190    Kostas
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Wed, 02 Dec 2020 10:08:52
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, purchase as p
        WHERE c.cID NOT IN (SELECT c.cID
                            FROM customer as c, purchase as p
                            WHERE c.cID NOT IN (SELECT c.cID
                                                FROM customer as c, purchase as p
                                                WHERE p.sID NOT IN ("Jumbo")
                                                AND p.cID = c.cID));
'''
# Wed, 02 Dec 2020 10:08:55
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 10:08:59
pd.read_sql_query(query3_4, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                    132  Noah
# Wed, 02 Dec 2020 10:18:50
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p
        WHERE (c.cID, c.cName) NOT IN (SELECT c.cID, c.cName                                       
                                       FROM store as s, costumer as c, purchase as p
                                       WHERE s.sName = "Jumbo"
                                       AND c.cID = p.cID
                                       AND p.sID = s.sID)
        AND c.cID = p.cID;
'''
# Wed, 02 Dec 2020 10:18:53
pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 10:19:12
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p
        WHERE (c.cID, c.cName) NOT IN (SELECT c.cID, c.cName                                       
                                       FROM store as s, customer as c, purchase as p
                                       WHERE s.sName = "Jumbo"
                                       AND c.cID = p.cID
                                       AND p.sID = s.sID)
        AND c.cID = p.cID;
'''
# Wed, 02 Dec 2020 10:19:15
pd.read_sql_query(query3_3, conn)
#[Out]#     cID    cName
#[Out]# 0     0     Noah
#[Out]# 1     1      Sem
#[Out]# 2     2    Lucas
#[Out]# 3     3     Finn
#[Out]# 4     5     Levi
#[Out]# 5     7     Bram
#[Out]# 6     8     Liam
#[Out]# 7    10      Sam
#[Out]# 8    11    Thijs
#[Out]# 9    13    James
#[Out]# 10   15     Noud
#[Out]# 11   16   Julian
#[Out]# 12   17      Dex
#[Out]# 13   20     Gijs
#[Out]# 14   22     Mats
#[Out]# 15   25    Mason
#[Out]# 16   26   Jayden
#[Out]# 17   28     Siem
#[Out]# 18   29    Ruben
#[Out]# 19   30     Teun
#[Out]# 20   31  Olivier
#[Out]# 21   33     Sven
#[Out]# 22   34    David
#[Out]# 23   35    Stijn
#[Out]# 24   39     Jack
#[Out]# 25   41    Quinn
#[Out]# 26   42     Tijn
#[Out]# 27   43      Tom
#[Out]# 28   44    Jason
#[Out]# 29   45     Ryan
#[Out]# ..  ...      ...
#[Out]# 67  128  Jasmijn
#[Out]# 68  129    Esmee
#[Out]# 69  131      Amy
#[Out]# 70  133   Sophia
#[Out]# 71  134     Ella
#[Out]# 72  135    Sofia
#[Out]# 73  137     Lena
#[Out]# 74  139    Elise
#[Out]# 75  144      Ivy
#[Out]# 76  145     Fien
#[Out]# 77  147   Isabel
#[Out]# 78  149    Lizzy
#[Out]# 79  151     Jill
#[Out]# 80  152     Anne
#[Out]# 81  157     Puck
#[Out]# 82  159    Fenne
#[Out]# 83  161    Floor
#[Out]# 84  162    Elena
#[Out]# 85  163     Cato
#[Out]# 86  168     Kiki
#[Out]# 87  169     Lily
#[Out]# 88  170     Iris
#[Out]# 89  175      Sam
#[Out]# 90  176    Amira
#[Out]# 91  177    Eline
#[Out]# 92  178     Elif
#[Out]# 93  179     Juul
#[Out]# 94  181     Liva
#[Out]# 95  182  Johanna
#[Out]# 96  184    Wilko
#[Out]# 
#[Out]# [97 rows x 2 columns]
# Wed, 02 Dec 2020 10:19:41
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID, c.cName) NOT IN (SELECT c.cID, c.cName                                       
                                       FROM store as s, customer as c, purchase as p
                                       WHERE s.sName = "Jumbo"
                                       AND c.cID = p.cID
                                       AND p.sID = s.sID);
'''
# Wed, 02 Dec 2020 10:19:45
pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Wed, 02 Dec 2020 10:20:58
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 10:26:14
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c
                                      WHERE c.cID NOT IN (SELECT c.cID
                                                          FROM customer as c, purchase as p, store as s
                                                          WHERE p.sID = s.sID
                                                          AND s.sName = "Jumbo"
                                                          AND p.cID = c.cID));                                                                                                                                                             
'''
# Wed, 02 Dec 2020 10:26:16
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 10:26:22
pd.read_sql_query(query3_4, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                     35  Daan
# Wed, 02 Dec 2020 10:28:31
query3_4 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c
                                      WHERE c.cID NOT IN (SELECT c.cID
                                                          FROM customer as c, purchase as p, store as s
                                                          WHERE p.sID = s.sID
                                                          AND s.sName = "Jumbo"
                                                          AND p.cID = c.cID));                                                             
'''
# Wed, 02 Dec 2020 10:28:33
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 10:28:39
pd.read_sql_query(query3_4, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                     35  Daan
# Wed, 02 Dec 2020 11:18:27
query3_2 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date LIKE "%2018%" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        ;
'''
# Wed, 02 Dec 2020 11:18:30
pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Wed, 02 Dec 2020 11:18:50
query3_2 = '''
        SELECT COUNT(DISTINCT c.cID), c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date LIKE "%2018%" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        ;
'''
# Wed, 02 Dec 2020 11:18:56
pd.read_sql_query(query3_2, conn)
#[Out]#    COUNT(DISTINCT c.cID) cName
#[Out]# 0                    104   Sem
# Wed, 02 Dec 2020 11:21:29
query3_2 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, shoppinglist as s, purchase as p
        WHERE s.date LIKE "%2018%" 
        AND s.date = p.date 
        AND s.cID = p.cID 
        AND c.cID = s.cID 
        AND c.cID = p.cID;
'''
# Wed, 02 Dec 2020 11:21:32
query3_3 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID, c.cName) NOT IN (SELECT c.cID, c.cName                                       
                                       FROM store as s, customer as c, purchase as p
                                       WHERE s.sName = "Jumbo"
                                       AND c.cID = p.cID
                                       AND p.sID = s.sID);
'''
# Wed, 02 Dec 2020 11:21:36
pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Wed, 02 Dec 2020 11:28:46
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c
                                      WHERE c.cID NOT IN (SELECT c.cID
                                                          FROM customer as c, purchase as p, store as s
                                                          WHERE p.sID = s.sID
                                                          AND s.sName = "Jumbo"
                                                          AND p.cID = c.cID));                                                             
'''
# Wed, 02 Dec 2020 11:28:52
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 11:29:00
pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Wed, 02 Dec 2020 12:20:57
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c, purchase as p, store as s
                                      WHERE p.sID = s.sID
                                      AND s.sName != "Jumbo"
                                      AND p.cID = c.cID));                                                             
'''
# Wed, 02 Dec 2020 12:21:00
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:21:05
pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:21:22
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c, purchase as p, store as s
                                      WHERE p.sID = s.sID
                                      AND s.sName != "Jumbo"
                                      AND p.cID = c.cID);                                                             
'''
# Wed, 02 Dec 2020 12:21:23
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:21:29
pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    47      Xavi
#[Out]# 9    48      Tygo
#[Out]# 10   49       Cas
#[Out]# 11   50       Pim
#[Out]# 12   53       Job
#[Out]# 13   54       Jax
#[Out]# 14   56    Tobias
#[Out]# 15   61    Morris
#[Out]# 16   62      Abel
#[Out]# 17   63      Senn
#[Out]# 18   65    Pepijn
#[Out]# 19   73      Owen
#[Out]# 20   74    Samuel
#[Out]# 21   79    Joshua
#[Out]# 22   81     Simon
#[Out]# 23   83     Melle
#[Out]# 24   87     Jelle
#[Out]# 25   89  Johannes
#[Out]# 26   93     Oscar
#[Out]# 27   98     Julia
#[Out]# 28  101       Eva
#[Out]# 29  102       Evi
#[Out]# ..  ...       ...
#[Out]# 36  117      Roos
#[Out]# 37  120     Sarah
#[Out]# 38  121       Isa
#[Out]# 39  125       Noa
#[Out]# 40  130     Sanne
#[Out]# 41  132    Hannah
#[Out]# 42  136     Femke
#[Out]# 43  138     Maria
#[Out]# 44  140      Vera
#[Out]# 45  141       Mia
#[Out]# 46  142        Bo
#[Out]# 47  143     Naomi
#[Out]# 48  146     Norah
#[Out]# 49  148  Isabella
#[Out]# 50  150     Julie
#[Out]# 51  153     Amber
#[Out]# 52  154    Benthe
#[Out]# 53  155     Linde
#[Out]# 54  156      Luna
#[Out]# 55  158      Rosa
#[Out]# 56  160      Lara
#[Out]# 57  164       Evy
#[Out]# 58  166   Rosalie
#[Out]# 59  173     Livia
#[Out]# 60  174      Romy
#[Out]# 61  183     Nikki
#[Out]# 62  185      Nick
#[Out]# 63  186    Angela
#[Out]# 64  188      Pino
#[Out]# 65  189      Koen
#[Out]# 
#[Out]# [66 rows x 2 columns]
# Wed, 02 Dec 2020 12:25:03
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p, store as s
        WHERE (c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c, purchase as p, store as s
                                      WHERE p.sID = s.sID
                                      AND s.sName != "Jumbo"
                                      AND p.cID = c.cID)
        AND s.sName = "Jumbo"
        AND s.sID = p.pID
        AND p.cID = c.cID;                                                             
'''
# Wed, 02 Dec 2020 12:25:05
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:25:15
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:25:43
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p, store as s
        WHERE AND s.sName = "Jumbo"
        AND s.sID = p.pID
        AND p.cID = c.cID (c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c, purchase as p, store as s
                                      WHERE p.sID = s.sID
                                      AND s.sName != "Jumbo"
                                      AND p.cID = c.cID)
       ;                                                             
'''
# Wed, 02 Dec 2020 12:25:46
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:25:49
pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:26:07
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p, store as s
        WHERE  s.sName = "Jumbo"
        AND s.sID = p.pID
        AND p.cID = c.cID  AND(c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c, purchase as p, store as s
                                      WHERE p.sID = s.sID
                                      AND s.sName != "Jumbo"
                                      AND p.cID = c.cID)
       ;                                                             
'''
# Wed, 02 Dec 2020 12:26:09
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:26:15
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:29:50
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c
                                      WHERE c.cID NOT IN (SELECT c.cID
                                                          FROM customer as c, purchase as p, store as s
                                                          WHERE p.sID = s.sID
                                                          AND s.sName = "Jumbo"
                                                          AND p.cID = c.cID));                                                             
'''
# Wed, 02 Dec 2020 12:29:52
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:29:56
pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Wed, 02 Dec 2020 12:30:52
query3_4 = '''
        SELECT DISTINCT c.cID, DISTINCT c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT c.cID, c.cName
                                      FROM customer as c
                                      WHERE c.cID NOT IN (SELECT c.cID
                                                          FROM customer as c, purchase as p, store as s
                                                          WHERE p.sID = s.sID
                                                          AND s.sName = "Jumbo"
                                                          AND p.cID = c.cID));                                                             
'''
# Wed, 02 Dec 2020 12:30:57
pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:31:16
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT DISTINCT c.cID, c.cName
                                      FROM customer as c
                                      WHERE c.cID NOT IN (SELECT c.cID
                                                          FROM customer as c, purchase as p, store as s
                                                          WHERE p.sID = s.sID
                                                          AND s.sName = "Jumbo"
                                                          AND p.cID = c.cID));                                                             
'''
# Wed, 02 Dec 2020 12:31:19
pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Wed, 02 Dec 2020 12:31:28
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT DISTINCT c.cID, c.cName
                                      FROM customer as c
                                      WHERE c.cID NOT IN (SELECT DISTINCT c.cID
                                                          FROM customer as c, purchase as p, store as s
                                                          WHERE p.sID = s.sID
                                                          AND s.sName = "Jumbo"
                                                          AND p.cID = c.cID));                                                             
'''
# Wed, 02 Dec 2020 12:31:32
pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Wed, 02 Dec 2020 12:38:04
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT DISTINCT c.cID, c.cName
                                      FROM customer as c, purchase as p, store as s
                                      WHERE p.sID = s.sID
                                      AND s.sName != "Jumbo"
                                      AND p.cID = c.cID));                                                             
'''
# Wed, 02 Dec 2020 12:38:07
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:38:10
pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 12:38:16
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c
        WHERE (c.cID,c.cName) NOT IN (SELECT DISTINCT c.cID, c.cName
                                      FROM customer as c, purchase as p, store as s
                                      WHERE p.sID = s.sID
                                      AND s.sName != "Jumbo"
                                      AND p.cID = c.cID);                                                             
'''
# Wed, 02 Dec 2020 12:38:18
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:38:22
pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    47      Xavi
#[Out]# 9    48      Tygo
#[Out]# 10   49       Cas
#[Out]# 11   50       Pim
#[Out]# 12   53       Job
#[Out]# 13   54       Jax
#[Out]# 14   56    Tobias
#[Out]# 15   61    Morris
#[Out]# 16   62      Abel
#[Out]# 17   63      Senn
#[Out]# 18   65    Pepijn
#[Out]# 19   73      Owen
#[Out]# 20   74    Samuel
#[Out]# 21   79    Joshua
#[Out]# 22   81     Simon
#[Out]# 23   83     Melle
#[Out]# 24   87     Jelle
#[Out]# 25   89  Johannes
#[Out]# 26   93     Oscar
#[Out]# 27   98     Julia
#[Out]# 28  101       Eva
#[Out]# 29  102       Evi
#[Out]# ..  ...       ...
#[Out]# 36  117      Roos
#[Out]# 37  120     Sarah
#[Out]# 38  121       Isa
#[Out]# 39  125       Noa
#[Out]# 40  130     Sanne
#[Out]# 41  132    Hannah
#[Out]# 42  136     Femke
#[Out]# 43  138     Maria
#[Out]# 44  140      Vera
#[Out]# 45  141       Mia
#[Out]# 46  142        Bo
#[Out]# 47  143     Naomi
#[Out]# 48  146     Norah
#[Out]# 49  148  Isabella
#[Out]# 50  150     Julie
#[Out]# 51  153     Amber
#[Out]# 52  154    Benthe
#[Out]# 53  155     Linde
#[Out]# 54  156      Luna
#[Out]# 55  158      Rosa
#[Out]# 56  160      Lara
#[Out]# 57  164       Evy
#[Out]# 58  166   Rosalie
#[Out]# 59  173     Livia
#[Out]# 60  174      Romy
#[Out]# 61  183     Nikki
#[Out]# 62  185      Nick
#[Out]# 63  186    Angela
#[Out]# 64  188      Pino
#[Out]# 65  189      Koen
#[Out]# 
#[Out]# [66 rows x 2 columns]
# Wed, 02 Dec 2020 12:40:46
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
        AND p.sID = s.sID
        AND s.sName = "Jumbo"
        AND c.cID NOT IN (SELECT DISTINCT c.cID
                          FROM customer as c, purchase as p, store as s
                          WHERE p.sID = s.sID
                          AND s.sName != "Jumbo"
                          AND p.cID = c.cID);                                                             
'''
# Wed, 02 Dec 2020 12:40:51
pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Wed, 02 Dec 2020 12:40:56
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:41:14
query3_4 = '''
        SELECT DISTINCT c.cID, c.cName
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
        AND p.sID = s.sID
        AND s.sName = "Jumbo"
        AND c.cID NOT IN (SELECT DISTINCT c.cID
                          FROM customer as c, purchase as p, store as s
                          WHERE p.sID = s.sID
                          AND s.sName != "Jumbo"
                          AND p.cID = c.cID);                                                             
'''
# Wed, 02 Dec 2020 12:41:15
vis.visualize(query3_4, schema)
# Wed, 02 Dec 2020 12:41:18
pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen


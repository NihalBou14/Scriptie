# IPython log file

# Sat, 28 Nov 2020 22:05:21
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

# Sat, 28 Nov 2020 22:05:31
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:05:37
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Sat, 28 Nov 2020 22:05:43
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:05:45
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# IPython log file

# Sat, 28 Nov 2020 22:08:22
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:08:22
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# IPython log file

# Sat, 28 Nov 2020 22:08:37
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:08:37
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Sat, 28 Nov 2020 22:10:15
cur
#[Out]# <sqlite3.Cursor at 0x1b5b382a030>
# Sat, 28 Nov 2020 22:10:20
dir(cur)
#[Out]# ['__class__',
#[Out]#  '__delattr__',
#[Out]#  '__dir__',
#[Out]#  '__doc__',
#[Out]#  '__eq__',
#[Out]#  '__format__',
#[Out]#  '__ge__',
#[Out]#  '__getattribute__',
#[Out]#  '__gt__',
#[Out]#  '__hash__',
#[Out]#  '__init__',
#[Out]#  '__init_subclass__',
#[Out]#  '__iter__',
#[Out]#  '__le__',
#[Out]#  '__lt__',
#[Out]#  '__ne__',
#[Out]#  '__new__',
#[Out]#  '__next__',
#[Out]#  '__reduce__',
#[Out]#  '__reduce_ex__',
#[Out]#  '__repr__',
#[Out]#  '__setattr__',
#[Out]#  '__sizeof__',
#[Out]#  '__str__',
#[Out]#  '__subclasshook__',
#[Out]#  'arraysize',
#[Out]#  'close',
#[Out]#  'connection',
#[Out]#  'description',
#[Out]#  'execute',
#[Out]#  'executemany',
#[Out]#  'executescript',
#[Out]#  'fetchall',
#[Out]#  'fetchmany',
#[Out]#  'fetchone',
#[Out]#  'lastrowid',
#[Out]#  'row_factory',
#[Out]#  'rowcount',
#[Out]#  'setinputsizes',
#[Out]#  'setoutputsize']
# Sat, 28 Nov 2020 22:11:00
cur.connection
#[Out]# <sqlite3.Connection at 0x1b5b38221f0>
# Sat, 28 Nov 2020 22:11:06
dir(cur.connection)
#[Out]# ['DataError',
#[Out]#  'DatabaseError',
#[Out]#  'Error',
#[Out]#  'IntegrityError',
#[Out]#  'InterfaceError',
#[Out]#  'InternalError',
#[Out]#  'NotSupportedError',
#[Out]#  'OperationalError',
#[Out]#  'ProgrammingError',
#[Out]#  'Warning',
#[Out]#  '__call__',
#[Out]#  '__class__',
#[Out]#  '__delattr__',
#[Out]#  '__dir__',
#[Out]#  '__doc__',
#[Out]#  '__enter__',
#[Out]#  '__eq__',
#[Out]#  '__exit__',
#[Out]#  '__format__',
#[Out]#  '__ge__',
#[Out]#  '__getattribute__',
#[Out]#  '__gt__',
#[Out]#  '__hash__',
#[Out]#  '__init__',
#[Out]#  '__init_subclass__',
#[Out]#  '__le__',
#[Out]#  '__lt__',
#[Out]#  '__ne__',
#[Out]#  '__new__',
#[Out]#  '__reduce__',
#[Out]#  '__reduce_ex__',
#[Out]#  '__repr__',
#[Out]#  '__setattr__',
#[Out]#  '__sizeof__',
#[Out]#  '__str__',
#[Out]#  '__subclasshook__',
#[Out]#  'backup',
#[Out]#  'close',
#[Out]#  'commit',
#[Out]#  'create_aggregate',
#[Out]#  'create_collation',
#[Out]#  'create_function',
#[Out]#  'cursor',
#[Out]#  'enable_load_extension',
#[Out]#  'execute',
#[Out]#  'executemany',
#[Out]#  'executescript',
#[Out]#  'in_transaction',
#[Out]#  'interrupt',
#[Out]#  'isolation_level',
#[Out]#  'iterdump',
#[Out]#  'load_extension',
#[Out]#  'rollback',
#[Out]#  'row_factory',
#[Out]#  'set_authorizer',
#[Out]#  'set_progress_handler',
#[Out]#  'set_trace_callback',
#[Out]#  'text_factory',
#[Out]#  'total_changes']
# Sat, 28 Nov 2020 22:11:20
help(cur)
# Sat, 28 Nov 2020 22:11:32
help(sql)
# Sat, 28 Nov 2020 22:11:53
cur
#[Out]# <sqlite3.Cursor at 0x1b5b382a030>
# Sat, 28 Nov 2020 22:11:58
help(cur)
# Sat, 28 Nov 2020 22:12:36
query3_2 = '''
    SELECT cID
    FROM customer;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 179  179
#[Out]# 180  180
#[Out]# 181  181
#[Out]# 182  182
#[Out]# 183  183
#[Out]# 
#[Out]# [184 rows x 1 columns]
# Sat, 28 Nov 2020 22:12:43
query3_2 = '''
    SELECT cIDs
    FROM customer;
'''

pd.read_sql_query(query3_2, conn)
# Sat, 28 Nov 2020 22:12:51
query3_2 = '''
    SELECT cID
    FROM customer;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 179  179
#[Out]# 180  180
#[Out]# 181  181
#[Out]# 182  182
#[Out]# 183  183
#[Out]# 
#[Out]# [184 rows x 1 columns]
# Sat, 28 Nov 2020 22:13:05
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      4     Daan
#[Out]# ..   ...      ...
#[Out]# 179  179     Juul
#[Out]# 180  180    Merel
#[Out]# 181  181     Liva
#[Out]# 182  182  Johanna
#[Out]# 183  183    Nikki
#[Out]# 
#[Out]# [184 rows x 2 columns]
# Sat, 28 Nov 2020 22:18:56
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%);
'''
pd.read_sql_query(query3_2, conn)
# Sat, 28 Nov 2020 22:19:15
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%');
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   25     Mason
#[Out]# 18   26    Jayden
#[Out]# 19   27       Tim
#[Out]# 20   28      Siem
#[Out]# 21   29     Ruben
#[Out]# 22   30      Teun
#[Out]# 23   31   Olivier
#[Out]# 24   33      Sven
# Sat, 28 Nov 2020 22:20:38
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%')
    AND EXISTS   (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND date LIKE '%2018%');
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   25     Mason
#[Out]# 18   26    Jayden
#[Out]# 19   27       Tim
#[Out]# 20   28      Siem
#[Out]# 21   29     Ruben
#[Out]# 22   30      Teun
#[Out]# 23   31   Olivier
#[Out]# 24   33      Sven
# Sat, 28 Nov 2020 22:24:47
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   25     Mason
#[Out]# 18   26    Jayden
#[Out]# 19   27       Tim
#[Out]# 20   28      Siem
#[Out]# 21   29     Ruben
#[Out]# 22   30      Teun
#[Out]# 23   31   Olivier
#[Out]# 24   33      Sven
# Sat, 28 Nov 2020 22:25:29
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.pID=p.pID
                  AND date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   25     Mason
#[Out]# 18   26    Jayden
#[Out]# 19   27       Tim
#[Out]# 20   28      Siem
#[Out]# 21   29     Ruben
#[Out]# 22   30      Teun
#[Out]# 23   31   Olivier
#[Out]# 24   33      Sven
# Sat, 28 Nov 2020 22:25:41
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.pID=p.pID));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   25     Mason
#[Out]# 18   26    Jayden
#[Out]# 19   27       Tim
#[Out]# 20   28      Siem
#[Out]# 21   29     Ruben
#[Out]# 22   30      Teun
#[Out]# 23   31   Olivier
#[Out]# 24   33      Sven
# Sat, 28 Nov 2020 22:26:11
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.pID=p.pID
                  AND s.date=p.date));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:26:20
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.pID=p.pID));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   25     Mason
#[Out]# 18   26    Jayden
#[Out]# 19   27       Tim
#[Out]# 20   28      Siem
#[Out]# 21   29     Ruben
#[Out]# 22   30      Teun
#[Out]# 23   31   Olivier
#[Out]# 24   33      Sven
# Sat, 28 Nov 2020 22:26:29
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.pID=p.pID
                  AND s.date=p.date
                  AND date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:26:47
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.date=p.date));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:27:11
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.date=p.date));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   25     Mason
#[Out]# 18   26    Jayden
#[Out]# 19   27       Tim
#[Out]# 20   28      Siem
#[Out]# 21   29     Ruben
#[Out]# 22   30      Teun
#[Out]# 23   31   Olivier
#[Out]# 24   33      Sven
# Sat, 28 Nov 2020 22:27:15
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.date=p.date));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:27:20
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.pID=p.pID
                  AND s.date=p.date));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:27:35
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.date=p.date));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   25     Mason
#[Out]# 18   26    Jayden
#[Out]# 19   27       Tim
#[Out]# 20   28      Siem
#[Out]# 21   29     Ruben
#[Out]# 22   30      Teun
#[Out]# 23   31   Olivier
#[Out]# 24   33      Sven
# Sat, 28 Nov 2020 22:27:38
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.date=p.date));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:27:40
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.date=p.date));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:27:55
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.date=p.date
                  AND date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:28:11
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE c.cID = p.cID
                  AND s.date=p.date
                  AND p.date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:29:16
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.pID = p.pID
                  AND s.date=p.date
                  AND p.date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven
# Sat, 28 Nov 2020 22:31:21
customers = '''
    SELECT DISTINCT cID, cName
    FROM customer c
'''

pd.read_sql_query(customers, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      4     Daan
#[Out]# ..   ...      ...
#[Out]# 179  179     Juul
#[Out]# 180  180    Merel
#[Out]# 181  181     Liva
#[Out]# 182  182  Johanna
#[Out]# 183  183    Nikki
#[Out]# 
#[Out]# [184 rows x 2 columns]
# Sat, 28 Nov 2020 22:33:46
query = '''
    SELECT cID
    FROM shoppinglist
'''
pd.read_sql_query(query, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     1
#[Out]# 2     1
#[Out]# 3     1
#[Out]# 4     1
#[Out]# ..  ...
#[Out]# 93   30
#[Out]# 94   30
#[Out]# 95   31
#[Out]# 96   31
#[Out]# 97   33
#[Out]# 
#[Out]# [98 rows x 1 columns]
# Sat, 28 Nov 2020 22:33:54
query = '''
    SELECT cID
    FROM shoppinglist
    WHERE cID = 1
'''
pd.read_sql_query(query, conn)
#[Out]#    cID
#[Out]# 0    1
#[Out]# 1    1
#[Out]# 2    1
#[Out]# 3    1
#[Out]# 4    1
#[Out]# 5    1
#[Out]# 6    1
#[Out]# 7    1
# Sat, 28 Nov 2020 22:34:02
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 1
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0    1  2018-08-20
#[Out]# 1    1  2018-08-20
#[Out]# 2    1  2018-08-20
#[Out]# 3    1  2018-08-20
#[Out]# 4    1  2018-08-20
#[Out]# 5    1  2018-08-20
#[Out]# 6    1  2018-08-20
#[Out]# 7    1  2018-08-21
# Sat, 28 Nov 2020 22:34:37
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 1
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0    1  2018-08-20
#[Out]# 1    1  2018-08-20
#[Out]# 2    1  2018-08-20
#[Out]# 3    1  2018-08-20
#[Out]# 4    1  2018-08-20
#[Out]# 5    1  2018-08-21
#[Out]# 6    1  2018-08-21
# Sat, 28 Nov 2020 22:34:54
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 2
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0    2  2018-08-16
#[Out]# 1    2  2018-08-17
#[Out]# 2    2  2018-08-17
#[Out]# 3    2  2018-08-17
#[Out]# 4    2  2018-08-17
# Sat, 28 Nov 2020 22:34:57
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 2
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0    2  2018-08-17
#[Out]# 1    2  2018-08-16
#[Out]# 2    2  2018-08-17
#[Out]# 3    2  2018-08-16
#[Out]# 4    2  2018-08-17
# Sat, 28 Nov 2020 22:35:09
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 3
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0    3  2018-08-19
#[Out]# 1    3  2018-08-18
#[Out]# 2    3  2018-08-18
# Sat, 28 Nov 2020 22:35:09
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 3
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0    3  2018-08-18
#[Out]# 1    3  2018-08-19
#[Out]# 2    3  2018-08-19
# Sat, 28 Nov 2020 22:35:18
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 4
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:35:18
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 4
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0    4  2018-08-24
#[Out]# 1    4  2018-08-24
#[Out]# 2    4  2018-08-25
#[Out]# 3    4  2018-08-24
#[Out]# 4    4  2018-08-25
#[Out]# 5    4  2018-08-25
# Sat, 28 Nov 2020 22:35:24
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 5
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0    5  2018-08-22
#[Out]# 1    5  2018-08-17
#[Out]# 2    5  2018-08-23
#[Out]# 3    5  2018-08-23
#[Out]# 4    5  2018-08-23
#[Out]# 5    5  2018-08-22
# Sat, 28 Nov 2020 22:35:24
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 5
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0    5  2018-08-17
#[Out]# 1    5  2018-08-22
#[Out]# 2    5  2018-08-23
#[Out]# 3    5  2018-08-23
#[Out]# 4    5  2018-08-23
#[Out]# 5    5  2018-08-23
# Sat, 28 Nov 2020 22:35:38
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 6
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:35:38
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 6
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:35:41
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 6
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:35:41
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 6
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:35:54
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 9
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:35:55
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 9
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:36:27
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 100
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:36:27
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 100
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:36:36
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 105
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:36:36
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 105
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:40:01
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 181
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:40:02
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 181
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []

# IPython log file

# Sat, 28 Nov 2020 22:43:03
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:43:03
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Sat, 28 Nov 2020 22:43:09
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 181
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:43:10
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 181
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:43:16
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 181
'''
pd.read_sql_query(query, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Sat, 28 Nov 2020 22:43:33
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.pID = p.pID
                  AND s.date=p.date
                  AND p.date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     5      Levi
#[Out]# 4     7      Bram
#[Out]# 5     8      Liam
#[Out]# 6    10       Sam
#[Out]# 7    11     Thijs
#[Out]# 8    13     James
#[Out]# 9    15      Noud
#[Out]# 10   17       Dex
#[Out]# 11   18      Hugo
#[Out]# 12   19      Lars
#[Out]# 13   20      Gijs
#[Out]# 14   21  Benjamin
#[Out]# 15   22      Mats
#[Out]# 16   24      Luca
#[Out]# 17   26    Jayden
#[Out]# 18   27       Tim
#[Out]# 19   28      Siem
#[Out]# 20   29     Ruben
#[Out]# 21   30      Teun
#[Out]# 22   31   Olivier
#[Out]# 23   33      Sven

# IPython log file

# Sat, 28 Nov 2020 22:44:22
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 22:44:22
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x18da00c91f0>
# Sat, 28 Nov 2020 22:47:54
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 181
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0  181  2018-08-27
#[Out]# 1  181  2018-08-24
#[Out]# 2  181  2018-08-27
#[Out]# 3  181  2018-08-24
# Sat, 28 Nov 2020 22:47:54
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 181
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0  181  2018-08-24
#[Out]# 1  181  2018-08-24
#[Out]# 2  181  2018-08-27
# Sat, 28 Nov 2020 22:47:54
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.pID = p.pID
                  AND s.date=p.date
                  AND p.date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID  cName
#[Out]# 0     1    Sem
#[Out]# 1     2  Lucas
#[Out]# 2     3   Finn
#[Out]# 3     5   Levi
#[Out]# 4     7   Bram
#[Out]# ..  ...    ...
#[Out]# 94  176  Amira
#[Out]# 95  178   Elif
#[Out]# 96  179   Juul
#[Out]# 97  180  Merel
#[Out]# 98  181   Liva
#[Out]# 
#[Out]# [99 rows x 2 columns]
# Sat, 28 Nov 2020 22:47:54
query3_3 = '''
    PUT YOUR QUERY HERE
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 22:52:11
query = '''
    SELECT cID, date
    FROM shoppinglist
    WHERE cID = 38
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0   38  2018-08-15
#[Out]# 1   38  2018-08-18
#[Out]# 2   38  2018-08-18
#[Out]# 3   38  2018-08-17
# Sat, 28 Nov 2020 22:52:11
query = '''
    SELECT cID, date
    FROM purchase
    WHERE cID = 38
'''
pd.read_sql_query(query, conn)
#[Out]#    cID        date
#[Out]# 0   38  2018-08-18
#[Out]# 1   38  2018-08-19
# Sat, 28 Nov 2020 22:54:51
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE cID IN (SELECT cID
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.pID = p.pID
                  AND s.date=p.date
                  AND p.date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID  cName
#[Out]# 0     1    Sem
#[Out]# 1     2  Lucas
#[Out]# 2     3   Finn
#[Out]# 3     5   Levi
#[Out]# 4     7   Bram
#[Out]# ..  ...    ...
#[Out]# 94  176  Amira
#[Out]# 95  178   Elif
#[Out]# 96  179   Juul
#[Out]# 97  180  Merel
#[Out]# 98  181   Liva
#[Out]# 
#[Out]# [99 rows x 2 columns]
# Sat, 28 Nov 2020 22:55:05
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE cID IN (SELECT cID
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND cID IN (SELECT *
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.pID = p.pID
                  AND s.date=p.date
                  AND p.date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
# Sat, 28 Nov 2020 22:55:27
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE cID IN (SELECT cID
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND cID IN (SELECT cID
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.pID = p.pID
                  AND s.date=p.date
                  AND p.date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#     cID  cName
#[Out]# 0     1    Sem
#[Out]# 1     2  Lucas
#[Out]# 2     3   Finn
#[Out]# 3     5   Levi
#[Out]# 4     7   Bram
#[Out]# ..  ...    ...
#[Out]# 94  176  Amira
#[Out]# 95  178   Elif
#[Out]# 96  179   Juul
#[Out]# 97  180  Merel
#[Out]# 98  181   Liva
#[Out]# 
#[Out]# [99 rows x 2 columns]
# Sat, 28 Nov 2020 22:56:28
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.date=p.date
                  AND p.date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sat, 28 Nov 2020 22:57:06
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.date=p.date
                  AND p.date LIKE '%2018%'));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sat, 28 Nov 2020 22:57:15
query3_2 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.date=p.date));
'''
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sat, 28 Nov 2020 23:00:13
query3_2_1 = '''
    SELECT DISTINCT cID, cName
    FROM customer c
    WHERE EXISTS (SELECT *
                  FROM shoppinglist s
                  WHERE c.cID = s.cID
                  AND date LIKE '%2018%'
                  AND EXISTS (SELECT *
                  FROM purchase p
                  WHERE s.cID = p.cID
                  AND s.date=p.date));
'''

query3_2_2 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, shoppinglist as s, purchase as p
    WHERE c.cID = s.cID AND c.cID = p.cID AND p.date LIKE '%2018%' AND p.date = s.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sat, 28 Nov 2020 23:09:26
query3_3 = '''
    (SELECT cID, cName
     FROM customer)
     EXCEPT
     SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = purchase.sID
     AND s.sName = "Kumar") 
    UNION
    ((SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID))
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:09:51
query3_3 = '''
    ((SELECT cID, cName
     FROM customer)
     EXCEPT
     (SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = purchase.sID
     AND s.sName = "Kumar"))
    UNION
    ((SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID))
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:11:58
query3_3 = '''
    ((SELECT cID, cName
     FROM customer)
     EXCEPT
     (SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"))
    UNION
    ((SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID))
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:12:51
query3_3 = '''
    (SELECT cID, cName
     FROM customer)
     EXCEPT
     (SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar")
    UNION
    ((SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID))
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:12:56
query3_3 = '''
    (SELECT cID, cName
     FROM customer)
     EXCEPT
     (SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar")
    UNION
    (SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID)
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:13:04
query3_3 = '''
    ((SELECT cID, cName
     FROM customer)
     EXCEPT
     (SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"))
    UNION
    ((SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID))
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:15:11
query3_3 = '''
    ((SELECT cID, cName
     FROM customer)
     EXCEPT
     (SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"))
    UNION
    ((SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID));
'''

# query3_3 = '''
#     (SELECT cID, cName
#     FROM customer)
#     EXCEPT
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:16:19
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    (SELECT cID, cName
    FROM customer)
    EXCEPT
     
    ((SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar")
     UNION
    ((SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID))
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:16:36
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    (SELECT cID, cName
    FROM customer)
    EXCEPT
    SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:16:41
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT cID, cName
    FROM customer
    EXCEPT
    SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:16:47
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    (SELECT cID, cName
    FROM customer)
    EXCEPT
    SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:17:04
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:17:09
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sat, 28 Nov 2020 23:17:46
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
     EXCEPT
     (SELECT cID, cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"))
    UNION
    ((SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID))
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:17:55
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    (SELECT c.cID, c.cName
     FROM customer c, store s, purchase p
     WHERE c.cID = p.cID
     AND s.sID = p.sID
     AND s.sName = "Kumar"))
    UNION
    ((SELECT cID, cName
      FROM customer)
      EXCEPT
      (SELECT cID, cName
      FROM customer c, purchase p
      WHERE c.cID = p.cID))
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:18:18
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    (SELECT cID, cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID))
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:18:20
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    (SELECT cID, cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:18:25
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT cID, cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:18:39
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sat, 28 Nov 2020 23:18:49
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sat, 28 Nov 2020 23:18:53
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sat, 28 Nov 2020 23:19:33
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sat, 28 Nov 2020 23:19:38
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sat, 28 Nov 2020 23:20:10
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    UNION
    (SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID)
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:27:21
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sat, 28 Nov 2020 23:27:39
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# ..   ...      ...
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sat, 28 Nov 2020 23:27:49
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sat, 28 Nov 2020 23:27:59
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sat, 28 Nov 2020 23:28:06
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# ..   ...      ...
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sat, 28 Nov 2020 23:28:21
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    UNION
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sat, 28 Nov 2020 23:28:49
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    UNION
    (SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID)
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 23:29:03
# query3_3 = '''
#     ((SELECT cID, cName
#      FROM customer)
#      EXCEPT
#      (SELECT cID, cName
#      FROM customer c, store s, purchase p
#      WHERE c.cID = p.cID
#      AND s.sID = p.sID
#      AND s.sName = "Kumar"))
#     UNION
#     ((SELECT cID, cName
#       FROM customer)
#       EXCEPT
#       (SELECT cID, cName
#       FROM customer c, purchase p
#       WHERE c.cID = p.cID))
# '''

query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# ..   ...      ...
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sat, 28 Nov 2020 23:31:53
query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# ..   ...      ...
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sat, 28 Nov 2020 23:33:08
query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sat, 28 Nov 2020 23:34:04
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sat, 28 Nov 2020 23:36:48
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c
    EXCEPT
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sat, 28 Nov 2020 23:37:04
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:37:12
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    19      Lars
#[Out]# 4    21  Benjamin
#[Out]# 5    24      Luca
#[Out]# 6    27       Tim
#[Out]# 7    37      Guus
#[Out]# 8    38    Floris
#[Out]# 9    40      Jens
#[Out]# 10   47      Xavi
#[Out]# 11   52    Willem
#[Out]# 12   59      Joep
#[Out]# 13   63      Senn
#[Out]# 14   66   Mohamed
#[Out]# 15   68     Boris
#[Out]# 16   72      Dani
#[Out]# 17   78      Mick
#[Out]# 18   85    Pieter
#[Out]# 19   86      Stef
#[Out]# 20  104       Liv
#[Out]# 21  109      Lynn
#[Out]# 22  112      Yara
#[Out]# 23  122      Elin
#[Out]# 24  126      Lina
#[Out]# 25  136     Femke
#[Out]# 26  165     Hanna
#[Out]# 27  167    Veerle
#[Out]# 28  171     Tessa
#[Out]# 29  172      Lana
#[Out]# 30  180     Merel
#[Out]# 31  185      Nick
#[Out]# 32  186    Angela
#[Out]# 33  188      Pino
#[Out]# 34  188      Pino
#[Out]# 35  189      Koen
#[Out]# 36  189      Koen
#[Out]# 37  190    Kostas
#[Out]# 38  190    Kostas
#[Out]# 39  190    Kostas
#[Out]# 40  190    Kostas
#[Out]# 41  190    Kostas
#[Out]# 42  190    Kostas
#[Out]# 43  190    Kostas
#[Out]# 44  190    Kostas
# Sat, 28 Nov 2020 23:39:29
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:39:33
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:39:43
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT c1.cID
                    FROM customer c1, store s1, purchase p1
                    WHERE s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:39:50
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND c.cID NOT IN (SELECT c1.cID
                    FROM customer c1, store s1, purchase p1
                    WHERE s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:39:54
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT c1.cID
                    FROM customer c1, store s1, purchase p1
                    WHERE s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:39:57
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:40:03
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:40:10
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:40:32
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE c1.cID = p1.cID
                    AND s1.sID = p1.sID
                    WHERE s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
# Sat, 28 Nov 2020 23:40:35
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE c1.cID = p1.cID
                    AND s1.sID = p1.sID
                    WHERE s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
# Sat, 28 Nov 2020 23:40:39
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE c1.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:41:14
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:41:37
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:42:12
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:42:13
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:42:19
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID   cName
#[Out]# 0     1     Sem
#[Out]# 1     1     Sem
#[Out]# 2     1     Sem
#[Out]# 3     2   Lucas
#[Out]# 4     5    Levi
#[Out]# ..  ...     ...
#[Out]# 59  190  Kostas
#[Out]# 60  190  Kostas
#[Out]# 61  190  Kostas
#[Out]# 62  190  Kostas
#[Out]# 63  190  Kostas
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 28 Nov 2020 23:42:24
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s1.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:42:27
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID   cName
#[Out]# 0     1     Sem
#[Out]# 1     1     Sem
#[Out]# 2     1     Sem
#[Out]# 3     2   Lucas
#[Out]# 4     5    Levi
#[Out]# ..  ...     ...
#[Out]# 59  190  Kostas
#[Out]# 60  190  Kostas
#[Out]# 61  190  Kostas
#[Out]# 62  190  Kostas
#[Out]# 63  190  Kostas
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 28 Nov 2020 23:42:41
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID)
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:42:42
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID   cName
#[Out]# 0     1     Sem
#[Out]# 1     1     Sem
#[Out]# 2     1     Sem
#[Out]# 3     2   Lucas
#[Out]# 4     5    Levi
#[Out]# ..  ...     ...
#[Out]# 59  190  Kostas
#[Out]# 60  190  Kostas
#[Out]# 61  190  Kostas
#[Out]# 62  190  Kostas
#[Out]# 63  190  Kostas
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 28 Nov 2020 23:43:04
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    19      Lars
#[Out]# 4    21  Benjamin
#[Out]# 5    24      Luca
#[Out]# 6    27       Tim
#[Out]# 7    37      Guus
#[Out]# 8    38    Floris
#[Out]# 9    40      Jens
#[Out]# 10   47      Xavi
#[Out]# 11   52    Willem
#[Out]# 12   59      Joep
#[Out]# 13   63      Senn
#[Out]# 14   66   Mohamed
#[Out]# 15   68     Boris
#[Out]# 16   72      Dani
#[Out]# 17   78      Mick
#[Out]# 18   85    Pieter
#[Out]# 19   86      Stef
#[Out]# 20  104       Liv
#[Out]# 21  109      Lynn
#[Out]# 22  112      Yara
#[Out]# 23  122      Elin
#[Out]# 24  126      Lina
#[Out]# 25  136     Femke
#[Out]# 26  165     Hanna
#[Out]# 27  167    Veerle
#[Out]# 28  171     Tessa
#[Out]# 29  172      Lana
#[Out]# 30  180     Merel
#[Out]# 31  185      Nick
#[Out]# 32  186    Angela
#[Out]# 33  188      Pino
#[Out]# 34  188      Pino
#[Out]# 35  189      Koen
#[Out]# 36  189      Koen
#[Out]# 37  190    Kostas
#[Out]# 38  190    Kostas
#[Out]# 39  190    Kostas
#[Out]# 40  190    Kostas
#[Out]# 41  190    Kostas
#[Out]# 42  190    Kostas
#[Out]# 43  190    Kostas
#[Out]# 44  190    Kostas
# Sat, 28 Nov 2020 23:43:12
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:43:19
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    19      Lars
#[Out]# 4    21  Benjamin
#[Out]# 5    24      Luca
#[Out]# 6    27       Tim
#[Out]# 7    37      Guus
#[Out]# 8    38    Floris
#[Out]# 9    40      Jens
#[Out]# 10   47      Xavi
#[Out]# 11   52    Willem
#[Out]# 12   59      Joep
#[Out]# 13   63      Senn
#[Out]# 14   66   Mohamed
#[Out]# 15   68     Boris
#[Out]# 16   72      Dani
#[Out]# 17   78      Mick
#[Out]# 18   85    Pieter
#[Out]# 19   86      Stef
#[Out]# 20  104       Liv
#[Out]# 21  109      Lynn
#[Out]# 22  112      Yara
#[Out]# 23  122      Elin
#[Out]# 24  126      Lina
#[Out]# 25  136     Femke
#[Out]# 26  165     Hanna
#[Out]# 27  167    Veerle
#[Out]# 28  171     Tessa
#[Out]# 29  172      Lana
#[Out]# 30  180     Merel
#[Out]# 31  185      Nick
#[Out]# 32  186    Angela
#[Out]# 33  188      Pino
#[Out]# 34  188      Pino
#[Out]# 35  189      Koen
#[Out]# 36  189      Koen
#[Out]# 37  190    Kostas
#[Out]# 38  190    Kostas
#[Out]# 39  190    Kostas
#[Out]# 40  190    Kostas
#[Out]# 41  190    Kostas
#[Out]# 42  190    Kostas
#[Out]# 43  190    Kostas
#[Out]# 44  190    Kostas
# Sat, 28 Nov 2020 23:43:21
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:43:23
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    19      Lars
#[Out]# 4    21  Benjamin
#[Out]# 5    24      Luca
#[Out]# 6    27       Tim
#[Out]# 7    37      Guus
#[Out]# 8    38    Floris
#[Out]# 9    40      Jens
#[Out]# 10   47      Xavi
#[Out]# 11   52    Willem
#[Out]# 12   59      Joep
#[Out]# 13   63      Senn
#[Out]# 14   66   Mohamed
#[Out]# 15   68     Boris
#[Out]# 16   72      Dani
#[Out]# 17   78      Mick
#[Out]# 18   85    Pieter
#[Out]# 19   86      Stef
#[Out]# 20  104       Liv
#[Out]# 21  109      Lynn
#[Out]# 22  112      Yara
#[Out]# 23  122      Elin
#[Out]# 24  126      Lina
#[Out]# 25  136     Femke
#[Out]# 26  165     Hanna
#[Out]# 27  167    Veerle
#[Out]# 28  171     Tessa
#[Out]# 29  172      Lana
#[Out]# 30  180     Merel
#[Out]# 31  185      Nick
#[Out]# 32  186    Angela
#[Out]# 33  188      Pino
#[Out]# 34  188      Pino
#[Out]# 35  189      Koen
#[Out]# 36  189      Koen
#[Out]# 37  190    Kostas
#[Out]# 38  190    Kostas
#[Out]# 39  190    Kostas
#[Out]# 40  190    Kostas
#[Out]# 41  190    Kostas
#[Out]# 42  190    Kostas
#[Out]# 43  190    Kostas
#[Out]# 44  190    Kostas
# Sat, 28 Nov 2020 23:43:27
query3_4 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    19      Lars
#[Out]# 4    21  Benjamin
#[Out]# 5    24      Luca
#[Out]# 6    27       Tim
#[Out]# 7    37      Guus
#[Out]# 8    38    Floris
#[Out]# 9    40      Jens
#[Out]# 10   47      Xavi
#[Out]# 11   52    Willem
#[Out]# 12   59      Joep
#[Out]# 13   63      Senn
#[Out]# 14   66   Mohamed
#[Out]# 15   68     Boris
#[Out]# 16   72      Dani
#[Out]# 17   78      Mick
#[Out]# 18   85    Pieter
#[Out]# 19   86      Stef
#[Out]# 20  104       Liv
#[Out]# 21  109      Lynn
#[Out]# 22  112      Yara
#[Out]# 23  122      Elin
#[Out]# 24  126      Lina
#[Out]# 25  136     Femke
#[Out]# 26  165     Hanna
#[Out]# 27  167    Veerle
#[Out]# 28  171     Tessa
#[Out]# 29  172      Lana
#[Out]# 30  180     Merel
#[Out]# 31  185      Nick
#[Out]# 32  186    Angela
#[Out]# 33  188      Pino
#[Out]# 34  188      Pino
#[Out]# 35  189      Koen
#[Out]# 36  189      Koen
#[Out]# 37  190    Kostas
#[Out]# 38  190    Kostas
#[Out]# 39  190    Kostas
#[Out]# 40  190    Kostas
#[Out]# 41  190    Kostas
#[Out]# 42  190    Kostas
#[Out]# 43  190    Kostas
#[Out]# 44  190    Kostas
# Sat, 28 Nov 2020 23:43:35
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Sat, 28 Nov 2020 23:43:45
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     5      Levi
#[Out]# 3     7      Bram
#[Out]# 4    13     James
#[Out]# 5    16    Julian
#[Out]# 6    19      Lars
#[Out]# 7    24      Luca
#[Out]# 8    25     Mason
#[Out]# 9    33      Sven
#[Out]# 10   37      Guus
#[Out]# 11   40      Jens
#[Out]# 12   42      Tijn
#[Out]# 13   43       Tom
#[Out]# 14   51      Ties
#[Out]# 15   57    Nathan
#[Out]# 16   58     Jurre
#[Out]# 17   59      Joep
#[Out]# 18   60  Mohammed
#[Out]# 19   82     Dylan
#[Out]# 20   86      Stef
#[Out]# 21   91   Thijmen
#[Out]# 22   92     Jelte
#[Out]# 23   95      Emma
#[Out]# 24  108      Noor
#[Out]# 25  112      Yara
#[Out]# 26  123     Milou
#[Out]# 27  124     Sofie
#[Out]# 28  157      Puck
#[Out]# 29  159     Fenne
#[Out]# 30  161     Floor
#[Out]# 31  163      Cato
#[Out]# 32  165     Hanna
#[Out]# 33  169      Lily
#[Out]# 34  170      Iris
#[Out]# 35  175       Sam
#[Out]# 36  176     Amira
#[Out]# 37  179      Juul
#[Out]# 38  190    Kostas
# Sat, 28 Nov 2020 23:43:57
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Sat, 28 Nov 2020 23:44:07
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     5      Levi
#[Out]# 3     7      Bram
#[Out]# 4    13     James
#[Out]# 5    16    Julian
#[Out]# 6    19      Lars
#[Out]# 7    24      Luca
#[Out]# 8    25     Mason
#[Out]# 9    33      Sven
#[Out]# 10   37      Guus
#[Out]# 11   40      Jens
#[Out]# 12   42      Tijn
#[Out]# 13   43       Tom
#[Out]# 14   51      Ties
#[Out]# 15   57    Nathan
#[Out]# 16   58     Jurre
#[Out]# 17   59      Joep
#[Out]# 18   60  Mohammed
#[Out]# 19   82     Dylan
#[Out]# 20   86      Stef
#[Out]# 21   91   Thijmen
#[Out]# 22   92     Jelte
#[Out]# 23   95      Emma
#[Out]# 24  108      Noor
#[Out]# 25  112      Yara
#[Out]# 26  123     Milou
#[Out]# 27  124     Sofie
#[Out]# 28  157      Puck
#[Out]# 29  159     Fenne
#[Out]# 30  161     Floor
#[Out]# 31  163      Cato
#[Out]# 32  165     Hanna
#[Out]# 33  169      Lily
#[Out]# 34  170      Iris
#[Out]# 35  175       Sam
#[Out]# 36  176     Amira
#[Out]# 37  179      Juul
#[Out]# 38  190    Kostas
# Sat, 28 Nov 2020 23:50:50
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     5      Levi
#[Out]# 3     7      Bram
#[Out]# 4    13     James
#[Out]# 5    16    Julian
#[Out]# 6    19      Lars
#[Out]# 7    24      Luca
#[Out]# 8    25     Mason
#[Out]# 9    33      Sven
#[Out]# 10   37      Guus
#[Out]# 11   40      Jens
#[Out]# 12   42      Tijn
#[Out]# 13   43       Tom
#[Out]# 14   51      Ties
#[Out]# 15   57    Nathan
#[Out]# 16   58     Jurre
#[Out]# 17   59      Joep
#[Out]# 18   60  Mohammed
#[Out]# 19   82     Dylan
#[Out]# 20   86      Stef
#[Out]# 21   91   Thijmen
#[Out]# 22   92     Jelte
#[Out]# 23   95      Emma
#[Out]# 24  108      Noor
#[Out]# 25  112      Yara
#[Out]# 26  123     Milou
#[Out]# 27  124     Sofie
#[Out]# 28  157      Puck
#[Out]# 29  159     Fenne
#[Out]# 30  161     Floor
#[Out]# 31  163      Cato
#[Out]# 32  165     Hanna
#[Out]# 33  169      Lily
#[Out]# 34  170      Iris
#[Out]# 35  175       Sam
#[Out]# 36  176     Amira
#[Out]# 37  179      Juul
#[Out]# 38  190    Kostas
# Sat, 28 Nov 2020 23:50:57
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Sat, 28 Nov 2020 23:51:06
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     5      Levi
#[Out]# 3     7      Bram
#[Out]# 4    13     James
#[Out]# 5    16    Julian
#[Out]# 6    19      Lars
#[Out]# 7    24      Luca
#[Out]# 8    25     Mason
#[Out]# 9    33      Sven
#[Out]# 10   37      Guus
#[Out]# 11   40      Jens
#[Out]# 12   42      Tijn
#[Out]# 13   43       Tom
#[Out]# 14   51      Ties
#[Out]# 15   57    Nathan
#[Out]# 16   58     Jurre
#[Out]# 17   59      Joep
#[Out]# 18   60  Mohammed
#[Out]# 19   82     Dylan
#[Out]# 20   86      Stef
#[Out]# 21   91   Thijmen
#[Out]# 22   92     Jelte
#[Out]# 23   95      Emma
#[Out]# 24  108      Noor
#[Out]# 25  112      Yara
#[Out]# 26  123     Milou
#[Out]# 27  124     Sofie
#[Out]# 28  157      Puck
#[Out]# 29  159     Fenne
#[Out]# 30  161     Floor
#[Out]# 31  163      Cato
#[Out]# 32  165     Hanna
#[Out]# 33  169      Lily
#[Out]# 34  170      Iris
#[Out]# 35  175       Sam
#[Out]# 36  176     Amira
#[Out]# 37  179      Juul
#[Out]# 38  190    Kostas
# Sat, 28 Nov 2020 23:51:11
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Sat, 28 Nov 2020 23:56:12
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND EXISTS (SELECT *
                FROM customer c, store s, purchase p
                WHERE c.cID = p.cID
                AND p.sID = s.sID
                AND s.sName = "Jumbo")
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Sat, 28 Nov 2020 23:56:20
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND EXISTS (SELECT *
                FROM customer c, store s, purchase p
                WHERE c.cID = p.cID
                AND p.sID = s.sID
                AND s.sName = "Lidl")
    AND NOT EXISTS (SELECT *
                    FROM purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     1       Sem
#[Out]# 1     2     Lucas
#[Out]# 2     5      Levi
#[Out]# 3     7      Bram
#[Out]# 4    13     James
#[Out]# 5    16    Julian
#[Out]# 6    19      Lars
#[Out]# 7    24      Luca
#[Out]# 8    25     Mason
#[Out]# 9    33      Sven
#[Out]# 10   37      Guus
#[Out]# 11   40      Jens
#[Out]# 12   42      Tijn
#[Out]# 13   43       Tom
#[Out]# 14   51      Ties
#[Out]# 15   57    Nathan
#[Out]# 16   58     Jurre
#[Out]# 17   59      Joep
#[Out]# 18   60  Mohammed
#[Out]# 19   82     Dylan
#[Out]# 20   86      Stef
#[Out]# 21   91   Thijmen
#[Out]# 22   92     Jelte
#[Out]# 23   95      Emma
#[Out]# 24  108      Noor
#[Out]# 25  112      Yara
#[Out]# 26  123     Milou
#[Out]# 27  124     Sofie
#[Out]# 28  157      Puck
#[Out]# 29  159     Fenne
#[Out]# 30  161     Floor
#[Out]# 31  163      Cato
#[Out]# 32  165     Hanna
#[Out]# 33  169      Lily
#[Out]# 34  170      Iris
#[Out]# 35  175       Sam
#[Out]# 36  176     Amira
#[Out]# 37  179      Juul
#[Out]# 38  190    Kostas
# Sat, 28 Nov 2020 23:57:06
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE c1.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:57:28
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM customer c1, store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Sat, 28 Nov 2020 23:57:32
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Sat, 28 Nov 2020 23:57:39
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:57:43
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Sat, 28 Nov 2020 23:57:45
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Sat, 28 Nov 2020 23:57:49
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Sat, 28 Nov 2020 23:57:51
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Sat, 28 Nov 2020 23:57:53
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s.sID = p1.sID
                    AND s.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Sat, 28 Nov 2020 23:57:57
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Sat, 28 Nov 2020 23:58:07
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Lidl"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Lidl")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  cName
#[Out]# 0   25  Mason
# Sat, 28 Nov 2020 23:58:09
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Jumbo"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Sat, 28 Nov 2020 23:58:17
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = "Kumar"
    AND NOT EXISTS (SELECT *
                    FROM store s1, purchase p1
                    WHERE c.cID = p1.cID
                    AND s1.sID = p1.sID
                    AND s1.sName != "Kumar")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []


# IPython log file

# Mon, 30 Nov 2020 11:25:54
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 11:25:59
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1e72faed1f0>
# Mon, 30 Nov 2020 11:30:10
query3_2 = '''
    SELECT c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      1    Sem
#[Out]# 2      1    Sem
#[Out]# 3      1    Sem
#[Out]# 4      1    Sem
#[Out]# 5      1    Sem
#[Out]# 6      1    Sem
#[Out]# 7      1    Sem
#[Out]# 8      1    Sem
#[Out]# 9      1    Sem
#[Out]# 10     1    Sem
#[Out]# 11     1    Sem
#[Out]# 12     1    Sem
#[Out]# 13     1    Sem
#[Out]# 14     1    Sem
#[Out]# 15     1    Sem
#[Out]# 16     1    Sem
#[Out]# 17     1    Sem
#[Out]# 18     1    Sem
#[Out]# 19     1    Sem
#[Out]# 20     1    Sem
#[Out]# 21     1    Sem
#[Out]# 22     1    Sem
#[Out]# 23     1    Sem
#[Out]# 24     1    Sem
#[Out]# 25     1    Sem
#[Out]# 26     1    Sem
#[Out]# 27     1    Sem
#[Out]# 28     1    Sem
#[Out]# 29     1    Sem
#[Out]# ..   ...    ...
#[Out]# 946  176  Amira
#[Out]# 947  178   Elif
#[Out]# 948  178   Elif
#[Out]# 949  178   Elif
#[Out]# 950  178   Elif
#[Out]# 951  179   Juul
#[Out]# 952  179   Juul
#[Out]# 953  179   Juul
#[Out]# 954  179   Juul
#[Out]# 955  179   Juul
#[Out]# 956  179   Juul
#[Out]# 957  179   Juul
#[Out]# 958  179   Juul
#[Out]# 959  179   Juul
#[Out]# 960  179   Juul
#[Out]# 961  179   Juul
#[Out]# 962  179   Juul
#[Out]# 963  179   Juul
#[Out]# 964  179   Juul
#[Out]# 965  179   Juul
#[Out]# 966  180  Merel
#[Out]# 967  180  Merel
#[Out]# 968  180  Merel
#[Out]# 969  180  Merel
#[Out]# 970  181   Liva
#[Out]# 971  181   Liva
#[Out]# 972  181   Liva
#[Out]# 973  181   Liva
#[Out]# 974  181   Liva
#[Out]# 975  181   Liva
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Mon, 30 Nov 2020 11:31:05
query3_2 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 11:31:26
query3_2 = '''
    SELECT distinct c.cID, c.cName, s
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID    
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 11:31:44
query3_2 = '''
    SELECT distinct c.cID, c.cName, s.date, p.date
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName        date        date
#[Out]# 0      1       Sem  2018-08-20  2018-08-20
#[Out]# 1      1       Sem  2018-08-21  2018-08-21
#[Out]# 2      2     Lucas  2018-08-16  2018-08-16
#[Out]# 3      2     Lucas  2018-08-17  2018-08-17
#[Out]# 4      3      Finn  2018-08-18  2018-08-18
#[Out]# 5      3      Finn  2018-08-19  2018-08-19
#[Out]# 6      5      Levi  2018-08-17  2018-08-17
#[Out]# 7      5      Levi  2018-08-22  2018-08-22
#[Out]# 8      5      Levi  2018-08-23  2018-08-23
#[Out]# 9      7      Bram  2018-08-23  2018-08-23
#[Out]# 10     7      Bram  2018-08-24  2018-08-24
#[Out]# 11     7      Bram  2018-08-25  2018-08-25
#[Out]# 12     7      Bram  2018-08-26  2018-08-26
#[Out]# 13     8      Liam  2018-08-16  2018-08-16
#[Out]# 14    10       Sam  2018-08-27  2018-08-27
#[Out]# 15    11     Thijs  2018-08-25  2018-08-25
#[Out]# 16    13     James  2018-08-17  2018-08-17
#[Out]# 17    13     James  2018-08-25  2018-08-25
#[Out]# 18    13     James  2018-08-26  2018-08-26
#[Out]# 19    13     James  2018-08-27  2018-08-27
#[Out]# 20    15      Noud  2018-08-27  2018-08-27
#[Out]# 21    17       Dex  2018-08-19  2018-08-19
#[Out]# 22    18      Hugo  2018-08-16  2018-08-16
#[Out]# 23    18      Hugo  2018-08-18  2018-08-18
#[Out]# 24    19      Lars  2018-08-17  2018-08-17
#[Out]# 25    19      Lars  2018-08-18  2018-08-18
#[Out]# 26    20      Gijs  2018-08-17  2018-08-17
#[Out]# 27    20      Gijs  2018-08-18  2018-08-18
#[Out]# 28    21  Benjamin  2018-08-15  2018-08-15
#[Out]# 29    22      Mats  2018-08-27  2018-08-27
#[Out]# ..   ...       ...         ...         ...
#[Out]# 156  165     Hanna  2018-08-23  2018-08-23
#[Out]# 157  165     Hanna  2018-08-24  2018-08-24
#[Out]# 158  167    Veerle  2018-08-18  2018-08-18
#[Out]# 159  167    Veerle  2018-08-19  2018-08-19
#[Out]# 160  167    Veerle  2018-08-20  2018-08-20
#[Out]# 161  167    Veerle  2018-08-21  2018-08-21
#[Out]# 162  167    Veerle  2018-08-15  2018-08-15
#[Out]# 163  168      Kiki  2018-08-16  2018-08-16
#[Out]# 164  169      Lily  2018-08-16  2018-08-16
#[Out]# 165  169      Lily  2018-08-17  2018-08-17
#[Out]# 166  169      Lily  2018-08-18  2018-08-18
#[Out]# 167  169      Lily  2018-08-19  2018-08-19
#[Out]# 168  169      Lily  2018-08-20  2018-08-20
#[Out]# 169  169      Lily  2018-08-26  2018-08-26
#[Out]# 170  169      Lily  2018-08-27  2018-08-27
#[Out]# 171  170      Iris  2018-08-16  2018-08-16
#[Out]# 172  171     Tessa  2018-08-20  2018-08-20
#[Out]# 173  172      Lana  2018-08-27  2018-08-27
#[Out]# 174  172      Lana  2018-08-24  2018-08-24
#[Out]# 175  175       Sam  2018-08-19  2018-08-19
#[Out]# 176  176     Amira  2018-08-22  2018-08-22
#[Out]# 177  176     Amira  2018-08-25  2018-08-25
#[Out]# 178  176     Amira  2018-08-26  2018-08-26
#[Out]# 179  178      Elif  2018-08-27  2018-08-27
#[Out]# 180  179      Juul  2018-08-24  2018-08-24
#[Out]# 181  179      Juul  2018-08-22  2018-08-22
#[Out]# 182  180     Merel  2018-08-26  2018-08-26
#[Out]# 183  180     Merel  2018-08-27  2018-08-27
#[Out]# 184  181      Liva  2018-08-24  2018-08-24
#[Out]# 185  181      Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [186 rows x 4 columns]
# Mon, 30 Nov 2020 11:31:58
query3_2 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 11:35:03
query3_3 = '''
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    19      Lars
#[Out]# 4    21  Benjamin
#[Out]# 5    24      Luca
#[Out]# 6    27       Tim
#[Out]# 7    37      Guus
#[Out]# 8    38    Floris
#[Out]# 9    40      Jens
#[Out]# 10   47      Xavi
#[Out]# 11   52    Willem
#[Out]# 12   59      Joep
#[Out]# 13   63      Senn
#[Out]# 14   66   Mohamed
#[Out]# 15   68     Boris
#[Out]# 16   72      Dani
#[Out]# 17   78      Mick
#[Out]# 18   85    Pieter
#[Out]# 19   86      Stef
#[Out]# 20  104       Liv
#[Out]# 21  109      Lynn
#[Out]# 22  112      Yara
#[Out]# 23  122      Elin
#[Out]# 24  126      Lina
#[Out]# 25  136     Femke
#[Out]# 26  165     Hanna
#[Out]# 27  167    Veerle
#[Out]# 28  171     Tessa
#[Out]# 29  172      Lana
#[Out]# 30  180     Merel
#[Out]# 31  185      Nick
#[Out]# 32  186    Angela
#[Out]# 33  188      Pino
#[Out]# 34  188      Pino
#[Out]# 35  189      Koen
#[Out]# 36  189      Koen
#[Out]# 37  190    Kostas
#[Out]# 38  190    Kostas
#[Out]# 39  190    Kostas
#[Out]# 40  190    Kostas
#[Out]# 41  190    Kostas
#[Out]# 42  190    Kostas
#[Out]# 43  190    Kostas
#[Out]# 44  190    Kostas
# Mon, 30 Nov 2020 11:35:15
query3_3 = '''
    SELECT c.cID, c.cName, s.sName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName  sName
#[Out]# 0     4      Daan  Jumbo
#[Out]# 1    18      Hugo  Jumbo
#[Out]# 2    19      Lars  Jumbo
#[Out]# 3    19      Lars  Jumbo
#[Out]# 4    21  Benjamin  Jumbo
#[Out]# 5    24      Luca  Jumbo
#[Out]# 6    27       Tim  Jumbo
#[Out]# 7    37      Guus  Jumbo
#[Out]# 8    38    Floris  Jumbo
#[Out]# 9    40      Jens  Jumbo
#[Out]# 10   47      Xavi  Jumbo
#[Out]# 11   52    Willem  Jumbo
#[Out]# 12   59      Joep  Jumbo
#[Out]# 13   63      Senn  Jumbo
#[Out]# 14   66   Mohamed  Jumbo
#[Out]# 15   68     Boris  Jumbo
#[Out]# 16   72      Dani  Jumbo
#[Out]# 17   78      Mick  Jumbo
#[Out]# 18   85    Pieter  Jumbo
#[Out]# 19   86      Stef  Jumbo
#[Out]# 20  104       Liv  Jumbo
#[Out]# 21  109      Lynn  Jumbo
#[Out]# 22  112      Yara  Jumbo
#[Out]# 23  122      Elin  Jumbo
#[Out]# 24  126      Lina  Jumbo
#[Out]# 25  136     Femke  Jumbo
#[Out]# 26  165     Hanna  Jumbo
#[Out]# 27  167    Veerle  Jumbo
#[Out]# 28  171     Tessa  Jumbo
#[Out]# 29  172      Lana  Jumbo
#[Out]# 30  180     Merel  Jumbo
#[Out]# 31  185      Nick  Jumbo
#[Out]# 32  186    Angela  Jumbo
#[Out]# 33  188      Pino  Jumbo
#[Out]# 34  188      Pino  Jumbo
#[Out]# 35  189      Koen  Jumbo
#[Out]# 36  189      Koen  Jumbo
#[Out]# 37  190    Kostas  Jumbo
#[Out]# 38  190    Kostas  Jumbo
#[Out]# 39  190    Kostas  Jumbo
#[Out]# 40  190    Kostas  Jumbo
#[Out]# 41  190    Kostas  Jumbo
#[Out]# 42  190    Kostas  Jumbo
#[Out]# 43  190    Kostas  Jumbo
#[Out]# 44  190    Kostas  Jumbo
# Mon, 30 Nov 2020 11:36:13
query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName, s.sName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 11:36:30
query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 11:36:40
query3_3 = '''
    
    
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    19      Lars
#[Out]# 4    21  Benjamin
#[Out]# 5    24      Luca
#[Out]# 6    27       Tim
#[Out]# 7    37      Guus
#[Out]# 8    38    Floris
#[Out]# 9    40      Jens
#[Out]# 10   47      Xavi
#[Out]# 11   52    Willem
#[Out]# 12   59      Joep
#[Out]# 13   63      Senn
#[Out]# 14   66   Mohamed
#[Out]# 15   68     Boris
#[Out]# 16   72      Dani
#[Out]# 17   78      Mick
#[Out]# 18   85    Pieter
#[Out]# 19   86      Stef
#[Out]# 20  104       Liv
#[Out]# 21  109      Lynn
#[Out]# 22  112      Yara
#[Out]# 23  122      Elin
#[Out]# 24  126      Lina
#[Out]# 25  136     Femke
#[Out]# 26  165     Hanna
#[Out]# 27  167    Veerle
#[Out]# 28  171     Tessa
#[Out]# 29  172      Lana
#[Out]# 30  180     Merel
#[Out]# 31  185      Nick
#[Out]# 32  186    Angela
#[Out]# 33  188      Pino
#[Out]# 34  188      Pino
#[Out]# 35  189      Koen
#[Out]# 36  189      Koen
#[Out]# 37  190    Kostas
#[Out]# 38  190    Kostas
#[Out]# 39  190    Kostas
#[Out]# 40  190    Kostas
#[Out]# 41  190    Kostas
#[Out]# 42  190    Kostas
#[Out]# 43  190    Kostas
#[Out]# 44  190    Kostas
# Mon, 30 Nov 2020 11:36:51
query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 11:37:07
query3_3 = '''
    SELECT distinct c.cID, c.cName
    FROM customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 11:37:16
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 11:44:08
query3_4 = '''
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    
    SELECT c.cID, c.cName
    FROM purchase as p1, purchase as p2, store as s, customer as c
    WHERE p1.sID = s.sID AND p2.sID = s.sID AND p1.cID = p2.cID AND p1.sID != p2.sID AND p1.cID = c.cID
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 11:44:22
query3_4 = '''
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    EXCEPT
    SELECT c.cID, c.cName
    FROM purchase as p1, purchase as p2, store as s, customer as c
    WHERE p1.sID = s.sID AND p2.sID = s.sID AND p1.cID = p2.cID AND p1.sID != p2.sID AND p1.cID = c.cID
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Mon, 30 Nov 2020 11:45:18
query3_4 = '''
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    EXCEPT
    SELECT c.cID, c.cName
    FROM purchase as p1, purchase as p2, store as s, customer as c
    WHERE p1.sID = s.sID AND p2.sID = s.sID AND p1.cID = p2.cID AND p1.sID != p2.sID AND p1.cID = c.cID
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Mon, 30 Nov 2020 11:46:10
query3_4 = '''
    SELECT cID
    FROM purchase
    WHERE cID = '4'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID
#[Out]# 0    4
#[Out]# 1    4
#[Out]# 2    4
#[Out]# 3    4
#[Out]# 4    4
#[Out]# 5    4
# Mon, 30 Nov 2020 11:46:16
query3_4 = '''
    SELECT *
    FROM purchase
    WHERE cID = '4'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    tID  cID  sID  pID        date  quantity  price
#[Out]# 0   16    4   17    8  2018-08-24         2   4.15
#[Out]# 1   17    4   10   27  2018-08-24         9   9.05
#[Out]# 2   18    4   53   12  2018-08-25         5  13.60
#[Out]# 3   19    4   21    6  2018-08-24         2   1.05
#[Out]# 4   20    4    7   13  2018-08-25         9   3.05
#[Out]# 5   21    4   44   26  2018-08-25         4   2.75
# Mon, 30 Nov 2020 11:47:01
query3_4 = '''
    SELECT *
    FROM purchase as p, store as s
    WHERE p.cID = '4' 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  sID      sName  \
#[Out]# 0     16    4   17    8  2018-08-24         2   4.15    0       Coop   
#[Out]# 1     17    4   10   27  2018-08-24         9   9.05    0       Coop   
#[Out]# 2     18    4   53   12  2018-08-25         5  13.60    0       Coop   
#[Out]# 3     19    4   21    6  2018-08-24         2   1.05    0       Coop   
#[Out]# 4     20    4    7   13  2018-08-25         9   3.05    0       Coop   
#[Out]# 5     21    4   44   26  2018-08-25         4   2.75    0       Coop   
#[Out]# 6     16    4   17    8  2018-08-24         2   4.15    1  Hoogvliet   
#[Out]# 7     17    4   10   27  2018-08-24         9   9.05    1  Hoogvliet   
#[Out]# 8     18    4   53   12  2018-08-25         5  13.60    1  Hoogvliet   
#[Out]# 9     19    4   21    6  2018-08-24         2   1.05    1  Hoogvliet   
#[Out]# 10    20    4    7   13  2018-08-25         9   3.05    1  Hoogvliet   
#[Out]# 11    21    4   44   26  2018-08-25         4   2.75    1  Hoogvliet   
#[Out]# 12    16    4   17    8  2018-08-24         2   4.15    2      Jumbo   
#[Out]# 13    17    4   10   27  2018-08-24         9   9.05    2      Jumbo   
#[Out]# 14    18    4   53   12  2018-08-25         5  13.60    2      Jumbo   
#[Out]# 15    19    4   21    6  2018-08-24         2   1.05    2      Jumbo   
#[Out]# 16    20    4    7   13  2018-08-25         9   3.05    2      Jumbo   
#[Out]# 17    21    4   44   26  2018-08-25         4   2.75    2      Jumbo   
#[Out]# 18    16    4   17    8  2018-08-24         2   4.15    3     Sligro   
#[Out]# 19    17    4   10   27  2018-08-24         9   9.05    3     Sligro   
#[Out]# 20    18    4   53   12  2018-08-25         5  13.60    3     Sligro   
#[Out]# 21    19    4   21    6  2018-08-24         2   1.05    3     Sligro   
#[Out]# 22    20    4    7   13  2018-08-25         9   3.05    3     Sligro   
#[Out]# 23    21    4   44   26  2018-08-25         4   2.75    3     Sligro   
#[Out]# 24    16    4   17    8  2018-08-24         2   4.15    4  Hoogvliet   
#[Out]# 25    17    4   10   27  2018-08-24         9   9.05    4  Hoogvliet   
#[Out]# 26    18    4   53   12  2018-08-25         5  13.60    4  Hoogvliet   
#[Out]# 27    19    4   21    6  2018-08-24         2   1.05    4  Hoogvliet   
#[Out]# 28    20    4    7   13  2018-08-25         9   3.05    4  Hoogvliet   
#[Out]# 29    21    4   44   26  2018-08-25         4   2.75    4  Hoogvliet   
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  ...        ...   
#[Out]# 354   16    4   17    8  2018-08-24         2   4.15   59      Jumbo   
#[Out]# 355   17    4   10   27  2018-08-24         9   9.05   59      Jumbo   
#[Out]# 356   18    4   53   12  2018-08-25         5  13.60   59      Jumbo   
#[Out]# 357   19    4   21    6  2018-08-24         2   1.05   59      Jumbo   
#[Out]# 358   20    4    7   13  2018-08-25         9   3.05   59      Jumbo   
#[Out]# 359   21    4   44   26  2018-08-25         4   2.75   59      Jumbo   
#[Out]# 360   16    4   17    8  2018-08-24         2   4.15   60       Lidl   
#[Out]# 361   17    4   10   27  2018-08-24         9   9.05   60       Lidl   
#[Out]# 362   18    4   53   12  2018-08-25         5  13.60   60       Lidl   
#[Out]# 363   19    4   21    6  2018-08-24         2   1.05   60       Lidl   
#[Out]# 364   20    4    7   13  2018-08-25         9   3.05   60       Lidl   
#[Out]# 365   21    4   44   26  2018-08-25         4   2.75   60       Lidl   
#[Out]# 366   16    4   17    8  2018-08-24         2   4.15   61       Lidl   
#[Out]# 367   17    4   10   27  2018-08-24         9   9.05   61       Lidl   
#[Out]# 368   18    4   53   12  2018-08-25         5  13.60   61       Lidl   
#[Out]# 369   19    4   21    6  2018-08-24         2   1.05   61       Lidl   
#[Out]# 370   20    4    7   13  2018-08-25         9   3.05   61       Lidl   
#[Out]# 371   21    4   44   26  2018-08-25         4   2.75   61       Lidl   
#[Out]# 372   16    4   17    8  2018-08-24         2   4.15   62      Jumbo   
#[Out]# 373   17    4   10   27  2018-08-24         9   9.05   62      Jumbo   
#[Out]# 374   18    4   53   12  2018-08-25         5  13.60   62      Jumbo   
#[Out]# 375   19    4   21    6  2018-08-24         2   1.05   62      Jumbo   
#[Out]# 376   20    4    7   13  2018-08-25         9   3.05   62      Jumbo   
#[Out]# 377   21    4   44   26  2018-08-25         4   2.75   62      Jumbo   
#[Out]# 378   16    4   17    8  2018-08-24         2   4.15   63      Jumbo   
#[Out]# 379   17    4   10   27  2018-08-24         9   9.05   63      Jumbo   
#[Out]# 380   18    4   53   12  2018-08-25         5  13.60   63      Jumbo   
#[Out]# 381   19    4   21    6  2018-08-24         2   1.05   63      Jumbo   
#[Out]# 382   20    4    7   13  2018-08-25         9   3.05   63      Jumbo   
#[Out]# 383   21    4   44   26  2018-08-25         4   2.75   63      Jumbo   
#[Out]# 
#[Out]#                street       city  
#[Out]# 0        Kalverstraat  Amsterdam  
#[Out]# 1        Kalverstraat  Amsterdam  
#[Out]# 2        Kalverstraat  Amsterdam  
#[Out]# 3        Kalverstraat  Amsterdam  
#[Out]# 4        Kalverstraat  Amsterdam  
#[Out]# 5        Kalverstraat  Amsterdam  
#[Out]# 6    Rozemarijnstraat      Breda  
#[Out]# 7    Rozemarijnstraat      Breda  
#[Out]# 8    Rozemarijnstraat      Breda  
#[Out]# 9    Rozemarijnstraat      Breda  
#[Out]# 10   Rozemarijnstraat      Breda  
#[Out]# 11   Rozemarijnstraat      Breda  
#[Out]# 12     Stadhoudersweg  Rotterdam  
#[Out]# 13     Stadhoudersweg  Rotterdam  
#[Out]# 14     Stadhoudersweg  Rotterdam  
#[Out]# 15     Stadhoudersweg  Rotterdam  
#[Out]# 16     Stadhoudersweg  Rotterdam  
#[Out]# 17     Stadhoudersweg  Rotterdam  
#[Out]# 18     Stadhoudersweg  Rotterdam  
#[Out]# 19     Stadhoudersweg  Rotterdam  
#[Out]# 20     Stadhoudersweg  Rotterdam  
#[Out]# 21     Stadhoudersweg  Rotterdam  
#[Out]# 22     Stadhoudersweg  Rotterdam  
#[Out]# 23     Stadhoudersweg  Rotterdam  
#[Out]# 24        Molenstraat  Eindhoven  
#[Out]# 25        Molenstraat  Eindhoven  
#[Out]# 26        Molenstraat  Eindhoven  
#[Out]# 27        Molenstraat  Eindhoven  
#[Out]# 28        Molenstraat  Eindhoven  
#[Out]# 29        Molenstraat  Eindhoven  
#[Out]# ..                ...        ...  
#[Out]# 354  Rozemarijnstraat      Breda  
#[Out]# 355  Rozemarijnstraat      Breda  
#[Out]# 356  Rozemarijnstraat      Breda  
#[Out]# 357  Rozemarijnstraat      Breda  
#[Out]# 358  Rozemarijnstraat      Breda  
#[Out]# 359  Rozemarijnstraat      Breda  
#[Out]# 360      Pannekoekweg      Breda  
#[Out]# 361      Pannekoekweg      Breda  
#[Out]# 362      Pannekoekweg      Breda  
#[Out]# 363      Pannekoekweg      Breda  
#[Out]# 364      Pannekoekweg      Breda  
#[Out]# 365      Pannekoekweg      Breda  
#[Out]# 366      Pannekoekweg      Breda  
#[Out]# 367      Pannekoekweg      Breda  
#[Out]# 368      Pannekoekweg      Breda  
#[Out]# 369      Pannekoekweg      Breda  
#[Out]# 370      Pannekoekweg      Breda  
#[Out]# 371      Pannekoekweg      Breda  
#[Out]# 372     Poffertjesweg  Eindhoven  
#[Out]# 373     Poffertjesweg  Eindhoven  
#[Out]# 374     Poffertjesweg  Eindhoven  
#[Out]# 375     Poffertjesweg  Eindhoven  
#[Out]# 376     Poffertjesweg  Eindhoven  
#[Out]# 377     Poffertjesweg  Eindhoven  
#[Out]# 378     Stationstraat        Oss  
#[Out]# 379     Stationstraat        Oss  
#[Out]# 380     Stationstraat        Oss  
#[Out]# 381     Stationstraat        Oss  
#[Out]# 382     Stationstraat        Oss  
#[Out]# 383     Stationstraat        Oss  
#[Out]# 
#[Out]# [384 rows x 11 columns]
# Mon, 30 Nov 2020 11:47:44
query3_4 = '''
    SELECT *
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    EXCEPT
    SELECT *
    FROM purchase as p1, purchase as p2, store as s, customer as c
    WHERE p1.sID = s.sID AND p2.sID = s.sID AND p1.cID = p2.cID AND p1.sID != p2.sID AND p1.cID = c.cID 
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 11:47:59
query3_4 = '''
    SELECT p1.*
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    EXCEPT
    SELECT p1.*
    FROM purchase as p1, purchase as p2, store as s, customer as c
    WHERE p1.sID = s.sID AND p2.sID = s.sID AND p1.cID = p2.cID AND p1.sID != p2.sID AND p1.cID = c.cID 
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 11:48:08
query3_4 = '''
    SELECT p.*
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    EXCEPT
    SELECT p1.*
    FROM purchase as p1, purchase as p2, store as s, customer as c
    WHERE p1.sID = s.sID AND p2.sID = s.sID AND p1.cID = p2.cID AND p1.sID != p2.sID AND p1.cID = c.cID 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price
#[Out]# 0    17    4   10   27  2018-08-24         9   9.05
#[Out]# 1    61   18    2    9  2018-08-16         6   1.70
#[Out]# 2    63   19   59    0  2018-08-17         1   3.90
#[Out]# 3    65   19    2   15  2018-08-18         1   1.05
#[Out]# 4    71   21    2   23  2018-08-16         3   2.40
#[Out]# 5    83   24   59   13  2018-08-21         5   4.00
#[Out]# 6    87   27   59   14  2018-08-26         4   3.50
#[Out]# 7   115   37   10   13  2018-08-15         4   2.90
#[Out]# 8   116   38   37   25  2018-08-18         5   4.70
#[Out]# 9   126   40   56   19  2018-08-17         5   2.25
#[Out]# 10  148   47   20   16  2018-08-17         7   2.10
#[Out]# 11  159   52    2    5  2018-08-25         6   0.50
#[Out]# 12  176   59   59   21  2018-08-15         6   2.20
#[Out]# 13  182   63   20   27  2018-08-17         8   6.85
#[Out]# 14  186   66   10   24  2018-08-16         5   3.65
#[Out]# 15  194   68   20    7  2018-08-27         3   1.65
#[Out]# 16  203   72   10   16  2018-08-22         7   1.50
#[Out]# 17  215   78   56   13  2018-08-18         5   4.15
#[Out]# 18  230   85   37    2  2018-08-19         2   2.25
#[Out]# 19  234   86   20   28  2018-08-17         6   8.60
#[Out]# 20  278  104    2   22  2018-08-22         2   2.00
#[Out]# 21  287  109   56   26  2018-08-21         2   3.25
#[Out]# 22  296  112   20    3  2018-08-25         4   1.40
#[Out]# 23  316  122   56    7  2018-08-22         4   2.35
#[Out]# 24  334  126   56   15  2018-08-22         1   1.00
#[Out]# 25  350  136   37   28  2018-08-24         5   7.75
#[Out]# 26  410  165   56    1  2018-08-23         3   4.40
#[Out]# 27  420  167   56    7  2018-08-20         1   2.10
#[Out]# 28  441  171   56    3  2018-08-20         1   1.50
#[Out]# 29  443  172   59    4  2018-08-27         4   0.90
#[Out]# 30  468  180   56   10  2018-08-27         3   0.60
#[Out]# 31  778  185   62   29  2018-08-20         1   1.00
#[Out]# 32  779  186   62   29  2018-08-21         5   1.00
#[Out]# 33  780  188   62   30  2018-08-20         1   1.00
#[Out]# 34  781  188   62   30  2018-09-20         1   1.00
#[Out]# 35  782  189   63    7  2018-08-25         5   1.25
#[Out]# 36  783  189   20   19  2018-08-26         3   2.50
#[Out]# 37  786  190    2   19  2018-08-19         4   1.40
#[Out]# 38  794  190   10   19  2018-08-22         7   0.90
#[Out]# 39  804  190   20   20  2018-08-17         7   0.50
#[Out]# 40  821  190   37   28  2018-08-15         4   0.65
#[Out]# 41  840  190   56   11  2018-08-15         4   1.60
#[Out]# 42  843  190   59   17  2018-08-26         2   3.80
#[Out]# 43  846  190   62    9  2018-08-16         2   3.15
#[Out]# 44  847  190   63   18  2018-08-21         1   3.30
# Mon, 30 Nov 2020 11:48:17
query3_4 = '''
    SELECT p.*, s.*
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    EXCEPT
    SELECT p1.*
    FROM purchase as p1, purchase as p2, store as s, customer as c
    WHERE p1.sID = s.sID AND p2.sID = s.sID AND p1.cID = p2.cID AND p1.sID != p2.sID AND p1.cID = c.cID 
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 11:48:29
query3_4 = '''
    SELECT p.*, s.*
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    EXCEPT
    SELECT p1.*, s.*
    FROM purchase as p1, purchase as p2, store as s, customer as c
    WHERE p1.sID = s.sID AND p2.sID = s.sID AND p1.cID = p2.cID AND p1.sID != p2.sID AND p1.cID = c.cID 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price  sID  sName  \
#[Out]# 0    17    4   10   27  2018-08-24         9   9.05   10  Jumbo   
#[Out]# 1    61   18    2    9  2018-08-16         6   1.70    2  Jumbo   
#[Out]# 2    63   19   59    0  2018-08-17         1   3.90   59  Jumbo   
#[Out]# 3    65   19    2   15  2018-08-18         1   1.05    2  Jumbo   
#[Out]# 4    71   21    2   23  2018-08-16         3   2.40    2  Jumbo   
#[Out]# 5    83   24   59   13  2018-08-21         5   4.00   59  Jumbo   
#[Out]# 6    87   27   59   14  2018-08-26         4   3.50   59  Jumbo   
#[Out]# 7   115   37   10   13  2018-08-15         4   2.90   10  Jumbo   
#[Out]# 8   116   38   37   25  2018-08-18         5   4.70   37  Jumbo   
#[Out]# 9   126   40   56   19  2018-08-17         5   2.25   56  Jumbo   
#[Out]# 10  148   47   20   16  2018-08-17         7   2.10   20  Jumbo   
#[Out]# 11  159   52    2    5  2018-08-25         6   0.50    2  Jumbo   
#[Out]# 12  176   59   59   21  2018-08-15         6   2.20   59  Jumbo   
#[Out]# 13  182   63   20   27  2018-08-17         8   6.85   20  Jumbo   
#[Out]# 14  186   66   10   24  2018-08-16         5   3.65   10  Jumbo   
#[Out]# 15  194   68   20    7  2018-08-27         3   1.65   20  Jumbo   
#[Out]# 16  203   72   10   16  2018-08-22         7   1.50   10  Jumbo   
#[Out]# 17  215   78   56   13  2018-08-18         5   4.15   56  Jumbo   
#[Out]# 18  230   85   37    2  2018-08-19         2   2.25   37  Jumbo   
#[Out]# 19  234   86   20   28  2018-08-17         6   8.60   20  Jumbo   
#[Out]# 20  278  104    2   22  2018-08-22         2   2.00    2  Jumbo   
#[Out]# 21  287  109   56   26  2018-08-21         2   3.25   56  Jumbo   
#[Out]# 22  296  112   20    3  2018-08-25         4   1.40   20  Jumbo   
#[Out]# 23  316  122   56    7  2018-08-22         4   2.35   56  Jumbo   
#[Out]# 24  334  126   56   15  2018-08-22         1   1.00   56  Jumbo   
#[Out]# 25  350  136   37   28  2018-08-24         5   7.75   37  Jumbo   
#[Out]# 26  410  165   56    1  2018-08-23         3   4.40   56  Jumbo   
#[Out]# 27  420  167   56    7  2018-08-20         1   2.10   56  Jumbo   
#[Out]# 28  441  171   56    3  2018-08-20         1   1.50   56  Jumbo   
#[Out]# 29  443  172   59    4  2018-08-27         4   0.90   59  Jumbo   
#[Out]# 30  468  180   56   10  2018-08-27         3   0.60   56  Jumbo   
#[Out]# 31  778  185   62   29  2018-08-20         1   1.00   62  Jumbo   
#[Out]# 32  779  186   62   29  2018-08-21         5   1.00   62  Jumbo   
#[Out]# 33  780  188   62   30  2018-08-20         1   1.00   62  Jumbo   
#[Out]# 34  781  188   62   30  2018-09-20         1   1.00   62  Jumbo   
#[Out]# 35  782  189   63    7  2018-08-25         5   1.25   63  Jumbo   
#[Out]# 36  783  189   20   19  2018-08-26         3   2.50   20  Jumbo   
#[Out]# 37  786  190    2   19  2018-08-19         4   1.40    2  Jumbo   
#[Out]# 38  794  190   10   19  2018-08-22         7   0.90   10  Jumbo   
#[Out]# 39  804  190   20   20  2018-08-17         7   0.50   20  Jumbo   
#[Out]# 40  821  190   37   28  2018-08-15         4   0.65   37  Jumbo   
#[Out]# 41  840  190   56   11  2018-08-15         4   1.60   56  Jumbo   
#[Out]# 42  843  190   59   17  2018-08-26         2   3.80   59  Jumbo   
#[Out]# 43  846  190   62    9  2018-08-16         2   3.15   62  Jumbo   
#[Out]# 44  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 
#[Out]#               street       city  
#[Out]# 0         Bergselaan  Rotterdam  
#[Out]# 1     Stadhoudersweg  Rotterdam  
#[Out]# 2   Rozemarijnstraat      Breda  
#[Out]# 3     Stadhoudersweg  Rotterdam  
#[Out]# 4     Stadhoudersweg  Rotterdam  
#[Out]# 5   Rozemarijnstraat      Breda  
#[Out]# 6   Rozemarijnstraat      Breda  
#[Out]# 7         Bergselaan  Rotterdam  
#[Out]# 8           Molenweg  Eindhoven  
#[Out]# 9        Parallelweg  Eindhoven  
#[Out]# 10      Kasteeldreef    Tilburg  
#[Out]# 11    Stadhoudersweg  Rotterdam  
#[Out]# 12  Rozemarijnstraat      Breda  
#[Out]# 13      Kasteeldreef    Tilburg  
#[Out]# 14        Bergselaan  Rotterdam  
#[Out]# 15      Kasteeldreef    Tilburg  
#[Out]# 16        Bergselaan  Rotterdam  
#[Out]# 17       Parallelweg  Eindhoven  
#[Out]# 18          Molenweg  Eindhoven  
#[Out]# 19      Kasteeldreef    Tilburg  
#[Out]# 20    Stadhoudersweg  Rotterdam  
#[Out]# 21       Parallelweg  Eindhoven  
#[Out]# 22      Kasteeldreef    Tilburg  
#[Out]# 23       Parallelweg  Eindhoven  
#[Out]# 24       Parallelweg  Eindhoven  
#[Out]# 25          Molenweg  Eindhoven  
#[Out]# 26       Parallelweg  Eindhoven  
#[Out]# 27       Parallelweg  Eindhoven  
#[Out]# 28       Parallelweg  Eindhoven  
#[Out]# 29  Rozemarijnstraat      Breda  
#[Out]# 30       Parallelweg  Eindhoven  
#[Out]# 31     Poffertjesweg  Eindhoven  
#[Out]# 32     Poffertjesweg  Eindhoven  
#[Out]# 33     Poffertjesweg  Eindhoven  
#[Out]# 34     Poffertjesweg  Eindhoven  
#[Out]# 35     Stationstraat        Oss  
#[Out]# 36      Kasteeldreef    Tilburg  
#[Out]# 37    Stadhoudersweg  Rotterdam  
#[Out]# 38        Bergselaan  Rotterdam  
#[Out]# 39      Kasteeldreef    Tilburg  
#[Out]# 40          Molenweg  Eindhoven  
#[Out]# 41       Parallelweg  Eindhoven  
#[Out]# 42  Rozemarijnstraat      Breda  
#[Out]# 43     Poffertjesweg  Eindhoven  
#[Out]# 44     Stationstraat        Oss  
# Mon, 30 Nov 2020 11:49:50
query3_4 = '''
    SELECT p.*, s.*, c.*
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  sID        sName  \
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45    3       Sligro   
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65   23         Dirk   
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60    3       Sligro   
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25   17    Hoogvliet   
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95   32  Albert Hein   
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75   16         Lidl   
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90   46         Lidl   
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10   36         Lidl   
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45   12         Lidl   
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35   39       Sligro   
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10   13         Coop   
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70   51         Coop   
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55   47         Coop   
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30   44  Albert Hein   
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75   30         Dirk   
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45   29       Sligro   
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15   17    Hoogvliet   
#[Out]# 17    18    4   53   12  2018-08-25         5  13.60   53         Coop   
#[Out]# 18    19    4   21    6  2018-08-24         2   1.05   21         Coop   
#[Out]# 19    20    4    7   13  2018-08-25         9   3.05    7       Sligro   
#[Out]# 20    21    4   44   26  2018-08-25         4   2.75   44  Albert Hein   
#[Out]# 21    22    5    4   14  2018-08-17         6   4.70    4    Hoogvliet   
#[Out]# 22    23    5   36   28  2018-08-22         6   8.25   36         Lidl   
#[Out]# 23    24    5   55    6  2018-08-23         9   1.10   55         Coop   
#[Out]# 24    25    5   51   22  2018-08-23         2   1.55   51         Coop   
#[Out]# 25    26    5    6   16  2018-08-23         2   1.85    6         Coop   
#[Out]# 26    27    5   17   19  2018-08-23         1   2.20   17    Hoogvliet   
#[Out]# 27    28    7    3   19  2018-08-23         2   2.10    3       Sligro   
#[Out]# 28    29    7   12    2  2018-08-23         6   1.70   12         Lidl   
#[Out]# 29    30    7   11   16  2018-08-24         4   1.90   11  Albert Hein   
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  ...          ...   
#[Out]# 434  813  190   29   17  2018-08-27         5   1.20   29       Sligro   
#[Out]# 435  814  190   30   10  2018-08-18         4   4.35   30         Dirk   
#[Out]# 436  815  190   31   17  2018-08-19         7   1.20   31         Coop   
#[Out]# 437  816  190   32    0  2018-08-26         4   3.85   32  Albert Hein   
#[Out]# 438  817  190   33   19  2018-08-19         5   4.25   33         Dirk   
#[Out]# 439  818  190   34   28  2018-08-20         4   2.80   34         Coop   
#[Out]# 440  819  190   35   27  2018-08-15         5   0.50   35         Lidl   
#[Out]# 441  820  190   36    5  2018-08-23         3   2.55   36         Lidl   
#[Out]# 442  822  190   38    7  2018-08-24         4   0.70   38    Hoogvliet   
#[Out]# 443  823  190   39    0  2018-08-25         4   3.70   39       Sligro   
#[Out]# 444  824  190   40   11  2018-08-15         2   3.50   40    Hoogvliet   
#[Out]# 445  825  190   41    6  2018-08-15         5   2.95   41  Albert Hein   
#[Out]# 446  826  190   42   19  2018-08-22         5   2.75   42       Sligro   
#[Out]# 447  827  190   43   17  2018-08-17         7   1.50   43         Coop   
#[Out]# 448  828  190   44    9  2018-08-18         5   0.85   44  Albert Hein   
#[Out]# 449  829  190   45   11  2018-08-19         2   3.55   45         Coop   
#[Out]# 450  830  190   46   22  2018-08-25         4   2.60   46         Lidl   
#[Out]# 451  831  190   47   17  2018-08-17         4   3.25   47         Coop   
#[Out]# 452  832  190   48   20  2018-08-26         6   4.30   48    Hoogvliet   
#[Out]# 453  833  190   49   11  2018-08-17         3   3.05   49    Hoogvliet   
#[Out]# 454  834  190   50   21  2018-08-22         6   4.05   50       Sligro   
#[Out]# 455  835  190   51   23  2018-08-19         1   1.50   51         Coop   
#[Out]# 456  836  190   52   23  2018-08-15         5   2.50   52         Lidl   
#[Out]# 457  837  190   53    8  2018-08-18         4   3.95   53         Coop   
#[Out]# 458  838  190   54    0  2018-08-25         6   3.50   54         Dirk   
#[Out]# 459  839  190   55    8  2018-08-18         7   2.95   55         Coop   
#[Out]# 460  841  190   57   15  2018-08-22         5   3.25   57         Dirk   
#[Out]# 461  842  190   58    2  2018-08-19         7   0.75   58         Dirk   
#[Out]# 462  844  190   60    5  2018-08-27         6   4.35   60         Lidl   
#[Out]# 463  845  190   61   19  2018-08-23         5   2.85   61         Lidl   
#[Out]# 
#[Out]#                street       city  cID   cName            street       city  
#[Out]# 0      Stadhoudersweg  Rotterdam    0    Noah         Koestraat    Utrecht  
#[Out]# 1       Stationsplein      Breda    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 2      Stadhoudersweg  Rotterdam    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 3          Kerkstraat  Eindhoven    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 4          Hoogstraat    Utrecht    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 5       Ambachtstraat    Utrecht    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 6          Bergselaan  Rotterdam    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 7       Julianastraat  Eindhoven    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 8    Wilhelminastraat  Eindhoven    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 9         Dorpsstraat  Eindhoven    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 10          Koestraat    Tilburg    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 11        Parallelweg    Utrecht    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 12      Julianastraat  Rotterdam    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 13      Ambachtstraat    Utrecht    3    Finn     Stationsplein      Breda  
#[Out]# 14        Nieuwstraat  Eindhoven    3    Finn     Stationsplein      Breda  
#[Out]# 15       Marnixstraat  Amsterdam    3    Finn     Stationsplein      Breda  
#[Out]# 16         Kerkstraat  Eindhoven    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 17         Hoogstraat    Utrecht    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 18       Kasteeldreef    Tilburg    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 19   Wilhelminastraat  Eindhoven    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 20      Ambachtstraat    Utrecht    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 21        Molenstraat  Eindhoven    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 22      Julianastraat  Eindhoven    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 23    Sint Annastraat      Breda    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 24        Parallelweg    Utrecht    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 25     Stadhoudersweg  Rotterdam    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 26         Kerkstraat  Eindhoven    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 27     Stadhoudersweg  Rotterdam    7    Bram      Schoolstraat  Eindhoven  
#[Out]# 28   Wilhelminastraat  Eindhoven    7    Bram      Schoolstraat  Eindhoven  
#[Out]# 29           Hofplein  Rotterdam    7    Bram      Schoolstraat  Eindhoven  
#[Out]# ..                ...        ...  ...     ...               ...        ...  
#[Out]# 434      Marnixstraat  Amsterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 435       Nieuwstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 436       Parallelweg    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 437        Hoogstraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 438       Nieuwstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 439          Bierkaai  Amsterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 440     Julianastraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 441     Julianastraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 442          Hofplein  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 443       Dorpsstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 444          Hofplein  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 445        Bergselaan  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 446      Kalverstraat  Amsterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 447    Gasthuisstraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 448     Ambachtstraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 449      Kasteeldreef    Tilburg  190  Kostas          Eindeweg    Utrecht  
#[Out]# 450        Bergselaan  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 451     Julianastraat  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 452      Kasteeldreef    Tilburg  190  Kostas          Eindeweg    Utrecht  
#[Out]# 453      Keizerstraat  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 454     Stationsplein      Breda  190  Kostas          Eindeweg    Utrecht  
#[Out]# 455       Parallelweg    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 456       Nieuwstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 457        Hoogstraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 458     Julianastraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 459   Sint Annastraat      Breda  190  Kostas          Eindeweg    Utrecht  
#[Out]# 460       Molenstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 461      Keizerstraat  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 462      Pannekoekweg      Breda  190  Kostas          Eindeweg    Utrecht  
#[Out]# 463      Pannekoekweg      Breda  190  Kostas          Eindeweg    Utrecht  
#[Out]# 
#[Out]# [464 rows x 15 columns]
# Mon, 30 Nov 2020 11:50:17
query3_4 = '''
    SELECT distinct p.*, s.*, c.*
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  sID        sName  \
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45    3       Sligro   
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65   23         Dirk   
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60    3       Sligro   
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25   17    Hoogvliet   
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95   32  Albert Hein   
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75   16         Lidl   
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90   46         Lidl   
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10   36         Lidl   
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45   12         Lidl   
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35   39       Sligro   
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10   13         Coop   
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70   51         Coop   
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55   47         Coop   
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30   44  Albert Hein   
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75   30         Dirk   
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45   29       Sligro   
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15   17    Hoogvliet   
#[Out]# 17    18    4   53   12  2018-08-25         5  13.60   53         Coop   
#[Out]# 18    19    4   21    6  2018-08-24         2   1.05   21         Coop   
#[Out]# 19    20    4    7   13  2018-08-25         9   3.05    7       Sligro   
#[Out]# 20    21    4   44   26  2018-08-25         4   2.75   44  Albert Hein   
#[Out]# 21    22    5    4   14  2018-08-17         6   4.70    4    Hoogvliet   
#[Out]# 22    23    5   36   28  2018-08-22         6   8.25   36         Lidl   
#[Out]# 23    24    5   55    6  2018-08-23         9   1.10   55         Coop   
#[Out]# 24    25    5   51   22  2018-08-23         2   1.55   51         Coop   
#[Out]# 25    26    5    6   16  2018-08-23         2   1.85    6         Coop   
#[Out]# 26    27    5   17   19  2018-08-23         1   2.20   17    Hoogvliet   
#[Out]# 27    28    7    3   19  2018-08-23         2   2.10    3       Sligro   
#[Out]# 28    29    7   12    2  2018-08-23         6   1.70   12         Lidl   
#[Out]# 29    30    7   11   16  2018-08-24         4   1.90   11  Albert Hein   
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  ...          ...   
#[Out]# 434  813  190   29   17  2018-08-27         5   1.20   29       Sligro   
#[Out]# 435  814  190   30   10  2018-08-18         4   4.35   30         Dirk   
#[Out]# 436  815  190   31   17  2018-08-19         7   1.20   31         Coop   
#[Out]# 437  816  190   32    0  2018-08-26         4   3.85   32  Albert Hein   
#[Out]# 438  817  190   33   19  2018-08-19         5   4.25   33         Dirk   
#[Out]# 439  818  190   34   28  2018-08-20         4   2.80   34         Coop   
#[Out]# 440  819  190   35   27  2018-08-15         5   0.50   35         Lidl   
#[Out]# 441  820  190   36    5  2018-08-23         3   2.55   36         Lidl   
#[Out]# 442  822  190   38    7  2018-08-24         4   0.70   38    Hoogvliet   
#[Out]# 443  823  190   39    0  2018-08-25         4   3.70   39       Sligro   
#[Out]# 444  824  190   40   11  2018-08-15         2   3.50   40    Hoogvliet   
#[Out]# 445  825  190   41    6  2018-08-15         5   2.95   41  Albert Hein   
#[Out]# 446  826  190   42   19  2018-08-22         5   2.75   42       Sligro   
#[Out]# 447  827  190   43   17  2018-08-17         7   1.50   43         Coop   
#[Out]# 448  828  190   44    9  2018-08-18         5   0.85   44  Albert Hein   
#[Out]# 449  829  190   45   11  2018-08-19         2   3.55   45         Coop   
#[Out]# 450  830  190   46   22  2018-08-25         4   2.60   46         Lidl   
#[Out]# 451  831  190   47   17  2018-08-17         4   3.25   47         Coop   
#[Out]# 452  832  190   48   20  2018-08-26         6   4.30   48    Hoogvliet   
#[Out]# 453  833  190   49   11  2018-08-17         3   3.05   49    Hoogvliet   
#[Out]# 454  834  190   50   21  2018-08-22         6   4.05   50       Sligro   
#[Out]# 455  835  190   51   23  2018-08-19         1   1.50   51         Coop   
#[Out]# 456  836  190   52   23  2018-08-15         5   2.50   52         Lidl   
#[Out]# 457  837  190   53    8  2018-08-18         4   3.95   53         Coop   
#[Out]# 458  838  190   54    0  2018-08-25         6   3.50   54         Dirk   
#[Out]# 459  839  190   55    8  2018-08-18         7   2.95   55         Coop   
#[Out]# 460  841  190   57   15  2018-08-22         5   3.25   57         Dirk   
#[Out]# 461  842  190   58    2  2018-08-19         7   0.75   58         Dirk   
#[Out]# 462  844  190   60    5  2018-08-27         6   4.35   60         Lidl   
#[Out]# 463  845  190   61   19  2018-08-23         5   2.85   61         Lidl   
#[Out]# 
#[Out]#                street       city  cID   cName            street       city  
#[Out]# 0      Stadhoudersweg  Rotterdam    0    Noah         Koestraat    Utrecht  
#[Out]# 1       Stationsplein      Breda    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 2      Stadhoudersweg  Rotterdam    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 3          Kerkstraat  Eindhoven    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 4          Hoogstraat    Utrecht    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 5       Ambachtstraat    Utrecht    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 6          Bergselaan  Rotterdam    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 7       Julianastraat  Eindhoven    1     Sem  Rozemarijnstraat      Breda  
#[Out]# 8    Wilhelminastraat  Eindhoven    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 9         Dorpsstraat  Eindhoven    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 10          Koestraat    Tilburg    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 11        Parallelweg    Utrecht    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 12      Julianastraat  Rotterdam    2   Lucas  Oude Leliestraat  Amsterdam  
#[Out]# 13      Ambachtstraat    Utrecht    3    Finn     Stationsplein      Breda  
#[Out]# 14        Nieuwstraat  Eindhoven    3    Finn     Stationsplein      Breda  
#[Out]# 15       Marnixstraat  Amsterdam    3    Finn     Stationsplein      Breda  
#[Out]# 16         Kerkstraat  Eindhoven    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 17         Hoogstraat    Utrecht    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 18       Kasteeldreef    Tilburg    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 19   Wilhelminastraat  Eindhoven    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 20      Ambachtstraat    Utrecht    4    Daan      Kalverstraat  Amsterdam  
#[Out]# 21        Molenstraat  Eindhoven    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 22      Julianastraat  Eindhoven    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 23    Sint Annastraat      Breda    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 24        Parallelweg    Utrecht    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 25     Stadhoudersweg  Rotterdam    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 26         Kerkstraat  Eindhoven    5    Levi    Gasthuisstraat    Utrecht  
#[Out]# 27     Stadhoudersweg  Rotterdam    7    Bram      Schoolstraat  Eindhoven  
#[Out]# 28   Wilhelminastraat  Eindhoven    7    Bram      Schoolstraat  Eindhoven  
#[Out]# 29           Hofplein  Rotterdam    7    Bram      Schoolstraat  Eindhoven  
#[Out]# ..                ...        ...  ...     ...               ...        ...  
#[Out]# 434      Marnixstraat  Amsterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 435       Nieuwstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 436       Parallelweg    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 437        Hoogstraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 438       Nieuwstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 439          Bierkaai  Amsterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 440     Julianastraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 441     Julianastraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 442          Hofplein  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 443       Dorpsstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 444          Hofplein  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 445        Bergselaan  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 446      Kalverstraat  Amsterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 447    Gasthuisstraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 448     Ambachtstraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 449      Kasteeldreef    Tilburg  190  Kostas          Eindeweg    Utrecht  
#[Out]# 450        Bergselaan  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 451     Julianastraat  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 452      Kasteeldreef    Tilburg  190  Kostas          Eindeweg    Utrecht  
#[Out]# 453      Keizerstraat  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 454     Stationsplein      Breda  190  Kostas          Eindeweg    Utrecht  
#[Out]# 455       Parallelweg    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 456       Nieuwstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 457        Hoogstraat    Utrecht  190  Kostas          Eindeweg    Utrecht  
#[Out]# 458     Julianastraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 459   Sint Annastraat      Breda  190  Kostas          Eindeweg    Utrecht  
#[Out]# 460       Molenstraat  Eindhoven  190  Kostas          Eindeweg    Utrecht  
#[Out]# 461      Keizerstraat  Rotterdam  190  Kostas          Eindeweg    Utrecht  
#[Out]# 462      Pannekoekweg      Breda  190  Kostas          Eindeweg    Utrecht  
#[Out]# 463      Pannekoekweg      Breda  190  Kostas          Eindeweg    Utrecht  
#[Out]# 
#[Out]# [464 rows x 15 columns]
# Mon, 30 Nov 2020 11:50:36
query3_4 = '''
    SELECT distinct c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName
#[Out]# 0        Noah
#[Out]# 1         Sem
#[Out]# 2       Lucas
#[Out]# 3        Finn
#[Out]# 4        Daan
#[Out]# 5        Levi
#[Out]# 6        Bram
#[Out]# 7        Liam
#[Out]# 8         Sam
#[Out]# 9       Thijs
#[Out]# 10      James
#[Out]# 11       Noud
#[Out]# 12     Julian
#[Out]# 13        Dex
#[Out]# 14       Hugo
#[Out]# 15       Lars
#[Out]# 16       Gijs
#[Out]# 17   Benjamin
#[Out]# 18       Mats
#[Out]# 19       Luca
#[Out]# 20      Mason
#[Out]# 21     Jayden
#[Out]# 22        Tim
#[Out]# 23       Siem
#[Out]# 24      Ruben
#[Out]# 25       Teun
#[Out]# 26    Olivier
#[Out]# 27       Sven
#[Out]# 28      David
#[Out]# 29      Stijn
#[Out]# ..        ...
#[Out]# 93      Sofia
#[Out]# 94       Lena
#[Out]# 95      Elise
#[Out]# 96        Ivy
#[Out]# 97       Fien
#[Out]# 98     Isabel
#[Out]# 99      Lizzy
#[Out]# 100      Jill
#[Out]# 101      Anne
#[Out]# 102      Puck
#[Out]# 103     Fenne
#[Out]# 104     Floor
#[Out]# 105     Elena
#[Out]# 106      Cato
#[Out]# 107     Hanna
#[Out]# 108    Veerle
#[Out]# 109      Kiki
#[Out]# 110      Lily
#[Out]# 111      Iris
#[Out]# 112     Tessa
#[Out]# 113      Lana
#[Out]# 114     Amira
#[Out]# 115     Eline
#[Out]# 116      Elif
#[Out]# 117      Juul
#[Out]# 118     Merel
#[Out]# 119      Liva
#[Out]# 120   Johanna
#[Out]# 121     Wilko
#[Out]# 122    Kostas
#[Out]# 
#[Out]# [123 rows x 1 columns]
# Mon, 30 Nov 2020 11:51:40
query3_4 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    
    INTERSECT

    SELECT SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 11:51:48
query3_4 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    
    INTERSECT

    SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    52    Willem
#[Out]# 10   59      Joep
#[Out]# 11   66   Mohamed
#[Out]# 12   68     Boris
#[Out]# 13   72      Dani
#[Out]# 14   78      Mick
#[Out]# 15   85    Pieter
#[Out]# 16   86      Stef
#[Out]# 17  109      Lynn
#[Out]# 18  112      Yara
#[Out]# 19  122      Elin
#[Out]# 20  126      Lina
#[Out]# 21  165     Hanna
#[Out]# 22  167    Veerle
#[Out]# 23  171     Tessa
#[Out]# 24  172      Lana
#[Out]# 25  180     Merel
#[Out]# 26  190    Kostas

# IPython log file

query3_2 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE %2018%    
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 14:23:15
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

query3_2 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE %2018%    
'''

pd.read_sql_query(query3_2, conn)
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Mon, 30 Nov 2020 14:23:15
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 14:23:16
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 14:23:20
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 14:23:23
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

query3_2 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE %2018%    
'''

pd.read_sql_query(query3_2, conn)
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 14:23:25
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 14:23:27
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 14:23:29
query3_2 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE %2018%    
'''

pd.read_sql_query(query3_2, conn)

# IPython log file

# Mon, 30 Nov 2020 14:23:53
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 14:23:53
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 14:24:03
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 14:24:09
query3_2 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE %2018%    
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 14:24:37
query3_2 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE "%2018%"    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 14:25:53
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 14:32:28
query3_3 = '''
    SELECT DISTINCT p.*, s.*, c.*
    FROM purchase as p, store as s, customer as c
    
    EXCEPT
    
    SELECT p.*, s.*, c.*
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          tID  cID  sID  pID        date  quantity  price  sID  sName  \
#[Out]# 0          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 1          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 2          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 3          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 4          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 5          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 6          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 7          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 8          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 9          0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 10         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 11         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 12         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 13         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 14         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 15         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 16         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 17         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 18         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 19         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 20         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 21         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 22         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 23         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 24         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 25         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 26         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 27         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 28         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# 29         0    0    3   10  2018-08-22         1   0.45    0   Coop   
#[Out]# ...      ...  ...  ...  ...         ...       ...    ...  ...    ...   
#[Out]# 6189365  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189366  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189367  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189368  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189369  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189370  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189371  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189372  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189373  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189374  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189375  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189376  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189377  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189378  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189379  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189380  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189381  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189382  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189383  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189384  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189385  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189386  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189387  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189388  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189389  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189390  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189391  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189392  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189393  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 6189394  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 
#[Out]#                 street       city  cID     cName                street  \
#[Out]# 0         Kalverstraat  Amsterdam    0      Noah             Koestraat   
#[Out]# 1         Kalverstraat  Amsterdam    1       Sem      Rozemarijnstraat   
#[Out]# 2         Kalverstraat  Amsterdam    2     Lucas      Oude Leliestraat   
#[Out]# 3         Kalverstraat  Amsterdam    3      Finn         Stationsplein   
#[Out]# 4         Kalverstraat  Amsterdam    4      Daan          Kalverstraat   
#[Out]# 5         Kalverstraat  Amsterdam    5      Levi        Gasthuisstraat   
#[Out]# 6         Kalverstraat  Amsterdam    6     Milan           Parallelweg   
#[Out]# 7         Kalverstraat  Amsterdam    7      Bram          Schoolstraat   
#[Out]# 8         Kalverstraat  Amsterdam    8      Liam         Rijsbergseweg   
#[Out]# 9         Kalverstraat  Amsterdam    9    Thomas           Parallelweg   
#[Out]# 10        Kalverstraat  Amsterdam   10       Sam           Langestraat   
#[Out]# 11        Kalverstraat  Amsterdam   11     Thijs             Koestraat   
#[Out]# 12        Kalverstraat  Amsterdam   12      Adam           Nieuwstraat   
#[Out]# 13        Kalverstraat  Amsterdam   13     James       Sint Annastraat   
#[Out]# 14        Kalverstraat  Amsterdam   14       Max             Eikenlaan   
#[Out]# 15        Kalverstraat  Amsterdam   15      Noud          Koningshoeve   
#[Out]# 16        Kalverstraat  Amsterdam   16    Julian  Prins Bernhardstraat   
#[Out]# 17        Kalverstraat  Amsterdam   17       Dex          Kasteeldreef   
#[Out]# 18        Kalverstraat  Amsterdam   18      Hugo          Kasteeldreef   
#[Out]# 19        Kalverstraat  Amsterdam   19      Lars         Rijsbergseweg   
#[Out]# 20        Kalverstraat  Amsterdam   20      Gijs            Heiligeweg   
#[Out]# 21        Kalverstraat  Amsterdam   21  Benjamin           Stationsweg   
#[Out]# 22        Kalverstraat  Amsterdam   22      Mats           Molenstraat   
#[Out]# 23        Kalverstraat  Amsterdam   23       Jan       Sint Annastraat   
#[Out]# 24        Kalverstraat  Amsterdam   24      Luca          Kasteeldreef   
#[Out]# 25        Kalverstraat  Amsterdam   25     Mason          Keizerstraat   
#[Out]# 26        Kalverstraat  Amsterdam   26    Jayden          Schoolstraat   
#[Out]# 27        Kalverstraat  Amsterdam   27       Tim             Koestraat   
#[Out]# 28        Kalverstraat  Amsterdam   28      Siem           Langestraat   
#[Out]# 29        Kalverstraat  Amsterdam   29     Ruben              Hofplein   
#[Out]# ...                ...        ...  ...       ...                   ...   
#[Out]# 6189365  Stationstraat        Oss  159     Fenne        Gasthuisstraat   
#[Out]# 6189366  Stationstraat        Oss  160      Lara           Langestraat   
#[Out]# 6189367  Stationstraat        Oss  161     Floor             Eikenlaan   
#[Out]# 6189368  Stationstraat        Oss  162     Elena            Bergselaan   
#[Out]# 6189369  Stationstraat        Oss  163      Cato          Kastanjelaan   
#[Out]# 6189370  Stationstraat        Oss  164       Evy      Rozemarijnstraat   
#[Out]# 6189371  Stationstraat        Oss  165     Hanna             Eikenlaan   
#[Out]# 6189372  Stationstraat        Oss  166   Rosalie           Stationsweg   
#[Out]# 6189373  Stationstraat        Oss  167    Veerle        Ginnekenstraat   
#[Out]# 6189374  Stationstraat        Oss  168      Kiki          Keizerstraat   
#[Out]# 6189375  Stationstraat        Oss  169      Lily        Gasthuisstraat   
#[Out]# 6189376  Stationstraat        Oss  170      Iris          Kastanjelaan   
#[Out]# 6189377  Stationstraat        Oss  171     Tessa           Haringvliet   
#[Out]# 6189378  Stationstraat        Oss  172      Lana             Eikenlaan   
#[Out]# 6189379  Stationstraat        Oss  173     Livia      Vierwindenstraat   
#[Out]# 6189380  Stationstraat        Oss  174      Romy           Parallelweg   
#[Out]# 6189381  Stationstraat        Oss  175       Sam             Bredalaan   
#[Out]# 6189382  Stationstraat        Oss  176     Amira           Parallelweg   
#[Out]# 6189383  Stationstraat        Oss  177     Eline          Kalverstraat   
#[Out]# 6189384  Stationstraat        Oss  178      Elif           Parallelweg   
#[Out]# 6189385  Stationstraat        Oss  179      Juul        Wilhelminapark   
#[Out]# 6189386  Stationstraat        Oss  180     Merel          Kalverstraat   
#[Out]# 6189387  Stationstraat        Oss  181      Liva           Fredriklaan   
#[Out]# 6189388  Stationstraat        Oss  182   Johanna         Beatrixstraat   
#[Out]# 6189389  Stationstraat        Oss  183     Nikki         Julianastraat   
#[Out]# 6189390  Stationstraat        Oss  184     Wilko          Onbekendeweg   
#[Out]# 6189391  Stationstraat        Oss  185      Nick                Verweg   
#[Out]# 6189392  Stationstraat        Oss  186    Angela              Dichtweg   
#[Out]# 6189393  Stationstraat        Oss  188      Pino            Maanstraat   
#[Out]# 6189394  Stationstraat        Oss  189      Koen              Akkerweg   
#[Out]# 
#[Out]#               city  
#[Out]# 0          Utrecht  
#[Out]# 1            Breda  
#[Out]# 2        Amsterdam  
#[Out]# 3            Breda  
#[Out]# 4        Amsterdam  
#[Out]# 5          Utrecht  
#[Out]# 6          Utrecht  
#[Out]# 7        Eindhoven  
#[Out]# 8            Breda  
#[Out]# 9        Amsterdam  
#[Out]# 10         Tilburg  
#[Out]# 11         Tilburg  
#[Out]# 12       Eindhoven  
#[Out]# 13           Breda  
#[Out]# 14         Tilburg  
#[Out]# 15         Tilburg  
#[Out]# 16       Eindhoven  
#[Out]# 17         Tilburg  
#[Out]# 18         Tilburg  
#[Out]# 19           Breda  
#[Out]# 20       Amsterdam  
#[Out]# 21         Tilburg  
#[Out]# 22       Eindhoven  
#[Out]# 23           Breda  
#[Out]# 24         Tilburg  
#[Out]# 25       Rotterdam  
#[Out]# 26       Eindhoven  
#[Out]# 27         Utrecht  
#[Out]# 28         Tilburg  
#[Out]# 29       Rotterdam  
#[Out]# ...            ...  
#[Out]# 6189365    Utrecht  
#[Out]# 6189366    Tilburg  
#[Out]# 6189367    Tilburg  
#[Out]# 6189368  Rotterdam  
#[Out]# 6189369    Tilburg  
#[Out]# 6189370      Breda  
#[Out]# 6189371    Tilburg  
#[Out]# 6189372  Eindhoven  
#[Out]# 6189373      Breda  
#[Out]# 6189374  Rotterdam  
#[Out]# 6189375    Utrecht  
#[Out]# 6189376  Eindhoven  
#[Out]# 6189377  Rotterdam  
#[Out]# 6189378    Tilburg  
#[Out]# 6189379      Breda  
#[Out]# 6189380  Eindhoven  
#[Out]# 6189381  Eindhoven  
#[Out]# 6189382  Amsterdam  
#[Out]# 6189383  Amsterdam  
#[Out]# 6189384    Utrecht  
#[Out]# 6189385    Tilburg  
#[Out]# 6189386  Amsterdam  
#[Out]# 6189387  Eindhoven  
#[Out]# 6189388  Eindhoven  
#[Out]# 6189389    Utrecht  
#[Out]# 6189390  Eindhoven  
#[Out]# 6189391  Eindhoven  
#[Out]# 6189392  Eindhoven  
#[Out]# 6189393  Rotterdam  
#[Out]# 6189394        Oss  
#[Out]# 
#[Out]# [6189395 rows x 15 columns]
# Mon, 30 Nov 2020 14:37:56
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName, p.date, s.Name
    FROM purchase as p, store as s, customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName, p.date, s.sName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 14:38:02
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName, p.date, s.sName
    FROM purchase as p, store as s, customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName, p.date, s.sName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cID   cName        date        sName
#[Out]# 0        0    Noah  2018-08-15  Albert Hein
#[Out]# 1        0    Noah  2018-08-15         Coop
#[Out]# 2        0    Noah  2018-08-15         Dirk
#[Out]# 3        0    Noah  2018-08-15    Hoogvliet
#[Out]# 4        0    Noah  2018-08-15        Jumbo
#[Out]# 5        0    Noah  2018-08-15         Lidl
#[Out]# 6        0    Noah  2018-08-15       Sligro
#[Out]# 7        0    Noah  2018-08-16  Albert Hein
#[Out]# 8        0    Noah  2018-08-16         Coop
#[Out]# 9        0    Noah  2018-08-16         Dirk
#[Out]# 10       0    Noah  2018-08-16    Hoogvliet
#[Out]# 11       0    Noah  2018-08-16        Jumbo
#[Out]# 12       0    Noah  2018-08-16         Lidl
#[Out]# 13       0    Noah  2018-08-16       Sligro
#[Out]# 14       0    Noah  2018-08-17  Albert Hein
#[Out]# 15       0    Noah  2018-08-17         Coop
#[Out]# 16       0    Noah  2018-08-17         Dirk
#[Out]# 17       0    Noah  2018-08-17    Hoogvliet
#[Out]# 18       0    Noah  2018-08-17        Jumbo
#[Out]# 19       0    Noah  2018-08-17         Lidl
#[Out]# 20       0    Noah  2018-08-17       Sligro
#[Out]# 21       0    Noah  2018-08-18  Albert Hein
#[Out]# 22       0    Noah  2018-08-18         Coop
#[Out]# 23       0    Noah  2018-08-18         Dirk
#[Out]# 24       0    Noah  2018-08-18    Hoogvliet
#[Out]# 25       0    Noah  2018-08-18        Jumbo
#[Out]# 26       0    Noah  2018-08-18         Lidl
#[Out]# 27       0    Noah  2018-08-18       Sligro
#[Out]# 28       0    Noah  2018-08-19  Albert Hein
#[Out]# 29       0    Noah  2018-08-19         Coop
#[Out]# ...    ...     ...         ...          ...
#[Out]# 21206  190  Kostas  2018-08-26         Lidl
#[Out]# 21207  190  Kostas  2018-08-26       Sligro
#[Out]# 21208  190  Kostas  2018-08-27  Albert Hein
#[Out]# 21209  190  Kostas  2018-08-27         Coop
#[Out]# 21210  190  Kostas  2018-08-27         Dirk
#[Out]# 21211  190  Kostas  2018-08-27    Hoogvliet
#[Out]# 21212  190  Kostas  2018-08-27        Jumbo
#[Out]# 21213  190  Kostas  2018-08-27         Lidl
#[Out]# 21214  190  Kostas  2018-08-27       Sligro
#[Out]# 21215  190  Kostas  2018-08-28  Albert Hein
#[Out]# 21216  190  Kostas  2018-08-28         Coop
#[Out]# 21217  190  Kostas  2018-08-28         Dirk
#[Out]# 21218  190  Kostas  2018-08-28    Hoogvliet
#[Out]# 21219  190  Kostas  2018-08-28        Jumbo
#[Out]# 21220  190  Kostas  2018-08-28         Lidl
#[Out]# 21221  190  Kostas  2018-08-28       Sligro
#[Out]# 21222  190  Kostas  2018-08-29  Albert Hein
#[Out]# 21223  190  Kostas  2018-08-29         Coop
#[Out]# 21224  190  Kostas  2018-08-29         Dirk
#[Out]# 21225  190  Kostas  2018-08-29    Hoogvliet
#[Out]# 21226  190  Kostas  2018-08-29        Jumbo
#[Out]# 21227  190  Kostas  2018-08-29         Lidl
#[Out]# 21228  190  Kostas  2018-08-29       Sligro
#[Out]# 21229  190  Kostas  2018-09-20  Albert Hein
#[Out]# 21230  190  Kostas  2018-09-20         Coop
#[Out]# 21231  190  Kostas  2018-09-20         Dirk
#[Out]# 21232  190  Kostas  2018-09-20    Hoogvliet
#[Out]# 21233  190  Kostas  2018-09-20        Jumbo
#[Out]# 21234  190  Kostas  2018-09-20         Lidl
#[Out]# 21235  190  Kostas  2018-09-20       Sligro
#[Out]# 
#[Out]# [21236 rows x 4 columns]
# Mon, 30 Nov 2020 14:38:52
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName, p.date, s.sName
    FROM customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName, p.date, s.sName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 14:39:34
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName, p.date, s.sName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND p.cID = c.cID
    
    EXCEPT
    
    SELECT c.cID, c.cName, p.date, s.sName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName        date        sName
#[Out]# 0      0    Noah  2018-08-22       Sligro
#[Out]# 1      1     Sem  2018-08-20  Albert Hein
#[Out]# 2      1     Sem  2018-08-20         Dirk
#[Out]# 3      1     Sem  2018-08-20    Hoogvliet
#[Out]# 4      1     Sem  2018-08-20         Lidl
#[Out]# 5      1     Sem  2018-08-20       Sligro
#[Out]# 6      1     Sem  2018-08-21         Lidl
#[Out]# 7      2   Lucas  2018-08-16         Lidl
#[Out]# 8      2   Lucas  2018-08-17         Coop
#[Out]# 9      2   Lucas  2018-08-17       Sligro
#[Out]# 10     3    Finn  2018-08-18  Albert Hein
#[Out]# 11     3    Finn  2018-08-19         Dirk
#[Out]# 12     3    Finn  2018-08-19       Sligro
#[Out]# 13     4    Daan  2018-08-24         Coop
#[Out]# 14     4    Daan  2018-08-24    Hoogvliet
#[Out]# 15     4    Daan  2018-08-25  Albert Hein
#[Out]# 16     4    Daan  2018-08-25         Coop
#[Out]# 17     4    Daan  2018-08-25       Sligro
#[Out]# 18     5    Levi  2018-08-17    Hoogvliet
#[Out]# 19     5    Levi  2018-08-22         Lidl
#[Out]# 20     5    Levi  2018-08-23         Coop
#[Out]# 21     5    Levi  2018-08-23    Hoogvliet
#[Out]# 22     7    Bram  2018-08-23         Lidl
#[Out]# 23     7    Bram  2018-08-23       Sligro
#[Out]# 24     7    Bram  2018-08-24  Albert Hein
#[Out]# 25     7    Bram  2018-08-25  Albert Hein
#[Out]# 26     7    Bram  2018-08-26    Hoogvliet
#[Out]# 27     7    Bram  2018-08-26       Sligro
#[Out]# 28     8    Liam  2018-08-16         Coop
#[Out]# 29    10     Sam  2018-08-27         Coop
#[Out]# ..   ...     ...         ...          ...
#[Out]# 370  190  Kostas  2018-08-17         Lidl
#[Out]# 371  190  Kostas  2018-08-17       Sligro
#[Out]# 372  190  Kostas  2018-08-18  Albert Hein
#[Out]# 373  190  Kostas  2018-08-18         Coop
#[Out]# 374  190  Kostas  2018-08-18         Dirk
#[Out]# 375  190  Kostas  2018-08-19         Coop
#[Out]# 376  190  Kostas  2018-08-19         Dirk
#[Out]# 377  190  Kostas  2018-08-19         Lidl
#[Out]# 378  190  Kostas  2018-08-20  Albert Hein
#[Out]# 379  190  Kostas  2018-08-20         Coop
#[Out]# 380  190  Kostas  2018-08-20         Lidl
#[Out]# 381  190  Kostas  2018-08-20       Sligro
#[Out]# 382  190  Kostas  2018-08-21       Sligro
#[Out]# 383  190  Kostas  2018-08-22  Albert Hein
#[Out]# 384  190  Kostas  2018-08-22         Dirk
#[Out]# 385  190  Kostas  2018-08-22    Hoogvliet
#[Out]# 386  190  Kostas  2018-08-22       Sligro
#[Out]# 387  190  Kostas  2018-08-23    Hoogvliet
#[Out]# 388  190  Kostas  2018-08-23         Lidl
#[Out]# 389  190  Kostas  2018-08-23       Sligro
#[Out]# 390  190  Kostas  2018-08-24    Hoogvliet
#[Out]# 391  190  Kostas  2018-08-25         Dirk
#[Out]# 392  190  Kostas  2018-08-25         Lidl
#[Out]# 393  190  Kostas  2018-08-25       Sligro
#[Out]# 394  190  Kostas  2018-08-26  Albert Hein
#[Out]# 395  190  Kostas  2018-08-26         Coop
#[Out]# 396  190  Kostas  2018-08-26    Hoogvliet
#[Out]# 397  190  Kostas  2018-08-26         Lidl
#[Out]# 398  190  Kostas  2018-08-27         Lidl
#[Out]# 399  190  Kostas  2018-08-27       Sligro
#[Out]# 
#[Out]# [400 rows x 4 columns]
# Mon, 30 Nov 2020 14:40:18
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 14:44:49
query3_2 = '''
    SELECT distinct c.cID, c.cName, s.date
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE "%2018%"    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName        date
#[Out]# 0      1       Sem  2018-08-20
#[Out]# 1      1       Sem  2018-08-21
#[Out]# 2      2     Lucas  2018-08-16
#[Out]# 3      2     Lucas  2018-08-17
#[Out]# 4      3      Finn  2018-08-18
#[Out]# 5      3      Finn  2018-08-19
#[Out]# 6      5      Levi  2018-08-17
#[Out]# 7      5      Levi  2018-08-22
#[Out]# 8      5      Levi  2018-08-23
#[Out]# 9      7      Bram  2018-08-23
#[Out]# 10     7      Bram  2018-08-24
#[Out]# 11     7      Bram  2018-08-25
#[Out]# 12     7      Bram  2018-08-26
#[Out]# 13     8      Liam  2018-08-16
#[Out]# 14    10       Sam  2018-08-27
#[Out]# 15    11     Thijs  2018-08-25
#[Out]# 16    13     James  2018-08-17
#[Out]# 17    13     James  2018-08-25
#[Out]# 18    13     James  2018-08-26
#[Out]# 19    13     James  2018-08-27
#[Out]# 20    15      Noud  2018-08-27
#[Out]# 21    17       Dex  2018-08-19
#[Out]# 22    18      Hugo  2018-08-16
#[Out]# 23    18      Hugo  2018-08-18
#[Out]# 24    19      Lars  2018-08-17
#[Out]# 25    19      Lars  2018-08-18
#[Out]# 26    20      Gijs  2018-08-17
#[Out]# 27    20      Gijs  2018-08-18
#[Out]# 28    21  Benjamin  2018-08-15
#[Out]# 29    22      Mats  2018-08-27
#[Out]# ..   ...       ...         ...
#[Out]# 156  165     Hanna  2018-08-23
#[Out]# 157  165     Hanna  2018-08-24
#[Out]# 158  167    Veerle  2018-08-18
#[Out]# 159  167    Veerle  2018-08-19
#[Out]# 160  167    Veerle  2018-08-20
#[Out]# 161  167    Veerle  2018-08-21
#[Out]# 162  167    Veerle  2018-08-15
#[Out]# 163  168      Kiki  2018-08-16
#[Out]# 164  169      Lily  2018-08-16
#[Out]# 165  169      Lily  2018-08-17
#[Out]# 166  169      Lily  2018-08-18
#[Out]# 167  169      Lily  2018-08-19
#[Out]# 168  169      Lily  2018-08-20
#[Out]# 169  169      Lily  2018-08-26
#[Out]# 170  169      Lily  2018-08-27
#[Out]# 171  170      Iris  2018-08-16
#[Out]# 172  171     Tessa  2018-08-20
#[Out]# 173  172      Lana  2018-08-27
#[Out]# 174  172      Lana  2018-08-24
#[Out]# 175  175       Sam  2018-08-19
#[Out]# 176  176     Amira  2018-08-22
#[Out]# 177  176     Amira  2018-08-25
#[Out]# 178  176     Amira  2018-08-26
#[Out]# 179  178      Elif  2018-08-27
#[Out]# 180  179      Juul  2018-08-24
#[Out]# 181  179      Juul  2018-08-22
#[Out]# 182  180     Merel  2018-08-26
#[Out]# 183  180     Merel  2018-08-27
#[Out]# 184  181      Liva  2018-08-24
#[Out]# 185  181      Liva  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Mon, 30 Nov 2020 15:10:48
query3_4 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    
    INTERSECT
    
    SELECT distinct c.cID, c.cName
    FROM customer as c
    WHERE c.cID, c.cName NOT IN (
        SELECT distinct c.cID, c.cName
        FROM purchase as p, store as s, customer as c
        WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID)
    
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 15:11:38
query3_4 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    
    INTERSECT
    
    SELECT distinct c.cID, c.cName
    FROM customer as c
    WHERE c.cID NOT IN (
        SELECT distinct c.cID, c.cName
        FROM purchase as p, store as s, customer as c
        WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID)
    
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 15:11:56
query3_4 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    
    INTERSECT
    
    SELECT distinct c.cID, c.cName
    FROM customer as c
    WHERE c.cID, c.cName NOT IN (
        SELECT distinct c.cID, c.cName
        FROM purchase as p, store as s, customer as c
        WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID)
    
'''

pd.read_sql_query(query3_4, conn)

# IPython log file

# Mon, 30 Nov 2020 15:12:20
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 15:12:20
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 15:13:00
query3_2 = '''
    SELECT distinct c.cID, c.cName, s.date
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE "%2018%"    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName        date
#[Out]# 0      1       Sem  2018-08-20
#[Out]# 1      1       Sem  2018-08-21
#[Out]# 2      2     Lucas  2018-08-16
#[Out]# 3      2     Lucas  2018-08-17
#[Out]# 4      3      Finn  2018-08-18
#[Out]# 5      3      Finn  2018-08-19
#[Out]# 6      5      Levi  2018-08-17
#[Out]# 7      5      Levi  2018-08-22
#[Out]# 8      5      Levi  2018-08-23
#[Out]# 9      7      Bram  2018-08-23
#[Out]# 10     7      Bram  2018-08-24
#[Out]# 11     7      Bram  2018-08-25
#[Out]# 12     7      Bram  2018-08-26
#[Out]# 13     8      Liam  2018-08-16
#[Out]# 14    10       Sam  2018-08-27
#[Out]# 15    11     Thijs  2018-08-25
#[Out]# 16    13     James  2018-08-17
#[Out]# 17    13     James  2018-08-25
#[Out]# 18    13     James  2018-08-26
#[Out]# 19    13     James  2018-08-27
#[Out]# 20    15      Noud  2018-08-27
#[Out]# 21    17       Dex  2018-08-19
#[Out]# 22    18      Hugo  2018-08-16
#[Out]# 23    18      Hugo  2018-08-18
#[Out]# 24    19      Lars  2018-08-17
#[Out]# 25    19      Lars  2018-08-18
#[Out]# 26    20      Gijs  2018-08-17
#[Out]# 27    20      Gijs  2018-08-18
#[Out]# 28    21  Benjamin  2018-08-15
#[Out]# 29    22      Mats  2018-08-27
#[Out]# ..   ...       ...         ...
#[Out]# 156  165     Hanna  2018-08-23
#[Out]# 157  165     Hanna  2018-08-24
#[Out]# 158  167    Veerle  2018-08-18
#[Out]# 159  167    Veerle  2018-08-19
#[Out]# 160  167    Veerle  2018-08-20
#[Out]# 161  167    Veerle  2018-08-21
#[Out]# 162  167    Veerle  2018-08-15
#[Out]# 163  168      Kiki  2018-08-16
#[Out]# 164  169      Lily  2018-08-16
#[Out]# 165  169      Lily  2018-08-17
#[Out]# 166  169      Lily  2018-08-18
#[Out]# 167  169      Lily  2018-08-19
#[Out]# 168  169      Lily  2018-08-20
#[Out]# 169  169      Lily  2018-08-26
#[Out]# 170  169      Lily  2018-08-27
#[Out]# 171  170      Iris  2018-08-16
#[Out]# 172  171     Tessa  2018-08-20
#[Out]# 173  172      Lana  2018-08-27
#[Out]# 174  172      Lana  2018-08-24
#[Out]# 175  175       Sam  2018-08-19
#[Out]# 176  176     Amira  2018-08-22
#[Out]# 177  176     Amira  2018-08-25
#[Out]# 178  176     Amira  2018-08-26
#[Out]# 179  178      Elif  2018-08-27
#[Out]# 180  179      Juul  2018-08-24
#[Out]# 181  179      Juul  2018-08-22
#[Out]# 182  180     Merel  2018-08-26
#[Out]# 183  180     Merel  2018-08-27
#[Out]# 184  181      Liva  2018-08-24
#[Out]# 185  181      Liva  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Mon, 30 Nov 2020 15:13:24
query3_2 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, shoppinglist as s, customer as c
    WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE "%2018%"    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 15:13:28
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c
    
    EXCEPT
    
    SELECT c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 15:13:30
query3_4 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    
    INTERSECT
    
    SELECT distinct c.cID, c.cName
    FROM customer as c
    WHERE c.cID, c.cName NOT IN (
        SELECT distinct c.cID, c.cName
        FROM purchase as p, store as s, customer as c
        WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID)
    
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 15:13:59
query3_4 = '''
    (SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID)
    
    INTERSECT
    
    (SELECT distinct c.cID, c.cName
    FROM customer as c
    WHERE c.cID, c.cName NOT IN (
        SELECT distinct c.cID, c.cName
        FROM purchase as p, store as s, customer as c
        WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID))
    
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 15:14:42
query3_4 = '''
    SELECT distinct c.cID, c.cName
    FROM purchase as p, store as s, customer as c
    WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    
    INTERSECT
    
    SELECT distinct c.cID, c.cName
    FROM customer as c
    WHERE (c.cID, c.cName) NOT IN (
        SELECT distinct c.cID, c.cName
        FROM purchase as p, store as s, customer as c
        WHERE p.sID = s.sID AND s.sName != "Jumbo" AND p.cID = c.cID)
    
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen

# IPython log file

# Tue, 01 Dec 2020 21:45:53
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 21:45:55
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 01 Dec 2020 21:49:18
query3_2 = '''
    SELECT distinct c.cID, c.cName
FROM purchase as p, shoppinglist as s, customer as c
WHERE p.cID = s.cID AND s.date = p.date AND c.cID = s.cID AND s.date LIKE "%2018%"    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 21:49:41
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName
FROM customer as c
    
EXCEPT
    
SELECT c.cID, c.cName
FROM purchase as p, store as s, customer as c
WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 21:50:02
query3_4 = '''
    SELECT distinct c.cID, c.cName
FROM purchase as p, store as s, customer as c
WHERE p.sID = s.sID AND s.sName = "Jumbo" AND p.cID = c.cID
    
INTERSECT

SELECT distinct c.cID, c.cName
FROM customer as c
WHERE (c.cID, c.cName) NOT IN ( 
	SELECT cu.cID, cu.cName
        FROM purchase as pu, store as st, customer as cu
        WHERE pu.sID = st.sID AND st.sName != "Jumbo" AND pu.cID = cu.cID)
    
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen


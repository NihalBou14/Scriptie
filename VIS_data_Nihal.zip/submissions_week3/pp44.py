# IPython log file

# Tue, 01 Dec 2020 13:03:17
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 13:06:47
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1a8af637ab0>
# Tue, 01 Dec 2020 13:07:14
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 17:45:10
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer c
    WHERE (cName, cID) IN 
    (SELECT c.cID
    FROM shoppinglist s, purchase p
    WHERE c.cID = s.cID AND c.cID=p.cID AND s.date = p.date AND s.date = p.date AND (s.date LIKE '2018%'))
'''
# Tue, 01 Dec 2020 17:45:12
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:45:41
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer c
    WHERE (cName, cID) IN (SELECT c.cID
    FROM shoppinglist s, purchase p
    WHERE c.cID = s.cID AND c.cID=p.cID AND s.date = p.date AND s.date = p.date AND (s.date LIKE '2018%'));
'''
# Tue, 01 Dec 2020 17:45:41
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:46:01
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer c
    WHERE cID IN (SELECT c.cID
    FROM shoppinglist s, purchase p
    WHERE c.cID = s.cID AND c.cID=p.cID AND s.date = p.date AND s.date = p.date AND (s.date LIKE '2018%'));
'''
# Tue, 01 Dec 2020 17:46:01
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:47:27
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer c
    WHERE cID IN (SELECT c.cID
    FROM shoppinglist s, purchase p
    WHERE c.cID = s.cID AND c.cID=p.cID AND s.date = p.date AND (s.date LIKE '2018%'));
'''
# Tue, 01 Dec 2020 17:47:28
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:49:22
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer c
    WHERE (cName,cID) IN (SELECT c.cID, cName
    FROM shoppinglist s, purchase p
    WHERE c.cID = s.cID AND c.cID=p.cID AND s.date = p.date AND (s.date LIKE '2018%'));
'''
# Tue, 01 Dec 2020 17:49:22
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:49:31
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer c
    WHERE cName, cID IN (SELECT c.cID, cName
    FROM shoppinglist s, purchase p
    WHERE c.cID = s.cID AND c.cID=p.cID AND s.date = p.date AND (s.date LIKE '2018%'));
'''
# Tue, 01 Dec 2020 17:49:32
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:49:47
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer c
    WHERE cID IN (SELECT c.cID
    FROM shoppinglist s, purchase p
    WHERE c.cID = s.cID AND c.cID=p.cID AND s.date = p.date AND (s.date LIKE '2018%'));
'''
# Tue, 01 Dec 2020 17:49:47
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:50:09
pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 17:53:32
query3_3 = '''
    PUT YOUR QUERY HERE
'''
# Tue, 01 Dec 2020 17:53:43
#pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 18:39:41
query3_3 = '''
    select distinct cName, cID
    from customer c
    where cID not in
    (select p.cID
    from purchase p, store st
    where p.sID = st.sID and st.sName LIKE 'Coop')
'''
# Tue, 01 Dec 2020 18:39:41
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:40:09
pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2        Finn    3
#[Out]# 3       Milan    6
#[Out]# 4        Bram    7
#[Out]# 5      Thomas    9
#[Out]# 6        Adam   12
#[Out]# 7       James   13
#[Out]# 8         Max   14
#[Out]# 9        Noud   15
#[Out]# 10       Lars   19
#[Out]# 11       Mats   22
#[Out]# 12        Jan   23
#[Out]# 13      Mason   25
#[Out]# 14       Teun   30
#[Out]# 15    Olivier   31
#[Out]# 16      Vince   32
#[Out]# 17      David   34
#[Out]# 18       Boaz   36
#[Out]# 19       Guus   37
#[Out]# 20     Floris   38
#[Out]# 21       Jens   40
#[Out]# 22      Quinn   41
#[Out]# 23        Tom   43
#[Out]# 24      Jason   44
#[Out]# 25       Ryan   45
#[Out]# 26      Fedde   46
#[Out]# 27       Xavi   47
#[Out]# 28       Tygo   48
#[Out]# 29        Cas   49
#[Out]# ..        ...  ...
#[Out]# 86         Bo  142
#[Out]# 87      Naomi  143
#[Out]# 88       Fien  145
#[Out]# 89      Norah  146
#[Out]# 90   Isabella  148
#[Out]# 91      Lizzy  149
#[Out]# 92      Julie  150
#[Out]# 93      Amber  153
#[Out]# 94     Benthe  154
#[Out]# 95      Linde  155
#[Out]# 96       Luna  156
#[Out]# 97       Puck  157
#[Out]# 98       Rosa  158
#[Out]# 99      Fenne  159
#[Out]# 100      Lara  160
#[Out]# 101       Evy  164
#[Out]# 102   Rosalie  166
#[Out]# 103    Veerle  167
#[Out]# 104      Kiki  168
#[Out]# 105      Iris  170
#[Out]# 106     Tessa  171
#[Out]# 107     Livia  173
#[Out]# 108      Romy  174
#[Out]# 109       Sam  175
#[Out]# 110   Johanna  182
#[Out]# 111     Nikki  183
#[Out]# 112      Nick  185
#[Out]# 113    Angela  186
#[Out]# 114      Pino  188
#[Out]# 115      Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 18:40:46
query3_3 = '''
    select distinct cName, cID
    from customer c
    where cID not in
    (select p.cID
    from purchase p, store st
    where p.sID = st.sID and st.sName LIKE 'Jumbo')
'''
# Tue, 01 Dec 2020 18:40:46
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:40:47
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# 5      Milan    6
#[Out]# 6       Bram    7
#[Out]# 7       Liam    8
#[Out]# 8     Thomas    9
#[Out]# 9        Sam   10
#[Out]# 10     Thijs   11
#[Out]# 11      Adam   12
#[Out]# 12     James   13
#[Out]# 13       Max   14
#[Out]# 14      Noud   15
#[Out]# 15    Julian   16
#[Out]# 16       Dex   17
#[Out]# 17      Gijs   20
#[Out]# 18      Mats   22
#[Out]# 19       Jan   23
#[Out]# 20     Mason   25
#[Out]# 21    Jayden   26
#[Out]# 22      Siem   28
#[Out]# 23     Ruben   29
#[Out]# 24      Teun   30
#[Out]# 25   Olivier   31
#[Out]# 26     Vince   32
#[Out]# 27      Sven   33
#[Out]# 28     David   34
#[Out]# 29     Stijn   35
#[Out]# ..       ...  ...
#[Out]# 125    Julie  150
#[Out]# 126     Jill  151
#[Out]# 127     Anne  152
#[Out]# 128    Amber  153
#[Out]# 129   Benthe  154
#[Out]# 130    Linde  155
#[Out]# 131     Luna  156
#[Out]# 132     Puck  157
#[Out]# 133     Rosa  158
#[Out]# 134    Fenne  159
#[Out]# 135     Lara  160
#[Out]# 136    Floor  161
#[Out]# 137    Elena  162
#[Out]# 138     Cato  163
#[Out]# 139      Evy  164
#[Out]# 140  Rosalie  166
#[Out]# 141     Kiki  168
#[Out]# 142     Lily  169
#[Out]# 143     Iris  170
#[Out]# 144    Livia  173
#[Out]# 145     Romy  174
#[Out]# 146      Sam  175
#[Out]# 147    Amira  176
#[Out]# 148    Eline  177
#[Out]# 149     Elif  178
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 18:42:34
query3_3 = '''
    select distinct cName, cID
    from customer c
    where cID not in
    (select p.cID
    from purchase p, store st
    where p.sID = st.sID and st.sName LIKE 'Sligro')
'''
# Tue, 01 Dec 2020 18:42:34
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:42:35
pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Levi    5
#[Out]# 1       Milan    6
#[Out]# 2        Liam    8
#[Out]# 3      Thomas    9
#[Out]# 4         Sam   10
#[Out]# 5       Thijs   11
#[Out]# 6        Adam   12
#[Out]# 7         Max   14
#[Out]# 8        Noud   15
#[Out]# 9         Dex   17
#[Out]# 10   Benjamin   21
#[Out]# 11        Jan   23
#[Out]# 12       Luca   24
#[Out]# 13      Mason   25
#[Out]# 14     Jayden   26
#[Out]# 15       Siem   28
#[Out]# 16      Vince   32
#[Out]# 17      David   34
#[Out]# 18      Stijn   35
#[Out]# 19       Boaz   36
#[Out]# 20       Guus   37
#[Out]# 21     Floris   38
#[Out]# 22       Jack   39
#[Out]# 23       Jens   40
#[Out]# 24       Tijn   42
#[Out]# 25       Ryan   45
#[Out]# 26      Fedde   46
#[Out]# 27       Xavi   47
#[Out]# 28       Tygo   48
#[Out]# 29        Cas   49
#[Out]# ..        ...  ...
#[Out]# 101     Julie  150
#[Out]# 102      Jill  151
#[Out]# 103     Amber  153
#[Out]# 104    Benthe  154
#[Out]# 105     Linde  155
#[Out]# 106      Luna  156
#[Out]# 107      Puck  157
#[Out]# 108      Rosa  158
#[Out]# 109     Fenne  159
#[Out]# 110      Lara  160
#[Out]# 111      Cato  163
#[Out]# 112       Evy  164
#[Out]# 113     Hanna  165
#[Out]# 114   Rosalie  166
#[Out]# 115      Kiki  168
#[Out]# 116      Iris  170
#[Out]# 117     Tessa  171
#[Out]# 118      Lana  172
#[Out]# 119     Livia  173
#[Out]# 120      Romy  174
#[Out]# 121     Amira  176
#[Out]# 122     Eline  177
#[Out]# 123      Juul  179
#[Out]# 124     Merel  180
#[Out]# 125     Nikki  183
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 
#[Out]# [131 rows x 2 columns]
# Tue, 01 Dec 2020 18:44:04
query3_3 = '''
    select distinct cName, cID
    from customer c
    where cID not in
    (select p.cID
    from purchase p, store st
    where p.sID = st.sID and st.sName LIKE 'Jumbo')
'''
# Tue, 01 Dec 2020 18:44:04
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:44:04
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# 5      Milan    6
#[Out]# 6       Bram    7
#[Out]# 7       Liam    8
#[Out]# 8     Thomas    9
#[Out]# 9        Sam   10
#[Out]# 10     Thijs   11
#[Out]# 11      Adam   12
#[Out]# 12     James   13
#[Out]# 13       Max   14
#[Out]# 14      Noud   15
#[Out]# 15    Julian   16
#[Out]# 16       Dex   17
#[Out]# 17      Gijs   20
#[Out]# 18      Mats   22
#[Out]# 19       Jan   23
#[Out]# 20     Mason   25
#[Out]# 21    Jayden   26
#[Out]# 22      Siem   28
#[Out]# 23     Ruben   29
#[Out]# 24      Teun   30
#[Out]# 25   Olivier   31
#[Out]# 26     Vince   32
#[Out]# 27      Sven   33
#[Out]# 28     David   34
#[Out]# 29     Stijn   35
#[Out]# ..       ...  ...
#[Out]# 125    Julie  150
#[Out]# 126     Jill  151
#[Out]# 127     Anne  152
#[Out]# 128    Amber  153
#[Out]# 129   Benthe  154
#[Out]# 130    Linde  155
#[Out]# 131     Luna  156
#[Out]# 132     Puck  157
#[Out]# 133     Rosa  158
#[Out]# 134    Fenne  159
#[Out]# 135     Lara  160
#[Out]# 136    Floor  161
#[Out]# 137    Elena  162
#[Out]# 138     Cato  163
#[Out]# 139      Evy  164
#[Out]# 140  Rosalie  166
#[Out]# 141     Kiki  168
#[Out]# 142     Lily  169
#[Out]# 143     Iris  170
#[Out]# 144    Livia  173
#[Out]# 145     Romy  174
#[Out]# 146      Sam  175
#[Out]# 147    Amira  176
#[Out]# 148    Eline  177
#[Out]# 149     Elif  178
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 18:47:37
query3_3 = '''
    select distinct cName, cID
    from customer c
    where cID not in
    (select p.cID
    from purchase p, store st
    where p.sID = st.sID and st.sName LIKE 'Kumar')
'''
# Tue, 01 Dec 2020 18:47:38
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:47:39
pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 18:48:31
#pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 18:48:56
query3_4 = '''
    select cID
    from customer
'''
# Tue, 01 Dec 2020 18:48:56
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 18:48:57
pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# 5      5
#[Out]# 6      6
#[Out]# 7      7
#[Out]# 8      8
#[Out]# 9      9
#[Out]# 10    10
#[Out]# 11    11
#[Out]# 12    12
#[Out]# 13    13
#[Out]# 14    14
#[Out]# 15    15
#[Out]# 16    16
#[Out]# 17    17
#[Out]# 18    18
#[Out]# 19    19
#[Out]# 20    20
#[Out]# 21    21
#[Out]# 22    22
#[Out]# 23    23
#[Out]# 24    24
#[Out]# 25    25
#[Out]# 26    26
#[Out]# 27    27
#[Out]# 28    28
#[Out]# 29    29
#[Out]# ..   ...
#[Out]# 160  160
#[Out]# 161  161
#[Out]# 162  162
#[Out]# 163  163
#[Out]# 164  164
#[Out]# 165  165
#[Out]# 166  166
#[Out]# 167  167
#[Out]# 168  168
#[Out]# 169  169
#[Out]# 170  170
#[Out]# 171  171
#[Out]# 172  172
#[Out]# 173  173
#[Out]# 174  174
#[Out]# 175  175
#[Out]# 176  176
#[Out]# 177  177
#[Out]# 178  178
#[Out]# 179  179
#[Out]# 180  180
#[Out]# 181  181
#[Out]# 182  182
#[Out]# 183  183
#[Out]# 184  184
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 18:49:08
query3_4 = '''
    select distinct cID
    from customer
'''
# Tue, 01 Dec 2020 18:49:08
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 18:49:09
pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# 5      5
#[Out]# 6      6
#[Out]# 7      7
#[Out]# 8      8
#[Out]# 9      9
#[Out]# 10    10
#[Out]# 11    11
#[Out]# 12    12
#[Out]# 13    13
#[Out]# 14    14
#[Out]# 15    15
#[Out]# 16    16
#[Out]# 17    17
#[Out]# 18    18
#[Out]# 19    19
#[Out]# 20    20
#[Out]# 21    21
#[Out]# 22    22
#[Out]# 23    23
#[Out]# 24    24
#[Out]# 25    25
#[Out]# 26    26
#[Out]# 27    27
#[Out]# 28    28
#[Out]# 29    29
#[Out]# ..   ...
#[Out]# 160  160
#[Out]# 161  161
#[Out]# 162  162
#[Out]# 163  163
#[Out]# 164  164
#[Out]# 165  165
#[Out]# 166  166
#[Out]# 167  167
#[Out]# 168  168
#[Out]# 169  169
#[Out]# 170  170
#[Out]# 171  171
#[Out]# 172  172
#[Out]# 173  173
#[Out]# 174  174
#[Out]# 175  175
#[Out]# 176  176
#[Out]# 177  177
#[Out]# 178  178
#[Out]# 179  179
#[Out]# 180  180
#[Out]# 181  181
#[Out]# 182  182
#[Out]# 183  183
#[Out]# 184  184
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 18:49:16
query3_4 = '''
    select distinct cID,cName
    from customer
'''
# Tue, 01 Dec 2020 18:49:16
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 18:49:17
pd.read_sql_query(query3_4, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 18:49:54
query3_3 = '''
    select distinct cName, cID
    from customer c
    where cID not in
    (select p.cID
    from purchase p, store st
    where p.sID = st.sID and st.sName LIKE 'Kumar')
'''
# Tue, 01 Dec 2020 18:49:55
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:49:55
#pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 18:49:59
pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 18:50:29
query3_3 = '''
    select distinct cName, cID
    from customer c
    
'''
# Tue, 01 Dec 2020 18:50:30
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:50:30
pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 18:50:45
query3_3 = '''
    select distinct cName, cID
    from customer c
    where cID not in
    (select p.cID
    from purchase p, store st
    where p.sID = st.sID and st.sName LIKE 'Kumar')
    
'''
# Tue, 01 Dec 2020 18:50:45
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:50:47
pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 18:50:54
query3_3 = '''
    select distinct cName, cID
    from customer c
    
    
'''
# Tue, 01 Dec 2020 18:50:55
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:50:55
pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 18:51:08
query3_3 = '''
    select distinct cName, cID
    from customer c
    where cID not in
    (select p.cID
    from purchase p, store st
    where p.sID = st.sID and st.sName LIKE 'Jumbo')    
'''
# Tue, 01 Dec 2020 18:51:08
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 18:51:09
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# 5      Milan    6
#[Out]# 6       Bram    7
#[Out]# 7       Liam    8
#[Out]# 8     Thomas    9
#[Out]# 9        Sam   10
#[Out]# 10     Thijs   11
#[Out]# 11      Adam   12
#[Out]# 12     James   13
#[Out]# 13       Max   14
#[Out]# 14      Noud   15
#[Out]# 15    Julian   16
#[Out]# 16       Dex   17
#[Out]# 17      Gijs   20
#[Out]# 18      Mats   22
#[Out]# 19       Jan   23
#[Out]# 20     Mason   25
#[Out]# 21    Jayden   26
#[Out]# 22      Siem   28
#[Out]# 23     Ruben   29
#[Out]# 24      Teun   30
#[Out]# 25   Olivier   31
#[Out]# 26     Vince   32
#[Out]# 27      Sven   33
#[Out]# 28     David   34
#[Out]# 29     Stijn   35
#[Out]# ..       ...  ...
#[Out]# 125    Julie  150
#[Out]# 126     Jill  151
#[Out]# 127     Anne  152
#[Out]# 128    Amber  153
#[Out]# 129   Benthe  154
#[Out]# 130    Linde  155
#[Out]# 131     Luna  156
#[Out]# 132     Puck  157
#[Out]# 133     Rosa  158
#[Out]# 134    Fenne  159
#[Out]# 135     Lara  160
#[Out]# 136    Floor  161
#[Out]# 137    Elena  162
#[Out]# 138     Cato  163
#[Out]# 139      Evy  164
#[Out]# 140  Rosalie  166
#[Out]# 141     Kiki  168
#[Out]# 142     Lily  169
#[Out]# 143     Iris  170
#[Out]# 144    Livia  173
#[Out]# 145     Romy  174
#[Out]# 146      Sam  175
#[Out]# 147    Amira  176
#[Out]# 148    Eline  177
#[Out]# 149     Elif  178
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 18:51:18
#pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 18:54:45
query3_4 = '''
    
'''
# Tue, 01 Dec 2020 18:54:46
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 18:54:46
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 19:01:50
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl';
'''
# Tue, 01 Dec 2020 19:01:50
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:01:51
pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID
#[Out]# 0        Sem    1
#[Out]# 1      Lucas    2
#[Out]# 2       Levi    5
#[Out]# 3       Bram    7
#[Out]# 4      James   13
#[Out]# 5     Julian   16
#[Out]# 6       Lars   19
#[Out]# 7       Luca   24
#[Out]# 8      Mason   25
#[Out]# 9       Sven   33
#[Out]# 10      Guus   37
#[Out]# 11      Jens   40
#[Out]# 12      Tijn   42
#[Out]# 13       Tom   43
#[Out]# 14      Ties   51
#[Out]# 15    Nathan   57
#[Out]# 16     Jurre   58
#[Out]# 17      Joep   59
#[Out]# 18  Mohammed   60
#[Out]# 19     Dylan   82
#[Out]# 20      Stef   86
#[Out]# 21   Thijmen   91
#[Out]# 22     Jelte   92
#[Out]# 23      Emma   95
#[Out]# 24      Noor  108
#[Out]# 25      Yara  112
#[Out]# 26     Milou  123
#[Out]# 27     Sofie  124
#[Out]# 28      Puck  157
#[Out]# 29     Fenne  159
#[Out]# 30     Floor  161
#[Out]# 31      Cato  163
#[Out]# 32     Hanna  165
#[Out]# 33      Lily  169
#[Out]# 34      Iris  170
#[Out]# 35       Sam  175
#[Out]# 36     Amira  176
#[Out]# 37      Juul  179
#[Out]# 38    Kostas  190
# Tue, 01 Dec 2020 19:06:00
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND never elsewhere!!!
'''
# Tue, 01 Dec 2020 19:06:00
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:06:01
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 19:27:48
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND c.cID NOT IN
    (SELECT c.cID
    WHERE c.cID IN p AND sName NOT LIKE 'Lidl');
'''
# Tue, 01 Dec 2020 19:27:48
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:27:49
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 19:28:49
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND c.cID NOT IN
    (SELECT c.cID
    FROM purchase p
    WHERE c.cID IN p AND sName NOT LIKE 'Lidl');
'''
# Tue, 01 Dec 2020 19:28:49
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:28:50
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 19:29:10
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND c.cID NOT IN
    SELECT c.cID
    WHERE c.cID IN p AND sName NOT LIKE 'Lidl';
'''
# Tue, 01 Dec 2020 19:29:11
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:29:11
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 19:29:16
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND c.cID NOT IN
    SELECT c.cID
    WHERE c.cID IN p AND sName NOT LIKE 'Lidl';
'''
# Tue, 01 Dec 2020 19:29:16
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:29:17
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 19:29:29
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND c.cID NOT IN
    SELECT c.cID
    WHERE (c.cID IN p) AND sName NOT LIKE 'Lidl';
'''
# Tue, 01 Dec 2020 19:29:29
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:29:30
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 19:29:39
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND c.cID NOT IN
    
'''
# Tue, 01 Dec 2020 19:29:39
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:29:40
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 19:29:50
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND c.cID 
'''
# Tue, 01 Dec 2020 19:29:50
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:29:54
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND c.cID 
'''
# Tue, 01 Dec 2020 19:29:54
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:30:06
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' 
'''
# Tue, 01 Dec 2020 19:30:06
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:30:07
pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID
#[Out]# 0        Sem    1
#[Out]# 1      Lucas    2
#[Out]# 2       Levi    5
#[Out]# 3       Bram    7
#[Out]# 4      James   13
#[Out]# 5     Julian   16
#[Out]# 6       Lars   19
#[Out]# 7       Luca   24
#[Out]# 8      Mason   25
#[Out]# 9       Sven   33
#[Out]# 10      Guus   37
#[Out]# 11      Jens   40
#[Out]# 12      Tijn   42
#[Out]# 13       Tom   43
#[Out]# 14      Ties   51
#[Out]# 15    Nathan   57
#[Out]# 16     Jurre   58
#[Out]# 17      Joep   59
#[Out]# 18  Mohammed   60
#[Out]# 19     Dylan   82
#[Out]# 20      Stef   86
#[Out]# 21   Thijmen   91
#[Out]# 22     Jelte   92
#[Out]# 23      Emma   95
#[Out]# 24      Noor  108
#[Out]# 25      Yara  112
#[Out]# 26     Milou  123
#[Out]# 27     Sofie  124
#[Out]# 28      Puck  157
#[Out]# 29     Fenne  159
#[Out]# 30     Floor  161
#[Out]# 31      Cato  163
#[Out]# 32     Hanna  165
#[Out]# 33      Lily  169
#[Out]# 34      Iris  170
#[Out]# 35       Sam  175
#[Out]# 36     Amira  176
#[Out]# 37      Juul  179
#[Out]# 38    Kostas  190
# Tue, 01 Dec 2020 19:33:38
query3_4 = '''
    select p.cID 
    from purchase p, store s
    where p.sID = s.sID and s.sName NOT LIKE 'Lidl'; 
'''
# Tue, 01 Dec 2020 19:34:07
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:34:45
pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# 5      2
#[Out]# 6      2
#[Out]# 7      2
#[Out]# 8      2
#[Out]# 9      3
#[Out]# 10     3
#[Out]# 11     3
#[Out]# 12     4
#[Out]# 13     4
#[Out]# 14     4
#[Out]# 15     4
#[Out]# 16     4
#[Out]# 17     4
#[Out]# 18     5
#[Out]# 19     5
#[Out]# 20     5
#[Out]# 21     5
#[Out]# 22     5
#[Out]# 23     7
#[Out]# 24     7
#[Out]# 25     7
#[Out]# 26     7
#[Out]# 27     7
#[Out]# 28     8
#[Out]# 29     8
#[Out]# ..   ...
#[Out]# 415  190
#[Out]# 416  190
#[Out]# 417  190
#[Out]# 418  190
#[Out]# 419  190
#[Out]# 420  190
#[Out]# 421  190
#[Out]# 422  190
#[Out]# 423  190
#[Out]# 424  190
#[Out]# 425  190
#[Out]# 426  190
#[Out]# 427  190
#[Out]# 428  190
#[Out]# 429  190
#[Out]# 430  190
#[Out]# 431  190
#[Out]# 432  190
#[Out]# 433  190
#[Out]# 434  190
#[Out]# 435  190
#[Out]# 436  190
#[Out]# 437  190
#[Out]# 438  190
#[Out]# 439  190
#[Out]# 440  190
#[Out]# 441  190
#[Out]# 442  190
#[Out]# 443  190
#[Out]# 444  190
#[Out]# 
#[Out]# [445 rows x 1 columns]
# Tue, 01 Dec 2020 19:34:57
pd.read_sql_query(query3_4, conn).sum();
# Tue, 01 Dec 2020 19:35:05
pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# 5      2
#[Out]# 6      2
#[Out]# 7      2
#[Out]# 8      2
#[Out]# 9      3
#[Out]# 10     3
#[Out]# 11     3
#[Out]# 12     4
#[Out]# 13     4
#[Out]# 14     4
#[Out]# 15     4
#[Out]# 16     4
#[Out]# 17     4
#[Out]# 18     5
#[Out]# 19     5
#[Out]# 20     5
#[Out]# 21     5
#[Out]# 22     5
#[Out]# 23     7
#[Out]# 24     7
#[Out]# 25     7
#[Out]# 26     7
#[Out]# 27     7
#[Out]# 28     8
#[Out]# 29     8
#[Out]# ..   ...
#[Out]# 415  190
#[Out]# 416  190
#[Out]# 417  190
#[Out]# 418  190
#[Out]# 419  190
#[Out]# 420  190
#[Out]# 421  190
#[Out]# 422  190
#[Out]# 423  190
#[Out]# 424  190
#[Out]# 425  190
#[Out]# 426  190
#[Out]# 427  190
#[Out]# 428  190
#[Out]# 429  190
#[Out]# 430  190
#[Out]# 431  190
#[Out]# 432  190
#[Out]# 433  190
#[Out]# 434  190
#[Out]# 435  190
#[Out]# 436  190
#[Out]# 437  190
#[Out]# 438  190
#[Out]# 439  190
#[Out]# 440  190
#[Out]# 441  190
#[Out]# 442  190
#[Out]# 443  190
#[Out]# 444  190
#[Out]# 
#[Out]# [445 rows x 1 columns]
# Tue, 01 Dec 2020 19:37:25
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Kumar' AND (c.cID NOT IN
    (select p.cID 
    from purchase p, store s
    where p.sID = s.sID and s.sName NOT LIKE 'Kumar'));  
'''
# Tue, 01 Dec 2020 19:37:25
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:37:27
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 19:37:43
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND (c.cID NOT IN
    (select p.cID 
    from purchase p, store s
    where p.sID = s.sID and s.sName NOT LIKE 'Lidl'));  
'''
# Tue, 01 Dec 2020 19:37:44
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:37:45
pd.read_sql_query(query3_4, conn)
#[Out]#    cName  cID
#[Out]# 0  Mason   25
# Tue, 01 Dec 2020 19:38:30
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND (c.cID NOT IN
    (select p.cID 
    from purchase p, store s
    where s.sName NOT LIKE 'Lidl'));  
'''
# Tue, 01 Dec 2020 19:38:30
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:38:32
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 19:38:40
query3_4 = '''
    SELECT DISTINCT cName, c.cID 
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND sName LIKE 'Lidl' AND (c.cID NOT IN
    (select p.cID 
    from purchase p, store s
    where p.sID = s.sID and s.sName NOT LIKE 'Lidl'));  
'''
# Tue, 01 Dec 2020 19:38:40
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 19:38:41
pd.read_sql_query(query3_4, conn)
#[Out]#    cName  cID
#[Out]# 0  Mason   25


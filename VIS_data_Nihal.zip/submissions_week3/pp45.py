# IPython log file

# Tue, 01 Dec 2020 10:11:34
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 10:12:42
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x293c613c2d0>
# Tue, 01 Dec 2020 10:13:00
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)

# IPython log file

# Tue, 01 Dec 2020 12:05:07
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 12:05:12
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
# db_location = 'shoppingDB.sql'

# f = open(db_location,'r')
# sql = f.read()
# cur.executescript(sql)
# Tue, 01 Dec 2020 12:05:17
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 12:13:03
query3_2 = '''
SELECT distinct C.cName, C.cID
FROM shoppinglist S, purchase P, customer C
WHERE S.cID = P.cID AND P.cID = C.cID AND S.date = P.date AND (S.date LIKE '%2018%');
'''
# Tue, 01 Dec 2020 12:13:04
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 12:13:45
pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 12:23:07
query3_3 = '''
SELECT DISTINCT C.cName, C.cID
FROM customer C, purchase P, store S
WHERE C.cID = P.cID AND S.sID = P.sID AND S.sName NOT IN (
    SELECT S2.sName
    FROM store S2
    WHERE S2.sName = 'Coop');
'''
# Tue, 01 Dec 2020 12:23:08
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 12:24:08
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 12:24:13
pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 12:25:56
query3_3 = '''
SELECT DISTINCT C.cName, C.cID
FROM customer C, purchase P, store S
WHERE C.cID = P.cID AND S.sID = P.sID AND C.cID NOT IN (
    SELECT C2.cID
    FROM customer C2, purchase P2, store S2
    WHERE C2.cID = P2.cID AND S2.sID = P2.sID S2.sName = 'Coop');
'''
# Tue, 01 Dec 2020 12:25:57
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 12:26:46
query3_3 = '''
SELECT DISTINCT C.cName, C.cID
FROM customer C, purchase P, store S
WHERE C.cID = P.cID AND S.sID = P.sID AND C.cID NOT IN (
    SELECT C2.cID
    FROM customer C2, purchase P2, store S2
    WHERE C2.cID = P2.cID AND S2.sID = P2.sID AND S2.sName = 'Coop');
'''
# Tue, 01 Dec 2020 12:26:46
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 12:27:22
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2       Finn    3
#[Out]# 3       Bram    7
#[Out]# 4      James   13
#[Out]# 5       Noud   15
#[Out]# 6       Lars   19
#[Out]# 7       Mats   22
#[Out]# 8      Mason   25
#[Out]# 9       Teun   30
#[Out]# 10   Olivier   31
#[Out]# 11     David   34
#[Out]# 12      Guus   37
#[Out]# 13    Floris   38
#[Out]# 14      Jens   40
#[Out]# 15     Quinn   41
#[Out]# 16       Tom   43
#[Out]# 17     Jason   44
#[Out]# 18      Ryan   45
#[Out]# 19      Xavi   47
#[Out]# 20    Willem   52
#[Out]# 21     Jurre   58
#[Out]# 22  Mohammed   60
#[Out]# 23      Senn   63
#[Out]# 24      Stan   64
#[Out]# 25   Mohamed   66
#[Out]# 26     Boris   68
#[Out]# 27      Roan   69
#[Out]# 28       Kai   70
#[Out]# 29      Dani   72
#[Out]# 30     Hidde   77
#[Out]# 31      Niek   80
#[Out]# 32    Casper   84
#[Out]# 33      Stef   86
#[Out]# 34      Lenn   90
#[Out]# 35      Emma   95
#[Out]# 36       Liv  104
#[Out]# 37      Lynn  109
#[Out]# 38    Lauren  111
#[Out]# 39      Nina  119
#[Out]# 40      Lina  126
#[Out]# 41   Jasmijn  128
#[Out]# 42     Femke  136
#[Out]# 43      Lena  137
#[Out]# 44      Fien  145
#[Out]# 45     Lizzy  149
#[Out]# 46      Puck  157
#[Out]# 47     Fenne  159
#[Out]# 48    Veerle  167
#[Out]# 49      Kiki  168
#[Out]# 50      Iris  170
#[Out]# 51     Tessa  171
#[Out]# 52       Sam  175
#[Out]# 53   Johanna  182
#[Out]# 54      Nick  185
#[Out]# 55    Angela  186
#[Out]# 56      Pino  188
#[Out]# 57      Koen  189
# Tue, 01 Dec 2020 12:33:14
query3_4 = '''
SELECT DISTINCT C.cName, C.cID
FROM customer C, purchase P, store S
WHERE C.cID = P.cID AND P.sID = S.sID AND S.sName = 'Coop' AND C.cID NOT IN (
    SELECT C2.cID
    FROM customer C2, purchase P2, store S2
    WHERE C2.cID = P2.cID AND P2.sID = S2.sID AND S2.sName <> 'Coop');
'''
# Tue, 01 Dec 2020 12:33:15
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 12:33:20
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184


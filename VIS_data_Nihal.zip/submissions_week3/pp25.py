# IPython log file

# Wed, 02 Dec 2020 01:50:31
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 01:53:48
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x22ad1970ea0>

# IPython log file

# Wed, 02 Dec 2020 12:26:09
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 12:26:12
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 12:26:13
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 12:34:52
query3_2 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID in (SELECT shoppinglist.cID
    FROM shoppinglist, purchase
    WHERE shoppinglist.DATE in purchase.DATE
    AND shoppinglist.cid in purchase.cid
    AND shoppinglist.DATE LIKE '%2018%')
    
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:35:31
query3_2 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID in (SELECT shoppinglist.cID
    FROM shoppinglist, purchase
    WHERE shoppinglist.date in purchase.date
    AND shoppinglist.cid in purchase.cid
    AND shoppinglist.DATE LIKE '%2018%')
    
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:35:45
query3_2 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID in (SELECT shoppinglist.cID
    FROM shoppinglist, purchase
    WHERE shoppinglist.date in purchase.date
    AND shoppinglist.cid in purchase.cid
    AND shoppinglist.DATE LIKE '%2018%')
    
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 12:39:50
query3_2 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID in (SELECT shoppinglist.cID
    FROM shoppinglist, purchase
    WHERE shoppinglist.date = purchase.date
    AND shoppinglist.cid = purchase.cid
    AND shoppinglist.DATE LIKE '%2018%')
    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Wed, 02 Dec 2020 12:47:30
query3_3 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase) AND customer.cName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:47:36
query3_3 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase) AND customer.cName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:50:50
query3_3 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase WHERE *) AND customer.cName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:51:17
query3_3 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase WHERE ) AND customer.cName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:52:14
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase) AND customer.cName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Wed, 02 Dec 2020 12:53:14
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase) AND cName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Wed, 02 Dec 2020 13:00:24
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase, store WHERE purchase.sID != (SELECT store.sID FROM store
    WHERE store.sName != 'Kumar'))
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0      Milan    6
#[Out]# 1     Thomas    9
#[Out]# 2      Thijs   11
#[Out]# 3       Adam   12
#[Out]# 4        Max   14
#[Out]# 5        Jan   23
#[Out]# 6      Vince   32
#[Out]# 7       Boaz   36
#[Out]# 8      Fedde   46
#[Out]# 9       Tygo   48
#[Out]# 10       Cas   49
#[Out]# 11       Pim   50
#[Out]# 12       Job   53
#[Out]# 13       Jax   54
#[Out]# 14    Tobias   56
#[Out]# 15    Morris   61
#[Out]# 16      Abel   62
#[Out]# 17    Pepijn   65
#[Out]# 18      Owen   73
#[Out]# 19    Samuel   74
#[Out]# 20    Joshua   79
#[Out]# 21     Simon   81
#[Out]# 22     Melle   83
#[Out]# 23     Jelle   87
#[Out]# 24  Johannes   89
#[Out]# 25     Oscar   93
#[Out]# 26     Julia   98
#[Out]# 27       Eva  101
#[Out]# 28       Evi  102
#[Out]# 29      Nora  105
#[Out]# 30     Fleur  106
#[Out]# 31    Olivia  107
#[Out]# 32      Maud  114
#[Out]# 33      Nova  115
#[Out]# 34      Roos  117
#[Out]# 35     Sarah  120
#[Out]# 36       Isa  121
#[Out]# 37       Noa  125
#[Out]# 38     Sanne  130
#[Out]# 39    Hannah  132
#[Out]# 40     Maria  138
#[Out]# 41      Vera  140
#[Out]# 42       Mia  141
#[Out]# 43        Bo  142
#[Out]# 44     Naomi  143
#[Out]# 45     Norah  146
#[Out]# 46  Isabella  148
#[Out]# 47     Julie  150
#[Out]# 48     Amber  153
#[Out]# 49    Benthe  154
#[Out]# 50     Linde  155
#[Out]# 51      Luna  156
#[Out]# 52      Rosa  158
#[Out]# 53      Lara  160
#[Out]# 54       Evy  164
#[Out]# 55   Rosalie  166
#[Out]# 56     Livia  173
#[Out]# 57      Romy  174
#[Out]# 58     Nikki  183
#[Out]# 59     Wilko  184
# Wed, 02 Dec 2020 13:01:55
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase WHERE purchase.sID != (SELECT store.sID FROM store
    WHERE store.sName != 'Kumar'))
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0      Milan    6
#[Out]# 1     Thomas    9
#[Out]# 2      Thijs   11
#[Out]# 3       Adam   12
#[Out]# 4        Max   14
#[Out]# 5        Jan   23
#[Out]# 6      Vince   32
#[Out]# 7       Boaz   36
#[Out]# 8      Fedde   46
#[Out]# 9       Tygo   48
#[Out]# 10       Cas   49
#[Out]# 11       Pim   50
#[Out]# 12       Job   53
#[Out]# 13       Jax   54
#[Out]# 14    Tobias   56
#[Out]# 15    Morris   61
#[Out]# 16      Abel   62
#[Out]# 17    Pepijn   65
#[Out]# 18      Owen   73
#[Out]# 19    Samuel   74
#[Out]# 20    Joshua   79
#[Out]# 21     Simon   81
#[Out]# 22     Melle   83
#[Out]# 23     Jelle   87
#[Out]# 24  Johannes   89
#[Out]# 25     Oscar   93
#[Out]# 26     Julia   98
#[Out]# 27       Eva  101
#[Out]# 28       Evi  102
#[Out]# 29      Nora  105
#[Out]# 30     Fleur  106
#[Out]# 31    Olivia  107
#[Out]# 32      Maud  114
#[Out]# 33      Nova  115
#[Out]# 34      Roos  117
#[Out]# 35     Sarah  120
#[Out]# 36       Isa  121
#[Out]# 37       Noa  125
#[Out]# 38     Sanne  130
#[Out]# 39    Hannah  132
#[Out]# 40     Maria  138
#[Out]# 41      Vera  140
#[Out]# 42       Mia  141
#[Out]# 43        Bo  142
#[Out]# 44     Naomi  143
#[Out]# 45     Norah  146
#[Out]# 46  Isabella  148
#[Out]# 47     Julie  150
#[Out]# 48     Amber  153
#[Out]# 49    Benthe  154
#[Out]# 50     Linde  155
#[Out]# 51      Luna  156
#[Out]# 52      Rosa  158
#[Out]# 53      Lara  160
#[Out]# 54       Evy  164
#[Out]# 55   Rosalie  166
#[Out]# 56     Livia  173
#[Out]# 57      Romy  174
#[Out]# 58     Nikki  183
#[Out]# 59     Wilko  184
# Wed, 02 Dec 2020 13:02:03
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase WHERE purchase.sID not in (SELECT store.sID FROM store
    WHERE store.sName != 'Kumar'))
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Wed, 02 Dec 2020 13:04:54
query3_3 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID not IN (SELECT purchase.cID 
    FROM purchase WHERE purchase.sID not in (SELECT store.sID FROM store
    WHERE store.sName != 'Kumar'))
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Wed, 02 Dec 2020 13:33:42
query3_4 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID in (SELECT purchase.cID 
    FROM purchase WHERE purchase.sID in (SELECT store.sID FROM store
    WHERE store.sName = 'Kumar')) AND cID not in (SELECT purchase.cID 
    FROM purchase WHERE purchase.sID in (SELECT store.sID FROM store
    WHERE store.sName != 'Kumar'))
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Wed, 02 Dec 2020 13:33:51
query3_4 = '''
    SELECT distinct cName, cID
    FROM customer
    WHERE cID in (SELECT purchase.cID 
    FROM purchase WHERE purchase.sID in (SELECT store.sID FROM store
    WHERE store.sName = 'Jumbo')) AND cID not in (SELECT purchase.cID 
    FROM purchase WHERE purchase.sID in (SELECT store.sID FROM store
    WHERE store.sName != 'Jumbo'))
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189


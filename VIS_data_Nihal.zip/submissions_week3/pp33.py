# IPython log file

# Tue, 01 Dec 2020 15:36:07
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Tue, 01 Dec 2020 15:37:41
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Tue, 01 Dec 2020 15:38:22
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy as np
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Tue, 01 Dec 2020 15:39:20
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy as np
import pandas as pd
from sqlvis import vis
# Tue, 01 Dec 2020 15:39:30
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy as np
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

# Tue, 01 Dec 2020 15:43:52
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Tue, 01 Dec 2020 15:43:58
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import nupy
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy
import pandas as pd
from sqlvis import vis
# Tue, 01 Dec 2020 15:44:03
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import nupy
import pandas as pd
from sqlvis import vis

# IPython log file

# Tue, 01 Dec 2020 15:47:32
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Tue, 01 Dec 2020 15:57:24
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Tue, 01 Dec 2020 16:04:22
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().magic('logstop')
get_ipython().magic('logstart -o -t')
import sqlite3
import numpy
import pandas as pd
from sqlvis import vis

# IPython log file

# Tue, 01 Dec 2020 16:53:27
activate myenv

# IPython log file

# Tue, 01 Dec 2020 17:25:59
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 17:26:18
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1e61c0ffd50>
# Tue, 01 Dec 2020 17:27:15
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 17:35:00
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date AND sl.date BETWEEN 01/01/2018 AND 31/12/2018
'''
# Tue, 01 Dec 2020 17:35:02
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:35:36
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 17:37:07
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date
'''
# Tue, 01 Dec 2020 17:37:08
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:37:13
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 17:38:02
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date AND sl.date BETWEEN 01/01/2018 AND 31/12/2018;
'''
# Tue, 01 Dec 2020 17:38:03
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:38:15
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date AND p.date BETWEEN 01/01/2018 AND 31/12/2018
'''
# Tue, 01 Dec 2020 17:38:15
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:38:32
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date
'''
# Tue, 01 Dec 2020 17:38:33
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:38:41
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:38:47
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, sl.date
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date
'''
# Tue, 01 Dec 2020 17:38:48
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:38:54
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-21
#[Out]# 2    Lucas    2  2018-08-16
#[Out]# 3    Lucas    2  2018-08-17
#[Out]# 4     Finn    3  2018-08-18
#[Out]# ..     ...  ...         ...
#[Out]# 181   Juul  179  2018-08-22
#[Out]# 182  Merel  180  2018-08-26
#[Out]# 183  Merel  180  2018-08-27
#[Out]# 184   Liva  181  2018-08-24
#[Out]# 185   Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Tue, 01 Dec 2020 17:39:40
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, sl.date
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date AND sl.date BETWEEN 2018-01-01 AND 2018-12-31
'''
# Tue, 01 Dec 2020 17:39:41
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:39:47
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, date]
#[Out]# Index: []
# Tue, 01 Dec 2020 17:40:31
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, sl.date
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date AND sl.date
'''
# Tue, 01 Dec 2020 17:40:32
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:40:40
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, sl.date
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date
'''
# Tue, 01 Dec 2020 17:40:41
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:40:44
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-21
#[Out]# 2    Lucas    2  2018-08-16
#[Out]# 3    Lucas    2  2018-08-17
#[Out]# 4     Finn    3  2018-08-18
#[Out]# ..     ...  ...         ...
#[Out]# 181   Juul  179  2018-08-22
#[Out]# 182  Merel  180  2018-08-26
#[Out]# 183  Merel  180  2018-08-27
#[Out]# 184   Liva  181  2018-08-24
#[Out]# 185   Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Tue, 01 Dec 2020 17:44:59
query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c1
    WHERE c1.cID NOT IN (
        SELECT c.cID
        FROM customer c, store s, purchase p
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo'
        )
'''
# Tue, 01 Dec 2020 17:44:59
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 17:45:15
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 17:45:36
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT c.cID
        FROM customer c, store s, purchase p
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo'
        )
'''
# Tue, 01 Dec 2020 17:45:37
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 17:45:41
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 17:46:07
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT c.cID
        FROM customer c, store s, purchase p
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
        )
'''
# Tue, 01 Dec 2020 17:46:07
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 17:46:09
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 17:46:19
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT c.cID
        FROM customer c, store s, purchase p
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
        )
'''
# Tue, 01 Dec 2020 17:46:20
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 17:46:21
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 17:48:05
query3_4 = '''
    SELECT DISTINCT c.cID
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo'
'''
# Tue, 01 Dec 2020 17:48:05
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 17:48:05
pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     4
#[Out]# 1    18
#[Out]# 2    19
#[Out]# 3    21
#[Out]# 4    24
#[Out]# 5    27
#[Out]# 6    37
#[Out]# 7    38
#[Out]# 8    40
#[Out]# 9    47
#[Out]# 10   52
#[Out]# 11   59
#[Out]# 12   63
#[Out]# 13   66
#[Out]# 14   68
#[Out]# 15   72
#[Out]# 16   78
#[Out]# 17   85
#[Out]# 18   86
#[Out]# 19  104
#[Out]# 20  109
#[Out]# 21  112
#[Out]# 22  122
#[Out]# 23  126
#[Out]# 24  136
#[Out]# 25  165
#[Out]# 26  167
#[Out]# 27  171
#[Out]# 28  172
#[Out]# 29  180
#[Out]# 30  185
#[Out]# 31  186
#[Out]# 32  188
#[Out]# 33  189
#[Out]# 34  190
# Tue, 01 Dec 2020 17:48:22
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo'
'''
# Tue, 01 Dec 2020 17:48:23
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 17:48:23
pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID
#[Out]# 0       Daan    4
#[Out]# 1       Hugo   18
#[Out]# 2       Lars   19
#[Out]# 3   Benjamin   21
#[Out]# 4       Luca   24
#[Out]# 5        Tim   27
#[Out]# 6       Guus   37
#[Out]# 7     Floris   38
#[Out]# 8       Jens   40
#[Out]# 9       Xavi   47
#[Out]# 10    Willem   52
#[Out]# 11      Joep   59
#[Out]# 12      Senn   63
#[Out]# 13   Mohamed   66
#[Out]# 14     Boris   68
#[Out]# 15      Dani   72
#[Out]# 16      Mick   78
#[Out]# 17    Pieter   85
#[Out]# 18      Stef   86
#[Out]# 19       Liv  104
#[Out]# 20      Lynn  109
#[Out]# 21      Yara  112
#[Out]# 22      Elin  122
#[Out]# 23      Lina  126
#[Out]# 24     Femke  136
#[Out]# 25     Hanna  165
#[Out]# 26    Veerle  167
#[Out]# 27     Tessa  171
#[Out]# 28      Lana  172
#[Out]# 29     Merel  180
#[Out]# 30      Nick  185
#[Out]# 31    Angela  186
#[Out]# 32      Pino  188
#[Out]# 33      Koen  189
#[Out]# 34    Kostas  190
# Tue, 01 Dec 2020 17:49:29
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo' AND c.cID NOT IN (
        SELECT DISTINCT c.cID
        FROM customer c, store s, purchase p
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo'
    )
'''
# Tue, 01 Dec 2020 17:49:30
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 17:49:36
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 17:49:42
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo' AND c.cID NOT IN (
        SELECT DISTINCT c.cID
        FROM customer c, store s, purchase p
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
    )
'''
# Tue, 01 Dec 2020 17:49:42
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 17:49:46
pd.read_sql_query(query3_4, conn)
#[Out]#       cName  cID
#[Out]# 0      Lars   19
#[Out]# 1      Guus   37
#[Out]# 2    Floris   38
#[Out]# 3      Jens   40
#[Out]# 4      Xavi   47
#[Out]# 5    Willem   52
#[Out]# 6      Senn   63
#[Out]# 7   Mohamed   66
#[Out]# 8     Boris   68
#[Out]# 9      Dani   72
#[Out]# 10     Stef   86
#[Out]# 11      Liv  104
#[Out]# 12     Lynn  109
#[Out]# 13     Lina  126
#[Out]# 14    Femke  136
#[Out]# 15   Veerle  167
#[Out]# 16    Tessa  171
#[Out]# 17     Nick  185
#[Out]# 18   Angela  186
#[Out]# 19     Pino  188
#[Out]# 20     Koen  189
# Tue, 01 Dec 2020 17:49:58
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo' AND c.cID NOT IN (
        SELECT DISTINCT c.cID
        FROM customer c, store s, purchase p
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName != 'Jumbo'
    )
'''
# Tue, 01 Dec 2020 17:49:59
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 17:50:03
pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Tue, 01 Dec 2020 17:50:29
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo' AND c.cID NOT IN (
        SELECT DISTINCT c1.cID
        FROM customer c1, store s1, purchase p1
        WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName != 'Jumbo'
    )
'''
# Tue, 01 Dec 2020 17:50:29
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 17:50:30
pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Tue, 01 Dec 2020 17:51:11
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar' AND c.cID NOT IN (
        SELECT DISTINCT c1.cID
        FROM customer c1, store s1, purchase p1
        WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName != 'Kumar'
    )
'''
# Tue, 01 Dec 2020 17:51:12
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 17:51:13
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []

# IPython log file

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date
'''
vis.visualize(query3_2, schema)
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 17:54:23
import sys
print (sys.version)
# Tue, 01 Dec 2020 17:54:25
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 17:54:27
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 17:54:29
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, shoppinglist sl, purchase p
    WHERE c.cID = sl.cID AND c.cID = p.cID AND sl.date = p.date
'''
# Tue, 01 Dec 2020 17:54:30
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 17:54:31
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 17:54:37
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT c.cID
        FROM customer c, store s, purchase p
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
    )
'''
# Tue, 01 Dec 2020 17:54:37
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 17:54:37
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 17:54:38
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar' AND c.cID NOT IN (
        SELECT DISTINCT c1.cID
        FROM customer c1, store s1, purchase p1
        WHERE c1.cID = p1.cID AND p1.sID = s1.sID AND s1.sName != 'Kumar'
    )
'''
# Tue, 01 Dec 2020 17:54:38
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 17:54:39
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []


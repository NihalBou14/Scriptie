# IPython log file

# Thu, 26 Nov 2020 20:38:36
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 20:41:16
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x238db591dc0>
# Thu, 26 Nov 2020 20:50:38
conn.head()
# Thu, 26 Nov 2020 20:52:52
query3_2 = '''
    SELECT cName, cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID
'''

pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 20:53:07
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1        Noah    0
#[Out]# 2        Noah    0
#[Out]# 3        Noah    0
#[Out]# 4        Noah    0
#[Out]# 5        Noah    0
#[Out]# 6        Noah    0
#[Out]# 7        Noah    0
#[Out]# 8        Noah    0
#[Out]# 9        Noah    0
#[Out]# 10       Noah    0
#[Out]# 11       Noah    0
#[Out]# 12       Noah    0
#[Out]# 13       Noah    0
#[Out]# 14       Noah    0
#[Out]# 15       Noah    0
#[Out]# 16       Noah    0
#[Out]# 17       Noah    0
#[Out]# 18       Noah    0
#[Out]# 19       Noah    0
#[Out]# 20       Noah    0
#[Out]# 21       Noah    0
#[Out]# 22       Noah    0
#[Out]# 23       Noah    0
#[Out]# 24       Noah    0
#[Out]# 25       Noah    0
#[Out]# 26       Noah    0
#[Out]# 27       Noah    0
#[Out]# 28       Noah    0
#[Out]# 29       Noah    0
#[Out]# ...       ...  ...
#[Out]# 96402  Kostas  190
#[Out]# 96403  Kostas  190
#[Out]# 96404  Kostas  190
#[Out]# 96405  Kostas  190
#[Out]# 96406  Kostas  190
#[Out]# 96407  Kostas  190
#[Out]# 96408  Kostas  190
#[Out]# 96409  Kostas  190
#[Out]# 96410  Kostas  190
#[Out]# 96411  Kostas  190
#[Out]# 96412  Kostas  190
#[Out]# 96413  Kostas  190
#[Out]# 96414  Kostas  190
#[Out]# 96415  Kostas  190
#[Out]# 96416  Kostas  190
#[Out]# 96417  Kostas  190
#[Out]# 96418  Kostas  190
#[Out]# 96419  Kostas  190
#[Out]# 96420  Kostas  190
#[Out]# 96421  Kostas  190
#[Out]# 96422  Kostas  190
#[Out]# 96423  Kostas  190
#[Out]# 96424  Kostas  190
#[Out]# 96425  Kostas  190
#[Out]# 96426  Kostas  190
#[Out]# 96427  Kostas  190
#[Out]# 96428  Kostas  190
#[Out]# 96429  Kostas  190
#[Out]# 96430  Kostas  190
#[Out]# 96431  Kostas  190
#[Out]# 
#[Out]# [96432 rows x 2 columns]
# Thu, 26 Nov 2020 20:54:20
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID, s.date = p.date
'''

pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 20:54:27
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1       Noah    0
#[Out]# 2       Noah    0
#[Out]# 3       Noah    0
#[Out]# 4       Noah    0
#[Out]# 5       Noah    0
#[Out]# 6       Noah    0
#[Out]# 7       Noah    0
#[Out]# 8       Noah    0
#[Out]# 9       Noah    0
#[Out]# 10      Noah    0
#[Out]# 11      Noah    0
#[Out]# 12      Noah    0
#[Out]# 13      Noah    0
#[Out]# 14      Noah    0
#[Out]# 15      Noah    0
#[Out]# 16      Noah    0
#[Out]# 17      Noah    0
#[Out]# 18      Noah    0
#[Out]# 19      Noah    0
#[Out]# 20      Noah    0
#[Out]# 21      Noah    0
#[Out]# 22      Noah    0
#[Out]# 23      Noah    0
#[Out]# 24      Noah    0
#[Out]# 25      Noah    0
#[Out]# 26      Noah    0
#[Out]# 27      Noah    0
#[Out]# 28      Noah    0
#[Out]# 29      Noah    0
#[Out]# ...      ...  ...
#[Out]# 6839  Kostas  190
#[Out]# 6840  Kostas  190
#[Out]# 6841  Kostas  190
#[Out]# 6842  Kostas  190
#[Out]# 6843  Kostas  190
#[Out]# 6844  Kostas  190
#[Out]# 6845  Kostas  190
#[Out]# 6846  Kostas  190
#[Out]# 6847  Kostas  190
#[Out]# 6848  Kostas  190
#[Out]# 6849  Kostas  190
#[Out]# 6850  Kostas  190
#[Out]# 6851  Kostas  190
#[Out]# 6852  Kostas  190
#[Out]# 6853  Kostas  190
#[Out]# 6854  Kostas  190
#[Out]# 6855  Kostas  190
#[Out]# 6856  Kostas  190
#[Out]# 6857  Kostas  190
#[Out]# 6858  Kostas  190
#[Out]# 6859  Kostas  190
#[Out]# 6860  Kostas  190
#[Out]# 6861  Kostas  190
#[Out]# 6862  Kostas  190
#[Out]# 6863  Kostas  190
#[Out]# 6864  Kostas  190
#[Out]# 6865  Kostas  190
#[Out]# 6866  Kostas  190
#[Out]# 6867  Kostas  190
#[Out]# 6868  Kostas  190
#[Out]# 
#[Out]# [6869 rows x 2 columns]
# Thu, 26 Nov 2020 20:54:48
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cName  cID        date
#[Out]# 0       Noah    0  2018-08-22
#[Out]# 1       Noah    0  2018-08-22
#[Out]# 2       Noah    0  2018-08-22
#[Out]# 3       Noah    0  2018-08-22
#[Out]# 4       Noah    0  2018-08-22
#[Out]# 5       Noah    0  2018-08-22
#[Out]# 6       Noah    0  2018-08-22
#[Out]# 7       Noah    0  2018-08-22
#[Out]# 8       Noah    0  2018-08-22
#[Out]# 9       Noah    0  2018-08-22
#[Out]# 10      Noah    0  2018-08-22
#[Out]# 11      Noah    0  2018-08-22
#[Out]# 12      Noah    0  2018-08-22
#[Out]# 13      Noah    0  2018-08-22
#[Out]# 14      Noah    0  2018-08-22
#[Out]# 15      Noah    0  2018-08-22
#[Out]# 16      Noah    0  2018-08-22
#[Out]# 17      Noah    0  2018-08-22
#[Out]# 18      Noah    0  2018-08-22
#[Out]# 19      Noah    0  2018-08-22
#[Out]# 20      Noah    0  2018-08-22
#[Out]# 21      Noah    0  2018-08-22
#[Out]# 22      Noah    0  2018-08-22
#[Out]# 23      Noah    0  2018-08-22
#[Out]# 24      Noah    0  2018-08-22
#[Out]# 25      Noah    0  2018-08-22
#[Out]# 26      Noah    0  2018-08-22
#[Out]# 27      Noah    0  2018-08-22
#[Out]# 28      Noah    0  2018-08-22
#[Out]# 29      Noah    0  2018-08-22
#[Out]# ...      ...  ...         ...
#[Out]# 6839  Kostas  190  2018-08-22
#[Out]# 6840  Kostas  190  2018-08-22
#[Out]# 6841  Kostas  190  2018-08-22
#[Out]# 6842  Kostas  190  2018-08-22
#[Out]# 6843  Kostas  190  2018-08-22
#[Out]# 6844  Kostas  190  2018-08-22
#[Out]# 6845  Kostas  190  2018-08-22
#[Out]# 6846  Kostas  190  2018-08-22
#[Out]# 6847  Kostas  190  2018-08-22
#[Out]# 6848  Kostas  190  2018-08-22
#[Out]# 6849  Kostas  190  2018-08-22
#[Out]# 6850  Kostas  190  2018-08-22
#[Out]# 6851  Kostas  190  2018-08-22
#[Out]# 6852  Kostas  190  2018-08-22
#[Out]# 6853  Kostas  190  2018-08-22
#[Out]# 6854  Kostas  190  2018-08-22
#[Out]# 6855  Kostas  190  2018-08-22
#[Out]# 6856  Kostas  190  2018-08-22
#[Out]# 6857  Kostas  190  2018-08-22
#[Out]# 6858  Kostas  190  2018-08-22
#[Out]# 6859  Kostas  190  2018-08-22
#[Out]# 6860  Kostas  190  2018-08-22
#[Out]# 6861  Kostas  190  2018-08-22
#[Out]# 6862  Kostas  190  2018-08-22
#[Out]# 6863  Kostas  190  2018-08-22
#[Out]# 6864  Kostas  190  2018-08-22
#[Out]# 6865  Kostas  190  2018-08-22
#[Out]# 6866  Kostas  190  2018-08-22
#[Out]# 6867  Kostas  190  2018-08-22
#[Out]# 6868  Kostas  190  2018-08-22
#[Out]# 
#[Out]# [6869 rows x 3 columns]
# Thu, 26 Nov 2020 21:06:36
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date
    GROUP BY c.cName
'''

pd.read_sql_query(query3_2, conn)
#[Out]#          cName  cID        date
#[Out]# 0         Abel   62  2018-08-22
#[Out]# 1         Adam   12  2018-08-22
#[Out]# 2        Aiden   55  2018-08-22
#[Out]# 3    Alexander   76  2018-08-22
#[Out]# 4        Amber  153  2018-08-22
#[Out]# 5        Amira  176  2018-08-22
#[Out]# 6          Amy  131  2018-08-22
#[Out]# 7       Angela  186  2018-08-22
#[Out]# 8         Anna   99  2018-08-22
#[Out]# 9         Anne  152  2018-08-22
#[Out]# 10    Benjamin   21  2018-08-22
#[Out]# 11      Benthe  154  2018-08-22
#[Out]# 12          Bo  142  2018-08-22
#[Out]# 13        Boaz   36  2018-08-22
#[Out]# 14       Boris   68  2018-08-22
#[Out]# 15        Bram    7  2018-08-22
#[Out]# 16         Cas   49  2018-08-22
#[Out]# 17      Casper   84  2018-08-22
#[Out]# 18        Cato  163  2018-08-22
#[Out]# 19        Daan    4  2018-08-22
#[Out]# 20        Dani   72  2018-08-22
#[Out]# 21       David   34  2018-08-22
#[Out]# 22        Dean   71  2018-08-22
#[Out]# 23         Dex   17  2018-08-22
#[Out]# 24       Dylan   82  2018-08-22
#[Out]# 25       Elena  162  2018-08-22
#[Out]# 26        Elif  178  2018-08-22
#[Out]# 27        Elin  122  2018-08-22
#[Out]# 28       Eline  177  2018-08-22
#[Out]# 29       Elise  139  2018-08-22
#[Out]# ..         ...  ...         ...
#[Out]# 159       Senn   63  2018-08-22
#[Out]# 160       Siem   28  2018-08-22
#[Out]# 161      Simon   81  2018-08-22
#[Out]# 162      Sofia  135  2018-08-22
#[Out]# 163      Sofie  124  2018-08-22
#[Out]# 164     Sophia  133  2018-08-22
#[Out]# 165     Sophie   97  2018-08-22
#[Out]# 166       Stan   64  2018-08-22
#[Out]# 167       Stef   86  2018-08-22
#[Out]# 168      Stijn   35  2018-08-22
#[Out]# 169       Sven   33  2018-08-22
#[Out]# 170       Tess   96  2018-08-22
#[Out]# 171      Tessa  171  2018-08-22
#[Out]# 172       Teun   30  2018-08-22
#[Out]# 173    Thijmen   91  2018-08-22
#[Out]# 174      Thijs   11  2018-08-22
#[Out]# 175     Thomas    9  2018-08-22
#[Out]# 176       Ties   51  2018-08-22
#[Out]# 177       Tijn   42  2018-08-22
#[Out]# 178        Tim   27  2018-08-22
#[Out]# 179     Tobias   56  2018-08-22
#[Out]# 180        Tom   43  2018-08-22
#[Out]# 181       Tygo   48  2018-08-22
#[Out]# 182     Veerle  167  2018-08-22
#[Out]# 183       Vera  140  2018-08-22
#[Out]# 184      Vince   32  2018-08-22
#[Out]# 185      Wilko  184  2018-08-22
#[Out]# 186     Willem   52  2018-08-22
#[Out]# 187       Xavi   47  2018-08-22
#[Out]# 188       Yara  112  2018-08-22
#[Out]# 
#[Out]# [189 rows x 3 columns]
# Thu, 26 Nov 2020 21:06:48
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0        Noah    0  2018-08-22
#[Out]# 1         Sem    1  2018-08-20
#[Out]# 2       Lucas    2  2018-08-22
#[Out]# 3        Finn    3  2018-08-22
#[Out]# 4        Daan    4  2018-08-22
#[Out]# 5        Levi    5  2018-08-22
#[Out]# 6       Milan    6  2018-08-22
#[Out]# 7        Bram    7  2018-08-22
#[Out]# 8        Liam    8  2018-08-22
#[Out]# 9      Thomas    9  2018-08-22
#[Out]# 10        Sam   10  2018-08-22
#[Out]# 11      Thijs   11  2018-08-22
#[Out]# 12       Adam   12  2018-08-22
#[Out]# 13      James   13  2018-08-22
#[Out]# 14        Max   14  2018-08-22
#[Out]# 15       Noud   15  2018-08-22
#[Out]# 16     Julian   16  2018-08-22
#[Out]# 17        Dex   17  2018-08-22
#[Out]# 18       Hugo   18  2018-08-22
#[Out]# 19       Lars   19  2018-08-22
#[Out]# 20       Gijs   20  2018-08-22
#[Out]# 21   Benjamin   21  2018-08-22
#[Out]# 22       Mats   22  2018-08-22
#[Out]# 23        Jan   23  2018-08-22
#[Out]# 24       Luca   24  2018-08-22
#[Out]# 25      Mason   25  2018-08-22
#[Out]# 26     Jayden   26  2018-08-22
#[Out]# 27        Tim   27  2018-08-22
#[Out]# 28       Siem   28  2018-08-22
#[Out]# 29      Ruben   29  2018-08-22
#[Out]# ..        ...  ...         ...
#[Out]# 160      Lara  160  2018-08-22
#[Out]# 161     Floor  161  2018-08-22
#[Out]# 162     Elena  162  2018-08-22
#[Out]# 163      Cato  163  2018-08-22
#[Out]# 164       Evy  164  2018-08-22
#[Out]# 165     Hanna  165  2018-08-22
#[Out]# 166   Rosalie  166  2018-08-22
#[Out]# 167    Veerle  167  2018-08-22
#[Out]# 168      Kiki  168  2018-08-22
#[Out]# 169      Lily  169  2018-08-22
#[Out]# 170      Iris  170  2018-08-22
#[Out]# 171     Tessa  171  2018-08-22
#[Out]# 172      Lana  172  2018-08-22
#[Out]# 173     Livia  173  2018-08-22
#[Out]# 174      Romy  174  2018-08-22
#[Out]# 175       Sam  175  2018-08-22
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Eline  177  2018-08-22
#[Out]# 178      Elif  178  2018-08-22
#[Out]# 179      Juul  179  2018-08-22
#[Out]# 180     Merel  180  2018-08-22
#[Out]# 181      Liva  181  2018-08-22
#[Out]# 182   Johanna  182  2018-08-22
#[Out]# 183     Nikki  183  2018-08-22
#[Out]# 184     Wilko  184  2018-08-22
#[Out]# 185      Nick  185  2018-08-22
#[Out]# 186    Angela  186  2018-08-22
#[Out]# 187      Pino  188  2018-08-22
#[Out]# 188      Koen  189  2018-08-22
#[Out]# 189    Kostas  190  2018-08-22
#[Out]# 
#[Out]# [190 rows x 3 columns]
# Thu, 26 Nov 2020 21:07:27
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Thu, 26 Nov 2020 21:08:46
query3_2 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Thu, 26 Nov 2020 21:08:56
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Thu, 26 Nov 2020 22:08:37
query3_3 = '''
    SELECT cName, cID
    FROM customer
    GROUP BY cID
    
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Abel   62
#[Out]# 1        Adam   12
#[Out]# 2       Amber  153
#[Out]# 3      Angela  186
#[Out]# 4      Benthe  154
#[Out]# 5          Bo  142
#[Out]# 6        Boaz   36
#[Out]# 7       Boris   68
#[Out]# 8        Bram    7
#[Out]# 9         Cas   49
#[Out]# 10     Casper   84
#[Out]# 11       Dani   72
#[Out]# 12      David   34
#[Out]# 13       Emma   95
#[Out]# 14        Eva  101
#[Out]# 15        Evi  102
#[Out]# 16        Evy  164
#[Out]# 17      Fedde   46
#[Out]# 18      Femke  136
#[Out]# 19      Fenne  159
#[Out]# 20       Fien  145
#[Out]# 21       Finn    3
#[Out]# 22      Fleur  106
#[Out]# 23     Floris   38
#[Out]# 24       Guus   37
#[Out]# 25     Hannah  132
#[Out]# 26      Hidde   77
#[Out]# 27       Iris  170
#[Out]# 28        Isa  121
#[Out]# 29   Isabella  148
#[Out]# ..        ...  ...
#[Out]# 86        Pim   50
#[Out]# 87       Pino  188
#[Out]# 88       Puck  157
#[Out]# 89      Quinn   41
#[Out]# 90       Roan   69
#[Out]# 91       Romy  174
#[Out]# 92       Roos  117
#[Out]# 93       Rosa  158
#[Out]# 94    Rosalie  166
#[Out]# 95       Ryan   45
#[Out]# 96        Sam  175
#[Out]# 97     Samuel   74
#[Out]# 98      Sanne  130
#[Out]# 99      Sarah  120
#[Out]# 100       Sem    1
#[Out]# 101      Senn   63
#[Out]# 102     Simon   81
#[Out]# 103      Stan   64
#[Out]# 104      Stef   86
#[Out]# 105     Tessa  171
#[Out]# 106      Teun   30
#[Out]# 107    Thomas    9
#[Out]# 108    Tobias   56
#[Out]# 109       Tom   43
#[Out]# 110      Tygo   48
#[Out]# 111    Veerle  167
#[Out]# 112      Vera  140
#[Out]# 113     Vince   32
#[Out]# 114    Willem   52
#[Out]# 115      Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 22:13:54
query3_3 = '''
    SELECT cName, cID
    FROM customer    
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
    GROUP BY cID
'''

pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 22:14:04
query3_3 = '''
    SELECT cName, cID
    FROM customer
    GROUP BY cID
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Abel   62
#[Out]# 1        Adam   12
#[Out]# 2       Amber  153
#[Out]# 3      Angela  186
#[Out]# 4      Benthe  154
#[Out]# 5          Bo  142
#[Out]# 6        Boaz   36
#[Out]# 7       Boris   68
#[Out]# 8        Bram    7
#[Out]# 9         Cas   49
#[Out]# 10     Casper   84
#[Out]# 11       Dani   72
#[Out]# 12      David   34
#[Out]# 13       Emma   95
#[Out]# 14        Eva  101
#[Out]# 15        Evi  102
#[Out]# 16        Evy  164
#[Out]# 17      Fedde   46
#[Out]# 18      Femke  136
#[Out]# 19      Fenne  159
#[Out]# 20       Fien  145
#[Out]# 21       Finn    3
#[Out]# 22      Fleur  106
#[Out]# 23     Floris   38
#[Out]# 24       Guus   37
#[Out]# 25     Hannah  132
#[Out]# 26      Hidde   77
#[Out]# 27       Iris  170
#[Out]# 28        Isa  121
#[Out]# 29   Isabella  148
#[Out]# ..        ...  ...
#[Out]# 86        Pim   50
#[Out]# 87       Pino  188
#[Out]# 88       Puck  157
#[Out]# 89      Quinn   41
#[Out]# 90       Roan   69
#[Out]# 91       Romy  174
#[Out]# 92       Roos  117
#[Out]# 93       Rosa  158
#[Out]# 94    Rosalie  166
#[Out]# 95       Ryan   45
#[Out]# 96        Sam  175
#[Out]# 97     Samuel   74
#[Out]# 98      Sanne  130
#[Out]# 99      Sarah  120
#[Out]# 100       Sem    1
#[Out]# 101      Senn   63
#[Out]# 102     Simon   81
#[Out]# 103      Stan   64
#[Out]# 104      Stef   86
#[Out]# 105     Tessa  171
#[Out]# 106      Teun   30
#[Out]# 107    Thomas    9
#[Out]# 108    Tobias   56
#[Out]# 109       Tom   43
#[Out]# 110      Tygo   48
#[Out]# 111    Veerle  167
#[Out]# 112      Vera  140
#[Out]# 113     Vince   32
#[Out]# 114    Willem   52
#[Out]# 115      Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 22:16:22
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Abel   62
#[Out]# 1        Adam   12
#[Out]# 2       Amber  153
#[Out]# 3      Angela  186
#[Out]# 4      Benthe  154
#[Out]# 5          Bo  142
#[Out]# 6        Boaz   36
#[Out]# 7       Boris   68
#[Out]# 8        Bram    7
#[Out]# 9         Cas   49
#[Out]# 10     Casper   84
#[Out]# 11       Dani   72
#[Out]# 12      David   34
#[Out]# 13       Emma   95
#[Out]# 14        Eva  101
#[Out]# 15        Evi  102
#[Out]# 16        Evy  164
#[Out]# 17      Fedde   46
#[Out]# 18      Femke  136
#[Out]# 19      Fenne  159
#[Out]# 20       Fien  145
#[Out]# 21       Finn    3
#[Out]# 22      Fleur  106
#[Out]# 23     Floris   38
#[Out]# 24       Guus   37
#[Out]# 25     Hannah  132
#[Out]# 26      Hidde   77
#[Out]# 27       Iris  170
#[Out]# 28        Isa  121
#[Out]# 29   Isabella  148
#[Out]# ..        ...  ...
#[Out]# 86        Pim   50
#[Out]# 87       Pino  188
#[Out]# 88       Puck  157
#[Out]# 89      Quinn   41
#[Out]# 90       Roan   69
#[Out]# 91       Romy  174
#[Out]# 92       Roos  117
#[Out]# 93       Rosa  158
#[Out]# 94    Rosalie  166
#[Out]# 95       Ryan   45
#[Out]# 96        Sam  175
#[Out]# 97     Samuel   74
#[Out]# 98      Sanne  130
#[Out]# 99      Sarah  120
#[Out]# 100       Sem    1
#[Out]# 101      Senn   63
#[Out]# 102     Simon   81
#[Out]# 103      Stan   64
#[Out]# 104      Stef   86
#[Out]# 105     Tessa  171
#[Out]# 106      Teun   30
#[Out]# 107    Thomas    9
#[Out]# 108    Tobias   56
#[Out]# 109       Tom   43
#[Out]# 110      Tygo   48
#[Out]# 111    Veerle  167
#[Out]# 112      Vera  140
#[Out]# 113     Vince   32
#[Out]# 114    Willem   52
#[Out]# 115      Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 22:17:16
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7         Anna   99
#[Out]# 8         Anne  152
#[Out]# 9       Benthe  154
#[Out]# 10          Bo  142
#[Out]# 11        Boaz   36
#[Out]# 12        Bram    7
#[Out]# 13         Cas   49
#[Out]# 14      Casper   84
#[Out]# 15        Cato  163
#[Out]# 16       David   34
#[Out]# 17        Dean   71
#[Out]# 18         Dex   17
#[Out]# 19       Dylan   82
#[Out]# 20       Elena  162
#[Out]# 21        Elif  178
#[Out]# 22       Eline  177
#[Out]# 23       Elise  139
#[Out]# 24        Ella  134
#[Out]# 25       Emily  127
#[Out]# 26        Emma   95
#[Out]# 27       Esmee  129
#[Out]# 28         Eva  101
#[Out]# 29         Evi  102
#[Out]# ..         ...  ...
#[Out]# 125       Saar  110
#[Out]# 126        Sam   10
#[Out]# 127        Sam  175
#[Out]# 128     Samuel   74
#[Out]# 129      Sanne  130
#[Out]# 130       Sara  100
#[Out]# 131      Sarah  120
#[Out]# 132        Sem    1
#[Out]# 133       Siem   28
#[Out]# 134      Simon   81
#[Out]# 135      Sofia  135
#[Out]# 136      Sofie  124
#[Out]# 137     Sophia  133
#[Out]# 138     Sophie   97
#[Out]# 139       Stan   64
#[Out]# 140      Stijn   35
#[Out]# 141       Sven   33
#[Out]# 142       Tess   96
#[Out]# 143       Teun   30
#[Out]# 144    Thijmen   91
#[Out]# 145      Thijs   11
#[Out]# 146     Thomas    9
#[Out]# 147       Ties   51
#[Out]# 148       Tijn   42
#[Out]# 149     Tobias   56
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Thu, 26 Nov 2020 22:17:32
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Abel   62
#[Out]# 1        Adam   12
#[Out]# 2       Amber  153
#[Out]# 3      Angela  186
#[Out]# 4      Benthe  154
#[Out]# 5          Bo  142
#[Out]# 6        Boaz   36
#[Out]# 7       Boris   68
#[Out]# 8        Bram    7
#[Out]# 9         Cas   49
#[Out]# 10     Casper   84
#[Out]# 11       Dani   72
#[Out]# 12      David   34
#[Out]# 13       Emma   95
#[Out]# 14        Eva  101
#[Out]# 15        Evi  102
#[Out]# 16        Evy  164
#[Out]# 17      Fedde   46
#[Out]# 18      Femke  136
#[Out]# 19      Fenne  159
#[Out]# 20       Fien  145
#[Out]# 21       Finn    3
#[Out]# 22      Fleur  106
#[Out]# 23     Floris   38
#[Out]# 24       Guus   37
#[Out]# 25     Hannah  132
#[Out]# 26      Hidde   77
#[Out]# 27       Iris  170
#[Out]# 28        Isa  121
#[Out]# 29   Isabella  148
#[Out]# ..        ...  ...
#[Out]# 86        Pim   50
#[Out]# 87       Pino  188
#[Out]# 88       Puck  157
#[Out]# 89      Quinn   41
#[Out]# 90       Roan   69
#[Out]# 91       Romy  174
#[Out]# 92       Roos  117
#[Out]# 93       Rosa  158
#[Out]# 94    Rosalie  166
#[Out]# 95       Ryan   45
#[Out]# 96        Sam  175
#[Out]# 97     Samuel   74
#[Out]# 98      Sanne  130
#[Out]# 99      Sarah  120
#[Out]# 100       Sem    1
#[Out]# 101      Senn   63
#[Out]# 102     Simon   81
#[Out]# 103      Stan   64
#[Out]# 104      Stef   86
#[Out]# 105     Tessa  171
#[Out]# 106      Teun   30
#[Out]# 107    Thomas    9
#[Out]# 108    Tobias   56
#[Out]# 109       Tom   43
#[Out]# 110      Tygo   48
#[Out]# 111    Veerle  167
#[Out]# 112      Vera  140
#[Out]# 113     Vince   32
#[Out]# 114    Willem   52
#[Out]# 115      Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 22:17:40
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7       Angela  186
#[Out]# 8         Anna   99
#[Out]# 9         Anne  152
#[Out]# 10    Benjamin   21
#[Out]# 11      Benthe  154
#[Out]# 12          Bo  142
#[Out]# 13        Boaz   36
#[Out]# 14       Boris   68
#[Out]# 15        Bram    7
#[Out]# 16         Cas   49
#[Out]# 17      Casper   84
#[Out]# 18        Cato  163
#[Out]# 19        Daan    4
#[Out]# 20        Dani   72
#[Out]# 21       David   34
#[Out]# 22        Dean   71
#[Out]# 23         Dex   17
#[Out]# 24       Dylan   82
#[Out]# 25       Elena  162
#[Out]# 26        Elif  178
#[Out]# 27        Elin  122
#[Out]# 28       Eline  177
#[Out]# 29       Elise  139
#[Out]# ..         ...  ...
#[Out]# 160       Senn   63
#[Out]# 161       Siem   28
#[Out]# 162      Simon   81
#[Out]# 163      Sofia  135
#[Out]# 164      Sofie  124
#[Out]# 165     Sophia  133
#[Out]# 166     Sophie   97
#[Out]# 167       Stan   64
#[Out]# 168       Stef   86
#[Out]# 169      Stijn   35
#[Out]# 170       Sven   33
#[Out]# 171       Tess   96
#[Out]# 172      Tessa  171
#[Out]# 173       Teun   30
#[Out]# 174    Thijmen   91
#[Out]# 175      Thijs   11
#[Out]# 176     Thomas    9
#[Out]# 177       Ties   51
#[Out]# 178       Tijn   42
#[Out]# 179        Tim   27
#[Out]# 180     Tobias   56
#[Out]# 181        Tom   43
#[Out]# 182       Tygo   48
#[Out]# 183     Veerle  167
#[Out]# 184       Vera  140
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Thu, 26 Nov 2020 22:21:48
query3_3 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    EXCEPT
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 22:22:01
query3_3 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    EXCEPT c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 22:22:11
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7       Angela  186
#[Out]# 8         Anna   99
#[Out]# 9         Anne  152
#[Out]# 10    Benjamin   21
#[Out]# 11      Benthe  154
#[Out]# 12          Bo  142
#[Out]# 13        Boaz   36
#[Out]# 14       Boris   68
#[Out]# 15        Bram    7
#[Out]# 16         Cas   49
#[Out]# 17      Casper   84
#[Out]# 18        Cato  163
#[Out]# 19        Daan    4
#[Out]# 20        Dani   72
#[Out]# 21       David   34
#[Out]# 22        Dean   71
#[Out]# 23         Dex   17
#[Out]# 24       Dylan   82
#[Out]# 25       Elena  162
#[Out]# 26        Elif  178
#[Out]# 27        Elin  122
#[Out]# 28       Eline  177
#[Out]# 29       Elise  139
#[Out]# ..         ...  ...
#[Out]# 160       Senn   63
#[Out]# 161       Siem   28
#[Out]# 162      Simon   81
#[Out]# 163      Sofia  135
#[Out]# 164      Sofie  124
#[Out]# 165     Sophia  133
#[Out]# 166     Sophie   97
#[Out]# 167       Stan   64
#[Out]# 168       Stef   86
#[Out]# 169      Stijn   35
#[Out]# 170       Sven   33
#[Out]# 171       Tess   96
#[Out]# 172      Tessa  171
#[Out]# 173       Teun   30
#[Out]# 174    Thijmen   91
#[Out]# 175      Thijs   11
#[Out]# 176     Thomas    9
#[Out]# 177       Ties   51
#[Out]# 178       Tijn   42
#[Out]# 179        Tim   27
#[Out]# 180     Tobias   56
#[Out]# 181        Tom   43
#[Out]# 182       Tygo   48
#[Out]# 183     Veerle  167
#[Out]# 184       Vera  140
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Thu, 26 Nov 2020 22:30:57
query3_4 = '''
    SELECT cName, cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName != 'Kumar'
'''

pd.read_sql_query(query3_4, conn)
# Thu, 26 Nov 2020 22:31:25
query3_4 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName != 'Kumar'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Thu, 26 Nov 2020 22:31:35
query3_4 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Jumbo'
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName != 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0  Angela  186
#[Out]# 1   Femke  136
#[Out]# 2    Koen  189
#[Out]# 3     Liv  104
#[Out]# 4    Nick  185
#[Out]# 5    Pino  188
#[Out]# 6    Senn   63
#[Out]# 7    Xavi   47
# Thu, 26 Nov 2020 22:31:52
query3_4 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName != 'Kumar'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []

# IPython log file

# Fri, 27 Nov 2020 11:44:35
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Fri, 27 Nov 2020 11:44:47
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 11:45:54
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE %2018%
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:46:23
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE 2018
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:56:39
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE %2018%
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:56:44
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0        Noah    0  2018-08-22
#[Out]# 1         Sem    1  2018-08-20
#[Out]# 2       Lucas    2  2018-08-22
#[Out]# 3        Finn    3  2018-08-22
#[Out]# 4        Daan    4  2018-08-22
#[Out]# 5        Levi    5  2018-08-22
#[Out]# 6       Milan    6  2018-08-22
#[Out]# 7        Bram    7  2018-08-22
#[Out]# 8        Liam    8  2018-08-22
#[Out]# 9      Thomas    9  2018-08-22
#[Out]# 10        Sam   10  2018-08-22
#[Out]# 11      Thijs   11  2018-08-22
#[Out]# 12       Adam   12  2018-08-22
#[Out]# 13      James   13  2018-08-22
#[Out]# 14        Max   14  2018-08-22
#[Out]# 15       Noud   15  2018-08-22
#[Out]# 16     Julian   16  2018-08-22
#[Out]# 17        Dex   17  2018-08-22
#[Out]# 18       Hugo   18  2018-08-22
#[Out]# 19       Lars   19  2018-08-22
#[Out]# 20       Gijs   20  2018-08-22
#[Out]# 21   Benjamin   21  2018-08-22
#[Out]# 22       Mats   22  2018-08-22
#[Out]# 23        Jan   23  2018-08-22
#[Out]# 24       Luca   24  2018-08-22
#[Out]# 25      Mason   25  2018-08-22
#[Out]# 26     Jayden   26  2018-08-22
#[Out]# 27        Tim   27  2018-08-22
#[Out]# 28       Siem   28  2018-08-22
#[Out]# 29      Ruben   29  2018-08-22
#[Out]# ..        ...  ...         ...
#[Out]# 160      Lara  160  2018-08-22
#[Out]# 161     Floor  161  2018-08-22
#[Out]# 162     Elena  162  2018-08-22
#[Out]# 163      Cato  163  2018-08-22
#[Out]# 164       Evy  164  2018-08-22
#[Out]# 165     Hanna  165  2018-08-22
#[Out]# 166   Rosalie  166  2018-08-22
#[Out]# 167    Veerle  167  2018-08-22
#[Out]# 168      Kiki  168  2018-08-22
#[Out]# 169      Lily  169  2018-08-22
#[Out]# 170      Iris  170  2018-08-22
#[Out]# 171     Tessa  171  2018-08-22
#[Out]# 172      Lana  172  2018-08-22
#[Out]# 173     Livia  173  2018-08-22
#[Out]# 174      Romy  174  2018-08-22
#[Out]# 175       Sam  175  2018-08-22
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Eline  177  2018-08-22
#[Out]# 178      Elif  178  2018-08-22
#[Out]# 179      Juul  179  2018-08-22
#[Out]# 180     Merel  180  2018-08-22
#[Out]# 181      Liva  181  2018-08-22
#[Out]# 182   Johanna  182  2018-08-22
#[Out]# 183     Nikki  183  2018-08-22
#[Out]# 184     Wilko  184  2018-08-22
#[Out]# 185      Nick  185  2018-08-22
#[Out]# 186    Angela  186  2018-08-22
#[Out]# 187      Pino  188  2018-08-22
#[Out]# 188      Koen  189  2018-08-22
#[Out]# 189    Kostas  190  2018-08-22
#[Out]# 
#[Out]# [190 rows x 3 columns]
# Fri, 27 Nov 2020 11:56:51
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE 2018%
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:56:55
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE 2018
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, date]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:57:00
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE *2018*
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:57:09
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE ~2018~
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
# Fri, 27 Nov 2020 11:58:17
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '2018'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, date]
#[Out]# Index: []
# Fri, 27 Nov 2020 11:59:40
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '2018_%'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0        Noah    0  2018-08-22
#[Out]# 1         Sem    1  2018-08-20
#[Out]# 2       Lucas    2  2018-08-22
#[Out]# 3        Finn    3  2018-08-22
#[Out]# 4        Daan    4  2018-08-22
#[Out]# 5        Levi    5  2018-08-22
#[Out]# 6       Milan    6  2018-08-22
#[Out]# 7        Bram    7  2018-08-22
#[Out]# 8        Liam    8  2018-08-22
#[Out]# 9      Thomas    9  2018-08-22
#[Out]# 10        Sam   10  2018-08-22
#[Out]# 11      Thijs   11  2018-08-22
#[Out]# 12       Adam   12  2018-08-22
#[Out]# 13      James   13  2018-08-22
#[Out]# 14        Max   14  2018-08-22
#[Out]# 15       Noud   15  2018-08-22
#[Out]# 16     Julian   16  2018-08-22
#[Out]# 17        Dex   17  2018-08-22
#[Out]# 18       Hugo   18  2018-08-22
#[Out]# 19       Lars   19  2018-08-22
#[Out]# 20       Gijs   20  2018-08-22
#[Out]# 21   Benjamin   21  2018-08-22
#[Out]# 22       Mats   22  2018-08-22
#[Out]# 23        Jan   23  2018-08-22
#[Out]# 24       Luca   24  2018-08-22
#[Out]# 25      Mason   25  2018-08-22
#[Out]# 26     Jayden   26  2018-08-22
#[Out]# 27        Tim   27  2018-08-22
#[Out]# 28       Siem   28  2018-08-22
#[Out]# 29      Ruben   29  2018-08-22
#[Out]# ..        ...  ...         ...
#[Out]# 160      Lara  160  2018-08-22
#[Out]# 161     Floor  161  2018-08-22
#[Out]# 162     Elena  162  2018-08-22
#[Out]# 163      Cato  163  2018-08-22
#[Out]# 164       Evy  164  2018-08-22
#[Out]# 165     Hanna  165  2018-08-22
#[Out]# 166   Rosalie  166  2018-08-22
#[Out]# 167    Veerle  167  2018-08-22
#[Out]# 168      Kiki  168  2018-08-22
#[Out]# 169      Lily  169  2018-08-22
#[Out]# 170      Iris  170  2018-08-22
#[Out]# 171     Tessa  171  2018-08-22
#[Out]# 172      Lana  172  2018-08-22
#[Out]# 173     Livia  173  2018-08-22
#[Out]# 174      Romy  174  2018-08-22
#[Out]# 175       Sam  175  2018-08-22
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Eline  177  2018-08-22
#[Out]# 178      Elif  178  2018-08-22
#[Out]# 179      Juul  179  2018-08-22
#[Out]# 180     Merel  180  2018-08-22
#[Out]# 181      Liva  181  2018-08-22
#[Out]# 182   Johanna  182  2018-08-22
#[Out]# 183     Nikki  183  2018-08-22
#[Out]# 184     Wilko  184  2018-08-22
#[Out]# 185      Nick  185  2018-08-22
#[Out]# 186    Angela  186  2018-08-22
#[Out]# 187      Pino  188  2018-08-22
#[Out]# 188      Koen  189  2018-08-22
#[Out]# 189    Kostas  190  2018-08-22
#[Out]# 
#[Out]# [190 rows x 3 columns]
# Fri, 27 Nov 2020 11:59:47
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '2018%'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0        Noah    0  2018-08-22
#[Out]# 1         Sem    1  2018-08-20
#[Out]# 2       Lucas    2  2018-08-22
#[Out]# 3        Finn    3  2018-08-22
#[Out]# 4        Daan    4  2018-08-22
#[Out]# 5        Levi    5  2018-08-22
#[Out]# 6       Milan    6  2018-08-22
#[Out]# 7        Bram    7  2018-08-22
#[Out]# 8        Liam    8  2018-08-22
#[Out]# 9      Thomas    9  2018-08-22
#[Out]# 10        Sam   10  2018-08-22
#[Out]# 11      Thijs   11  2018-08-22
#[Out]# 12       Adam   12  2018-08-22
#[Out]# 13      James   13  2018-08-22
#[Out]# 14        Max   14  2018-08-22
#[Out]# 15       Noud   15  2018-08-22
#[Out]# 16     Julian   16  2018-08-22
#[Out]# 17        Dex   17  2018-08-22
#[Out]# 18       Hugo   18  2018-08-22
#[Out]# 19       Lars   19  2018-08-22
#[Out]# 20       Gijs   20  2018-08-22
#[Out]# 21   Benjamin   21  2018-08-22
#[Out]# 22       Mats   22  2018-08-22
#[Out]# 23        Jan   23  2018-08-22
#[Out]# 24       Luca   24  2018-08-22
#[Out]# 25      Mason   25  2018-08-22
#[Out]# 26     Jayden   26  2018-08-22
#[Out]# 27        Tim   27  2018-08-22
#[Out]# 28       Siem   28  2018-08-22
#[Out]# 29      Ruben   29  2018-08-22
#[Out]# ..        ...  ...         ...
#[Out]# 160      Lara  160  2018-08-22
#[Out]# 161     Floor  161  2018-08-22
#[Out]# 162     Elena  162  2018-08-22
#[Out]# 163      Cato  163  2018-08-22
#[Out]# 164       Evy  164  2018-08-22
#[Out]# 165     Hanna  165  2018-08-22
#[Out]# 166   Rosalie  166  2018-08-22
#[Out]# 167    Veerle  167  2018-08-22
#[Out]# 168      Kiki  168  2018-08-22
#[Out]# 169      Lily  169  2018-08-22
#[Out]# 170      Iris  170  2018-08-22
#[Out]# 171     Tessa  171  2018-08-22
#[Out]# 172      Lana  172  2018-08-22
#[Out]# 173     Livia  173  2018-08-22
#[Out]# 174      Romy  174  2018-08-22
#[Out]# 175       Sam  175  2018-08-22
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Eline  177  2018-08-22
#[Out]# 178      Elif  178  2018-08-22
#[Out]# 179      Juul  179  2018-08-22
#[Out]# 180     Merel  180  2018-08-22
#[Out]# 181      Liva  181  2018-08-22
#[Out]# 182   Johanna  182  2018-08-22
#[Out]# 183     Nikki  183  2018-08-22
#[Out]# 184     Wilko  184  2018-08-22
#[Out]# 185      Nick  185  2018-08-22
#[Out]# 186    Angela  186  2018-08-22
#[Out]# 187      Pino  188  2018-08-22
#[Out]# 188      Koen  189  2018-08-22
#[Out]# 189    Kostas  190  2018-08-22
#[Out]# 
#[Out]# [190 rows x 3 columns]
# Fri, 27 Nov 2020 11:59:50
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '%2018%'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0        Noah    0  2018-08-22
#[Out]# 1         Sem    1  2018-08-20
#[Out]# 2       Lucas    2  2018-08-22
#[Out]# 3        Finn    3  2018-08-22
#[Out]# 4        Daan    4  2018-08-22
#[Out]# 5        Levi    5  2018-08-22
#[Out]# 6       Milan    6  2018-08-22
#[Out]# 7        Bram    7  2018-08-22
#[Out]# 8        Liam    8  2018-08-22
#[Out]# 9      Thomas    9  2018-08-22
#[Out]# 10        Sam   10  2018-08-22
#[Out]# 11      Thijs   11  2018-08-22
#[Out]# 12       Adam   12  2018-08-22
#[Out]# 13      James   13  2018-08-22
#[Out]# 14        Max   14  2018-08-22
#[Out]# 15       Noud   15  2018-08-22
#[Out]# 16     Julian   16  2018-08-22
#[Out]# 17        Dex   17  2018-08-22
#[Out]# 18       Hugo   18  2018-08-22
#[Out]# 19       Lars   19  2018-08-22
#[Out]# 20       Gijs   20  2018-08-22
#[Out]# 21   Benjamin   21  2018-08-22
#[Out]# 22       Mats   22  2018-08-22
#[Out]# 23        Jan   23  2018-08-22
#[Out]# 24       Luca   24  2018-08-22
#[Out]# 25      Mason   25  2018-08-22
#[Out]# 26     Jayden   26  2018-08-22
#[Out]# 27        Tim   27  2018-08-22
#[Out]# 28       Siem   28  2018-08-22
#[Out]# 29      Ruben   29  2018-08-22
#[Out]# ..        ...  ...         ...
#[Out]# 160      Lara  160  2018-08-22
#[Out]# 161     Floor  161  2018-08-22
#[Out]# 162     Elena  162  2018-08-22
#[Out]# 163      Cato  163  2018-08-22
#[Out]# 164       Evy  164  2018-08-22
#[Out]# 165     Hanna  165  2018-08-22
#[Out]# 166   Rosalie  166  2018-08-22
#[Out]# 167    Veerle  167  2018-08-22
#[Out]# 168      Kiki  168  2018-08-22
#[Out]# 169      Lily  169  2018-08-22
#[Out]# 170      Iris  170  2018-08-22
#[Out]# 171     Tessa  171  2018-08-22
#[Out]# 172      Lana  172  2018-08-22
#[Out]# 173     Livia  173  2018-08-22
#[Out]# 174      Romy  174  2018-08-22
#[Out]# 175       Sam  175  2018-08-22
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Eline  177  2018-08-22
#[Out]# 178      Elif  178  2018-08-22
#[Out]# 179      Juul  179  2018-08-22
#[Out]# 180     Merel  180  2018-08-22
#[Out]# 181      Liva  181  2018-08-22
#[Out]# 182   Johanna  182  2018-08-22
#[Out]# 183     Nikki  183  2018-08-22
#[Out]# 184     Wilko  184  2018-08-22
#[Out]# 185      Nick  185  2018-08-22
#[Out]# 186    Angela  186  2018-08-22
#[Out]# 187      Pino  188  2018-08-22
#[Out]# 188      Koen  189  2018-08-22
#[Out]# 189    Kostas  190  2018-08-22
#[Out]# 
#[Out]# [190 rows x 3 columns]
# Fri, 27 Nov 2020 12:00:09
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '2018%'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0        Noah    0  2018-08-22
#[Out]# 1         Sem    1  2018-08-20
#[Out]# 2       Lucas    2  2018-08-22
#[Out]# 3        Finn    3  2018-08-22
#[Out]# 4        Daan    4  2018-08-22
#[Out]# 5        Levi    5  2018-08-22
#[Out]# 6       Milan    6  2018-08-22
#[Out]# 7        Bram    7  2018-08-22
#[Out]# 8        Liam    8  2018-08-22
#[Out]# 9      Thomas    9  2018-08-22
#[Out]# 10        Sam   10  2018-08-22
#[Out]# 11      Thijs   11  2018-08-22
#[Out]# 12       Adam   12  2018-08-22
#[Out]# 13      James   13  2018-08-22
#[Out]# 14        Max   14  2018-08-22
#[Out]# 15       Noud   15  2018-08-22
#[Out]# 16     Julian   16  2018-08-22
#[Out]# 17        Dex   17  2018-08-22
#[Out]# 18       Hugo   18  2018-08-22
#[Out]# 19       Lars   19  2018-08-22
#[Out]# 20       Gijs   20  2018-08-22
#[Out]# 21   Benjamin   21  2018-08-22
#[Out]# 22       Mats   22  2018-08-22
#[Out]# 23        Jan   23  2018-08-22
#[Out]# 24       Luca   24  2018-08-22
#[Out]# 25      Mason   25  2018-08-22
#[Out]# 26     Jayden   26  2018-08-22
#[Out]# 27        Tim   27  2018-08-22
#[Out]# 28       Siem   28  2018-08-22
#[Out]# 29      Ruben   29  2018-08-22
#[Out]# ..        ...  ...         ...
#[Out]# 160      Lara  160  2018-08-22
#[Out]# 161     Floor  161  2018-08-22
#[Out]# 162     Elena  162  2018-08-22
#[Out]# 163      Cato  163  2018-08-22
#[Out]# 164       Evy  164  2018-08-22
#[Out]# 165     Hanna  165  2018-08-22
#[Out]# 166   Rosalie  166  2018-08-22
#[Out]# 167    Veerle  167  2018-08-22
#[Out]# 168      Kiki  168  2018-08-22
#[Out]# 169      Lily  169  2018-08-22
#[Out]# 170      Iris  170  2018-08-22
#[Out]# 171     Tessa  171  2018-08-22
#[Out]# 172      Lana  172  2018-08-22
#[Out]# 173     Livia  173  2018-08-22
#[Out]# 174      Romy  174  2018-08-22
#[Out]# 175       Sam  175  2018-08-22
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Eline  177  2018-08-22
#[Out]# 178      Elif  178  2018-08-22
#[Out]# 179      Juul  179  2018-08-22
#[Out]# 180     Merel  180  2018-08-22
#[Out]# 181      Liva  181  2018-08-22
#[Out]# 182   Johanna  182  2018-08-22
#[Out]# 183     Nikki  183  2018-08-22
#[Out]# 184     Wilko  184  2018-08-22
#[Out]# 185      Nick  185  2018-08-22
#[Out]# 186    Angela  186  2018-08-22
#[Out]# 187      Pino  188  2018-08-22
#[Out]# 188      Koen  189  2018-08-22
#[Out]# 189    Kostas  190  2018-08-22
#[Out]# 
#[Out]# [190 rows x 3 columns]
# Fri, 27 Nov 2020 12:00:20
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '2018-08-20%'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cName  cID        date
#[Out]# 0        Sem    1  2018-08-20
#[Out]# 1   Benjamin   21  2018-08-20
#[Out]# 2       Luca   24  2018-08-20
#[Out]# 3      Jurre   58  2018-08-20
#[Out]# 4      Boris   68  2018-08-20
#[Out]# 5       Dani   72  2018-08-20
#[Out]# 6      Dylan   82  2018-08-20
#[Out]# 7     Casper   84  2018-08-20
#[Out]# 8       Sara  100  2018-08-20
#[Out]# 9       Lynn  109  2018-08-20
#[Out]# 10      Lisa  118  2018-08-20
#[Out]# 11  Isabella  148  2018-08-20
#[Out]# 12      Anne  152  2018-08-20
#[Out]# 13    Veerle  167  2018-08-20
#[Out]# 14      Lily  169  2018-08-20
#[Out]# 15     Tessa  171  2018-08-20
#[Out]# 16     Nikki  183  2018-08-20
# Fri, 27 Nov 2020 12:00:27
query3_2 = '''
    SELECT c.cName, c.cID, s.date
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '2018%'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0        Noah    0  2018-08-22
#[Out]# 1         Sem    1  2018-08-20
#[Out]# 2       Lucas    2  2018-08-22
#[Out]# 3        Finn    3  2018-08-22
#[Out]# 4        Daan    4  2018-08-22
#[Out]# 5        Levi    5  2018-08-22
#[Out]# 6       Milan    6  2018-08-22
#[Out]# 7        Bram    7  2018-08-22
#[Out]# 8        Liam    8  2018-08-22
#[Out]# 9      Thomas    9  2018-08-22
#[Out]# 10        Sam   10  2018-08-22
#[Out]# 11      Thijs   11  2018-08-22
#[Out]# 12       Adam   12  2018-08-22
#[Out]# 13      James   13  2018-08-22
#[Out]# 14        Max   14  2018-08-22
#[Out]# 15       Noud   15  2018-08-22
#[Out]# 16     Julian   16  2018-08-22
#[Out]# 17        Dex   17  2018-08-22
#[Out]# 18       Hugo   18  2018-08-22
#[Out]# 19       Lars   19  2018-08-22
#[Out]# 20       Gijs   20  2018-08-22
#[Out]# 21   Benjamin   21  2018-08-22
#[Out]# 22       Mats   22  2018-08-22
#[Out]# 23        Jan   23  2018-08-22
#[Out]# 24       Luca   24  2018-08-22
#[Out]# 25      Mason   25  2018-08-22
#[Out]# 26     Jayden   26  2018-08-22
#[Out]# 27        Tim   27  2018-08-22
#[Out]# 28       Siem   28  2018-08-22
#[Out]# 29      Ruben   29  2018-08-22
#[Out]# ..        ...  ...         ...
#[Out]# 160      Lara  160  2018-08-22
#[Out]# 161     Floor  161  2018-08-22
#[Out]# 162     Elena  162  2018-08-22
#[Out]# 163      Cato  163  2018-08-22
#[Out]# 164       Evy  164  2018-08-22
#[Out]# 165     Hanna  165  2018-08-22
#[Out]# 166   Rosalie  166  2018-08-22
#[Out]# 167    Veerle  167  2018-08-22
#[Out]# 168      Kiki  168  2018-08-22
#[Out]# 169      Lily  169  2018-08-22
#[Out]# 170      Iris  170  2018-08-22
#[Out]# 171     Tessa  171  2018-08-22
#[Out]# 172      Lana  172  2018-08-22
#[Out]# 173     Livia  173  2018-08-22
#[Out]# 174      Romy  174  2018-08-22
#[Out]# 175       Sam  175  2018-08-22
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Eline  177  2018-08-22
#[Out]# 178      Elif  178  2018-08-22
#[Out]# 179      Juul  179  2018-08-22
#[Out]# 180     Merel  180  2018-08-22
#[Out]# 181      Liva  181  2018-08-22
#[Out]# 182   Johanna  182  2018-08-22
#[Out]# 183     Nikki  183  2018-08-22
#[Out]# 184     Wilko  184  2018-08-22
#[Out]# 185      Nick  185  2018-08-22
#[Out]# 186    Angela  186  2018-08-22
#[Out]# 187      Pino  188  2018-08-22
#[Out]# 188      Koen  189  2018-08-22
#[Out]# 189    Kostas  190  2018-08-22
#[Out]# 
#[Out]# [190 rows x 3 columns]
# Fri, 27 Nov 2020 12:00:38
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '2018%'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:00:51
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1       Noah    0
#[Out]# 2       Noah    0
#[Out]# 3       Noah    0
#[Out]# 4       Noah    0
#[Out]# 5       Noah    0
#[Out]# 6       Noah    0
#[Out]# 7       Noah    0
#[Out]# 8       Noah    0
#[Out]# 9       Noah    0
#[Out]# 10      Noah    0
#[Out]# 11      Noah    0
#[Out]# 12      Noah    0
#[Out]# 13      Noah    0
#[Out]# 14      Noah    0
#[Out]# 15      Noah    0
#[Out]# 16      Noah    0
#[Out]# 17      Noah    0
#[Out]# 18      Noah    0
#[Out]# 19      Noah    0
#[Out]# 20      Noah    0
#[Out]# 21      Noah    0
#[Out]# 22      Noah    0
#[Out]# 23      Noah    0
#[Out]# 24      Noah    0
#[Out]# 25      Noah    0
#[Out]# 26      Noah    0
#[Out]# 27      Noah    0
#[Out]# 28      Noah    0
#[Out]# 29      Noah    0
#[Out]# ...      ...  ...
#[Out]# 6839  Kostas  190
#[Out]# 6840  Kostas  190
#[Out]# 6841  Kostas  190
#[Out]# 6842  Kostas  190
#[Out]# 6843  Kostas  190
#[Out]# 6844  Kostas  190
#[Out]# 6845  Kostas  190
#[Out]# 6846  Kostas  190
#[Out]# 6847  Kostas  190
#[Out]# 6848  Kostas  190
#[Out]# 6849  Kostas  190
#[Out]# 6850  Kostas  190
#[Out]# 6851  Kostas  190
#[Out]# 6852  Kostas  190
#[Out]# 6853  Kostas  190
#[Out]# 6854  Kostas  190
#[Out]# 6855  Kostas  190
#[Out]# 6856  Kostas  190
#[Out]# 6857  Kostas  190
#[Out]# 6858  Kostas  190
#[Out]# 6859  Kostas  190
#[Out]# 6860  Kostas  190
#[Out]# 6861  Kostas  190
#[Out]# 6862  Kostas  190
#[Out]# 6863  Kostas  190
#[Out]# 6864  Kostas  190
#[Out]# 6865  Kostas  190
#[Out]# 6866  Kostas  190
#[Out]# 6867  Kostas  190
#[Out]# 6868  Kostas  190
#[Out]# 
#[Out]# [6869 rows x 2 columns]
# Fri, 27 Nov 2020 12:00:56
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppingList AS s, purchase AS p
    WHERE c.cID = s.cID = p.cID AND s.date = p.date AND s.date LIKE '2018%'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:04:47
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7       Angela  186
#[Out]# 8         Anna   99
#[Out]# 9         Anne  152
#[Out]# 10    Benjamin   21
#[Out]# 11      Benthe  154
#[Out]# 12          Bo  142
#[Out]# 13        Boaz   36
#[Out]# 14       Boris   68
#[Out]# 15        Bram    7
#[Out]# 16         Cas   49
#[Out]# 17      Casper   84
#[Out]# 18        Cato  163
#[Out]# 19        Daan    4
#[Out]# 20        Dani   72
#[Out]# 21       David   34
#[Out]# 22        Dean   71
#[Out]# 23         Dex   17
#[Out]# 24       Dylan   82
#[Out]# 25       Elena  162
#[Out]# 26        Elif  178
#[Out]# 27        Elin  122
#[Out]# 28       Eline  177
#[Out]# 29       Elise  139
#[Out]# ..         ...  ...
#[Out]# 160       Senn   63
#[Out]# 161       Siem   28
#[Out]# 162      Simon   81
#[Out]# 163      Sofia  135
#[Out]# 164      Sofie  124
#[Out]# 165     Sophia  133
#[Out]# 166     Sophie   97
#[Out]# 167       Stan   64
#[Out]# 168       Stef   86
#[Out]# 169      Stijn   35
#[Out]# 170       Sven   33
#[Out]# 171       Tess   96
#[Out]# 172      Tessa  171
#[Out]# 173       Teun   30
#[Out]# 174    Thijmen   91
#[Out]# 175      Thijs   11
#[Out]# 176     Thomas    9
#[Out]# 177       Ties   51
#[Out]# 178       Tijn   42
#[Out]# 179        Tim   27
#[Out]# 180     Tobias   56
#[Out]# 181        Tom   43
#[Out]# 182       Tygo   48
#[Out]# 183     Veerle  167
#[Out]# 184       Vera  140
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:05:04
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7       Angela  186
#[Out]# 8         Anna   99
#[Out]# 9         Anne  152
#[Out]# 10    Benjamin   21
#[Out]# 11      Benthe  154
#[Out]# 12          Bo  142
#[Out]# 13        Boaz   36
#[Out]# 14       Boris   68
#[Out]# 15        Bram    7
#[Out]# 16         Cas   49
#[Out]# 17      Casper   84
#[Out]# 18        Cato  163
#[Out]# 19        Daan    4
#[Out]# 20        Dani   72
#[Out]# 21       David   34
#[Out]# 22        Dean   71
#[Out]# 23         Dex   17
#[Out]# 24       Dylan   82
#[Out]# 25       Elena  162
#[Out]# 26        Elif  178
#[Out]# 27        Elin  122
#[Out]# 28       Eline  177
#[Out]# 29       Elise  139
#[Out]# ..         ...  ...
#[Out]# 160       Senn   63
#[Out]# 161       Siem   28
#[Out]# 162      Simon   81
#[Out]# 163      Sofia  135
#[Out]# 164      Sofie  124
#[Out]# 165     Sophia  133
#[Out]# 166     Sophie   97
#[Out]# 167       Stan   64
#[Out]# 168       Stef   86
#[Out]# 169      Stijn   35
#[Out]# 170       Sven   33
#[Out]# 171       Tess   96
#[Out]# 172      Tessa  171
#[Out]# 173       Teun   30
#[Out]# 174    Thijmen   91
#[Out]# 175      Thijs   11
#[Out]# 176     Thomas    9
#[Out]# 177       Ties   51
#[Out]# 178       Tijn   42
#[Out]# 179        Tim   27
#[Out]# 180     Tobias   56
#[Out]# 181        Tom   43
#[Out]# 182       Tygo   48
#[Out]# 183     Veerle  167
#[Out]# 184       Vera  140
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:05:08
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
    GROUP BY c.cID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7       Angela  186
#[Out]# 8         Anna   99
#[Out]# 9         Anne  152
#[Out]# 10    Benjamin   21
#[Out]# 11      Benthe  154
#[Out]# 12          Bo  142
#[Out]# 13        Boaz   36
#[Out]# 14       Boris   68
#[Out]# 15        Bram    7
#[Out]# 16         Cas   49
#[Out]# 17      Casper   84
#[Out]# 18        Cato  163
#[Out]# 19        Daan    4
#[Out]# 20        Dani   72
#[Out]# 21       David   34
#[Out]# 22        Dean   71
#[Out]# 23         Dex   17
#[Out]# 24       Dylan   82
#[Out]# 25       Elena  162
#[Out]# 26        Elif  178
#[Out]# 27        Elin  122
#[Out]# 28       Eline  177
#[Out]# 29       Elise  139
#[Out]# ..         ...  ...
#[Out]# 160       Senn   63
#[Out]# 161       Siem   28
#[Out]# 162      Simon   81
#[Out]# 163      Sofia  135
#[Out]# 164      Sofie  124
#[Out]# 165     Sophia  133
#[Out]# 166     Sophie   97
#[Out]# 167       Stan   64
#[Out]# 168       Stef   86
#[Out]# 169      Stijn   35
#[Out]# 170       Sven   33
#[Out]# 171       Tess   96
#[Out]# 172      Tessa  171
#[Out]# 173       Teun   30
#[Out]# 174    Thijmen   91
#[Out]# 175      Thijs   11
#[Out]# 176     Thomas    9
#[Out]# 177       Ties   51
#[Out]# 178       Tijn   42
#[Out]# 179        Tim   27
#[Out]# 180     Tobias   56
#[Out]# 181        Tom   43
#[Out]# 182       Tygo   48
#[Out]# 183     Veerle  167
#[Out]# 184       Vera  140
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:05:17
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
    GROUP BY cID
'''

pd.read_sql_query(query3_3, conn)
# Fri, 27 Nov 2020 12:05:23
query3_3 = '''
    SELECT cName, cID
    FROM customer
    GROUP BY cID
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7       Angela  186
#[Out]# 8         Anna   99
#[Out]# 9         Anne  152
#[Out]# 10    Benjamin   21
#[Out]# 11      Benthe  154
#[Out]# 12          Bo  142
#[Out]# 13        Boaz   36
#[Out]# 14       Boris   68
#[Out]# 15        Bram    7
#[Out]# 16         Cas   49
#[Out]# 17      Casper   84
#[Out]# 18        Cato  163
#[Out]# 19        Daan    4
#[Out]# 20        Dani   72
#[Out]# 21       David   34
#[Out]# 22        Dean   71
#[Out]# 23         Dex   17
#[Out]# 24       Dylan   82
#[Out]# 25       Elena  162
#[Out]# 26        Elif  178
#[Out]# 27        Elin  122
#[Out]# 28       Eline  177
#[Out]# 29       Elise  139
#[Out]# ..         ...  ...
#[Out]# 160       Senn   63
#[Out]# 161       Siem   28
#[Out]# 162      Simon   81
#[Out]# 163      Sofia  135
#[Out]# 164      Sofie  124
#[Out]# 165     Sophia  133
#[Out]# 166     Sophie   97
#[Out]# 167       Stan   64
#[Out]# 168       Stef   86
#[Out]# 169      Stijn   35
#[Out]# 170       Sven   33
#[Out]# 171       Tess   96
#[Out]# 172      Tessa  171
#[Out]# 173       Teun   30
#[Out]# 174    Thijmen   91
#[Out]# 175      Thijs   11
#[Out]# 176     Thomas    9
#[Out]# 177       Ties   51
#[Out]# 178       Tijn   42
#[Out]# 179        Tim   27
#[Out]# 180     Tobias   56
#[Out]# 181        Tom   43
#[Out]# 182       Tygo   48
#[Out]# 183     Veerle  167
#[Out]# 184       Vera  140
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Fri, 27 Nov 2020 12:05:30
query3_3 = '''
    SELECT cName, cID
    FROM customer
    EXCEPT
    SELECT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7       Angela  186
#[Out]# 8         Anna   99
#[Out]# 9         Anne  152
#[Out]# 10    Benjamin   21
#[Out]# 11      Benthe  154
#[Out]# 12          Bo  142
#[Out]# 13        Boaz   36
#[Out]# 14       Boris   68
#[Out]# 15        Bram    7
#[Out]# 16         Cas   49
#[Out]# 17      Casper   84
#[Out]# 18        Cato  163
#[Out]# 19        Daan    4
#[Out]# 20        Dani   72
#[Out]# 21       David   34
#[Out]# 22        Dean   71
#[Out]# 23         Dex   17
#[Out]# 24       Dylan   82
#[Out]# 25       Elena  162
#[Out]# 26        Elif  178
#[Out]# 27        Elin  122
#[Out]# 28       Eline  177
#[Out]# 29       Elise  139
#[Out]# ..         ...  ...
#[Out]# 160       Senn   63
#[Out]# 161       Siem   28
#[Out]# 162      Simon   81
#[Out]# 163      Sofia  135
#[Out]# 164      Sofie  124
#[Out]# 165     Sophia  133
#[Out]# 166     Sophie   97
#[Out]# 167       Stan   64
#[Out]# 168       Stef   86
#[Out]# 169      Stijn   35
#[Out]# 170       Sven   33
#[Out]# 171       Tess   96
#[Out]# 172      Tessa  171
#[Out]# 173       Teun   30
#[Out]# 174    Thijmen   91
#[Out]# 175      Thijs   11
#[Out]# 176     Thomas    9
#[Out]# 177       Ties   51
#[Out]# 178       Tijn   42
#[Out]# 179        Tim   27
#[Out]# 180     Tobias   56
#[Out]# 181        Tom   43
#[Out]# 182       Tygo   48
#[Out]# 183     Veerle  167
#[Out]# 184       Vera  140
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]


# IPython log file

# Tue, 01 Dec 2020 19:15:06
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 19:15:06
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7f91f0384e30>
# Tue, 01 Dec 2020 19:15:10
query3_2 = '''
    PUT YOUR QUERY HERE
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 19:15:15
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:15
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:16
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:17
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:19
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:21
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:26
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:37
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:37
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:38
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:39
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:39
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:42
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:43
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:44
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:44
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:45
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:45
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:50
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:52
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:53
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:15:53
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:16:07
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:16:13
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:16:23
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:16:23
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:16:23
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:16:24
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:16:25
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:16:34
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:16:36
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:18:58
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:02
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:02
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:03
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:03
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:04
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:04
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:04
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:05
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:05
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:08
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:08
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:18
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:50
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:50
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:51
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:53
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:19:55
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:19
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:20
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:20
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:21
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:21
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:21
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:22
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:22
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:23
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:24
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:36
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:36
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:37
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer
    JOIN shoppinglist ON shoppinglist.cID=customer.cID
    JOIN purchase ON purchase.cID=customer.cID AND purchase.pID=shoppinglist.pID
    WHERE shoppinglist.date LIKE '%2018%' AND purchase.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 19:20:38
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:42
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:42
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:43
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:43
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:45
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:46
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:20:49
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer
    JOIN shoppinglist ON shoppinglist.cID=customer.cID
    JOIN purchase ON purchase.cID=customer.cID AND purchase.pID=shoppinglist.pID
    WHERE shoppinglist.date LIKE '%2018%' AND purchase.date LIKE '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 107  Amira  176
#[Out]# 108   Elif  178
#[Out]# 109   Juul  179
#[Out]# 110  Merel  180
#[Out]# 111   Liva  181
#[Out]# 
#[Out]# [112 rows x 2 columns]
# Tue, 01 Dec 2020 19:21:21
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:21:22
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:21:23
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:21:23
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:21:56
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:22:03
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:22:04
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:22:06
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:22:14
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer

    EXCEPT

    SELECT DISTINCT cName, customer.cID
    FROM purchase
    JOIN store ON store.sID=purchase.sID
    JOIN customer ON purchase.cID=customer.cID
    WHERE store.sName == 'Kumar';
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 19:22:15
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:22:37
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:22:45
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:22:45
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:23:06
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:23:12
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:23:15
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:23:20
query3_4 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer
    JOIN purchase ON purchase.cID=customer.cID
    JOIN store ON store.sID=purchase.sID
    WHERE store.sName LIKE 'Kumar'

    EXCEPT

    SELECT DISTINCT cName, customer.cID
    FROM customer
    JOIN purchase ON purchase.cID=customer.cID
    JOIN store ON store.sID=purchase.sID
    WHERE store.sName <> 'Kumar';
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 19:23:32
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)
# Tue, 01 Dec 2020 19:23:35
_rwho_ls = get_ipython().run_line_magic('who_ls', '')
print(_rwho_ls)


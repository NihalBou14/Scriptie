# IPython log file

# Mon, 30 Nov 2020 21:33:30
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 21:35:45
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1bffed21b20>
# Mon, 30 Nov 2020 21:49:05
query3_2 = '''
    SELECT DISTINCT cust.cName, cust.cID
    FROM customer as cust, shoppinglist as sList, purchase as p
    WHERE sList.date = p.date
    AND sList.date LIKE '%2018%'
    AND sList.cID = p.cID
    AND cust.cID = sList.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 21:49:23
query3_2 = '''
    SELECT cust.cName, cust.cID
    FROM customer as cust, shoppinglist as sList, purchase as p
    WHERE sList.date = p.date
    AND sList.date LIKE '%2018%'
    AND sList.cID = p.cID
    AND cust.cID = sList.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1      Sem    1
#[Out]# 2      Sem    1
#[Out]# 3      Sem    1
#[Out]# 4      Sem    1
#[Out]# 5      Sem    1
#[Out]# 6      Sem    1
#[Out]# 7      Sem    1
#[Out]# 8      Sem    1
#[Out]# 9      Sem    1
#[Out]# 10     Sem    1
#[Out]# 11     Sem    1
#[Out]# 12     Sem    1
#[Out]# 13     Sem    1
#[Out]# 14     Sem    1
#[Out]# 15     Sem    1
#[Out]# 16     Sem    1
#[Out]# 17     Sem    1
#[Out]# 18     Sem    1
#[Out]# 19     Sem    1
#[Out]# 20     Sem    1
#[Out]# 21     Sem    1
#[Out]# 22     Sem    1
#[Out]# 23     Sem    1
#[Out]# 24     Sem    1
#[Out]# 25     Sem    1
#[Out]# 26     Sem    1
#[Out]# 27     Sem    1
#[Out]# 28     Sem    1
#[Out]# 29     Sem    1
#[Out]# ..     ...  ...
#[Out]# 946  Amira  176
#[Out]# 947   Elif  178
#[Out]# 948   Elif  178
#[Out]# 949   Elif  178
#[Out]# 950   Elif  178
#[Out]# 951   Juul  179
#[Out]# 952   Juul  179
#[Out]# 953   Juul  179
#[Out]# 954   Juul  179
#[Out]# 955   Juul  179
#[Out]# 956   Juul  179
#[Out]# 957   Juul  179
#[Out]# 958   Juul  179
#[Out]# 959   Juul  179
#[Out]# 960   Juul  179
#[Out]# 961   Juul  179
#[Out]# 962   Juul  179
#[Out]# 963   Juul  179
#[Out]# 964   Juul  179
#[Out]# 965   Juul  179
#[Out]# 966  Merel  180
#[Out]# 967  Merel  180
#[Out]# 968  Merel  180
#[Out]# 969  Merel  180
#[Out]# 970   Liva  181
#[Out]# 971   Liva  181
#[Out]# 972   Liva  181
#[Out]# 973   Liva  181
#[Out]# 974   Liva  181
#[Out]# 975   Liva  181
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Mon, 30 Nov 2020 21:49:40
query3_2 = '''
    SELECT DISTINCT (cust.cName, cust.cID)
    FROM customer as cust, shoppinglist as sList, purchase as p
    WHERE sList.date = p.date
    AND sList.date LIKE '%2018%'
    AND sList.cID = p.cID
    AND cust.cID = sList.cID
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 21:53:58
query3_2 = '''
    SET single = (SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID)
    SELECT cust.cName, cust.cID
    FROM single, single
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 21:54:09
query3_2 = '''
    SET @single = (SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID)
    SELECT cust.cName, cust.cID
    FROM @single, @single
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 21:54:59
query3_2 = '''
    SET @single = (SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID)
    SELECT cust.cName, cust.cID
    FROM (SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID), (SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID)
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 21:55:12
query3_2 = '''
    SELECT cust.cName, cust.cID
    FROM (SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID), (SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID)
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 21:55:32
query3_2 = '''
    SELECT cName, cID
    FROM (SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID), (SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID)
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 21:57:15
query3_2 = '''
    SELECT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1      Sem    1
#[Out]# 2      Sem    1
#[Out]# 3      Sem    1
#[Out]# 4      Sem    1
#[Out]# 5      Sem    1
#[Out]# 6      Sem    1
#[Out]# 7      Sem    1
#[Out]# 8      Sem    1
#[Out]# 9      Sem    1
#[Out]# 10     Sem    1
#[Out]# 11     Sem    1
#[Out]# 12     Sem    1
#[Out]# 13     Sem    1
#[Out]# 14     Sem    1
#[Out]# 15     Sem    1
#[Out]# 16     Sem    1
#[Out]# 17     Sem    1
#[Out]# 18     Sem    1
#[Out]# 19     Sem    1
#[Out]# 20     Sem    1
#[Out]# 21     Sem    1
#[Out]# 22     Sem    1
#[Out]# 23     Sem    1
#[Out]# 24     Sem    1
#[Out]# 25     Sem    1
#[Out]# 26     Sem    1
#[Out]# 27     Sem    1
#[Out]# 28     Sem    1
#[Out]# 29     Sem    1
#[Out]# ..     ...  ...
#[Out]# 946  Amira  176
#[Out]# 947   Elif  178
#[Out]# 948   Elif  178
#[Out]# 949   Elif  178
#[Out]# 950   Elif  178
#[Out]# 951   Juul  179
#[Out]# 952   Juul  179
#[Out]# 953   Juul  179
#[Out]# 954   Juul  179
#[Out]# 955   Juul  179
#[Out]# 956   Juul  179
#[Out]# 957   Juul  179
#[Out]# 958   Juul  179
#[Out]# 959   Juul  179
#[Out]# 960   Juul  179
#[Out]# 961   Juul  179
#[Out]# 962   Juul  179
#[Out]# 963   Juul  179
#[Out]# 964   Juul  179
#[Out]# 965   Juul  179
#[Out]# 966  Merel  180
#[Out]# 967  Merel  180
#[Out]# 968  Merel  180
#[Out]# 969  Merel  180
#[Out]# 970   Liva  181
#[Out]# 971   Liva  181
#[Out]# 972   Liva  181
#[Out]# 973   Liva  181
#[Out]# 974   Liva  181
#[Out]# 975   Liva  181
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Mon, 30 Nov 2020 21:57:25
query3_2 = '''
    SELECT distinct cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 22:20:22
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cust.cID NOT IN (
        SELECT DISTINCT cust.cName, cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND p.sID = s.SID
        AND s.sName = 'Jumbo')
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 22:21:08
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT DISTINCT cust.cName, cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND p.sID = s.SID
        AND s.sName = 'Jumbo')
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 22:21:25
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cName, cID NOT IN (
        SELECT DISTINCT cust.cName, cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND p.sID = s.SID
        AND s.sName = 'Jumbo')
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 22:21:39
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT DISTINCT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND p.sID = s.SID
        AND s.sName = 'Jumbo')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# 5      Milan    6
#[Out]# 6       Bram    7
#[Out]# 7       Liam    8
#[Out]# 8     Thomas    9
#[Out]# 9        Sam   10
#[Out]# 10     Thijs   11
#[Out]# 11      Adam   12
#[Out]# 12     James   13
#[Out]# 13       Max   14
#[Out]# 14      Noud   15
#[Out]# 15    Julian   16
#[Out]# 16       Dex   17
#[Out]# 17      Gijs   20
#[Out]# 18      Mats   22
#[Out]# 19       Jan   23
#[Out]# 20     Mason   25
#[Out]# 21    Jayden   26
#[Out]# 22      Siem   28
#[Out]# 23     Ruben   29
#[Out]# 24      Teun   30
#[Out]# 25   Olivier   31
#[Out]# 26     Vince   32
#[Out]# 27      Sven   33
#[Out]# 28     David   34
#[Out]# 29     Stijn   35
#[Out]# ..       ...  ...
#[Out]# 125    Julie  150
#[Out]# 126     Jill  151
#[Out]# 127     Anne  152
#[Out]# 128    Amber  153
#[Out]# 129   Benthe  154
#[Out]# 130    Linde  155
#[Out]# 131     Luna  156
#[Out]# 132     Puck  157
#[Out]# 133     Rosa  158
#[Out]# 134    Fenne  159
#[Out]# 135     Lara  160
#[Out]# 136    Floor  161
#[Out]# 137    Elena  162
#[Out]# 138     Cato  163
#[Out]# 139      Evy  164
#[Out]# 140  Rosalie  166
#[Out]# 141     Kiki  168
#[Out]# 142     Lily  169
#[Out]# 143     Iris  170
#[Out]# 144    Livia  173
#[Out]# 145     Romy  174
#[Out]# 146      Sam  175
#[Out]# 147    Amira  176
#[Out]# 148    Eline  177
#[Out]# 149     Elif  178
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 22:21:52
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT DISTINCT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND p.sID = s.SID
        AND s.sName = 'Lidl')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1        Finn    3
#[Out]# 2        Daan    4
#[Out]# 3       Milan    6
#[Out]# 4        Liam    8
#[Out]# 5      Thomas    9
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8        Adam   12
#[Out]# 9         Max   14
#[Out]# 10       Noud   15
#[Out]# 11        Dex   17
#[Out]# 12       Hugo   18
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16        Jan   23
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23      Vince   32
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Boaz   36
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 121     Lizzy  149
#[Out]# 122     Julie  150
#[Out]# 123      Jill  151
#[Out]# 124      Anne  152
#[Out]# 125     Amber  153
#[Out]# 126    Benthe  154
#[Out]# 127     Linde  155
#[Out]# 128      Luna  156
#[Out]# 129      Rosa  158
#[Out]# 130      Lara  160
#[Out]# 131     Elena  162
#[Out]# 132       Evy  164
#[Out]# 133   Rosalie  166
#[Out]# 134    Veerle  167
#[Out]# 135      Kiki  168
#[Out]# 136     Tessa  171
#[Out]# 137      Lana  172
#[Out]# 138     Livia  173
#[Out]# 139      Romy  174
#[Out]# 140     Eline  177
#[Out]# 141      Elif  178
#[Out]# 142     Merel  180
#[Out]# 143      Liva  181
#[Out]# 144   Johanna  182
#[Out]# 145     Nikki  183
#[Out]# 146     Wilko  184
#[Out]# 147      Nick  185
#[Out]# 148    Angela  186
#[Out]# 149      Pino  188
#[Out]# 150      Koen  189
#[Out]# 
#[Out]# [151 rows x 2 columns]
# Mon, 30 Nov 2020 22:22:11
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT DISTINCT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND p.sID = s.SID
        AND s.sName = 'Coop')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2        Finn    3
#[Out]# 3       Milan    6
#[Out]# 4        Bram    7
#[Out]# 5      Thomas    9
#[Out]# 6        Adam   12
#[Out]# 7       James   13
#[Out]# 8         Max   14
#[Out]# 9        Noud   15
#[Out]# 10       Lars   19
#[Out]# 11       Mats   22
#[Out]# 12        Jan   23
#[Out]# 13      Mason   25
#[Out]# 14       Teun   30
#[Out]# 15    Olivier   31
#[Out]# 16      Vince   32
#[Out]# 17      David   34
#[Out]# 18       Boaz   36
#[Out]# 19       Guus   37
#[Out]# 20     Floris   38
#[Out]# 21       Jens   40
#[Out]# 22      Quinn   41
#[Out]# 23        Tom   43
#[Out]# 24      Jason   44
#[Out]# 25       Ryan   45
#[Out]# 26      Fedde   46
#[Out]# 27       Xavi   47
#[Out]# 28       Tygo   48
#[Out]# 29        Cas   49
#[Out]# ..        ...  ...
#[Out]# 86         Bo  142
#[Out]# 87      Naomi  143
#[Out]# 88       Fien  145
#[Out]# 89      Norah  146
#[Out]# 90   Isabella  148
#[Out]# 91      Lizzy  149
#[Out]# 92      Julie  150
#[Out]# 93      Amber  153
#[Out]# 94     Benthe  154
#[Out]# 95      Linde  155
#[Out]# 96       Luna  156
#[Out]# 97       Puck  157
#[Out]# 98       Rosa  158
#[Out]# 99      Fenne  159
#[Out]# 100      Lara  160
#[Out]# 101       Evy  164
#[Out]# 102   Rosalie  166
#[Out]# 103    Veerle  167
#[Out]# 104      Kiki  168
#[Out]# 105      Iris  170
#[Out]# 106     Tessa  171
#[Out]# 107     Livia  173
#[Out]# 108      Romy  174
#[Out]# 109       Sam  175
#[Out]# 110   Johanna  182
#[Out]# 111     Nikki  183
#[Out]# 112      Nick  185
#[Out]# 113    Angela  186
#[Out]# 114      Pino  188
#[Out]# 115      Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Mon, 30 Nov 2020 22:22:23
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT DISTINCT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND p.sID = s.SID
        AND s.sName = 'Jumbo')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# 5      Milan    6
#[Out]# 6       Bram    7
#[Out]# 7       Liam    8
#[Out]# 8     Thomas    9
#[Out]# 9        Sam   10
#[Out]# 10     Thijs   11
#[Out]# 11      Adam   12
#[Out]# 12     James   13
#[Out]# 13       Max   14
#[Out]# 14      Noud   15
#[Out]# 15    Julian   16
#[Out]# 16       Dex   17
#[Out]# 17      Gijs   20
#[Out]# 18      Mats   22
#[Out]# 19       Jan   23
#[Out]# 20     Mason   25
#[Out]# 21    Jayden   26
#[Out]# 22      Siem   28
#[Out]# 23     Ruben   29
#[Out]# 24      Teun   30
#[Out]# 25   Olivier   31
#[Out]# 26     Vince   32
#[Out]# 27      Sven   33
#[Out]# 28     David   34
#[Out]# 29     Stijn   35
#[Out]# ..       ...  ...
#[Out]# 125    Julie  150
#[Out]# 126     Jill  151
#[Out]# 127     Anne  152
#[Out]# 128    Amber  153
#[Out]# 129   Benthe  154
#[Out]# 130    Linde  155
#[Out]# 131     Luna  156
#[Out]# 132     Puck  157
#[Out]# 133     Rosa  158
#[Out]# 134    Fenne  159
#[Out]# 135     Lara  160
#[Out]# 136    Floor  161
#[Out]# 137    Elena  162
#[Out]# 138     Cato  163
#[Out]# 139      Evy  164
#[Out]# 140  Rosalie  166
#[Out]# 141     Kiki  168
#[Out]# 142     Lily  169
#[Out]# 143     Iris  170
#[Out]# 144    Livia  173
#[Out]# 145     Romy  174
#[Out]# 146      Sam  175
#[Out]# 147    Amira  176
#[Out]# 148    Eline  177
#[Out]# 149     Elif  178
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 22:22:38
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT DISTINCT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND p.sID = s.SID
        AND s.sName = 'Kumar')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 22:34:47
query3_4 = '''
    SELECT cust.cName, cust.cID
    FROM customer as cust, purchase as p, store as s
    WHERE cust.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = 'Kumar'
    AND cust.cID NOT IN (
        SELECT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND s.sID = p.sID
        AND s.sName != 'Kumar')
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Mon, 30 Nov 2020 22:34:59
query3_4 = '''
    SELECT cust.cName, cust.cID
    FROM customer as cust, purchase as p, store as s
    WHERE cust.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = 'Jumbo'
    AND cust.cID NOT IN (
        SELECT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND s.sID = p.sID
        AND s.sName != 'Jumbo')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Pino  188
#[Out]# 8    Koen  189
#[Out]# 9    Koen  189
# Mon, 30 Nov 2020 22:35:09
query3_4 = '''
    SELECT cust.cName, cust.cID
    FROM customer as cust, purchase as p, store as s
    WHERE cust.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = 'Coop'
    AND cust.cID NOT IN (
        SELECT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND s.sID = p.sID
        AND s.sName != 'Coop')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1        Liam    8
#[Out]# 2         Sam   10
#[Out]# 3       Thijs   11
#[Out]# 4      Jayden   26
#[Out]# 5        Siem   28
#[Out]# 6       Aiden   55
#[Out]# 7       Aiden   55
#[Out]# 8   Alexander   76
#[Out]# 9       Joris   88
#[Out]# 10       Anna   99
#[Out]# 11      Lotte  103
#[Out]# 12        Amy  131
#[Out]# 13      Sofia  135
#[Out]# 14       Jill  151
#[Out]# 15       Jill  151
#[Out]# 16      Wilko  184
# Mon, 30 Nov 2020 22:35:20
query3_4 = '''
    SELECT DISTINCT cust.cName, cust.cID
    FROM customer as cust, purchase as p, store as s
    WHERE cust.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = 'Coop'
    AND cust.cID NOT IN (
        SELECT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND s.sID = p.sID
        AND s.sName != 'Coop')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Mon, 30 Nov 2020 22:35:41
query3_4 = '''
    SELECT DISTINCT cust.cName, cust.cID
    FROM customer as cust, purchase as p, store as s
    WHERE cust.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = 'Jumbo'
    AND cust.cID NOT IN (
        SELECT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND s.sID = p.sID
        AND s.sName != 'Jumbo')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Mon, 30 Nov 2020 22:35:54
query3_4 = '''
    SELECT DISTINCT cust.cName, cust.cID
    FROM customer as cust, purchase as p, store as s
    WHERE cust.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = 'Lidl'
    AND cust.cID NOT IN (
        SELECT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND s.sID = p.sID
        AND s.sName != 'Lidl')
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cName  cID
#[Out]# 0  Mason   25
# Mon, 30 Nov 2020 22:36:28
query3_2 = '''
    SELECT DISTINCT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
        WHERE sList.date = p.date
        AND sList.date LIKE '%2018%'
        AND sList.cID = p.cID
        AND cust.cID = sList.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 22:36:35
query3_3 = '''
    SELECT cName, cID
    FROM customer
    WHERE cID NOT IN (
        SELECT DISTINCT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND p.sID = s.SID
        AND s.sName = 'Kumar')
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 22:36:42
query3_4 = '''
    SELECT DISTINCT cust.cName, cust.cID
    FROM customer as cust, purchase as p, store as s
    WHERE cust.cID = p.cID
    AND s.sID = p.sID
    AND s.sName = 'Kumar'
    AND cust.cID NOT IN (
        SELECT cust.cID
        FROM customer as cust, purchase as p, store as s
        WHERE cust.cID = p.cID
        AND s.sID = p.sID
        AND s.sName != 'Kumar')
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Mon, 30 Nov 2020 22:39:37
query3_2 = '''
    SELECT DISTINCT cust.cName, cust.cID
        FROM customer as cust, shoppinglist as sList, purchase as p
    WHERE sList.date = p.date
    AND sList.date LIKE '%2018%'
    AND sList.cID = p.cID
    AND cust.cID = sList.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 22:39:41
query3_2 = '''
    SELECT DISTINCT cust.cName, cust.cID
    FROM customer as cust, shoppinglist as sList, purchase as p
    WHERE sList.date = p.date
    AND sList.date LIKE '%2018%'
    AND sList.cID = p.cID
    AND cust.cID = sList.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]


# IPython log file


# IPython log file

# Sun, 29 Nov 2020 21:45:33
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file


# IPython log file

# Sun, 29 Nov 2020 21:54:32
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 29 Nov 2020 21:54:50
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x217eb044f80>
# Sun, 29 Nov 2020 21:54:53
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Sun, 29 Nov 2020 21:55:23
query3_2 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, shoppinglist sl, purchase pu
	WHERE cu.cID = sl.cID 
	AND   cu.cID = pu.cID
	AND   sl.date = pu.date
	AND   sl.date like '%2018%'
'''
# Sun, 29 Nov 2020 21:55:25
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 21:55:32
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 21:56:13
query3_2 = '''
SELECT DISTINCT cu.cName, cu.cID, sl.date
	FROM customer cu, shoppinglist sl, purchase pu
	WHERE cu.cID = sl.cID 
	AND   cu.cID = pu.cID
	AND   sl.date = pu.date
	AND   sl.date like '%2018%'
'''
# Sun, 29 Nov 2020 21:56:14
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 21:56:15
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-21
#[Out]# 2    Lucas    2  2018-08-16
#[Out]# 3    Lucas    2  2018-08-17
#[Out]# 4     Finn    3  2018-08-18
#[Out]# ..     ...  ...         ...
#[Out]# 181   Juul  179  2018-08-22
#[Out]# 182  Merel  180  2018-08-26
#[Out]# 183  Merel  180  2018-08-27
#[Out]# 184   Liva  181  2018-08-24
#[Out]# 185   Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Sun, 29 Nov 2020 21:56:34
query3_2 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, shoppinglist sl, purchase pu
	WHERE cu.cID = sl.cID 
	AND   cu.cID = pu.cID
	AND   sl.date = pu.date
	AND   sl.date like '%2018%'
'''
# Sun, 29 Nov 2020 21:56:34
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 21:56:35
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 21:56:39
query3_2 = '''
SELECT DISTINCT cu.cName, cu.cID, sl.date
	FROM customer cu, shoppinglist sl, purchase pu
	WHERE cu.cID = sl.cID 
	AND   cu.cID = pu.cID
	AND   sl.date = pu.date
	AND   sl.date like '%2018%'
'''
# Sun, 29 Nov 2020 21:56:40
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 21:56:43
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-21
#[Out]# 2    Lucas    2  2018-08-16
#[Out]# 3    Lucas    2  2018-08-17
#[Out]# 4     Finn    3  2018-08-18
#[Out]# ..     ...  ...         ...
#[Out]# 181   Juul  179  2018-08-22
#[Out]# 182  Merel  180  2018-08-26
#[Out]# 183  Merel  180  2018-08-27
#[Out]# 184   Liva  181  2018-08-24
#[Out]# 185   Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Sun, 29 Nov 2020 21:57:23
query3_2 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, shoppinglist sl, purchase pu
	WHERE cu.cID = sl.cID 
	AND   cu.cID = pu.cID
	AND   sl.date = pu.date
	AND   sl.date like '%2018%'
'''
# Sun, 29 Nov 2020 21:57:24
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 21:57:24
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 21:57:31
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
	EXCEPT	SELECT cu.cName, cu.cID 
			FROM customer cu2, purchase pu, store st
			WHERE cu2.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'

'''
# Sun, 29 Nov 2020 21:57:33
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 21:57:43
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
	EXCEPT SELECT cu.cName, cu.cID 
			FROM customer cu2, purchase pu, store st
			WHERE cu2.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'

'''
# Sun, 29 Nov 2020 21:57:50
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 21:58:17
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
EXCEPT SELECT cu.cName, cu.cID 
			FROM customer cu2, purchase pu, store st
			WHERE cu2.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'

'''
# Sun, 29 Nov 2020 21:58:17
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 21:58:45
query3_3 = '''
-- All customers except those who made a purchase at Kumar
Select DISTINCT cu.cName, cu.cID
FROM customer cu

EXCEPT
-- All customers who made a purchase at Kumar
SELECT cu.cName, cu.cID
FROM customer cu, purchase pu, store st
WHERE cu.cID = pu.cID
	AND pu.sID = st.sID
    AND st.sName = "Kumar"
    

'''
# Sun, 29 Nov 2020 21:58:46
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 21:59:02
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
FROM customer cu, shoppinglist sh, purchase pu
WHERE cu.cID = sh.cID
	AND sh.cID = pu.cID
	AND sh.date = pu.date
    	AND sh.date like "%2018%"
    

'''
# Sun, 29 Nov 2020 21:59:03
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 21:59:08
pd.read_sql_query(query3_3, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 22:05:34
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
	EXCEPT	SELECT cu.cName, cu.cID 
			FROM customer cu2, purchase pu, store st
			WHERE cu2.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'


'''
# Sun, 29 Nov 2020 22:05:51
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
	EXCEPT	SELECT cu.cName, cu.cID 
			FROM customer cu2, purchase pu, store st
			WHERE cu2.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'Lidl'
'''
# Sun, 29 Nov 2020 22:05:52
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:06:03
pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 22:07:26
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
	EXCEPT	SELECT cu.cName, cu.cID 
			FROM customer cu2, purchase pu, store st
			WHERE cu2.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'Lidl'
'''
# Sun, 29 Nov 2020 22:07:26
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:07:27
pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 22:07:45
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
	EXCEPT	SELECT cu.cName, cu.cID 
			FROM customer cu2, purchase pu, store st
			WHERE cu2.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'Lidl'
'''
# Sun, 29 Nov 2020 22:07:45
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:07:46
pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 22:10:27
query3_3 = '''
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:10:28
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:10:29
pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Sun, 29 Nov 2020 22:10:35
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
'''
# Sun, 29 Nov 2020 22:10:36
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:10:37
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 22:10:49
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
EXCEPT
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:10:49
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:11:04
query3_3 = '''
(SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu)
EXCEPT
(SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar')
'''
# Sun, 29 Nov 2020 22:11:05
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:11:06
pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 22:11:13
query3_3 = '''
(SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu)
--
(SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar')
'''
# Sun, 29 Nov 2020 22:11:14
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:11:15
pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 22:13:03
query3_3 = '''
(SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu)
~~
EXCEPT
~~ 
(SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar')
'''
# Sun, 29 Nov 2020 22:13:04
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:13:05
pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 22:13:28
query3_3 = '''
(SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu)
/
(SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar')
'''
# Sun, 29 Nov 2020 22:13:28
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:13:40
query3_3 = '''
(SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu)
--
(SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar')
'''
# Sun, 29 Nov 2020 22:13:40
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:13:53
query3_3 = '''
(SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu)
EXCEPT
(SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar')
'''
# Sun, 29 Nov 2020 22:13:54
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:14:56
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
EXCEPT
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:14:56
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:15:45
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
    WHERE customer.cName = customer.cName
EXCEPT
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:15:45
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:15:58
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
    WHERE customer.cName = customer.cName
UNION
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:15:58
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:16:13
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
    WHERE customer.cName = customer.cName
EXCEPT
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:16:14
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:16:32
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
    WHERE customer.cName = customer.cName
-
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:16:32
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:16:38
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
    WHERE customer.cName = customer.cName
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:16:39
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:16:57
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
    WHERE customer.cName = customer.cName
MINUS
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:16:58
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:18:37
query3_2 = '''
SELECT customer.cID
    FROM customer
EXCEPT 
SELECT shoppinglist.cID
    FROM shoppinglist
'''
# Sun, 29 Nov 2020 22:18:37
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 22:19:17
pd.read_sql_query(query3_2, conn)
#[Out]#     cID
#[Out]# 0     0
#[Out]# 1     4
#[Out]# 2     6
#[Out]# 3     9
#[Out]# 4    12
#[Out]# 5    14
#[Out]# 6    16
#[Out]# 7    23
#[Out]# 8    32
#[Out]# 9    44
#[Out]# 10   48
#[Out]# 11   49
#[Out]# 12   53
#[Out]# 13   54
#[Out]# 14   56
#[Out]# 15   60
#[Out]# 16   61
#[Out]# 17   65
#[Out]# 18   69
#[Out]# 19   75
#[Out]# 20   78
#[Out]# 21   79
#[Out]# 22   81
#[Out]# 23   89
#[Out]# 24   93
#[Out]# 25   98
#[Out]# 26  105
#[Out]# 27  106
#[Out]# 28  107
#[Out]# 29  114
#[Out]# 30  120
#[Out]# 31  125
#[Out]# 32  126
#[Out]# 33  129
#[Out]# 34  130
#[Out]# 35  132
#[Out]# 36  135
#[Out]# 37  139
#[Out]# 38  140
#[Out]# 39  141
#[Out]# 40  142
#[Out]# 41  143
#[Out]# 42  146
#[Out]# 43  153
#[Out]# 44  155
#[Out]# 45  156
#[Out]# 46  160
#[Out]# 47  173
#[Out]# 48  174
#[Out]# 49  177
#[Out]# 50  182
#[Out]# 51  184
#[Out]# 52  185
#[Out]# 53  186
#[Out]# 54  188
#[Out]# 55  189
#[Out]# 56  190
# Sun, 29 Nov 2020 22:19:36
query3_2 = '''
SELECT customer.cID
    FROM customer
EXCEPT 
SELECT shoppinglist.cID
    FROM shoppinglist
'''
# Sun, 29 Nov 2020 22:19:36
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 22:19:37
pd.read_sql_query(query3_2, conn)
#[Out]#     cID
#[Out]# 0     0
#[Out]# 1     4
#[Out]# 2     6
#[Out]# 3     9
#[Out]# 4    12
#[Out]# 5    14
#[Out]# 6    16
#[Out]# 7    23
#[Out]# 8    32
#[Out]# 9    44
#[Out]# 10   48
#[Out]# 11   49
#[Out]# 12   53
#[Out]# 13   54
#[Out]# 14   56
#[Out]# 15   60
#[Out]# 16   61
#[Out]# 17   65
#[Out]# 18   69
#[Out]# 19   75
#[Out]# 20   78
#[Out]# 21   79
#[Out]# 22   81
#[Out]# 23   89
#[Out]# 24   93
#[Out]# 25   98
#[Out]# 26  105
#[Out]# 27  106
#[Out]# 28  107
#[Out]# 29  114
#[Out]# 30  120
#[Out]# 31  125
#[Out]# 32  126
#[Out]# 33  129
#[Out]# 34  130
#[Out]# 35  132
#[Out]# 36  135
#[Out]# 37  139
#[Out]# 38  140
#[Out]# 39  141
#[Out]# 40  142
#[Out]# 41  143
#[Out]# 42  146
#[Out]# 43  153
#[Out]# 44  155
#[Out]# 45  156
#[Out]# 46  160
#[Out]# 47  173
#[Out]# 48  174
#[Out]# 49  177
#[Out]# 50  182
#[Out]# 51  184
#[Out]# 52  185
#[Out]# 53  186
#[Out]# 54  188
#[Out]# 55  189
#[Out]# 56  190
# Sun, 29 Nov 2020 22:20:08
query3_2 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, shoppinglist sl, purchase pu
	WHERE cu.cID = sl.cID 
	AND   cu.cID = pu.cID
	AND   sl.date = pu.date
	AND   sl.date like '%2018%'
'''
# Sun, 29 Nov 2020 22:20:08
vis.visualize(query3_2, schema)
# Sun, 29 Nov 2020 22:20:09
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 22:20:11
query3_3 = '''
SELECT customer.cID
    FROM customer
EXCEPT 
SELECT shoppinglist.cID
    FROM shoppinglist
'''
# Sun, 29 Nov 2020 22:20:12
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:20:13
pd.read_sql_query(query3_3, conn)
#[Out]#     cID
#[Out]# 0     0
#[Out]# 1     4
#[Out]# 2     6
#[Out]# 3     9
#[Out]# 4    12
#[Out]# 5    14
#[Out]# 6    16
#[Out]# 7    23
#[Out]# 8    32
#[Out]# 9    44
#[Out]# 10   48
#[Out]# 11   49
#[Out]# 12   53
#[Out]# 13   54
#[Out]# 14   56
#[Out]# 15   60
#[Out]# 16   61
#[Out]# 17   65
#[Out]# 18   69
#[Out]# 19   75
#[Out]# 20   78
#[Out]# 21   79
#[Out]# 22   81
#[Out]# 23   89
#[Out]# 24   93
#[Out]# 25   98
#[Out]# 26  105
#[Out]# 27  106
#[Out]# 28  107
#[Out]# 29  114
#[Out]# 30  120
#[Out]# 31  125
#[Out]# 32  126
#[Out]# 33  129
#[Out]# 34  130
#[Out]# 35  132
#[Out]# 36  135
#[Out]# 37  139
#[Out]# 38  140
#[Out]# 39  141
#[Out]# 40  142
#[Out]# 41  143
#[Out]# 42  146
#[Out]# 43  153
#[Out]# 44  155
#[Out]# 45  156
#[Out]# 46  160
#[Out]# 47  173
#[Out]# 48  174
#[Out]# 49  177
#[Out]# 50  182
#[Out]# 51  184
#[Out]# 52  185
#[Out]# 53  186
#[Out]# 54  188
#[Out]# 55  189
#[Out]# 56  190
# Sun, 29 Nov 2020 22:20:42
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
EXCEPT 
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:20:43
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:20:43
pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 185      Vince   32
#[Out]# 186      Wilko  184
#[Out]# 187     Willem   52
#[Out]# 188       Xavi   47
#[Out]# 189       Yara  112
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 22:21:17
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID, pu.sID
	FROM customer cu
EXCEPT 
SELECT cu.cName, cu.cID 
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'kumar'
'''
# Sun, 29 Nov 2020 22:21:17
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:21:18
pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 22:21:48
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID, pu.sID
	FROM customer cu
EXCEPT 
SELECT cu.cName, cu.cID
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'Coop'
'''
# Sun, 29 Nov 2020 22:21:48
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:22:26
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
EXCEPT 
SELECT cu.cName, cu.cID
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'Coop'
'''
# Sun, 29 Nov 2020 22:22:27
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:22:27
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Abel   62
#[Out]# 1      Adam   12
#[Out]# 2     Amber  153
#[Out]# 3    Angela  186
#[Out]# 4    Benthe  154
#[Out]# ..      ...  ...
#[Out]# 111  Veerle  167
#[Out]# 112    Vera  140
#[Out]# 113   Vince   32
#[Out]# 114  Willem   52
#[Out]# 115    Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Sun, 29 Nov 2020 22:22:33
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
EXCEPT 
SELECT cu.cName, cu.cID
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'Jumbo'
'''
# Sun, 29 Nov 2020 22:22:33
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:22:34
pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# ..         ...  ...
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 22:22:39
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
EXCEPT 
SELECT cu.cName, cu.cID
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'Coop'
'''
# Sun, 29 Nov 2020 22:22:40
vis.visualize(query3_3, schema)
# Sun, 29 Nov 2020 22:22:41
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Abel   62
#[Out]# 1      Adam   12
#[Out]# 2     Amber  153
#[Out]# 3    Angela  186
#[Out]# 4    Benthe  154
#[Out]# ..      ...  ...
#[Out]# 111  Veerle  167
#[Out]# 112    Vera  140
#[Out]# 113   Vince   32
#[Out]# 114  Willem   52
#[Out]# 115    Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]

# IPython log file

# Mon, 30 Nov 2020 10:32:24
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 10:32:25
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 10:32:25
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Mon, 30 Nov 2020 10:32:29
query3_2 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, shoppinglist sl, purchase pu
	WHERE cu.cID = sl.cID 
	AND   cu.cID = pu.cID
	AND   sl.date = pu.date
	AND   sl.date like '%2018%'
'''
# Mon, 30 Nov 2020 10:32:30
vis.visualize(query3_2, schema)
# Mon, 30 Nov 2020 10:32:30
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 10:32:31
query3_3 = '''
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu
EXCEPT 
SELECT cu.cName, cu.cID
			FROM customer cu, purchase pu, store st
			WHERE cu.cID = pu.cID
			AND   pu.sID =  st.sID
			AND   st.sName = 'Coop'
'''
# Mon, 30 Nov 2020 10:32:32
vis.visualize(query3_3, schema)
# Mon, 30 Nov 2020 10:32:32
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Abel   62
#[Out]# 1      Adam   12
#[Out]# 2     Amber  153
#[Out]# 3    Angela  186
#[Out]# 4    Benthe  154
#[Out]# ..      ...  ...
#[Out]# 111  Veerle  167
#[Out]# 112    Vera  140
#[Out]# 113   Vince   32
#[Out]# 114  Willem   52
#[Out]# 115    Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Mon, 30 Nov 2020 10:32:34
query3_4 = '''
    PUT YOUR QUERY HERE
'''
# Mon, 30 Nov 2020 10:33:07
query3_4 = '''

SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, purchase pu, store st
	WHERE cu.cID = pu.cID
	AND   pu.sID = st.sID
	AND st.sName = 'Coop'
EXCEPT
SELECT cu.cName, cu.cID
	FROM customer cu, purchase pu
	WHERE cu.cID = pu.cID
	AND   pu.sID = st.sID
	AND st.sName != 'Coop'
'''
# Mon, 30 Nov 2020 10:33:08
vis.visualize(query3_4, schema)
# Mon, 30 Nov 2020 10:33:13
pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 10:33:27
query3_4 = '''

SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, purchase pu, store st
	WHERE cu.cID = pu.cID
	AND   pu.sID = st.sID
	AND st.sName = 'Coop'
EXCEPT
SELECT cu.cName, cu.cID
	FROM customer cu, purchase pu, store st
	WHERE cu.cID = pu.cID
	AND   pu.sID = st.sID
	AND st.sName != 'Coop'
'''
# Mon, 30 Nov 2020 10:33:27
vis.visualize(query3_4, schema)
# Mon, 30 Nov 2020 10:33:28
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0       Aiden   55
#[Out]# 1   Alexander   76
#[Out]# 2         Amy  131
#[Out]# 3        Anna   99
#[Out]# 4      Jayden   26
#[Out]# 5        Jill  151
#[Out]# 6       Joris   88
#[Out]# 7        Liam    8
#[Out]# 8       Lotte  103
#[Out]# 9         Sam   10
#[Out]# 10       Siem   28
#[Out]# 11      Sofia  135
#[Out]# 12      Thijs   11
#[Out]# 13      Wilko  184
# Mon, 30 Nov 2020 10:34:51
query3_4 = '''

SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, purchase pu, store st
	WHERE cu.cID = pu.cID
	AND   pu.sID = st.sID
	AND st.sName = 'Coop'
EXCEPT
SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, purchase pu, store st
	WHERE cu.cID = pu.cID
	AND   pu.sID = st.sID
	AND st.sName != 'Coop'
'''
# Mon, 30 Nov 2020 10:34:52
vis.visualize(query3_4, schema)
# Mon, 30 Nov 2020 10:34:53
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0       Aiden   55
#[Out]# 1   Alexander   76
#[Out]# 2         Amy  131
#[Out]# 3        Anna   99
#[Out]# 4      Jayden   26
#[Out]# 5        Jill  151
#[Out]# 6       Joris   88
#[Out]# 7        Liam    8
#[Out]# 8       Lotte  103
#[Out]# 9         Sam   10
#[Out]# 10       Siem   28
#[Out]# 11      Sofia  135
#[Out]# 12      Thijs   11
#[Out]# 13      Wilko  184
# Mon, 30 Nov 2020 10:34:58
query3_4 = '''

SELECT DISTINCT cu.cName, cu.cID
	FROM customer cu, purchase pu, store st
	WHERE cu.cID = pu.cID
	AND   pu.sID = st.sID
	AND st.sName = 'Coop'
EXCEPT
SELECT cu.cName, cu.cID
	FROM customer cu, purchase pu, store st
	WHERE cu.cID = pu.cID
	AND   pu.sID = st.sID
	AND st.sName != 'Coop'
'''


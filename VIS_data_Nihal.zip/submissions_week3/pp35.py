# IPython log file

# Mon, 30 Nov 2020 16:38:39
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 16:39:02
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 16:39:56
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Mon, 30 Nov 2020 16:44:58
query3_2 = '''
    SELECT DISTINCT c.cID, DISTINCT c.cName
    FROM customer c, shoppinglist sl, purchase p
    WHERE sl.date = p.date AND c.cID = sl.cID AND sl.date LIKE '%2018%'
'''
# Mon, 30 Nov 2020 16:44:58
vis.visualize(query3_2, schema)
# Mon, 30 Nov 2020 16:45:06
pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 16:45:34
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, shoppinglist sl, purchase p
    WHERE sl.date = p.date AND c.cID = sl.cID AND sl.date LIKE '%2018%'
'''
# Mon, 30 Nov 2020 16:45:35
vis.visualize(query3_2, schema)
# Mon, 30 Nov 2020 16:45:36
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 128  178   Elif
#[Out]# 129  179   Juul
#[Out]# 130  180  Merel
#[Out]# 131  181   Liva
#[Out]# 132  183  Nikki
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Mon, 30 Nov 2020 16:46:37
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, shoppinglist sl, purchase p
    WHERE sl.date = p.date AND c.cID = sl.cID AND c.cID = p.cID AND p.cID = sl.cID AND sl.date LIKE '%2018%'
'''
# Mon, 30 Nov 2020 16:46:37
vis.visualize(query3_2, schema)
# Mon, 30 Nov 2020 16:46:37
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 16:50:42
query3_3 = '''
    SELECT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID NOT IN (
    SELECT p1.cID
    FROM store s1, purchase p1
    WHERE s1.sID = p1.sID AND s1.sID LIKE '%Jumbo%');
'''
# Mon, 30 Nov 2020 16:50:43
vis.visualize(query3_3, schema)
# Mon, 30 Nov 2020 16:50:43
pd.read_sql_query(query3_3, conn)
#[Out]#          cID   cName
#[Out]# 0          0    Noah
#[Out]# 1          0    Noah
#[Out]# 2          0    Noah
#[Out]# 3          0    Noah
#[Out]# 4          0    Noah
#[Out]# ...      ...     ...
#[Out]# 6189435  190  Kostas
#[Out]# 6189436  190  Kostas
#[Out]# 6189437  190  Kostas
#[Out]# 6189438  190  Kostas
#[Out]# 6189439  190  Kostas
#[Out]# 
#[Out]# [6189440 rows x 2 columns]
# Mon, 30 Nov 2020 16:51:07
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID NOT IN (
    SELECT p1.cID
    FROM store s1, purchase p1
    WHERE s1.sID = p1.sID AND s1.sID LIKE '%Jumbo%');
'''
# Mon, 30 Nov 2020 16:51:08
vis.visualize(query3_3, schema)
# Mon, 30 Nov 2020 16:51:08
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 16:53:06
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID NOT IN (
    SELECT p1.cID
    FROM store s1, purchase p1
    WHERE s1.sID = p1.sID AND s1.sName LIKE '%Jumbo%');
'''
# Mon, 30 Nov 2020 16:53:06
vis.visualize(query3_3, schema)
# Mon, 30 Nov 2020 16:53:08
pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# ..   ...      ...
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 16:54:24
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE c.cID NOT IN (
    SELECT p1.cID
    FROM store s1, purchase p1
    WHERE s1.sID = p1.sID AND s1.sName LIKE '%Kumar%');
'''
# Mon, 30 Nov 2020 16:54:24
vis.visualize(query3_3, schema)
# Mon, 30 Nov 2020 16:54:24
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 16:56:24
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE s.sName LIKE '%Lidl%' AND c.cID NOT IN (
    SELECT p1.cID
    FROM store s1, purchase p1
    WHERE s1.sID = p1.sID AND s1.sName NOT LIKE '%Lidl%');
'''
# Mon, 30 Nov 2020 16:56:24
vis.visualize(query3_4, schema)
# Mon, 30 Nov 2020 16:56:24
pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    25     Mason
#[Out]# 6    32     Vince
#[Out]# 7    36      Boaz
#[Out]# 8    46     Fedde
#[Out]# 9    48      Tygo
#[Out]# 10   49       Cas
#[Out]# 11   50       Pim
#[Out]# 12   53       Job
#[Out]# 13   54       Jax
#[Out]# 14   56    Tobias
#[Out]# 15   61    Morris
#[Out]# 16   62      Abel
#[Out]# 17   65    Pepijn
#[Out]# 18   73      Owen
#[Out]# 19   74    Samuel
#[Out]# 20   79    Joshua
#[Out]# 21   81     Simon
#[Out]# 22   83     Melle
#[Out]# 23   87     Jelle
#[Out]# 24   89  Johannes
#[Out]# 25   93     Oscar
#[Out]# 26   98     Julia
#[Out]# 27  101       Eva
#[Out]# 28  102       Evi
#[Out]# 29  105      Nora
#[Out]# 30  106     Fleur
#[Out]# 31  107    Olivia
#[Out]# 32  114      Maud
#[Out]# 33  115      Nova
#[Out]# 34  117      Roos
#[Out]# 35  120     Sarah
#[Out]# 36  121       Isa
#[Out]# 37  125       Noa
#[Out]# 38  130     Sanne
#[Out]# 39  132    Hannah
#[Out]# 40  138     Maria
#[Out]# 41  140      Vera
#[Out]# 42  141       Mia
#[Out]# 43  142        Bo
#[Out]# 44  143     Naomi
#[Out]# 45  146     Norah
#[Out]# 46  148  Isabella
#[Out]# 47  150     Julie
#[Out]# 48  153     Amber
#[Out]# 49  154    Benthe
#[Out]# 50  155     Linde
#[Out]# 51  156      Luna
#[Out]# 52  158      Rosa
#[Out]# 53  160      Lara
#[Out]# 54  164       Evy
#[Out]# 55  166   Rosalie
#[Out]# 56  173     Livia
#[Out]# 57  174      Romy
#[Out]# 58  183     Nikki
# Mon, 30 Nov 2020 16:57:05
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE s.sName LIKE '%Lidl%' AND p.cID = c.cID AND c.cID NOT IN (
    SELECT p1.cID
    FROM store s1, purchase p1
    WHERE s1.sID = p1.sID AND s1.sName NOT LIKE '%Lidl%');
'''
# Mon, 30 Nov 2020 16:57:05
vis.visualize(query3_4, schema)
# Mon, 30 Nov 2020 16:57:06
pd.read_sql_query(query3_4, conn)
#[Out]#    cID  cName
#[Out]# 0   25  Mason
# Mon, 30 Nov 2020 16:57:36
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE s.sName LIKE '%Jumbo%' AND p.cID = c.cID AND c.cID NOT IN (
    SELECT p1.cID
    FROM store s1, purchase p1
    WHERE s1.sID = p1.sID AND s1.sName NOT LIKE '%Jumbo%');
'''
# Mon, 30 Nov 2020 16:57:36
vis.visualize(query3_4, schema)
# Mon, 30 Nov 2020 16:57:36
pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Mon, 30 Nov 2020 16:58:36
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer c, store s, purchase p
    WHERE s.sName LIKE '%Kumar%' AND p.cID = c.cID AND c.cID NOT IN (
    SELECT p1.cID
    FROM store s1, purchase p1
    WHERE s1.sID = p1.sID AND s1.sName NOT LIKE '%Kumar%');
'''
# Mon, 30 Nov 2020 16:58:37
vis.visualize(query3_4, schema)
# Mon, 30 Nov 2020 16:58:37
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []


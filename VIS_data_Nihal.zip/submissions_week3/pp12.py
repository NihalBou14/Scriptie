# IPython log file

# Tue, 01 Dec 2020 21:10:07
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 21:10:10
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7f9af5158b20>
# Tue, 01 Dec 2020 21:12:52
query3_2 = '''
    SELECT DISTINCT c.cId, c.cName, FROM customer c, shoppinglist s, purchase p WHERE s.date LIKE "2018%" AND s.date = p.date AND c.cID=s.cID AND c.cID=p.cID;
'''

pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 21:15:17
query3_2 = '''
    SELECT DISTINCT c.cId, c.cName FROM customer c, shoppinglist s, purchase p WHERE s.date LIKE "2018%" AND s.date = p.date AND c.cID=s.cID AND c.cID=p.cID;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 21:16:44
query3_3 = '''
    SELECT * FROM customer c, purchase p, store s WHERE c.cID=p.cID AND p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName            street     city  tID  cID  sID  pID        date  \
#[Out]# 0      0    Noah         Koestraat  Utrecht    0    0    3   10  2018-08-22   
#[Out]# 1      1     Sem  Rozemarijnstraat    Breda    1    1   23   14  2018-08-20   
#[Out]# 2      1     Sem  Rozemarijnstraat    Breda    2    1    3   16  2018-08-20   
#[Out]# 3      1     Sem  Rozemarijnstraat    Breda    3    1   17    9  2018-08-20   
#[Out]# 4      1     Sem  Rozemarijnstraat    Breda    4    1   32   25  2018-08-20   
#[Out]# ..   ...     ...               ...      ...  ...  ...  ...  ...         ...   
#[Out]# 504  190  Kostas          Eindeweg  Utrecht  843  190   59   17  2018-08-26   
#[Out]# 505  190  Kostas          Eindeweg  Utrecht  844  190   60    5  2018-08-27   
#[Out]# 506  190  Kostas          Eindeweg  Utrecht  845  190   61   19  2018-08-23   
#[Out]# 507  190  Kostas          Eindeweg  Utrecht  846  190   62    9  2018-08-16   
#[Out]# 508  190  Kostas          Eindeweg  Utrecht  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#      quantity  price  sID        sName            street       city  
#[Out]# 0           1   0.45    3       Sligro    Stadhoudersweg  Rotterdam  
#[Out]# 1           2   4.65   23         Dirk     Stationsplein      Breda  
#[Out]# 2           3   1.60    3       Sligro    Stadhoudersweg  Rotterdam  
#[Out]# 3           2   1.25   17    Hoogvliet        Kerkstraat  Eindhoven  
#[Out]# 4           4   3.95   32  Albert Hein        Hoogstraat    Utrecht  
#[Out]# ..        ...    ...  ...          ...               ...        ...  
#[Out]# 504         2   3.80   59        Jumbo  Rozemarijnstraat      Breda  
#[Out]# 505         6   4.35   60         Lidl      Pannekoekweg      Breda  
#[Out]# 506         5   2.85   61         Lidl      Pannekoekweg      Breda  
#[Out]# 507         2   3.15   62        Jumbo     Poffertjesweg  Eindhoven  
#[Out]# 508         1   3.30   63        Jumbo     Stationstraat        Oss  
#[Out]# 
#[Out]# [509 rows x 15 columns]
# Tue, 01 Dec 2020 21:17:17
query3_3 = '''
    SELECT * FROM customer c, purchase p, store s WHERE c.cID=p.cID AND p.sID = s.sID AND NOT s.sName='Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName            street     city  tID  cID  sID  pID        date  \
#[Out]# 0      0    Noah         Koestraat  Utrecht    0    0    3   10  2018-08-22   
#[Out]# 1      1     Sem  Rozemarijnstraat    Breda    1    1   23   14  2018-08-20   
#[Out]# 2      1     Sem  Rozemarijnstraat    Breda    2    1    3   16  2018-08-20   
#[Out]# 3      1     Sem  Rozemarijnstraat    Breda    3    1   17    9  2018-08-20   
#[Out]# 4      1     Sem  Rozemarijnstraat    Breda    4    1   32   25  2018-08-20   
#[Out]# ..   ...     ...               ...      ...  ...  ...  ...  ...         ...   
#[Out]# 504  190  Kostas          Eindeweg  Utrecht  843  190   59   17  2018-08-26   
#[Out]# 505  190  Kostas          Eindeweg  Utrecht  844  190   60    5  2018-08-27   
#[Out]# 506  190  Kostas          Eindeweg  Utrecht  845  190   61   19  2018-08-23   
#[Out]# 507  190  Kostas          Eindeweg  Utrecht  846  190   62    9  2018-08-16   
#[Out]# 508  190  Kostas          Eindeweg  Utrecht  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#      quantity  price  sID        sName            street       city  
#[Out]# 0           1   0.45    3       Sligro    Stadhoudersweg  Rotterdam  
#[Out]# 1           2   4.65   23         Dirk     Stationsplein      Breda  
#[Out]# 2           3   1.60    3       Sligro    Stadhoudersweg  Rotterdam  
#[Out]# 3           2   1.25   17    Hoogvliet        Kerkstraat  Eindhoven  
#[Out]# 4           4   3.95   32  Albert Hein        Hoogstraat    Utrecht  
#[Out]# ..        ...    ...  ...          ...               ...        ...  
#[Out]# 504         2   3.80   59        Jumbo  Rozemarijnstraat      Breda  
#[Out]# 505         6   4.35   60         Lidl      Pannekoekweg      Breda  
#[Out]# 506         5   2.85   61         Lidl      Pannekoekweg      Breda  
#[Out]# 507         2   3.15   62        Jumbo     Poffertjesweg  Eindhoven  
#[Out]# 508         1   3.30   63        Jumbo     Stationstraat        Oss  
#[Out]# 
#[Out]# [509 rows x 15 columns]
# Tue, 01 Dec 2020 21:18:09
query3_3 = '''
    SELECT DISTINCT c.cID FROM customer c, purchase p, store s WHERE p.sID = s.sID AND NOT s.sName='Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 21:18:57
query3_4 = '''
    SELECT DISTINCT c.cID FROM customer c, purchase p 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 21:19:05
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE p.sID = s.sID AND NOT s.sName='Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 21:19:18
query3_3 = '''
    SELECT DISTINCT c.cID, DISTINCT c.cName FROM customer c, purchase p, store s WHERE p.sID = s.sID AND NOT s.sName='Kumar'
'''

pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 21:19:22
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE p.sID = s.sID AND NOT s.sName='Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 21:19:33
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 21:20:41
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p,store s WHERE c.cID = p.cID AND p.sID=s.sID AND s.sName='Kumar'
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 01 Dec 2020 21:20:45
query3_4 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p,store s WHERE c.cID = p.cID AND p.sID=s.sID AND s.sName='Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    21  Benjamin
#[Out]# 4    24      Luca
#[Out]# 5    27       Tim
#[Out]# 6    37      Guus
#[Out]# 7    38    Floris
#[Out]# 8    40      Jens
#[Out]# 9    47      Xavi
#[Out]# 10   52    Willem
#[Out]# 11   59      Joep
#[Out]# 12   63      Senn
#[Out]# 13   66   Mohamed
#[Out]# 14   68     Boris
#[Out]# 15   72      Dani
#[Out]# 16   78      Mick
#[Out]# 17   85    Pieter
#[Out]# 18   86      Stef
#[Out]# 19  104       Liv
#[Out]# 20  109      Lynn
#[Out]# 21  112      Yara
#[Out]# 22  122      Elin
#[Out]# 23  126      Lina
#[Out]# 24  136     Femke
#[Out]# 25  165     Hanna
#[Out]# 26  167    Veerle
#[Out]# 27  171     Tessa
#[Out]# 28  172      Lana
#[Out]# 29  180     Merel
#[Out]# 30  185      Nick
#[Out]# 31  186    Angela
#[Out]# 32  188      Pino
#[Out]# 33  189      Koen
#[Out]# 34  190    Kostas
# Tue, 01 Dec 2020 21:22:02
query3_4 = '''
    SELECT DISTINCT p.cID FROM purchase p, store s where p.sID = s.sID  
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 127  185
#[Out]# 128  186
#[Out]# 129  188
#[Out]# 130  189
#[Out]# 131  190
#[Out]# 
#[Out]# [132 rows x 1 columns]
# Tue, 01 Dec 2020 21:22:19
query3_4 = '''
    SELECT DISTINCT p.cID FROM purchase p, store s where p.sID = s.sID and s.sName = 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     4
#[Out]# 1    18
#[Out]# 2    19
#[Out]# 3    21
#[Out]# 4    24
#[Out]# 5    27
#[Out]# 6    37
#[Out]# 7    38
#[Out]# 8    40
#[Out]# 9    47
#[Out]# 10   52
#[Out]# 11   59
#[Out]# 12   63
#[Out]# 13   66
#[Out]# 14   68
#[Out]# 15   72
#[Out]# 16   78
#[Out]# 17   85
#[Out]# 18   86
#[Out]# 19  104
#[Out]# 20  109
#[Out]# 21  112
#[Out]# 22  122
#[Out]# 23  126
#[Out]# 24  136
#[Out]# 25  165
#[Out]# 26  167
#[Out]# 27  171
#[Out]# 28  172
#[Out]# 29  180
#[Out]# 30  185
#[Out]# 31  186
#[Out]# 32  188
#[Out]# 33  189
#[Out]# 34  190
# Tue, 01 Dec 2020 21:22:59
query3_4 = '''
    SELECT DISTINCT * FROM purchase p, store s where p.sID = s.sID and s.sName = 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price  sID  sName  \
#[Out]# 0    17    4   10   27  2018-08-24         9   9.05   10  Jumbo   
#[Out]# 1    61   18    2    9  2018-08-16         6   1.70    2  Jumbo   
#[Out]# 2    63   19   59    0  2018-08-17         1   3.90   59  Jumbo   
#[Out]# 3    65   19    2   15  2018-08-18         1   1.05    2  Jumbo   
#[Out]# 4    71   21    2   23  2018-08-16         3   2.40    2  Jumbo   
#[Out]# 5    83   24   59   13  2018-08-21         5   4.00   59  Jumbo   
#[Out]# 6    87   27   59   14  2018-08-26         4   3.50   59  Jumbo   
#[Out]# 7   115   37   10   13  2018-08-15         4   2.90   10  Jumbo   
#[Out]# 8   116   38   37   25  2018-08-18         5   4.70   37  Jumbo   
#[Out]# 9   126   40   56   19  2018-08-17         5   2.25   56  Jumbo   
#[Out]# 10  148   47   20   16  2018-08-17         7   2.10   20  Jumbo   
#[Out]# 11  159   52    2    5  2018-08-25         6   0.50    2  Jumbo   
#[Out]# 12  176   59   59   21  2018-08-15         6   2.20   59  Jumbo   
#[Out]# 13  182   63   20   27  2018-08-17         8   6.85   20  Jumbo   
#[Out]# 14  186   66   10   24  2018-08-16         5   3.65   10  Jumbo   
#[Out]# 15  194   68   20    7  2018-08-27         3   1.65   20  Jumbo   
#[Out]# 16  203   72   10   16  2018-08-22         7   1.50   10  Jumbo   
#[Out]# 17  215   78   56   13  2018-08-18         5   4.15   56  Jumbo   
#[Out]# 18  230   85   37    2  2018-08-19         2   2.25   37  Jumbo   
#[Out]# 19  234   86   20   28  2018-08-17         6   8.60   20  Jumbo   
#[Out]# 20  278  104    2   22  2018-08-22         2   2.00    2  Jumbo   
#[Out]# 21  287  109   56   26  2018-08-21         2   3.25   56  Jumbo   
#[Out]# 22  296  112   20    3  2018-08-25         4   1.40   20  Jumbo   
#[Out]# 23  316  122   56    7  2018-08-22         4   2.35   56  Jumbo   
#[Out]# 24  334  126   56   15  2018-08-22         1   1.00   56  Jumbo   
#[Out]# 25  350  136   37   28  2018-08-24         5   7.75   37  Jumbo   
#[Out]# 26  410  165   56    1  2018-08-23         3   4.40   56  Jumbo   
#[Out]# 27  420  167   56    7  2018-08-20         1   2.10   56  Jumbo   
#[Out]# 28  441  171   56    3  2018-08-20         1   1.50   56  Jumbo   
#[Out]# 29  443  172   59    4  2018-08-27         4   0.90   59  Jumbo   
#[Out]# 30  468  180   56   10  2018-08-27         3   0.60   56  Jumbo   
#[Out]# 31  778  185   62   29  2018-08-20         1   1.00   62  Jumbo   
#[Out]# 32  779  186   62   29  2018-08-21         5   1.00   62  Jumbo   
#[Out]# 33  780  188   62   30  2018-08-20         1   1.00   62  Jumbo   
#[Out]# 34  781  188   62   30  2018-09-20         1   1.00   62  Jumbo   
#[Out]# 35  782  189   63    7  2018-08-25         5   1.25   63  Jumbo   
#[Out]# 36  783  189   20   19  2018-08-26         3   2.50   20  Jumbo   
#[Out]# 37  786  190    2   19  2018-08-19         4   1.40    2  Jumbo   
#[Out]# 38  794  190   10   19  2018-08-22         7   0.90   10  Jumbo   
#[Out]# 39  804  190   20   20  2018-08-17         7   0.50   20  Jumbo   
#[Out]# 40  821  190   37   28  2018-08-15         4   0.65   37  Jumbo   
#[Out]# 41  840  190   56   11  2018-08-15         4   1.60   56  Jumbo   
#[Out]# 42  843  190   59   17  2018-08-26         2   3.80   59  Jumbo   
#[Out]# 43  846  190   62    9  2018-08-16         2   3.15   62  Jumbo   
#[Out]# 44  847  190   63   18  2018-08-21         1   3.30   63  Jumbo   
#[Out]# 
#[Out]#               street       city  
#[Out]# 0         Bergselaan  Rotterdam  
#[Out]# 1     Stadhoudersweg  Rotterdam  
#[Out]# 2   Rozemarijnstraat      Breda  
#[Out]# 3     Stadhoudersweg  Rotterdam  
#[Out]# 4     Stadhoudersweg  Rotterdam  
#[Out]# 5   Rozemarijnstraat      Breda  
#[Out]# 6   Rozemarijnstraat      Breda  
#[Out]# 7         Bergselaan  Rotterdam  
#[Out]# 8           Molenweg  Eindhoven  
#[Out]# 9        Parallelweg  Eindhoven  
#[Out]# 10      Kasteeldreef    Tilburg  
#[Out]# 11    Stadhoudersweg  Rotterdam  
#[Out]# 12  Rozemarijnstraat      Breda  
#[Out]# 13      Kasteeldreef    Tilburg  
#[Out]# 14        Bergselaan  Rotterdam  
#[Out]# 15      Kasteeldreef    Tilburg  
#[Out]# 16        Bergselaan  Rotterdam  
#[Out]# 17       Parallelweg  Eindhoven  
#[Out]# 18          Molenweg  Eindhoven  
#[Out]# 19      Kasteeldreef    Tilburg  
#[Out]# 20    Stadhoudersweg  Rotterdam  
#[Out]# 21       Parallelweg  Eindhoven  
#[Out]# 22      Kasteeldreef    Tilburg  
#[Out]# 23       Parallelweg  Eindhoven  
#[Out]# 24       Parallelweg  Eindhoven  
#[Out]# 25          Molenweg  Eindhoven  
#[Out]# 26       Parallelweg  Eindhoven  
#[Out]# 27       Parallelweg  Eindhoven  
#[Out]# 28       Parallelweg  Eindhoven  
#[Out]# 29  Rozemarijnstraat      Breda  
#[Out]# 30       Parallelweg  Eindhoven  
#[Out]# 31     Poffertjesweg  Eindhoven  
#[Out]# 32     Poffertjesweg  Eindhoven  
#[Out]# 33     Poffertjesweg  Eindhoven  
#[Out]# 34     Poffertjesweg  Eindhoven  
#[Out]# 35     Stationstraat        Oss  
#[Out]# 36      Kasteeldreef    Tilburg  
#[Out]# 37    Stadhoudersweg  Rotterdam  
#[Out]# 38        Bergselaan  Rotterdam  
#[Out]# 39      Kasteeldreef    Tilburg  
#[Out]# 40          Molenweg  Eindhoven  
#[Out]# 41       Parallelweg  Eindhoven  
#[Out]# 42  Rozemarijnstraat      Breda  
#[Out]# 43     Poffertjesweg  Eindhoven  
#[Out]# 44     Stationstraat        Oss  
# Tue, 01 Dec 2020 21:23:20
query3_4 = '''
    SELECT DISTINCT cID FROM purchase p, store s where p.sID = s.sID and s.sName = 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     4
#[Out]# 1    18
#[Out]# 2    19
#[Out]# 3    21
#[Out]# 4    24
#[Out]# 5    27
#[Out]# 6    37
#[Out]# 7    38
#[Out]# 8    40
#[Out]# 9    47
#[Out]# 10   52
#[Out]# 11   59
#[Out]# 12   63
#[Out]# 13   66
#[Out]# 14   68
#[Out]# 15   72
#[Out]# 16   78
#[Out]# 17   85
#[Out]# 18   86
#[Out]# 19  104
#[Out]# 20  109
#[Out]# 21  112
#[Out]# 22  122
#[Out]# 23  126
#[Out]# 24  136
#[Out]# 25  165
#[Out]# 26  167
#[Out]# 27  171
#[Out]# 28  172
#[Out]# 29  180
#[Out]# 30  185
#[Out]# 31  186
#[Out]# 32  188
#[Out]# 33  189
#[Out]# 34  190
# Tue, 01 Dec 2020 21:26:47
query3_4 = '''
    SELECT DISTINCT p.cID 
    FROM purchase p, store s 
    where p.sID = s.sID 
    and s.sName = 'Jumbo'
    and p.cID not in (SELECT cID 
                        from purchase d , 
                        store z where z.sSname!="Jumbo")
'''

pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 21:26:59
query3_4 = '''
    SELECT DISTINCT p.cID 
    FROM purchase p, store s 
    where p.sID = s.sID 
    and s.sName = 'Jumbo'
    and p.cID not in (SELECT cID 
                        from purchase d , 
                        store z where z.sName!="Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 21:28:06
query3_4 = '''
    SELECT DISTINCT p.cID 
    FROM purchase p, store s 
    where p.sID = s.sID 
    and s.sName = 'Jumbo'
    and p.cID not in (SELECT cID 
                        from purchase d , 
                        store z where d.sID=z.sID and z.sName!="Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID
#[Out]# 0   47
#[Out]# 1   63
#[Out]# 2  104
#[Out]# 3  136
#[Out]# 4  185
#[Out]# 5  186
#[Out]# 6  188
#[Out]# 7  189
# Tue, 01 Dec 2020 21:28:48
query3_4 = '''
    SELECT DISTINCT c.cID , c.cName
    FROM purchase p, store s,customer c
    where p.sID = s.sID 
    and p.cID = c.cID
    and s.sName = 'Jumbo'
    and p.cID not in (SELECT cID 
                        from purchase d , 
                        store z where d.sID=z.sID and z.sName!="Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen
# Tue, 01 Dec 2020 23:39:04
query3_4 = '''
    SELECT DISTINCT c.cID , c.cName
    FROM purchase p, store s,customer c
    where p.sID = s.sID 
    and p.cID = c.cID
    and s.sName = 'Jumbo'
    and p.cID not in (SELECT cID 
                        from purchase d , 
                        store z where d.sID=z.sID and z.sName!="Jumbo")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID   cName
#[Out]# 0   47    Xavi
#[Out]# 1   63    Senn
#[Out]# 2  104     Liv
#[Out]# 3  136   Femke
#[Out]# 4  185    Nick
#[Out]# 5  186  Angela
#[Out]# 6  188    Pino
#[Out]# 7  189    Koen

# IPython log file

# Sun, 29 Nov 2020 12:56:28
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Sun, 29 Nov 2020 12:56:53
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 29 Nov 2020 12:56:57
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x108955180>
# Sun, 29 Nov 2020 12:57:32
query3_2 = '''
    select *
    from customer
    limit(10);
'''

pd.read_sql_query(query3_2, conn)
#[Out]#    cID   cName            street       city
#[Out]# 0    0    Noah         Koestraat    Utrecht
#[Out]# 1    1     Sem  Rozemarijnstraat      Breda
#[Out]# 2    2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 3    3    Finn     Stationsplein      Breda
#[Out]# 4    4    Daan      Kalverstraat  Amsterdam
#[Out]# 5    5    Levi    Gasthuisstraat    Utrecht
#[Out]# 6    6   Milan       Parallelweg    Utrecht
#[Out]# 7    7    Bram      Schoolstraat  Eindhoven
#[Out]# 8    8    Liam     Rijsbergseweg      Breda
#[Out]# 9    9  Thomas       Parallelweg  Amsterdam
# Sun, 29 Nov 2020 12:58:23
query3_2 = '''
    select date
    from purchase
    limit(10);
'''

pd.read_sql_query(query3_2, conn)
#[Out]#          date
#[Out]# 0  2018-08-22
#[Out]# 1  2018-08-20
#[Out]# 2  2018-08-20
#[Out]# 3  2018-08-20
#[Out]# 4  2018-08-20
#[Out]# 5  2018-08-20
#[Out]# 6  2018-08-21
#[Out]# 7  2018-08-21
#[Out]# 8  2018-08-16
#[Out]# 9  2018-08-17
# Sun, 29 Nov 2020 12:58:46
query3_2 = '''
    select date
    from purchase
    where date not like '&'
    limit(10);
'''

pd.read_sql_query(query3_2, conn)
#[Out]#          date
#[Out]# 0  2018-08-22
#[Out]# 1  2018-08-20
#[Out]# 2  2018-08-20
#[Out]# 3  2018-08-20
#[Out]# 4  2018-08-20
#[Out]# 5  2018-08-20
#[Out]# 6  2018-08-21
#[Out]# 7  2018-08-21
#[Out]# 8  2018-08-16
#[Out]# 9  2018-08-17
# Sun, 29 Nov 2020 12:59:02
query3_2 = '''
    select date
    from purchase
    where date not like '%2018%'
    limit(10);
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [date]
#[Out]# Index: []
# Sun, 29 Nov 2020 12:59:13
query3_2 = '''
    select date
    from purchase
    where date like '%2018%'
    limit(10);
'''

pd.read_sql_query(query3_2, conn)
#[Out]#          date
#[Out]# 0  2018-08-22
#[Out]# 1  2018-08-20
#[Out]# 2  2018-08-20
#[Out]# 3  2018-08-20
#[Out]# 4  2018-08-20
#[Out]# 5  2018-08-20
#[Out]# 6  2018-08-21
#[Out]# 7  2018-08-21
#[Out]# 8  2018-08-16
#[Out]# 9  2018-08-17
# Sun, 29 Nov 2020 13:02:15
query3_2 = '''
    select c.cName, c.cId
    from customer c
    limit(10)
'''

pd.read_sql_query(query3_2, conn)
#[Out]#     cName  cID
#[Out]# 0    Noah    0
#[Out]# 1     Sem    1
#[Out]# 2   Lucas    2
#[Out]# 3    Finn    3
#[Out]# 4    Daan    4
#[Out]# 5    Levi    5
#[Out]# 6   Milan    6
#[Out]# 7    Bram    7
#[Out]# 8    Liam    8
#[Out]# 9  Thomas    9
# Sun, 29 Nov 2020 13:04:20
query3_2 = '''
    select c.cName, c.cId
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    limit(25)
'''

pd.read_sql_query(query3_2, conn)
#[Out]#    cName  cID
#[Out]# 0    Sem    1
#[Out]# 1    Sem    1
#[Out]# 2    Sem    1
#[Out]# 3    Sem    1
#[Out]# 4    Sem    1
#[Out]# 5    Sem    1
#[Out]# 6    Sem    1
#[Out]# 7    Sem    1
#[Out]# 8    Sem    1
#[Out]# 9    Sem    1
#[Out]# 10   Sem    1
#[Out]# 11   Sem    1
#[Out]# 12   Sem    1
#[Out]# 13   Sem    1
#[Out]# 14   Sem    1
#[Out]# 15   Sem    1
#[Out]# 16   Sem    1
#[Out]# 17   Sem    1
#[Out]# 18   Sem    1
#[Out]# 19   Sem    1
#[Out]# 20   Sem    1
#[Out]# 21   Sem    1
#[Out]# 22   Sem    1
#[Out]# 23   Sem    1
#[Out]# 24   Sem    1
# Sun, 29 Nov 2020 13:04:46
query3_2 = '''
    select *
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    limit(25)
'''

pd.read_sql_query(query3_2, conn)
#[Out]#     cID cName            street   city  cID  pID  quantity        date  tID  \
#[Out]# 0     1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    1   
#[Out]# 1     1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    1   
#[Out]# 2     1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    1   
#[Out]# 3     1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    1   
#[Out]# 4     1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    1   
#[Out]# 5     1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    1   
#[Out]# 6     1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    1   
#[Out]# 7     1   Sem  Rozemarijnstraat  Breda    1   27         6  2018-08-21    1   
#[Out]# 8     1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    2   
#[Out]# 9     1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    2   
#[Out]# 10    1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    2   
#[Out]# 11    1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    2   
#[Out]# 12    1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    2   
#[Out]# 13    1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    2   
#[Out]# 14    1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    2   
#[Out]# 15    1   Sem  Rozemarijnstraat  Breda    1   27         6  2018-08-21    2   
#[Out]# 16    1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    3   
#[Out]# 17    1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    3   
#[Out]# 18    1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    3   
#[Out]# 19    1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    3   
#[Out]# 20    1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    3   
#[Out]# 21    1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    3   
#[Out]# 22    1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    3   
#[Out]# 23    1   Sem  Rozemarijnstraat  Breda    1   27         6  2018-08-21    3   
#[Out]# 24    1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    4   
#[Out]# 
#[Out]#     cID  sID  pID        date  quantity  price  
#[Out]# 0     1   23   14  2018-08-20         2   4.65  
#[Out]# 1     1   23   14  2018-08-20         2   4.65  
#[Out]# 2     1   23   14  2018-08-20         2   4.65  
#[Out]# 3     1   23   14  2018-08-20         2   4.65  
#[Out]# 4     1   23   14  2018-08-20         2   4.65  
#[Out]# 5     1   23   14  2018-08-20         2   4.65  
#[Out]# 6     1   23   14  2018-08-20         2   4.65  
#[Out]# 7     1   23   14  2018-08-20         2   4.65  
#[Out]# 8     1    3   16  2018-08-20         3   1.60  
#[Out]# 9     1    3   16  2018-08-20         3   1.60  
#[Out]# 10    1    3   16  2018-08-20         3   1.60  
#[Out]# 11    1    3   16  2018-08-20         3   1.60  
#[Out]# 12    1    3   16  2018-08-20         3   1.60  
#[Out]# 13    1    3   16  2018-08-20         3   1.60  
#[Out]# 14    1    3   16  2018-08-20         3   1.60  
#[Out]# 15    1    3   16  2018-08-20         3   1.60  
#[Out]# 16    1   17    9  2018-08-20         2   1.25  
#[Out]# 17    1   17    9  2018-08-20         2   1.25  
#[Out]# 18    1   17    9  2018-08-20         2   1.25  
#[Out]# 19    1   17    9  2018-08-20         2   1.25  
#[Out]# 20    1   17    9  2018-08-20         2   1.25  
#[Out]# 21    1   17    9  2018-08-20         2   1.25  
#[Out]# 22    1   17    9  2018-08-20         2   1.25  
#[Out]# 23    1   17    9  2018-08-20         2   1.25  
#[Out]# 24    1   32   25  2018-08-20         4   3.95  
# Sun, 29 Nov 2020 13:08:58
query3_2 = '''
    select distinct *
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    limit(25)
'''

pd.read_sql_query(query3_2, conn)
#[Out]#     cID cName            street   city  cID  pID  quantity        date  tID  \
#[Out]# 0     1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    1   
#[Out]# 1     1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    1   
#[Out]# 2     1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    1   
#[Out]# 3     1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    1   
#[Out]# 4     1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    1   
#[Out]# 5     1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    1   
#[Out]# 6     1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    1   
#[Out]# 7     1   Sem  Rozemarijnstraat  Breda    1   27         6  2018-08-21    1   
#[Out]# 8     1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    2   
#[Out]# 9     1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    2   
#[Out]# 10    1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    2   
#[Out]# 11    1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    2   
#[Out]# 12    1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    2   
#[Out]# 13    1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    2   
#[Out]# 14    1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    2   
#[Out]# 15    1   Sem  Rozemarijnstraat  Breda    1   27         6  2018-08-21    2   
#[Out]# 16    1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    3   
#[Out]# 17    1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    3   
#[Out]# 18    1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    3   
#[Out]# 19    1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    3   
#[Out]# 20    1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    3   
#[Out]# 21    1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    3   
#[Out]# 22    1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    3   
#[Out]# 23    1   Sem  Rozemarijnstraat  Breda    1   27         6  2018-08-21    3   
#[Out]# 24    1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    4   
#[Out]# 
#[Out]#     cID  sID  pID        date  quantity  price  
#[Out]# 0     1   23   14  2018-08-20         2   4.65  
#[Out]# 1     1   23   14  2018-08-20         2   4.65  
#[Out]# 2     1   23   14  2018-08-20         2   4.65  
#[Out]# 3     1   23   14  2018-08-20         2   4.65  
#[Out]# 4     1   23   14  2018-08-20         2   4.65  
#[Out]# 5     1   23   14  2018-08-20         2   4.65  
#[Out]# 6     1   23   14  2018-08-20         2   4.65  
#[Out]# 7     1   23   14  2018-08-20         2   4.65  
#[Out]# 8     1    3   16  2018-08-20         3   1.60  
#[Out]# 9     1    3   16  2018-08-20         3   1.60  
#[Out]# 10    1    3   16  2018-08-20         3   1.60  
#[Out]# 11    1    3   16  2018-08-20         3   1.60  
#[Out]# 12    1    3   16  2018-08-20         3   1.60  
#[Out]# 13    1    3   16  2018-08-20         3   1.60  
#[Out]# 14    1    3   16  2018-08-20         3   1.60  
#[Out]# 15    1    3   16  2018-08-20         3   1.60  
#[Out]# 16    1   17    9  2018-08-20         2   1.25  
#[Out]# 17    1   17    9  2018-08-20         2   1.25  
#[Out]# 18    1   17    9  2018-08-20         2   1.25  
#[Out]# 19    1   17    9  2018-08-20         2   1.25  
#[Out]# 20    1   17    9  2018-08-20         2   1.25  
#[Out]# 21    1   17    9  2018-08-20         2   1.25  
#[Out]# 22    1   17    9  2018-08-20         2   1.25  
#[Out]# 23    1   17    9  2018-08-20         2   1.25  
#[Out]# 24    1   32   25  2018-08-20         4   3.95  
# Sun, 29 Nov 2020 13:09:35
query3_2 = '''
    select distinct *
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    and date like '2018%'
    limit(25)
'''

pd.read_sql_query(query3_2, conn)
# Sun, 29 Nov 2020 13:09:52
query3_2 = '''
    select distinct *
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    and sl.date like '2018%'
    limit(25)
'''

pd.read_sql_query(query3_2, conn)
#[Out]#     cID cName            street   city  cID  pID  quantity        date  tID  \
#[Out]# 0     1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    1   
#[Out]# 1     1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    1   
#[Out]# 2     1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    1   
#[Out]# 3     1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    1   
#[Out]# 4     1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    1   
#[Out]# 5     1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    1   
#[Out]# 6     1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    1   
#[Out]# 7     1   Sem  Rozemarijnstraat  Breda    1   27         6  2018-08-21    1   
#[Out]# 8     1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    2   
#[Out]# 9     1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    2   
#[Out]# 10    1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    2   
#[Out]# 11    1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    2   
#[Out]# 12    1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    2   
#[Out]# 13    1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    2   
#[Out]# 14    1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    2   
#[Out]# 15    1   Sem  Rozemarijnstraat  Breda    1   27         6  2018-08-21    2   
#[Out]# 16    1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    3   
#[Out]# 17    1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    3   
#[Out]# 18    1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    3   
#[Out]# 19    1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    3   
#[Out]# 20    1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    3   
#[Out]# 21    1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    3   
#[Out]# 22    1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    3   
#[Out]# 23    1   Sem  Rozemarijnstraat  Breda    1   27         6  2018-08-21    3   
#[Out]# 24    1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    4   
#[Out]# 
#[Out]#     cID  sID  pID        date  quantity  price  
#[Out]# 0     1   23   14  2018-08-20         2   4.65  
#[Out]# 1     1   23   14  2018-08-20         2   4.65  
#[Out]# 2     1   23   14  2018-08-20         2   4.65  
#[Out]# 3     1   23   14  2018-08-20         2   4.65  
#[Out]# 4     1   23   14  2018-08-20         2   4.65  
#[Out]# 5     1   23   14  2018-08-20         2   4.65  
#[Out]# 6     1   23   14  2018-08-20         2   4.65  
#[Out]# 7     1   23   14  2018-08-20         2   4.65  
#[Out]# 8     1    3   16  2018-08-20         3   1.60  
#[Out]# 9     1    3   16  2018-08-20         3   1.60  
#[Out]# 10    1    3   16  2018-08-20         3   1.60  
#[Out]# 11    1    3   16  2018-08-20         3   1.60  
#[Out]# 12    1    3   16  2018-08-20         3   1.60  
#[Out]# 13    1    3   16  2018-08-20         3   1.60  
#[Out]# 14    1    3   16  2018-08-20         3   1.60  
#[Out]# 15    1    3   16  2018-08-20         3   1.60  
#[Out]# 16    1   17    9  2018-08-20         2   1.25  
#[Out]# 17    1   17    9  2018-08-20         2   1.25  
#[Out]# 18    1   17    9  2018-08-20         2   1.25  
#[Out]# 19    1   17    9  2018-08-20         2   1.25  
#[Out]# 20    1   17    9  2018-08-20         2   1.25  
#[Out]# 21    1   17    9  2018-08-20         2   1.25  
#[Out]# 22    1   17    9  2018-08-20         2   1.25  
#[Out]# 23    1   17    9  2018-08-20         2   1.25  
#[Out]# 24    1   32   25  2018-08-20         4   3.95  
# Sun, 29 Nov 2020 13:10:10
query3_2 = '''
    select distinct *
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    and sl.date like '2018%'
    and sl.date = p.date
    limit(25)
'''

pd.read_sql_query(query3_2, conn)
#[Out]#     cID cName            street   city  cID  pID  quantity        date  tID  \
#[Out]# 0     1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    1   
#[Out]# 1     1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    1   
#[Out]# 2     1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    1   
#[Out]# 3     1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    1   
#[Out]# 4     1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    1   
#[Out]# 5     1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    1   
#[Out]# 6     1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    1   
#[Out]# 7     1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    2   
#[Out]# 8     1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    2   
#[Out]# 9     1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    2   
#[Out]# 10    1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    2   
#[Out]# 11    1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    2   
#[Out]# 12    1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    2   
#[Out]# 13    1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    2   
#[Out]# 14    1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    3   
#[Out]# 15    1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    3   
#[Out]# 16    1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    3   
#[Out]# 17    1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    3   
#[Out]# 18    1   Sem  Rozemarijnstraat  Breda    1   21         6  2018-08-20    3   
#[Out]# 19    1   Sem  Rozemarijnstraat  Breda    1   25         4  2018-08-20    3   
#[Out]# 20    1   Sem  Rozemarijnstraat  Breda    1   26         4  2018-08-20    3   
#[Out]# 21    1   Sem  Rozemarijnstraat  Breda    1    9         2  2018-08-20    4   
#[Out]# 22    1   Sem  Rozemarijnstraat  Breda    1   11         8  2018-08-20    4   
#[Out]# 23    1   Sem  Rozemarijnstraat  Breda    1   14         2  2018-08-20    4   
#[Out]# 24    1   Sem  Rozemarijnstraat  Breda    1   16         3  2018-08-20    4   
#[Out]# 
#[Out]#     cID  sID  pID        date  quantity  price  
#[Out]# 0     1   23   14  2018-08-20         2   4.65  
#[Out]# 1     1   23   14  2018-08-20         2   4.65  
#[Out]# 2     1   23   14  2018-08-20         2   4.65  
#[Out]# 3     1   23   14  2018-08-20         2   4.65  
#[Out]# 4     1   23   14  2018-08-20         2   4.65  
#[Out]# 5     1   23   14  2018-08-20         2   4.65  
#[Out]# 6     1   23   14  2018-08-20         2   4.65  
#[Out]# 7     1    3   16  2018-08-20         3   1.60  
#[Out]# 8     1    3   16  2018-08-20         3   1.60  
#[Out]# 9     1    3   16  2018-08-20         3   1.60  
#[Out]# 10    1    3   16  2018-08-20         3   1.60  
#[Out]# 11    1    3   16  2018-08-20         3   1.60  
#[Out]# 12    1    3   16  2018-08-20         3   1.60  
#[Out]# 13    1    3   16  2018-08-20         3   1.60  
#[Out]# 14    1   17    9  2018-08-20         2   1.25  
#[Out]# 15    1   17    9  2018-08-20         2   1.25  
#[Out]# 16    1   17    9  2018-08-20         2   1.25  
#[Out]# 17    1   17    9  2018-08-20         2   1.25  
#[Out]# 18    1   17    9  2018-08-20         2   1.25  
#[Out]# 19    1   17    9  2018-08-20         2   1.25  
#[Out]# 20    1   17    9  2018-08-20         2   1.25  
#[Out]# 21    1   32   25  2018-08-20         4   3.95  
#[Out]# 22    1   32   25  2018-08-20         4   3.95  
#[Out]# 23    1   32   25  2018-08-20         4   3.95  
#[Out]# 24    1   32   25  2018-08-20         4   3.95  
# Sun, 29 Nov 2020 13:11:37
query3_2 = '''
    select distinct c.cName, c.cId 
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    and sl.date like '2018%'
    and sl.date = p.date
    limit(25)
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cName  cID
#[Out]# 0        Sem    1
#[Out]# 1      Lucas    2
#[Out]# 2       Finn    3
#[Out]# 3       Levi    5
#[Out]# 4       Bram    7
#[Out]# 5       Liam    8
#[Out]# 6        Sam   10
#[Out]# 7      Thijs   11
#[Out]# 8      James   13
#[Out]# 9       Noud   15
#[Out]# 10       Dex   17
#[Out]# 11      Hugo   18
#[Out]# 12      Lars   19
#[Out]# 13      Gijs   20
#[Out]# 14  Benjamin   21
#[Out]# 15      Mats   22
#[Out]# 16      Luca   24
#[Out]# 17    Jayden   26
#[Out]# 18       Tim   27
#[Out]# 19      Siem   28
#[Out]# 20     Ruben   29
#[Out]# 21      Teun   30
#[Out]# 22   Olivier   31
#[Out]# 23      Sven   33
#[Out]# 24     David   34
# Sun, 29 Nov 2020 13:11:52
query3_2 = '''
    select distinct c.cName, c.cId 
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    and sl.date like '2018%'
    and sl.date = p.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 13:12:26
query3_2 = '''
    select distinct c.cName, c.cId 
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    and sl.date like '2018-%'
    and sl.date = p.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 13:14:03
query3_3 = '''
    select sName
    from store
    where sName = 'Kumar'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sun, 29 Nov 2020 13:14:39
query3_3 = '''
    select sName
    from store
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sun, 29 Nov 2020 13:15:13
query3_3 = '''
    select sName
    from store
    where sName like 'K%'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sun, 29 Nov 2020 13:15:18
query3_3 = '''
    select sName
    from store
    where sName like 'k%'
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sun, 29 Nov 2020 13:15:50
query3_3 = '''
    select sName
    from store
    where sName = 'Jumbo'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
# Sun, 29 Nov 2020 13:19:02
query3_3 = '''
    select cId
    from purchase p
    where sId in (
        select sId
        from store s
        where sName = 'Jumbo'
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID
#[Out]# 0     4
#[Out]# 1    18
#[Out]# 2    19
#[Out]# 3    19
#[Out]# 4    21
#[Out]# 5    24
#[Out]# 6    27
#[Out]# 7    37
#[Out]# 8    38
#[Out]# 9    40
#[Out]# 10   47
#[Out]# 11   52
#[Out]# 12   59
#[Out]# 13   63
#[Out]# 14   66
#[Out]# 15   68
#[Out]# 16   72
#[Out]# 17   78
#[Out]# 18   85
#[Out]# 19   86
#[Out]# 20  104
#[Out]# 21  109
#[Out]# 22  112
#[Out]# 23  122
#[Out]# 24  126
#[Out]# 25  136
#[Out]# 26  165
#[Out]# 27  167
#[Out]# 28  171
#[Out]# 29  172
#[Out]# 30  180
#[Out]# 31  185
#[Out]# 32  186
#[Out]# 33  188
#[Out]# 34  188
#[Out]# 35  189
#[Out]# 36  189
#[Out]# 37  190
#[Out]# 38  190
#[Out]# 39  190
#[Out]# 40  190
#[Out]# 41  190
#[Out]# 42  190
#[Out]# 43  190
#[Out]# 44  190
# Sun, 29 Nov 2020 13:20:03
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where sName = 'Jumbo'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 13:20:19
query3_3 = '''
    select distinct cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where sName = 'Jumbo'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 13:20:25
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where sName = 'Jumbo'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 13:20:41
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'jumbo'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 13:20:51
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'kumar'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 13:21:18
query3_3 = '''
    select count(*)
    from customer
'''

pd.read_sql_query(query3_3, conn)
#[Out]#    count(*)
#[Out]# 0       190
# Sun, 29 Nov 2020 13:21:26
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'kumar'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 13:21:38
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'jumbo'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 13:21:47
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'kumar'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 13:24:54
query3_3 = '''
    select cName, cId
    from customer c
    where cId in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store
            where lower(sName) = 'jumbo'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Daan    4
#[Out]# 1       Hugo   18
#[Out]# 2       Lars   19
#[Out]# 3   Benjamin   21
#[Out]# 4       Luca   24
#[Out]# 5        Tim   27
#[Out]# 6       Guus   37
#[Out]# 7     Floris   38
#[Out]# 8       Jens   40
#[Out]# 9       Xavi   47
#[Out]# 10    Willem   52
#[Out]# 11      Joep   59
#[Out]# 12      Senn   63
#[Out]# 13   Mohamed   66
#[Out]# 14     Boris   68
#[Out]# 15      Dani   72
#[Out]# 16      Mick   78
#[Out]# 17    Pieter   85
#[Out]# 18      Stef   86
#[Out]# 19       Liv  104
#[Out]# 20      Lynn  109
#[Out]# 21      Yara  112
#[Out]# 22      Elin  122
#[Out]# 23      Lina  126
#[Out]# 24     Femke  136
#[Out]# 25     Hanna  165
#[Out]# 26    Veerle  167
#[Out]# 27     Tessa  171
#[Out]# 28      Lana  172
#[Out]# 29     Merel  180
#[Out]# 30      Nick  185
#[Out]# 31    Angela  186
#[Out]# 32      Pino  188
#[Out]# 33      Koen  189
#[Out]# 34    Kostas  190
# Sun, 29 Nov 2020 13:25:20
query3_3 = '''
    select count(*)
    from customer c
    where cId in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store
            where lower(sName) = 'jumbo'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#    count(*)
#[Out]# 0        35
# Sun, 29 Nov 2020 13:25:26
query3_3 = '''
    select *
    from customer c
    where cId in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store
            where lower(sName) = 'jumbo'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName            street       city
#[Out]# 0     4      Daan      Kalverstraat  Amsterdam
#[Out]# 1    18      Hugo      Kasteeldreef    Tilburg
#[Out]# 2    19      Lars     Rijsbergseweg      Breda
#[Out]# 3    21  Benjamin       Stationsweg    Tilburg
#[Out]# 4    24      Luca      Kasteeldreef    Tilburg
#[Out]# 5    27       Tim         Koestraat    Utrecht
#[Out]# 6    37      Guus         Koestraat    Tilburg
#[Out]# 7    38    Floris       Stationsweg  Eindhoven
#[Out]# 8    40      Jens        Bergselaan  Rotterdam
#[Out]# 9    47      Xavi     Julianastraat    Utrecht
#[Out]# 10   52    Willem  Rozemarijnstraat      Breda
#[Out]# 11   59      Joep            Amstel  Amsterdam
#[Out]# 12   63      Senn   Raamschoorseweg      Breda
#[Out]# 13   66   Mohamed  Oude Leliestraat  Amsterdam
#[Out]# 14   68     Boris     Maasboulebard  Rotterdam
#[Out]# 15   72      Dani       Karrestraat      Breda
#[Out]# 16   78      Mick       Dorpsstraat  Eindhoven
#[Out]# 17   85    Pieter         Koestraat    Utrecht
#[Out]# 18   86      Stef       Dorpsstraat  Eindhoven
#[Out]# 19  104       Liv        Pompenburg  Rotterdam
#[Out]# 20  109      Lynn     Stationsplein      Breda
#[Out]# 21  112      Yara       Stationsweg    Tilburg
#[Out]# 22  122      Elin       Langestraat    Tilburg
#[Out]# 23  126      Lina      Kalverstraat  Amsterdam
#[Out]# 24  136     Femke        Oosterkade  Rotterdam
#[Out]# 25  165     Hanna         Eikenlaan    Tilburg
#[Out]# 26  167    Veerle    Ginnekenstraat      Breda
#[Out]# 27  171     Tessa       Haringvliet  Rotterdam
#[Out]# 28  172      Lana         Eikenlaan    Tilburg
#[Out]# 29  180     Merel      Kalverstraat  Amsterdam
#[Out]# 30  185      Nick            Verweg  Eindhoven
#[Out]# 31  186    Angela          Dichtweg  Eindhoven
#[Out]# 32  188      Pino        Maanstraat  Rotterdam
#[Out]# 33  189      Koen          Akkerweg        Oss
#[Out]# 34  190    Kostas          Eindeweg    Utrecht
# Sun, 29 Nov 2020 13:26:39
query3_3 = '''
    select count(*)
    from customer c
    where cId not in (
        select cId
        from purchase
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#    count(*)
#[Out]# 0        58
# Sun, 29 Nov 2020 13:29:14
query3_3 = '''
    select *
    from purchase p
    where cId not in (
        select cId
        from purchase
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Sun, 29 Nov 2020 13:29:45
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'kumar'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 13:31:11
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'jumbo'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 13:32:20
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'kumar'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 13:36:25
query3_4 = '''
    select distinct c.cName, c.cId
    from customer c, purchase p
    where c.cId = p.cId
    and c.cId in (
        select cId
        from purchase p2
        where p2.sId in (
            select sId
            from store
            where lower(sName) = 'jumbo'
        )
        and p2.cId not in (
            select cId
            from purchase p3
            where p3.sId not in (
                select sId
                from store
                where lower(sName) != 'jumbo'
            )
        )
    )
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Sun, 29 Nov 2020 13:37:40
query3_4 = '''
    select distinct c.cName, c.cId
    from customer c, purchase p
    where c.cId = p.cId
    and c.cId in (
        select cId
        from purchase p2
        where p2.sId in (
            select sId
            from store
            where lower(sName) = 'jumbo'
        )
    )
'''

pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID
#[Out]# 0       Daan    4
#[Out]# 1       Hugo   18
#[Out]# 2       Lars   19
#[Out]# 3   Benjamin   21
#[Out]# 4       Luca   24
#[Out]# 5        Tim   27
#[Out]# 6       Guus   37
#[Out]# 7     Floris   38
#[Out]# 8       Jens   40
#[Out]# 9       Xavi   47
#[Out]# 10    Willem   52
#[Out]# 11      Joep   59
#[Out]# 12      Senn   63
#[Out]# 13   Mohamed   66
#[Out]# 14     Boris   68
#[Out]# 15      Dani   72
#[Out]# 16      Mick   78
#[Out]# 17    Pieter   85
#[Out]# 18      Stef   86
#[Out]# 19       Liv  104
#[Out]# 20      Lynn  109
#[Out]# 21      Yara  112
#[Out]# 22      Elin  122
#[Out]# 23      Lina  126
#[Out]# 24     Femke  136
#[Out]# 25     Hanna  165
#[Out]# 26    Veerle  167
#[Out]# 27     Tessa  171
#[Out]# 28      Lana  172
#[Out]# 29     Merel  180
#[Out]# 30      Nick  185
#[Out]# 31    Angela  186
#[Out]# 32      Pino  188
#[Out]# 33      Koen  189
#[Out]# 34    Kostas  190
# Sun, 29 Nov 2020 13:39:55
query3_4 = '''
    select distinct c.cName, c.cId
    from customer c, purchase p
    where c.cId = p.cId
    and c.cId not in (
        select cId
        from purchase p3
        where p3.sId not in (
            select sId
            from store
            where lower(sName) != 'jumbo'
        )
    )
'''

pd.read_sql_query(query3_4, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Levi    5
#[Out]# ..      ...  ...
#[Out]# 92     Elif  178
#[Out]# 93     Juul  179
#[Out]# 94     Liva  181
#[Out]# 95  Johanna  182
#[Out]# 96    Wilko  184
#[Out]# 
#[Out]# [97 rows x 2 columns]
# Sun, 29 Nov 2020 13:42:40
query3_4 = '''
    select distinct c.cName, c.cId
    from customer c, purchase p
    where c.cId = p.cId
    and c.cId in (
        select cId
        from purchase p2
        where p2.sId in (
            select sId
            from store
            where lower(sName) = 'jumbo'
        )
        and p2.cId not in (
            select cId
            from purchase p3
            where p3.sId not in (
                select sId
                from store
                where lower(sName) = 'jumbo'
            )
        )
    )
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Sun, 29 Nov 2020 13:44:29
query3_4 = '''
    select distinct c.cName, c.cId
    from customer c, purchase p
    where c.cId = p.cId
    and c.cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(sName) = 'jumbo'
        )
        and cId not in (
            select cId
            from purchase
            where sId not in (
                select sId
                from store
                where lower(sName) = 'jumbo'
            )
        )
    )
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Sun, 29 Nov 2020 13:49:01
query3_4 = '''
    select distinct cId, s.sId, s.sName
    from purchase p, store s
    where p.sId = s.sId
    and cId = 47
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  sID  sName
#[Out]# 0   47   20  Jumbo
# Sun, 29 Nov 2020 13:49:12
query3_4 = '''
    select cId, s.sId, s.sName
    from purchase p, store s
    where p.sId = s.sId
    and cId = 47
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  sID  sName
#[Out]# 0   47   20  Jumbo
# Sun, 29 Nov 2020 13:49:18
query3_4 = '''
    select distinct cId, s.sId, s.sName
    from purchase p, store s
    where p.sId = s.sId
    and cId = 136
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  sID  sName
#[Out]# 0  136   37  Jumbo
# Sun, 29 Nov 2020 13:49:27
query3_4 = '''
    select cId, s.sId, s.sName
    from purchase p, store s
    where p.sId = s.sId
    and cId = 136
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID  sID  sName
#[Out]# 0  136   37  Jumbo
# Sun, 29 Nov 2020 13:49:43
query3_4 = '''
    select *
    from purchase p, store s
    where p.sId = s.sId
    and cId = 47
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    tID  cID  sID  pID        date  quantity  price  sID  sName        street  \
#[Out]# 0  148   47   20   16  2018-08-17         7    2.1   20  Jumbo  Kasteeldreef   
#[Out]# 
#[Out]#       city  
#[Out]# 0  Tilburg  
# Sun, 29 Nov 2020 13:51:01
query3_4 = '''
    select *
    from purchase p, store s
    where p.sId = s.sId
    and cId in (47, 63, 104, 136, 185, 186, 188, 189)
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    tID  cID  sID  pID        date  quantity  price  sID  sName  \
#[Out]# 0  148   47   20   16  2018-08-17         7   2.10   20  Jumbo   
#[Out]# 1  182   63   20   27  2018-08-17         8   6.85   20  Jumbo   
#[Out]# 2  278  104    2   22  2018-08-22         2   2.00    2  Jumbo   
#[Out]# 3  350  136   37   28  2018-08-24         5   7.75   37  Jumbo   
#[Out]# 4  778  185   62   29  2018-08-20         1   1.00   62  Jumbo   
#[Out]# 5  779  186   62   29  2018-08-21         5   1.00   62  Jumbo   
#[Out]# 6  780  188   62   30  2018-08-20         1   1.00   62  Jumbo   
#[Out]# 7  781  188   62   30  2018-09-20         1   1.00   62  Jumbo   
#[Out]# 8  782  189   63    7  2018-08-25         5   1.25   63  Jumbo   
#[Out]# 9  783  189   20   19  2018-08-26         3   2.50   20  Jumbo   
#[Out]# 
#[Out]#            street       city  
#[Out]# 0    Kasteeldreef    Tilburg  
#[Out]# 1    Kasteeldreef    Tilburg  
#[Out]# 2  Stadhoudersweg  Rotterdam  
#[Out]# 3        Molenweg  Eindhoven  
#[Out]# 4   Poffertjesweg  Eindhoven  
#[Out]# 5   Poffertjesweg  Eindhoven  
#[Out]# 6   Poffertjesweg  Eindhoven  
#[Out]# 7   Poffertjesweg  Eindhoven  
#[Out]# 8   Stationstraat        Oss  
#[Out]# 9    Kasteeldreef    Tilburg  
# Sun, 29 Nov 2020 13:52:12
query3_4 = '''
    select distinct c.cName, c.cId
    from customer c, purchase p
    where c.cId = p.cId
    and c.cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(sName) = 'jumbo'
        )
        and cId not in (
            select cId
            from purchase
            where sId not in (
                select sId
                from store
                where lower(sName) = 'jumbo'
            )
        )
    )
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cName  cID
#[Out]# 0    Xavi   47
#[Out]# 1    Senn   63
#[Out]# 2     Liv  104
#[Out]# 3   Femke  136
#[Out]# 4    Nick  185
#[Out]# 5  Angela  186
#[Out]# 6    Pino  188
#[Out]# 7    Koen  189
# Sun, 29 Nov 2020 13:53:31
query3_4 = '''
    select distinct c.cName, c.cId
    from customer c, purchase p
    where c.cId = p.cId
    and c.cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(sName) = 'kumar'
        )
        and cId not in (
            select cId
            from purchase
            where sId not in (
                select sId
                from store
                where lower(sName) = 'kumar'
            )
        )
    )
'''

pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Sun, 29 Nov 2020 13:53:40
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'kumar'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 13:55:16
query3_2 = '''
    select distinct c.cName, c.cId 
    from customer c, shoppinglist sl, purchase p
    where c.cId = sl.cId
    and c.cId = p.cId
    and sl.date like '2018-%'
    and sl.date = p.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sun, 29 Nov 2020 13:55:30
query3_3 = '''
    select cName, cId
    from customer c
    where cId not in (
        select cId
        from purchase p
        where sId in (
            select sId
            from store s
            where lower(sName) = 'kumar'
        )
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]


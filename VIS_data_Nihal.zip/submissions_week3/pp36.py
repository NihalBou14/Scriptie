# IPython log file

# Tue, 01 Dec 2020 11:03:24
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 11:03:24
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
print("hey")
sql = f.read()
print("hey")
cur.executescript(sql)
print("hey")
# Tue, 01 Dec 2020 11:06:32
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 11:06:32
query3_2 = '''
    PUT YOUR QUERY HERE
'''
# Tue, 01 Dec 2020 11:06:32
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 11:06:32
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:07:04
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
vis.vizualize(schema)
# Tue, 01 Dec 2020 11:07:08
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
vis.visualize(schema)
# Tue, 01 Dec 2020 11:07:25
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 11:08:53
query3_2 = '''
    SELECT cName, cID FROM customer
'''
# Tue, 01 Dec 2020 11:08:55
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 11:09:09
query3_2 = '''
    SELECT cName FROM customer
'''
# Tue, 01 Dec 2020 11:09:10
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 11:10:31
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
schema
#[Out]# {'customer': ['cID', 'cName', 'street', 'city'],
#[Out]#  'store': ['sID', 'sName', 'street', 'city'],
#[Out]#  'product': ['pID', 'pName', 'suffix'],
#[Out]#  'shoppinglist': ['cID', 'pID', 'quantity', 'date'],
#[Out]#  'purchase': ['tID', 'cID', 'sID', 'pID', 'date', 'quantity', 'price'],
#[Out]#  'inventory': ['sID', 'pID', 'date', 'quantity', 'unit_price']}
# Tue, 01 Dec 2020 11:11:00
query3_2 = '''
    SELECT cName FROM customer
'''
# Tue, 01 Dec 2020 11:11:17
pd.read_sql_query(query3_2, conn)
#[Out]#       cName
#[Out]# 0      Noah
#[Out]# 1       Sem
#[Out]# 2     Lucas
#[Out]# 3      Finn
#[Out]# 4      Daan
#[Out]# ..      ...
#[Out]# 185    Nick
#[Out]# 186  Angela
#[Out]# 187    Pino
#[Out]# 188    Koen
#[Out]# 189  Kostas
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 11:11:21
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 11:11:22
pd.read_sql_query(query3_2, conn)
#[Out]#       cName
#[Out]# 0      Noah
#[Out]# 1       Sem
#[Out]# 2     Lucas
#[Out]# 3      Finn
#[Out]# 4      Daan
#[Out]# ..      ...
#[Out]# 185    Nick
#[Out]# 186  Angela
#[Out]# 187    Pino
#[Out]# 188    Koen
#[Out]# 189  Kostas
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 01 Dec 2020 11:11:53
query3_2 = '''
    SELECT cName, cID
    FROM customer
'''
# Tue, 01 Dec 2020 11:11:55
pd.read_sql_query(query3_2, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 11:13:51
#cName, cID
query3_2 = '''
    SELECT customer.cName, customer.cID
    FROM customer
    
    WHERE 
'''
# Tue, 01 Dec 2020 11:13:52
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:15:09
#cName, cID
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID AND c.cID == p.cID
'''
# Tue, 01 Dec 2020 11:15:11
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1      Sem    1
#[Out]# 2      Sem    1
#[Out]# 3      Sem    1
#[Out]# 4      Sem    1
#[Out]# ...    ...  ...
#[Out]# 2322  Liva  181
#[Out]# 2323  Liva  181
#[Out]# 2324  Liva  181
#[Out]# 2325  Liva  181
#[Out]# 2326  Liva  181
#[Out]# 
#[Out]# [2327 rows x 2 columns]
# Tue, 01 Dec 2020 11:16:50
#cName, cID
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
    AND s.date CONTAINS '2018'
'''
# Tue, 01 Dec 2020 11:16:52
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:16:56
#cName, cID
query3_2 = '''
    SELECT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
   
'''
# Tue, 01 Dec 2020 11:16:58
pd.read_sql_query(query3_2, conn)
#[Out]#     cName  cID
#[Out]# 0     Sem    1
#[Out]# 1     Sem    1
#[Out]# 2     Sem    1
#[Out]# 3     Sem    1
#[Out]# 4     Sem    1
#[Out]# ..    ...  ...
#[Out]# 971  Liva  181
#[Out]# 972  Liva  181
#[Out]# 973  Liva  181
#[Out]# 974  Liva  181
#[Out]# 975  Liva  181
#[Out]# 
#[Out]# [976 rows x 2 columns]
# Tue, 01 Dec 2020 11:17:09
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
   
'''
# Tue, 01 Dec 2020 11:17:11
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 11:18:29
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
    AND '2018' in s.date
'''
# Tue, 01 Dec 2020 11:18:30
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:19:49
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
    AND s.date CONTAINS '2018'
'''
# Tue, 01 Dec 2020 11:19:51
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:21:00
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
    AND CONTAINS(s.date, '2018')
'''
# Tue, 01 Dec 2020 11:21:02
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:21:21
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE CONTAINS(s.date, '2018')
'''
# Tue, 01 Dec 2020 11:21:22
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:21:25
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
    AND CONTAINS(s.date, '2018')
'''
# Tue, 01 Dec 2020 11:21:27
pd.read_sql_query(query3_2, conn)
# Tue, 01 Dec 2020 11:21:42
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
    AND s.date LIKE '%2018%'
'''
# Tue, 01 Dec 2020 11:21:43
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 11:21:54
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
    AND s.date LIKE '%2018%'
'''
# Tue, 01 Dec 2020 11:21:55
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID        date
#[Out]# 0      Sem    1  2018-08-20
#[Out]# 1      Sem    1  2018-08-21
#[Out]# 2    Lucas    2  2018-08-16
#[Out]# 3    Lucas    2  2018-08-17
#[Out]# 4     Finn    3  2018-08-18
#[Out]# ..     ...  ...         ...
#[Out]# 181   Juul  179  2018-08-22
#[Out]# 182  Merel  180  2018-08-26
#[Out]# 183  Merel  180  2018-08-27
#[Out]# 184   Liva  181  2018-08-24
#[Out]# 185   Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Tue, 01 Dec 2020 11:22:16
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID == s.cID
    AND c.cID == p.cID
    AND s.date == p.date
    AND s.date LIKE '%2018%'
'''
# Tue, 01 Dec 2020 11:22:17
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 11:22:45
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 11:23:00
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID = s.cID
    AND c.cID = p.cID
    AND s.date = p.date
    AND s.date LIKE '%2018%'
'''
# Tue, 01 Dec 2020 11:23:02
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 11:23:55
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID = s.cID
    AND c.cID = p.cID
    AND s.date = p.date
    AND s.date LIKE '%2018%'
'''
# Tue, 01 Dec 2020 11:23:57
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 11:23:59
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 11:26:25
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 11:26:28
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID = s.cID
    AND c.cID = p.cID
    AND s.date = p.date
    AND s.date LIKE '%2018%'
'''
# Tue, 01 Dec 2020 11:26:29
vis.visualize(query3_2, schema)

# IPython log file

# Tue, 01 Dec 2020 11:26:34
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 11:26:34
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
schema
#[Out]# {'customer': ['cID', 'cName', 'street', 'city'],
#[Out]#  'store': ['sID', 'sName', 'street', 'city'],
#[Out]#  'product': ['pID', 'pName', 'suffix'],
#[Out]#  'shoppinglist': ['cID', 'pID', 'quantity', 'date'],
#[Out]#  'purchase': ['tID', 'cID', 'sID', 'pID', 'date', 'quantity', 'price'],
#[Out]#  'inventory': ['sID', 'pID', 'date', 'quantity', 'unit_price']}
# Tue, 01 Dec 2020 11:26:34
#cName, cID
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, shoppinglist AS s, purchase AS p
    
    WHERE c.cID = s.cID
    AND c.cID = p.cID
    AND s.date = p.date
    AND s.date LIKE '%2018%'
'''
# Tue, 01 Dec 2020 11:26:34
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 11:26:34
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 11:26:34
query3_3 = '''
    PUT YOUR QUERY HERE
'''
# Tue, 01 Dec 2020 11:26:34
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 11:26:34
pd.read_sql_query(query3_3, conn)
# Tue, 01 Dec 2020 11:34:31
query3_3 = '''
    SELECT *
    FROM customer AS c, purchase AS p, store AS s
    
    WHERE NOT c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName == 'Kumar'
'''
# Tue, 01 Dec 2020 11:34:32
pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, street, city, tID, cID, sID, pID, date, quantity, price, sID, sName, street, city]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:34:45
query3_3 = '''
    SELECT *
    FROM customer AS c, purchase AS p, store AS s
    
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName == 'Kumar'
'''
# Tue, 01 Dec 2020 11:34:47
pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, street, city, tID, cID, sID, pID, date, quantity, price, sID, sName, street, city]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:35:19
query3_3 = '''
    SELECT *
    FROM customer AS c, purchase AS p, store AS s
    
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND NOT s.sName == 'Kumar'
'''
# Tue, 01 Dec 2020 11:35:21
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName            street     city  tID  cID  sID  pID        date  \
#[Out]# 0      0    Noah         Koestraat  Utrecht    0    0    3   10  2018-08-22   
#[Out]# 1      1     Sem  Rozemarijnstraat    Breda    1    1   23   14  2018-08-20   
#[Out]# 2      1     Sem  Rozemarijnstraat    Breda    2    1    3   16  2018-08-20   
#[Out]# 3      1     Sem  Rozemarijnstraat    Breda    3    1   17    9  2018-08-20   
#[Out]# 4      1     Sem  Rozemarijnstraat    Breda    4    1   32   25  2018-08-20   
#[Out]# ..   ...     ...               ...      ...  ...  ...  ...  ...         ...   
#[Out]# 504  190  Kostas          Eindeweg  Utrecht  843  190   59   17  2018-08-26   
#[Out]# 505  190  Kostas          Eindeweg  Utrecht  844  190   60    5  2018-08-27   
#[Out]# 506  190  Kostas          Eindeweg  Utrecht  845  190   61   19  2018-08-23   
#[Out]# 507  190  Kostas          Eindeweg  Utrecht  846  190   62    9  2018-08-16   
#[Out]# 508  190  Kostas          Eindeweg  Utrecht  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#      quantity  price  sID        sName            street       city  
#[Out]# 0           1   0.45    3       Sligro    Stadhoudersweg  Rotterdam  
#[Out]# 1           2   4.65   23         Dirk     Stationsplein      Breda  
#[Out]# 2           3   1.60    3       Sligro    Stadhoudersweg  Rotterdam  
#[Out]# 3           2   1.25   17    Hoogvliet        Kerkstraat  Eindhoven  
#[Out]# 4           4   3.95   32  Albert Hein        Hoogstraat    Utrecht  
#[Out]# ..        ...    ...  ...          ...               ...        ...  
#[Out]# 504         2   3.80   59        Jumbo  Rozemarijnstraat      Breda  
#[Out]# 505         6   4.35   60         Lidl      Pannekoekweg      Breda  
#[Out]# 506         5   2.85   61         Lidl      Pannekoekweg      Breda  
#[Out]# 507         2   3.15   62        Jumbo     Poffertjesweg  Eindhoven  
#[Out]# 508         1   3.30   63        Jumbo     Stationstraat        Oss  
#[Out]# 
#[Out]# [509 rows x 15 columns]
# Tue, 01 Dec 2020 11:35:25
query3_3 = '''
    SELECT *
    FROM customer AS c, purchase AS p, store AS s
    
    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName == 'Kumar'
'''
# Tue, 01 Dec 2020 11:35:27
pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, street, city, tID, cID, sID, pID, date, quantity, price, sID, sName, street, city]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:37:32
query3_3 = '''
    SELECT *
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT c.cID
        FROM customer AS c, purchase AS p, store AS s
    
        WHERE c.cID = p.cID
        AND p.sID = s.sID
        AND s.sName == 'Kumar')
'''
# Tue, 01 Dec 2020 11:37:34
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName            street       city
#[Out]# 0      0    Noah         Koestraat    Utrecht
#[Out]# 1      1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 3      3    Finn     Stationsplein      Breda
#[Out]# 4      4    Daan      Kalverstraat  Amsterdam
#[Out]# ..   ...     ...               ...        ...
#[Out]# 185  185    Nick            Verweg  Eindhoven
#[Out]# 186  186  Angela          Dichtweg  Eindhoven
#[Out]# 187  188    Pino        Maanstraat  Rotterdam
#[Out]# 188  189    Koen          Akkerweg        Oss
#[Out]# 189  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Tue, 01 Dec 2020 11:37:54
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT c.cID
        FROM customer AS c, purchase AS p, store AS s
    
        WHERE c.cID = p.cID
        AND p.sID = s.sID
        AND s.sName == 'Kumar')
'''
# Tue, 01 Dec 2020 11:37:55
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 11:38:04
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT c.cID
        FROM customer AS c, purchase AS p, store AS s
    
        WHERE c.cID = p.cID
        AND p.sID = s.sID
        AND s.sName == 'Jumbo')
'''
# Tue, 01 Dec 2020 11:38:06
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 11:38:12
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT c.cID
        FROM customer AS c, purchase AS p, store AS s
    
        WHERE c.cID = p.cID
        AND p.sID = s.sID
        AND s.sName == 'Kumar')
'''
# Tue, 01 Dec 2020 11:38:14
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 11:40:17
query3_4 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT c.cID
        FROM customer AS c, purchase AS p, store AS s
    
        WHERE c.cID = p.cID
        AND p.sID = s.sID
        AND s.sName == 'Jumbo')
'''
# Tue, 01 Dec 2020 11:40:19
pd.read_sql_query(query3_4, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 11:40:56
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName == 'Kumar')
'''
# Tue, 01 Dec 2020 11:40:58
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 11:41:53
query3_4 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Jumbo')
'''
# Tue, 01 Dec 2020 11:41:54
pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID
#[Out]# 0    Milan    6
#[Out]# 1   Thomas    9
#[Out]# 2     Adam   12
#[Out]# 3      Max   14
#[Out]# 4      Jan   23
#[Out]# ..     ...  ...
#[Out]# 61   Nikki  183
#[Out]# 62    Nick  185
#[Out]# 63  Angela  186
#[Out]# 64    Pino  188
#[Out]# 65    Koen  189
#[Out]# 
#[Out]# [66 rows x 2 columns]
# Tue, 01 Dec 2020 11:42:41
query3_4 = '''
    
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Jumbo'
'''
# Tue, 01 Dec 2020 11:42:43
pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# ..   ...
#[Out]# 459  190
#[Out]# 460  190
#[Out]# 461  190
#[Out]# 462  190
#[Out]# 463  190
#[Out]# 
#[Out]# [464 rows x 1 columns]
# Tue, 01 Dec 2020 11:42:54
query3_4 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Jumbo')
'''
# Tue, 01 Dec 2020 11:43:03
query3_4 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Jumbo')
'''
# Tue, 01 Dec 2020 11:43:05
pd.read_sql_query(query3_4, conn)
#[Out]#      cName  cID
#[Out]# 0    Milan    6
#[Out]# 1   Thomas    9
#[Out]# 2     Adam   12
#[Out]# 3      Max   14
#[Out]# 4      Jan   23
#[Out]# ..     ...  ...
#[Out]# 61   Nikki  183
#[Out]# 62    Nick  185
#[Out]# 63  Angela  186
#[Out]# 64    Pino  188
#[Out]# 65    Koen  189
#[Out]# 
#[Out]# [66 rows x 2 columns]
# Tue, 01 Dec 2020 11:44:15
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName == 'Kumar')
'''
# Tue, 01 Dec 2020 11:44:16
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 11:44:46
query3_4 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c, purchase AS p, store AS s

    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sID = 'Jumbo'
    
    AND (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Jumbo')
'''
# Tue, 01 Dec 2020 11:44:48
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 11:46:14
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName = 'Kumar')
'''
# Tue, 01 Dec 2020 11:46:15
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 11:48:24
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName = 'Jumbo')
'''
# Tue, 01 Dec 2020 11:48:25
pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0       Noah    0
#[Out]# 1        Sem    1
#[Out]# 2      Lucas    2
#[Out]# 3       Finn    3
#[Out]# 4       Levi    5
#[Out]# ..       ...  ...
#[Out]# 150     Juul  179
#[Out]# 151     Liva  181
#[Out]# 152  Johanna  182
#[Out]# 153    Nikki  183
#[Out]# 154    Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Tue, 01 Dec 2020 11:49:10
query3_3 = '''
    SELECT DISTINCT cName, cID
    FROM customer AS c

    WHERE (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName = 'Kumar')
'''
# Tue, 01 Dec 2020 11:49:12
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 11:50:18
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c2, purchase AS p2, store AS s2

    WHERE c2.cID = p2.cID
    AND p2.sID = s2.sID
    AND s2.sID = 'Jumbo'
    
    AND (c2.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Jumbo')
'''
# Tue, 01 Dec 2020 11:50:20
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 11:50:25
query3_4 = '''
    SELECT DISTINCT c2.cName, c2.cID
    FROM customer AS c2, purchase AS p2, store AS s2

    WHERE c2.cID = p2.cID
    AND p2.sID = s2.sID
    AND s2.sID = 'Jumbo'
    
    AND (c2.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Jumbo')
'''
# Tue, 01 Dec 2020 11:50:26
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:50:40
query3_4 = '''
    SELECT DISTINCT c2.cName, c2.cID
    FROM customer AS c2, purchase AS p2, store AS s2

    WHERE c2.cID = p2.cID
    AND p2.sID = s2.sID
    AND s2.sID = 'Coop'
    
    AND (c2.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Coop')
'''
# Tue, 01 Dec 2020 11:50:42
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:56:02
query3_4 = '''
    SELECT DISTINCT c2.cName, c2.cID
    FROM customer AS c2, purchase AS p2, store AS s2

    WHERE c2.cID = p2.cID
    AND p2.sID = s2.sID
    AND s2.sName = 'Coop'
    
    AND (c2.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Coop')
'''
# Tue, 01 Dec 2020 11:56:04
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Tue, 01 Dec 2020 11:58:00
query3_4 = '''
    SELECT DISTINCT c2.cName, c2.cID
    FROM customer AS c2, purchase AS p2, store AS s2

    WHERE c2.cID = p2.cID
    AND p2.sID = s2.sID
    AND s2.sName = 'Kumar'
    
    AND (c2.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Kumar')
'''
# Tue, 01 Dec 2020 11:58:01
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 11:58:09
query3_4 = '''
    SELECT DISTINCT c2.cName, c2.cID
    FROM customer AS c2, purchase AS p2, store AS s2

    WHERE c2.cID = p2.cID
    AND p2.sID = s2.sID
    AND s2.sName = 'Coop'
    
    AND (c2.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Coop')
'''
# Tue, 01 Dec 2020 11:58:13
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Tue, 01 Dec 2020 11:59:49
query3_4 = '''
    SELECT DISTINCT c2.cName, c2.cID
    FROM customer AS c2, purchase AS p2, store AS s2

    WHERE c2.cID = p2.cID
    AND p2.sID = s2.sID
    AND s2.sName = 'Coop'
    
    AND (c2.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Coop')
'''
# Tue, 01 Dec 2020 11:59:51
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Tue, 01 Dec 2020 12:00:23
query3_4 = '''
    SELECT DISTINCT c2.cName, c2.cID
    FROM customer AS c2, purchase AS p, store AS s

    WHERE c2.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = 'Coop'
    
    AND (c2.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Coop')
'''
# Tue, 01 Dec 2020 12:00:25
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Tue, 01 Dec 2020 12:00:35
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c2, purchase AS p, store AS s

    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = 'Coop'
    
    AND (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Coop')
'''
# Tue, 01 Dec 2020 12:00:37
pd.read_sql_query(query3_4, conn)
# Tue, 01 Dec 2020 12:00:46
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s

    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = 'Coop'
    
    AND (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Coop')
'''
# Tue, 01 Dec 2020 12:00:48
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Tue, 01 Dec 2020 12:00:57
query3_4 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer AS c, purchase AS p, store AS s

    WHERE c.cID = p.cID
    AND p.sID = s.sID
    AND s.sName = 'Kumar'
    
    AND (c.cID) NOT IN (
        SELECT p.cID
        FROM purchase AS p, store AS s
    
        WHERE p.sID = s.sID
        AND s.sName != 'Kumar')
'''
# Tue, 01 Dec 2020 12:00:59
pd.read_sql_query(query3_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []


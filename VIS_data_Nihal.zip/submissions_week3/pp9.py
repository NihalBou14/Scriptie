# IPython log file

# Wed, 02 Dec 2020 10:25:03
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 10:25:05
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7f9d1c63b810>
# Wed, 02 Dec 2020 10:26:04
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 02 Dec 2020 10:26:12
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 02 Dec 2020 10:26:14
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7f9d4696d9d0>
# Wed, 02 Dec 2020 10:29:30
query3_2 = '''
    SELECT cID, name
    FROM customer;
'''

pd.read_sql_query(query3_2, conn)
# Wed, 02 Dec 2020 10:29:38
query3_2 = '''
    SELECT cID, cName
    FROM customer;
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Wed, 02 Dec 2020 10:37:43
query3_2 = '''
    SELECT DISTINCT customer.cID as cID, customer.cName as cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID
            and
          shoppinglist.cID = purchase.cID
            and
          shoppinglist.date = purchase.date
            and
          shoppinglist.date > date('2017-12-31')
            and
          shoppinglist.date < date('2019-01-01');
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Wed, 02 Dec 2020 10:38:20
query3_2 = '''
    SELECT DISTINCT customer.cID as cID, customer.cName as cName, shoppinglist.date as sDate, purchase.date as pDate
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID
            and
          shoppinglist.cID = purchase.cID
            and
          shoppinglist.date = purchase.date
            and
          shoppinglist.date > date('2017-12-31')
            and
          shoppinglist.date < date('2019-01-01');
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName       sDate       pDate
#[Out]# 0      1    Sem  2018-08-20  2018-08-20
#[Out]# 1      1    Sem  2018-08-21  2018-08-21
#[Out]# 2      2  Lucas  2018-08-16  2018-08-16
#[Out]# 3      2  Lucas  2018-08-17  2018-08-17
#[Out]# 4      3   Finn  2018-08-18  2018-08-18
#[Out]# ..   ...    ...         ...         ...
#[Out]# 181  179   Juul  2018-08-22  2018-08-22
#[Out]# 182  180  Merel  2018-08-26  2018-08-26
#[Out]# 183  180  Merel  2018-08-27  2018-08-27
#[Out]# 184  181   Liva  2018-08-24  2018-08-24
#[Out]# 185  181   Liva  2018-08-27  2018-08-27
#[Out]# 
#[Out]# [186 rows x 4 columns]
# Wed, 02 Dec 2020 10:38:40
query3_2 = '''
    SELECT DISTINCT customer.cID as cID, customer.cName as cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID
            and
          shoppinglist.cID = purchase.cID
            and
          shoppinglist.date = purchase.date
            and
          shoppinglist.date > date('2017-12-31')
            and
          shoppinglist.date < date('2019-01-01');
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Wed, 02 Dec 2020 10:44:28
query3_3 = '''
(SELECT cID FROM customer)
EXCEPT
(SELECT cID FROM purchase)
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 10:45:01
query3_3 = '''
(SELECT cID FROM customer)
EXCEPT
(SELECT cID FROM purchase);
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 10:46:03
query3_3 = '''
SELECT cID FROM customer
EXCEPT
SELECT cID FROM purchase;
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID
#[Out]# 0     6
#[Out]# 1     9
#[Out]# 2    12
#[Out]# 3    14
#[Out]# 4    23
#[Out]# 5    32
#[Out]# 6    36
#[Out]# 7    46
#[Out]# 8    48
#[Out]# 9    49
#[Out]# 10   50
#[Out]# 11   53
#[Out]# 12   54
#[Out]# 13   56
#[Out]# 14   61
#[Out]# 15   62
#[Out]# 16   65
#[Out]# 17   73
#[Out]# 18   74
#[Out]# 19   79
#[Out]# 20   81
#[Out]# 21   83
#[Out]# 22   87
#[Out]# 23   89
#[Out]# 24   93
#[Out]# 25   98
#[Out]# 26  101
#[Out]# 27  102
#[Out]# 28  105
#[Out]# 29  106
#[Out]# 30  107
#[Out]# 31  114
#[Out]# 32  115
#[Out]# 33  117
#[Out]# 34  120
#[Out]# 35  121
#[Out]# 36  125
#[Out]# 37  130
#[Out]# 38  132
#[Out]# 39  138
#[Out]# 40  140
#[Out]# 41  141
#[Out]# 42  142
#[Out]# 43  143
#[Out]# 44  146
#[Out]# 45  148
#[Out]# 46  150
#[Out]# 47  153
#[Out]# 48  154
#[Out]# 49  155
#[Out]# 50  156
#[Out]# 51  158
#[Out]# 52  160
#[Out]# 53  164
#[Out]# 54  166
#[Out]# 55  173
#[Out]# 56  174
#[Out]# 57  183
# Wed, 02 Dec 2020 10:47:24
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID in (SELECT cID FROM customer
              EXCEPT
              SELECT cID FROM purchase);
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Wed, 02 Dec 2020 10:49:09
query3_3 = '''

SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN (SELECT cID FROM purchase);
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Wed, 02 Dec 2020 10:50:40
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN (SELECT cID FROM purchase, store WHERE purchase.sID = store.sID and store.name = 'Coop')
UNION
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN (SELECT cID FROM purchase);
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 10:50:50
query3_3 = '''
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN (SELECT cID FROM purchase, store WHERE purchase.sID = store.sID and store.sName = 'Coop')
UNION
SELECT DISTINCT cID, cName
FROM customer
WHERE cID NOT IN (SELECT cID FROM purchase);
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Wed, 02 Dec 2020 10:54:52
query3_4 = '''
SELECT DISTINCT cID
FROM purchase, store
WHERE purchase.sID = store.sID
        and
      store.sName = 'Coop';
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     2
#[Out]# 1     4
#[Out]# 2     5
#[Out]# 3     8
#[Out]# 4    10
#[Out]# ..  ...
#[Out]# 69  179
#[Out]# 70  180
#[Out]# 71  181
#[Out]# 72  184
#[Out]# 73  190
#[Out]# 
#[Out]# [74 rows x 1 columns]
# Wed, 02 Dec 2020 10:55:59
query3_4 = '''
SELECT DISTINCT cID
FROM purchase, store
WHERE purchase.sID = store.sID
        and
      store.sName = 'Coop'
EXCEPT
SELECT DISTINCT cID
FROM purchase, store
WHERE purchase.sID = store.sID
        and
      store.sName != 'Coop'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     8
#[Out]# 1    10
#[Out]# 2    11
#[Out]# 3    26
#[Out]# 4    28
#[Out]# 5    55
#[Out]# 6    76
#[Out]# 7    88
#[Out]# 8    99
#[Out]# 9   103
#[Out]# 10  131
#[Out]# 11  135
#[Out]# 12  151
#[Out]# 13  184
# Wed, 02 Dec 2020 10:57:43
query3_4 = '''
SELECT cID, name
FROM customer
WHERE cID in (SELECT DISTINCT cID
            FROM purchase, store
            WHERE purchase.sID = store.sID
                    and
                  store.sName = 'Coop'
            EXCEPT
            SELECT DISTINCT cID
            FROM purchase, store
            WHERE purchase.sID = store.sID
                    and
                  store.sName != 'Coop');
'''

pd.read_sql_query(query3_4, conn)
# Wed, 02 Dec 2020 10:57:47
query3_4 = '''
SELECT cID, cName
FROM customer
WHERE cID in (SELECT DISTINCT cID
            FROM purchase, store
            WHERE purchase.sID = store.sID
                    and
                  store.sName = 'Coop'
            EXCEPT
            SELECT DISTINCT cID
            FROM purchase, store
            WHERE purchase.sID = store.sID
                    and
                  store.sName != 'Coop');
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID      cName
#[Out]# 0     8       Liam
#[Out]# 1    10        Sam
#[Out]# 2    11      Thijs
#[Out]# 3    26     Jayden
#[Out]# 4    28       Siem
#[Out]# 5    55      Aiden
#[Out]# 6    76  Alexander
#[Out]# 7    88      Joris
#[Out]# 8    99       Anna
#[Out]# 9   103      Lotte
#[Out]# 10  131        Amy
#[Out]# 11  135      Sofia
#[Out]# 12  151       Jill
#[Out]# 13  184      Wilko


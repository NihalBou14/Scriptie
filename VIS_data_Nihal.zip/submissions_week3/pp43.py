# IPython log file

# Thu, 26 Nov 2020 09:40:29
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 09:40:30
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7fd3e03aa260>
# Thu, 26 Nov 2020 09:40:40
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 09:40:52
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 09:46:07
query3_2 = '''
    SELECT DISTINCT cName, cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.data
      AND year(purchase) = 2018;
'''
# Thu, 26 Nov 2020 09:46:09
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:46:14
pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 09:46:25
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.data
      AND year(purchase) = 2018;
'''
# Thu, 26 Nov 2020 09:46:25
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:46:26
pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 09:46:32
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND year(purchase) = 2018;
'''
# Thu, 26 Nov 2020 09:46:32
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:46:32
pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 09:47:40
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND year(purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:47:41
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:47:41
pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 09:47:56
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND YEAR(purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:47:56
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:47:56
pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 09:51:15
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:51:16
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:51:16
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Thu, 26 Nov 2020 09:53:13
query3_2 = '''
    SELECT strftime('%Y', purchase.date)
    FROM purchase.date;
'''
# Thu, 26 Nov 2020 09:53:14
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:53:14
pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 09:53:20
query3_2 = '''
    SELECT strftime('%Y', purchase.date)
    FROM purchase;
'''
# Thu, 26 Nov 2020 09:53:22
pd.read_sql_query(query3_2, conn)
#[Out]#     strftime('%Y', purchase.date)
#[Out]# 0                            2018
#[Out]# 1                            2018
#[Out]# 2                            2018
#[Out]# 3                            2018
#[Out]# 4                            2018
#[Out]# ..                            ...
#[Out]# 504                          2018
#[Out]# 505                          2018
#[Out]# 506                          2018
#[Out]# 507                          2018
#[Out]# 508                          2018
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Thu, 26 Nov 2020 09:53:29
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:53:30
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:53:31
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Thu, 26 Nov 2020 09:54:01
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE  strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:54:02
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:54:02
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Thu, 26 Nov 2020 09:54:06
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:54:08
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Thu, 26 Nov 2020 09:55:08
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist

'''
# Thu, 26 Nov 2020 09:55:10
pd.read_sql_query(query3_2, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Thu, 26 Nov 2020 09:55:26
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE  customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:55:27
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Thu, 26 Nov 2020 09:55:33
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND  purchase.date = shoppinglist.date
      AND strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:55:35
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Thu, 26 Nov 2020 09:55:42
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND  strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:55:43
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Thu, 26 Nov 2020 09:55:53
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      ;
'''
# Thu, 26 Nov 2020 09:55:54
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 09:58:08
query3_2 = '''
    SELECT DISTINCT cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      ;
'''
# Thu, 26 Nov 2020 09:58:10
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:58:10
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 09:59:00
query3_2 = '''
    SELECT 
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:59:00
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:59:01
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:59:02
pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 09:59:06
query3_2 = '''
    SELECT *
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:59:07
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:59:07
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:59:07
pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, street, city, tID, cID, sID, pID, date, quantity, price, cID, pID, quantity, date]
#[Out]# Index: []
# Thu, 26 Nov 2020 09:59:27
query3_2 = '''
    SELECT *
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      --AND strftime('%Y', purchase.date) = 2018;
'''
# Thu, 26 Nov 2020 09:59:27
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 09:59:27
pd.read_sql_query(query3_2, conn)
#[Out]#      cID cName            street       city  tID  cID  sID  pID        date  \
#[Out]# 0      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# 1      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# 2      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# 3      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# 4      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# ..   ...   ...               ...        ...  ...  ...  ...  ...         ...   
#[Out]# 971  181  Liva       Fredriklaan  Eindhoven  469  181    6   26  2018-08-24   
#[Out]# 972  181  Liva       Fredriklaan  Eindhoven  470  181   45    6  2018-08-24   
#[Out]# 973  181  Liva       Fredriklaan  Eindhoven  470  181   45    6  2018-08-24   
#[Out]# 974  181  Liva       Fredriklaan  Eindhoven  471  181   27   21  2018-08-27   
#[Out]# 975  181  Liva       Fredriklaan  Eindhoven  471  181   27   21  2018-08-27   
#[Out]# 
#[Out]#      quantity  price  cID  pID  quantity        date  
#[Out]# 0           2   4.65    1    9         2  2018-08-20  
#[Out]# 1           2   4.65    1   11         8  2018-08-20  
#[Out]# 2           2   4.65    1   14         2  2018-08-20  
#[Out]# 3           2   4.65    1   16         3  2018-08-20  
#[Out]# 4           2   4.65    1   21         6  2018-08-20  
#[Out]# ..        ...    ...  ...  ...       ...         ...  
#[Out]# 971         4   2.70  181   26         4  2018-08-24  
#[Out]# 972         3   0.90  181    6         3  2018-08-24  
#[Out]# 973         3   0.90  181   26         4  2018-08-24  
#[Out]# 974         5   2.00  181    5         3  2018-08-27  
#[Out]# 975         5   2.00  181   21         5  2018-08-27  
#[Out]# 
#[Out]# [976 rows x 15 columns]
# Thu, 26 Nov 2020 10:01:10
query3_2 = '''
    SELECT YEAR(purchase.date)
    FROM purchase;
'''
# Thu, 26 Nov 2020 10:01:11
pd.read_sql_query(query3_2, conn)
# Thu, 26 Nov 2020 10:02:16
query3_2 = '''
    SELECT *
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      --AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 10:02:17
query3_2 = '''
    SELECT YEAR(purchase.date)
    FROM purchase;
'''
# Thu, 26 Nov 2020 10:02:17
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 10:02:19
query3_2 = '''
    SELECT *
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      --AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 10:02:21
pd.read_sql_query(query3_2, conn)
#[Out]#      cID cName            street       city  tID  cID  sID  pID        date  \
#[Out]# 0      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# 1      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# 2      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# 3      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# 4      1   Sem  Rozemarijnstraat      Breda    1    1   23   14  2018-08-20   
#[Out]# ..   ...   ...               ...        ...  ...  ...  ...  ...         ...   
#[Out]# 971  181  Liva       Fredriklaan  Eindhoven  469  181    6   26  2018-08-24   
#[Out]# 972  181  Liva       Fredriklaan  Eindhoven  470  181   45    6  2018-08-24   
#[Out]# 973  181  Liva       Fredriklaan  Eindhoven  470  181   45    6  2018-08-24   
#[Out]# 974  181  Liva       Fredriklaan  Eindhoven  471  181   27   21  2018-08-27   
#[Out]# 975  181  Liva       Fredriklaan  Eindhoven  471  181   27   21  2018-08-27   
#[Out]# 
#[Out]#      quantity  price  cID  pID  quantity        date  
#[Out]# 0           2   4.65    1    9         2  2018-08-20  
#[Out]# 1           2   4.65    1   11         8  2018-08-20  
#[Out]# 2           2   4.65    1   14         2  2018-08-20  
#[Out]# 3           2   4.65    1   16         3  2018-08-20  
#[Out]# 4           2   4.65    1   21         6  2018-08-20  
#[Out]# ..        ...    ...  ...  ...       ...         ...  
#[Out]# 971         4   2.70  181   26         4  2018-08-24  
#[Out]# 972         3   0.90  181    6         3  2018-08-24  
#[Out]# 973         3   0.90  181   26         4  2018-08-24  
#[Out]# 974         5   2.00  181    5         3  2018-08-27  
#[Out]# 975         5   2.00  181   21         5  2018-08-27  
#[Out]# 
#[Out]# [976 rows x 15 columns]
# Thu, 26 Nov 2020 10:02:59
query3_2 = '''
    SELECT DISTINCT customer.cID, customer.cName
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 10:03:00
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 10:03:06
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 10:05:17
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Thu, 26 Nov 2020 10:19:29
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 10:20:31
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) {
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
}
# Thu, 26 Nov 2020 10:20:42
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 10:20:57
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 10:20:58
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 10:21:03
query3_2 = '''
    SELECT DISTINCT customer.cID, customer.cName
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 10:21:03
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 10:21:05
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 10:24:39
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 10:29:44
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Thu, 26 Nov 2020 10:30:06
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 10:30:07
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 10:30:08
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 10:30:10
query3_2 = '''
    SELECT DISTINCT customer.cID, customer.cName
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 10:30:11
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 10:30:33
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 10:30:38
vis.visualize(query3_2, schema)

# IPython log file

# Thu, 26 Nov 2020 10:30:44
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 10:30:44
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 10:30:44
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 10:30:45
query3_2 = '''
    SELECT DISTINCT customer.cID, customer.cName
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 10:30:45
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 10:30:45
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 10:30:45
query3_3 = '''
    PUT YOUR QUERY HERE
'''
# Thu, 26 Nov 2020 10:30:45
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:30:45
pd.read_sql_query(query3_3, conn)

# IPython log file

# Thu, 26 Nov 2020 10:31:00
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 10:31:00
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 10:31:01
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 10:31:03
query3_2 = '''
    SELECT DISTINCT customer.cID, customer.cName
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 10:31:04
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 10:31:06
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 10:31:12
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Thu, 26 Nov 2020 10:31:37
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 10:31:38
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 10:31:38
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 10:31:40
query3_2 = '''
    SELECT DISTINCT customer.cID, customer.cName
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 10:31:42
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 10:31:43
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 10:37:17
query3_3 = '''
   (SELECT customer.cID, customer.cName
    FROM customer
   )
    EXCEPT
   (SELECT customer.cID, customer.cName
    FROM customer, purchase, store
    WHERE customer.cID = purchase.cID
      AND purchase.sID = store.sID
      AND store.sName = "Coop"
   )
'''
# Thu, 26 Nov 2020 10:37:18
query3_3 = '''
   (SELECT customer.cID, customer.cName
    FROM customer
   )
    EXCEPT
   (SELECT customer.cID, customer.cName
    FROM customer, purchase, store
    WHERE customer.cID = purchase.cID
      AND purchase.sID = store.sID
      AND store.sName = "Coop"
   )
'''
# Thu, 26 Nov 2020 10:37:18
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:37:19
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:37:26
query3_3 = '''
   (SELECT customer.cID, customer.cName
    FROM customer
   )
    EXCEPT
   (SELECT customer.cID, customer.cName
    FROM customer, purchase, store
    WHERE customer.cID = purchase.cID
      AND purchase.sID = store.sID
      AND store.sName = "Coop"
   );
'''
# Thu, 26 Nov 2020 10:37:27
query3_3 = '''
   (SELECT customer.cID, customer.cName
    FROM customer
   )
    EXCEPT
   (SELECT customer.cID, customer.cName
    FROM customer, purchase, store
    WHERE customer.cID = purchase.cID
      AND purchase.sID = store.sID
      AND store.sName = "Coop"
   );
'''
# Thu, 26 Nov 2020 10:37:27
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:37:28
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:39:51
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer
    WHERE (customer.cID, customer.cName) NOT IN
    (SELECT customer.cID, customer.cName
     FROM customer, purchase, store
     WHERE customer.cID = purchase.cID
       AND purchase.sID = store.sID
       AND store.sName = "Coop");
   ;
'''
# Thu, 26 Nov 2020 10:39:51
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:39:52
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:41:47
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer
    WHERE customer.cID NOT IN
    (SELECT customer.cID
     FROM customer, purchase, store
     WHERE customer.cID = purchase.cID
       AND purchase.sID = store.sID
       AND store.sName = "Coop");
   ;
'''
# Thu, 26 Nov 2020 10:41:48
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:41:49
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:42:32
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer
    WHERE customer.cID NOT IN
    (SELECT customer.cID
     FROM customer, purchase, store
     WHERE customer.cID = purchase.cID
       AND purchase.sID = store.sID
       AND store.sName = "Coop";);
   ;
'''
# Thu, 26 Nov 2020 10:42:32
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:42:33
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:42:38
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer
    WHERE customer.cID NOT IN
    (SELECT customer.cID
     FROM customer, purchase, store
     WHERE customer.cID = purchase.cID
       AND purchase.sID = store.sID
       AND store.sName = "Coop")
   ;
'''
# Thu, 26 Nov 2020 10:42:38
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:42:38
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 10:42:51
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer
    WHERE customer.cID NOT IN
    (SELECT customer.cID
     FROM customer, purchase, store
     WHERE customer.cID = purchase.cID
       AND purchase.sID = store.sID
       AND store.sName = "Coop";);
'''
# Thu, 26 Nov 2020 10:42:51
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:42:51
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:42:58
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer
    WHERE customer.cID NOT IN
    (SELECT customer.cID
     FROM customer, purchase, store
     WHERE customer.cID = purchase.cID
       AND purchase.sID = store.sID
       AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:42:58
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:42:58
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 10:43:01
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer
    WHERE customer.cID NOT IN
    (SELECT customer.cID
     FROM customer, purchase, store
     WHERE customer.cID = purchase.cID
       AND purchase.sID = store.sID
       AND store.sName = "Coop")
'''
# Thu, 26 Nov 2020 10:43:01
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:43:01
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 10:43:04
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer
    WHERE customer.cID NOT IN
    (SELECT customer.cID
     FROM customer, purchase, store
     WHERE customer.cID = purchase.cID
       AND purchase.sID = store.sID
       AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:43:04
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:43:05
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 10:44:03
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN
    (SELECT customer.cID
     FROM customer, purchase, store
     WHERE customer.cID = purchase.cID
       AND purchase.sID = store.sID
       AND store.sName = "Coop")
       OR customer.cID NOT IN purchase.cID;
'''
# Thu, 26 Nov 2020 10:44:04
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:44:05
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:46:16
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN purchase.cID
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:46:16
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:46:17
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:47:42
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN purchase.cID
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:47:42
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:47:42
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:48:33
# query test box
query_test = '''
    LIST TABLES;
'''
pd.read_sql_query(query_test, conn)
# Thu, 26 Nov 2020 10:48:38
# query test box
query_test = '''
    SHOW TABLES;
'''
pd.read_sql_query(query_test, conn)
# Thu, 26 Nov 2020 10:48:55
# query test box
query_test = '''
    .tables
'''
pd.read_sql_query(query_test, conn)
# Thu, 26 Nov 2020 10:49:17
# query test box
query_test = '''
    SELECT name FROM sqlite_master 
    WHERE type IN ('table','view') 
    AND name NOT LIKE 'sqlite_%'
    ORDER BY 1;
'''
pd.read_sql_query(query_test, conn)
#[Out]#            name
#[Out]# 0      customer
#[Out]# 1     inventory
#[Out]# 2       product
#[Out]# 3      purchase
#[Out]# 4  shoppinglist
#[Out]# 5         store
# Thu, 26 Nov 2020 10:49:48
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE --customer.cID NOT IN purchase.cID
       --OR 
       customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:49:48
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE --customer.cID NOT IN purchase.cID
       --OR 
       customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:49:48
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:49:49
pd.read_sql_query(query3_3, conn)
#[Out]#        cID cName
#[Out]# 0        0  Noah
#[Out]# 1        0  Noah
#[Out]# 2        0  Noah
#[Out]# 3        0  Noah
#[Out]# 4        0  Noah
#[Out]# ...    ...   ...
#[Out]# 59039  189  Koen
#[Out]# 59040  189  Koen
#[Out]# 59041  189  Koen
#[Out]# 59042  189  Koen
#[Out]# 59043  189  Koen
#[Out]# 
#[Out]# [59044 rows x 2 columns]
# Thu, 26 Nov 2020 10:49:58
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN purchase.cID
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:49:59
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN purchase.cID
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:49:59
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN purchase.cID
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:49:59
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:50:00
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:50:10
query3_3 = '''
    SELECT customer.cID, customer.cName, purchase.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN purchase.cID
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:50:10
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:50:11
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:50:25
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN purchase.cID
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:50:26
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:50:26
pd.read_sql_query(query3_3, conn)

# IPython log file

# Thu, 26 Nov 2020 10:52:25
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 10:52:26
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 10:52:26
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 10:52:28
query3_2 = '''
    SELECT DISTINCT customer.cID, customer.cName
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 10:52:28
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 10:52:28
pd.read_sql_query(query3_2, conn)
#[Out]#      cID  cName
#[Out]# 0      1    Sem
#[Out]# 1      2  Lucas
#[Out]# 2      3   Finn
#[Out]# 3      5   Levi
#[Out]# 4      7   Bram
#[Out]# ..   ...    ...
#[Out]# 99   176  Amira
#[Out]# 100  178   Elif
#[Out]# 101  179   Juul
#[Out]# 102  180  Merel
#[Out]# 103  181   Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 10:52:30
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN purchase.cID
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:52:31
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:52:31
pd.read_sql_query(query3_3, conn)
# Thu, 26 Nov 2020 10:52:35
# query test box
query_test = '''
    SELECT name FROM sqlite_master 
    WHERE type IN ('table','view') 
    AND name NOT LIKE 'sqlite_%'
    ORDER BY 1;
'''
pd.read_sql_query(query_test, conn)
#[Out]#            name
#[Out]# 0      customer
#[Out]# 1     inventory
#[Out]# 2       product
#[Out]# 3      purchase
#[Out]# 4  shoppinglist
#[Out]# 5         store
# Thu, 26 Nov 2020 10:55:50
# query test box
query_test = '''
    SELECT * from purchase;
'''
pd.read_sql_query(query_test, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Thu, 26 Nov 2020 10:56:07
# query test box
query_test = '''
    SELECT purchase.cID from purchase;
'''
pd.read_sql_query(query_test, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# ..   ...
#[Out]# 504  190
#[Out]# 505  190
#[Out]# 506  190
#[Out]# 507  190
#[Out]# 508  190
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Thu, 26 Nov 2020 10:56:24
# query test box
query_test = '''
    SELECT * from customer, purchase;
'''
pd.read_sql_query(query_test, conn)
#[Out]#        cID   cName     street     city  tID  cID  sID  pID        date  \
#[Out]# 0        0    Noah  Koestraat  Utrecht    0    0    3   10  2018-08-22   
#[Out]# 1        0    Noah  Koestraat  Utrecht    1    1   23   14  2018-08-20   
#[Out]# 2        0    Noah  Koestraat  Utrecht    2    1    3   16  2018-08-20   
#[Out]# 3        0    Noah  Koestraat  Utrecht    3    1   17    9  2018-08-20   
#[Out]# 4        0    Noah  Koestraat  Utrecht    4    1   32   25  2018-08-20   
#[Out]# ...    ...     ...        ...      ...  ...  ...  ...  ...         ...   
#[Out]# 96705  190  Kostas   Eindeweg  Utrecht  843  190   59   17  2018-08-26   
#[Out]# 96706  190  Kostas   Eindeweg  Utrecht  844  190   60    5  2018-08-27   
#[Out]# 96707  190  Kostas   Eindeweg  Utrecht  845  190   61   19  2018-08-23   
#[Out]# 96708  190  Kostas   Eindeweg  Utrecht  846  190   62    9  2018-08-16   
#[Out]# 96709  190  Kostas   Eindeweg  Utrecht  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#        quantity  price  
#[Out]# 0             1   0.45  
#[Out]# 1             2   4.65  
#[Out]# 2             3   1.60  
#[Out]# 3             2   1.25  
#[Out]# 4             4   3.95  
#[Out]# ...         ...    ...  
#[Out]# 96705         2   3.80  
#[Out]# 96706         6   4.35  
#[Out]# 96707         5   2.85  
#[Out]# 96708         2   3.15  
#[Out]# 96709         1   3.30  
#[Out]# 
#[Out]# [96710 rows x 11 columns]
# Thu, 26 Nov 2020 10:56:39
# query test box
query_test = '''
    SELECT * FROM customer, purchase WHERE customer.cID = purchase.cID;
'''
pd.read_sql_query(query_test, conn)
#[Out]#      cID   cName            street     city  tID  cID  sID  pID        date  \
#[Out]# 0      0    Noah         Koestraat  Utrecht    0    0    3   10  2018-08-22   
#[Out]# 1      1     Sem  Rozemarijnstraat    Breda    1    1   23   14  2018-08-20   
#[Out]# 2      1     Sem  Rozemarijnstraat    Breda    2    1    3   16  2018-08-20   
#[Out]# 3      1     Sem  Rozemarijnstraat    Breda    3    1   17    9  2018-08-20   
#[Out]# 4      1     Sem  Rozemarijnstraat    Breda    4    1   32   25  2018-08-20   
#[Out]# ..   ...     ...               ...      ...  ...  ...  ...  ...         ...   
#[Out]# 504  190  Kostas          Eindeweg  Utrecht  843  190   59   17  2018-08-26   
#[Out]# 505  190  Kostas          Eindeweg  Utrecht  844  190   60    5  2018-08-27   
#[Out]# 506  190  Kostas          Eindeweg  Utrecht  845  190   61   19  2018-08-23   
#[Out]# 507  190  Kostas          Eindeweg  Utrecht  846  190   62    9  2018-08-16   
#[Out]# 508  190  Kostas          Eindeweg  Utrecht  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#      quantity  price  
#[Out]# 0           1   0.45  
#[Out]# 1           2   4.65  
#[Out]# 2           3   1.60  
#[Out]# 3           2   1.25  
#[Out]# 4           4   3.95  
#[Out]# ..        ...    ...  
#[Out]# 504         2   3.80  
#[Out]# 505         6   4.35  
#[Out]# 506         5   2.85  
#[Out]# 507         2   3.15  
#[Out]# 508         1   3.30  
#[Out]# 
#[Out]# [509 rows x 11 columns]
# Thu, 26 Nov 2020 10:56:43
# query test box
query_test = '''
    SELECT * FROM customer, purchase WHERE customer.cID NOT IN purchase.cID;
'''
pd.read_sql_query(query_test, conn)
# Thu, 26 Nov 2020 10:57:05
# query test box
query_test = '''
    SELECT * FROM customer, purchase WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase);
'''
pd.read_sql_query(query_test, conn)
#[Out]#        cID  cName         street     city  tID  cID  sID  pID        date  \
#[Out]# 0        6  Milan    Parallelweg  Utrecht    0    0    3   10  2018-08-22   
#[Out]# 1        6  Milan    Parallelweg  Utrecht    1    1   23   14  2018-08-20   
#[Out]# 2        6  Milan    Parallelweg  Utrecht    2    1    3   16  2018-08-20   
#[Out]# 3        6  Milan    Parallelweg  Utrecht    3    1   17    9  2018-08-20   
#[Out]# 4        6  Milan    Parallelweg  Utrecht    4    1   32   25  2018-08-20   
#[Out]# ...    ...    ...            ...      ...  ...  ...  ...  ...         ...   
#[Out]# 29517  183  Nikki  Julianastraat  Utrecht  843  190   59   17  2018-08-26   
#[Out]# 29518  183  Nikki  Julianastraat  Utrecht  844  190   60    5  2018-08-27   
#[Out]# 29519  183  Nikki  Julianastraat  Utrecht  845  190   61   19  2018-08-23   
#[Out]# 29520  183  Nikki  Julianastraat  Utrecht  846  190   62    9  2018-08-16   
#[Out]# 29521  183  Nikki  Julianastraat  Utrecht  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#        quantity  price  
#[Out]# 0             1   0.45  
#[Out]# 1             2   4.65  
#[Out]# 2             3   1.60  
#[Out]# 3             2   1.25  
#[Out]# 4             4   3.95  
#[Out]# ...         ...    ...  
#[Out]# 29517         2   3.80  
#[Out]# 29518         6   4.35  
#[Out]# 29519         5   2.85  
#[Out]# 29520         2   3.15  
#[Out]# 29521         1   3.30  
#[Out]# 
#[Out]# [29522 rows x 11 columns]
# Thu, 26 Nov 2020 10:57:15
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:57:15
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 10:57:15
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 10:57:16
pd.read_sql_query(query3_3, conn)
#[Out]#        cID cName
#[Out]# 0        0  Noah
#[Out]# 1        0  Noah
#[Out]# 2        0  Noah
#[Out]# 3        0  Noah
#[Out]# 4        0  Noah
#[Out]# ...    ...   ...
#[Out]# 59039  189  Koen
#[Out]# 59040  189  Koen
#[Out]# 59041  189  Koen
#[Out]# 59042  189  Koen
#[Out]# 59043  189  Koen
#[Out]# 
#[Out]# [59044 rows x 2 columns]
# Thu, 26 Nov 2020 10:57:41
# Final answer, with name of shop replaced by Kumar:
query3_3 = '''
    SELECT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Kumar");
'''
# Thu, 26 Nov 2020 10:58:17
# Final answer, with name of shop replaced by Kumar:
query3_3.replace("Coop", "Kumar")
#[Out]# '\n    SELECT customer.cID, customer.cName\n    FROM customer, purchase\n    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)\n       OR customer.cID NOT IN\n       (SELECT customer.cID\n       FROM customer, purchase, store\n       WHERE customer.cID = purchase.cID\n         AND purchase.sID = store.sID\n         AND store.sName = "Kumar");\n'
# Thu, 26 Nov 2020 10:59:07
# Final answer, with name of shop replaced by Kumar:
query3_3.replace("Coop", "Kumar")

# With help from https://stackoverflow.com/a/8573909/2378368
query3_3.replace(/\n/g, "<br />");
# Thu, 26 Nov 2020 10:59:47
# Final answer, with name of shop replaced by Kumar:
query3_3.replace("Coop", "Kumar")

# With help from https://stackoverflow.com/a/8573909/2378368
query3_3.replace('/\n/g', "<br />");
# Thu, 26 Nov 2020 10:59:51
# Final answer, with name of shop replaced by Kumar:
query3_3.replace("Coop", "Kumar")

# With help from https://stackoverflow.com/a/8573909/2378368
query3_3.replace('/\n/g', "<br />")
#[Out]# '\n    SELECT customer.cID, customer.cName\n    FROM customer, purchase\n    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)\n       OR customer.cID NOT IN\n       (SELECT customer.cID\n       FROM customer, purchase, store\n       WHERE customer.cID = purchase.cID\n         AND purchase.sID = store.sID\n         AND store.sName = "Kumar");\n'
# Thu, 26 Nov 2020 10:59:55
# Final answer, with name of shop replaced by Kumar:
query3_3.replace("Coop", "Kumar")

# With help from https://stackoverflow.com/a/8573909/2378368
query3_3.replace('\n', "<br />")
#[Out]# '<br />    SELECT customer.cID, customer.cName<br />    FROM customer, purchase<br />    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)<br />       OR customer.cID NOT IN<br />       (SELECT customer.cID<br />       FROM customer, purchase, store<br />       WHERE customer.cID = purchase.cID<br />         AND purchase.sID = store.sID<br />         AND store.sName = "Kumar");<br />'
# Thu, 26 Nov 2020 11:01:57
# Final answer, with name of shop replaced by Kumar:
query3_3.replace("Coop", "Kumar")

# With help from https://stackoverflow.com/a/8573909/2378368
print(query3_3.replace('\n', "<br />"))
# Thu, 26 Nov 2020 11:02:03
# Final answer, with name of shop replaced by Kumar:
query3_3.replace("Coop", "Kumar")

# With help from https://stackoverflow.com/a/8573909/2378368
print(query3_3)
# Thu, 26 Nov 2020 11:02:16
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 11:02:47
query3_3 = '''
    SELECT DISTINCT customer.cID, customer.cName
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 11:02:47
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 11:02:48
pd.read_sql_query(query3_3, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 11:02:49
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 11:04:49
query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 11:04:50
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 11:04:50
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 11:04:52
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 11:04:52
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 11:04:52
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 11:04:54
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 11:08:01
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Thu, 26 Nov 2020 11:08:01
vis.visualize(query3_4, schema)
# Thu, 26 Nov 2020 11:08:01
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Thu, 26 Nov 2020 11:08:04
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 11:08:24
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 11:08:25
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Thu, 26 Nov 2020 11:08:37
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 11:08:37
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 11:08:37
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 11:08:37
query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 11:08:37
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 11:08:37
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 11:08:37
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 11:08:37
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 11:08:38
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 11:08:38
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 11:08:38
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Thu, 26 Nov 2020 11:08:38
vis.visualize(query3_4, schema)
# Thu, 26 Nov 2020 11:08:38
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Thu, 26 Nov 2020 11:08:38
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 11:08:38
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Thu, 26 Nov 2020 12:50:04
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 12:50:04
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 12:50:04
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 12:50:05
query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 12:50:05
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 12:50:05
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 12:50:05
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 12:50:05
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 12:50:05
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 12:50:05
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 12:50:05
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Thu, 26 Nov 2020 12:50:05
vis.visualize(query3_4, schema)
# Thu, 26 Nov 2020 12:50:06
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Thu, 26 Nov 2020 12:50:06
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 12:50:06
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Thu, 26 Nov 2020 12:50:15
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 12:50:15
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 12:50:15
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 12:50:16
query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 12:50:16
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 12:50:16
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 12:50:16
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 12:50:16
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 12:50:16
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 12:50:16
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 12:50:16
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Thu, 26 Nov 2020 12:50:16
vis.visualize(query3_4, schema)
# Thu, 26 Nov 2020 12:50:16
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Thu, 26 Nov 2020 12:50:17
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 12:50:17
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Thu, 26 Nov 2020 12:51:34
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 12:51:34
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 12:51:34
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 12:51:35
query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 12:51:35
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 12:51:35
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 12:51:35
print(query3_2)
# Thu, 26 Nov 2020 12:51:35
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 12:51:35
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 12:51:35
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 12:51:35
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 12:51:35
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Thu, 26 Nov 2020 12:51:35
vis.visualize(query3_4, schema)
# Thu, 26 Nov 2020 12:51:35
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Thu, 26 Nov 2020 12:51:36
# Final answer, with name of shop replaced by Kumar:
print(query3_4.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 12:51:36
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Thu, 26 Nov 2020 12:52:01
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 26 Nov 2020 12:52:01
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 26 Nov 2020 12:52:01
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 26 Nov 2020 12:52:01
query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
'''
# Thu, 26 Nov 2020 12:52:01
vis.visualize(query3_2, schema)
# Thu, 26 Nov 2020 12:52:01
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Thu, 26 Nov 2020 12:52:01
print(query3_2)
# Thu, 26 Nov 2020 12:52:01
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Thu, 26 Nov 2020 12:52:01
vis.visualize(query3_3, schema)
# Thu, 26 Nov 2020 12:52:02
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Thu, 26 Nov 2020 12:52:02
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 12:52:02
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Thu, 26 Nov 2020 12:52:02
vis.visualize(query3_4, schema)
# Thu, 26 Nov 2020 12:52:02
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Thu, 26 Nov 2020 12:52:02
# Final answer, with name of shop replaced by Kumar:
print(query3_4.replace("Coop", "Kumar"))
# Thu, 26 Nov 2020 12:52:02
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Fri, 27 Nov 2020 15:33:36
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Fri, 27 Nov 2020 15:33:36
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Fri, 27 Nov 2020 15:33:36
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Fri, 27 Nov 2020 15:33:37
#query3_2 = '''
#    SELECT DISTINCT customer.cName, customer.cID
#    FROM customer, purchase, shoppinglist
#    WHERE customer.cID = purchase.cID
#      AND customer.cID = shoppinglist.cID
#      AND purchase.date = shoppinglist.date
#      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
#'''

query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date LIKE "%2018%";
'''
# Fri, 27 Nov 2020 15:33:37
vis.visualize(query3_2, schema)
# Fri, 27 Nov 2020 15:33:37
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Fri, 27 Nov 2020 15:33:37
print(query3_2)
# Fri, 27 Nov 2020 15:33:37
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Fri, 27 Nov 2020 15:33:37
vis.visualize(query3_3, schema)
# Fri, 27 Nov 2020 15:33:37
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Fri, 27 Nov 2020 15:33:37
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Fri, 27 Nov 2020 15:33:37
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Fri, 27 Nov 2020 15:33:37
vis.visualize(query3_4, schema)
# Fri, 27 Nov 2020 15:33:37
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Fri, 27 Nov 2020 15:33:37
# Final answer, with name of shop replaced by Kumar:
print(query3_4.replace("Coop", "Kumar"))
# Fri, 27 Nov 2020 15:33:37
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Fri, 27 Nov 2020 15:37:19
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Fri, 27 Nov 2020 15:37:19
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Fri, 27 Nov 2020 15:37:19
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Fri, 27 Nov 2020 15:37:20
#query3_2 = '''
#    SELECT DISTINCT customer.cName, customer.cID
#    FROM customer, purchase, shoppinglist
#    WHERE customer.cID = purchase.cID
#      AND customer.cID = shoppinglist.cID
#      AND purchase.date = shoppinglist.date
#      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
#'''

query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date LIKE "%2018%";
'''
# Fri, 27 Nov 2020 15:37:20
vis.visualize(query3_2, schema)
# Fri, 27 Nov 2020 15:37:20
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Fri, 27 Nov 2020 15:37:20
print(query3_2)
# Fri, 27 Nov 2020 15:37:20
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Fri, 27 Nov 2020 15:37:20
vis.visualize(query3_3, schema)
# Fri, 27 Nov 2020 15:37:20
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Fri, 27 Nov 2020 15:37:20
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Fri, 27 Nov 2020 15:37:20
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Fri, 27 Nov 2020 15:37:20
vis.visualize(query3_4, schema)
# Fri, 27 Nov 2020 15:37:21
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Fri, 27 Nov 2020 15:37:21
# Final answer, with name of shop replaced by Kumar:
print(query3_4.replace("Coop", "Kumar"))
# Fri, 27 Nov 2020 15:37:21
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Sat, 28 Nov 2020 19:23:37
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 19:23:37
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Sat, 28 Nov 2020 19:23:37
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Sat, 28 Nov 2020 19:23:37
#query3_2 = '''
#    SELECT DISTINCT customer.cName, customer.cID
#    FROM customer, purchase, shoppinglist
#    WHERE customer.cID = purchase.cID
#      AND customer.cID = shoppinglist.cID
#      AND purchase.date = shoppinglist.date
#      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
#'''

query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date LIKE "%2018%";
'''
# Sat, 28 Nov 2020 19:23:37
vis.visualize(query3_2, schema)
# Sat, 28 Nov 2020 19:23:37
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Sat, 28 Nov 2020 19:23:37
print(query3_2)
# Sat, 28 Nov 2020 19:23:37
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Sat, 28 Nov 2020 19:23:37
vis.visualize(query3_3, schema)
# Sat, 28 Nov 2020 19:23:38
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Sat, 28 Nov 2020 19:23:38
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Sat, 28 Nov 2020 19:23:38
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Sat, 28 Nov 2020 19:23:38
vis.visualize(query3_4, schema)
# Sat, 28 Nov 2020 19:23:38
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Sat, 28 Nov 2020 19:23:38
# Final answer, with name of shop replaced by Kumar:
print(query3_4.replace("Coop", "Kumar"))
# Sat, 28 Nov 2020 19:23:38
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Tue, 01 Dec 2020 13:23:55
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 13:23:55
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Tue, 01 Dec 2020 13:23:55
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 13:23:56
#query3_2 = '''
#    SELECT DISTINCT customer.cName, customer.cID
#    FROM customer, purchase, shoppinglist
#    WHERE customer.cID = purchase.cID
#      AND customer.cID = shoppinglist.cID
#      AND purchase.date = shoppinglist.date
#      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
#'''

query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date LIKE "%2018%";
'''
# Tue, 01 Dec 2020 13:23:56
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 13:23:56
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 13:23:56
print(query3_2)
# Tue, 01 Dec 2020 13:23:56
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Tue, 01 Dec 2020 13:23:56
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 13:23:56
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 13:23:56
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Tue, 01 Dec 2020 13:23:56
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Tue, 01 Dec 2020 13:23:56
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 13:23:57
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Tue, 01 Dec 2020 13:23:57
# Final answer, with name of shop replaced by Kumar:
print(query3_4.replace("Coop", "Kumar"))
# Tue, 01 Dec 2020 13:23:57
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')

# IPython log file

# Tue, 01 Dec 2020 13:24:35
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 13:24:35
# needed to check for empty db file
import os

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

if (os.stat(db_location).st_size == 0) :
    f = open(db_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Tue, 01 Dec 2020 13:24:35
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 01 Dec 2020 13:24:36
#query3_2 = '''
#    SELECT DISTINCT customer.cName, customer.cID
#    FROM customer, purchase, shoppinglist
#    WHERE customer.cID = purchase.cID
#      AND customer.cID = shoppinglist.cID
#      AND purchase.date = shoppinglist.date
#      AND purchase.date BETWEEN DATE('2018-01-01') AND DATE('2018-12-31');
#'''

query3_2 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase, shoppinglist
    WHERE customer.cID = purchase.cID
      AND customer.cID = shoppinglist.cID
      AND purchase.date = shoppinglist.date
      AND purchase.date LIKE "%2018%";
'''
# Tue, 01 Dec 2020 13:24:36
vis.visualize(query3_2, schema)
# Tue, 01 Dec 2020 13:24:36
pd.read_sql_query(query3_2, conn)
#[Out]#      cName  cID
#[Out]# 0      Sem    1
#[Out]# 1    Lucas    2
#[Out]# 2     Finn    3
#[Out]# 3     Levi    5
#[Out]# 4     Bram    7
#[Out]# ..     ...  ...
#[Out]# 99   Amira  176
#[Out]# 100   Elif  178
#[Out]# 101   Juul  179
#[Out]# 102  Merel  180
#[Out]# 103   Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 13:24:36
print(query3_2)
# Tue, 01 Dec 2020 13:24:36
query3_3 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID NOT IN (SELECT purchase.cID FROM purchase)
       OR customer.cID NOT IN
       (SELECT customer.cID
       FROM customer, purchase, store
       WHERE customer.cID = purchase.cID
         AND purchase.sID = store.sID
         AND store.sName = "Coop");
'''
# Tue, 01 Dec 2020 13:24:36
vis.visualize(query3_3, schema)
# Tue, 01 Dec 2020 13:24:36
pd.read_sql_query(query3_3, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2      Finn    3
#[Out]# 3     Milan    6
#[Out]# 4      Bram    7
#[Out]# ..      ...  ...
#[Out]# 111   Nikki  183
#[Out]# 112    Nick  185
#[Out]# 113  Angela  186
#[Out]# 114    Pino  188
#[Out]# 115    Koen  189
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Tue, 01 Dec 2020 13:24:36
# Final answer, with name of shop replaced by Kumar:
print(query3_3.replace("Coop", "Kumar"))
# Tue, 01 Dec 2020 13:24:36
query3_4 = '''
    SELECT DISTINCT customer.cName, customer.cID
    FROM customer, purchase
    WHERE customer.cID IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName = "Coop")
      AND customer.cID NOT IN (SELECT customer.cID FROM customer, purchase, store WHERE customer.cID = purchase.cID AND purchase.sID = store.sID AND store.sName != "Coop")
'''
# Tue, 01 Dec 2020 13:24:36
vis.visualize(query3_4, schema)
# Tue, 01 Dec 2020 13:24:37
pd.read_sql_query(query3_4, conn)
#[Out]#         cName  cID
#[Out]# 0        Liam    8
#[Out]# 1         Sam   10
#[Out]# 2       Thijs   11
#[Out]# 3      Jayden   26
#[Out]# 4        Siem   28
#[Out]# 5       Aiden   55
#[Out]# 6   Alexander   76
#[Out]# 7       Joris   88
#[Out]# 8        Anna   99
#[Out]# 9       Lotte  103
#[Out]# 10        Amy  131
#[Out]# 11      Sofia  135
#[Out]# 12       Jill  151
#[Out]# 13      Wilko  184
# Tue, 01 Dec 2020 13:24:37
# Final answer, with name of shop replaced by Kumar:
print(query3_4.replace("Coop", "Kumar"))
# Tue, 01 Dec 2020 13:24:37
# Cell which allows me to stop logging when I reboot the server
get_ipython().run_line_magic('logstop', '')


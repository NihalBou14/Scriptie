# IPython log file

# Sat, 28 Nov 2020 14:50:54
query3_2 = '''
    SELECT c.cName, c.cID FROM customer c, shoppinglist sl, purchase p WHERE sl.cID = p.cID AND sl.date = '2018' AND p.date = '2018'
'''

pd.read_sql_query(query3_2, conn)
# Sat, 28 Nov 2020 14:51:00
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 14:51:00
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1dcee54a810>
# Sat, 28 Nov 2020 14:51:14
query3_2 = '''
    SELECT c.cName, c.cID FROM customer c, shoppinglist sl, purchase p WHERE sl.cID = p.cID AND sl.date = '2018' AND p.date = '2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Sat, 28 Nov 2020 14:51:17
query3_3 = '''
    PUT YOUR QUERY HERE
'''

pd.read_sql_query(query3_3, conn)
# Sat, 28 Nov 2020 14:51:52
query3_2 = '''
    SELECT * FROM purchase
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Sat, 28 Nov 2020 14:52:40
query3_2 = '''
    SELECT * FROM purchase WHERE data LIKE "2018"
'''

pd.read_sql_query(query3_2, conn)
# Sat, 28 Nov 2020 14:52:45
query3_2 = '''
    SELECT * FROM purchase WHERE data LIKE '2018'
'''

pd.read_sql_query(query3_2, conn)
# Sat, 28 Nov 2020 14:52:48
query3_2 = '''
    SELECT * FROM purchase WHERE date LIKE '2018'
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Sat, 28 Nov 2020 14:53:43
query3_2 = '''
    SELECT * FROM purchase WHERE SUBSTRING(date, 0,4) = '2018'
'''

pd.read_sql_query(query3_2, conn)
# Sat, 28 Nov 2020 14:57:36
query3_2 = '''
    SELECT * FROM purchase WHERE date LIKE '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Sat, 28 Nov 2020 14:59:37
query3_2 = '''
    SELECT c.cID, c.cName FROM customer c, shoppinglist s, purchase p WHERE p.date LIKE '2018%' AND p.date = s.date 

'''

pd.read_sql_query(query3_2, conn)
#[Out]#          cID   cName
#[Out]# 0          0    Noah
#[Out]# 1          0    Noah
#[Out]# 2          0    Noah
#[Out]# 3          0    Noah
#[Out]# 4          0    Noah
#[Out]# ...      ...     ...
#[Out]# 3692075  190  Kostas
#[Out]# 3692076  190  Kostas
#[Out]# 3692077  190  Kostas
#[Out]# 3692078  190  Kostas
#[Out]# 3692079  190  Kostas
#[Out]# 
#[Out]# [3692080 rows x 2 columns]
# Sat, 28 Nov 2020 14:59:56
query3_2 = '''
    SELECT * FROM customer c, shoppinglist s, purchase p WHERE p.date LIKE '2018%' AND p.date = s.date 

'''

pd.read_sql_query(query3_2, conn)
#[Out]#          cID   cName     street     city  cID  pID  quantity        date  tID  \
#[Out]# 0          0    Noah  Koestraat  Utrecht    5    6         9  2018-08-22    0   
#[Out]# 1          0    Noah  Koestraat  Utrecht    5   28         6  2018-08-22    0   
#[Out]# 2          0    Noah  Koestraat  Utrecht   59   22         1  2018-08-22    0   
#[Out]# 3          0    Noah  Koestraat  Utrecht   64    9         7  2018-08-22    0   
#[Out]# 4          0    Noah  Koestraat  Utrecht   72   10         5  2018-08-22    0   
#[Out]# ...      ...     ...        ...      ...  ...  ...       ...         ...  ...   
#[Out]# 3692075  190  Kostas   Eindeweg  Utrecht  162   14         3  2018-08-21  847   
#[Out]# 3692076  190  Kostas   Eindeweg  Utrecht  162   18         6  2018-08-21  847   
#[Out]# 3692077  190  Kostas   Eindeweg  Utrecht  167    0         8  2018-08-21  847   
#[Out]# 3692078  190  Kostas   Eindeweg  Utrecht  183   12         9  2018-08-21  847   
#[Out]# 3692079  190  Kostas   Eindeweg  Utrecht  183   18         8  2018-08-21  847   
#[Out]# 
#[Out]#          cID  sID  pID        date  quantity  price  
#[Out]# 0          0    3   10  2018-08-22         1   0.45  
#[Out]# 1          0    3   10  2018-08-22         1   0.45  
#[Out]# 2          0    3   10  2018-08-22         1   0.45  
#[Out]# 3          0    3   10  2018-08-22         1   0.45  
#[Out]# 4          0    3   10  2018-08-22         1   0.45  
#[Out]# ...      ...  ...  ...         ...       ...    ...  
#[Out]# 3692075  190   63   18  2018-08-21         1   3.30  
#[Out]# 3692076  190   63   18  2018-08-21         1   3.30  
#[Out]# 3692077  190   63   18  2018-08-21         1   3.30  
#[Out]# 3692078  190   63   18  2018-08-21         1   3.30  
#[Out]# 3692079  190   63   18  2018-08-21         1   3.30  
#[Out]# 
#[Out]# [3692080 rows x 15 columns]
# Sat, 28 Nov 2020 15:02:45
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, shoppinglist s, purchase p WHERE p.date LIKE '2018%' AND p.date = s.date 

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sat, 28 Nov 2020 15:03:12
query3_2 = '''
    SELECT DISTINCT * FROM customer c, shoppinglist s, purchase p WHERE p.date LIKE '2018%' AND p.date = s.date 

'''

pd.read_sql_query(query3_2, conn)
#[Out]#          cID   cName     street     city  cID  pID  quantity        date  tID  \
#[Out]# 0          0    Noah  Koestraat  Utrecht    1    9         2  2018-08-20    1   
#[Out]# 1          0    Noah  Koestraat  Utrecht    1    9         2  2018-08-20    2   
#[Out]# 2          0    Noah  Koestraat  Utrecht    1    9         2  2018-08-20    3   
#[Out]# 3          0    Noah  Koestraat  Utrecht    1    9         2  2018-08-20    4   
#[Out]# 4          0    Noah  Koestraat  Utrecht    1    9         2  2018-08-20    5   
#[Out]# ...      ...     ...        ...      ...  ...  ...       ...         ...  ...   
#[Out]# 3692075  190  Kostas   Eindeweg  Utrecht  183   25         4  2018-08-22  795   
#[Out]# 3692076  190  Kostas   Eindeweg  Utrecht  183   25         4  2018-08-22  810   
#[Out]# 3692077  190  Kostas   Eindeweg  Utrecht  183   25         4  2018-08-22  826   
#[Out]# 3692078  190  Kostas   Eindeweg  Utrecht  183   25         4  2018-08-22  834   
#[Out]# 3692079  190  Kostas   Eindeweg  Utrecht  183   25         4  2018-08-22  841   
#[Out]# 
#[Out]#          cID  sID  pID        date  quantity  price  
#[Out]# 0          1   23   14  2018-08-20         2   4.65  
#[Out]# 1          1    3   16  2018-08-20         3   1.60  
#[Out]# 2          1   17    9  2018-08-20         2   1.25  
#[Out]# 3          1   32   25  2018-08-20         4   3.95  
#[Out]# 4          1   16   26  2018-08-20         4   2.75  
#[Out]# ...      ...  ...  ...         ...       ...    ...  
#[Out]# 3692075  190   11    9  2018-08-22         5   3.00  
#[Out]# 3692076  190   26   21  2018-08-22         7   0.60  
#[Out]# 3692077  190   42   19  2018-08-22         5   2.75  
#[Out]# 3692078  190   50   21  2018-08-22         6   4.05  
#[Out]# 3692079  190   57   15  2018-08-22         5   3.25  
#[Out]# 
#[Out]# [3692080 rows x 15 columns]
# Sat, 28 Nov 2020 15:04:25
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, shoppinglist s, purchase p WHERE p.date LIKE '2018%' AND p.date = s.date 

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]

# IPython log file

# Sat, 28 Nov 2020 19:29:24
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 28 Nov 2020 19:29:25
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Sat, 28 Nov 2020 19:29:35
query3_2 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, shoppinglist s, purchase p WHERE p.date LIKE '2018%' AND p.date = s.date 

'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sat, 28 Nov 2020 19:31:28
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID FROM customer c, shoppinglist s, purchase p WHERE p.date LIKE '2018%' AND p.date = s.date 

'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]

# IPython log file

# Sun, 29 Nov 2020 10:45:18
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 29 Nov 2020 10:45:31
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID FROM customer c, shoppinglist s, purchase p WHERE p.date LIKE '2018%' AND p.date = s.date 

'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 10:46:15
query3_2 = '''
    SELECT DISTINCT c.cName, c.cID FROM customer c, shoppinglist s, purchase p WHERE p.date LIKE '2018%' AND p.date = s.date; 

'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cName  cID
#[Out]# 0      Noah    0
#[Out]# 1       Sem    1
#[Out]# 2     Lucas    2
#[Out]# 3      Finn    3
#[Out]# 4      Daan    4
#[Out]# ..      ...  ...
#[Out]# 185    Nick  185
#[Out]# 186  Angela  186
#[Out]# 187    Pino  188
#[Out]# 188    Koen  189
#[Out]# 189  Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 10:49:33
query3_3 = '''
    SELECT c.cID, c.cName FROM customer c, purchase p NOT IN (SELECT c.cID, c.cName FROM customer c, purchase p WHERE p.cID = c.cID) 
'''

pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 10:50:38
query3_3 = '''
    SELECT c.cID, c.cName FROM customer c, purchase p WHERE c.cID, c.cName NOT IN (SELECT c.cID, c.cName FROM customer c, purchase p WHERE p.cID = c.cID) 
'''

pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 10:50:51
query3_3 = '''
    SELECT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID, c.cName FROM customer c, purchase p WHERE p.cID = c.cID) 
'''

pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 10:51:49
query3_3 = '''
    SELECT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID) 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cID  cName
#[Out]# 0        6  Milan
#[Out]# 1        6  Milan
#[Out]# 2        6  Milan
#[Out]# 3        6  Milan
#[Out]# 4        6  Milan
#[Out]# ...    ...    ...
#[Out]# 29517  183  Nikki
#[Out]# 29518  183  Nikki
#[Out]# 29519  183  Nikki
#[Out]# 29520  183  Nikki
#[Out]# 29521  183  Nikki
#[Out]# 
#[Out]# [29522 rows x 2 columns]
# Sun, 29 Nov 2020 10:52:04
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID) 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sun, 29 Nov 2020 10:53:29
query3_3 = '''
    SELECT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID) 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cID  cName
#[Out]# 0        6  Milan
#[Out]# 1        6  Milan
#[Out]# 2        6  Milan
#[Out]# 3        6  Milan
#[Out]# 4        6  Milan
#[Out]# ...    ...    ...
#[Out]# 29517  183  Nikki
#[Out]# 29518  183  Nikki
#[Out]# 29519  183  Nikki
#[Out]# 29520  183  Nikki
#[Out]# 29521  183  Nikki
#[Out]# 
#[Out]# [29522 rows x 2 columns]
# Sun, 29 Nov 2020 10:53:44
query3_3 = '''
    SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID) 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sun, 29 Nov 2020 10:57:14
query3_3 = '''
     SELECT c.cID, c.cName, s.sName FROM customer c, purchase p, store s WHERE s.sName != 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cID   cName      sName
#[Out]# 0          0    Noah  Hoogvliet
#[Out]# 1          0    Noah  Hoogvliet
#[Out]# 2          0    Noah  Hoogvliet
#[Out]# 3          0    Noah  Hoogvliet
#[Out]# 4          0    Noah  Hoogvliet
#[Out]# ...      ...     ...        ...
#[Out]# 4835495  190  Kostas      Jumbo
#[Out]# 4835496  190  Kostas      Jumbo
#[Out]# 4835497  190  Kostas      Jumbo
#[Out]# 4835498  190  Kostas      Jumbo
#[Out]# 4835499  190  Kostas      Jumbo
#[Out]# 
#[Out]# [4835500 rows x 3 columns]
# Sun, 29 Nov 2020 10:57:53
query3_3 = '''
     SELECT DISTINCT c.cID, c.cName, s.sName FROM customer c, purchase p, store s WHERE s.sName != 'Coop'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#       cID   cName        sName
#[Out]# 0       0    Noah    Hoogvliet
#[Out]# 1       0    Noah        Jumbo
#[Out]# 2       0    Noah       Sligro
#[Out]# 3       0    Noah  Albert Hein
#[Out]# 4       0    Noah         Lidl
#[Out]# ...   ...     ...          ...
#[Out]# 1135  190  Kostas        Jumbo
#[Out]# 1136  190  Kostas       Sligro
#[Out]# 1137  190  Kostas  Albert Hein
#[Out]# 1138  190  Kostas         Lidl
#[Out]# 1139  190  Kostas         Dirk
#[Out]# 
#[Out]# [1140 rows x 3 columns]
# Sun, 29 Nov 2020 10:58:05
query3_3 = '''
     SELECT DISTINCT c.cID, c.cName, s.sName FROM customer c, purchase p, store s WHERE s.sName != 'Coop'
'''

df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 10:59:08
df.contains(pat="Coop")
# Sun, 29 Nov 2020 10:59:16
df.store
# Sun, 29 Nov 2020 10:59:20
df.sName
#[Out]# 0         Hoogvliet
#[Out]# 1             Jumbo
#[Out]# 2            Sligro
#[Out]# 3       Albert Hein
#[Out]# 4              Lidl
#[Out]#            ...     
#[Out]# 1135          Jumbo
#[Out]# 1136         Sligro
#[Out]# 1137    Albert Hein
#[Out]# 1138           Lidl
#[Out]# 1139           Dirk
#[Out]# Name: sName, Length: 1140, dtype: object
# Sun, 29 Nov 2020 10:59:28
df.sName.contains(pat = "Coop")
# Sun, 29 Nov 2020 11:00:12
pd.Series(df.sName).contains(pat = "Coop")
# Sun, 29 Nov 2020 11:00:48
df['sName'].unique()
#[Out]# array(['Hoogvliet', 'Jumbo', 'Sligro', 'Albert Hein', 'Lidl', 'Dirk'],
#[Out]#       dtype=object)
# Sun, 29 Nov 2020 11:00:57
"Coop" in df['sName'].unique()
#[Out]# False
# Sun, 29 Nov 2020 11:02:17
query3_3 = '''
     SELECT * FROM customer c, purchase p, store s WHERE s.sName != 'Coop'
'''

df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:02:49
df
#[Out]#          cID   cName     street     city  tID  cID  sID  pID        date  \
#[Out]# 0          0    Noah  Koestraat  Utrecht    0    0    3   10  2018-08-22   
#[Out]# 1          0    Noah  Koestraat  Utrecht    1    1   23   14  2018-08-20   
#[Out]# 2          0    Noah  Koestraat  Utrecht    2    1    3   16  2018-08-20   
#[Out]# 3          0    Noah  Koestraat  Utrecht    3    1   17    9  2018-08-20   
#[Out]# 4          0    Noah  Koestraat  Utrecht    4    1   32   25  2018-08-20   
#[Out]# ...      ...     ...        ...      ...  ...  ...  ...  ...         ...   
#[Out]# 4835495  190  Kostas   Eindeweg  Utrecht  843  190   59   17  2018-08-26   
#[Out]# 4835496  190  Kostas   Eindeweg  Utrecht  844  190   60    5  2018-08-27   
#[Out]# 4835497  190  Kostas   Eindeweg  Utrecht  845  190   61   19  2018-08-23   
#[Out]# 4835498  190  Kostas   Eindeweg  Utrecht  846  190   62    9  2018-08-16   
#[Out]# 4835499  190  Kostas   Eindeweg  Utrecht  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#          quantity  price  sID      sName            street   city  
#[Out]# 0               1   0.45    1  Hoogvliet  Rozemarijnstraat  Breda  
#[Out]# 1               2   4.65    1  Hoogvliet  Rozemarijnstraat  Breda  
#[Out]# 2               3   1.60    1  Hoogvliet  Rozemarijnstraat  Breda  
#[Out]# 3               2   1.25    1  Hoogvliet  Rozemarijnstraat  Breda  
#[Out]# 4               4   3.95    1  Hoogvliet  Rozemarijnstraat  Breda  
#[Out]# ...           ...    ...  ...        ...               ...    ...  
#[Out]# 4835495         2   3.80   63      Jumbo     Stationstraat    Oss  
#[Out]# 4835496         6   4.35   63      Jumbo     Stationstraat    Oss  
#[Out]# 4835497         5   2.85   63      Jumbo     Stationstraat    Oss  
#[Out]# 4835498         2   3.15   63      Jumbo     Stationstraat    Oss  
#[Out]# 4835499         1   3.30   63      Jumbo     Stationstraat    Oss  
#[Out]# 
#[Out]# [4835500 rows x 15 columns]
# Sun, 29 Nov 2020 11:03:41
df[sName].unique()
# Sun, 29 Nov 2020 11:03:45
df["sName"].unique()
#[Out]# array(['Hoogvliet', 'Jumbo', 'Sligro', 'Albert Hein', 'Lidl', 'Dirk'],
#[Out]#       dtype=object)
# Sun, 29 Nov 2020 11:04:01
query3_3 = '''
     SELECT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop'
'''

df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:04:07
df.head()
#[Out]#    cID cName
#[Out]# 0    0  Noah
#[Out]# 1    0  Noah
#[Out]# 2    0  Noah
#[Out]# 3    0  Noah
#[Out]# 4    0  Noah
# Sun, 29 Nov 2020 11:04:18
query3_3 = '''
     SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop'
'''

df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:04:19
df.head()
#[Out]#    cID  cName
#[Out]# 0    0   Noah
#[Out]# 1    1    Sem
#[Out]# 2    2  Lucas
#[Out]# 3    3   Finn
#[Out]# 4    4   Daan
# Sun, 29 Nov 2020 11:06:50
query3_3 = '''
     SELECT c.cID, c.cName FROM customer c WHERE c.cID IN (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) OR c.cID IN (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop');
'''

df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:07:11
query3_3 = '''
     SELECT c.cID, c.cName FROM customer c WHERE c.cID IN (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) OR c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p, store s WHERE s.sName != 'Coop');
'''

df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:07:19
query3_3 = '''
     SELECT c.cID, c.cName FROM customer c WHERE c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) OR c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p, store s WHERE s.sName != 'Coop');
'''

df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:07:23
df.head()
#[Out]#    cID   cName
#[Out]# 0    6   Milan
#[Out]# 1    9  Thomas
#[Out]# 2   12    Adam
#[Out]# 3   14     Max
#[Out]# 4   23     Jan
# Sun, 29 Nov 2020 11:08:44
query3_3 = '''
     SELECT c.cID, c.cName FROM customer c WHERE c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) OR c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p, store s WHERE s.sName != 'Coop');
'''

querytest = '''SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)'''
nopur = pd.read_sql_query(querytest, conn)
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:08:47
nopur
#[Out]#     cID
#[Out]# 0     6
#[Out]# 1     9
#[Out]# 2    12
#[Out]# 3    14
#[Out]# 4    23
#[Out]# 5    32
#[Out]# 6    36
#[Out]# 7    46
#[Out]# 8    48
#[Out]# 9    49
#[Out]# 10   50
#[Out]# 11   53
#[Out]# 12   54
#[Out]# 13   56
#[Out]# 14   61
#[Out]# 15   62
#[Out]# 16   65
#[Out]# 17   73
#[Out]# 18   74
#[Out]# 19   79
#[Out]# 20   81
#[Out]# 21   83
#[Out]# 22   87
#[Out]# 23   89
#[Out]# 24   93
#[Out]# 25   98
#[Out]# 26  101
#[Out]# 27  102
#[Out]# 28  105
#[Out]# 29  106
#[Out]# 30  107
#[Out]# 31  114
#[Out]# 32  115
#[Out]# 33  117
#[Out]# 34  120
#[Out]# 35  121
#[Out]# 36  125
#[Out]# 37  130
#[Out]# 38  132
#[Out]# 39  138
#[Out]# 40  140
#[Out]# 41  141
#[Out]# 42  142
#[Out]# 43  143
#[Out]# 44  146
#[Out]# 45  148
#[Out]# 46  150
#[Out]# 47  153
#[Out]# 48  154
#[Out]# 49  155
#[Out]# 50  156
#[Out]# 51  158
#[Out]# 52  160
#[Out]# 53  164
#[Out]# 54  166
#[Out]# 55  173
#[Out]# 56  174
#[Out]# 57  183
# Sun, 29 Nov 2020 11:08:51
nopur.head()
#[Out]#    cID
#[Out]# 0    6
#[Out]# 1    9
#[Out]# 2   12
#[Out]# 3   14
#[Out]# 4   23
# Sun, 29 Nov 2020 11:09:17
query3_3 = '''
     SELECT c.cID, c.cName FROM customer c WHERE c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) OR c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p, store s WHERE s.sName != 'Coop');
'''

querytest = '''SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)'''
nopur = pd.read_sql_query(querytest, conn)
querytest2 = '''SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop''''
nocoop = pd.read_sql_query(querytest2, conn)
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:09:29
query3_3 = '''
     SELECT c.cID, c.cName FROM customer c WHERE c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) OR c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p, store s WHERE s.sName != 'Coop');
'''

querytest = '''SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)'''
nopur = pd.read_sql_query(querytest, conn)
querytest2 = '''SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop' 
'''
nocoop = pd.read_sql_query(querytest2, conn)
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:09:31
nopur.head()
#[Out]#    cID
#[Out]# 0    6
#[Out]# 1    9
#[Out]# 2   12
#[Out]# 3   14
#[Out]# 4   23
# Sun, 29 Nov 2020 11:09:34
nopur.head()
#[Out]#    cID
#[Out]# 0    6
#[Out]# 1    9
#[Out]# 2   12
#[Out]# 3   14
#[Out]# 4   23
# Sun, 29 Nov 2020 11:09:42
nopur.head()
nocoop.head()
#[Out]#    cID  cName
#[Out]# 0    0   Noah
#[Out]# 1    1    Sem
#[Out]# 2    2  Lucas
#[Out]# 3    3   Finn
#[Out]# 4    4   Daan
# Sun, 29 Nov 2020 11:09:52
nopur.head()
nocoop.head()
df.head()
#[Out]#    cID   cName
#[Out]# 0    6   Milan
#[Out]# 1    9  Thomas
#[Out]# 2   12    Adam
#[Out]# 3   14     Max
#[Out]# 4   23     Jan
# Sun, 29 Nov 2020 11:09:56
nopur.head()
nocoop.head()
#[Out]#    cID  cName
#[Out]# 0    0   Noah
#[Out]# 1    1    Sem
#[Out]# 2    2  Lucas
#[Out]# 3    3   Finn
#[Out]# 4    4   Daan
# Sun, 29 Nov 2020 11:11:23
nocoop.head()
#[Out]#    cID  cName
#[Out]# 0    0   Noah
#[Out]# 1    1    Sem
#[Out]# 2    2  Lucas
#[Out]# 3    3   Finn
#[Out]# 4    4   Daan
# Sun, 29 Nov 2020 11:11:30
nopur.head()
#[Out]#    cID
#[Out]# 0    6
#[Out]# 1    9
#[Out]# 2   12
#[Out]# 3   14
#[Out]# 4   23
# Sun, 29 Nov 2020 11:11:37
df.head()
#[Out]#    cID   cName
#[Out]# 0    6   Milan
#[Out]# 1    9  Thomas
#[Out]# 2   12    Adam
#[Out]# 3   14     Max
#[Out]# 4   23     Jan
# Sun, 29 Nov 2020 11:12:12
query3_3 = '''
     SELECT c.cID, c.cName FROM customer c WHERE (c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID))) OR (c.cID IN (SELECT DISTINCT c.cID FROM customer c, purchase p, store s WHERE s.sName != 'Coop'));
'''

querytest = '''SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)'''
nopur = pd.read_sql_query(querytest, conn)
querytest2 = '''SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop' 
'''
nocoop = pd.read_sql_query(querytest2, conn)
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:12:17
df.head()
#[Out]#    cID   cName
#[Out]# 0    6   Milan
#[Out]# 1    9  Thomas
#[Out]# 2   12    Adam
#[Out]# 3   14     Max
#[Out]# 4   23     Jan
# Sun, 29 Nov 2020 11:15:01
query3_3 = '''
     SELECT c.cID, c.cName FROM (SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) UNION (SELECT DISTINCT c.cID FROM customer c, purchase p, store s WHERE s.sName != 'Coop'));
'''

querytest = '''SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)'''
nopur = pd.read_sql_query(querytest, conn)
querytest2 = '''SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop' 
'''
nocoop = pd.read_sql_query(querytest2, conn)
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:16:03
query3_3 = '''
     SELECT DISTINCT c.cID, c.cName FROM ((SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) UNION (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop'));
'''

querytest = '''SELECT DISTINCT c.cID FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)'''
nopur = pd.read_sql_query(querytest, conn)
querytest2 = '''SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop' 
'''
nocoop = pd.read_sql_query(querytest2, conn)
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:17:33
query3_3 = '''
     SELECT DISTINCT c.cID, c.cName FROM (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) UNION (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop');
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:18:11
query3_3 = '''
     SELECT * FROM (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop' UNION SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID))
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:18:12
df.head()
#[Out]#    cID  cName
#[Out]# 0    0   Noah
#[Out]# 1    1    Sem
#[Out]# 2    2  Lucas
#[Out]# 3    3   Finn
#[Out]# 4    4   Daan
# Sun, 29 Nov 2020 11:18:46
query3_3 = '''
     SELECT * FROM ((SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop') UNION (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)));
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:18:58
query3_3 = '''
     SELECT * FROM ((SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop') UNION (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID));
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:19:08
query3_3 = '''
     SELECT * FROM (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop' UNION SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID));
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:19:10
df.head()
#[Out]#    cID  cName
#[Out]# 0    0   Noah
#[Out]# 1    1    Sem
#[Out]# 2    2  Lucas
#[Out]# 3    3   Finn
#[Out]# 4    4   Daan
# Sun, 29 Nov 2020 11:19:20
df[0:30]
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     1       Sem
#[Out]# 2     2     Lucas
#[Out]# 3     3      Finn
#[Out]# 4     4      Daan
#[Out]# 5     5      Levi
#[Out]# 6     6     Milan
#[Out]# 7     7      Bram
#[Out]# 8     8      Liam
#[Out]# 9     9    Thomas
#[Out]# 10   10       Sam
#[Out]# 11   11     Thijs
#[Out]# 12   12      Adam
#[Out]# 13   13     James
#[Out]# 14   14       Max
#[Out]# 15   15      Noud
#[Out]# 16   16    Julian
#[Out]# 17   17       Dex
#[Out]# 18   18      Hugo
#[Out]# 19   19      Lars
#[Out]# 20   20      Gijs
#[Out]# 21   21  Benjamin
#[Out]# 22   22      Mats
#[Out]# 23   23       Jan
#[Out]# 24   24      Luca
#[Out]# 25   25     Mason
#[Out]# 26   26    Jayden
#[Out]# 27   27       Tim
#[Out]# 28   28      Siem
#[Out]# 29   29     Ruben
# Sun, 29 Nov 2020 11:20:41
query3_3 = '''
     SELECT * FROM ((SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) UNION ());
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:20:50
query3_3 = '''
     SELECT * FROM ((SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)) UNION (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop'));
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:20:50
df[0:30]
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     1       Sem
#[Out]# 2     2     Lucas
#[Out]# 3     3      Finn
#[Out]# 4     4      Daan
#[Out]# 5     5      Levi
#[Out]# 6     6     Milan
#[Out]# 7     7      Bram
#[Out]# 8     8      Liam
#[Out]# 9     9    Thomas
#[Out]# 10   10       Sam
#[Out]# 11   11     Thijs
#[Out]# 12   12      Adam
#[Out]# 13   13     James
#[Out]# 14   14       Max
#[Out]# 15   15      Noud
#[Out]# 16   16    Julian
#[Out]# 17   17       Dex
#[Out]# 18   18      Hugo
#[Out]# 19   19      Lars
#[Out]# 20   20      Gijs
#[Out]# 21   21  Benjamin
#[Out]# 22   22      Mats
#[Out]# 23   23       Jan
#[Out]# 24   24      Luca
#[Out]# 25   25     Mason
#[Out]# 26   26    Jayden
#[Out]# 27   27       Tim
#[Out]# 28   28      Siem
#[Out]# 29   29     Ruben
# Sun, 29 Nov 2020 11:22:09
query3_3 = '''
     SELECT * FROM (SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop'
     UNION 
     SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID));
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:22:11
df[0:30]
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     1       Sem
#[Out]# 2     2     Lucas
#[Out]# 3     3      Finn
#[Out]# 4     4      Daan
#[Out]# 5     5      Levi
#[Out]# 6     6     Milan
#[Out]# 7     7      Bram
#[Out]# 8     8      Liam
#[Out]# 9     9    Thomas
#[Out]# 10   10       Sam
#[Out]# 11   11     Thijs
#[Out]# 12   12      Adam
#[Out]# 13   13     James
#[Out]# 14   14       Max
#[Out]# 15   15      Noud
#[Out]# 16   16    Julian
#[Out]# 17   17       Dex
#[Out]# 18   18      Hugo
#[Out]# 19   19      Lars
#[Out]# 20   20      Gijs
#[Out]# 21   21  Benjamin
#[Out]# 22   22      Mats
#[Out]# 23   23       Jan
#[Out]# 24   24      Luca
#[Out]# 25   25     Mason
#[Out]# 26   26    Jayden
#[Out]# 27   27       Tim
#[Out]# 28   28      Siem
#[Out]# 29   29     Ruben
# Sun, 29 Nov 2020 11:22:25
query3_3 = '''
     SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p, store s WHERE s.sName != 'Coop'
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:22:26
df[0:30]
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     1       Sem
#[Out]# 2     2     Lucas
#[Out]# 3     3      Finn
#[Out]# 4     4      Daan
#[Out]# 5     5      Levi
#[Out]# 6     6     Milan
#[Out]# 7     7      Bram
#[Out]# 8     8      Liam
#[Out]# 9     9    Thomas
#[Out]# 10   10       Sam
#[Out]# 11   11     Thijs
#[Out]# 12   12      Adam
#[Out]# 13   13     James
#[Out]# 14   14       Max
#[Out]# 15   15      Noud
#[Out]# 16   16    Julian
#[Out]# 17   17       Dex
#[Out]# 18   18      Hugo
#[Out]# 19   19      Lars
#[Out]# 20   20      Gijs
#[Out]# 21   21  Benjamin
#[Out]# 22   22      Mats
#[Out]# 23   23       Jan
#[Out]# 24   24      Luca
#[Out]# 25   25     Mason
#[Out]# 26   26    Jayden
#[Out]# 27   27       Tim
#[Out]# 28   28      Siem
#[Out]# 29   29     Ruben
# Sun, 29 Nov 2020 11:22:34
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 11:22:56
query3_3 = '''
     SELECT DISTINCT c.cID, c.cName FROM customer c, purchase p WHERE c.cID NOT IN (SELECT c.cID FROM customer c, purchase p WHERE p.cID = c.cID)
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:22:56
df
#[Out]#     cID     cName
#[Out]# 0     6     Milan
#[Out]# 1     9    Thomas
#[Out]# 2    12      Adam
#[Out]# 3    14       Max
#[Out]# 4    23       Jan
#[Out]# 5    32     Vince
#[Out]# 6    36      Boaz
#[Out]# 7    46     Fedde
#[Out]# 8    48      Tygo
#[Out]# 9    49       Cas
#[Out]# 10   50       Pim
#[Out]# 11   53       Job
#[Out]# 12   54       Jax
#[Out]# 13   56    Tobias
#[Out]# 14   61    Morris
#[Out]# 15   62      Abel
#[Out]# 16   65    Pepijn
#[Out]# 17   73      Owen
#[Out]# 18   74    Samuel
#[Out]# 19   79    Joshua
#[Out]# 20   81     Simon
#[Out]# 21   83     Melle
#[Out]# 22   87     Jelle
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  101       Eva
#[Out]# 27  102       Evi
#[Out]# 28  105      Nora
#[Out]# 29  106     Fleur
#[Out]# 30  107    Olivia
#[Out]# 31  114      Maud
#[Out]# 32  115      Nova
#[Out]# 33  117      Roos
#[Out]# 34  120     Sarah
#[Out]# 35  121       Isa
#[Out]# 36  125       Noa
#[Out]# 37  130     Sanne
#[Out]# 38  132    Hannah
#[Out]# 39  138     Maria
#[Out]# 40  140      Vera
#[Out]# 41  141       Mia
#[Out]# 42  142        Bo
#[Out]# 43  143     Naomi
#[Out]# 44  146     Norah
#[Out]# 45  148  Isabella
#[Out]# 46  150     Julie
#[Out]# 47  153     Amber
#[Out]# 48  154    Benthe
#[Out]# 49  155     Linde
#[Out]# 50  156      Luna
#[Out]# 51  158      Rosa
#[Out]# 52  160      Lara
#[Out]# 53  164       Evy
#[Out]# 54  166   Rosalie
#[Out]# 55  173     Livia
#[Out]# 56  174      Romy
#[Out]# 57  183     Nikki
# Sun, 29 Nov 2020 11:28:02
query3_3 = '''
     SELECT c.cID FROM (
     SELECT c.cID FROM customer c
     EXCEPT
     SELECT p.cID FROM purchase p
     )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:28:17
query3_3 = '''
     SELECT c.cID FROM (
     SELECT c.cID FROM customer c
     EXCEPT
     SELECT p.cID FROM purchase p
     ) as c
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:28:36
query3_3 = '''
     SELECT cID FROM (
     SELECT c.cID FROM customer c
     EXCEPT
     SELECT p.cID FROM purchase p
     )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:28:37
df
#[Out]#     cID
#[Out]# 0     6
#[Out]# 1     9
#[Out]# 2    12
#[Out]# 3    14
#[Out]# 4    23
#[Out]# 5    32
#[Out]# 6    36
#[Out]# 7    46
#[Out]# 8    48
#[Out]# 9    49
#[Out]# 10   50
#[Out]# 11   53
#[Out]# 12   54
#[Out]# 13   56
#[Out]# 14   61
#[Out]# 15   62
#[Out]# 16   65
#[Out]# 17   73
#[Out]# 18   74
#[Out]# 19   79
#[Out]# 20   81
#[Out]# 21   83
#[Out]# 22   87
#[Out]# 23   89
#[Out]# 24   93
#[Out]# 25   98
#[Out]# 26  101
#[Out]# 27  102
#[Out]# 28  105
#[Out]# 29  106
#[Out]# 30  107
#[Out]# 31  114
#[Out]# 32  115
#[Out]# 33  117
#[Out]# 34  120
#[Out]# 35  121
#[Out]# 36  125
#[Out]# 37  130
#[Out]# 38  132
#[Out]# 39  138
#[Out]# 40  140
#[Out]# 41  141
#[Out]# 42  142
#[Out]# 43  143
#[Out]# 44  146
#[Out]# 45  148
#[Out]# 46  150
#[Out]# 47  153
#[Out]# 48  154
#[Out]# 49  155
#[Out]# 50  156
#[Out]# 51  158
#[Out]# 52  160
#[Out]# 53  164
#[Out]# 54  166
#[Out]# 55  173
#[Out]# 56  174
#[Out]# 57  183
# Sun, 29 Nov 2020 11:31:10
query3_3 = '''
    SELECT cID FROM (
    SELECT cID FROM customer
    EXCEPT
    SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Coop")
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:31:11
df
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 176  183
#[Out]# 177  185
#[Out]# 178  186
#[Out]# 179  188
#[Out]# 180  189
#[Out]# 
#[Out]# [181 rows x 1 columns]
# Sun, 29 Nov 2020 11:31:48
query3_3 = '''
    SELECT sID FROM store WHERE sName = "Coop"
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:31:49
df
#[Out]#     sID
#[Out]# 0     0
#[Out]# 1     6
#[Out]# 2    13
#[Out]# 3    14
#[Out]# 4    19
#[Out]# 5    21
#[Out]# 6    31
#[Out]# 7    34
#[Out]# 8    43
#[Out]# 9    45
#[Out]# 10   47
#[Out]# 11   51
#[Out]# 12   53
#[Out]# 13   55
# Sun, 29 Nov 2020 11:32:19
query3_3 = '''
    SELECT cID FROM (
    SELECT cID FROM customer
    EXCEPT
    SELECT cID FROM purchase WHERE sID NOT IN (SELECT sID FROM store WHERE sName = "Coop")
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:32:20
df
#[Out]#     cID
#[Out]# 0     6
#[Out]# 1     8
#[Out]# 2     9
#[Out]# 3    10
#[Out]# 4    11
#[Out]# ..  ...
#[Out]# 67  166
#[Out]# 68  173
#[Out]# 69  174
#[Out]# 70  183
#[Out]# 71  184
#[Out]# 
#[Out]# [72 rows x 1 columns]
# Sun, 29 Nov 2020 11:33:58
query3_3 = '''
    SELECT DISTINCT * FROM ( 
     SELECT cID, cName FROM (
     SELECT cID, cName FROM customer
     EXCEPT
     SELECT cID, cName FROM purchase p
     )
    UNION
    SELECT cID, cName FROM (
    SELECT cID, cName FROM customer
    EXCEPT
    SELECT cID, cName FROM purchase WHERE sID NOT IN (SELECT sID FROM store WHERE sName = "Coop")
    )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:35:32
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
     SELECT cID FROM customer 
     EXCEPT
     SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
     SELECT cID FROM customer
     EXCEPT
     SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Coop")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:35:33
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 176  183   Nikki
#[Out]# 177  185    Nick
#[Out]# 178  186  Angela
#[Out]# 179  188    Pino
#[Out]# 180  189    Koen
#[Out]# 
#[Out]# [181 rows x 2 columns]
# Sun, 29 Nov 2020 11:35:42
df[0:30]
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     1       Sem
#[Out]# 2     2     Lucas
#[Out]# 3     3      Finn
#[Out]# 4     4      Daan
#[Out]# 5     5      Levi
#[Out]# 6     6     Milan
#[Out]# 7     7      Bram
#[Out]# 8     8      Liam
#[Out]# 9     9    Thomas
#[Out]# 10   10       Sam
#[Out]# 11   12      Adam
#[Out]# 12   13     James
#[Out]# 13   14       Max
#[Out]# 14   15      Noud
#[Out]# 15   16    Julian
#[Out]# 16   17       Dex
#[Out]# 17   18      Hugo
#[Out]# 18   19      Lars
#[Out]# 19   20      Gijs
#[Out]# 20   21  Benjamin
#[Out]# 21   22      Mats
#[Out]# 22   23       Jan
#[Out]# 23   25     Mason
#[Out]# 24   26    Jayden
#[Out]# 25   27       Tim
#[Out]# 26   28      Siem
#[Out]# 27   29     Ruben
#[Out]# 28   30      Teun
#[Out]# 29   31   Olivier
# Sun, 29 Nov 2020 11:35:54
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
     SELECT cID FROM customer 
     EXCEPT
     SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
     SELECT cID FROM customer
     EXCEPT
     SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Jumbo")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:35:54
df[0:30]
#[Out]#     cID    cName
#[Out]# 0     0     Noah
#[Out]# 1     1      Sem
#[Out]# 2     2    Lucas
#[Out]# 3     3     Finn
#[Out]# 4     4     Daan
#[Out]# 5     5     Levi
#[Out]# 6     6    Milan
#[Out]# 7     7     Bram
#[Out]# 8     8     Liam
#[Out]# 9     9   Thomas
#[Out]# 10   10      Sam
#[Out]# 11   11    Thijs
#[Out]# 12   12     Adam
#[Out]# 13   13    James
#[Out]# 14   14      Max
#[Out]# 15   15     Noud
#[Out]# 16   16   Julian
#[Out]# 17   17      Dex
#[Out]# 18   20     Gijs
#[Out]# 19   22     Mats
#[Out]# 20   23      Jan
#[Out]# 21   24     Luca
#[Out]# 22   25    Mason
#[Out]# 23   26   Jayden
#[Out]# 24   27      Tim
#[Out]# 25   28     Siem
#[Out]# 26   29    Ruben
#[Out]# 27   30     Teun
#[Out]# 28   31  Olivier
#[Out]# 29   32    Vince
# Sun, 29 Nov 2020 11:36:05
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
     SELECT cID FROM customer 
     EXCEPT
     SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
     SELECT cID FROM customer
     EXCEPT
     SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Lidl")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:36:06
df[0:30]
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     1       Sem
#[Out]# 2     3      Finn
#[Out]# 3     4      Daan
#[Out]# 4     5      Levi
#[Out]# 5     6     Milan
#[Out]# 6     8      Liam
#[Out]# 7     9    Thomas
#[Out]# 8    10       Sam
#[Out]# 9    11     Thijs
#[Out]# 10   12      Adam
#[Out]# 11   13     James
#[Out]# 12   14       Max
#[Out]# 13   15      Noud
#[Out]# 14   16    Julian
#[Out]# 15   17       Dex
#[Out]# 16   18      Hugo
#[Out]# 17   19      Lars
#[Out]# 18   20      Gijs
#[Out]# 19   21  Benjamin
#[Out]# 20   22      Mats
#[Out]# 21   23       Jan
#[Out]# 22   24      Luca
#[Out]# 23   26    Jayden
#[Out]# 24   27       Tim
#[Out]# 25   28      Siem
#[Out]# 26   29     Ruben
#[Out]# 27   30      Teun
#[Out]# 28   31   Olivier
#[Out]# 29   32     Vince
# Sun, 29 Nov 2020 11:39:58
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Lidl")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:39:58
df[0:30]
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     1       Sem
#[Out]# 2     3      Finn
#[Out]# 3     4      Daan
#[Out]# 4     5      Levi
#[Out]# 5     6     Milan
#[Out]# 6     8      Liam
#[Out]# 7     9    Thomas
#[Out]# 8    10       Sam
#[Out]# 9    11     Thijs
#[Out]# 10   12      Adam
#[Out]# 11   13     James
#[Out]# 12   14       Max
#[Out]# 13   15      Noud
#[Out]# 14   16    Julian
#[Out]# 15   17       Dex
#[Out]# 16   18      Hugo
#[Out]# 17   19      Lars
#[Out]# 18   20      Gijs
#[Out]# 19   21  Benjamin
#[Out]# 20   22      Mats
#[Out]# 21   23       Jan
#[Out]# 22   24      Luca
#[Out]# 23   26    Jayden
#[Out]# 24   27       Tim
#[Out]# 25   28      Siem
#[Out]# 26   29     Ruben
#[Out]# 27   30      Teun
#[Out]# 28   31   Olivier
#[Out]# 29   32     Vince
# Sun, 29 Nov 2020 11:40:03
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Dirk")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:40:03
df[0:30]
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     2     Lucas
#[Out]# 2     3      Finn
#[Out]# 3     4      Daan
#[Out]# 4     5      Levi
#[Out]# 5     6     Milan
#[Out]# 6     7      Bram
#[Out]# 7     8      Liam
#[Out]# 8     9    Thomas
#[Out]# 9    10       Sam
#[Out]# 10   11     Thijs
#[Out]# 11   12      Adam
#[Out]# 12   13     James
#[Out]# 13   14       Max
#[Out]# 14   15      Noud
#[Out]# 15   16    Julian
#[Out]# 16   17       Dex
#[Out]# 17   18      Hugo
#[Out]# 18   19      Lars
#[Out]# 19   20      Gijs
#[Out]# 20   21  Benjamin
#[Out]# 21   22      Mats
#[Out]# 22   23       Jan
#[Out]# 23   24      Luca
#[Out]# 24   25     Mason
#[Out]# 25   26    Jayden
#[Out]# 26   27       Tim
#[Out]# 27   28      Siem
#[Out]# 28   29     Ruben
#[Out]# 29   30      Teun
# Sun, 29 Nov 2020 11:40:18
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      2   Lucas
#[Out]# 2      3    Finn
#[Out]# 3      4    Daan
#[Out]# 4      5    Levi
#[Out]# ..   ...     ...
#[Out]# 180  184   Wilko
#[Out]# 181  185    Nick
#[Out]# 182  186  Angela
#[Out]# 183  188    Pino
#[Out]# 184  189    Koen
#[Out]# 
#[Out]# [185 rows x 2 columns]
# Sun, 29 Nov 2020 11:40:22
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Jumbo")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:40:22
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 179  184   Wilko
#[Out]# 180  185    Nick
#[Out]# 181  186  Angela
#[Out]# 182  188    Pino
#[Out]# 183  189    Koen
#[Out]# 
#[Out]# [184 rows x 2 columns]
# Sun, 29 Nov 2020 11:40:26
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Lidl")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:40:27
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      4    Daan
#[Out]# 4      5    Levi
#[Out]# ..   ...     ...
#[Out]# 176  184   Wilko
#[Out]# 177  185    Nick
#[Out]# 178  186  Angela
#[Out]# 179  188    Pino
#[Out]# 180  189    Koen
#[Out]# 
#[Out]# [181 rows x 2 columns]
# Sun, 29 Nov 2020 11:40:32
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Spar")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:40:32
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 185  185    Nick
#[Out]# 186  186  Angela
#[Out]# 187  188    Pino
#[Out]# 188  189    Koen
#[Out]# 189  190  Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 29 Nov 2020 11:40:38
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID = (SELECT sID FROM store WHERE sName = "Coop")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:40:38
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 176  183   Nikki
#[Out]# 177  185    Nick
#[Out]# 178  186  Angela
#[Out]# 179  188    Pino
#[Out]# 180  189    Koen
#[Out]# 
#[Out]# [181 rows x 2 columns]
# Sun, 29 Nov 2020 11:41:54
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:41:55
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Sun, 29 Nov 2020 11:42:06
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Jumbo")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:42:07
df
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# ..   ...      ...
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Sun, 29 Nov 2020 11:42:12
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:44:13
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
     )
    );
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:44:13
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Sun, 29 Nov 2020 11:44:18
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
     )
    )
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:44:18
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Sun, 29 Nov 2020 11:44:20
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
     )
    );
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:44:20
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      3    Finn
#[Out]# 3      6   Milan
#[Out]# 4      7    Bram
#[Out]# ..   ...     ...
#[Out]# 111  183   Nikki
#[Out]# 112  185    Nick
#[Out]# 113  186  Angela
#[Out]# 114  188    Pino
#[Out]# 115  189    Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Sun, 29 Nov 2020 11:44:26
query3_3 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
      SELECT cID FROM customer 
      EXCEPT
      SELECT cID FROM purchase
     )
     UNION 
     SELECT cID FROM (
      SELECT cID FROM customer
      EXCEPT
      SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Dirk")
     )
    );
'''
df = pd.read_sql_query(query3_3, conn)
# Sun, 29 Nov 2020 11:44:27
df
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      2   Lucas
#[Out]# 2      4    Daan
#[Out]# 3      5    Levi
#[Out]# 4      6   Milan
#[Out]# ..   ...     ...
#[Out]# 153  184   Wilko
#[Out]# 154  185    Nick
#[Out]# 155  186  Angela
#[Out]# 156  188    Pino
#[Out]# 157  189    Koen
#[Out]# 
#[Out]# [158 rows x 2 columns]
# Sun, 29 Nov 2020 11:45:58
query3_4 = '''
    SELECT sID FROM store WHERE sName != "Coop"
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     sID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# 5     7
#[Out]# 6     8
#[Out]# 7     9
#[Out]# 8    10
#[Out]# 9    11
#[Out]# 10   12
#[Out]# 11   15
#[Out]# 12   16
#[Out]# 13   17
#[Out]# 14   18
#[Out]# 15   20
#[Out]# 16   22
#[Out]# 17   23
#[Out]# 18   24
#[Out]# 19   25
#[Out]# 20   26
#[Out]# 21   27
#[Out]# 22   28
#[Out]# 23   29
#[Out]# 24   30
#[Out]# 25   32
#[Out]# 26   33
#[Out]# 27   35
#[Out]# 28   36
#[Out]# 29   37
#[Out]# 30   38
#[Out]# 31   39
#[Out]# 32   40
#[Out]# 33   41
#[Out]# 34   42
#[Out]# 35   44
#[Out]# 36   46
#[Out]# 37   48
#[Out]# 38   49
#[Out]# 39   50
#[Out]# 40   52
#[Out]# 41   54
#[Out]# 42   56
#[Out]# 43   57
#[Out]# 44   58
#[Out]# 45   59
#[Out]# 46   60
#[Out]# 47   61
#[Out]# 48   62
#[Out]# 49   63
# Sun, 29 Nov 2020 11:46:05
query3_4 = '''
    SELECT sID FROM store WHERE sName = "Coop"
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     sID
#[Out]# 0     0
#[Out]# 1     6
#[Out]# 2    13
#[Out]# 3    14
#[Out]# 4    19
#[Out]# 5    21
#[Out]# 6    31
#[Out]# 7    34
#[Out]# 8    43
#[Out]# 9    45
#[Out]# 10   47
#[Out]# 11   51
#[Out]# 12   53
#[Out]# 13   55
# Sun, 29 Nov 2020 11:46:09
query3_4 = '''
    SELECT sID FROM store WHERE sName != "Coop"
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     sID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# 5     7
#[Out]# 6     8
#[Out]# 7     9
#[Out]# 8    10
#[Out]# 9    11
#[Out]# 10   12
#[Out]# 11   15
#[Out]# 12   16
#[Out]# 13   17
#[Out]# 14   18
#[Out]# 15   20
#[Out]# 16   22
#[Out]# 17   23
#[Out]# 18   24
#[Out]# 19   25
#[Out]# 20   26
#[Out]# 21   27
#[Out]# 22   28
#[Out]# 23   29
#[Out]# 24   30
#[Out]# 25   32
#[Out]# 26   33
#[Out]# 27   35
#[Out]# 28   36
#[Out]# 29   37
#[Out]# 30   38
#[Out]# 31   39
#[Out]# 32   40
#[Out]# 33   41
#[Out]# 34   42
#[Out]# 35   44
#[Out]# 36   46
#[Out]# 37   48
#[Out]# 38   49
#[Out]# 39   50
#[Out]# 40   52
#[Out]# 41   54
#[Out]# 42   56
#[Out]# 43   57
#[Out]# 44   58
#[Out]# 45   59
#[Out]# 46   60
#[Out]# 47   61
#[Out]# 48   62
#[Out]# 49   63
# Sun, 29 Nov 2020 11:48:32
query3_4 = '''
    SELECT DISTINCT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop");
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     2
#[Out]# 1     4
#[Out]# 2     5
#[Out]# 3     8
#[Out]# 4    10
#[Out]# ..  ...
#[Out]# 69  179
#[Out]# 70  180
#[Out]# 71  181
#[Out]# 72  184
#[Out]# 73  190
#[Out]# 
#[Out]# [74 rows x 1 columns]
# Sun, 29 Nov 2020 11:59:54
query3_4 = '''
SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      2
#[Out]# 1      2
#[Out]# 2      2
#[Out]# 3      4
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 127  190
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 
#[Out]# [132 rows x 1 columns]
# Sun, 29 Nov 2020 12:00:07
query3_4 = '''
SELECT DISTINCT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     2
#[Out]# 1     4
#[Out]# 2     5
#[Out]# 3     8
#[Out]# 4    10
#[Out]# ..  ...
#[Out]# 69  179
#[Out]# 70  180
#[Out]# 71  181
#[Out]# 72  184
#[Out]# 73  190
#[Out]# 
#[Out]# [74 rows x 1 columns]
# Sun, 29 Nov 2020 12:02:01
query3_4 = '''
SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName != "Coop")
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# ..   ...
#[Out]# 372  190
#[Out]# 373  190
#[Out]# 374  190
#[Out]# 375  190
#[Out]# 376  190
#[Out]# 
#[Out]# [377 rows x 1 columns]
# Sun, 29 Nov 2020 12:03:04
query3_4 = '''
    SELECT cID FROM (
    SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
    EXCEPT
    SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName != "Coop")
    );
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     8
#[Out]# 1    10
#[Out]# 2    11
#[Out]# 3    26
#[Out]# 4    28
#[Out]# 5    55
#[Out]# 6    76
#[Out]# 7    88
#[Out]# 8    99
#[Out]# 9   103
#[Out]# 10  131
#[Out]# 11  135
#[Out]# 12  151
#[Out]# 13  184
# Sun, 29 Nov 2020 12:04:58
query3_4 = '''
    SELECT DISTINCT cID, cName FROM customer WHERE cID IN (
     SELECT cID FROM (
       SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName = "Coop")
      EXCEPT
       SELECT cID FROM purchase WHERE sID IN (SELECT sID FROM store WHERE sName != "Coop")
     )
    );
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID      cName
#[Out]# 0     8       Liam
#[Out]# 1    10        Sam
#[Out]# 2    11      Thijs
#[Out]# 3    26     Jayden
#[Out]# 4    28       Siem
#[Out]# 5    55      Aiden
#[Out]# 6    76  Alexander
#[Out]# 7    88      Joris
#[Out]# 8    99       Anna
#[Out]# 9   103      Lotte
#[Out]# 10  131        Amy
#[Out]# 11  135      Sofia
#[Out]# 12  151       Jill
#[Out]# 13  184      Wilko

   Bud1            %                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 @                                              @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   E   %                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       DSDB                             `                                                     @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              

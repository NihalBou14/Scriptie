# IPython log file

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Tue, 01 Dec 2020 21:32:53
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 01 Dec 2020 21:32:53
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7f9ef778de30>

# IPython log file

# Tue, 01 Dec 2020 21:47:39

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 

# Tue, 01 Dec 2020 21:47:39

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# Tue, 01 Dec 2020 21:48:28

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 

# Tue, 01 Dec 2020 21:48:34

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 

# Tue, 01 Dec 2020 21:48:48

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# Tue, 01 Dec 2020 21:49:07

query3_2 = '''
    SELECT *
'''

pd.read_sql_query(query3_2, conn)

# Tue, 01 Dec 2020 21:49:26

query3_2 = '''
    SELECT *
    FROM WORK 
'''

pd.read_sql_query(query3_2, conn)

# Tue, 01 Dec 2020 21:49:38

query3_2 = '''
    SELECT *
    FROM WORKS
'''

pd.read_sql_query(query3_2, conn)

# Tue, 01 Dec 2020 21:50:46

query3_2 = '''
    SELECT *
    FROM product
'''

pd.read_sql_query(query3_2, conn)

#[Out]#     pID             pName suffix
#[Out]# 0     0       Cashew Nuts       
#[Out]# 1     1        Mixed Nuts       
#[Out]# 2     2          Potatoes       
#[Out]# 3     3      Green Pepper       
#[Out]# 4     4            Onions       
#[Out]# 5     5         Mushrooms       
#[Out]# 6     6           Carrots       
#[Out]# 7     7          Tomatoes       
#[Out]# 8     8  Hot Dog Sausages       
#[Out]# 9     9           Bananas       
#[Out]# 10   10             Water       
#[Out]# 11   11              Milk       
#[Out]# 12   12              Beef       
#[Out]# 13   13              Eggs       
#[Out]# 14   14            Apples       
#[Out]# 15   15         Cucumbers       
#[Out]# 16   16              Rice       
#[Out]# 17   17             Bread       
#[Out]# 18   18            Cheese       
#[Out]# 19   19              Coca       
#[Out]# 20   20             Fanta       
#[Out]# 21   21            Coffee       
#[Out]# 22   22               Tea       
#[Out]# 23   23   Spiced Biscuits       
#[Out]# 24   24           Oranges       
#[Out]# 25   25            Donuts       
#[Out]# 26   26             Pasta       
#[Out]# 27   27             Pizza       
#[Out]# 28   28           Lasanga       
#[Out]# 29   29            Salmon       
#[Out]# 30   30           Ketchup       
#[Out]# 31   31   French baguette       
# Tue, 01 Dec 2020 21:57:13

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID 
    WHERE s.date = p.date and s.date = "2018"
'''

pd.read_sql_query(query3_2, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 21:57:22

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date and s.date = 2018
'''

pd.read_sql_query(query3_2, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 21:57:29

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date
'''

pd.read_sql_query(query3_2, conn)

#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 21:57:39

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date
'''

pd.read_sql_query(query3_2, conn)

#[Out]#         cName  cID        date
#[Out]# 0         Sem    1  2018-08-20
#[Out]# 1         Sem    1  2018-08-21
#[Out]# 2       Lucas    2  2018-08-16
#[Out]# 3       Lucas    2  2018-08-17
#[Out]# 4        Finn    3  2018-08-18
#[Out]# 5        Finn    3  2018-08-19
#[Out]# 6        Levi    5  2018-08-17
#[Out]# 7        Levi    5  2018-08-22
#[Out]# 8        Levi    5  2018-08-23
#[Out]# 9        Bram    7  2018-08-23
#[Out]# 10       Bram    7  2018-08-24
#[Out]# 11       Bram    7  2018-08-25
#[Out]# 12       Bram    7  2018-08-26
#[Out]# 13       Liam    8  2018-08-16
#[Out]# 14        Sam   10  2018-08-27
#[Out]# 15      Thijs   11  2018-08-25
#[Out]# 16      James   13  2018-08-17
#[Out]# 17      James   13  2018-08-25
#[Out]# 18      James   13  2018-08-26
#[Out]# 19      James   13  2018-08-27
#[Out]# 20       Noud   15  2018-08-27
#[Out]# 21        Dex   17  2018-08-19
#[Out]# 22       Hugo   18  2018-08-16
#[Out]# 23       Hugo   18  2018-08-18
#[Out]# 24       Lars   19  2018-08-17
#[Out]# 25       Lars   19  2018-08-18
#[Out]# 26       Gijs   20  2018-08-17
#[Out]# 27       Gijs   20  2018-08-18
#[Out]# 28   Benjamin   21  2018-08-15
#[Out]# 29       Mats   22  2018-08-27
#[Out]# ..        ...  ...         ...
#[Out]# 156     Hanna  165  2018-08-23
#[Out]# 157     Hanna  165  2018-08-24
#[Out]# 158    Veerle  167  2018-08-18
#[Out]# 159    Veerle  167  2018-08-19
#[Out]# 160    Veerle  167  2018-08-20
#[Out]# 161    Veerle  167  2018-08-21
#[Out]# 162    Veerle  167  2018-08-15
#[Out]# 163      Kiki  168  2018-08-16
#[Out]# 164      Lily  169  2018-08-16
#[Out]# 165      Lily  169  2018-08-17
#[Out]# 166      Lily  169  2018-08-18
#[Out]# 167      Lily  169  2018-08-19
#[Out]# 168      Lily  169  2018-08-20
#[Out]# 169      Lily  169  2018-08-26
#[Out]# 170      Lily  169  2018-08-27
#[Out]# 171      Iris  170  2018-08-16
#[Out]# 172     Tessa  171  2018-08-20
#[Out]# 173      Lana  172  2018-08-27
#[Out]# 174      Lana  172  2018-08-24
#[Out]# 175       Sam  175  2018-08-19
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Amira  176  2018-08-25
#[Out]# 178     Amira  176  2018-08-26
#[Out]# 179      Elif  178  2018-08-27
#[Out]# 180      Juul  179  2018-08-24
#[Out]# 181      Juul  179  2018-08-22
#[Out]# 182     Merel  180  2018-08-26
#[Out]# 183     Merel  180  2018-08-27
#[Out]# 184      Liva  181  2018-08-24
#[Out]# 185      Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Tue, 01 Dec 2020 21:57:56

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date and s.date = %2018%
'''

pd.read_sql_query(query3_2, conn)

# Tue, 01 Dec 2020 21:58:03

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date and s.date like %2018%
'''

pd.read_sql_query(query3_2, conn)

# Tue, 01 Dec 2020 21:58:49

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date
'''

pd.read_sql_query(query3_2, conn)

#[Out]#         cName  cID        date
#[Out]# 0         Sem    1  2018-08-20
#[Out]# 1         Sem    1  2018-08-21
#[Out]# 2       Lucas    2  2018-08-16
#[Out]# 3       Lucas    2  2018-08-17
#[Out]# 4        Finn    3  2018-08-18
#[Out]# 5        Finn    3  2018-08-19
#[Out]# 6        Levi    5  2018-08-17
#[Out]# 7        Levi    5  2018-08-22
#[Out]# 8        Levi    5  2018-08-23
#[Out]# 9        Bram    7  2018-08-23
#[Out]# 10       Bram    7  2018-08-24
#[Out]# 11       Bram    7  2018-08-25
#[Out]# 12       Bram    7  2018-08-26
#[Out]# 13       Liam    8  2018-08-16
#[Out]# 14        Sam   10  2018-08-27
#[Out]# 15      Thijs   11  2018-08-25
#[Out]# 16      James   13  2018-08-17
#[Out]# 17      James   13  2018-08-25
#[Out]# 18      James   13  2018-08-26
#[Out]# 19      James   13  2018-08-27
#[Out]# 20       Noud   15  2018-08-27
#[Out]# 21        Dex   17  2018-08-19
#[Out]# 22       Hugo   18  2018-08-16
#[Out]# 23       Hugo   18  2018-08-18
#[Out]# 24       Lars   19  2018-08-17
#[Out]# 25       Lars   19  2018-08-18
#[Out]# 26       Gijs   20  2018-08-17
#[Out]# 27       Gijs   20  2018-08-18
#[Out]# 28   Benjamin   21  2018-08-15
#[Out]# 29       Mats   22  2018-08-27
#[Out]# ..        ...  ...         ...
#[Out]# 156     Hanna  165  2018-08-23
#[Out]# 157     Hanna  165  2018-08-24
#[Out]# 158    Veerle  167  2018-08-18
#[Out]# 159    Veerle  167  2018-08-19
#[Out]# 160    Veerle  167  2018-08-20
#[Out]# 161    Veerle  167  2018-08-21
#[Out]# 162    Veerle  167  2018-08-15
#[Out]# 163      Kiki  168  2018-08-16
#[Out]# 164      Lily  169  2018-08-16
#[Out]# 165      Lily  169  2018-08-17
#[Out]# 166      Lily  169  2018-08-18
#[Out]# 167      Lily  169  2018-08-19
#[Out]# 168      Lily  169  2018-08-20
#[Out]# 169      Lily  169  2018-08-26
#[Out]# 170      Lily  169  2018-08-27
#[Out]# 171      Iris  170  2018-08-16
#[Out]# 172     Tessa  171  2018-08-20
#[Out]# 173      Lana  172  2018-08-27
#[Out]# 174      Lana  172  2018-08-24
#[Out]# 175       Sam  175  2018-08-19
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Amira  176  2018-08-25
#[Out]# 178     Amira  176  2018-08-26
#[Out]# 179      Elif  178  2018-08-27
#[Out]# 180      Juul  179  2018-08-24
#[Out]# 181      Juul  179  2018-08-22
#[Out]# 182     Merel  180  2018-08-26
#[Out]# 183     Merel  180  2018-08-27
#[Out]# 184      Liva  181  2018-08-24
#[Out]# 185      Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Tue, 01 Dec 2020 21:59:09

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date and s.date like '2018%'
'''

pd.read_sql_query(query3_2, conn)

#[Out]#         cName  cID        date
#[Out]# 0         Sem    1  2018-08-20
#[Out]# 1         Sem    1  2018-08-21
#[Out]# 2       Lucas    2  2018-08-16
#[Out]# 3       Lucas    2  2018-08-17
#[Out]# 4        Finn    3  2018-08-18
#[Out]# 5        Finn    3  2018-08-19
#[Out]# 6        Levi    5  2018-08-17
#[Out]# 7        Levi    5  2018-08-22
#[Out]# 8        Levi    5  2018-08-23
#[Out]# 9        Bram    7  2018-08-23
#[Out]# 10       Bram    7  2018-08-24
#[Out]# 11       Bram    7  2018-08-25
#[Out]# 12       Bram    7  2018-08-26
#[Out]# 13       Liam    8  2018-08-16
#[Out]# 14        Sam   10  2018-08-27
#[Out]# 15      Thijs   11  2018-08-25
#[Out]# 16      James   13  2018-08-17
#[Out]# 17      James   13  2018-08-25
#[Out]# 18      James   13  2018-08-26
#[Out]# 19      James   13  2018-08-27
#[Out]# 20       Noud   15  2018-08-27
#[Out]# 21        Dex   17  2018-08-19
#[Out]# 22       Hugo   18  2018-08-16
#[Out]# 23       Hugo   18  2018-08-18
#[Out]# 24       Lars   19  2018-08-17
#[Out]# 25       Lars   19  2018-08-18
#[Out]# 26       Gijs   20  2018-08-17
#[Out]# 27       Gijs   20  2018-08-18
#[Out]# 28   Benjamin   21  2018-08-15
#[Out]# 29       Mats   22  2018-08-27
#[Out]# ..        ...  ...         ...
#[Out]# 156     Hanna  165  2018-08-23
#[Out]# 157     Hanna  165  2018-08-24
#[Out]# 158    Veerle  167  2018-08-18
#[Out]# 159    Veerle  167  2018-08-19
#[Out]# 160    Veerle  167  2018-08-20
#[Out]# 161    Veerle  167  2018-08-21
#[Out]# 162    Veerle  167  2018-08-15
#[Out]# 163      Kiki  168  2018-08-16
#[Out]# 164      Lily  169  2018-08-16
#[Out]# 165      Lily  169  2018-08-17
#[Out]# 166      Lily  169  2018-08-18
#[Out]# 167      Lily  169  2018-08-19
#[Out]# 168      Lily  169  2018-08-20
#[Out]# 169      Lily  169  2018-08-26
#[Out]# 170      Lily  169  2018-08-27
#[Out]# 171      Iris  170  2018-08-16
#[Out]# 172     Tessa  171  2018-08-20
#[Out]# 173      Lana  172  2018-08-27
#[Out]# 174      Lana  172  2018-08-24
#[Out]# 175       Sam  175  2018-08-19
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Amira  176  2018-08-25
#[Out]# 178     Amira  176  2018-08-26
#[Out]# 179      Elif  178  2018-08-27
#[Out]# 180      Juul  179  2018-08-24
#[Out]# 181      Juul  179  2018-08-22
#[Out]# 182     Merel  180  2018-08-26
#[Out]# 183     Merel  180  2018-08-27
#[Out]# 184      Liva  181  2018-08-24
#[Out]# 185      Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]
# Tue, 01 Dec 2020 22:05:58



query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, shoppinglist as s, purchase as p 
    WHERE s.cID = c.cID and p.cID = c.cID and s.date = p.date and s.date like '2018%'
    
'''

pd.read_sql_query(query3_2, conn)

#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Tue, 01 Dec 2020 22:08:50

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 22:09:30

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:09:47

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Kumar"
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 22:09:57

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> ""
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 22:10:06

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Jumbo"
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 94       Lena  137
#[Out]# 95      Elise  139
#[Out]# 96        Ivy  144
#[Out]# 97       Fien  145
#[Out]# 98     Isabel  147
#[Out]# 99      Lizzy  149
#[Out]# 100      Jill  151
#[Out]# 101      Anne  152
#[Out]# 102      Puck  157
#[Out]# 103     Fenne  159
#[Out]# 104     Floor  161
#[Out]# 105     Elena  162
#[Out]# 106      Cato  163
#[Out]# 107     Hanna  165
#[Out]# 108    Veerle  167
#[Out]# 109      Kiki  168
#[Out]# 110      Lily  169
#[Out]# 111      Iris  170
#[Out]# 112     Tessa  171
#[Out]# 113      Lana  172
#[Out]# 114       Sam  175
#[Out]# 115     Amira  176
#[Out]# 116     Eline  177
#[Out]# 117      Elif  178
#[Out]# 118      Juul  179
#[Out]# 119     Merel  180
#[Out]# 120      Liva  181
#[Out]# 121   Johanna  182
#[Out]# 122     Wilko  184
#[Out]# 123    Kostas  190
#[Out]# 
#[Out]# [124 rows x 2 columns]
# Tue, 01 Dec 2020 22:12:41

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Jumbo"*/
    
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE not exists()
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:13:25

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Jumbo"*/

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase
    
    )
'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID
#[Out]# 0      Milan    6
#[Out]# 1     Thomas    9
#[Out]# 2       Adam   12
#[Out]# 3        Max   14
#[Out]# 4        Jan   23
#[Out]# 5      Vince   32
#[Out]# 6       Boaz   36
#[Out]# 7      Fedde   46
#[Out]# 8       Tygo   48
#[Out]# 9        Cas   49
#[Out]# 10       Pim   50
#[Out]# 11       Job   53
#[Out]# 12       Jax   54
#[Out]# 13    Tobias   56
#[Out]# 14    Morris   61
#[Out]# 15      Abel   62
#[Out]# 16    Pepijn   65
#[Out]# 17      Owen   73
#[Out]# 18    Samuel   74
#[Out]# 19    Joshua   79
#[Out]# 20     Simon   81
#[Out]# 21     Melle   83
#[Out]# 22     Jelle   87
#[Out]# 23  Johannes   89
#[Out]# 24     Oscar   93
#[Out]# 25     Julia   98
#[Out]# 26       Eva  101
#[Out]# 27       Evi  102
#[Out]# 28      Nora  105
#[Out]# 29     Fleur  106
#[Out]# 30    Olivia  107
#[Out]# 31      Maud  114
#[Out]# 32      Nova  115
#[Out]# 33      Roos  117
#[Out]# 34     Sarah  120
#[Out]# 35       Isa  121
#[Out]# 36       Noa  125
#[Out]# 37     Sanne  130
#[Out]# 38    Hannah  132
#[Out]# 39     Maria  138
#[Out]# 40      Vera  140
#[Out]# 41       Mia  141
#[Out]# 42        Bo  142
#[Out]# 43     Naomi  143
#[Out]# 44     Norah  146
#[Out]# 45  Isabella  148
#[Out]# 46     Julie  150
#[Out]# 47     Amber  153
#[Out]# 48    Benthe  154
#[Out]# 49     Linde  155
#[Out]# 50      Luna  156
#[Out]# 51      Rosa  158
#[Out]# 52      Lara  160
#[Out]# 53       Evy  164
#[Out]# 54   Rosalie  166
#[Out]# 55     Livia  173
#[Out]# 56      Romy  174
#[Out]# 57     Nikki  183
# Tue, 01 Dec 2020 22:13:57

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> ""

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 22:14:28

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop"

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0       Lucas    2
#[Out]# 1        Daan    4
#[Out]# 2        Levi    5
#[Out]# 3        Liam    8
#[Out]# 4         Sam   10
#[Out]# 5       Thijs   11
#[Out]# 6      Julian   16
#[Out]# 7         Dex   17
#[Out]# 8        Hugo   18
#[Out]# 9        Gijs   20
#[Out]# 10   Benjamin   21
#[Out]# 11       Luca   24
#[Out]# 12     Jayden   26
#[Out]# 13        Tim   27
#[Out]# 14       Siem   28
#[Out]# 15      Ruben   29
#[Out]# 16       Sven   33
#[Out]# 17      Stijn   35
#[Out]# 18       Jack   39
#[Out]# 19       Tijn   42
#[Out]# 20       Ties   51
#[Out]# 21      Aiden   55
#[Out]# 22     Nathan   57
#[Out]# 23       Joep   59
#[Out]# 24      Rayan   67
#[Out]# 25       Dean   71
#[Out]# 26       Jace   75
#[Out]# 27  Alexander   76
#[Out]# 28       Mick   78
#[Out]# 29      Dylan   82
#[Out]# ..        ...  ...
#[Out]# 44      Lieke  116
#[Out]# 45       Lisa  118
#[Out]# 46       Elin  122
#[Out]# 47      Milou  123
#[Out]# 48      Sofie  124
#[Out]# 49      Emily  127
#[Out]# 50      Esmee  129
#[Out]# 51        Amy  131
#[Out]# 52     Sophia  133
#[Out]# 53       Ella  134
#[Out]# 54      Sofia  135
#[Out]# 55      Elise  139
#[Out]# 56        Ivy  144
#[Out]# 57     Isabel  147
#[Out]# 58       Jill  151
#[Out]# 59       Anne  152
#[Out]# 60      Floor  161
#[Out]# 61      Elena  162
#[Out]# 62       Cato  163
#[Out]# 63      Hanna  165
#[Out]# 64       Lily  169
#[Out]# 65       Lana  172
#[Out]# 66      Amira  176
#[Out]# 67      Eline  177
#[Out]# 68       Elif  178
#[Out]# 69       Juul  179
#[Out]# 70      Merel  180
#[Out]# 71       Liva  181
#[Out]# 72      Wilko  184
#[Out]# 73     Kostas  190
#[Out]# 
#[Out]# [74 rows x 2 columns]
# Tue, 01 Dec 2020 22:15:06

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:15:45

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:15:50

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 22:16:18

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> ""

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 22:17:50

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:18:42

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> ""



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 22:23:13

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Tue, 01 Dec 2020 22:23:27

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID 

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Tue, 01 Dec 2020 22:23:49

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop"

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0       Lucas    2
#[Out]# 1        Daan    4
#[Out]# 2        Levi    5
#[Out]# 3        Liam    8
#[Out]# 4         Sam   10
#[Out]# 5       Thijs   11
#[Out]# 6      Julian   16
#[Out]# 7         Dex   17
#[Out]# 8        Hugo   18
#[Out]# 9        Gijs   20
#[Out]# 10   Benjamin   21
#[Out]# 11       Luca   24
#[Out]# 12     Jayden   26
#[Out]# 13        Tim   27
#[Out]# 14       Siem   28
#[Out]# 15      Ruben   29
#[Out]# 16       Sven   33
#[Out]# 17      Stijn   35
#[Out]# 18       Jack   39
#[Out]# 19       Tijn   42
#[Out]# 20       Ties   51
#[Out]# 21      Aiden   55
#[Out]# 22     Nathan   57
#[Out]# 23       Joep   59
#[Out]# 24      Rayan   67
#[Out]# 25       Dean   71
#[Out]# 26       Jace   75
#[Out]# 27  Alexander   76
#[Out]# 28       Mick   78
#[Out]# 29      Dylan   82
#[Out]# ..        ...  ...
#[Out]# 44      Lieke  116
#[Out]# 45       Lisa  118
#[Out]# 46       Elin  122
#[Out]# 47      Milou  123
#[Out]# 48      Sofie  124
#[Out]# 49      Emily  127
#[Out]# 50      Esmee  129
#[Out]# 51        Amy  131
#[Out]# 52     Sophia  133
#[Out]# 53       Ella  134
#[Out]# 54      Sofia  135
#[Out]# 55      Elise  139
#[Out]# 56        Ivy  144
#[Out]# 57     Isabel  147
#[Out]# 58       Jill  151
#[Out]# 59       Anne  152
#[Out]# 60      Floor  161
#[Out]# 61      Elena  162
#[Out]# 62       Cato  163
#[Out]# 63      Hanna  165
#[Out]# 64       Lily  169
#[Out]# 65       Lana  172
#[Out]# 66      Amira  176
#[Out]# 67      Eline  177
#[Out]# 68       Elif  178
#[Out]# 69       Juul  179
#[Out]# 70      Merel  180
#[Out]# 71       Liva  181
#[Out]# 72      Wilko  184
#[Out]# 73     Kostas  190
#[Out]# 
#[Out]# [74 rows x 2 columns]
# Tue, 01 Dec 2020 22:23:57

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:24:25

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:26:42

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID exist in (SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )) 



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:26:57

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID EXISTS in (SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )) 



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:27:09

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID EXISTS (SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    ))



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:27:17

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    ))



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:27:28

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (SELECT DISTINCT c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    ))



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0       Milan    6
#[Out]# 1      Thomas    9
#[Out]# 2        Adam   12
#[Out]# 3         Max   14
#[Out]# 4         Jan   23
#[Out]# 5       Vince   32
#[Out]# 6        Boaz   36
#[Out]# 7       Fedde   46
#[Out]# 8        Tygo   48
#[Out]# 9         Cas   49
#[Out]# 10        Pim   50
#[Out]# 11        Job   53
#[Out]# 12        Jax   54
#[Out]# 13     Tobias   56
#[Out]# 14     Morris   61
#[Out]# 15       Abel   62
#[Out]# 16     Pepijn   65
#[Out]# 17       Owen   73
#[Out]# 18     Samuel   74
#[Out]# 19     Joshua   79
#[Out]# 20      Simon   81
#[Out]# 21      Melle   83
#[Out]# 22      Jelle   87
#[Out]# 23   Johannes   89
#[Out]# 24      Oscar   93
#[Out]# 25      Julia   98
#[Out]# 26        Eva  101
#[Out]# 27        Evi  102
#[Out]# 28       Nora  105
#[Out]# 29      Fleur  106
#[Out]# ..        ...  ...
#[Out]# 146       Ivy  144
#[Out]# 147      Fien  145
#[Out]# 148    Isabel  147
#[Out]# 149     Lizzy  149
#[Out]# 150      Anne  152
#[Out]# 151      Puck  157
#[Out]# 152     Fenne  159
#[Out]# 153     Floor  161
#[Out]# 154     Elena  162
#[Out]# 155      Cato  163
#[Out]# 156     Hanna  165
#[Out]# 157    Veerle  167
#[Out]# 158      Kiki  168
#[Out]# 159      Lily  169
#[Out]# 160      Iris  170
#[Out]# 161     Tessa  171
#[Out]# 162      Lana  172
#[Out]# 163       Sam  175
#[Out]# 164     Amira  176
#[Out]# 165     Eline  177
#[Out]# 166      Elif  178
#[Out]# 167      Juul  179
#[Out]# 168     Merel  180
#[Out]# 169      Liva  181
#[Out]# 170   Johanna  182
#[Out]# 171      Nick  185
#[Out]# 172    Angela  186
#[Out]# 173      Pino  188
#[Out]# 174      Koen  189
#[Out]# 175    Kostas  190
#[Out]# 
#[Out]# [176 rows x 2 columns]
# Tue, 01 Dec 2020 22:28:15

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (SELECT DISTINCT c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    ))



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID        sName
#[Out]# 0       Milan    6         Coop
#[Out]# 1      Thomas    9         Coop
#[Out]# 2        Adam   12         Coop
#[Out]# 3         Max   14         Coop
#[Out]# 4         Jan   23         Coop
#[Out]# 5       Vince   32         Coop
#[Out]# 6        Boaz   36         Coop
#[Out]# 7       Fedde   46         Coop
#[Out]# 8        Tygo   48         Coop
#[Out]# 9         Cas   49         Coop
#[Out]# 10        Pim   50         Coop
#[Out]# 11        Job   53         Coop
#[Out]# 12        Jax   54         Coop
#[Out]# 13     Tobias   56         Coop
#[Out]# 14     Morris   61         Coop
#[Out]# 15       Abel   62         Coop
#[Out]# 16     Pepijn   65         Coop
#[Out]# 17       Owen   73         Coop
#[Out]# 18     Samuel   74         Coop
#[Out]# 19     Joshua   79         Coop
#[Out]# 20      Simon   81         Coop
#[Out]# 21      Melle   83         Coop
#[Out]# 22      Jelle   87         Coop
#[Out]# 23   Johannes   89         Coop
#[Out]# 24      Oscar   93         Coop
#[Out]# 25      Julia   98         Coop
#[Out]# 26        Eva  101         Coop
#[Out]# 27        Evi  102         Coop
#[Out]# 28       Nora  105         Coop
#[Out]# 29      Fleur  106         Coop
#[Out]# ..        ...  ...          ...
#[Out]# 636      Iris  170  Albert Hein
#[Out]# 637      Iris  170         Lidl
#[Out]# 638      Iris  170    Hoogvliet
#[Out]# 639     Tessa  171        Jumbo
#[Out]# 640     Tessa  171  Albert Hein
#[Out]# 641      Lana  172        Jumbo
#[Out]# 642       Sam  175       Sligro
#[Out]# 643       Sam  175         Lidl
#[Out]# 644     Amira  176         Lidl
#[Out]# 645     Amira  176    Hoogvliet
#[Out]# 646     Eline  177    Hoogvliet
#[Out]# 647     Eline  177  Albert Hein
#[Out]# 648      Elif  178       Sligro
#[Out]# 649      Juul  179  Albert Hein
#[Out]# 650      Juul  179         Dirk
#[Out]# 651      Juul  179         Lidl
#[Out]# 652     Merel  180        Jumbo
#[Out]# 653      Liva  181       Sligro
#[Out]# 654   Johanna  182    Hoogvliet
#[Out]# 655   Johanna  182       Sligro
#[Out]# 656      Nick  185        Jumbo
#[Out]# 657    Angela  186        Jumbo
#[Out]# 658      Pino  188        Jumbo
#[Out]# 659      Koen  189        Jumbo
#[Out]# 660    Kostas  190    Hoogvliet
#[Out]# 661    Kostas  190        Jumbo
#[Out]# 662    Kostas  190       Sligro
#[Out]# 663    Kostas  190  Albert Hein
#[Out]# 664    Kostas  190         Lidl
#[Out]# 665    Kostas  190         Dirk
#[Out]# 
#[Out]# [666 rows x 3 columns]
# Tue, 01 Dec 2020 22:28:48

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") 



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]
# Tue, 01 Dec 2020 22:29:52

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID,
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:30:11

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:30:19

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:31:25

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not EXISTS(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:31:30

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID EXISTS(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:31:55

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not in (
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:32:12

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID
#[Out]# 0      Milan    6
#[Out]# 1     Thomas    9
#[Out]# 2       Adam   12
#[Out]# 3        Max   14
#[Out]# 4        Jan   23
#[Out]# 5      Vince   32
#[Out]# 6       Boaz   36
#[Out]# 7      Fedde   46
#[Out]# 8       Tygo   48
#[Out]# 9        Cas   49
#[Out]# 10       Pim   50
#[Out]# 11       Job   53
#[Out]# 12       Jax   54
#[Out]# 13    Tobias   56
#[Out]# 14    Morris   61
#[Out]# 15      Abel   62
#[Out]# 16    Pepijn   65
#[Out]# 17      Owen   73
#[Out]# 18    Samuel   74
#[Out]# 19    Joshua   79
#[Out]# 20     Simon   81
#[Out]# 21     Melle   83
#[Out]# 22     Jelle   87
#[Out]# 23  Johannes   89
#[Out]# 24     Oscar   93
#[Out]# 25     Julia   98
#[Out]# 26       Eva  101
#[Out]# 27       Evi  102
#[Out]# 28      Nora  105
#[Out]# 29     Fleur  106
#[Out]# 30    Olivia  107
#[Out]# 31      Maud  114
#[Out]# 32      Nova  115
#[Out]# 33      Roos  117
#[Out]# 34     Sarah  120
#[Out]# 35       Isa  121
#[Out]# 36       Noa  125
#[Out]# 37     Sanne  130
#[Out]# 38    Hannah  132
#[Out]# 39     Maria  138
#[Out]# 40      Vera  140
#[Out]# 41       Mia  141
#[Out]# 42        Bo  142
#[Out]# 43     Naomi  143
#[Out]# 44     Norah  146
#[Out]# 45  Isabella  148
#[Out]# 46     Julie  150
#[Out]# 47     Amber  153
#[Out]# 48    Benthe  154
#[Out]# 49     Linde  155
#[Out]# 50      Luna  156
#[Out]# 51      Rosa  158
#[Out]# 52      Lara  160
#[Out]# 53       Evy  164
#[Out]# 54   Rosalie  166
#[Out]# 55     Livia  173
#[Out]# 56      Romy  174
#[Out]# 57     Nikki  183
# Tue, 01 Dec 2020 22:32:19

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID        sName
#[Out]# 0      Milan    6         Coop
#[Out]# 1      Milan    6    Hoogvliet
#[Out]# 2      Milan    6        Jumbo
#[Out]# 3      Milan    6       Sligro
#[Out]# 4      Milan    6  Albert Hein
#[Out]# 5      Milan    6         Lidl
#[Out]# 6      Milan    6         Dirk
#[Out]# 7     Thomas    9         Coop
#[Out]# 8     Thomas    9    Hoogvliet
#[Out]# 9     Thomas    9        Jumbo
#[Out]# 10    Thomas    9       Sligro
#[Out]# 11    Thomas    9  Albert Hein
#[Out]# 12    Thomas    9         Lidl
#[Out]# 13    Thomas    9         Dirk
#[Out]# 14      Adam   12         Coop
#[Out]# 15      Adam   12    Hoogvliet
#[Out]# 16      Adam   12        Jumbo
#[Out]# 17      Adam   12       Sligro
#[Out]# 18      Adam   12  Albert Hein
#[Out]# 19      Adam   12         Lidl
#[Out]# 20      Adam   12         Dirk
#[Out]# 21       Max   14         Coop
#[Out]# 22       Max   14    Hoogvliet
#[Out]# 23       Max   14        Jumbo
#[Out]# 24       Max   14       Sligro
#[Out]# 25       Max   14  Albert Hein
#[Out]# 26       Max   14         Lidl
#[Out]# 27       Max   14         Dirk
#[Out]# 28       Jan   23         Coop
#[Out]# 29       Jan   23    Hoogvliet
#[Out]# ..       ...  ...          ...
#[Out]# 376      Evy  164         Lidl
#[Out]# 377      Evy  164         Dirk
#[Out]# 378  Rosalie  166         Coop
#[Out]# 379  Rosalie  166    Hoogvliet
#[Out]# 380  Rosalie  166        Jumbo
#[Out]# 381  Rosalie  166       Sligro
#[Out]# 382  Rosalie  166  Albert Hein
#[Out]# 383  Rosalie  166         Lidl
#[Out]# 384  Rosalie  166         Dirk
#[Out]# 385    Livia  173         Coop
#[Out]# 386    Livia  173    Hoogvliet
#[Out]# 387    Livia  173        Jumbo
#[Out]# 388    Livia  173       Sligro
#[Out]# 389    Livia  173  Albert Hein
#[Out]# 390    Livia  173         Lidl
#[Out]# 391    Livia  173         Dirk
#[Out]# 392     Romy  174         Coop
#[Out]# 393     Romy  174    Hoogvliet
#[Out]# 394     Romy  174        Jumbo
#[Out]# 395     Romy  174       Sligro
#[Out]# 396     Romy  174  Albert Hein
#[Out]# 397     Romy  174         Lidl
#[Out]# 398     Romy  174         Dirk
#[Out]# 399    Nikki  183         Coop
#[Out]# 400    Nikki  183    Hoogvliet
#[Out]# 401    Nikki  183        Jumbo
#[Out]# 402    Nikki  183       Sligro
#[Out]# 403    Nikki  183  Albert Hein
#[Out]# 404    Nikki  183         Lidl
#[Out]# 405    Nikki  183         Dirk
#[Out]# 
#[Out]# [406 rows x 3 columns]
# Tue, 01 Dec 2020 22:32:38

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:32:53

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID        sName
#[Out]# 0      Milan    6       Sligro
#[Out]# 1      Milan    6         Dirk
#[Out]# 2      Milan    6    Hoogvliet
#[Out]# 3      Milan    6  Albert Hein
#[Out]# 4      Milan    6         Lidl
#[Out]# 5      Milan    6         Coop
#[Out]# 6      Milan    6        Jumbo
#[Out]# 7     Thomas    9       Sligro
#[Out]# 8     Thomas    9         Dirk
#[Out]# 9     Thomas    9    Hoogvliet
#[Out]# 10    Thomas    9  Albert Hein
#[Out]# 11    Thomas    9         Lidl
#[Out]# 12    Thomas    9         Coop
#[Out]# 13    Thomas    9        Jumbo
#[Out]# 14      Adam   12       Sligro
#[Out]# 15      Adam   12         Dirk
#[Out]# 16      Adam   12    Hoogvliet
#[Out]# 17      Adam   12  Albert Hein
#[Out]# 18      Adam   12         Lidl
#[Out]# 19      Adam   12         Coop
#[Out]# 20      Adam   12        Jumbo
#[Out]# 21       Max   14       Sligro
#[Out]# 22       Max   14         Dirk
#[Out]# 23       Max   14    Hoogvliet
#[Out]# 24       Max   14  Albert Hein
#[Out]# 25       Max   14         Lidl
#[Out]# 26       Max   14         Coop
#[Out]# 27       Max   14        Jumbo
#[Out]# 28       Jan   23       Sligro
#[Out]# 29       Jan   23         Dirk
#[Out]# ..       ...  ...          ...
#[Out]# 376      Evy  164         Coop
#[Out]# 377      Evy  164        Jumbo
#[Out]# 378  Rosalie  166       Sligro
#[Out]# 379  Rosalie  166         Dirk
#[Out]# 380  Rosalie  166    Hoogvliet
#[Out]# 381  Rosalie  166  Albert Hein
#[Out]# 382  Rosalie  166         Lidl
#[Out]# 383  Rosalie  166         Coop
#[Out]# 384  Rosalie  166        Jumbo
#[Out]# 385    Livia  173       Sligro
#[Out]# 386    Livia  173         Dirk
#[Out]# 387    Livia  173    Hoogvliet
#[Out]# 388    Livia  173  Albert Hein
#[Out]# 389    Livia  173         Lidl
#[Out]# 390    Livia  173         Coop
#[Out]# 391    Livia  173        Jumbo
#[Out]# 392     Romy  174       Sligro
#[Out]# 393     Romy  174         Dirk
#[Out]# 394     Romy  174    Hoogvliet
#[Out]# 395     Romy  174  Albert Hein
#[Out]# 396     Romy  174         Lidl
#[Out]# 397     Romy  174         Coop
#[Out]# 398     Romy  174        Jumbo
#[Out]# 399    Nikki  183       Sligro
#[Out]# 400    Nikki  183         Dirk
#[Out]# 401    Nikki  183    Hoogvliet
#[Out]# 402    Nikki  183  Albert Hein
#[Out]# 403    Nikki  183         Lidl
#[Out]# 404    Nikki  183         Coop
#[Out]# 405    Nikki  183        Jumbo
#[Out]# 
#[Out]# [406 rows x 3 columns]
# Tue, 01 Dec 2020 22:33:16

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID and c.cID = p.pID
'''

pd.read_sql_query(query3_3, conn)

#[Out]#      cName  cID        sName
#[Out]# 0      Max   14         Dirk
#[Out]# 1   Thomas    9    Hoogvliet
#[Out]# 2   Thomas    9       Sligro
#[Out]# 3      Max   14  Albert Hein
#[Out]# 4     Adam   12         Coop
#[Out]# 5    Milan    6         Coop
#[Out]# 6      Max   14    Hoogvliet
#[Out]# 7     Adam   12  Albert Hein
#[Out]# 8    Milan    6    Hoogvliet
#[Out]# 9      Max   14         Coop
#[Out]# 10     Jan   23    Hoogvliet
#[Out]# 11     Jan   23         Coop
#[Out]# 12  Thomas    9        Jumbo
#[Out]# 13     Jan   23        Jumbo
#[Out]# 14   Milan    6         Lidl
#[Out]# 15   Milan    6  Albert Hein
#[Out]# 16     Max   14        Jumbo
#[Out]# 17    Adam   12         Dirk
#[Out]# 18   Milan    6       Sligro
#[Out]# 19     Max   14       Sligro
#[Out]# 20    Adam   12       Sligro
#[Out]# 21  Thomas    9  Albert Hein
#[Out]# 22  Thomas    9         Lidl
#[Out]# 23   Milan    6         Dirk
#[Out]# 24    Adam   12    Hoogvliet
#[Out]# 25  Thomas    9         Coop
#[Out]# 26  Thomas    9         Dirk
#[Out]# 27     Jan   23  Albert Hein
#[Out]# 28     Max   14         Lidl
#[Out]# 29     Jan   23         Lidl
# Tue, 01 Dec 2020 22:33:24

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID and c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:36:45

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID 
'''

pd.read_sql_query(query3_3, conn)

#[Out]#      cID        sName
#[Out]# 0      0       Sligro
#[Out]# 1      1         Dirk
#[Out]# 2      1       Sligro
#[Out]# 3      1    Hoogvliet
#[Out]# 4      1  Albert Hein
#[Out]# 5      1         Lidl
#[Out]# 6      2         Lidl
#[Out]# 7      2       Sligro
#[Out]# 8      2         Coop
#[Out]# 9      3  Albert Hein
#[Out]# 10     3         Dirk
#[Out]# 11     3       Sligro
#[Out]# 12     4    Hoogvliet
#[Out]# 13     4        Jumbo
#[Out]# 14     4         Coop
#[Out]# 15     4       Sligro
#[Out]# 16     4  Albert Hein
#[Out]# 17     5    Hoogvliet
#[Out]# 18     5         Lidl
#[Out]# 19     5         Coop
#[Out]# 20     7       Sligro
#[Out]# 21     7         Lidl
#[Out]# 22     7  Albert Hein
#[Out]# 23     7    Hoogvliet
#[Out]# 24     8         Coop
#[Out]# 25    10         Coop
#[Out]# 26    11         Coop
#[Out]# 27    13         Dirk
#[Out]# 28    13    Hoogvliet
#[Out]# 29    13         Lidl
#[Out]# ..   ...          ...
#[Out]# 304  176         Lidl
#[Out]# 305  176         Coop
#[Out]# 306  176    Hoogvliet
#[Out]# 307  177         Coop
#[Out]# 308  177    Hoogvliet
#[Out]# 309  177  Albert Hein
#[Out]# 310  178         Coop
#[Out]# 311  178       Sligro
#[Out]# 312  179  Albert Hein
#[Out]# 313  179         Dirk
#[Out]# 314  179         Coop
#[Out]# 315  179         Lidl
#[Out]# 316  180         Coop
#[Out]# 317  180        Jumbo
#[Out]# 318  181         Coop
#[Out]# 319  181       Sligro
#[Out]# 320  182    Hoogvliet
#[Out]# 321  182       Sligro
#[Out]# 322  184         Coop
#[Out]# 323  185        Jumbo
#[Out]# 324  186        Jumbo
#[Out]# 325  188        Jumbo
#[Out]# 326  189        Jumbo
#[Out]# 327  190         Coop
#[Out]# 328  190    Hoogvliet
#[Out]# 329  190        Jumbo
#[Out]# 330  190       Sligro
#[Out]# 331  190  Albert Hein
#[Out]# 332  190         Lidl
#[Out]# 333  190         Dirk
#[Out]# 
#[Out]# [334 rows x 2 columns]
# Tue, 01 Dec 2020 22:37:05

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID 
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:37:21

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM purchase as p, store as s
    WHERE p.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:39:44

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM purchase as p, store as s
    WHERE p.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:41:01

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop")


'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]
# Tue, 01 Dec 2020 22:41:35

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName = "")


'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]
# Tue, 01 Dec 2020 22:42:19

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is NULL)


'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]
# Tue, 01 Dec 2020 22:45:01

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" )


'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]
# Tue, 01 Dec 2020 22:45:51

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is NULL)


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:48:13

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" )


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:49:02

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and (p.sID = s.sID or p.sID is NULL) and (s.sName <> "Coop" or p.sID is NULL)


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:49:36

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID or p.cID is NULL) and p.sID = s.sID and (s.sName <> "Coop" or p.sID is NULL)


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:49:45

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID or p.cID is NULL) and p.sID = s.sID and s.sName <> "Coop"


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:50:34

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" 


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:50:46

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or p.sID is NULL)


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 22:51:27

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName is NULL


'''

pd.read_sql_query(query3_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 22:52:09

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    --c.cID = p.cID and p.sID = s.sID and s.sName /*<> "Coop"*/


'''

pd.read_sql_query(query3_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 22:52:12

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    --c.cID = p.cID and p.sID = s.sID and s.sName /*<> "Coop"*/


'''

pd.read_sql_query(query3_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 22:53:14

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */
    
    SELECT 
    

'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:53:26

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */

    SELECT *


'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:53:31

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */

    SELECT *
    from customer


'''

pd.read_sql_query(query3_3, conn)

#[Out]#      cID     cName                street       city
#[Out]# 0      0      Noah             Koestraat    Utrecht
#[Out]# 1      1       Sem      Rozemarijnstraat      Breda
#[Out]# 2      2     Lucas      Oude Leliestraat  Amsterdam
#[Out]# 3      3      Finn         Stationsplein      Breda
#[Out]# 4      4      Daan          Kalverstraat  Amsterdam
#[Out]# 5      5      Levi        Gasthuisstraat    Utrecht
#[Out]# 6      6     Milan           Parallelweg    Utrecht
#[Out]# 7      7      Bram          Schoolstraat  Eindhoven
#[Out]# 8      8      Liam         Rijsbergseweg      Breda
#[Out]# 9      9    Thomas           Parallelweg  Amsterdam
#[Out]# 10    10       Sam           Langestraat    Tilburg
#[Out]# 11    11     Thijs             Koestraat    Tilburg
#[Out]# 12    12      Adam           Nieuwstraat  Eindhoven
#[Out]# 13    13     James       Sint Annastraat      Breda
#[Out]# 14    14       Max             Eikenlaan    Tilburg
#[Out]# 15    15      Noud          Koningshoeve    Tilburg
#[Out]# 16    16    Julian  Prins Bernhardstraat  Eindhoven
#[Out]# 17    17       Dex          Kasteeldreef    Tilburg
#[Out]# 18    18      Hugo          Kasteeldreef    Tilburg
#[Out]# 19    19      Lars         Rijsbergseweg      Breda
#[Out]# 20    20      Gijs            Heiligeweg  Amsterdam
#[Out]# 21    21  Benjamin           Stationsweg    Tilburg
#[Out]# 22    22      Mats           Molenstraat  Eindhoven
#[Out]# 23    23       Jan       Sint Annastraat      Breda
#[Out]# 24    24      Luca          Kasteeldreef    Tilburg
#[Out]# 25    25     Mason          Keizerstraat  Rotterdam
#[Out]# 26    26    Jayden          Schoolstraat  Eindhoven
#[Out]# 27    27       Tim             Koestraat    Utrecht
#[Out]# 28    28      Siem           Langestraat    Tilburg
#[Out]# 29    29     Ruben              Hofplein  Rotterdam
#[Out]# ..   ...       ...                   ...        ...
#[Out]# 160  160      Lara           Langestraat    Tilburg
#[Out]# 161  161     Floor             Eikenlaan    Tilburg
#[Out]# 162  162     Elena            Bergselaan  Rotterdam
#[Out]# 163  163      Cato          Kastanjelaan    Tilburg
#[Out]# 164  164       Evy      Rozemarijnstraat      Breda
#[Out]# 165  165     Hanna             Eikenlaan    Tilburg
#[Out]# 166  166   Rosalie           Stationsweg  Eindhoven
#[Out]# 167  167    Veerle        Ginnekenstraat      Breda
#[Out]# 168  168      Kiki          Keizerstraat  Rotterdam
#[Out]# 169  169      Lily        Gasthuisstraat    Utrecht
#[Out]# 170  170      Iris          Kastanjelaan  Eindhoven
#[Out]# 171  171     Tessa           Haringvliet  Rotterdam
#[Out]# 172  172      Lana             Eikenlaan    Tilburg
#[Out]# 173  173     Livia      Vierwindenstraat      Breda
#[Out]# 174  174      Romy           Parallelweg  Eindhoven
#[Out]# 175  175       Sam             Bredalaan  Eindhoven
#[Out]# 176  176     Amira           Parallelweg  Amsterdam
#[Out]# 177  177     Eline          Kalverstraat  Amsterdam
#[Out]# 178  178      Elif           Parallelweg    Utrecht
#[Out]# 179  179      Juul        Wilhelminapark    Tilburg
#[Out]# 180  180     Merel          Kalverstraat  Amsterdam
#[Out]# 181  181      Liva           Fredriklaan  Eindhoven
#[Out]# 182  182   Johanna         Beatrixstraat  Eindhoven
#[Out]# 183  183     Nikki         Julianastraat    Utrecht
#[Out]# 184  184     Wilko          Onbekendeweg  Eindhoven
#[Out]# 185  185      Nick                Verweg  Eindhoven
#[Out]# 186  186    Angela              Dichtweg  Eindhoven
#[Out]# 187  188      Pino            Maanstraat  Rotterdam
#[Out]# 188  189      Koen              Akkerweg        Oss
#[Out]# 189  190    Kostas              Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Tue, 01 Dec 2020 22:55:28

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */

    
    SELECT cID
    FROM customer as c
    WHERE c.cID not in (
        SELECT c.cID
        FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:56:11

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */


    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase


'''

pd.read_sql_query(query3_3, conn)

#[Out]#     cID
#[Out]# 0     6
#[Out]# 1     9
#[Out]# 2    12
#[Out]# 3    14
#[Out]# 4    23
#[Out]# 5    32
#[Out]# 6    36
#[Out]# 7    46
#[Out]# 8    48
#[Out]# 9    49
#[Out]# 10   50
#[Out]# 11   53
#[Out]# 12   54
#[Out]# 13   56
#[Out]# 14   61
#[Out]# 15   62
#[Out]# 16   65
#[Out]# 17   73
#[Out]# 18   74
#[Out]# 19   79
#[Out]# 20   81
#[Out]# 21   83
#[Out]# 22   87
#[Out]# 23   89
#[Out]# 24   93
#[Out]# 25   98
#[Out]# 26  101
#[Out]# 27  102
#[Out]# 28  105
#[Out]# 29  106
#[Out]# 30  107
#[Out]# 31  114
#[Out]# 32  115
#[Out]# 33  117
#[Out]# 34  120
#[Out]# 35  121
#[Out]# 36  125
#[Out]# 37  130
#[Out]# 38  132
#[Out]# 39  138
#[Out]# 40  140
#[Out]# 41  141
#[Out]# 42  142
#[Out]# 43  143
#[Out]# 44  146
#[Out]# 45  148
#[Out]# 46  150
#[Out]# 47  153
#[Out]# 48  154
#[Out]# 49  155
#[Out]# 50  156
#[Out]# 51  158
#[Out]# 52  160
#[Out]# 53  164
#[Out]# 54  166
#[Out]# 55  173
#[Out]# 56  174
#[Out]# 57  183
# Tue, 01 Dec 2020 22:59:26

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (
    
    

    SELECT cID, cName
    FROM customer
    EXCEPT
    SELECT cID, cName
    FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 22:59:37

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0       Milan    6
#[Out]# 1      Thomas    9
#[Out]# 2        Adam   12
#[Out]# 3         Max   14
#[Out]# 4         Jan   23
#[Out]# 5       Vince   32
#[Out]# 6        Boaz   36
#[Out]# 7       Fedde   46
#[Out]# 8        Tygo   48
#[Out]# 9         Cas   49
#[Out]# 10        Pim   50
#[Out]# 11        Job   53
#[Out]# 12        Jax   54
#[Out]# 13     Tobias   56
#[Out]# 14     Morris   61
#[Out]# 15       Abel   62
#[Out]# 16     Pepijn   65
#[Out]# 17       Owen   73
#[Out]# 18     Samuel   74
#[Out]# 19     Joshua   79
#[Out]# 20      Simon   81
#[Out]# 21      Melle   83
#[Out]# 22      Jelle   87
#[Out]# 23   Johannes   89
#[Out]# 24      Oscar   93
#[Out]# 25      Julia   98
#[Out]# 26        Eva  101
#[Out]# 27        Evi  102
#[Out]# 28       Nora  105
#[Out]# 29      Fleur  106
#[Out]# ..        ...  ...
#[Out]# 146       Ivy  144
#[Out]# 147      Fien  145
#[Out]# 148    Isabel  147
#[Out]# 149     Lizzy  149
#[Out]# 150      Anne  152
#[Out]# 151      Puck  157
#[Out]# 152     Fenne  159
#[Out]# 153     Floor  161
#[Out]# 154     Elena  162
#[Out]# 155      Cato  163
#[Out]# 156     Hanna  165
#[Out]# 157    Veerle  167
#[Out]# 158      Kiki  168
#[Out]# 159      Lily  169
#[Out]# 160      Iris  170
#[Out]# 161     Tessa  171
#[Out]# 162      Lana  172
#[Out]# 163       Sam  175
#[Out]# 164     Amira  176
#[Out]# 165     Eline  177
#[Out]# 166      Elif  178
#[Out]# 167      Juul  179
#[Out]# 168     Merel  180
#[Out]# 169      Liva  181
#[Out]# 170   Johanna  182
#[Out]# 171      Nick  185
#[Out]# 172    Angela  186
#[Out]# 173      Pino  188
#[Out]# 174      Koen  189
#[Out]# 175    Kostas  190
#[Out]# 
#[Out]# [176 rows x 2 columns]
# Tue, 01 Dec 2020 23:00:19

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Jumbo") or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0       Milan    6
#[Out]# 1      Thomas    9
#[Out]# 2        Adam   12
#[Out]# 3         Max   14
#[Out]# 4         Jan   23
#[Out]# 5       Vince   32
#[Out]# 6        Boaz   36
#[Out]# 7       Fedde   46
#[Out]# 8        Tygo   48
#[Out]# 9         Cas   49
#[Out]# 10        Pim   50
#[Out]# 11        Job   53
#[Out]# 12        Jax   54
#[Out]# 13     Tobias   56
#[Out]# 14     Morris   61
#[Out]# 15       Abel   62
#[Out]# 16     Pepijn   65
#[Out]# 17       Owen   73
#[Out]# 18     Samuel   74
#[Out]# 19     Joshua   79
#[Out]# 20      Simon   81
#[Out]# 21      Melle   83
#[Out]# 22      Jelle   87
#[Out]# 23   Johannes   89
#[Out]# 24      Oscar   93
#[Out]# 25      Julia   98
#[Out]# 26        Eva  101
#[Out]# 27        Evi  102
#[Out]# 28       Nora  105
#[Out]# 29      Fleur  106
#[Out]# ..        ...  ...
#[Out]# 152      Lena  137
#[Out]# 153     Elise  139
#[Out]# 154       Ivy  144
#[Out]# 155      Fien  145
#[Out]# 156    Isabel  147
#[Out]# 157     Lizzy  149
#[Out]# 158      Jill  151
#[Out]# 159      Anne  152
#[Out]# 160      Puck  157
#[Out]# 161     Fenne  159
#[Out]# 162     Floor  161
#[Out]# 163     Elena  162
#[Out]# 164      Cato  163
#[Out]# 165     Hanna  165
#[Out]# 166    Veerle  167
#[Out]# 167      Kiki  168
#[Out]# 168      Lily  169
#[Out]# 169      Iris  170
#[Out]# 170     Tessa  171
#[Out]# 171      Lana  172
#[Out]# 172       Sam  175
#[Out]# 173     Amira  176
#[Out]# 174     Eline  177
#[Out]# 175      Elif  178
#[Out]# 176      Juul  179
#[Out]# 177     Merel  180
#[Out]# 178      Liva  181
#[Out]# 179   Johanna  182
#[Out]# 180     Wilko  184
#[Out]# 181    Kostas  190
#[Out]# 
#[Out]# [182 rows x 2 columns]
# Tue, 01 Dec 2020 23:00:28

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0       Milan    6
#[Out]# 1      Thomas    9
#[Out]# 2        Adam   12
#[Out]# 3         Max   14
#[Out]# 4         Jan   23
#[Out]# 5       Vince   32
#[Out]# 6        Boaz   36
#[Out]# 7       Fedde   46
#[Out]# 8        Tygo   48
#[Out]# 9         Cas   49
#[Out]# 10        Pim   50
#[Out]# 11        Job   53
#[Out]# 12        Jax   54
#[Out]# 13     Tobias   56
#[Out]# 14     Morris   61
#[Out]# 15       Abel   62
#[Out]# 16     Pepijn   65
#[Out]# 17       Owen   73
#[Out]# 18     Samuel   74
#[Out]# 19     Joshua   79
#[Out]# 20      Simon   81
#[Out]# 21      Melle   83
#[Out]# 22      Jelle   87
#[Out]# 23   Johannes   89
#[Out]# 24      Oscar   93
#[Out]# 25      Julia   98
#[Out]# 26        Eva  101
#[Out]# 27        Evi  102
#[Out]# 28       Nora  105
#[Out]# 29      Fleur  106
#[Out]# ..        ...  ...
#[Out]# 146       Ivy  144
#[Out]# 147      Fien  145
#[Out]# 148    Isabel  147
#[Out]# 149     Lizzy  149
#[Out]# 150      Anne  152
#[Out]# 151      Puck  157
#[Out]# 152     Fenne  159
#[Out]# 153     Floor  161
#[Out]# 154     Elena  162
#[Out]# 155      Cato  163
#[Out]# 156     Hanna  165
#[Out]# 157    Veerle  167
#[Out]# 158      Kiki  168
#[Out]# 159      Lily  169
#[Out]# 160      Iris  170
#[Out]# 161     Tessa  171
#[Out]# 162      Lana  172
#[Out]# 163       Sam  175
#[Out]# 164     Amira  176
#[Out]# 165     Eline  177
#[Out]# 166      Elif  178
#[Out]# 167      Juul  179
#[Out]# 168     Merel  180
#[Out]# 169      Liva  181
#[Out]# 170   Johanna  182
#[Out]# 171      Nick  185
#[Out]# 172    Angela  186
#[Out]# 173      Pino  188
#[Out]# 174      Koen  189
#[Out]# 175    Kostas  190
#[Out]# 
#[Out]# [176 rows x 2 columns]
# Tue, 01 Dec 2020 23:00:52

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    ))


'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 23:01:22

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    ))


'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]
# Tue, 01 Dec 2020 23:02:01

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )) and p.sName is null


'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 23:02:10

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )) and s.sName is null


'''

pd.read_sql_query(query3_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, sName]
#[Out]# Index: []
# Tue, 01 Dec 2020 23:02:26

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )) `


'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 23:04:06

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    ));*/

    SELECT cID
    FROM purchase
    EXCEPT
    SELECT cID
    FROM purchase as p, store as s
    WHERE S.sID = S.sID and s.sName = "Coop"
    
'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 23:04:24

query3_3 = '''


    SELECT cID
    FROM purchase
    EXCEPT
    SELECT cID
    FROM purchase as p, store as s
    WHERE S.sID = S.sID and s.sName = "Coop"

'''

pd.read_sql_query(query3_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 23:04:28

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    ));*/

    SELECT cID
    FROM purchase
    EXCEPT
    SELECT cID
    FROM purchase as p, store as s
    WHERE S.sID = S.sID and s.sName = "Coop"

'''

pd.read_sql_query(query3_3, conn)

# Tue, 01 Dec 2020 23:04:36

query3_3 = '''


    SELECT cID
    FROM purchase
    EXCEPT
    SELECT cID
    FROM purchase as p, store as s
    WHERE S.sID = S.sID and s.sName = "Coop"

'''

pd.read_sql_query(query3_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Tue, 01 Dec 2020 23:05:17

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is null)

'''

pd.read_sql_query(query3_3, conn)

#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]
# Tue, 01 Dec 2020 23:05:31

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is null)

'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Tue, 01 Dec 2020 23:08:38

query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop" 
    EXCEPT 
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName != "Coop" 
'''

pd.read_sql_query(query3_4, conn)

#[Out]#     cID      cName
#[Out]# 0     8       Liam
#[Out]# 1    10        Sam
#[Out]# 2    11      Thijs
#[Out]# 3    26     Jayden
#[Out]# 4    28       Siem
#[Out]# 5    55      Aiden
#[Out]# 6    76  Alexander
#[Out]# 7    88      Joris
#[Out]# 8    99       Anna
#[Out]# 9   103      Lotte
#[Out]# 10  131        Amy
#[Out]# 11  135      Sofia
#[Out]# 12  151       Jill
#[Out]# 13  184      Wilko
# Wed, 02 Dec 2020 12:32:31

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT 
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop"

'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Abel   62
#[Out]# 1        Adam   12
#[Out]# 2       Amber  153
#[Out]# 3      Angela  186
#[Out]# 4      Benthe  154
#[Out]# 5          Bo  142
#[Out]# 6        Boaz   36
#[Out]# 7       Boris   68
#[Out]# 8        Bram    7
#[Out]# 9         Cas   49
#[Out]# 10     Casper   84
#[Out]# 11       Dani   72
#[Out]# 12      David   34
#[Out]# 13       Emma   95
#[Out]# 14        Eva  101
#[Out]# 15        Evi  102
#[Out]# 16        Evy  164
#[Out]# 17      Fedde   46
#[Out]# 18      Femke  136
#[Out]# 19      Fenne  159
#[Out]# 20       Fien  145
#[Out]# 21       Finn    3
#[Out]# 22      Fleur  106
#[Out]# 23     Floris   38
#[Out]# 24       Guus   37
#[Out]# 25     Hannah  132
#[Out]# 26      Hidde   77
#[Out]# 27       Iris  170
#[Out]# 28        Isa  121
#[Out]# 29   Isabella  148
#[Out]# ..        ...  ...
#[Out]# 86        Pim   50
#[Out]# 87       Pino  188
#[Out]# 88       Puck  157
#[Out]# 89      Quinn   41
#[Out]# 90       Roan   69
#[Out]# 91       Romy  174
#[Out]# 92       Roos  117
#[Out]# 93       Rosa  158
#[Out]# 94    Rosalie  166
#[Out]# 95       Ryan   45
#[Out]# 96        Sam  175
#[Out]# 97     Samuel   74
#[Out]# 98      Sanne  130
#[Out]# 99      Sarah  120
#[Out]# 100       Sem    1
#[Out]# 101      Senn   63
#[Out]# 102     Simon   81
#[Out]# 103      Stan   64
#[Out]# 104      Stef   86
#[Out]# 105     Tessa  171
#[Out]# 106      Teun   30
#[Out]# 107    Thomas    9
#[Out]# 108    Tobias   56
#[Out]# 109       Tom   43
#[Out]# 110      Tygo   48
#[Out]# 111    Veerle  167
#[Out]# 112      Vera  140
#[Out]# 113     Vince   32
#[Out]# 114    Willem   52
#[Out]# 115      Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Wed, 02 Dec 2020 12:32:55

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Jumbo"

'''

pd.read_sql_query(query3_3, conn)

#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7         Anna   99
#[Out]# 8         Anne  152
#[Out]# 9       Benthe  154
#[Out]# 10          Bo  142
#[Out]# 11        Boaz   36
#[Out]# 12        Bram    7
#[Out]# 13         Cas   49
#[Out]# 14      Casper   84
#[Out]# 15        Cato  163
#[Out]# 16       David   34
#[Out]# 17        Dean   71
#[Out]# 18         Dex   17
#[Out]# 19       Dylan   82
#[Out]# 20       Elena  162
#[Out]# 21        Elif  178
#[Out]# 22       Eline  177
#[Out]# 23       Elise  139
#[Out]# 24        Ella  134
#[Out]# 25       Emily  127
#[Out]# 26        Emma   95
#[Out]# 27       Esmee  129
#[Out]# 28         Eva  101
#[Out]# 29         Evi  102
#[Out]# ..         ...  ...
#[Out]# 125       Saar  110
#[Out]# 126        Sam   10
#[Out]# 127        Sam  175
#[Out]# 128     Samuel   74
#[Out]# 129      Sanne  130
#[Out]# 130       Sara  100
#[Out]# 131      Sarah  120
#[Out]# 132        Sem    1
#[Out]# 133       Siem   28
#[Out]# 134      Simon   81
#[Out]# 135      Sofia  135
#[Out]# 136      Sofie  124
#[Out]# 137     Sophia  133
#[Out]# 138     Sophie   97
#[Out]# 139       Stan   64
#[Out]# 140      Stijn   35
#[Out]# 141       Sven   33
#[Out]# 142       Tess   96
#[Out]# 143       Teun   30
#[Out]# 144    Thijmen   91
#[Out]# 145      Thijs   11
#[Out]# 146     Thomas    9
#[Out]# 147       Ties   51
#[Out]# 148       Tijn   42
#[Out]# 149     Tobias   56
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Wed, 02 Dec 2020 12:32:59

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Jumbo"

'''

pd.read_sql_query(query3_3, conn)

#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7         Anna   99
#[Out]# 8         Anne  152
#[Out]# 9       Benthe  154
#[Out]# 10          Bo  142
#[Out]# 11        Boaz   36
#[Out]# 12        Bram    7
#[Out]# 13         Cas   49
#[Out]# 14      Casper   84
#[Out]# 15        Cato  163
#[Out]# 16       David   34
#[Out]# 17        Dean   71
#[Out]# 18         Dex   17
#[Out]# 19       Dylan   82
#[Out]# 20       Elena  162
#[Out]# 21        Elif  178
#[Out]# 22       Eline  177
#[Out]# 23       Elise  139
#[Out]# 24        Ella  134
#[Out]# 25       Emily  127
#[Out]# 26        Emma   95
#[Out]# 27       Esmee  129
#[Out]# 28         Eva  101
#[Out]# 29         Evi  102
#[Out]# ..         ...  ...
#[Out]# 125       Saar  110
#[Out]# 126        Sam   10
#[Out]# 127        Sam  175
#[Out]# 128     Samuel   74
#[Out]# 129      Sanne  130
#[Out]# 130       Sara  100
#[Out]# 131      Sarah  120
#[Out]# 132        Sem    1
#[Out]# 133       Siem   28
#[Out]# 134      Simon   81
#[Out]# 135      Sofia  135
#[Out]# 136      Sofie  124
#[Out]# 137     Sophia  133
#[Out]# 138     Sophie   97
#[Out]# 139       Stan   64
#[Out]# 140      Stijn   35
#[Out]# 141       Sven   33
#[Out]# 142       Tess   96
#[Out]# 143       Teun   30
#[Out]# 144    Thijmen   91
#[Out]# 145      Thijs   11
#[Out]# 146     Thomas    9
#[Out]# 147       Ties   51
#[Out]# 148       Tijn   42
#[Out]# 149     Tobias   56
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Wed, 02 Dec 2020 12:33:14

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM purchase as p, store as s
    WHERE p.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)

# Wed, 02 Dec 2020 12:33:31

get_ipython().magic(u'logstop')
get_ipython().magic(u'logstart -o -t')
import sqlite3
import pandas as pd


# IPython log file


get_ipython().magic(u'logstop')
get_ipython().magic(u'logstart -o -t')
import sqlite3
import pandas as pd

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

query3_2 = '''
    SELECT *
'''

pd.read_sql_query(query3_2, conn)

query3_2 = '''
    SELECT *
    FROM WORK 
'''

pd.read_sql_query(query3_2, conn)

query3_2 = '''
    SELECT *
    FROM WORKS
'''

pd.read_sql_query(query3_2, conn)

query3_2 = '''
    SELECT *
    FROM product
'''

pd.read_sql_query(query3_2, conn)
#[Out]#     pID             pName suffix
#[Out]# 0     0       Cashew Nuts       
#[Out]# 1     1        Mixed Nuts       
#[Out]# 2     2          Potatoes       
#[Out]# 3     3      Green Pepper       
#[Out]# 4     4            Onions       
#[Out]# 5     5         Mushrooms       
#[Out]# 6     6           Carrots       
#[Out]# 7     7          Tomatoes       
#[Out]# 8     8  Hot Dog Sausages       
#[Out]# 9     9           Bananas       
#[Out]# 10   10             Water       
#[Out]# 11   11              Milk       
#[Out]# 12   12              Beef       
#[Out]# 13   13              Eggs       
#[Out]# 14   14            Apples       
#[Out]# 15   15         Cucumbers       
#[Out]# 16   16              Rice       
#[Out]# 17   17             Bread       
#[Out]# 18   18            Cheese       
#[Out]# 19   19              Coca       
#[Out]# 20   20             Fanta       
#[Out]# 21   21            Coffee       
#[Out]# 22   22               Tea       
#[Out]# 23   23   Spiced Biscuits       
#[Out]# 24   24           Oranges       
#[Out]# 25   25            Donuts       
#[Out]# 26   26             Pasta       
#[Out]# 27   27             Pizza       
#[Out]# 28   28           Lasanga       
#[Out]# 29   29            Salmon       
#[Out]# 30   30           Ketchup       
#[Out]# 31   31   French baguette       

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID 
    WHERE s.date = p.date and s.date = "2018"
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date and s.date = 2018
'''

pd.read_sql_query(query3_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0         Sem    1  2018-08-20
#[Out]# 1         Sem    1  2018-08-21
#[Out]# 2       Lucas    2  2018-08-16
#[Out]# 3       Lucas    2  2018-08-17
#[Out]# 4        Finn    3  2018-08-18
#[Out]# 5        Finn    3  2018-08-19
#[Out]# 6        Levi    5  2018-08-17
#[Out]# 7        Levi    5  2018-08-22
#[Out]# 8        Levi    5  2018-08-23
#[Out]# 9        Bram    7  2018-08-23
#[Out]# 10       Bram    7  2018-08-24
#[Out]# 11       Bram    7  2018-08-25
#[Out]# 12       Bram    7  2018-08-26
#[Out]# 13       Liam    8  2018-08-16
#[Out]# 14        Sam   10  2018-08-27
#[Out]# 15      Thijs   11  2018-08-25
#[Out]# 16      James   13  2018-08-17
#[Out]# 17      James   13  2018-08-25
#[Out]# 18      James   13  2018-08-26
#[Out]# 19      James   13  2018-08-27
#[Out]# 20       Noud   15  2018-08-27
#[Out]# 21        Dex   17  2018-08-19
#[Out]# 22       Hugo   18  2018-08-16
#[Out]# 23       Hugo   18  2018-08-18
#[Out]# 24       Lars   19  2018-08-17
#[Out]# 25       Lars   19  2018-08-18
#[Out]# 26       Gijs   20  2018-08-17
#[Out]# 27       Gijs   20  2018-08-18
#[Out]# 28   Benjamin   21  2018-08-15
#[Out]# 29       Mats   22  2018-08-27
#[Out]# ..        ...  ...         ...
#[Out]# 156     Hanna  165  2018-08-23
#[Out]# 157     Hanna  165  2018-08-24
#[Out]# 158    Veerle  167  2018-08-18
#[Out]# 159    Veerle  167  2018-08-19
#[Out]# 160    Veerle  167  2018-08-20
#[Out]# 161    Veerle  167  2018-08-21
#[Out]# 162    Veerle  167  2018-08-15
#[Out]# 163      Kiki  168  2018-08-16
#[Out]# 164      Lily  169  2018-08-16
#[Out]# 165      Lily  169  2018-08-17
#[Out]# 166      Lily  169  2018-08-18
#[Out]# 167      Lily  169  2018-08-19
#[Out]# 168      Lily  169  2018-08-20
#[Out]# 169      Lily  169  2018-08-26
#[Out]# 170      Lily  169  2018-08-27
#[Out]# 171      Iris  170  2018-08-16
#[Out]# 172     Tessa  171  2018-08-20
#[Out]# 173      Lana  172  2018-08-27
#[Out]# 174      Lana  172  2018-08-24
#[Out]# 175       Sam  175  2018-08-19
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Amira  176  2018-08-25
#[Out]# 178     Amira  176  2018-08-26
#[Out]# 179      Elif  178  2018-08-27
#[Out]# 180      Juul  179  2018-08-24
#[Out]# 181      Juul  179  2018-08-22
#[Out]# 182     Merel  180  2018-08-26
#[Out]# 183     Merel  180  2018-08-27
#[Out]# 184      Liva  181  2018-08-24
#[Out]# 185      Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date and s.date = %2018%
'''

pd.read_sql_query(query3_2, conn)

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date and s.date like %2018%
'''

pd.read_sql_query(query3_2, conn)

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0         Sem    1  2018-08-20
#[Out]# 1         Sem    1  2018-08-21
#[Out]# 2       Lucas    2  2018-08-16
#[Out]# 3       Lucas    2  2018-08-17
#[Out]# 4        Finn    3  2018-08-18
#[Out]# 5        Finn    3  2018-08-19
#[Out]# 6        Levi    5  2018-08-17
#[Out]# 7        Levi    5  2018-08-22
#[Out]# 8        Levi    5  2018-08-23
#[Out]# 9        Bram    7  2018-08-23
#[Out]# 10       Bram    7  2018-08-24
#[Out]# 11       Bram    7  2018-08-25
#[Out]# 12       Bram    7  2018-08-26
#[Out]# 13       Liam    8  2018-08-16
#[Out]# 14        Sam   10  2018-08-27
#[Out]# 15      Thijs   11  2018-08-25
#[Out]# 16      James   13  2018-08-17
#[Out]# 17      James   13  2018-08-25
#[Out]# 18      James   13  2018-08-26
#[Out]# 19      James   13  2018-08-27
#[Out]# 20       Noud   15  2018-08-27
#[Out]# 21        Dex   17  2018-08-19
#[Out]# 22       Hugo   18  2018-08-16
#[Out]# 23       Hugo   18  2018-08-18
#[Out]# 24       Lars   19  2018-08-17
#[Out]# 25       Lars   19  2018-08-18
#[Out]# 26       Gijs   20  2018-08-17
#[Out]# 27       Gijs   20  2018-08-18
#[Out]# 28   Benjamin   21  2018-08-15
#[Out]# 29       Mats   22  2018-08-27
#[Out]# ..        ...  ...         ...
#[Out]# 156     Hanna  165  2018-08-23
#[Out]# 157     Hanna  165  2018-08-24
#[Out]# 158    Veerle  167  2018-08-18
#[Out]# 159    Veerle  167  2018-08-19
#[Out]# 160    Veerle  167  2018-08-20
#[Out]# 161    Veerle  167  2018-08-21
#[Out]# 162    Veerle  167  2018-08-15
#[Out]# 163      Kiki  168  2018-08-16
#[Out]# 164      Lily  169  2018-08-16
#[Out]# 165      Lily  169  2018-08-17
#[Out]# 166      Lily  169  2018-08-18
#[Out]# 167      Lily  169  2018-08-19
#[Out]# 168      Lily  169  2018-08-20
#[Out]# 169      Lily  169  2018-08-26
#[Out]# 170      Lily  169  2018-08-27
#[Out]# 171      Iris  170  2018-08-16
#[Out]# 172     Tessa  171  2018-08-20
#[Out]# 173      Lana  172  2018-08-27
#[Out]# 174      Lana  172  2018-08-24
#[Out]# 175       Sam  175  2018-08-19
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Amira  176  2018-08-25
#[Out]# 178     Amira  176  2018-08-26
#[Out]# 179      Elif  178  2018-08-27
#[Out]# 180      Juul  179  2018-08-24
#[Out]# 181      Juul  179  2018-08-22
#[Out]# 182     Merel  180  2018-08-26
#[Out]# 183     Merel  180  2018-08-27
#[Out]# 184      Liva  181  2018-08-24
#[Out]# 185      Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]

query3_2 = '''
    SELECT DISTINCT c.cName, c.cID, s.date
    FROM customer as c
    INNER JOIN shoppinglist as s
    ON s.cID = c.cID
    INNER JOIN purchase as p
    on p.cID = c.cID
    WHERE s.date = p.date and s.date like '2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID        date
#[Out]# 0         Sem    1  2018-08-20
#[Out]# 1         Sem    1  2018-08-21
#[Out]# 2       Lucas    2  2018-08-16
#[Out]# 3       Lucas    2  2018-08-17
#[Out]# 4        Finn    3  2018-08-18
#[Out]# 5        Finn    3  2018-08-19
#[Out]# 6        Levi    5  2018-08-17
#[Out]# 7        Levi    5  2018-08-22
#[Out]# 8        Levi    5  2018-08-23
#[Out]# 9        Bram    7  2018-08-23
#[Out]# 10       Bram    7  2018-08-24
#[Out]# 11       Bram    7  2018-08-25
#[Out]# 12       Bram    7  2018-08-26
#[Out]# 13       Liam    8  2018-08-16
#[Out]# 14        Sam   10  2018-08-27
#[Out]# 15      Thijs   11  2018-08-25
#[Out]# 16      James   13  2018-08-17
#[Out]# 17      James   13  2018-08-25
#[Out]# 18      James   13  2018-08-26
#[Out]# 19      James   13  2018-08-27
#[Out]# 20       Noud   15  2018-08-27
#[Out]# 21        Dex   17  2018-08-19
#[Out]# 22       Hugo   18  2018-08-16
#[Out]# 23       Hugo   18  2018-08-18
#[Out]# 24       Lars   19  2018-08-17
#[Out]# 25       Lars   19  2018-08-18
#[Out]# 26       Gijs   20  2018-08-17
#[Out]# 27       Gijs   20  2018-08-18
#[Out]# 28   Benjamin   21  2018-08-15
#[Out]# 29       Mats   22  2018-08-27
#[Out]# ..        ...  ...         ...
#[Out]# 156     Hanna  165  2018-08-23
#[Out]# 157     Hanna  165  2018-08-24
#[Out]# 158    Veerle  167  2018-08-18
#[Out]# 159    Veerle  167  2018-08-19
#[Out]# 160    Veerle  167  2018-08-20
#[Out]# 161    Veerle  167  2018-08-21
#[Out]# 162    Veerle  167  2018-08-15
#[Out]# 163      Kiki  168  2018-08-16
#[Out]# 164      Lily  169  2018-08-16
#[Out]# 165      Lily  169  2018-08-17
#[Out]# 166      Lily  169  2018-08-18
#[Out]# 167      Lily  169  2018-08-19
#[Out]# 168      Lily  169  2018-08-20
#[Out]# 169      Lily  169  2018-08-26
#[Out]# 170      Lily  169  2018-08-27
#[Out]# 171      Iris  170  2018-08-16
#[Out]# 172     Tessa  171  2018-08-20
#[Out]# 173      Lana  172  2018-08-27
#[Out]# 174      Lana  172  2018-08-24
#[Out]# 175       Sam  175  2018-08-19
#[Out]# 176     Amira  176  2018-08-22
#[Out]# 177     Amira  176  2018-08-25
#[Out]# 178     Amira  176  2018-08-26
#[Out]# 179      Elif  178  2018-08-27
#[Out]# 180      Juul  179  2018-08-24
#[Out]# 181      Juul  179  2018-08-22
#[Out]# 182     Merel  180  2018-08-26
#[Out]# 183     Merel  180  2018-08-27
#[Out]# 184      Liva  181  2018-08-24
#[Out]# 185      Liva  181  2018-08-27
#[Out]# 
#[Out]# [186 rows x 3 columns]



query3_2 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, shoppinglist as s, purchase as p 
    WHERE s.cID = c.cID and p.cID = c.cID and s.date = p.date and s.date like '2018%'
    
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0         Sem    1
#[Out]# 1       Lucas    2
#[Out]# 2        Finn    3
#[Out]# 3        Levi    5
#[Out]# 4        Bram    7
#[Out]# 5        Liam    8
#[Out]# 6         Sam   10
#[Out]# 7       Thijs   11
#[Out]# 8       James   13
#[Out]# 9        Noud   15
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17     Jayden   26
#[Out]# 18        Tim   27
#[Out]# 19       Siem   28
#[Out]# 20      Ruben   29
#[Out]# 21       Teun   30
#[Out]# 22    Olivier   31
#[Out]# 23       Sven   33
#[Out]# 24      David   34
#[Out]# 25      Stijn   35
#[Out]# 26       Guus   37
#[Out]# 27     Floris   38
#[Out]# 28       Jack   39
#[Out]# 29       Jens   40
#[Out]# ..        ...  ...
#[Out]# 74      Sofie  124
#[Out]# 75      Emily  127
#[Out]# 76    Jasmijn  128
#[Out]# 77     Sophia  133
#[Out]# 78       Ella  134
#[Out]# 79       Lena  137
#[Out]# 80        Ivy  144
#[Out]# 81       Fien  145
#[Out]# 82     Isabel  147
#[Out]# 83      Lizzy  149
#[Out]# 84       Jill  151
#[Out]# 85       Anne  152
#[Out]# 86       Puck  157
#[Out]# 87      Fenne  159
#[Out]# 88      Floor  161
#[Out]# 89      Elena  162
#[Out]# 90       Cato  163
#[Out]# 91      Hanna  165
#[Out]# 92     Veerle  167
#[Out]# 93       Kiki  168
#[Out]# 94       Lily  169
#[Out]# 95       Iris  170
#[Out]# 96      Tessa  171
#[Out]# 97       Lana  172
#[Out]# 98        Sam  175
#[Out]# 99      Amira  176
#[Out]# 100      Elif  178
#[Out]# 101      Juul  179
#[Out]# 102     Merel  180
#[Out]# 103      Liva  181
#[Out]# 
#[Out]# [104 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Kumar"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> ""
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Jumbo"
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 94       Lena  137
#[Out]# 95      Elise  139
#[Out]# 96        Ivy  144
#[Out]# 97       Fien  145
#[Out]# 98     Isabel  147
#[Out]# 99      Lizzy  149
#[Out]# 100      Jill  151
#[Out]# 101      Anne  152
#[Out]# 102      Puck  157
#[Out]# 103     Fenne  159
#[Out]# 104     Floor  161
#[Out]# 105     Elena  162
#[Out]# 106      Cato  163
#[Out]# 107     Hanna  165
#[Out]# 108    Veerle  167
#[Out]# 109      Kiki  168
#[Out]# 110      Lily  169
#[Out]# 111      Iris  170
#[Out]# 112     Tessa  171
#[Out]# 113      Lana  172
#[Out]# 114       Sam  175
#[Out]# 115     Amira  176
#[Out]# 116     Eline  177
#[Out]# 117      Elif  178
#[Out]# 118      Juul  179
#[Out]# 119     Merel  180
#[Out]# 120      Liva  181
#[Out]# 121   Johanna  182
#[Out]# 122     Wilko  184
#[Out]# 123    Kostas  190
#[Out]# 
#[Out]# [124 rows x 2 columns]

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Jumbo"*/
    
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE not exists()
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Jumbo"*/

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase
    
    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0      Milan    6
#[Out]# 1     Thomas    9
#[Out]# 2       Adam   12
#[Out]# 3        Max   14
#[Out]# 4        Jan   23
#[Out]# 5      Vince   32
#[Out]# 6       Boaz   36
#[Out]# 7      Fedde   46
#[Out]# 8       Tygo   48
#[Out]# 9        Cas   49
#[Out]# 10       Pim   50
#[Out]# 11       Job   53
#[Out]# 12       Jax   54
#[Out]# 13    Tobias   56
#[Out]# 14    Morris   61
#[Out]# 15      Abel   62
#[Out]# 16    Pepijn   65
#[Out]# 17      Owen   73
#[Out]# 18    Samuel   74
#[Out]# 19    Joshua   79
#[Out]# 20     Simon   81
#[Out]# 21     Melle   83
#[Out]# 22     Jelle   87
#[Out]# 23  Johannes   89
#[Out]# 24     Oscar   93
#[Out]# 25     Julia   98
#[Out]# 26       Eva  101
#[Out]# 27       Evi  102
#[Out]# 28      Nora  105
#[Out]# 29     Fleur  106
#[Out]# 30    Olivia  107
#[Out]# 31      Maud  114
#[Out]# 32      Nova  115
#[Out]# 33      Roos  117
#[Out]# 34     Sarah  120
#[Out]# 35       Isa  121
#[Out]# 36       Noa  125
#[Out]# 37     Sanne  130
#[Out]# 38    Hannah  132
#[Out]# 39     Maria  138
#[Out]# 40      Vera  140
#[Out]# 41       Mia  141
#[Out]# 42        Bo  142
#[Out]# 43     Naomi  143
#[Out]# 44     Norah  146
#[Out]# 45  Isabella  148
#[Out]# 46     Julie  150
#[Out]# 47     Amber  153
#[Out]# 48    Benthe  154
#[Out]# 49     Linde  155
#[Out]# 50      Luna  156
#[Out]# 51      Rosa  158
#[Out]# 52      Lara  160
#[Out]# 53       Evy  164
#[Out]# 54   Rosalie  166
#[Out]# 55     Livia  173
#[Out]# 56      Romy  174
#[Out]# 57     Nikki  183

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> ""

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop"

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0       Lucas    2
#[Out]# 1        Daan    4
#[Out]# 2        Levi    5
#[Out]# 3        Liam    8
#[Out]# 4         Sam   10
#[Out]# 5       Thijs   11
#[Out]# 6      Julian   16
#[Out]# 7         Dex   17
#[Out]# 8        Hugo   18
#[Out]# 9        Gijs   20
#[Out]# 10   Benjamin   21
#[Out]# 11       Luca   24
#[Out]# 12     Jayden   26
#[Out]# 13        Tim   27
#[Out]# 14       Siem   28
#[Out]# 15      Ruben   29
#[Out]# 16       Sven   33
#[Out]# 17      Stijn   35
#[Out]# 18       Jack   39
#[Out]# 19       Tijn   42
#[Out]# 20       Ties   51
#[Out]# 21      Aiden   55
#[Out]# 22     Nathan   57
#[Out]# 23       Joep   59
#[Out]# 24      Rayan   67
#[Out]# 25       Dean   71
#[Out]# 26       Jace   75
#[Out]# 27  Alexander   76
#[Out]# 28       Mick   78
#[Out]# 29      Dylan   82
#[Out]# ..        ...  ...
#[Out]# 44      Lieke  116
#[Out]# 45       Lisa  118
#[Out]# 46       Elin  122
#[Out]# 47      Milou  123
#[Out]# 48      Sofie  124
#[Out]# 49      Emily  127
#[Out]# 50      Esmee  129
#[Out]# 51        Amy  131
#[Out]# 52     Sophia  133
#[Out]# 53       Ella  134
#[Out]# 54      Sofia  135
#[Out]# 55      Elise  139
#[Out]# 56        Ivy  144
#[Out]# 57     Isabel  147
#[Out]# 58       Jill  151
#[Out]# 59       Anne  152
#[Out]# 60      Floor  161
#[Out]# 61      Elena  162
#[Out]# 62       Cato  163
#[Out]# 63      Hanna  165
#[Out]# 64       Lily  169
#[Out]# 65       Lana  172
#[Out]# 66      Amira  176
#[Out]# 67      Eline  177
#[Out]# 68       Elif  178
#[Out]# 69       Juul  179
#[Out]# 70      Merel  180
#[Out]# 71       Liva  181
#[Out]# 72      Wilko  184
#[Out]# 73     Kostas  190
#[Out]# 
#[Out]# [74 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> ""

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> ""



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID 

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7        Liam    8
#[Out]# 8         Sam   10
#[Out]# 9       Thijs   11
#[Out]# 10      James   13
#[Out]# 11       Noud   15
#[Out]# 12     Julian   16
#[Out]# 13        Dex   17
#[Out]# 14       Hugo   18
#[Out]# 15       Lars   19
#[Out]# 16       Gijs   20
#[Out]# 17   Benjamin   21
#[Out]# 18       Mats   22
#[Out]# 19       Luca   24
#[Out]# 20      Mason   25
#[Out]# 21     Jayden   26
#[Out]# 22        Tim   27
#[Out]# 23       Siem   28
#[Out]# 24      Ruben   29
#[Out]# 25       Teun   30
#[Out]# 26    Olivier   31
#[Out]# 27       Sven   33
#[Out]# 28      David   34
#[Out]# 29      Stijn   35
#[Out]# ..        ...  ...
#[Out]# 102    Isabel  147
#[Out]# 103     Lizzy  149
#[Out]# 104      Jill  151
#[Out]# 105      Anne  152
#[Out]# 106      Puck  157
#[Out]# 107     Fenne  159
#[Out]# 108     Floor  161
#[Out]# 109     Elena  162
#[Out]# 110      Cato  163
#[Out]# 111     Hanna  165
#[Out]# 112    Veerle  167
#[Out]# 113      Kiki  168
#[Out]# 114      Lily  169
#[Out]# 115      Iris  170
#[Out]# 116     Tessa  171
#[Out]# 117      Lana  172
#[Out]# 118       Sam  175
#[Out]# 119     Amira  176
#[Out]# 120     Eline  177
#[Out]# 121      Elif  178
#[Out]# 122      Juul  179
#[Out]# 123     Merel  180
#[Out]# 124      Liva  181
#[Out]# 125   Johanna  182
#[Out]# 126     Wilko  184
#[Out]# 127      Nick  185
#[Out]# 128    Angela  186
#[Out]# 129      Pino  188
#[Out]# 130      Koen  189
#[Out]# 131    Kostas  190
#[Out]# 
#[Out]# [132 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop"

   

    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0       Lucas    2
#[Out]# 1        Daan    4
#[Out]# 2        Levi    5
#[Out]# 3        Liam    8
#[Out]# 4         Sam   10
#[Out]# 5       Thijs   11
#[Out]# 6      Julian   16
#[Out]# 7         Dex   17
#[Out]# 8        Hugo   18
#[Out]# 9        Gijs   20
#[Out]# 10   Benjamin   21
#[Out]# 11       Luca   24
#[Out]# 12     Jayden   26
#[Out]# 13        Tim   27
#[Out]# 14       Siem   28
#[Out]# 15      Ruben   29
#[Out]# 16       Sven   33
#[Out]# 17      Stijn   35
#[Out]# 18       Jack   39
#[Out]# 19       Tijn   42
#[Out]# 20       Ties   51
#[Out]# 21      Aiden   55
#[Out]# 22     Nathan   57
#[Out]# 23       Joep   59
#[Out]# 24      Rayan   67
#[Out]# 25       Dean   71
#[Out]# 26       Jace   75
#[Out]# 27  Alexander   76
#[Out]# 28       Mick   78
#[Out]# 29      Dylan   82
#[Out]# ..        ...  ...
#[Out]# 44      Lieke  116
#[Out]# 45       Lisa  118
#[Out]# 46       Elin  122
#[Out]# 47      Milou  123
#[Out]# 48      Sofie  124
#[Out]# 49      Emily  127
#[Out]# 50      Esmee  129
#[Out]# 51        Amy  131
#[Out]# 52     Sophia  133
#[Out]# 53       Ella  134
#[Out]# 54      Sofia  135
#[Out]# 55      Elise  139
#[Out]# 56        Ivy  144
#[Out]# 57     Isabel  147
#[Out]# 58       Jill  151
#[Out]# 59       Anne  152
#[Out]# 60      Floor  161
#[Out]# 61      Elena  162
#[Out]# 62       Cato  163
#[Out]# 63      Hanna  165
#[Out]# 64       Lily  169
#[Out]# 65       Lana  172
#[Out]# 66      Amira  176
#[Out]# 67      Eline  177
#[Out]# 68       Elif  178
#[Out]# 69       Juul  179
#[Out]# 70      Merel  180
#[Out]# 71       Liva  181
#[Out]# 72      Wilko  184
#[Out]# 73     Kostas  190
#[Out]# 
#[Out]# [74 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop"



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID exist in (SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )) 



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID EXISTS in (SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )) 



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID EXISTS (SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    ))



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    ))



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (SELECT DISTINCT c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    ))



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0       Milan    6
#[Out]# 1      Thomas    9
#[Out]# 2        Adam   12
#[Out]# 3         Max   14
#[Out]# 4         Jan   23
#[Out]# 5       Vince   32
#[Out]# 6        Boaz   36
#[Out]# 7       Fedde   46
#[Out]# 8        Tygo   48
#[Out]# 9         Cas   49
#[Out]# 10        Pim   50
#[Out]# 11        Job   53
#[Out]# 12        Jax   54
#[Out]# 13     Tobias   56
#[Out]# 14     Morris   61
#[Out]# 15       Abel   62
#[Out]# 16     Pepijn   65
#[Out]# 17       Owen   73
#[Out]# 18     Samuel   74
#[Out]# 19     Joshua   79
#[Out]# 20      Simon   81
#[Out]# 21      Melle   83
#[Out]# 22      Jelle   87
#[Out]# 23   Johannes   89
#[Out]# 24      Oscar   93
#[Out]# 25      Julia   98
#[Out]# 26        Eva  101
#[Out]# 27        Evi  102
#[Out]# 28       Nora  105
#[Out]# 29      Fleur  106
#[Out]# ..        ...  ...
#[Out]# 146       Ivy  144
#[Out]# 147      Fien  145
#[Out]# 148    Isabel  147
#[Out]# 149     Lizzy  149
#[Out]# 150      Anne  152
#[Out]# 151      Puck  157
#[Out]# 152     Fenne  159
#[Out]# 153     Floor  161
#[Out]# 154     Elena  162
#[Out]# 155      Cato  163
#[Out]# 156     Hanna  165
#[Out]# 157    Veerle  167
#[Out]# 158      Kiki  168
#[Out]# 159      Lily  169
#[Out]# 160      Iris  170
#[Out]# 161     Tessa  171
#[Out]# 162      Lana  172
#[Out]# 163       Sam  175
#[Out]# 164     Amira  176
#[Out]# 165     Eline  177
#[Out]# 166      Elif  178
#[Out]# 167      Juul  179
#[Out]# 168     Merel  180
#[Out]# 169      Liva  181
#[Out]# 170   Johanna  182
#[Out]# 171      Nick  185
#[Out]# 172    Angela  186
#[Out]# 173      Pino  188
#[Out]# 174      Koen  189
#[Out]# 175    Kostas  190
#[Out]# 
#[Out]# [176 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (SELECT DISTINCT c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    ))



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID        sName
#[Out]# 0       Milan    6         Coop
#[Out]# 1      Thomas    9         Coop
#[Out]# 2        Adam   12         Coop
#[Out]# 3         Max   14         Coop
#[Out]# 4         Jan   23         Coop
#[Out]# 5       Vince   32         Coop
#[Out]# 6        Boaz   36         Coop
#[Out]# 7       Fedde   46         Coop
#[Out]# 8        Tygo   48         Coop
#[Out]# 9         Cas   49         Coop
#[Out]# 10        Pim   50         Coop
#[Out]# 11        Job   53         Coop
#[Out]# 12        Jax   54         Coop
#[Out]# 13     Tobias   56         Coop
#[Out]# 14     Morris   61         Coop
#[Out]# 15       Abel   62         Coop
#[Out]# 16     Pepijn   65         Coop
#[Out]# 17       Owen   73         Coop
#[Out]# 18     Samuel   74         Coop
#[Out]# 19     Joshua   79         Coop
#[Out]# 20      Simon   81         Coop
#[Out]# 21      Melle   83         Coop
#[Out]# 22      Jelle   87         Coop
#[Out]# 23   Johannes   89         Coop
#[Out]# 24      Oscar   93         Coop
#[Out]# 25      Julia   98         Coop
#[Out]# 26        Eva  101         Coop
#[Out]# 27        Evi  102         Coop
#[Out]# 28       Nora  105         Coop
#[Out]# 29      Fleur  106         Coop
#[Out]# ..        ...  ...          ...
#[Out]# 636      Iris  170  Albert Hein
#[Out]# 637      Iris  170         Lidl
#[Out]# 638      Iris  170    Hoogvliet
#[Out]# 639     Tessa  171        Jumbo
#[Out]# 640     Tessa  171  Albert Hein
#[Out]# 641      Lana  172        Jumbo
#[Out]# 642       Sam  175       Sligro
#[Out]# 643       Sam  175         Lidl
#[Out]# 644     Amira  176         Lidl
#[Out]# 645     Amira  176    Hoogvliet
#[Out]# 646     Eline  177    Hoogvliet
#[Out]# 647     Eline  177  Albert Hein
#[Out]# 648      Elif  178       Sligro
#[Out]# 649      Juul  179  Albert Hein
#[Out]# 650      Juul  179         Dirk
#[Out]# 651      Juul  179         Lidl
#[Out]# 652     Merel  180        Jumbo
#[Out]# 653      Liva  181       Sligro
#[Out]# 654   Johanna  182    Hoogvliet
#[Out]# 655   Johanna  182       Sligro
#[Out]# 656      Nick  185        Jumbo
#[Out]# 657    Angela  186        Jumbo
#[Out]# 658      Pino  188        Jumbo
#[Out]# 659      Koen  189        Jumbo
#[Out]# 660    Kostas  190    Hoogvliet
#[Out]# 661    Kostas  190        Jumbo
#[Out]# 662    Kostas  190       Sligro
#[Out]# 663    Kostas  190  Albert Hein
#[Out]# 664    Kostas  190         Lidl
#[Out]# 665    Kostas  190         Dirk
#[Out]# 
#[Out]# [666 rows x 3 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") 



    /*SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p
    WHERE c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )*/
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID,
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not in(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not EXISTS(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID EXISTS(
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and c.cID not in (
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID
#[Out]# 0      Milan    6
#[Out]# 1     Thomas    9
#[Out]# 2       Adam   12
#[Out]# 3        Max   14
#[Out]# 4        Jan   23
#[Out]# 5      Vince   32
#[Out]# 6       Boaz   36
#[Out]# 7      Fedde   46
#[Out]# 8       Tygo   48
#[Out]# 9        Cas   49
#[Out]# 10       Pim   50
#[Out]# 11       Job   53
#[Out]# 12       Jax   54
#[Out]# 13    Tobias   56
#[Out]# 14    Morris   61
#[Out]# 15      Abel   62
#[Out]# 16    Pepijn   65
#[Out]# 17      Owen   73
#[Out]# 18    Samuel   74
#[Out]# 19    Joshua   79
#[Out]# 20     Simon   81
#[Out]# 21     Melle   83
#[Out]# 22     Jelle   87
#[Out]# 23  Johannes   89
#[Out]# 24     Oscar   93
#[Out]# 25     Julia   98
#[Out]# 26       Eva  101
#[Out]# 27       Evi  102
#[Out]# 28      Nora  105
#[Out]# 29     Fleur  106
#[Out]# 30    Olivia  107
#[Out]# 31      Maud  114
#[Out]# 32      Nova  115
#[Out]# 33      Roos  117
#[Out]# 34     Sarah  120
#[Out]# 35       Isa  121
#[Out]# 36       Noa  125
#[Out]# 37     Sanne  130
#[Out]# 38    Hannah  132
#[Out]# 39     Maria  138
#[Out]# 40      Vera  140
#[Out]# 41       Mia  141
#[Out]# 42        Bo  142
#[Out]# 43     Naomi  143
#[Out]# 44     Norah  146
#[Out]# 45  Isabella  148
#[Out]# 46     Julie  150
#[Out]# 47     Amber  153
#[Out]# 48    Benthe  154
#[Out]# 49     Linde  155
#[Out]# 50      Luna  156
#[Out]# 51      Rosa  158
#[Out]# 52      Lara  160
#[Out]# 53       Evy  164
#[Out]# 54   Rosalie  166
#[Out]# 55     Livia  173
#[Out]# 56      Romy  174
#[Out]# 57     Nikki  183

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase

    )
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID        sName
#[Out]# 0      Milan    6         Coop
#[Out]# 1      Milan    6    Hoogvliet
#[Out]# 2      Milan    6        Jumbo
#[Out]# 3      Milan    6       Sligro
#[Out]# 4      Milan    6  Albert Hein
#[Out]# 5      Milan    6         Lidl
#[Out]# 6      Milan    6         Dirk
#[Out]# 7     Thomas    9         Coop
#[Out]# 8     Thomas    9    Hoogvliet
#[Out]# 9     Thomas    9        Jumbo
#[Out]# 10    Thomas    9       Sligro
#[Out]# 11    Thomas    9  Albert Hein
#[Out]# 12    Thomas    9         Lidl
#[Out]# 13    Thomas    9         Dirk
#[Out]# 14      Adam   12         Coop
#[Out]# 15      Adam   12    Hoogvliet
#[Out]# 16      Adam   12        Jumbo
#[Out]# 17      Adam   12       Sligro
#[Out]# 18      Adam   12  Albert Hein
#[Out]# 19      Adam   12         Lidl
#[Out]# 20      Adam   12         Dirk
#[Out]# 21       Max   14         Coop
#[Out]# 22       Max   14    Hoogvliet
#[Out]# 23       Max   14        Jumbo
#[Out]# 24       Max   14       Sligro
#[Out]# 25       Max   14  Albert Hein
#[Out]# 26       Max   14         Lidl
#[Out]# 27       Max   14         Dirk
#[Out]# 28       Jan   23         Coop
#[Out]# 29       Jan   23    Hoogvliet
#[Out]# ..       ...  ...          ...
#[Out]# 376      Evy  164         Lidl
#[Out]# 377      Evy  164         Dirk
#[Out]# 378  Rosalie  166         Coop
#[Out]# 379  Rosalie  166    Hoogvliet
#[Out]# 380  Rosalie  166        Jumbo
#[Out]# 381  Rosalie  166       Sligro
#[Out]# 382  Rosalie  166  Albert Hein
#[Out]# 383  Rosalie  166         Lidl
#[Out]# 384  Rosalie  166         Dirk
#[Out]# 385    Livia  173         Coop
#[Out]# 386    Livia  173    Hoogvliet
#[Out]# 387    Livia  173        Jumbo
#[Out]# 388    Livia  173       Sligro
#[Out]# 389    Livia  173  Albert Hein
#[Out]# 390    Livia  173         Lidl
#[Out]# 391    Livia  173         Dirk
#[Out]# 392     Romy  174         Coop
#[Out]# 393     Romy  174    Hoogvliet
#[Out]# 394     Romy  174        Jumbo
#[Out]# 395     Romy  174       Sligro
#[Out]# 396     Romy  174  Albert Hein
#[Out]# 397     Romy  174         Lidl
#[Out]# 398     Romy  174         Dirk
#[Out]# 399    Nikki  183         Coop
#[Out]# 400    Nikki  183    Hoogvliet
#[Out]# 401    Nikki  183        Jumbo
#[Out]# 402    Nikki  183       Sligro
#[Out]# 403    Nikki  183  Albert Hein
#[Out]# 404    Nikki  183         Lidl
#[Out]# 405    Nikki  183         Dirk
#[Out]# 
#[Out]# [406 rows x 3 columns]

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID        sName
#[Out]# 0      Milan    6       Sligro
#[Out]# 1      Milan    6         Dirk
#[Out]# 2      Milan    6    Hoogvliet
#[Out]# 3      Milan    6  Albert Hein
#[Out]# 4      Milan    6         Lidl
#[Out]# 5      Milan    6         Coop
#[Out]# 6      Milan    6        Jumbo
#[Out]# 7     Thomas    9       Sligro
#[Out]# 8     Thomas    9         Dirk
#[Out]# 9     Thomas    9    Hoogvliet
#[Out]# 10    Thomas    9  Albert Hein
#[Out]# 11    Thomas    9         Lidl
#[Out]# 12    Thomas    9         Coop
#[Out]# 13    Thomas    9        Jumbo
#[Out]# 14      Adam   12       Sligro
#[Out]# 15      Adam   12         Dirk
#[Out]# 16      Adam   12    Hoogvliet
#[Out]# 17      Adam   12  Albert Hein
#[Out]# 18      Adam   12         Lidl
#[Out]# 19      Adam   12         Coop
#[Out]# 20      Adam   12        Jumbo
#[Out]# 21       Max   14       Sligro
#[Out]# 22       Max   14         Dirk
#[Out]# 23       Max   14    Hoogvliet
#[Out]# 24       Max   14  Albert Hein
#[Out]# 25       Max   14         Lidl
#[Out]# 26       Max   14         Coop
#[Out]# 27       Max   14        Jumbo
#[Out]# 28       Jan   23       Sligro
#[Out]# 29       Jan   23         Dirk
#[Out]# ..       ...  ...          ...
#[Out]# 376      Evy  164         Coop
#[Out]# 377      Evy  164        Jumbo
#[Out]# 378  Rosalie  166       Sligro
#[Out]# 379  Rosalie  166         Dirk
#[Out]# 380  Rosalie  166    Hoogvliet
#[Out]# 381  Rosalie  166  Albert Hein
#[Out]# 382  Rosalie  166         Lidl
#[Out]# 383  Rosalie  166         Coop
#[Out]# 384  Rosalie  166        Jumbo
#[Out]# 385    Livia  173       Sligro
#[Out]# 386    Livia  173         Dirk
#[Out]# 387    Livia  173    Hoogvliet
#[Out]# 388    Livia  173  Albert Hein
#[Out]# 389    Livia  173         Lidl
#[Out]# 390    Livia  173         Coop
#[Out]# 391    Livia  173        Jumbo
#[Out]# 392     Romy  174       Sligro
#[Out]# 393     Romy  174         Dirk
#[Out]# 394     Romy  174    Hoogvliet
#[Out]# 395     Romy  174  Albert Hein
#[Out]# 396     Romy  174         Lidl
#[Out]# 397     Romy  174         Coop
#[Out]# 398     Romy  174        Jumbo
#[Out]# 399    Nikki  183       Sligro
#[Out]# 400    Nikki  183         Dirk
#[Out]# 401    Nikki  183    Hoogvliet
#[Out]# 402    Nikki  183  Albert Hein
#[Out]# 403    Nikki  183         Lidl
#[Out]# 404    Nikki  183         Coop
#[Out]# 405    Nikki  183        Jumbo
#[Out]# 
#[Out]# [406 rows x 3 columns]

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID and c.cID = p.pID
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cName  cID        sName
#[Out]# 0      Max   14         Dirk
#[Out]# 1   Thomas    9    Hoogvliet
#[Out]# 2   Thomas    9       Sligro
#[Out]# 3      Max   14  Albert Hein
#[Out]# 4     Adam   12         Coop
#[Out]# 5    Milan    6         Coop
#[Out]# 6      Max   14    Hoogvliet
#[Out]# 7     Adam   12  Albert Hein
#[Out]# 8    Milan    6    Hoogvliet
#[Out]# 9      Max   14         Coop
#[Out]# 10     Jan   23    Hoogvliet
#[Out]# 11     Jan   23         Coop
#[Out]# 12  Thomas    9        Jumbo
#[Out]# 13     Jan   23        Jumbo
#[Out]# 14   Milan    6         Lidl
#[Out]# 15   Milan    6  Albert Hein
#[Out]# 16     Max   14        Jumbo
#[Out]# 17    Adam   12         Dirk
#[Out]# 18   Milan    6       Sligro
#[Out]# 19     Max   14       Sligro
#[Out]# 20    Adam   12       Sligro
#[Out]# 21  Thomas    9  Albert Hein
#[Out]# 22  Thomas    9         Lidl
#[Out]# 23   Milan    6         Dirk
#[Out]# 24    Adam   12    Hoogvliet
#[Out]# 25  Thomas    9         Coop
#[Out]# 26  Thomas    9         Dirk
#[Out]# 27     Jan   23  Albert Hein
#[Out]# 28     Max   14         Lidl
#[Out]# 29     Jan   23         Lidl

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID and c.cID = p.cID
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID 
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID        sName
#[Out]# 0      0       Sligro
#[Out]# 1      1         Dirk
#[Out]# 2      1       Sligro
#[Out]# 3      1    Hoogvliet
#[Out]# 4      1  Albert Hein
#[Out]# 5      1         Lidl
#[Out]# 6      2         Lidl
#[Out]# 7      2       Sligro
#[Out]# 8      2         Coop
#[Out]# 9      3  Albert Hein
#[Out]# 10     3         Dirk
#[Out]# 11     3       Sligro
#[Out]# 12     4    Hoogvliet
#[Out]# 13     4        Jumbo
#[Out]# 14     4         Coop
#[Out]# 15     4       Sligro
#[Out]# 16     4  Albert Hein
#[Out]# 17     5    Hoogvliet
#[Out]# 18     5         Lidl
#[Out]# 19     5         Coop
#[Out]# 20     7       Sligro
#[Out]# 21     7         Lidl
#[Out]# 22     7  Albert Hein
#[Out]# 23     7    Hoogvliet
#[Out]# 24     8         Coop
#[Out]# 25    10         Coop
#[Out]# 26    11         Coop
#[Out]# 27    13         Dirk
#[Out]# 28    13    Hoogvliet
#[Out]# 29    13         Lidl
#[Out]# ..   ...          ...
#[Out]# 304  176         Lidl
#[Out]# 305  176         Coop
#[Out]# 306  176    Hoogvliet
#[Out]# 307  177         Coop
#[Out]# 308  177    Hoogvliet
#[Out]# 309  177  Albert Hein
#[Out]# 310  178         Coop
#[Out]# 311  178       Sligro
#[Out]# 312  179  Albert Hein
#[Out]# 313  179         Dirk
#[Out]# 314  179         Coop
#[Out]# 315  179         Lidl
#[Out]# 316  180         Coop
#[Out]# 317  180        Jumbo
#[Out]# 318  181         Coop
#[Out]# 319  181       Sligro
#[Out]# 320  182    Hoogvliet
#[Out]# 321  182       Sligro
#[Out]# 322  184         Coop
#[Out]# 323  185        Jumbo
#[Out]# 324  186        Jumbo
#[Out]# 325  188        Jumbo
#[Out]# 326  189        Jumbo
#[Out]# 327  190         Coop
#[Out]# 328  190    Hoogvliet
#[Out]# 329  190        Jumbo
#[Out]# 330  190       Sligro
#[Out]# 331  190  Albert Hein
#[Out]# 332  190         Lidl
#[Out]# 333  190         Dirk
#[Out]# 
#[Out]# [334 rows x 2 columns]

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM purchase as p, store as s
    WHERE c.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID 
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM purchase as p, store as s
    WHERE p.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM purchase as p, store as s
    WHERE p.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop")


'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName = "")


'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is NULL)


'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" )


'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is NULL)


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" )


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and (p.sID = s.sID or p.sID is NULL) and (s.sName <> "Coop" or p.sID is NULL)


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID or p.cID is NULL) and p.sID = s.sID and (s.sName <> "Coop" or p.sID is NULL)


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID or p.cID is NULL) and p.sID = s.sID and s.sName <> "Coop"


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" 


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or p.sID is NULL)


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName is NULL


'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    --c.cID = p.cID and p.sID = s.sID and s.sName /*<> "Coop"*/


'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    --c.cID = p.cID and p.sID = s.sID and s.sName /*<> "Coop"*/


'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID]
#[Out]# Index: []

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */
    
    SELECT 
    

'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */

    SELECT *


'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */

    SELECT *
    from customer


'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName                street       city
#[Out]# 0      0      Noah             Koestraat    Utrecht
#[Out]# 1      1       Sem      Rozemarijnstraat      Breda
#[Out]# 2      2     Lucas      Oude Leliestraat  Amsterdam
#[Out]# 3      3      Finn         Stationsplein      Breda
#[Out]# 4      4      Daan          Kalverstraat  Amsterdam
#[Out]# 5      5      Levi        Gasthuisstraat    Utrecht
#[Out]# 6      6     Milan           Parallelweg    Utrecht
#[Out]# 7      7      Bram          Schoolstraat  Eindhoven
#[Out]# 8      8      Liam         Rijsbergseweg      Breda
#[Out]# 9      9    Thomas           Parallelweg  Amsterdam
#[Out]# 10    10       Sam           Langestraat    Tilburg
#[Out]# 11    11     Thijs             Koestraat    Tilburg
#[Out]# 12    12      Adam           Nieuwstraat  Eindhoven
#[Out]# 13    13     James       Sint Annastraat      Breda
#[Out]# 14    14       Max             Eikenlaan    Tilburg
#[Out]# 15    15      Noud          Koningshoeve    Tilburg
#[Out]# 16    16    Julian  Prins Bernhardstraat  Eindhoven
#[Out]# 17    17       Dex          Kasteeldreef    Tilburg
#[Out]# 18    18      Hugo          Kasteeldreef    Tilburg
#[Out]# 19    19      Lars         Rijsbergseweg      Breda
#[Out]# 20    20      Gijs            Heiligeweg  Amsterdam
#[Out]# 21    21  Benjamin           Stationsweg    Tilburg
#[Out]# 22    22      Mats           Molenstraat  Eindhoven
#[Out]# 23    23       Jan       Sint Annastraat      Breda
#[Out]# 24    24      Luca          Kasteeldreef    Tilburg
#[Out]# 25    25     Mason          Keizerstraat  Rotterdam
#[Out]# 26    26    Jayden          Schoolstraat  Eindhoven
#[Out]# 27    27       Tim             Koestraat    Utrecht
#[Out]# 28    28      Siem           Langestraat    Tilburg
#[Out]# 29    29     Ruben              Hofplein  Rotterdam
#[Out]# ..   ...       ...                   ...        ...
#[Out]# 160  160      Lara           Langestraat    Tilburg
#[Out]# 161  161     Floor             Eikenlaan    Tilburg
#[Out]# 162  162     Elena            Bergselaan  Rotterdam
#[Out]# 163  163      Cato          Kastanjelaan    Tilburg
#[Out]# 164  164       Evy      Rozemarijnstraat      Breda
#[Out]# 165  165     Hanna             Eikenlaan    Tilburg
#[Out]# 166  166   Rosalie           Stationsweg  Eindhoven
#[Out]# 167  167    Veerle        Ginnekenstraat      Breda
#[Out]# 168  168      Kiki          Keizerstraat  Rotterdam
#[Out]# 169  169      Lily        Gasthuisstraat    Utrecht
#[Out]# 170  170      Iris          Kastanjelaan  Eindhoven
#[Out]# 171  171     Tessa           Haringvliet  Rotterdam
#[Out]# 172  172      Lana             Eikenlaan    Tilburg
#[Out]# 173  173     Livia      Vierwindenstraat      Breda
#[Out]# 174  174      Romy           Parallelweg  Eindhoven
#[Out]# 175  175       Sam             Bredalaan  Eindhoven
#[Out]# 176  176     Amira           Parallelweg  Amsterdam
#[Out]# 177  177     Eline          Kalverstraat  Amsterdam
#[Out]# 178  178      Elif           Parallelweg    Utrecht
#[Out]# 179  179      Juul        Wilhelminapark    Tilburg
#[Out]# 180  180     Merel          Kalverstraat  Amsterdam
#[Out]# 181  181      Liva           Fredriklaan  Eindhoven
#[Out]# 182  182   Johanna         Beatrixstraat  Eindhoven
#[Out]# 183  183     Nikki         Julianastraat    Utrecht
#[Out]# 184  184     Wilko          Onbekendeweg  Eindhoven
#[Out]# 185  185      Nick                Verweg  Eindhoven
#[Out]# 186  186    Angela              Dichtweg  Eindhoven
#[Out]# 187  188      Pino            Maanstraat  Rotterdam
#[Out]# 188  189      Koen              Akkerweg        Oss
#[Out]# 189  190    Kostas              Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */

    
    SELECT cID
    FROM customer as c
    WHERE c.cID not in (
        SELECT c.cID
        FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /* SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE p.cID is null
    c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop" */


    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase


'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID
#[Out]# 0     6
#[Out]# 1     9
#[Out]# 2    12
#[Out]# 3    14
#[Out]# 4    23
#[Out]# 5    32
#[Out]# 6    36
#[Out]# 7    46
#[Out]# 8    48
#[Out]# 9    49
#[Out]# 10   50
#[Out]# 11   53
#[Out]# 12   54
#[Out]# 13   56
#[Out]# 14   61
#[Out]# 15   62
#[Out]# 16   65
#[Out]# 17   73
#[Out]# 18   74
#[Out]# 19   79
#[Out]# 20   81
#[Out]# 21   83
#[Out]# 22   87
#[Out]# 23   89
#[Out]# 24   93
#[Out]# 25   98
#[Out]# 26  101
#[Out]# 27  102
#[Out]# 28  105
#[Out]# 29  106
#[Out]# 30  107
#[Out]# 31  114
#[Out]# 32  115
#[Out]# 33  117
#[Out]# 34  120
#[Out]# 35  121
#[Out]# 36  125
#[Out]# 37  130
#[Out]# 38  132
#[Out]# 39  138
#[Out]# 40  140
#[Out]# 41  141
#[Out]# 42  142
#[Out]# 43  143
#[Out]# 44  146
#[Out]# 45  148
#[Out]# 46  150
#[Out]# 47  153
#[Out]# 48  154
#[Out]# 49  155
#[Out]# 50  156
#[Out]# 51  158
#[Out]# 52  160
#[Out]# 53  164
#[Out]# 54  166
#[Out]# 55  173
#[Out]# 56  174
#[Out]# 57  183

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (
    
    

    SELECT cID, cName
    FROM customer
    EXCEPT
    SELECT cID, cName
    FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0       Milan    6
#[Out]# 1      Thomas    9
#[Out]# 2        Adam   12
#[Out]# 3         Max   14
#[Out]# 4         Jan   23
#[Out]# 5       Vince   32
#[Out]# 6        Boaz   36
#[Out]# 7       Fedde   46
#[Out]# 8        Tygo   48
#[Out]# 9         Cas   49
#[Out]# 10        Pim   50
#[Out]# 11        Job   53
#[Out]# 12        Jax   54
#[Out]# 13     Tobias   56
#[Out]# 14     Morris   61
#[Out]# 15       Abel   62
#[Out]# 16     Pepijn   65
#[Out]# 17       Owen   73
#[Out]# 18     Samuel   74
#[Out]# 19     Joshua   79
#[Out]# 20      Simon   81
#[Out]# 21      Melle   83
#[Out]# 22      Jelle   87
#[Out]# 23   Johannes   89
#[Out]# 24      Oscar   93
#[Out]# 25      Julia   98
#[Out]# 26        Eva  101
#[Out]# 27        Evi  102
#[Out]# 28       Nora  105
#[Out]# 29      Fleur  106
#[Out]# ..        ...  ...
#[Out]# 146       Ivy  144
#[Out]# 147      Fien  145
#[Out]# 148    Isabel  147
#[Out]# 149     Lizzy  149
#[Out]# 150      Anne  152
#[Out]# 151      Puck  157
#[Out]# 152     Fenne  159
#[Out]# 153     Floor  161
#[Out]# 154     Elena  162
#[Out]# 155      Cato  163
#[Out]# 156     Hanna  165
#[Out]# 157    Veerle  167
#[Out]# 158      Kiki  168
#[Out]# 159      Lily  169
#[Out]# 160      Iris  170
#[Out]# 161     Tessa  171
#[Out]# 162      Lana  172
#[Out]# 163       Sam  175
#[Out]# 164     Amira  176
#[Out]# 165     Eline  177
#[Out]# 166      Elif  178
#[Out]# 167      Juul  179
#[Out]# 168     Merel  180
#[Out]# 169      Liva  181
#[Out]# 170   Johanna  182
#[Out]# 171      Nick  185
#[Out]# 172    Angela  186
#[Out]# 173      Pino  188
#[Out]# 174      Koen  189
#[Out]# 175    Kostas  190
#[Out]# 
#[Out]# [176 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Jumbo") or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0       Milan    6
#[Out]# 1      Thomas    9
#[Out]# 2        Adam   12
#[Out]# 3         Max   14
#[Out]# 4         Jan   23
#[Out]# 5       Vince   32
#[Out]# 6        Boaz   36
#[Out]# 7       Fedde   46
#[Out]# 8        Tygo   48
#[Out]# 9         Cas   49
#[Out]# 10        Pim   50
#[Out]# 11        Job   53
#[Out]# 12        Jax   54
#[Out]# 13     Tobias   56
#[Out]# 14     Morris   61
#[Out]# 15       Abel   62
#[Out]# 16     Pepijn   65
#[Out]# 17       Owen   73
#[Out]# 18     Samuel   74
#[Out]# 19     Joshua   79
#[Out]# 20      Simon   81
#[Out]# 21      Melle   83
#[Out]# 22      Jelle   87
#[Out]# 23   Johannes   89
#[Out]# 24      Oscar   93
#[Out]# 25      Julia   98
#[Out]# 26        Eva  101
#[Out]# 27        Evi  102
#[Out]# 28       Nora  105
#[Out]# 29      Fleur  106
#[Out]# ..        ...  ...
#[Out]# 152      Lena  137
#[Out]# 153     Elise  139
#[Out]# 154       Ivy  144
#[Out]# 155      Fien  145
#[Out]# 156    Isabel  147
#[Out]# 157     Lizzy  149
#[Out]# 158      Jill  151
#[Out]# 159      Anne  152
#[Out]# 160      Puck  157
#[Out]# 161     Fenne  159
#[Out]# 162     Floor  161
#[Out]# 163     Elena  162
#[Out]# 164      Cato  163
#[Out]# 165     Hanna  165
#[Out]# 166    Veerle  167
#[Out]# 167      Kiki  168
#[Out]# 168      Lily  169
#[Out]# 169      Iris  170
#[Out]# 170     Tessa  171
#[Out]# 171      Lana  172
#[Out]# 172       Sam  175
#[Out]# 173     Amira  176
#[Out]# 174     Eline  177
#[Out]# 175      Elif  178
#[Out]# 176      Juul  179
#[Out]# 177     Merel  180
#[Out]# 178      Liva  181
#[Out]# 179   Johanna  182
#[Out]# 180     Wilko  184
#[Out]# 181    Kostas  190
#[Out]# 
#[Out]# [182 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0       Milan    6
#[Out]# 1      Thomas    9
#[Out]# 2        Adam   12
#[Out]# 3         Max   14
#[Out]# 4         Jan   23
#[Out]# 5       Vince   32
#[Out]# 6        Boaz   36
#[Out]# 7       Fedde   46
#[Out]# 8        Tygo   48
#[Out]# 9         Cas   49
#[Out]# 10        Pim   50
#[Out]# 11        Job   53
#[Out]# 12        Jax   54
#[Out]# 13     Tobias   56
#[Out]# 14     Morris   61
#[Out]# 15       Abel   62
#[Out]# 16     Pepijn   65
#[Out]# 17       Owen   73
#[Out]# 18     Samuel   74
#[Out]# 19     Joshua   79
#[Out]# 20      Simon   81
#[Out]# 21      Melle   83
#[Out]# 22      Jelle   87
#[Out]# 23   Johannes   89
#[Out]# 24      Oscar   93
#[Out]# 25      Julia   98
#[Out]# 26        Eva  101
#[Out]# 27        Evi  102
#[Out]# 28       Nora  105
#[Out]# 29      Fleur  106
#[Out]# ..        ...  ...
#[Out]# 146       Ivy  144
#[Out]# 147      Fien  145
#[Out]# 148    Isabel  147
#[Out]# 149     Lizzy  149
#[Out]# 150      Anne  152
#[Out]# 151      Puck  157
#[Out]# 152     Fenne  159
#[Out]# 153     Floor  161
#[Out]# 154     Elena  162
#[Out]# 155      Cato  163
#[Out]# 156     Hanna  165
#[Out]# 157    Veerle  167
#[Out]# 158      Kiki  168
#[Out]# 159      Lily  169
#[Out]# 160      Iris  170
#[Out]# 161     Tessa  171
#[Out]# 162      Lana  172
#[Out]# 163       Sam  175
#[Out]# 164     Amira  176
#[Out]# 165     Eline  177
#[Out]# 166      Elif  178
#[Out]# 167      Juul  179
#[Out]# 168     Merel  180
#[Out]# 169      Liva  181
#[Out]# 170   Johanna  182
#[Out]# 171      Nick  185
#[Out]# 172    Angela  186
#[Out]# 173      Pino  188
#[Out]# 174      Koen  189
#[Out]# 175    Kostas  190
#[Out]# 
#[Out]# [176 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    ))


'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    ))


'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )) and p.sName is null


'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )) and s.sName is null


'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName, cID, sName]
#[Out]# Index: []

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    )) `


'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    ));*/

    SELECT cID
    FROM purchase
    EXCEPT
    SELECT cID
    FROM purchase as p, store as s
    WHERE S.sID = S.sID and s.sName = "Coop"
    
'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''


    SELECT cID
    FROM purchase
    EXCEPT
    SELECT cID
    FROM purchase as p, store as s
    WHERE S.sID = S.sID and s.sName = "Coop"

'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or c.cID in (



    SELECT cID
    FROM customer
    EXCEPT
    SELECT cID
    FROM purchase
    ));*/

    SELECT cID
    FROM purchase
    EXCEPT
    SELECT cID
    FROM purchase as p, store as s
    WHERE S.sID = S.sID and s.sName = "Coop"

'''

pd.read_sql_query(query3_3, conn)

query3_3 = '''


    SELECT cID
    FROM purchase
    EXCEPT
    SELECT cID
    FROM purchase as p, store as s
    WHERE S.sID = S.sID and s.sName = "Coop"

'''

pd.read_sql_query(query3_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is null)

'''

pd.read_sql_query(query3_3, conn)
#[Out]#        cName  cID        sName
#[Out]# 0       Noah    0       Sligro
#[Out]# 1        Sem    1         Dirk
#[Out]# 2        Sem    1       Sligro
#[Out]# 3        Sem    1    Hoogvliet
#[Out]# 4        Sem    1  Albert Hein
#[Out]# 5        Sem    1         Lidl
#[Out]# 6      Lucas    2         Lidl
#[Out]# 7      Lucas    2       Sligro
#[Out]# 8       Finn    3  Albert Hein
#[Out]# 9       Finn    3         Dirk
#[Out]# 10      Finn    3       Sligro
#[Out]# 11      Daan    4    Hoogvliet
#[Out]# 12      Daan    4        Jumbo
#[Out]# 13      Daan    4       Sligro
#[Out]# 14      Daan    4  Albert Hein
#[Out]# 15      Levi    5    Hoogvliet
#[Out]# 16      Levi    5         Lidl
#[Out]# 17      Bram    7       Sligro
#[Out]# 18      Bram    7         Lidl
#[Out]# 19      Bram    7  Albert Hein
#[Out]# 20      Bram    7    Hoogvliet
#[Out]# 21     James   13         Dirk
#[Out]# 22     James   13    Hoogvliet
#[Out]# 23     James   13         Lidl
#[Out]# 24     James   13       Sligro
#[Out]# 25     James   13  Albert Hein
#[Out]# 26      Noud   15  Albert Hein
#[Out]# 27    Julian   16       Sligro
#[Out]# 28    Julian   16         Lidl
#[Out]# 29    Julian   16  Albert Hein
#[Out]# ..       ...  ...          ...
#[Out]# 230     Iris  170  Albert Hein
#[Out]# 231     Iris  170         Lidl
#[Out]# 232     Iris  170    Hoogvliet
#[Out]# 233    Tessa  171        Jumbo
#[Out]# 234    Tessa  171  Albert Hein
#[Out]# 235     Lana  172        Jumbo
#[Out]# 236      Sam  175       Sligro
#[Out]# 237      Sam  175         Lidl
#[Out]# 238    Amira  176         Lidl
#[Out]# 239    Amira  176    Hoogvliet
#[Out]# 240    Eline  177    Hoogvliet
#[Out]# 241    Eline  177  Albert Hein
#[Out]# 242     Elif  178       Sligro
#[Out]# 243     Juul  179  Albert Hein
#[Out]# 244     Juul  179         Dirk
#[Out]# 245     Juul  179         Lidl
#[Out]# 246    Merel  180        Jumbo
#[Out]# 247     Liva  181       Sligro
#[Out]# 248  Johanna  182    Hoogvliet
#[Out]# 249  Johanna  182       Sligro
#[Out]# 250     Nick  185        Jumbo
#[Out]# 251   Angela  186        Jumbo
#[Out]# 252     Pino  188        Jumbo
#[Out]# 253     Koen  189        Jumbo
#[Out]# 254   Kostas  190    Hoogvliet
#[Out]# 255   Kostas  190        Jumbo
#[Out]# 256   Kostas  190       Sligro
#[Out]# 257   Kostas  190  Albert Hein
#[Out]# 258   Kostas  190         Lidl
#[Out]# 259   Kostas  190         Dirk
#[Out]# 
#[Out]# [260 rows x 3 columns]

query3_3 = '''
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is null)

'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]

query3_4 = '''
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop" 
    EXCEPT 
    SELECT DISTINCT c.cID, c.cName
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName != "Coop" 
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID      cName
#[Out]# 0     8       Liam
#[Out]# 1    10        Sam
#[Out]# 2    11      Thijs
#[Out]# 3    26     Jayden
#[Out]# 4    28       Siem
#[Out]# 5    55      Aiden
#[Out]# 6    76  Alexander
#[Out]# 7    88      Joris
#[Out]# 8    99       Anna
#[Out]# 9   103      Lotte
#[Out]# 10  131        Amy
#[Out]# 11  135      Sofia
#[Out]# 12  151       Jill
#[Out]# 13  184      Wilko

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT 
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop"

'''

pd.read_sql_query(query3_3, conn)
#[Out]#         cName  cID
#[Out]# 0        Abel   62
#[Out]# 1        Adam   12
#[Out]# 2       Amber  153
#[Out]# 3      Angela  186
#[Out]# 4      Benthe  154
#[Out]# 5          Bo  142
#[Out]# 6        Boaz   36
#[Out]# 7       Boris   68
#[Out]# 8        Bram    7
#[Out]# 9         Cas   49
#[Out]# 10     Casper   84
#[Out]# 11       Dani   72
#[Out]# 12      David   34
#[Out]# 13       Emma   95
#[Out]# 14        Eva  101
#[Out]# 15        Evi  102
#[Out]# 16        Evy  164
#[Out]# 17      Fedde   46
#[Out]# 18      Femke  136
#[Out]# 19      Fenne  159
#[Out]# 20       Fien  145
#[Out]# 21       Finn    3
#[Out]# 22      Fleur  106
#[Out]# 23     Floris   38
#[Out]# 24       Guus   37
#[Out]# 25     Hannah  132
#[Out]# 26      Hidde   77
#[Out]# 27       Iris  170
#[Out]# 28        Isa  121
#[Out]# 29   Isabella  148
#[Out]# ..        ...  ...
#[Out]# 86        Pim   50
#[Out]# 87       Pino  188
#[Out]# 88       Puck  157
#[Out]# 89      Quinn   41
#[Out]# 90       Roan   69
#[Out]# 91       Romy  174
#[Out]# 92       Roos  117
#[Out]# 93       Rosa  158
#[Out]# 94    Rosalie  166
#[Out]# 95       Ryan   45
#[Out]# 96        Sam  175
#[Out]# 97     Samuel   74
#[Out]# 98      Sanne  130
#[Out]# 99      Sarah  120
#[Out]# 100       Sem    1
#[Out]# 101      Senn   63
#[Out]# 102     Simon   81
#[Out]# 103      Stan   64
#[Out]# 104      Stef   86
#[Out]# 105     Tessa  171
#[Out]# 106      Teun   30
#[Out]# 107    Thomas    9
#[Out]# 108    Tobias   56
#[Out]# 109       Tom   43
#[Out]# 110      Tygo   48
#[Out]# 111    Veerle  167
#[Out]# 112      Vera  140
#[Out]# 113     Vince   32
#[Out]# 114    Willem   52
#[Out]# 115      Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Jumbo"

'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7         Anna   99
#[Out]# 8         Anne  152
#[Out]# 9       Benthe  154
#[Out]# 10          Bo  142
#[Out]# 11        Boaz   36
#[Out]# 12        Bram    7
#[Out]# 13         Cas   49
#[Out]# 14      Casper   84
#[Out]# 15        Cato  163
#[Out]# 16       David   34
#[Out]# 17        Dean   71
#[Out]# 18         Dex   17
#[Out]# 19       Dylan   82
#[Out]# 20       Elena  162
#[Out]# 21        Elif  178
#[Out]# 22       Eline  177
#[Out]# 23       Elise  139
#[Out]# 24        Ella  134
#[Out]# 25       Emily  127
#[Out]# 26        Emma   95
#[Out]# 27       Esmee  129
#[Out]# 28         Eva  101
#[Out]# 29         Evi  102
#[Out]# ..         ...  ...
#[Out]# 125       Saar  110
#[Out]# 126        Sam   10
#[Out]# 127        Sam  175
#[Out]# 128     Samuel   74
#[Out]# 129      Sanne  130
#[Out]# 130       Sara  100
#[Out]# 131      Sarah  120
#[Out]# 132        Sem    1
#[Out]# 133       Siem   28
#[Out]# 134      Simon   81
#[Out]# 135      Sofia  135
#[Out]# 136      Sofie  124
#[Out]# 137     Sophia  133
#[Out]# 138     Sophie   97
#[Out]# 139       Stan   64
#[Out]# 140      Stijn   35
#[Out]# 141       Sven   33
#[Out]# 142       Tess   96
#[Out]# 143       Teun   30
#[Out]# 144    Thijmen   91
#[Out]# 145      Thijs   11
#[Out]# 146     Thomas    9
#[Out]# 147       Ties   51
#[Out]# 148       Tijn   42
#[Out]# 149     Tobias   56
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Jumbo"

'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7         Anna   99
#[Out]# 8         Anne  152
#[Out]# 9       Benthe  154
#[Out]# 10          Bo  142
#[Out]# 11        Boaz   36
#[Out]# 12        Bram    7
#[Out]# 13         Cas   49
#[Out]# 14      Casper   84
#[Out]# 15        Cato  163
#[Out]# 16       David   34
#[Out]# 17        Dean   71
#[Out]# 18         Dex   17
#[Out]# 19       Dylan   82
#[Out]# 20       Elena  162
#[Out]# 21        Elif  178
#[Out]# 22       Eline  177
#[Out]# 23       Elise  139
#[Out]# 24        Ella  134
#[Out]# 25       Emily  127
#[Out]# 26        Emma   95
#[Out]# 27       Esmee  129
#[Out]# 28         Eva  101
#[Out]# 29         Evi  102
#[Out]# ..         ...  ...
#[Out]# 125       Saar  110
#[Out]# 126        Sam   10
#[Out]# 127        Sam  175
#[Out]# 128     Samuel   74
#[Out]# 129      Sanne  130
#[Out]# 130       Sara  100
#[Out]# 131      Sarah  120
#[Out]# 132        Sem    1
#[Out]# 133       Siem   28
#[Out]# 134      Simon   81
#[Out]# 135      Sofia  135
#[Out]# 136      Sofie  124
#[Out]# 137     Sophia  133
#[Out]# 138     Sophie   97
#[Out]# 139       Stan   64
#[Out]# 140      Stijn   35
#[Out]# 141       Sven   33
#[Out]# 142       Tess   96
#[Out]# 143       Teun   30
#[Out]# 144    Thijmen   91
#[Out]# 145      Thijs   11
#[Out]# 146     Thomas    9
#[Out]# 147       Ties   51
#[Out]# 148       Tijn   42
#[Out]# 149     Tobias   56
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM purchase as p, store as s
    WHERE p.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:33:32

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 

# Wed, 02 Dec 2020 12:33:32

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# Wed, 02 Dec 2020 12:34:37
query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Jumbo"

'''

pd.read_sql_query(query3_3, conn)
#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7         Anna   99
#[Out]# 8         Anne  152
#[Out]# 9       Benthe  154
#[Out]# 10          Bo  142
#[Out]# 11        Boaz   36
#[Out]# 12        Bram    7
#[Out]# 13         Cas   49
#[Out]# 14      Casper   84
#[Out]# 15        Cato  163
#[Out]# 16       David   34
#[Out]# 17        Dean   71
#[Out]# 18         Dex   17
#[Out]# 19       Dylan   82
#[Out]# 20       Elena  162
#[Out]# 21        Elif  178
#[Out]# 22       Eline  177
#[Out]# 23       Elise  139
#[Out]# 24        Ella  134
#[Out]# 25       Emily  127
#[Out]# 26        Emma   95
#[Out]# 27       Esmee  129
#[Out]# 28         Eva  101
#[Out]# 29         Evi  102
#[Out]# ..         ...  ...
#[Out]# 125       Saar  110
#[Out]# 126        Sam   10
#[Out]# 127        Sam  175
#[Out]# 128     Samuel   74
#[Out]# 129      Sanne  130
#[Out]# 130       Sara  100
#[Out]# 131      Sarah  120
#[Out]# 132        Sem    1
#[Out]# 133       Siem   28
#[Out]# 134      Simon   81
#[Out]# 135      Sofia  135
#[Out]# 136      Sofie  124
#[Out]# 137     Sophia  133
#[Out]# 138     Sophie   97
#[Out]# 139       Stan   64
#[Out]# 140      Stijn   35
#[Out]# 141       Sven   33
#[Out]# 142       Tess   96
#[Out]# 143       Teun   30
#[Out]# 144    Thijmen   91
#[Out]# 145      Thijs   11
#[Out]# 146     Thomas    9
#[Out]# 147       Ties   51
#[Out]# 148       Tijn   42
#[Out]# 149     Tobias   56
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Wed, 02 Dec 2020 12:34:45

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Jumbo"

'''

pd.read_sql_query(query3_3, conn)

#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7         Anna   99
#[Out]# 8         Anne  152
#[Out]# 9       Benthe  154
#[Out]# 10          Bo  142
#[Out]# 11        Boaz   36
#[Out]# 12        Bram    7
#[Out]# 13         Cas   49
#[Out]# 14      Casper   84
#[Out]# 15        Cato  163
#[Out]# 16       David   34
#[Out]# 17        Dean   71
#[Out]# 18         Dex   17
#[Out]# 19       Dylan   82
#[Out]# 20       Elena  162
#[Out]# 21        Elif  178
#[Out]# 22       Eline  177
#[Out]# 23       Elise  139
#[Out]# 24        Ella  134
#[Out]# 25       Emily  127
#[Out]# 26        Emma   95
#[Out]# 27       Esmee  129
#[Out]# 28         Eva  101
#[Out]# 29         Evi  102
#[Out]# ..         ...  ...
#[Out]# 125       Saar  110
#[Out]# 126        Sam   10
#[Out]# 127        Sam  175
#[Out]# 128     Samuel   74
#[Out]# 129      Sanne  130
#[Out]# 130       Sara  100
#[Out]# 131      Sarah  120
#[Out]# 132        Sem    1
#[Out]# 133       Siem   28
#[Out]# 134      Simon   81
#[Out]# 135      Sofia  135
#[Out]# 136      Sofie  124
#[Out]# 137     Sophia  133
#[Out]# 138     Sophie   97
#[Out]# 139       Stan   64
#[Out]# 140      Stijn   35
#[Out]# 141       Sven   33
#[Out]# 142       Tess   96
#[Out]# 143       Teun   30
#[Out]# 144    Thijmen   91
#[Out]# 145      Thijs   11
#[Out]# 146     Thomas    9
#[Out]# 147       Ties   51
#[Out]# 148       Tijn   42
#[Out]# 149     Tobias   56
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Wed, 02 Dec 2020 12:34:53

query3_3 = '''
    /*SELECT DISTINCT c.cName, c.cID, s.sName
    FROM customer as c, purchase as p, store as s
    WHERE (c.cID = p.cID and p.sID = s.sID and s.sName <> "Coop") */



    SELECT DISTINCT p.cID, s.sName
    FROM purchase as p, store as s
    WHERE p.cID not in (
        SELECT DISTINCT cID
        FROM purchase
    ) and p.sID = s.sID
'''

pd.read_sql_query(query3_3, conn)


# IPython log file


query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Jumbo"

'''

pd.read_sql_query(query3_3, conn)
# Wed, 02 Dec 2020 12:43:52

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 

# Wed, 02 Dec 2020 12:43:53

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# Wed, 02 Dec 2020 12:44:14

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Jumbo"

'''

pd.read_sql_query(query3_3, conn)

#[Out]#          cName  cID
#[Out]# 0         Abel   62
#[Out]# 1         Adam   12
#[Out]# 2        Aiden   55
#[Out]# 3    Alexander   76
#[Out]# 4        Amber  153
#[Out]# 5        Amira  176
#[Out]# 6          Amy  131
#[Out]# 7         Anna   99
#[Out]# 8         Anne  152
#[Out]# 9       Benthe  154
#[Out]# 10          Bo  142
#[Out]# 11        Boaz   36
#[Out]# 12        Bram    7
#[Out]# 13         Cas   49
#[Out]# 14      Casper   84
#[Out]# 15        Cato  163
#[Out]# 16       David   34
#[Out]# 17        Dean   71
#[Out]# 18         Dex   17
#[Out]# 19       Dylan   82
#[Out]# 20       Elena  162
#[Out]# 21        Elif  178
#[Out]# 22       Eline  177
#[Out]# 23       Elise  139
#[Out]# 24        Ella  134
#[Out]# 25       Emily  127
#[Out]# 26        Emma   95
#[Out]# 27       Esmee  129
#[Out]# 28         Eva  101
#[Out]# 29         Evi  102
#[Out]# ..         ...  ...
#[Out]# 125       Saar  110
#[Out]# 126        Sam   10
#[Out]# 127        Sam  175
#[Out]# 128     Samuel   74
#[Out]# 129      Sanne  130
#[Out]# 130       Sara  100
#[Out]# 131      Sarah  120
#[Out]# 132        Sem    1
#[Out]# 133       Siem   28
#[Out]# 134      Simon   81
#[Out]# 135      Sofia  135
#[Out]# 136      Sofie  124
#[Out]# 137     Sophia  133
#[Out]# 138     Sophie   97
#[Out]# 139       Stan   64
#[Out]# 140      Stijn   35
#[Out]# 141       Sven   33
#[Out]# 142       Tess   96
#[Out]# 143       Teun   30
#[Out]# 144    Thijmen   91
#[Out]# 145      Thijs   11
#[Out]# 146     Thomas    9
#[Out]# 147       Ties   51
#[Out]# 148       Tijn   42
#[Out]# 149     Tobias   56
#[Out]# 150        Tom   43
#[Out]# 151       Tygo   48
#[Out]# 152       Vera  140
#[Out]# 153      Vince   32
#[Out]# 154      Wilko  184
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Wed, 02 Dec 2020 12:44:28

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop"

'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Abel   62
#[Out]# 1        Adam   12
#[Out]# 2       Amber  153
#[Out]# 3      Angela  186
#[Out]# 4      Benthe  154
#[Out]# 5          Bo  142
#[Out]# 6        Boaz   36
#[Out]# 7       Boris   68
#[Out]# 8        Bram    7
#[Out]# 9         Cas   49
#[Out]# 10     Casper   84
#[Out]# 11       Dani   72
#[Out]# 12      David   34
#[Out]# 13       Emma   95
#[Out]# 14        Eva  101
#[Out]# 15        Evi  102
#[Out]# 16        Evy  164
#[Out]# 17      Fedde   46
#[Out]# 18      Femke  136
#[Out]# 19      Fenne  159
#[Out]# 20       Fien  145
#[Out]# 21       Finn    3
#[Out]# 22      Fleur  106
#[Out]# 23     Floris   38
#[Out]# 24       Guus   37
#[Out]# 25     Hannah  132
#[Out]# 26      Hidde   77
#[Out]# 27       Iris  170
#[Out]# 28        Isa  121
#[Out]# 29   Isabella  148
#[Out]# ..        ...  ...
#[Out]# 86        Pim   50
#[Out]# 87       Pino  188
#[Out]# 88       Puck  157
#[Out]# 89      Quinn   41
#[Out]# 90       Roan   69
#[Out]# 91       Romy  174
#[Out]# 92       Roos  117
#[Out]# 93       Rosa  158
#[Out]# 94    Rosalie  166
#[Out]# 95       Ryan   45
#[Out]# 96        Sam  175
#[Out]# 97     Samuel   74
#[Out]# 98      Sanne  130
#[Out]# 99      Sarah  120
#[Out]# 100       Sem    1
#[Out]# 101      Senn   63
#[Out]# 102     Simon   81
#[Out]# 103      Stan   64
#[Out]# 104      Stef   86
#[Out]# 105     Tessa  171
#[Out]# 106      Teun   30
#[Out]# 107    Thomas    9
#[Out]# 108    Tobias   56
#[Out]# 109       Tom   43
#[Out]# 110      Tygo   48
#[Out]# 111    Veerle  167
#[Out]# 112      Vera  140
#[Out]# 113     Vince   32
#[Out]# 114    Willem   52
#[Out]# 115      Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Wed, 02 Dec 2020 12:45:10

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop";
    
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is null)

'''

pd.read_sql_query(query3_3, conn)

# Wed, 02 Dec 2020 12:45:21

query3_3 = '''


    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and (s.sName <> "Coop" or s.sName is null)

'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6        Bram    7
#[Out]# 7       James   13
#[Out]# 8        Noud   15
#[Out]# 9      Julian   16
#[Out]# 10        Dex   17
#[Out]# 11       Hugo   18
#[Out]# 12       Lars   19
#[Out]# 13       Gijs   20
#[Out]# 14   Benjamin   21
#[Out]# 15       Mats   22
#[Out]# 16       Luca   24
#[Out]# 17      Mason   25
#[Out]# 18        Tim   27
#[Out]# 19      Ruben   29
#[Out]# 20       Teun   30
#[Out]# 21    Olivier   31
#[Out]# 22       Sven   33
#[Out]# 23      David   34
#[Out]# 24      Stijn   35
#[Out]# 25       Guus   37
#[Out]# 26     Floris   38
#[Out]# 27       Jack   39
#[Out]# 28       Jens   40
#[Out]# 29      Quinn   41
#[Out]# ..        ...  ...
#[Out]# 88        Ivy  144
#[Out]# 89       Fien  145
#[Out]# 90     Isabel  147
#[Out]# 91      Lizzy  149
#[Out]# 92       Anne  152
#[Out]# 93       Puck  157
#[Out]# 94      Fenne  159
#[Out]# 95      Floor  161
#[Out]# 96      Elena  162
#[Out]# 97       Cato  163
#[Out]# 98      Hanna  165
#[Out]# 99     Veerle  167
#[Out]# 100      Kiki  168
#[Out]# 101      Lily  169
#[Out]# 102      Iris  170
#[Out]# 103     Tessa  171
#[Out]# 104      Lana  172
#[Out]# 105       Sam  175
#[Out]# 106     Amira  176
#[Out]# 107     Eline  177
#[Out]# 108      Elif  178
#[Out]# 109      Juul  179
#[Out]# 110     Merel  180
#[Out]# 111      Liva  181
#[Out]# 112   Johanna  182
#[Out]# 113      Nick  185
#[Out]# 114    Angela  186
#[Out]# 115      Pino  188
#[Out]# 116      Koen  189
#[Out]# 117    Kostas  190
#[Out]# 
#[Out]# [118 rows x 2 columns]
# Wed, 02 Dec 2020 12:45:29

query3_3 = '''

    SELECT DISTINCT c.cName, c.cID
    FROM customer as c
    EXCEPT
    SELECT DISTINCT c.cName, c.cID
    FROM customer as c, purchase as p, store as s
    WHERE c.cID = p.cID and p.sID = s.sID and s.sName = "Coop"
    
    
'''

pd.read_sql_query(query3_3, conn)

#[Out]#         cName  cID
#[Out]# 0        Abel   62
#[Out]# 1        Adam   12
#[Out]# 2       Amber  153
#[Out]# 3      Angela  186
#[Out]# 4      Benthe  154
#[Out]# 5          Bo  142
#[Out]# 6        Boaz   36
#[Out]# 7       Boris   68
#[Out]# 8        Bram    7
#[Out]# 9         Cas   49
#[Out]# 10     Casper   84
#[Out]# 11       Dani   72
#[Out]# 12      David   34
#[Out]# 13       Emma   95
#[Out]# 14        Eva  101
#[Out]# 15        Evi  102
#[Out]# 16        Evy  164
#[Out]# 17      Fedde   46
#[Out]# 18      Femke  136
#[Out]# 19      Fenne  159
#[Out]# 20       Fien  145
#[Out]# 21       Finn    3
#[Out]# 22      Fleur  106
#[Out]# 23     Floris   38
#[Out]# 24       Guus   37
#[Out]# 25     Hannah  132
#[Out]# 26      Hidde   77
#[Out]# 27       Iris  170
#[Out]# 28        Isa  121
#[Out]# 29   Isabella  148
#[Out]# ..        ...  ...
#[Out]# 86        Pim   50
#[Out]# 87       Pino  188
#[Out]# 88       Puck  157
#[Out]# 89      Quinn   41
#[Out]# 90       Roan   69
#[Out]# 91       Romy  174
#[Out]# 92       Roos  117
#[Out]# 93       Rosa  158
#[Out]# 94    Rosalie  166
#[Out]# 95       Ryan   45
#[Out]# 96        Sam  175
#[Out]# 97     Samuel   74
#[Out]# 98      Sanne  130
#[Out]# 99      Sarah  120
#[Out]# 100       Sem    1
#[Out]# 101      Senn   63
#[Out]# 102     Simon   81
#[Out]# 103      Stan   64
#[Out]# 104      Stef   86
#[Out]# 105     Tessa  171
#[Out]# 106      Teun   30
#[Out]# 107    Thomas    9
#[Out]# 108    Tobias   56
#[Out]# 109       Tom   43
#[Out]# 110      Tygo   48
#[Out]# 111    Veerle  167
#[Out]# 112      Vera  140
#[Out]# 113     Vince   32
#[Out]# 114    Willem   52
#[Out]# 115      Xavi   47
#[Out]# 
#[Out]# [116 rows x 2 columns]


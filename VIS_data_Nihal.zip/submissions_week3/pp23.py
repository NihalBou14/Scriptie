# IPython log file

# Mon, 30 Nov 2020 15:45:57
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Mon, 30 Nov 2020 15:46:12
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 30 Nov 2020 15:46:22
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x291434ddc70>
# Mon, 30 Nov 2020 15:47:37
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'C:\Users\20192300\Documents\Year 2\Q2\2ID50\week3_versionA\shoppingDB.sql'

f = open(db_location,'shoppingDB.sql')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 15:48:08
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'C:/Users/20192300/Documents/Year 2/Q2/2ID50/week3_versionA/shoppingDB.sql'

f = open(db_location,'shoppingDB.sql')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 15:48:17
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'C:/Users/20192300/Documents/Year 2/Q2/2ID50/week3_versionA/shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 30 Nov 2020 15:49:29
query3_2 = '''
    SELECT cID
    FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# 5      5
#[Out]# 6      6
#[Out]# 7      7
#[Out]# 8      8
#[Out]# 9      9
#[Out]# 10    10
#[Out]# 11    11
#[Out]# 12    12
#[Out]# 13    13
#[Out]# 14    14
#[Out]# 15    15
#[Out]# 16    16
#[Out]# 17    17
#[Out]# 18    18
#[Out]# 19    19
#[Out]# 20    20
#[Out]# 21    21
#[Out]# 22    22
#[Out]# 23    23
#[Out]# 24    24
#[Out]# 25    25
#[Out]# 26    26
#[Out]# 27    27
#[Out]# 28    28
#[Out]# 29    29
#[Out]# ..   ...
#[Out]# 160  160
#[Out]# 161  161
#[Out]# 162  162
#[Out]# 163  163
#[Out]# 164  164
#[Out]# 165  165
#[Out]# 166  166
#[Out]# 167  167
#[Out]# 168  168
#[Out]# 169  169
#[Out]# 170  170
#[Out]# 171  171
#[Out]# 172  172
#[Out]# 173  173
#[Out]# 174  174
#[Out]# 175  175
#[Out]# 176  176
#[Out]# 177  177
#[Out]# 178  178
#[Out]# 179  179
#[Out]# 180  180
#[Out]# 181  181
#[Out]# 182  182
#[Out]# 183  183
#[Out]# 184  184
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Mon, 30 Nov 2020 15:49:42
query3_2 = '''
    SELECT cName
    FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName
#[Out]# 0        Noah
#[Out]# 1         Sem
#[Out]# 2       Lucas
#[Out]# 3        Finn
#[Out]# 4        Daan
#[Out]# 5        Levi
#[Out]# 6       Milan
#[Out]# 7        Bram
#[Out]# 8        Liam
#[Out]# 9      Thomas
#[Out]# 10        Sam
#[Out]# 11      Thijs
#[Out]# 12       Adam
#[Out]# 13      James
#[Out]# 14        Max
#[Out]# 15       Noud
#[Out]# 16     Julian
#[Out]# 17        Dex
#[Out]# 18       Hugo
#[Out]# 19       Lars
#[Out]# 20       Gijs
#[Out]# 21   Benjamin
#[Out]# 22       Mats
#[Out]# 23        Jan
#[Out]# 24       Luca
#[Out]# 25      Mason
#[Out]# 26     Jayden
#[Out]# 27        Tim
#[Out]# 28       Siem
#[Out]# 29      Ruben
#[Out]# ..        ...
#[Out]# 160      Lara
#[Out]# 161     Floor
#[Out]# 162     Elena
#[Out]# 163      Cato
#[Out]# 164       Evy
#[Out]# 165     Hanna
#[Out]# 166   Rosalie
#[Out]# 167    Veerle
#[Out]# 168      Kiki
#[Out]# 169      Lily
#[Out]# 170      Iris
#[Out]# 171     Tessa
#[Out]# 172      Lana
#[Out]# 173     Livia
#[Out]# 174      Romy
#[Out]# 175       Sam
#[Out]# 176     Amira
#[Out]# 177     Eline
#[Out]# 178      Elif
#[Out]# 179      Juul
#[Out]# 180     Merel
#[Out]# 181      Liva
#[Out]# 182   Johanna
#[Out]# 183     Nikki
#[Out]# 184     Wilko
#[Out]# 185      Nick
#[Out]# 186    Angela
#[Out]# 187      Pino
#[Out]# 188      Koen
#[Out]# 189    Kostas
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Mon, 30 Nov 2020 15:49:46
query3_2 = '''
    SELECT cName, cID
    FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName  cID
#[Out]# 0        Noah    0
#[Out]# 1         Sem    1
#[Out]# 2       Lucas    2
#[Out]# 3        Finn    3
#[Out]# 4        Daan    4
#[Out]# 5        Levi    5
#[Out]# 6       Milan    6
#[Out]# 7        Bram    7
#[Out]# 8        Liam    8
#[Out]# 9      Thomas    9
#[Out]# 10        Sam   10
#[Out]# 11      Thijs   11
#[Out]# 12       Adam   12
#[Out]# 13      James   13
#[Out]# 14        Max   14
#[Out]# 15       Noud   15
#[Out]# 16     Julian   16
#[Out]# 17        Dex   17
#[Out]# 18       Hugo   18
#[Out]# 19       Lars   19
#[Out]# 20       Gijs   20
#[Out]# 21   Benjamin   21
#[Out]# 22       Mats   22
#[Out]# 23        Jan   23
#[Out]# 24       Luca   24
#[Out]# 25      Mason   25
#[Out]# 26     Jayden   26
#[Out]# 27        Tim   27
#[Out]# 28       Siem   28
#[Out]# 29      Ruben   29
#[Out]# ..        ...  ...
#[Out]# 160      Lara  160
#[Out]# 161     Floor  161
#[Out]# 162     Elena  162
#[Out]# 163      Cato  163
#[Out]# 164       Evy  164
#[Out]# 165     Hanna  165
#[Out]# 166   Rosalie  166
#[Out]# 167    Veerle  167
#[Out]# 168      Kiki  168
#[Out]# 169      Lily  169
#[Out]# 170      Iris  170
#[Out]# 171     Tessa  171
#[Out]# 172      Lana  172
#[Out]# 173     Livia  173
#[Out]# 174      Romy  174
#[Out]# 175       Sam  175
#[Out]# 176     Amira  176
#[Out]# 177     Eline  177
#[Out]# 178      Elif  178
#[Out]# 179      Juul  179
#[Out]# 180     Merel  180
#[Out]# 181      Liva  181
#[Out]# 182   Johanna  182
#[Out]# 183     Nikki  183
#[Out]# 184     Wilko  184
#[Out]# 185      Nick  185
#[Out]# 186    Angela  186
#[Out]# 187      Pino  188
#[Out]# 188      Koen  189
#[Out]# 189    Kostas  190
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 15:49:52
query3_2 = '''
    SELECT *
    FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName                street       city
#[Out]# 0      0      Noah             Koestraat    Utrecht
#[Out]# 1      1       Sem      Rozemarijnstraat      Breda
#[Out]# 2      2     Lucas      Oude Leliestraat  Amsterdam
#[Out]# 3      3      Finn         Stationsplein      Breda
#[Out]# 4      4      Daan          Kalverstraat  Amsterdam
#[Out]# 5      5      Levi        Gasthuisstraat    Utrecht
#[Out]# 6      6     Milan           Parallelweg    Utrecht
#[Out]# 7      7      Bram          Schoolstraat  Eindhoven
#[Out]# 8      8      Liam         Rijsbergseweg      Breda
#[Out]# 9      9    Thomas           Parallelweg  Amsterdam
#[Out]# 10    10       Sam           Langestraat    Tilburg
#[Out]# 11    11     Thijs             Koestraat    Tilburg
#[Out]# 12    12      Adam           Nieuwstraat  Eindhoven
#[Out]# 13    13     James       Sint Annastraat      Breda
#[Out]# 14    14       Max             Eikenlaan    Tilburg
#[Out]# 15    15      Noud          Koningshoeve    Tilburg
#[Out]# 16    16    Julian  Prins Bernhardstraat  Eindhoven
#[Out]# 17    17       Dex          Kasteeldreef    Tilburg
#[Out]# 18    18      Hugo          Kasteeldreef    Tilburg
#[Out]# 19    19      Lars         Rijsbergseweg      Breda
#[Out]# 20    20      Gijs            Heiligeweg  Amsterdam
#[Out]# 21    21  Benjamin           Stationsweg    Tilburg
#[Out]# 22    22      Mats           Molenstraat  Eindhoven
#[Out]# 23    23       Jan       Sint Annastraat      Breda
#[Out]# 24    24      Luca          Kasteeldreef    Tilburg
#[Out]# 25    25     Mason          Keizerstraat  Rotterdam
#[Out]# 26    26    Jayden          Schoolstraat  Eindhoven
#[Out]# 27    27       Tim             Koestraat    Utrecht
#[Out]# 28    28      Siem           Langestraat    Tilburg
#[Out]# 29    29     Ruben              Hofplein  Rotterdam
#[Out]# ..   ...       ...                   ...        ...
#[Out]# 160  160      Lara           Langestraat    Tilburg
#[Out]# 161  161     Floor             Eikenlaan    Tilburg
#[Out]# 162  162     Elena            Bergselaan  Rotterdam
#[Out]# 163  163      Cato          Kastanjelaan    Tilburg
#[Out]# 164  164       Evy      Rozemarijnstraat      Breda
#[Out]# 165  165     Hanna             Eikenlaan    Tilburg
#[Out]# 166  166   Rosalie           Stationsweg  Eindhoven
#[Out]# 167  167    Veerle        Ginnekenstraat      Breda
#[Out]# 168  168      Kiki          Keizerstraat  Rotterdam
#[Out]# 169  169      Lily        Gasthuisstraat    Utrecht
#[Out]# 170  170      Iris          Kastanjelaan  Eindhoven
#[Out]# 171  171     Tessa           Haringvliet  Rotterdam
#[Out]# 172  172      Lana             Eikenlaan    Tilburg
#[Out]# 173  173     Livia      Vierwindenstraat      Breda
#[Out]# 174  174      Romy           Parallelweg  Eindhoven
#[Out]# 175  175       Sam             Bredalaan  Eindhoven
#[Out]# 176  176     Amira           Parallelweg  Amsterdam
#[Out]# 177  177     Eline          Kalverstraat  Amsterdam
#[Out]# 178  178      Elif           Parallelweg    Utrecht
#[Out]# 179  179      Juul        Wilhelminapark    Tilburg
#[Out]# 180  180     Merel          Kalverstraat  Amsterdam
#[Out]# 181  181      Liva           Fredriklaan  Eindhoven
#[Out]# 182  182   Johanna         Beatrixstraat  Eindhoven
#[Out]# 183  183     Nikki         Julianastraat    Utrecht
#[Out]# 184  184     Wilko          Onbekendeweg  Eindhoven
#[Out]# 185  185      Nick                Verweg  Eindhoven
#[Out]# 186  186    Angela              Dichtweg  Eindhoven
#[Out]# 187  188      Pino            Maanstraat  Rotterdam
#[Out]# 188  189      Koen              Akkerweg        Oss
#[Out]# 189  190    Kostas              Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Mon, 30 Nov 2020 15:50:02
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
#db_location = 'C:/Users/20192300/Documents/Year 2/Q2/2ID50/week3_versionA/shoppingDB.sql'

#f = open(db_location,'r')
#sql = f.read()
#cur.executescript(sql)
# Mon, 30 Nov 2020 15:50:03
query3_2 = '''
    SELECT *
    FROM customer
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName                street       city
#[Out]# 0      0      Noah             Koestraat    Utrecht
#[Out]# 1      1       Sem      Rozemarijnstraat      Breda
#[Out]# 2      2     Lucas      Oude Leliestraat  Amsterdam
#[Out]# 3      3      Finn         Stationsplein      Breda
#[Out]# 4      4      Daan          Kalverstraat  Amsterdam
#[Out]# 5      5      Levi        Gasthuisstraat    Utrecht
#[Out]# 6      6     Milan           Parallelweg    Utrecht
#[Out]# 7      7      Bram          Schoolstraat  Eindhoven
#[Out]# 8      8      Liam         Rijsbergseweg      Breda
#[Out]# 9      9    Thomas           Parallelweg  Amsterdam
#[Out]# 10    10       Sam           Langestraat    Tilburg
#[Out]# 11    11     Thijs             Koestraat    Tilburg
#[Out]# 12    12      Adam           Nieuwstraat  Eindhoven
#[Out]# 13    13     James       Sint Annastraat      Breda
#[Out]# 14    14       Max             Eikenlaan    Tilburg
#[Out]# 15    15      Noud          Koningshoeve    Tilburg
#[Out]# 16    16    Julian  Prins Bernhardstraat  Eindhoven
#[Out]# 17    17       Dex          Kasteeldreef    Tilburg
#[Out]# 18    18      Hugo          Kasteeldreef    Tilburg
#[Out]# 19    19      Lars         Rijsbergseweg      Breda
#[Out]# 20    20      Gijs            Heiligeweg  Amsterdam
#[Out]# 21    21  Benjamin           Stationsweg    Tilburg
#[Out]# 22    22      Mats           Molenstraat  Eindhoven
#[Out]# 23    23       Jan       Sint Annastraat      Breda
#[Out]# 24    24      Luca          Kasteeldreef    Tilburg
#[Out]# 25    25     Mason          Keizerstraat  Rotterdam
#[Out]# 26    26    Jayden          Schoolstraat  Eindhoven
#[Out]# 27    27       Tim             Koestraat    Utrecht
#[Out]# 28    28      Siem           Langestraat    Tilburg
#[Out]# 29    29     Ruben              Hofplein  Rotterdam
#[Out]# ..   ...       ...                   ...        ...
#[Out]# 160  160      Lara           Langestraat    Tilburg
#[Out]# 161  161     Floor             Eikenlaan    Tilburg
#[Out]# 162  162     Elena            Bergselaan  Rotterdam
#[Out]# 163  163      Cato          Kastanjelaan    Tilburg
#[Out]# 164  164       Evy      Rozemarijnstraat      Breda
#[Out]# 165  165     Hanna             Eikenlaan    Tilburg
#[Out]# 166  166   Rosalie           Stationsweg  Eindhoven
#[Out]# 167  167    Veerle        Ginnekenstraat      Breda
#[Out]# 168  168      Kiki          Keizerstraat  Rotterdam
#[Out]# 169  169      Lily        Gasthuisstraat    Utrecht
#[Out]# 170  170      Iris          Kastanjelaan  Eindhoven
#[Out]# 171  171     Tessa           Haringvliet  Rotterdam
#[Out]# 172  172      Lana             Eikenlaan    Tilburg
#[Out]# 173  173     Livia      Vierwindenstraat      Breda
#[Out]# 174  174      Romy           Parallelweg  Eindhoven
#[Out]# 175  175       Sam             Bredalaan  Eindhoven
#[Out]# 176  176     Amira           Parallelweg  Amsterdam
#[Out]# 177  177     Eline          Kalverstraat  Amsterdam
#[Out]# 178  178      Elif           Parallelweg    Utrecht
#[Out]# 179  179      Juul        Wilhelminapark    Tilburg
#[Out]# 180  180     Merel          Kalverstraat  Amsterdam
#[Out]# 181  181      Liva           Fredriklaan  Eindhoven
#[Out]# 182  182   Johanna         Beatrixstraat  Eindhoven
#[Out]# 183  183     Nikki         Julianastraat    Utrecht
#[Out]# 184  184     Wilko          Onbekendeweg  Eindhoven
#[Out]# 185  185      Nick                Verweg  Eindhoven
#[Out]# 186  186    Angela              Dichtweg  Eindhoven
#[Out]# 187  188      Pino            Maanstraat  Rotterdam
#[Out]# 188  189      Koen              Akkerweg        Oss
#[Out]# 189  190    Kostas              Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Mon, 30 Nov 2020 15:51:14
query3_2 = '''
    SELECT cID, cName
    FROM customer, shoppinglist
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 15:51:23
query3_2 = '''
    SELECT customer.cID, cName
    FROM customer, shoppinglist
'''

pd.read_sql_query(query3_2, conn)
#[Out]#        cID   cName
#[Out]# 0        0    Noah
#[Out]# 1        0    Noah
#[Out]# 2        0    Noah
#[Out]# 3        0    Noah
#[Out]# 4        0    Noah
#[Out]# 5        0    Noah
#[Out]# 6        0    Noah
#[Out]# 7        0    Noah
#[Out]# 8        0    Noah
#[Out]# 9        0    Noah
#[Out]# 10       0    Noah
#[Out]# 11       0    Noah
#[Out]# 12       0    Noah
#[Out]# 13       0    Noah
#[Out]# 14       0    Noah
#[Out]# 15       0    Noah
#[Out]# 16       0    Noah
#[Out]# 17       0    Noah
#[Out]# 18       0    Noah
#[Out]# 19       0    Noah
#[Out]# 20       0    Noah
#[Out]# 21       0    Noah
#[Out]# 22       0    Noah
#[Out]# 23       0    Noah
#[Out]# 24       0    Noah
#[Out]# 25       0    Noah
#[Out]# 26       0    Noah
#[Out]# 27       0    Noah
#[Out]# 28       0    Noah
#[Out]# 29       0    Noah
#[Out]# ...    ...     ...
#[Out]# 93450  190  Kostas
#[Out]# 93451  190  Kostas
#[Out]# 93452  190  Kostas
#[Out]# 93453  190  Kostas
#[Out]# 93454  190  Kostas
#[Out]# 93455  190  Kostas
#[Out]# 93456  190  Kostas
#[Out]# 93457  190  Kostas
#[Out]# 93458  190  Kostas
#[Out]# 93459  190  Kostas
#[Out]# 93460  190  Kostas
#[Out]# 93461  190  Kostas
#[Out]# 93462  190  Kostas
#[Out]# 93463  190  Kostas
#[Out]# 93464  190  Kostas
#[Out]# 93465  190  Kostas
#[Out]# 93466  190  Kostas
#[Out]# 93467  190  Kostas
#[Out]# 93468  190  Kostas
#[Out]# 93469  190  Kostas
#[Out]# 93470  190  Kostas
#[Out]# 93471  190  Kostas
#[Out]# 93472  190  Kostas
#[Out]# 93473  190  Kostas
#[Out]# 93474  190  Kostas
#[Out]# 93475  190  Kostas
#[Out]# 93476  190  Kostas
#[Out]# 93477  190  Kostas
#[Out]# 93478  190  Kostas
#[Out]# 93479  190  Kostas
#[Out]# 
#[Out]# [93480 rows x 2 columns]
# Mon, 30 Nov 2020 15:51:40
query3_2 = '''
    SELECT distinct customer.cID, cName
    FROM customer, shoppinglist
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 15:52:52
query3_2 = '''
    SELECT distinct customer.cID, cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID = purchase.cID
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 15:54:29
query3_2 = '''
    SELECT distinct customer.cID, cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like %2018%
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 15:54:52
query3_2 = '''
    SELECT distinct customer.cID, cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 15:56:48
query3_2 = '''
    SELECT distinct customer.cID, cName, shoppinglist.date
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName        date
#[Out]# 0      0      Noah  2018-08-22
#[Out]# 1      1       Sem  2018-08-20
#[Out]# 2      1       Sem  2018-08-21
#[Out]# 3      1       Sem  2018-08-22
#[Out]# 4      2     Lucas  2018-08-22
#[Out]# 5      3      Finn  2018-08-22
#[Out]# 6      4      Daan  2018-08-22
#[Out]# 7      5      Levi  2018-08-22
#[Out]# 8      6     Milan  2018-08-22
#[Out]# 9      7      Bram  2018-08-22
#[Out]# 10     8      Liam  2018-08-22
#[Out]# 11     9    Thomas  2018-08-22
#[Out]# 12    10       Sam  2018-08-22
#[Out]# 13    11     Thijs  2018-08-22
#[Out]# 14    12      Adam  2018-08-22
#[Out]# 15    13     James  2018-08-22
#[Out]# 16    14       Max  2018-08-22
#[Out]# 17    15      Noud  2018-08-22
#[Out]# 18    16    Julian  2018-08-22
#[Out]# 19    17       Dex  2018-08-22
#[Out]# 20    18      Hugo  2018-08-22
#[Out]# 21    19      Lars  2018-08-22
#[Out]# 22    20      Gijs  2018-08-22
#[Out]# 23    21  Benjamin  2018-08-22
#[Out]# 24    21  Benjamin  2018-08-20
#[Out]# 25    22      Mats  2018-08-22
#[Out]# 26    23       Jan  2018-08-22
#[Out]# 27    24      Luca  2018-08-22
#[Out]# 28    24      Luca  2018-08-20
#[Out]# 29    25     Mason  2018-08-22
#[Out]# ..   ...       ...         ...
#[Out]# 194  166   Rosalie  2018-08-22
#[Out]# 195  167    Veerle  2018-08-22
#[Out]# 196  167    Veerle  2018-08-21
#[Out]# 197  167    Veerle  2018-08-20
#[Out]# 198  168      Kiki  2018-08-22
#[Out]# 199  169      Lily  2018-08-22
#[Out]# 200  169      Lily  2018-08-20
#[Out]# 201  170      Iris  2018-08-22
#[Out]# 202  171     Tessa  2018-08-22
#[Out]# 203  171     Tessa  2018-08-20
#[Out]# 204  172      Lana  2018-08-22
#[Out]# 205  173     Livia  2018-08-22
#[Out]# 206  174      Romy  2018-08-22
#[Out]# 207  175       Sam  2018-08-22
#[Out]# 208  176     Amira  2018-08-22
#[Out]# 209  177     Eline  2018-08-22
#[Out]# 210  178      Elif  2018-08-22
#[Out]# 211  179      Juul  2018-08-22
#[Out]# 212  180     Merel  2018-08-22
#[Out]# 213  181      Liva  2018-08-22
#[Out]# 214  182   Johanna  2018-08-22
#[Out]# 215  183     Nikki  2018-08-22
#[Out]# 216  183     Nikki  2018-08-20
#[Out]# 217  183     Nikki  2018-08-21
#[Out]# 218  184     Wilko  2018-08-22
#[Out]# 219  185      Nick  2018-08-22
#[Out]# 220  186    Angela  2018-08-22
#[Out]# 221  188      Pino  2018-08-22
#[Out]# 222  189      Koen  2018-08-22
#[Out]# 223  190    Kostas  2018-08-22
#[Out]# 
#[Out]# [224 rows x 3 columns]
# Mon, 30 Nov 2020 15:56:58
query3_2 = '''
    SELECT distinct customer.cID, cName, shoppinglist.date, purchase.date
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName        date        date
#[Out]# 0      0      Noah  2018-08-22  2018-08-22
#[Out]# 1      1       Sem  2018-08-20  2018-08-20
#[Out]# 2      1       Sem  2018-08-21  2018-08-21
#[Out]# 3      1       Sem  2018-08-22  2018-08-22
#[Out]# 4      2     Lucas  2018-08-22  2018-08-22
#[Out]# 5      3      Finn  2018-08-22  2018-08-22
#[Out]# 6      4      Daan  2018-08-22  2018-08-22
#[Out]# 7      5      Levi  2018-08-22  2018-08-22
#[Out]# 8      6     Milan  2018-08-22  2018-08-22
#[Out]# 9      7      Bram  2018-08-22  2018-08-22
#[Out]# 10     8      Liam  2018-08-22  2018-08-22
#[Out]# 11     9    Thomas  2018-08-22  2018-08-22
#[Out]# 12    10       Sam  2018-08-22  2018-08-22
#[Out]# 13    11     Thijs  2018-08-22  2018-08-22
#[Out]# 14    12      Adam  2018-08-22  2018-08-22
#[Out]# 15    13     James  2018-08-22  2018-08-22
#[Out]# 16    14       Max  2018-08-22  2018-08-22
#[Out]# 17    15      Noud  2018-08-22  2018-08-22
#[Out]# 18    16    Julian  2018-08-22  2018-08-22
#[Out]# 19    17       Dex  2018-08-22  2018-08-22
#[Out]# 20    18      Hugo  2018-08-22  2018-08-22
#[Out]# 21    19      Lars  2018-08-22  2018-08-22
#[Out]# 22    20      Gijs  2018-08-22  2018-08-22
#[Out]# 23    21  Benjamin  2018-08-22  2018-08-22
#[Out]# 24    21  Benjamin  2018-08-20  2018-08-20
#[Out]# 25    22      Mats  2018-08-22  2018-08-22
#[Out]# 26    23       Jan  2018-08-22  2018-08-22
#[Out]# 27    24      Luca  2018-08-22  2018-08-22
#[Out]# 28    24      Luca  2018-08-20  2018-08-20
#[Out]# 29    25     Mason  2018-08-22  2018-08-22
#[Out]# ..   ...       ...         ...         ...
#[Out]# 194  166   Rosalie  2018-08-22  2018-08-22
#[Out]# 195  167    Veerle  2018-08-22  2018-08-22
#[Out]# 196  167    Veerle  2018-08-21  2018-08-21
#[Out]# 197  167    Veerle  2018-08-20  2018-08-20
#[Out]# 198  168      Kiki  2018-08-22  2018-08-22
#[Out]# 199  169      Lily  2018-08-22  2018-08-22
#[Out]# 200  169      Lily  2018-08-20  2018-08-20
#[Out]# 201  170      Iris  2018-08-22  2018-08-22
#[Out]# 202  171     Tessa  2018-08-22  2018-08-22
#[Out]# 203  171     Tessa  2018-08-20  2018-08-20
#[Out]# 204  172      Lana  2018-08-22  2018-08-22
#[Out]# 205  173     Livia  2018-08-22  2018-08-22
#[Out]# 206  174      Romy  2018-08-22  2018-08-22
#[Out]# 207  175       Sam  2018-08-22  2018-08-22
#[Out]# 208  176     Amira  2018-08-22  2018-08-22
#[Out]# 209  177     Eline  2018-08-22  2018-08-22
#[Out]# 210  178      Elif  2018-08-22  2018-08-22
#[Out]# 211  179      Juul  2018-08-22  2018-08-22
#[Out]# 212  180     Merel  2018-08-22  2018-08-22
#[Out]# 213  181      Liva  2018-08-22  2018-08-22
#[Out]# 214  182   Johanna  2018-08-22  2018-08-22
#[Out]# 215  183     Nikki  2018-08-22  2018-08-22
#[Out]# 216  183     Nikki  2018-08-20  2018-08-20
#[Out]# 217  183     Nikki  2018-08-21  2018-08-21
#[Out]# 218  184     Wilko  2018-08-22  2018-08-22
#[Out]# 219  185      Nick  2018-08-22  2018-08-22
#[Out]# 220  186    Angela  2018-08-22  2018-08-22
#[Out]# 221  188      Pino  2018-08-22  2018-08-22
#[Out]# 222  189      Koen  2018-08-22  2018-08-22
#[Out]# 223  190    Kostas  2018-08-22  2018-08-22
#[Out]# 
#[Out]# [224 rows x 4 columns]
# Mon, 30 Nov 2020 15:57:44
query3_2 = '''
    SELECT customer.cID, cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID   cName
#[Out]# 0       0    Noah
#[Out]# 1       0    Noah
#[Out]# 2       0    Noah
#[Out]# 3       0    Noah
#[Out]# 4       0    Noah
#[Out]# 5       0    Noah
#[Out]# 6       0    Noah
#[Out]# 7       0    Noah
#[Out]# 8       0    Noah
#[Out]# 9       0    Noah
#[Out]# 10      0    Noah
#[Out]# 11      0    Noah
#[Out]# 12      0    Noah
#[Out]# 13      0    Noah
#[Out]# 14      0    Noah
#[Out]# 15      0    Noah
#[Out]# 16      0    Noah
#[Out]# 17      0    Noah
#[Out]# 18      0    Noah
#[Out]# 19      0    Noah
#[Out]# 20      0    Noah
#[Out]# 21      0    Noah
#[Out]# 22      0    Noah
#[Out]# 23      0    Noah
#[Out]# 24      0    Noah
#[Out]# 25      0    Noah
#[Out]# 26      0    Noah
#[Out]# 27      0    Noah
#[Out]# 28      0    Noah
#[Out]# 29      0    Noah
#[Out]# ...   ...     ...
#[Out]# 6839  190  Kostas
#[Out]# 6840  190  Kostas
#[Out]# 6841  190  Kostas
#[Out]# 6842  190  Kostas
#[Out]# 6843  190  Kostas
#[Out]# 6844  190  Kostas
#[Out]# 6845  190  Kostas
#[Out]# 6846  190  Kostas
#[Out]# 6847  190  Kostas
#[Out]# 6848  190  Kostas
#[Out]# 6849  190  Kostas
#[Out]# 6850  190  Kostas
#[Out]# 6851  190  Kostas
#[Out]# 6852  190  Kostas
#[Out]# 6853  190  Kostas
#[Out]# 6854  190  Kostas
#[Out]# 6855  190  Kostas
#[Out]# 6856  190  Kostas
#[Out]# 6857  190  Kostas
#[Out]# 6858  190  Kostas
#[Out]# 6859  190  Kostas
#[Out]# 6860  190  Kostas
#[Out]# 6861  190  Kostas
#[Out]# 6862  190  Kostas
#[Out]# 6863  190  Kostas
#[Out]# 6864  190  Kostas
#[Out]# 6865  190  Kostas
#[Out]# 6866  190  Kostas
#[Out]# 6867  190  Kostas
#[Out]# 6868  190  Kostas
#[Out]# 
#[Out]# [6869 rows x 2 columns]
# Mon, 30 Nov 2020 15:57:53
query3_2 = '''
    SELECT distinct customer.cID, distinct cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
# Mon, 30 Nov 2020 15:58:02
query3_2 = '''
    SELECT distinct customer.cID, cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 15:59:11
query3_2 = '''
    SELECT distinct customer.cID, cName, purchase.date, shoppinglist.date, purchase.tID, shoppinglist.cID
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID   cName        date        date  tID  cID
#[Out]# 0       0    Noah  2018-08-22  2018-08-22    0    5
#[Out]# 1       0    Noah  2018-08-22  2018-08-22    0   59
#[Out]# 2       0    Noah  2018-08-22  2018-08-22    0   64
#[Out]# 3       0    Noah  2018-08-22  2018-08-22    0   72
#[Out]# 4       0    Noah  2018-08-22  2018-08-22    0   82
#[Out]# 5       0    Noah  2018-08-22  2018-08-22    0   95
#[Out]# 6       0    Noah  2018-08-22  2018-08-22    0  100
#[Out]# 7       0    Noah  2018-08-22  2018-08-22    0  103
#[Out]# 8       0    Noah  2018-08-22  2018-08-22    0  104
#[Out]# 9       0    Noah  2018-08-22  2018-08-22    0  108
#[Out]# 10      0    Noah  2018-08-22  2018-08-22    0  109
#[Out]# 11      0    Noah  2018-08-22  2018-08-22    0  111
#[Out]# 12      0    Noah  2018-08-22  2018-08-22    0  122
#[Out]# 13      0    Noah  2018-08-22  2018-08-22    0  144
#[Out]# 14      0    Noah  2018-08-22  2018-08-22    0  145
#[Out]# 15      0    Noah  2018-08-22  2018-08-22    0  162
#[Out]# 16      0    Noah  2018-08-22  2018-08-22    0  163
#[Out]# 17      0    Noah  2018-08-22  2018-08-22    0  165
#[Out]# 18      0    Noah  2018-08-22  2018-08-22    0  176
#[Out]# 19      0    Noah  2018-08-22  2018-08-22    0  179
#[Out]# 20      0    Noah  2018-08-22  2018-08-22    0  183
#[Out]# 21      1     Sem  2018-08-20  2018-08-20    1    1
#[Out]# 22      1     Sem  2018-08-20  2018-08-20    2    1
#[Out]# 23      1     Sem  2018-08-20  2018-08-20    3    1
#[Out]# 24      1     Sem  2018-08-20  2018-08-20    4    1
#[Out]# 25      1     Sem  2018-08-20  2018-08-20    5    1
#[Out]# 26      1     Sem  2018-08-21  2018-08-21    6    1
#[Out]# 27      1     Sem  2018-08-21  2018-08-21    7    1
#[Out]# 28      1     Sem  2018-08-22  2018-08-22    0    5
#[Out]# 29      1     Sem  2018-08-22  2018-08-22    0   59
#[Out]# ...   ...     ...         ...         ...  ...  ...
#[Out]# 4058  189    Koen  2018-08-22  2018-08-22    0  122
#[Out]# 4059  189    Koen  2018-08-22  2018-08-22    0  144
#[Out]# 4060  189    Koen  2018-08-22  2018-08-22    0  145
#[Out]# 4061  189    Koen  2018-08-22  2018-08-22    0  162
#[Out]# 4062  189    Koen  2018-08-22  2018-08-22    0  163
#[Out]# 4063  189    Koen  2018-08-22  2018-08-22    0  165
#[Out]# 4064  189    Koen  2018-08-22  2018-08-22    0  176
#[Out]# 4065  189    Koen  2018-08-22  2018-08-22    0  179
#[Out]# 4066  189    Koen  2018-08-22  2018-08-22    0  183
#[Out]# 4067  190  Kostas  2018-08-22  2018-08-22    0    5
#[Out]# 4068  190  Kostas  2018-08-22  2018-08-22    0   59
#[Out]# 4069  190  Kostas  2018-08-22  2018-08-22    0   64
#[Out]# 4070  190  Kostas  2018-08-22  2018-08-22    0   72
#[Out]# 4071  190  Kostas  2018-08-22  2018-08-22    0   82
#[Out]# 4072  190  Kostas  2018-08-22  2018-08-22    0   95
#[Out]# 4073  190  Kostas  2018-08-22  2018-08-22    0  100
#[Out]# 4074  190  Kostas  2018-08-22  2018-08-22    0  103
#[Out]# 4075  190  Kostas  2018-08-22  2018-08-22    0  104
#[Out]# 4076  190  Kostas  2018-08-22  2018-08-22    0  108
#[Out]# 4077  190  Kostas  2018-08-22  2018-08-22    0  109
#[Out]# 4078  190  Kostas  2018-08-22  2018-08-22    0  111
#[Out]# 4079  190  Kostas  2018-08-22  2018-08-22    0  122
#[Out]# 4080  190  Kostas  2018-08-22  2018-08-22    0  144
#[Out]# 4081  190  Kostas  2018-08-22  2018-08-22    0  145
#[Out]# 4082  190  Kostas  2018-08-22  2018-08-22    0  162
#[Out]# 4083  190  Kostas  2018-08-22  2018-08-22    0  163
#[Out]# 4084  190  Kostas  2018-08-22  2018-08-22    0  165
#[Out]# 4085  190  Kostas  2018-08-22  2018-08-22    0  176
#[Out]# 4086  190  Kostas  2018-08-22  2018-08-22    0  179
#[Out]# 4087  190  Kostas  2018-08-22  2018-08-22    0  183
#[Out]# 
#[Out]# [4088 rows x 6 columns]
# Mon, 30 Nov 2020 15:59:45
query3_2 = '''
    SELECT distinct customer.cID, cName, purchase.date, shoppinglist.date, purchase.tID, shoppinglist.cID
    FROM customer, shoppinglist, purchase
    WHERE customer.cID == shoppinglist.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID   cName        date        date  tID  cID
#[Out]# 0       0    Noah  2018-08-22  2018-08-22    0    5
#[Out]# 1       0    Noah  2018-08-22  2018-08-22    0   59
#[Out]# 2       0    Noah  2018-08-22  2018-08-22    0   64
#[Out]# 3       0    Noah  2018-08-22  2018-08-22    0   72
#[Out]# 4       0    Noah  2018-08-22  2018-08-22    0   82
#[Out]# 5       0    Noah  2018-08-22  2018-08-22    0   95
#[Out]# 6       0    Noah  2018-08-22  2018-08-22    0  100
#[Out]# 7       0    Noah  2018-08-22  2018-08-22    0  103
#[Out]# 8       0    Noah  2018-08-22  2018-08-22    0  104
#[Out]# 9       0    Noah  2018-08-22  2018-08-22    0  108
#[Out]# 10      0    Noah  2018-08-22  2018-08-22    0  109
#[Out]# 11      0    Noah  2018-08-22  2018-08-22    0  111
#[Out]# 12      0    Noah  2018-08-22  2018-08-22    0  122
#[Out]# 13      0    Noah  2018-08-22  2018-08-22    0  144
#[Out]# 14      0    Noah  2018-08-22  2018-08-22    0  145
#[Out]# 15      0    Noah  2018-08-22  2018-08-22    0  162
#[Out]# 16      0    Noah  2018-08-22  2018-08-22    0  163
#[Out]# 17      0    Noah  2018-08-22  2018-08-22    0  165
#[Out]# 18      0    Noah  2018-08-22  2018-08-22    0  176
#[Out]# 19      0    Noah  2018-08-22  2018-08-22    0  179
#[Out]# 20      0    Noah  2018-08-22  2018-08-22    0  183
#[Out]# 21      1     Sem  2018-08-20  2018-08-20    1    1
#[Out]# 22      1     Sem  2018-08-20  2018-08-20    2    1
#[Out]# 23      1     Sem  2018-08-20  2018-08-20    3    1
#[Out]# 24      1     Sem  2018-08-20  2018-08-20    4    1
#[Out]# 25      1     Sem  2018-08-20  2018-08-20    5    1
#[Out]# 26      1     Sem  2018-08-21  2018-08-21    6    1
#[Out]# 27      1     Sem  2018-08-21  2018-08-21    7    1
#[Out]# 28      1     Sem  2018-08-22  2018-08-22    0    5
#[Out]# 29      1     Sem  2018-08-22  2018-08-22    0   59
#[Out]# ...   ...     ...         ...         ...  ...  ...
#[Out]# 4058  189    Koen  2018-08-22  2018-08-22    0  122
#[Out]# 4059  189    Koen  2018-08-22  2018-08-22    0  144
#[Out]# 4060  189    Koen  2018-08-22  2018-08-22    0  145
#[Out]# 4061  189    Koen  2018-08-22  2018-08-22    0  162
#[Out]# 4062  189    Koen  2018-08-22  2018-08-22    0  163
#[Out]# 4063  189    Koen  2018-08-22  2018-08-22    0  165
#[Out]# 4064  189    Koen  2018-08-22  2018-08-22    0  176
#[Out]# 4065  189    Koen  2018-08-22  2018-08-22    0  179
#[Out]# 4066  189    Koen  2018-08-22  2018-08-22    0  183
#[Out]# 4067  190  Kostas  2018-08-22  2018-08-22    0    5
#[Out]# 4068  190  Kostas  2018-08-22  2018-08-22    0   59
#[Out]# 4069  190  Kostas  2018-08-22  2018-08-22    0   64
#[Out]# 4070  190  Kostas  2018-08-22  2018-08-22    0   72
#[Out]# 4071  190  Kostas  2018-08-22  2018-08-22    0   82
#[Out]# 4072  190  Kostas  2018-08-22  2018-08-22    0   95
#[Out]# 4073  190  Kostas  2018-08-22  2018-08-22    0  100
#[Out]# 4074  190  Kostas  2018-08-22  2018-08-22    0  103
#[Out]# 4075  190  Kostas  2018-08-22  2018-08-22    0  104
#[Out]# 4076  190  Kostas  2018-08-22  2018-08-22    0  108
#[Out]# 4077  190  Kostas  2018-08-22  2018-08-22    0  109
#[Out]# 4078  190  Kostas  2018-08-22  2018-08-22    0  111
#[Out]# 4079  190  Kostas  2018-08-22  2018-08-22    0  122
#[Out]# 4080  190  Kostas  2018-08-22  2018-08-22    0  144
#[Out]# 4081  190  Kostas  2018-08-22  2018-08-22    0  145
#[Out]# 4082  190  Kostas  2018-08-22  2018-08-22    0  162
#[Out]# 4083  190  Kostas  2018-08-22  2018-08-22    0  163
#[Out]# 4084  190  Kostas  2018-08-22  2018-08-22    0  165
#[Out]# 4085  190  Kostas  2018-08-22  2018-08-22    0  176
#[Out]# 4086  190  Kostas  2018-08-22  2018-08-22    0  179
#[Out]# 4087  190  Kostas  2018-08-22  2018-08-22    0  183
#[Out]# 
#[Out]# [4088 rows x 6 columns]
# Mon, 30 Nov 2020 15:59:49
query3_2 = '''
    SELECT distinct customer.cID, cName, purchase.date, shoppinglist.date, purchase.tID, shoppinglist.cID
    FROM customer, shoppinglist, purchase
    WHERE customer.cID == shoppinglist.cID == purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#       cID   cName        date        date  tID  cID
#[Out]# 0       0    Noah  2018-08-22  2018-08-22    0    5
#[Out]# 1       0    Noah  2018-08-22  2018-08-22    0   59
#[Out]# 2       0    Noah  2018-08-22  2018-08-22    0   64
#[Out]# 3       0    Noah  2018-08-22  2018-08-22    0   72
#[Out]# 4       0    Noah  2018-08-22  2018-08-22    0   82
#[Out]# 5       0    Noah  2018-08-22  2018-08-22    0   95
#[Out]# 6       0    Noah  2018-08-22  2018-08-22    0  100
#[Out]# 7       0    Noah  2018-08-22  2018-08-22    0  103
#[Out]# 8       0    Noah  2018-08-22  2018-08-22    0  104
#[Out]# 9       0    Noah  2018-08-22  2018-08-22    0  108
#[Out]# 10      0    Noah  2018-08-22  2018-08-22    0  109
#[Out]# 11      0    Noah  2018-08-22  2018-08-22    0  111
#[Out]# 12      0    Noah  2018-08-22  2018-08-22    0  122
#[Out]# 13      0    Noah  2018-08-22  2018-08-22    0  144
#[Out]# 14      0    Noah  2018-08-22  2018-08-22    0  145
#[Out]# 15      0    Noah  2018-08-22  2018-08-22    0  162
#[Out]# 16      0    Noah  2018-08-22  2018-08-22    0  163
#[Out]# 17      0    Noah  2018-08-22  2018-08-22    0  165
#[Out]# 18      0    Noah  2018-08-22  2018-08-22    0  176
#[Out]# 19      0    Noah  2018-08-22  2018-08-22    0  179
#[Out]# 20      0    Noah  2018-08-22  2018-08-22    0  183
#[Out]# 21      1     Sem  2018-08-20  2018-08-20    1    1
#[Out]# 22      1     Sem  2018-08-20  2018-08-20    2    1
#[Out]# 23      1     Sem  2018-08-20  2018-08-20    3    1
#[Out]# 24      1     Sem  2018-08-20  2018-08-20    4    1
#[Out]# 25      1     Sem  2018-08-20  2018-08-20    5    1
#[Out]# 26      1     Sem  2018-08-21  2018-08-21    6    1
#[Out]# 27      1     Sem  2018-08-21  2018-08-21    7    1
#[Out]# 28      1     Sem  2018-08-22  2018-08-22    0    5
#[Out]# 29      1     Sem  2018-08-22  2018-08-22    0   59
#[Out]# ...   ...     ...         ...         ...  ...  ...
#[Out]# 4058  189    Koen  2018-08-22  2018-08-22    0  122
#[Out]# 4059  189    Koen  2018-08-22  2018-08-22    0  144
#[Out]# 4060  189    Koen  2018-08-22  2018-08-22    0  145
#[Out]# 4061  189    Koen  2018-08-22  2018-08-22    0  162
#[Out]# 4062  189    Koen  2018-08-22  2018-08-22    0  163
#[Out]# 4063  189    Koen  2018-08-22  2018-08-22    0  165
#[Out]# 4064  189    Koen  2018-08-22  2018-08-22    0  176
#[Out]# 4065  189    Koen  2018-08-22  2018-08-22    0  179
#[Out]# 4066  189    Koen  2018-08-22  2018-08-22    0  183
#[Out]# 4067  190  Kostas  2018-08-22  2018-08-22    0    5
#[Out]# 4068  190  Kostas  2018-08-22  2018-08-22    0   59
#[Out]# 4069  190  Kostas  2018-08-22  2018-08-22    0   64
#[Out]# 4070  190  Kostas  2018-08-22  2018-08-22    0   72
#[Out]# 4071  190  Kostas  2018-08-22  2018-08-22    0   82
#[Out]# 4072  190  Kostas  2018-08-22  2018-08-22    0   95
#[Out]# 4073  190  Kostas  2018-08-22  2018-08-22    0  100
#[Out]# 4074  190  Kostas  2018-08-22  2018-08-22    0  103
#[Out]# 4075  190  Kostas  2018-08-22  2018-08-22    0  104
#[Out]# 4076  190  Kostas  2018-08-22  2018-08-22    0  108
#[Out]# 4077  190  Kostas  2018-08-22  2018-08-22    0  109
#[Out]# 4078  190  Kostas  2018-08-22  2018-08-22    0  111
#[Out]# 4079  190  Kostas  2018-08-22  2018-08-22    0  122
#[Out]# 4080  190  Kostas  2018-08-22  2018-08-22    0  144
#[Out]# 4081  190  Kostas  2018-08-22  2018-08-22    0  145
#[Out]# 4082  190  Kostas  2018-08-22  2018-08-22    0  162
#[Out]# 4083  190  Kostas  2018-08-22  2018-08-22    0  163
#[Out]# 4084  190  Kostas  2018-08-22  2018-08-22    0  165
#[Out]# 4085  190  Kostas  2018-08-22  2018-08-22    0  176
#[Out]# 4086  190  Kostas  2018-08-22  2018-08-22    0  179
#[Out]# 4087  190  Kostas  2018-08-22  2018-08-22    0  183
#[Out]# 
#[Out]# [4088 rows x 6 columns]
# Mon, 30 Nov 2020 16:01:28
query3_2 = '''
    SELECT distinct customer.cID, cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID == shoppinglist.cID == purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Mon, 30 Nov 2020 16:01:53
query3_2 = '''
    SELECT distinct customer.cID
    FROM customer, shoppinglist, purchase
    WHERE customer.cID == shoppinglist.cID == purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# 5      5
#[Out]# 6      6
#[Out]# 7      7
#[Out]# 8      8
#[Out]# 9      9
#[Out]# 10    10
#[Out]# 11    11
#[Out]# 12    12
#[Out]# 13    13
#[Out]# 14    14
#[Out]# 15    15
#[Out]# 16    16
#[Out]# 17    17
#[Out]# 18    18
#[Out]# 19    19
#[Out]# 20    20
#[Out]# 21    21
#[Out]# 22    22
#[Out]# 23    23
#[Out]# 24    24
#[Out]# 25    25
#[Out]# 26    26
#[Out]# 27    27
#[Out]# 28    28
#[Out]# 29    29
#[Out]# ..   ...
#[Out]# 160  160
#[Out]# 161  161
#[Out]# 162  162
#[Out]# 163  163
#[Out]# 164  164
#[Out]# 165  165
#[Out]# 166  166
#[Out]# 167  167
#[Out]# 168  168
#[Out]# 169  169
#[Out]# 170  170
#[Out]# 171  171
#[Out]# 172  172
#[Out]# 173  173
#[Out]# 174  174
#[Out]# 175  175
#[Out]# 176  176
#[Out]# 177  177
#[Out]# 178  178
#[Out]# 179  179
#[Out]# 180  180
#[Out]# 181  181
#[Out]# 182  182
#[Out]# 183  183
#[Out]# 184  184
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Mon, 30 Nov 2020 16:02:07
query3_2 = '''
    SELECT distinct cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID == shoppinglist.cID == purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName
#[Out]# 0        Noah
#[Out]# 1         Sem
#[Out]# 2       Lucas
#[Out]# 3        Finn
#[Out]# 4        Daan
#[Out]# 5        Levi
#[Out]# 6       Milan
#[Out]# 7        Bram
#[Out]# 8        Liam
#[Out]# 9      Thomas
#[Out]# 10        Sam
#[Out]# 11      Thijs
#[Out]# 12       Adam
#[Out]# 13      James
#[Out]# 14        Max
#[Out]# 15       Noud
#[Out]# 16     Julian
#[Out]# 17        Dex
#[Out]# 18       Hugo
#[Out]# 19       Lars
#[Out]# 20       Gijs
#[Out]# 21   Benjamin
#[Out]# 22       Mats
#[Out]# 23        Jan
#[Out]# 24       Luca
#[Out]# 25      Mason
#[Out]# 26     Jayden
#[Out]# 27        Tim
#[Out]# 28       Siem
#[Out]# 29      Ruben
#[Out]# ..        ...
#[Out]# 159     Fenne
#[Out]# 160      Lara
#[Out]# 161     Floor
#[Out]# 162     Elena
#[Out]# 163      Cato
#[Out]# 164       Evy
#[Out]# 165     Hanna
#[Out]# 166   Rosalie
#[Out]# 167    Veerle
#[Out]# 168      Kiki
#[Out]# 169      Lily
#[Out]# 170      Iris
#[Out]# 171     Tessa
#[Out]# 172      Lana
#[Out]# 173     Livia
#[Out]# 174      Romy
#[Out]# 175     Amira
#[Out]# 176     Eline
#[Out]# 177      Elif
#[Out]# 178      Juul
#[Out]# 179     Merel
#[Out]# 180      Liva
#[Out]# 181   Johanna
#[Out]# 182     Nikki
#[Out]# 183     Wilko
#[Out]# 184      Nick
#[Out]# 185    Angela
#[Out]# 186      Pino
#[Out]# 187      Koen
#[Out]# 188    Kostas
#[Out]# 
#[Out]# [189 rows x 1 columns]
# Mon, 30 Nov 2020 16:02:34
query3_2 = '''
    SELECT distinct cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID == shoppinglist.cID AND customer.cID == purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#         cName
#[Out]# 0         Sem
#[Out]# 1       Lucas
#[Out]# 2        Finn
#[Out]# 3        Levi
#[Out]# 4        Bram
#[Out]# 5        Liam
#[Out]# 6         Sam
#[Out]# 7       Thijs
#[Out]# 8       James
#[Out]# 9        Noud
#[Out]# 10        Dex
#[Out]# 11       Hugo
#[Out]# 12       Lars
#[Out]# 13       Gijs
#[Out]# 14   Benjamin
#[Out]# 15       Mats
#[Out]# 16       Luca
#[Out]# 17     Jayden
#[Out]# 18        Tim
#[Out]# 19       Siem
#[Out]# 20      Ruben
#[Out]# 21       Teun
#[Out]# 22    Olivier
#[Out]# 23       Sven
#[Out]# 24      David
#[Out]# 25      Stijn
#[Out]# 26       Guus
#[Out]# 27     Floris
#[Out]# 28       Jack
#[Out]# 29       Jens
#[Out]# ..        ...
#[Out]# 73      Milou
#[Out]# 74      Sofie
#[Out]# 75      Emily
#[Out]# 76    Jasmijn
#[Out]# 77     Sophia
#[Out]# 78       Ella
#[Out]# 79       Lena
#[Out]# 80        Ivy
#[Out]# 81       Fien
#[Out]# 82     Isabel
#[Out]# 83      Lizzy
#[Out]# 84       Jill
#[Out]# 85       Anne
#[Out]# 86       Puck
#[Out]# 87      Fenne
#[Out]# 88      Floor
#[Out]# 89      Elena
#[Out]# 90       Cato
#[Out]# 91      Hanna
#[Out]# 92     Veerle
#[Out]# 93       Kiki
#[Out]# 94       Lily
#[Out]# 95       Iris
#[Out]# 96      Tessa
#[Out]# 97       Lana
#[Out]# 98      Amira
#[Out]# 99       Elif
#[Out]# 100      Juul
#[Out]# 101     Merel
#[Out]# 102      Liva
#[Out]# 
#[Out]# [103 rows x 1 columns]
# Mon, 30 Nov 2020 16:02:53
query3_2 = '''
    SELECT distinct customer.cID, cName
    FROM customer, shoppinglist, purchase
    WHERE customer.cID = shoppinglist.cID AND customer.cID = purchase.cID AND shoppinglist.date = purchase.date AND shoppinglist.date like '%2018%'
'''

pd.read_sql_query(query3_2, conn)
#[Out]#      cID     cName
#[Out]# 0      1       Sem
#[Out]# 1      2     Lucas
#[Out]# 2      3      Finn
#[Out]# 3      5      Levi
#[Out]# 4      7      Bram
#[Out]# 5      8      Liam
#[Out]# 6     10       Sam
#[Out]# 7     11     Thijs
#[Out]# 8     13     James
#[Out]# 9     15      Noud
#[Out]# 10    17       Dex
#[Out]# 11    18      Hugo
#[Out]# 12    19      Lars
#[Out]# 13    20      Gijs
#[Out]# 14    21  Benjamin
#[Out]# 15    22      Mats
#[Out]# 16    24      Luca
#[Out]# 17    26    Jayden
#[Out]# 18    27       Tim
#[Out]# 19    28      Siem
#[Out]# 20    29     Ruben
#[Out]# 21    30      Teun
#[Out]# 22    31   Olivier
#[Out]# 23    33      Sven
#[Out]# 24    34     David
#[Out]# 25    35     Stijn
#[Out]# 26    37      Guus
#[Out]# 27    38    Floris
#[Out]# 28    39      Jack
#[Out]# 29    40      Jens
#[Out]# ..   ...       ...
#[Out]# 74   124     Sofie
#[Out]# 75   127     Emily
#[Out]# 76   128   Jasmijn
#[Out]# 77   133    Sophia
#[Out]# 78   134      Ella
#[Out]# 79   137      Lena
#[Out]# 80   144       Ivy
#[Out]# 81   145      Fien
#[Out]# 82   147    Isabel
#[Out]# 83   149     Lizzy
#[Out]# 84   151      Jill
#[Out]# 85   152      Anne
#[Out]# 86   157      Puck
#[Out]# 87   159     Fenne
#[Out]# 88   161     Floor
#[Out]# 89   162     Elena
#[Out]# 90   163      Cato
#[Out]# 91   165     Hanna
#[Out]# 92   167    Veerle
#[Out]# 93   168      Kiki
#[Out]# 94   169      Lily
#[Out]# 95   170      Iris
#[Out]# 96   171     Tessa
#[Out]# 97   172      Lana
#[Out]# 98   175       Sam
#[Out]# 99   176     Amira
#[Out]# 100  178      Elif
#[Out]# 101  179      Juul
#[Out]# 102  180     Merel
#[Out]# 103  181      Liva
#[Out]# 
#[Out]# [104 rows x 2 columns]
# Mon, 30 Nov 2020 16:10:52
query3_3 = '''
    SELECT customer.cID, cName
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Jumbo'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName
#[Out]# 0     4      Daan
#[Out]# 1    18      Hugo
#[Out]# 2    19      Lars
#[Out]# 3    19      Lars
#[Out]# 4    21  Benjamin
#[Out]# 5    24      Luca
#[Out]# 6    27       Tim
#[Out]# 7    37      Guus
#[Out]# 8    38    Floris
#[Out]# 9    40      Jens
#[Out]# 10   47      Xavi
#[Out]# 11   52    Willem
#[Out]# 12   59      Joep
#[Out]# 13   63      Senn
#[Out]# 14   66   Mohamed
#[Out]# 15   68     Boris
#[Out]# 16   72      Dani
#[Out]# 17   78      Mick
#[Out]# 18   85    Pieter
#[Out]# 19   86      Stef
#[Out]# 20  104       Liv
#[Out]# 21  109      Lynn
#[Out]# 22  112      Yara
#[Out]# 23  122      Elin
#[Out]# 24  126      Lina
#[Out]# 25  136     Femke
#[Out]# 26  165     Hanna
#[Out]# 27  167    Veerle
#[Out]# 28  171     Tessa
#[Out]# 29  172      Lana
#[Out]# 30  180     Merel
#[Out]# 31  185      Nick
#[Out]# 32  186    Angela
#[Out]# 33  188      Pino
#[Out]# 34  188      Pino
#[Out]# 35  189      Koen
#[Out]# 36  189      Koen
#[Out]# 37  190    Kostas
#[Out]# 38  190    Kostas
#[Out]# 39  190    Kostas
#[Out]# 40  190    Kostas
#[Out]# 41  190    Kostas
#[Out]# 42  190    Kostas
#[Out]# 43  190    Kostas
#[Out]# 44  190    Kostas
# Mon, 30 Nov 2020 16:11:08
query3_3 = '''
    SELECT distinct customer.cID, cName, sName
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Jumbo'
'''

pd.read_sql_query(query3_3, conn)
#[Out]#     cID     cName  sName
#[Out]# 0     4      Daan  Jumbo
#[Out]# 1    18      Hugo  Jumbo
#[Out]# 2    19      Lars  Jumbo
#[Out]# 3    21  Benjamin  Jumbo
#[Out]# 4    24      Luca  Jumbo
#[Out]# 5    27       Tim  Jumbo
#[Out]# 6    37      Guus  Jumbo
#[Out]# 7    38    Floris  Jumbo
#[Out]# 8    40      Jens  Jumbo
#[Out]# 9    47      Xavi  Jumbo
#[Out]# 10   52    Willem  Jumbo
#[Out]# 11   59      Joep  Jumbo
#[Out]# 12   63      Senn  Jumbo
#[Out]# 13   66   Mohamed  Jumbo
#[Out]# 14   68     Boris  Jumbo
#[Out]# 15   72      Dani  Jumbo
#[Out]# 16   78      Mick  Jumbo
#[Out]# 17   85    Pieter  Jumbo
#[Out]# 18   86      Stef  Jumbo
#[Out]# 19  104       Liv  Jumbo
#[Out]# 20  109      Lynn  Jumbo
#[Out]# 21  112      Yara  Jumbo
#[Out]# 22  122      Elin  Jumbo
#[Out]# 23  126      Lina  Jumbo
#[Out]# 24  136     Femke  Jumbo
#[Out]# 25  165     Hanna  Jumbo
#[Out]# 26  167    Veerle  Jumbo
#[Out]# 27  171     Tessa  Jumbo
#[Out]# 28  172      Lana  Jumbo
#[Out]# 29  180     Merel  Jumbo
#[Out]# 30  185      Nick  Jumbo
#[Out]# 31  186    Angela  Jumbo
#[Out]# 32  188      Pino  Jumbo
#[Out]# 33  189      Koen  Jumbo
#[Out]# 34  190    Kostas  Jumbo
# Mon, 30 Nov 2020 16:13:10
query3_3 = '''
    SELECT cID, cName
    FROM customer
    WHERE cID NOT IN (SELECT distinct customer.cID, cName, sName
        FROM customer, purchase, store
        WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Jumbo')
    
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 16:13:46
query3_3 = '''
    SELECT cID, cName
    FROM customer
    WHERE cID NOT IN (SELECT distinct customer.cID
        FROM customer, purchase, store
        WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Jumbo')
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID    cName
#[Out]# 0      0     Noah
#[Out]# 1      1      Sem
#[Out]# 2      2    Lucas
#[Out]# 3      3     Finn
#[Out]# 4      5     Levi
#[Out]# 5      6    Milan
#[Out]# 6      7     Bram
#[Out]# 7      8     Liam
#[Out]# 8      9   Thomas
#[Out]# 9     10      Sam
#[Out]# 10    11    Thijs
#[Out]# 11    12     Adam
#[Out]# 12    13    James
#[Out]# 13    14      Max
#[Out]# 14    15     Noud
#[Out]# 15    16   Julian
#[Out]# 16    17      Dex
#[Out]# 17    20     Gijs
#[Out]# 18    22     Mats
#[Out]# 19    23      Jan
#[Out]# 20    25    Mason
#[Out]# 21    26   Jayden
#[Out]# 22    28     Siem
#[Out]# 23    29    Ruben
#[Out]# 24    30     Teun
#[Out]# 25    31  Olivier
#[Out]# 26    32    Vince
#[Out]# 27    33     Sven
#[Out]# 28    34    David
#[Out]# 29    35    Stijn
#[Out]# ..   ...      ...
#[Out]# 125  150    Julie
#[Out]# 126  151     Jill
#[Out]# 127  152     Anne
#[Out]# 128  153    Amber
#[Out]# 129  154   Benthe
#[Out]# 130  155    Linde
#[Out]# 131  156     Luna
#[Out]# 132  157     Puck
#[Out]# 133  158     Rosa
#[Out]# 134  159    Fenne
#[Out]# 135  160     Lara
#[Out]# 136  161    Floor
#[Out]# 137  162    Elena
#[Out]# 138  163     Cato
#[Out]# 139  164      Evy
#[Out]# 140  166  Rosalie
#[Out]# 141  168     Kiki
#[Out]# 142  169     Lily
#[Out]# 143  170     Iris
#[Out]# 144  173    Livia
#[Out]# 145  174     Romy
#[Out]# 146  175      Sam
#[Out]# 147  176    Amira
#[Out]# 148  177    Eline
#[Out]# 149  178     Elif
#[Out]# 150  179     Juul
#[Out]# 151  181     Liva
#[Out]# 152  182  Johanna
#[Out]# 153  183    Nikki
#[Out]# 154  184    Wilko
#[Out]# 
#[Out]# [155 rows x 2 columns]
# Mon, 30 Nov 2020 16:16:27
query3_3 = '''
    SELECT cID, cName
    FROM customer
    WHERE cID NOT IN (SELECT distinct customer.cID
        FROM customer, purchase, store
        WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Coop)
    
'''

pd.read_sql_query(query3_3, conn)
# Mon, 30 Nov 2020 16:16:31
query3_3 = '''
    SELECT cID, cName
    FROM customer
    WHERE cID NOT IN (SELECT distinct customer.cID
        FROM customer, purchase, store
        WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Coop')
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Mon, 30 Nov 2020 16:21:10
query3_4 = '''
    SELECT distinct customer.cID
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName != 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# 5      5
#[Out]# 6      7
#[Out]# 7      8
#[Out]# 8     10
#[Out]# 9     11
#[Out]# 10    13
#[Out]# 11    15
#[Out]# 12    16
#[Out]# 13    17
#[Out]# 14    18
#[Out]# 15    19
#[Out]# 16    20
#[Out]# 17    21
#[Out]# 18    22
#[Out]# 19    24
#[Out]# 20    25
#[Out]# 21    26
#[Out]# 22    27
#[Out]# 23    28
#[Out]# 24    29
#[Out]# 25    30
#[Out]# 26    31
#[Out]# 27    33
#[Out]# 28    34
#[Out]# 29    35
#[Out]# ..   ...
#[Out]# 94   137
#[Out]# 95   139
#[Out]# 96   144
#[Out]# 97   145
#[Out]# 98   147
#[Out]# 99   149
#[Out]# 100  151
#[Out]# 101  152
#[Out]# 102  157
#[Out]# 103  159
#[Out]# 104  161
#[Out]# 105  162
#[Out]# 106  163
#[Out]# 107  165
#[Out]# 108  167
#[Out]# 109  168
#[Out]# 110  169
#[Out]# 111  170
#[Out]# 112  171
#[Out]# 113  172
#[Out]# 114  175
#[Out]# 115  176
#[Out]# 116  177
#[Out]# 117  178
#[Out]# 118  179
#[Out]# 119  180
#[Out]# 120  181
#[Out]# 121  182
#[Out]# 122  184
#[Out]# 123  190
#[Out]# 
#[Out]# [124 rows x 1 columns]
# Mon, 30 Nov 2020 16:21:23
query3_3 = '''
    SELECT distinct cID, cName
    FROM customer
    WHERE cID NOT IN (SELECT distinct customer.cID
        FROM customer, purchase, store
        WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Coop')
    
'''

pd.read_sql_query(query3_3, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      3      Finn
#[Out]# 3      6     Milan
#[Out]# 4      7      Bram
#[Out]# 5      9    Thomas
#[Out]# 6     12      Adam
#[Out]# 7     13     James
#[Out]# 8     14       Max
#[Out]# 9     15      Noud
#[Out]# 10    19      Lars
#[Out]# 11    22      Mats
#[Out]# 12    23       Jan
#[Out]# 13    25     Mason
#[Out]# 14    30      Teun
#[Out]# 15    31   Olivier
#[Out]# 16    32     Vince
#[Out]# 17    34     David
#[Out]# 18    36      Boaz
#[Out]# 19    37      Guus
#[Out]# 20    38    Floris
#[Out]# 21    40      Jens
#[Out]# 22    41     Quinn
#[Out]# 23    43       Tom
#[Out]# 24    44     Jason
#[Out]# 25    45      Ryan
#[Out]# 26    46     Fedde
#[Out]# 27    47      Xavi
#[Out]# 28    48      Tygo
#[Out]# 29    49       Cas
#[Out]# ..   ...       ...
#[Out]# 86   142        Bo
#[Out]# 87   143     Naomi
#[Out]# 88   145      Fien
#[Out]# 89   146     Norah
#[Out]# 90   148  Isabella
#[Out]# 91   149     Lizzy
#[Out]# 92   150     Julie
#[Out]# 93   153     Amber
#[Out]# 94   154    Benthe
#[Out]# 95   155     Linde
#[Out]# 96   156      Luna
#[Out]# 97   157      Puck
#[Out]# 98   158      Rosa
#[Out]# 99   159     Fenne
#[Out]# 100  160      Lara
#[Out]# 101  164       Evy
#[Out]# 102  166   Rosalie
#[Out]# 103  167    Veerle
#[Out]# 104  168      Kiki
#[Out]# 105  170      Iris
#[Out]# 106  171     Tessa
#[Out]# 107  173     Livia
#[Out]# 108  174      Romy
#[Out]# 109  175       Sam
#[Out]# 110  182   Johanna
#[Out]# 111  183     Nikki
#[Out]# 112  185      Nick
#[Out]# 113  186    Angela
#[Out]# 114  188      Pino
#[Out]# 115  189      Koen
#[Out]# 
#[Out]# [116 rows x 2 columns]
# Mon, 30 Nov 2020 16:21:50
query3_4 = '''
    SELECT distinct customer.cID, store.sName 
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName != 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#      cID        sName
#[Out]# 0      0       Sligro
#[Out]# 1      1         Dirk
#[Out]# 2      1       Sligro
#[Out]# 3      1    Hoogvliet
#[Out]# 4      1  Albert Hein
#[Out]# 5      1         Lidl
#[Out]# 6      2         Lidl
#[Out]# 7      2       Sligro
#[Out]# 8      2         Coop
#[Out]# 9      3  Albert Hein
#[Out]# 10     3         Dirk
#[Out]# 11     3       Sligro
#[Out]# 12     4    Hoogvliet
#[Out]# 13     4         Coop
#[Out]# 14     4       Sligro
#[Out]# 15     4  Albert Hein
#[Out]# 16     5    Hoogvliet
#[Out]# 17     5         Lidl
#[Out]# 18     5         Coop
#[Out]# 19     7       Sligro
#[Out]# 20     7         Lidl
#[Out]# 21     7  Albert Hein
#[Out]# 22     7    Hoogvliet
#[Out]# 23     8         Coop
#[Out]# 24    10         Coop
#[Out]# 25    11         Coop
#[Out]# 26    13         Dirk
#[Out]# 27    13    Hoogvliet
#[Out]# 28    13         Lidl
#[Out]# 29    13       Sligro
#[Out]# ..   ...          ...
#[Out]# 269  170         Lidl
#[Out]# 270  170    Hoogvliet
#[Out]# 271  171  Albert Hein
#[Out]# 272  172         Coop
#[Out]# 273  175       Sligro
#[Out]# 274  175         Lidl
#[Out]# 275  176         Lidl
#[Out]# 276  176         Coop
#[Out]# 277  176    Hoogvliet
#[Out]# 278  177         Coop
#[Out]# 279  177    Hoogvliet
#[Out]# 280  177  Albert Hein
#[Out]# 281  178         Coop
#[Out]# 282  178       Sligro
#[Out]# 283  179  Albert Hein
#[Out]# 284  179         Dirk
#[Out]# 285  179         Coop
#[Out]# 286  179         Lidl
#[Out]# 287  180         Coop
#[Out]# 288  181         Coop
#[Out]# 289  181       Sligro
#[Out]# 290  182    Hoogvliet
#[Out]# 291  182       Sligro
#[Out]# 292  184         Coop
#[Out]# 293  190         Coop
#[Out]# 294  190    Hoogvliet
#[Out]# 295  190       Sligro
#[Out]# 296  190  Albert Hein
#[Out]# 297  190         Lidl
#[Out]# 298  190         Dirk
#[Out]# 
#[Out]# [299 rows x 2 columns]
# Mon, 30 Nov 2020 16:23:26
query3_4 = '''
SELECT distinct customer.cID
FROM customer
WHERE cID NOT IN (
    SELECT distinct customer.cID, store.sName 
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName != 'Jumbo'
    )
'''

pd.read_sql_query(query3_4, conn)
# Mon, 30 Nov 2020 16:23:32
query3_4 = '''
SELECT distinct customer.cID
FROM customer
WHERE cID NOT IN (
    SELECT distinct customer.cID
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName != 'Jumbo'
    )
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     6
#[Out]# 1     9
#[Out]# 2    12
#[Out]# 3    14
#[Out]# 4    23
#[Out]# 5    32
#[Out]# 6    36
#[Out]# 7    46
#[Out]# 8    47
#[Out]# 9    48
#[Out]# 10   49
#[Out]# 11   50
#[Out]# 12   53
#[Out]# 13   54
#[Out]# 14   56
#[Out]# 15   61
#[Out]# 16   62
#[Out]# 17   63
#[Out]# 18   65
#[Out]# 19   73
#[Out]# 20   74
#[Out]# 21   79
#[Out]# 22   81
#[Out]# 23   83
#[Out]# 24   87
#[Out]# 25   89
#[Out]# 26   93
#[Out]# 27   98
#[Out]# 28  101
#[Out]# 29  102
#[Out]# ..  ...
#[Out]# 36  117
#[Out]# 37  120
#[Out]# 38  121
#[Out]# 39  125
#[Out]# 40  130
#[Out]# 41  132
#[Out]# 42  136
#[Out]# 43  138
#[Out]# 44  140
#[Out]# 45  141
#[Out]# 46  142
#[Out]# 47  143
#[Out]# 48  146
#[Out]# 49  148
#[Out]# 50  150
#[Out]# 51  153
#[Out]# 52  154
#[Out]# 53  155
#[Out]# 54  156
#[Out]# 55  158
#[Out]# 56  160
#[Out]# 57  164
#[Out]# 58  166
#[Out]# 59  173
#[Out]# 60  174
#[Out]# 61  183
#[Out]# 62  185
#[Out]# 63  186
#[Out]# 64  188
#[Out]# 65  189
#[Out]# 
#[Out]# [66 rows x 1 columns]
# Mon, 30 Nov 2020 16:24:52
query3_4 = '''
SELECT distinct customer.cID
FROM customer
WHERE cID NOT IN (
    SELECT distinct customer.cID
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName != 'Jumbo'
    ) AND cID = 12
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID
#[Out]# 0   12
# Mon, 30 Nov 2020 16:25:25
query3_4 = '''
SELECT distinct customer.cID
FROM customer, purchase, store
WHERE customer.cID NOT IN (
    SELECT distinct customer.cID
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName != 'Jumbo'
    ) AND purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID
#[Out]# 0   47
#[Out]# 1   63
#[Out]# 2  104
#[Out]# 3  136
#[Out]# 4  185
#[Out]# 5  186
#[Out]# 6  188
#[Out]# 7  189
# Mon, 30 Nov 2020 16:27:39
query3_4 = '''
SELECT distinct customer.cID
FROM customer, purchase, store
WHERE customer.cID IN (
    SELECT distinct customer.cID
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName != 'Jumbo'
    ) 
    AND purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#     cID
#[Out]# 0     4
#[Out]# 1    18
#[Out]# 2    19
#[Out]# 3    21
#[Out]# 4    24
#[Out]# 5    27
#[Out]# 6    37
#[Out]# 7    38
#[Out]# 8    40
#[Out]# 9    52
#[Out]# 10   59
#[Out]# 11   66
#[Out]# 12   68
#[Out]# 13   72
#[Out]# 14   78
#[Out]# 15   85
#[Out]# 16   86
#[Out]# 17  109
#[Out]# 18  112
#[Out]# 19  122
#[Out]# 20  126
#[Out]# 21  165
#[Out]# 22  167
#[Out]# 23  171
#[Out]# 24  172
#[Out]# 25  180
#[Out]# 26  190
# Mon, 30 Nov 2020 16:28:27
query3_4 = '''
SELECT distinct customer.cID
FROM customer, purchase, store
WHERE customer.cID NOT IN (
    SELECT distinct customer.cID
    FROM customer, purchase, store
    WHERE purchase.cID = customer.cID AND purchase.sID = store.sID AND sName != 'Jumbo'
    ) 
    AND purchase.cID = customer.cID AND purchase.sID = store.sID AND sName = 'Jumbo'
'''

pd.read_sql_query(query3_4, conn)
#[Out]#    cID
#[Out]# 0   47
#[Out]# 1   63
#[Out]# 2  104
#[Out]# 3  136
#[Out]# 4  185
#[Out]# 5  186
#[Out]# 6  188
#[Out]# 7  189


# IPython log file

# Wed, 09 Dec 2020 10:34:45
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 10:34:48
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1f9179e5dc0>
# Wed, 09 Dec 2020 10:35:59
query4_3 = '''
    with customer_store(city) as (
	select city from customer
	union 
	select city from store )
select sName, city
from store s1
where not exists (
	select city
	from customer_city
	where not exists (
		select *
		from store s2
		where s2.sName=s1.sName
		and s2.city = customer_city.city))
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:36:33
query4_3 = '''

with customer_store(city) as (
select city from customer
union 
select city from store )
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:37:39
query4_3 = '''

with customer_store(city) as(
    select city from customer
    union 
    select city from store)
select *
from customer_store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 10:38:10
query4_3 = '''
select sName, city
from store s1
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 10:38:56
query4_3 = '''

with customer_store(city) as(
    select city from customer
    union 
    select city from store)
select sName, city
from store s1
where not exists(
    select city
    from customer_city
)
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:39:17
query4_3 = '''

with customer_store(city) as(
    select city from customer
    union 
    select city from store)
select sName, city
from store s1
where not exists(
    select city
    from customer_store
)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 10:40:16
query4_3 = '''

with customer_store(city) as(
    select city from customer
    union 
    select city from store)
select sName, city
from store s1
where not exists(
    select city
    from customer_store
    where not exists (
                select *
                from store s2
                where s2.sName=s1.sName
                and s2.city = customer_store.city)
)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 10:54:25
query4_4 = '''
    select *
    from purchase 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15
#[Out]# 17    17    4   10   27  2018-08-24         9   9.05
#[Out]# 18    18    4   53   12  2018-08-25         5  13.60
#[Out]# 19    19    4   21    6  2018-08-24         2   1.05
#[Out]# 20    20    4    7   13  2018-08-25         9   3.05
#[Out]# 21    21    4   44   26  2018-08-25         4   2.75
#[Out]# 22    22    5    4   14  2018-08-17         6   4.70
#[Out]# 23    23    5   36   28  2018-08-22         6   8.25
#[Out]# 24    24    5   55    6  2018-08-23         9   1.10
#[Out]# 25    25    5   51   22  2018-08-23         2   1.55
#[Out]# 26    26    5    6   16  2018-08-23         2   1.85
#[Out]# 27    27    5   17   19  2018-08-23         1   2.20
#[Out]# 28    28    7    3   19  2018-08-23         2   2.10
#[Out]# 29    29    7   12    2  2018-08-23         6   1.70
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 479  818  190   34   28  2018-08-20         4   2.80
#[Out]# 480  819  190   35   27  2018-08-15         5   0.50
#[Out]# 481  820  190   36    5  2018-08-23         3   2.55
#[Out]# 482  821  190   37   28  2018-08-15         4   0.65
#[Out]# 483  822  190   38    7  2018-08-24         4   0.70
#[Out]# 484  823  190   39    0  2018-08-25         4   3.70
#[Out]# 485  824  190   40   11  2018-08-15         2   3.50
#[Out]# 486  825  190   41    6  2018-08-15         5   2.95
#[Out]# 487  826  190   42   19  2018-08-22         5   2.75
#[Out]# 488  827  190   43   17  2018-08-17         7   1.50
#[Out]# 489  828  190   44    9  2018-08-18         5   0.85
#[Out]# 490  829  190   45   11  2018-08-19         2   3.55
#[Out]# 491  830  190   46   22  2018-08-25         4   2.60
#[Out]# 492  831  190   47   17  2018-08-17         4   3.25
#[Out]# 493  832  190   48   20  2018-08-26         6   4.30
#[Out]# 494  833  190   49   11  2018-08-17         3   3.05
#[Out]# 495  834  190   50   21  2018-08-22         6   4.05
#[Out]# 496  835  190   51   23  2018-08-19         1   1.50
#[Out]# 497  836  190   52   23  2018-08-15         5   2.50
#[Out]# 498  837  190   53    8  2018-08-18         4   3.95
#[Out]# 499  838  190   54    0  2018-08-25         6   3.50
#[Out]# 500  839  190   55    8  2018-08-18         7   2.95
#[Out]# 501  840  190   56   11  2018-08-15         4   1.60
#[Out]# 502  841  190   57   15  2018-08-22         5   3.25
#[Out]# 503  842  190   58    2  2018-08-19         7   0.75
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Wed, 09 Dec 2020 10:55:53
query4_4 = '''
    select sum(price)
    from purchase
    where cID =1
    and date='2018-8-22'
'''

pd.read_sql_query(query4_4, conn)
#[Out]#   sum(price)
#[Out]# 0       None
# Wed, 09 Dec 2020 10:56:17
query4_4 = '''
    select *
    from purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15
#[Out]# 17    17    4   10   27  2018-08-24         9   9.05
#[Out]# 18    18    4   53   12  2018-08-25         5  13.60
#[Out]# 19    19    4   21    6  2018-08-24         2   1.05
#[Out]# 20    20    4    7   13  2018-08-25         9   3.05
#[Out]# 21    21    4   44   26  2018-08-25         4   2.75
#[Out]# 22    22    5    4   14  2018-08-17         6   4.70
#[Out]# 23    23    5   36   28  2018-08-22         6   8.25
#[Out]# 24    24    5   55    6  2018-08-23         9   1.10
#[Out]# 25    25    5   51   22  2018-08-23         2   1.55
#[Out]# 26    26    5    6   16  2018-08-23         2   1.85
#[Out]# 27    27    5   17   19  2018-08-23         1   2.20
#[Out]# 28    28    7    3   19  2018-08-23         2   2.10
#[Out]# 29    29    7   12    2  2018-08-23         6   1.70
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 479  818  190   34   28  2018-08-20         4   2.80
#[Out]# 480  819  190   35   27  2018-08-15         5   0.50
#[Out]# 481  820  190   36    5  2018-08-23         3   2.55
#[Out]# 482  821  190   37   28  2018-08-15         4   0.65
#[Out]# 483  822  190   38    7  2018-08-24         4   0.70
#[Out]# 484  823  190   39    0  2018-08-25         4   3.70
#[Out]# 485  824  190   40   11  2018-08-15         2   3.50
#[Out]# 486  825  190   41    6  2018-08-15         5   2.95
#[Out]# 487  826  190   42   19  2018-08-22         5   2.75
#[Out]# 488  827  190   43   17  2018-08-17         7   1.50
#[Out]# 489  828  190   44    9  2018-08-18         5   0.85
#[Out]# 490  829  190   45   11  2018-08-19         2   3.55
#[Out]# 491  830  190   46   22  2018-08-25         4   2.60
#[Out]# 492  831  190   47   17  2018-08-17         4   3.25
#[Out]# 493  832  190   48   20  2018-08-26         6   4.30
#[Out]# 494  833  190   49   11  2018-08-17         3   3.05
#[Out]# 495  834  190   50   21  2018-08-22         6   4.05
#[Out]# 496  835  190   51   23  2018-08-19         1   1.50
#[Out]# 497  836  190   52   23  2018-08-15         5   2.50
#[Out]# 498  837  190   53    8  2018-08-18         4   3.95
#[Out]# 499  838  190   54    0  2018-08-25         6   3.50
#[Out]# 500  839  190   55    8  2018-08-18         7   2.95
#[Out]# 501  840  190   56   11  2018-08-15         4   1.60
#[Out]# 502  841  190   57   15  2018-08-22         5   3.25
#[Out]# 503  842  190   58    2  2018-08-19         7   0.75
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Wed, 09 Dec 2020 10:57:09
query4_4 = '''
    select sum(price)
    from purchase
    where cID =1
    and date='2018-8-20'
'''

pd.read_sql_query(query4_4, conn)
#[Out]#   sum(price)
#[Out]# 0       None
# Wed, 09 Dec 2020 10:57:46
query4_4 = '''
    select *
    from purchase
    where cID =1
    and date='2018-8-20'
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Wed, 09 Dec 2020 10:57:52
query4_4 = '''
    select *
    from purchase
    where cID =1
    and date='2018-8-20';
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Wed, 09 Dec 2020 10:57:56
query4_4 = '''
    select *
    from purchase
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15
#[Out]# 17    17    4   10   27  2018-08-24         9   9.05
#[Out]# 18    18    4   53   12  2018-08-25         5  13.60
#[Out]# 19    19    4   21    6  2018-08-24         2   1.05
#[Out]# 20    20    4    7   13  2018-08-25         9   3.05
#[Out]# 21    21    4   44   26  2018-08-25         4   2.75
#[Out]# 22    22    5    4   14  2018-08-17         6   4.70
#[Out]# 23    23    5   36   28  2018-08-22         6   8.25
#[Out]# 24    24    5   55    6  2018-08-23         9   1.10
#[Out]# 25    25    5   51   22  2018-08-23         2   1.55
#[Out]# 26    26    5    6   16  2018-08-23         2   1.85
#[Out]# 27    27    5   17   19  2018-08-23         1   2.20
#[Out]# 28    28    7    3   19  2018-08-23         2   2.10
#[Out]# 29    29    7   12    2  2018-08-23         6   1.70
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 479  818  190   34   28  2018-08-20         4   2.80
#[Out]# 480  819  190   35   27  2018-08-15         5   0.50
#[Out]# 481  820  190   36    5  2018-08-23         3   2.55
#[Out]# 482  821  190   37   28  2018-08-15         4   0.65
#[Out]# 483  822  190   38    7  2018-08-24         4   0.70
#[Out]# 484  823  190   39    0  2018-08-25         4   3.70
#[Out]# 485  824  190   40   11  2018-08-15         2   3.50
#[Out]# 486  825  190   41    6  2018-08-15         5   2.95
#[Out]# 487  826  190   42   19  2018-08-22         5   2.75
#[Out]# 488  827  190   43   17  2018-08-17         7   1.50
#[Out]# 489  828  190   44    9  2018-08-18         5   0.85
#[Out]# 490  829  190   45   11  2018-08-19         2   3.55
#[Out]# 491  830  190   46   22  2018-08-25         4   2.60
#[Out]# 492  831  190   47   17  2018-08-17         4   3.25
#[Out]# 493  832  190   48   20  2018-08-26         6   4.30
#[Out]# 494  833  190   49   11  2018-08-17         3   3.05
#[Out]# 495  834  190   50   21  2018-08-22         6   4.05
#[Out]# 496  835  190   51   23  2018-08-19         1   1.50
#[Out]# 497  836  190   52   23  2018-08-15         5   2.50
#[Out]# 498  837  190   53    8  2018-08-18         4   3.95
#[Out]# 499  838  190   54    0  2018-08-25         6   3.50
#[Out]# 500  839  190   55    8  2018-08-18         7   2.95
#[Out]# 501  840  190   56   11  2018-08-15         4   1.60
#[Out]# 502  841  190   57   15  2018-08-22         5   3.25
#[Out]# 503  842  190   58    2  2018-08-19         7   0.75
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Wed, 09 Dec 2020 10:58:15
query4_4 = '''
    select *
    from purchase
    where cID =1
    and date='2018-08-20';
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    tID  cID  sID  pID        date  quantity  price
#[Out]# 0    1    1   23   14  2018-08-20         2   4.65
#[Out]# 1    2    1    3   16  2018-08-20         3   1.60
#[Out]# 2    3    1   17    9  2018-08-20         2   1.25
#[Out]# 3    4    1   32   25  2018-08-20         4   3.95
#[Out]# 4    5    1   16   26  2018-08-20         4   2.75
# Wed, 09 Dec 2020 10:58:24
query4_4 = '''
    select sum(price)
    from purchase
    where cID =1
    and date='2018-08-20';
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    sum(price)
#[Out]# 0        14.2
# Wed, 09 Dec 2020 10:58:56
query4_3 = '''

with customer_store(city) as(
    select city from customer
    union 
    select city from store)
select sName, city
from store s1
where not exists(
    select city
    from customer_store
    where not exists (
                select *
                from store s2
                where s2.sName=s1.sName
                and s2.city = customer_store.city
                )
    );
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 10:59:34
query4_4 = '''
    select cID, max(sum(price))
    from purchase
    and date='2018-08-20';
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:59:48
query4_4 = '''
    select cID, max(sum(price))
    from purchase
    where date='2018-08-20';
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:59:59
query4_4 = '''
    select cID, sum(price)
    from purchase
    where date='2018-08-20';
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  sum(price)
#[Out]# 0    1      103.75
# Wed, 09 Dec 2020 11:00:20
query4_4 = '''
    select cID
    from purchase
    where date='2018-08-20';
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     1
#[Out]# 2     1
#[Out]# 3     1
#[Out]# 4     1
#[Out]# 5    24
#[Out]# 6    24
#[Out]# 7    24
#[Out]# 8    24
#[Out]# 9    24
#[Out]# 10   24
#[Out]# 11   72
#[Out]# 12   82
#[Out]# 13  100
#[Out]# 14  100
#[Out]# 15  109
#[Out]# 16  109
#[Out]# 17  118
#[Out]# 18  129
#[Out]# 19  129
#[Out]# 20  129
#[Out]# 21  152
#[Out]# 22  152
#[Out]# 23  167
#[Out]# 24  167
#[Out]# 25  167
#[Out]# 26  167
#[Out]# 27  169
#[Out]# 28  169
#[Out]# 29  171
#[Out]# 30  171
#[Out]# 31  175
#[Out]# 32  177
#[Out]# 33  184
#[Out]# 34  185
#[Out]# 35  188
#[Out]# 36  190
#[Out]# 37  190
#[Out]# 38  190
#[Out]# 39  190
# Wed, 09 Dec 2020 11:00:31
query4_4 = '''
    select *
    from purchase
    where date='2018-08-20';
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price
#[Out]# 0     1    1   23   14  2018-08-20         2   4.65
#[Out]# 1     2    1    3   16  2018-08-20         3   1.60
#[Out]# 2     3    1   17    9  2018-08-20         2   1.25
#[Out]# 3     4    1   32   25  2018-08-20         4   3.95
#[Out]# 4     5    1   16   26  2018-08-20         4   2.75
#[Out]# 5    77   24   11   18  2018-08-20         1  11.55
#[Out]# 6    78   24   17    5  2018-08-20         7   0.55
#[Out]# 7    79   24   45   10  2018-08-20         1   0.60
#[Out]# 8    80   24   49    7  2018-08-20         4   2.05
#[Out]# 9    81   24   14    0  2018-08-20         3   4.80
#[Out]# 10   82   24   36    6  2018-08-20         3   1.15
#[Out]# 11  201   72    7   20  2018-08-20         5   2.10
#[Out]# 12  219   82   13   13  2018-08-20         4   4.00
#[Out]# 13  268  100   50   15  2018-08-20         2   1.30
#[Out]# 14  274  100   47   23  2018-08-20         8   2.55
#[Out]# 15  285  109   38    9  2018-08-20         5   1.50
#[Out]# 16  286  109   44    6  2018-08-20         4   1.05
#[Out]# 17  307  118   38   28  2018-08-20         5   6.95
#[Out]# 18  340  129   17   20  2018-08-20         7   2.40
#[Out]# 19  341  129   24    5  2018-08-20         7   0.45
#[Out]# 20  342  129   55   15  2018-08-20         7   1.40
#[Out]# 21  369  152   14   21  2018-08-20         1   1.85
#[Out]# 22  370  152   42   20  2018-08-20         5   2.00
#[Out]# 23  418  167   18   19  2018-08-20         1   2.25
#[Out]# 24  419  167   40   26  2018-08-20         9   3.00
#[Out]# 25  420  167   56    7  2018-08-20         1   2.10
#[Out]# 26  421  167    3   11  2018-08-20         8   1.15
#[Out]# 27  433  169   32    5  2018-08-20         7   0.40
#[Out]# 28  434  169    1    4  2018-08-20         3   1.10
#[Out]# 29  441  171   56    3  2018-08-20         1   1.50
#[Out]# 30  442  171   44   21  2018-08-20         2   2.35
#[Out]# 31  446  175   16   21  2018-08-20         2   2.25
#[Out]# 32  453  177   47   18  2018-08-20         1   8.85
#[Out]# 33  777  184    0    0  2018-08-20         2   3.50
#[Out]# 34  778  185   62   29  2018-08-20         1   1.00
#[Out]# 35  780  188   62   30  2018-08-20         1   1.00
#[Out]# 36  791  190    7   22  2018-08-20         4   3.20
#[Out]# 37  799  190   15   21  2018-08-20         2   3.10
#[Out]# 38  809  190   25    5  2018-08-20         2   1.75
#[Out]# 39  818  190   34   28  2018-08-20         4   2.80
# Wed, 09 Dec 2020 11:00:50
query4_4 = '''
    select *
    from purchase
    where date='2018-08-20'
    group by cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price
#[Out]# 0     1    1   23   14  2018-08-20         2   4.65
#[Out]# 1    77   24   11   18  2018-08-20         1  11.55
#[Out]# 2   201   72    7   20  2018-08-20         5   2.10
#[Out]# 3   219   82   13   13  2018-08-20         4   4.00
#[Out]# 4   268  100   50   15  2018-08-20         2   1.30
#[Out]# 5   285  109   38    9  2018-08-20         5   1.50
#[Out]# 6   307  118   38   28  2018-08-20         5   6.95
#[Out]# 7   340  129   17   20  2018-08-20         7   2.40
#[Out]# 8   369  152   14   21  2018-08-20         1   1.85
#[Out]# 9   418  167   18   19  2018-08-20         1   2.25
#[Out]# 10  433  169   32    5  2018-08-20         7   0.40
#[Out]# 11  441  171   56    3  2018-08-20         1   1.50
#[Out]# 12  446  175   16   21  2018-08-20         2   2.25
#[Out]# 13  453  177   47   18  2018-08-20         1   8.85
#[Out]# 14  777  184    0    0  2018-08-20         2   3.50
#[Out]# 15  778  185   62   29  2018-08-20         1   1.00
#[Out]# 16  780  188   62   30  2018-08-20         1   1.00
#[Out]# 17  791  190    7   22  2018-08-20         4   3.20
# Wed, 09 Dec 2020 11:01:04
query4_4 = '''
    select *
    from purchase
    where date='2018-08-20'
;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price
#[Out]# 0     1    1   23   14  2018-08-20         2   4.65
#[Out]# 1     2    1    3   16  2018-08-20         3   1.60
#[Out]# 2     3    1   17    9  2018-08-20         2   1.25
#[Out]# 3     4    1   32   25  2018-08-20         4   3.95
#[Out]# 4     5    1   16   26  2018-08-20         4   2.75
#[Out]# 5    77   24   11   18  2018-08-20         1  11.55
#[Out]# 6    78   24   17    5  2018-08-20         7   0.55
#[Out]# 7    79   24   45   10  2018-08-20         1   0.60
#[Out]# 8    80   24   49    7  2018-08-20         4   2.05
#[Out]# 9    81   24   14    0  2018-08-20         3   4.80
#[Out]# 10   82   24   36    6  2018-08-20         3   1.15
#[Out]# 11  201   72    7   20  2018-08-20         5   2.10
#[Out]# 12  219   82   13   13  2018-08-20         4   4.00
#[Out]# 13  268  100   50   15  2018-08-20         2   1.30
#[Out]# 14  274  100   47   23  2018-08-20         8   2.55
#[Out]# 15  285  109   38    9  2018-08-20         5   1.50
#[Out]# 16  286  109   44    6  2018-08-20         4   1.05
#[Out]# 17  307  118   38   28  2018-08-20         5   6.95
#[Out]# 18  340  129   17   20  2018-08-20         7   2.40
#[Out]# 19  341  129   24    5  2018-08-20         7   0.45
#[Out]# 20  342  129   55   15  2018-08-20         7   1.40
#[Out]# 21  369  152   14   21  2018-08-20         1   1.85
#[Out]# 22  370  152   42   20  2018-08-20         5   2.00
#[Out]# 23  418  167   18   19  2018-08-20         1   2.25
#[Out]# 24  419  167   40   26  2018-08-20         9   3.00
#[Out]# 25  420  167   56    7  2018-08-20         1   2.10
#[Out]# 26  421  167    3   11  2018-08-20         8   1.15
#[Out]# 27  433  169   32    5  2018-08-20         7   0.40
#[Out]# 28  434  169    1    4  2018-08-20         3   1.10
#[Out]# 29  441  171   56    3  2018-08-20         1   1.50
#[Out]# 30  442  171   44   21  2018-08-20         2   2.35
#[Out]# 31  446  175   16   21  2018-08-20         2   2.25
#[Out]# 32  453  177   47   18  2018-08-20         1   8.85
#[Out]# 33  777  184    0    0  2018-08-20         2   3.50
#[Out]# 34  778  185   62   29  2018-08-20         1   1.00
#[Out]# 35  780  188   62   30  2018-08-20         1   1.00
#[Out]# 36  791  190    7   22  2018-08-20         4   3.20
#[Out]# 37  799  190   15   21  2018-08-20         2   3.10
#[Out]# 38  809  190   25    5  2018-08-20         2   1.75
#[Out]# 39  818  190   34   28  2018-08-20         4   2.80
# Wed, 09 Dec 2020 11:01:20
query4_4 = '''
    select *
    from purchase
    where date='2018-08-20'
    group by cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price
#[Out]# 0     1    1   23   14  2018-08-20         2   4.65
#[Out]# 1    77   24   11   18  2018-08-20         1  11.55
#[Out]# 2   201   72    7   20  2018-08-20         5   2.10
#[Out]# 3   219   82   13   13  2018-08-20         4   4.00
#[Out]# 4   268  100   50   15  2018-08-20         2   1.30
#[Out]# 5   285  109   38    9  2018-08-20         5   1.50
#[Out]# 6   307  118   38   28  2018-08-20         5   6.95
#[Out]# 7   340  129   17   20  2018-08-20         7   2.40
#[Out]# 8   369  152   14   21  2018-08-20         1   1.85
#[Out]# 9   418  167   18   19  2018-08-20         1   2.25
#[Out]# 10  433  169   32    5  2018-08-20         7   0.40
#[Out]# 11  441  171   56    3  2018-08-20         1   1.50
#[Out]# 12  446  175   16   21  2018-08-20         2   2.25
#[Out]# 13  453  177   47   18  2018-08-20         1   8.85
#[Out]# 14  777  184    0    0  2018-08-20         2   3.50
#[Out]# 15  778  185   62   29  2018-08-20         1   1.00
#[Out]# 16  780  188   62   30  2018-08-20         1   1.00
#[Out]# 17  791  190    7   22  2018-08-20         4   3.20
# Wed, 09 Dec 2020 11:02:01
query4_4 = '''
    select *
    from purchase
    where date='2018-08-20'
    order by cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price
#[Out]# 0     1    1   23   14  2018-08-20         2   4.65
#[Out]# 1     2    1    3   16  2018-08-20         3   1.60
#[Out]# 2     3    1   17    9  2018-08-20         2   1.25
#[Out]# 3     4    1   32   25  2018-08-20         4   3.95
#[Out]# 4     5    1   16   26  2018-08-20         4   2.75
#[Out]# 5    77   24   11   18  2018-08-20         1  11.55
#[Out]# 6    78   24   17    5  2018-08-20         7   0.55
#[Out]# 7    79   24   45   10  2018-08-20         1   0.60
#[Out]# 8    80   24   49    7  2018-08-20         4   2.05
#[Out]# 9    81   24   14    0  2018-08-20         3   4.80
#[Out]# 10   82   24   36    6  2018-08-20         3   1.15
#[Out]# 11  201   72    7   20  2018-08-20         5   2.10
#[Out]# 12  219   82   13   13  2018-08-20         4   4.00
#[Out]# 13  268  100   50   15  2018-08-20         2   1.30
#[Out]# 14  274  100   47   23  2018-08-20         8   2.55
#[Out]# 15  285  109   38    9  2018-08-20         5   1.50
#[Out]# 16  286  109   44    6  2018-08-20         4   1.05
#[Out]# 17  307  118   38   28  2018-08-20         5   6.95
#[Out]# 18  340  129   17   20  2018-08-20         7   2.40
#[Out]# 19  341  129   24    5  2018-08-20         7   0.45
#[Out]# 20  342  129   55   15  2018-08-20         7   1.40
#[Out]# 21  369  152   14   21  2018-08-20         1   1.85
#[Out]# 22  370  152   42   20  2018-08-20         5   2.00
#[Out]# 23  418  167   18   19  2018-08-20         1   2.25
#[Out]# 24  419  167   40   26  2018-08-20         9   3.00
#[Out]# 25  420  167   56    7  2018-08-20         1   2.10
#[Out]# 26  421  167    3   11  2018-08-20         8   1.15
#[Out]# 27  433  169   32    5  2018-08-20         7   0.40
#[Out]# 28  434  169    1    4  2018-08-20         3   1.10
#[Out]# 29  441  171   56    3  2018-08-20         1   1.50
#[Out]# 30  442  171   44   21  2018-08-20         2   2.35
#[Out]# 31  446  175   16   21  2018-08-20         2   2.25
#[Out]# 32  453  177   47   18  2018-08-20         1   8.85
#[Out]# 33  777  184    0    0  2018-08-20         2   3.50
#[Out]# 34  778  185   62   29  2018-08-20         1   1.00
#[Out]# 35  780  188   62   30  2018-08-20         1   1.00
#[Out]# 36  791  190    7   22  2018-08-20         4   3.20
#[Out]# 37  799  190   15   21  2018-08-20         2   3.10
#[Out]# 38  809  190   25    5  2018-08-20         2   1.75
#[Out]# 39  818  190   34   28  2018-08-20         4   2.80
# Wed, 09 Dec 2020 11:03:10
query4_4 = '''
    select cID, price
    from purchase
    where date='2018-08-20'
    group by cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID  price
#[Out]# 0     1   4.65
#[Out]# 1    24  11.55
#[Out]# 2    72   2.10
#[Out]# 3    82   4.00
#[Out]# 4   100   1.30
#[Out]# 5   109   1.50
#[Out]# 6   118   6.95
#[Out]# 7   129   2.40
#[Out]# 8   152   1.85
#[Out]# 9   167   2.25
#[Out]# 10  169   0.40
#[Out]# 11  171   1.50
#[Out]# 12  175   2.25
#[Out]# 13  177   8.85
#[Out]# 14  184   3.50
#[Out]# 15  185   1.00
#[Out]# 16  188   1.00
#[Out]# 17  190   3.20
# Wed, 09 Dec 2020 11:03:26
query4_4 = '''
    select *
    from purchase
    where date='2018-08-20'
    order by cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price
#[Out]# 0     1    1   23   14  2018-08-20         2   4.65
#[Out]# 1     2    1    3   16  2018-08-20         3   1.60
#[Out]# 2     3    1   17    9  2018-08-20         2   1.25
#[Out]# 3     4    1   32   25  2018-08-20         4   3.95
#[Out]# 4     5    1   16   26  2018-08-20         4   2.75
#[Out]# 5    77   24   11   18  2018-08-20         1  11.55
#[Out]# 6    78   24   17    5  2018-08-20         7   0.55
#[Out]# 7    79   24   45   10  2018-08-20         1   0.60
#[Out]# 8    80   24   49    7  2018-08-20         4   2.05
#[Out]# 9    81   24   14    0  2018-08-20         3   4.80
#[Out]# 10   82   24   36    6  2018-08-20         3   1.15
#[Out]# 11  201   72    7   20  2018-08-20         5   2.10
#[Out]# 12  219   82   13   13  2018-08-20         4   4.00
#[Out]# 13  268  100   50   15  2018-08-20         2   1.30
#[Out]# 14  274  100   47   23  2018-08-20         8   2.55
#[Out]# 15  285  109   38    9  2018-08-20         5   1.50
#[Out]# 16  286  109   44    6  2018-08-20         4   1.05
#[Out]# 17  307  118   38   28  2018-08-20         5   6.95
#[Out]# 18  340  129   17   20  2018-08-20         7   2.40
#[Out]# 19  341  129   24    5  2018-08-20         7   0.45
#[Out]# 20  342  129   55   15  2018-08-20         7   1.40
#[Out]# 21  369  152   14   21  2018-08-20         1   1.85
#[Out]# 22  370  152   42   20  2018-08-20         5   2.00
#[Out]# 23  418  167   18   19  2018-08-20         1   2.25
#[Out]# 24  419  167   40   26  2018-08-20         9   3.00
#[Out]# 25  420  167   56    7  2018-08-20         1   2.10
#[Out]# 26  421  167    3   11  2018-08-20         8   1.15
#[Out]# 27  433  169   32    5  2018-08-20         7   0.40
#[Out]# 28  434  169    1    4  2018-08-20         3   1.10
#[Out]# 29  441  171   56    3  2018-08-20         1   1.50
#[Out]# 30  442  171   44   21  2018-08-20         2   2.35
#[Out]# 31  446  175   16   21  2018-08-20         2   2.25
#[Out]# 32  453  177   47   18  2018-08-20         1   8.85
#[Out]# 33  777  184    0    0  2018-08-20         2   3.50
#[Out]# 34  778  185   62   29  2018-08-20         1   1.00
#[Out]# 35  780  188   62   30  2018-08-20         1   1.00
#[Out]# 36  791  190    7   22  2018-08-20         4   3.20
#[Out]# 37  799  190   15   21  2018-08-20         2   3.10
#[Out]# 38  809  190   25    5  2018-08-20         2   1.75
#[Out]# 39  818  190   34   28  2018-08-20         4   2.80
# Wed, 09 Dec 2020 11:04:12
query4_4 = '''
    select sum(price)
    from purchase
    where date='2018-08-20'
    group by cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     sum(price)
#[Out]# 0        14.20
#[Out]# 1        20.70
#[Out]# 2         2.10
#[Out]# 3         4.00
#[Out]# 4         3.85
#[Out]# 5         2.55
#[Out]# 6         6.95
#[Out]# 7         4.25
#[Out]# 8         3.85
#[Out]# 9         8.50
#[Out]# 10        1.50
#[Out]# 11        3.85
#[Out]# 12        2.25
#[Out]# 13        8.85
#[Out]# 14        3.50
#[Out]# 15        1.00
#[Out]# 16        1.00
#[Out]# 17       10.85
# Wed, 09 Dec 2020 11:04:21
query4_4 = '''
    select cID,sum(price)
    from purchase
    where date='2018-08-20'
    group by cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID  sum(price)
#[Out]# 0     1       14.20
#[Out]# 1    24       20.70
#[Out]# 2    72        2.10
#[Out]# 3    82        4.00
#[Out]# 4   100        3.85
#[Out]# 5   109        2.55
#[Out]# 6   118        6.95
#[Out]# 7   129        4.25
#[Out]# 8   152        3.85
#[Out]# 9   167        8.50
#[Out]# 10  169        1.50
#[Out]# 11  171        3.85
#[Out]# 12  175        2.25
#[Out]# 13  177        8.85
#[Out]# 14  184        3.50
#[Out]# 15  185        1.00
#[Out]# 16  188        1.00
#[Out]# 17  190       10.85
# Wed, 09 Dec 2020 11:04:54
query4_4 = '''
    select cID,max(sum(price))
    from purchase
    where date='2018-08-20'
    group by cID;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:05:01
query4_4 = '''
    select cID,sum(price)
    from purchase
    where date='2018-08-20'
    group by cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID  sum(price)
#[Out]# 0     1       14.20
#[Out]# 1    24       20.70
#[Out]# 2    72        2.10
#[Out]# 3    82        4.00
#[Out]# 4   100        3.85
#[Out]# 5   109        2.55
#[Out]# 6   118        6.95
#[Out]# 7   129        4.25
#[Out]# 8   152        3.85
#[Out]# 9   167        8.50
#[Out]# 10  169        1.50
#[Out]# 11  171        3.85
#[Out]# 12  175        2.25
#[Out]# 13  177        8.85
#[Out]# 14  184        3.50
#[Out]# 15  185        1.00
#[Out]# 16  188        1.00
#[Out]# 17  190       10.85
# Wed, 09 Dec 2020 11:06:05
query4_4 = '''

select max(sum(price))
from(
    select cID,sum(price)
    from purchase
    where date='2018-08-20'
    group by cID
)
    ;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:06:16
query4_4 = '''

select max(*)
from(
    select cID,sum(price)
    from purchase
    where date='2018-08-20'
    group by cID
)
    ;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:07:50
query4_4 = '''

with sum(price) as
    select cID,sum(price)
    from purchase
    where date='2018-08-20'
    group by cID
)
select max(sum(price))
from sum
    ;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:07:58
query4_4 = '''

with sum(price) as
    select cID,sum(price)
    from purchase
    where date='2018-08-20'
    group by cID
)
select max(*)
from sum
    ;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:08:08
query4_4 = '''

with sum(price) as
    select cID,sum(price)
    from purchase
    where date='2018-08-20'
    group by cID
)
select max(price)
from sum
    ;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:08:54
query4_4 = '''

with sum(price) as
    select cID,sum(price)
    from purchase
    where date='2018-08-20'
    group by cID
)
select *
from sum
    
    ;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:12:30
query4_5 = '''
    select cID
    from customer
    where exists(
        select cID
        from purchase
    )
    and city='Eindhoven';
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     7
#[Out]# 1    12
#[Out]# 2    16
#[Out]# 3    22
#[Out]# 4    26
#[Out]# 5    36
#[Out]# 6    38
#[Out]# 7    39
#[Out]# 8    46
#[Out]# 9    51
#[Out]# 10   78
#[Out]# 11   82
#[Out]# 12   86
#[Out]# 13   88
#[Out]# 14   91
#[Out]# 15   95
#[Out]# 16   96
#[Out]# 17  120
#[Out]# 18  125
#[Out]# 19  143
#[Out]# 20  148
#[Out]# 21  149
#[Out]# 22  153
#[Out]# 23  155
#[Out]# 24  166
#[Out]# 25  170
#[Out]# 26  174
#[Out]# 27  175
#[Out]# 28  181
#[Out]# 29  182
#[Out]# 30  184
#[Out]# 31  185
#[Out]# 32  186
# Wed, 09 Dec 2020 11:18:20
query4_5 = '''
    select cID
    from customer
    where exists(
        select cID
        from purchase p, store s
        where p.sID = s.ID
        and s.city ='Eindhoven'
    )
    ;
'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 11:18:27
query4_5 = '''
    select cID
    from customer
    where exists(
        select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    )
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# 5      5
#[Out]# 6      6
#[Out]# 7      7
#[Out]# 8      8
#[Out]# 9      9
#[Out]# 10    10
#[Out]# 11    11
#[Out]# 12    12
#[Out]# 13    13
#[Out]# 14    14
#[Out]# 15    15
#[Out]# 16    16
#[Out]# 17    17
#[Out]# 18    18
#[Out]# 19    19
#[Out]# 20    20
#[Out]# 21    21
#[Out]# 22    22
#[Out]# 23    23
#[Out]# 24    24
#[Out]# 25    25
#[Out]# 26    26
#[Out]# 27    27
#[Out]# 28    28
#[Out]# 29    29
#[Out]# ..   ...
#[Out]# 160  160
#[Out]# 161  161
#[Out]# 162  162
#[Out]# 163  163
#[Out]# 164  164
#[Out]# 165  165
#[Out]# 166  166
#[Out]# 167  167
#[Out]# 168  168
#[Out]# 169  169
#[Out]# 170  170
#[Out]# 171  171
#[Out]# 172  172
#[Out]# 173  173
#[Out]# 174  174
#[Out]# 175  175
#[Out]# 176  176
#[Out]# 177  177
#[Out]# 178  178
#[Out]# 179  179
#[Out]# 180  180
#[Out]# 181  181
#[Out]# 182  182
#[Out]# 183  183
#[Out]# 184  184
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Wed, 09 Dec 2020 11:19:36
query4_5 = '''
    select *
    from customer
    
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID     cName                street       city
#[Out]# 0      0      Noah             Koestraat    Utrecht
#[Out]# 1      1       Sem      Rozemarijnstraat      Breda
#[Out]# 2      2     Lucas      Oude Leliestraat  Amsterdam
#[Out]# 3      3      Finn         Stationsplein      Breda
#[Out]# 4      4      Daan          Kalverstraat  Amsterdam
#[Out]# 5      5      Levi        Gasthuisstraat    Utrecht
#[Out]# 6      6     Milan           Parallelweg    Utrecht
#[Out]# 7      7      Bram          Schoolstraat  Eindhoven
#[Out]# 8      8      Liam         Rijsbergseweg      Breda
#[Out]# 9      9    Thomas           Parallelweg  Amsterdam
#[Out]# 10    10       Sam           Langestraat    Tilburg
#[Out]# 11    11     Thijs             Koestraat    Tilburg
#[Out]# 12    12      Adam           Nieuwstraat  Eindhoven
#[Out]# 13    13     James       Sint Annastraat      Breda
#[Out]# 14    14       Max             Eikenlaan    Tilburg
#[Out]# 15    15      Noud          Koningshoeve    Tilburg
#[Out]# 16    16    Julian  Prins Bernhardstraat  Eindhoven
#[Out]# 17    17       Dex          Kasteeldreef    Tilburg
#[Out]# 18    18      Hugo          Kasteeldreef    Tilburg
#[Out]# 19    19      Lars         Rijsbergseweg      Breda
#[Out]# 20    20      Gijs            Heiligeweg  Amsterdam
#[Out]# 21    21  Benjamin           Stationsweg    Tilburg
#[Out]# 22    22      Mats           Molenstraat  Eindhoven
#[Out]# 23    23       Jan       Sint Annastraat      Breda
#[Out]# 24    24      Luca          Kasteeldreef    Tilburg
#[Out]# 25    25     Mason          Keizerstraat  Rotterdam
#[Out]# 26    26    Jayden          Schoolstraat  Eindhoven
#[Out]# 27    27       Tim             Koestraat    Utrecht
#[Out]# 28    28      Siem           Langestraat    Tilburg
#[Out]# 29    29     Ruben              Hofplein  Rotterdam
#[Out]# ..   ...       ...                   ...        ...
#[Out]# 160  160      Lara           Langestraat    Tilburg
#[Out]# 161  161     Floor             Eikenlaan    Tilburg
#[Out]# 162  162     Elena            Bergselaan  Rotterdam
#[Out]# 163  163      Cato          Kastanjelaan    Tilburg
#[Out]# 164  164       Evy      Rozemarijnstraat      Breda
#[Out]# 165  165     Hanna             Eikenlaan    Tilburg
#[Out]# 166  166   Rosalie           Stationsweg  Eindhoven
#[Out]# 167  167    Veerle        Ginnekenstraat      Breda
#[Out]# 168  168      Kiki          Keizerstraat  Rotterdam
#[Out]# 169  169      Lily        Gasthuisstraat    Utrecht
#[Out]# 170  170      Iris          Kastanjelaan  Eindhoven
#[Out]# 171  171     Tessa           Haringvliet  Rotterdam
#[Out]# 172  172      Lana             Eikenlaan    Tilburg
#[Out]# 173  173     Livia      Vierwindenstraat      Breda
#[Out]# 174  174      Romy           Parallelweg  Eindhoven
#[Out]# 175  175       Sam             Bredalaan  Eindhoven
#[Out]# 176  176     Amira           Parallelweg  Amsterdam
#[Out]# 177  177     Eline          Kalverstraat  Amsterdam
#[Out]# 178  178      Elif           Parallelweg    Utrecht
#[Out]# 179  179      Juul        Wilhelminapark    Tilburg
#[Out]# 180  180     Merel          Kalverstraat  Amsterdam
#[Out]# 181  181      Liva           Fredriklaan  Eindhoven
#[Out]# 182  182   Johanna         Beatrixstraat  Eindhoven
#[Out]# 183  183     Nikki         Julianastraat    Utrecht
#[Out]# 184  184     Wilko          Onbekendeweg  Eindhoven
#[Out]# 185  185      Nick                Verweg  Eindhoven
#[Out]# 186  186    Angela              Dichtweg  Eindhoven
#[Out]# 187  188      Pino            Maanstraat  Rotterdam
#[Out]# 188  189      Koen              Akkerweg        Oss
#[Out]# 189  190    Kostas              Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Wed, 09 Dec 2020 11:19:56
query4_5 = '''
    select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# 5      4
#[Out]# 6      4
#[Out]# 7      5
#[Out]# 8      5
#[Out]# 9      5
#[Out]# 10     7
#[Out]# 11    13
#[Out]# 12    13
#[Out]# 13    13
#[Out]# 14    13
#[Out]# 15    13
#[Out]# 16    13
#[Out]# 17    16
#[Out]# 18    24
#[Out]# 19    24
#[Out]# 20    25
#[Out]# 21    27
#[Out]# 22    30
#[Out]# 23    30
#[Out]# 24    31
#[Out]# 25    33
#[Out]# 26    33
#[Out]# 27    33
#[Out]# 28    33
#[Out]# 29    33
#[Out]# ..   ...
#[Out]# 103  169
#[Out]# 104  170
#[Out]# 105  171
#[Out]# 106  176
#[Out]# 107  176
#[Out]# 108  176
#[Out]# 109  178
#[Out]# 110  179
#[Out]# 111  180
#[Out]# 112  182
#[Out]# 113  182
#[Out]# 114  185
#[Out]# 115  186
#[Out]# 116  188
#[Out]# 117  188
#[Out]# 118  190
#[Out]# 119  190
#[Out]# 120  190
#[Out]# 121  190
#[Out]# 122  190
#[Out]# 123  190
#[Out]# 124  190
#[Out]# 125  190
#[Out]# 126  190
#[Out]# 127  190
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Wed, 09 Dec 2020 11:21:30
query4_5 = '''
    select cID
        from purchase p, store s
        where p.sID = s.sID
        and p.city ='Eindhoven'
    ;
'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 11:21:45
query4_5 = '''
    select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# 5      4
#[Out]# 6      4
#[Out]# 7      5
#[Out]# 8      5
#[Out]# 9      5
#[Out]# 10     7
#[Out]# 11    13
#[Out]# 12    13
#[Out]# 13    13
#[Out]# 14    13
#[Out]# 15    13
#[Out]# 16    13
#[Out]# 17    16
#[Out]# 18    24
#[Out]# 19    24
#[Out]# 20    25
#[Out]# 21    27
#[Out]# 22    30
#[Out]# 23    30
#[Out]# 24    31
#[Out]# 25    33
#[Out]# 26    33
#[Out]# 27    33
#[Out]# 28    33
#[Out]# 29    33
#[Out]# ..   ...
#[Out]# 103  169
#[Out]# 104  170
#[Out]# 105  171
#[Out]# 106  176
#[Out]# 107  176
#[Out]# 108  176
#[Out]# 109  178
#[Out]# 110  179
#[Out]# 111  180
#[Out]# 112  182
#[Out]# 113  182
#[Out]# 114  185
#[Out]# 115  186
#[Out]# 116  188
#[Out]# 117  188
#[Out]# 118  190
#[Out]# 119  190
#[Out]# 120  190
#[Out]# 121  190
#[Out]# 122  190
#[Out]# 123  190
#[Out]# 124  190
#[Out]# 125  190
#[Out]# 126  190
#[Out]# 127  190
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Wed, 09 Dec 2020 11:23:03
query4_5 = '''
    select cID
    from customer
    where exists(
        select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    )
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# 5      5
#[Out]# 6      6
#[Out]# 7      7
#[Out]# 8      8
#[Out]# 9      9
#[Out]# 10    10
#[Out]# 11    11
#[Out]# 12    12
#[Out]# 13    13
#[Out]# 14    14
#[Out]# 15    15
#[Out]# 16    16
#[Out]# 17    17
#[Out]# 18    18
#[Out]# 19    19
#[Out]# 20    20
#[Out]# 21    21
#[Out]# 22    22
#[Out]# 23    23
#[Out]# 24    24
#[Out]# 25    25
#[Out]# 26    26
#[Out]# 27    27
#[Out]# 28    28
#[Out]# 29    29
#[Out]# ..   ...
#[Out]# 160  160
#[Out]# 161  161
#[Out]# 162  162
#[Out]# 163  163
#[Out]# 164  164
#[Out]# 165  165
#[Out]# 166  166
#[Out]# 167  167
#[Out]# 168  168
#[Out]# 169  169
#[Out]# 170  170
#[Out]# 171  171
#[Out]# 172  172
#[Out]# 173  173
#[Out]# 174  174
#[Out]# 175  175
#[Out]# 176  176
#[Out]# 177  177
#[Out]# 178  178
#[Out]# 179  179
#[Out]# 180  180
#[Out]# 181  181
#[Out]# 182  182
#[Out]# 183  183
#[Out]# 184  184
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Wed, 09 Dec 2020 11:25:57
query4_5 = '''
    select cID
    from customer
    where not exists(
        select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    )
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:26:20
query4_5 = '''
    select *
        from customer
    
        
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID     cName                street       city
#[Out]# 0      0      Noah             Koestraat    Utrecht
#[Out]# 1      1       Sem      Rozemarijnstraat      Breda
#[Out]# 2      2     Lucas      Oude Leliestraat  Amsterdam
#[Out]# 3      3      Finn         Stationsplein      Breda
#[Out]# 4      4      Daan          Kalverstraat  Amsterdam
#[Out]# 5      5      Levi        Gasthuisstraat    Utrecht
#[Out]# 6      6     Milan           Parallelweg    Utrecht
#[Out]# 7      7      Bram          Schoolstraat  Eindhoven
#[Out]# 8      8      Liam         Rijsbergseweg      Breda
#[Out]# 9      9    Thomas           Parallelweg  Amsterdam
#[Out]# 10    10       Sam           Langestraat    Tilburg
#[Out]# 11    11     Thijs             Koestraat    Tilburg
#[Out]# 12    12      Adam           Nieuwstraat  Eindhoven
#[Out]# 13    13     James       Sint Annastraat      Breda
#[Out]# 14    14       Max             Eikenlaan    Tilburg
#[Out]# 15    15      Noud          Koningshoeve    Tilburg
#[Out]# 16    16    Julian  Prins Bernhardstraat  Eindhoven
#[Out]# 17    17       Dex          Kasteeldreef    Tilburg
#[Out]# 18    18      Hugo          Kasteeldreef    Tilburg
#[Out]# 19    19      Lars         Rijsbergseweg      Breda
#[Out]# 20    20      Gijs            Heiligeweg  Amsterdam
#[Out]# 21    21  Benjamin           Stationsweg    Tilburg
#[Out]# 22    22      Mats           Molenstraat  Eindhoven
#[Out]# 23    23       Jan       Sint Annastraat      Breda
#[Out]# 24    24      Luca          Kasteeldreef    Tilburg
#[Out]# 25    25     Mason          Keizerstraat  Rotterdam
#[Out]# 26    26    Jayden          Schoolstraat  Eindhoven
#[Out]# 27    27       Tim             Koestraat    Utrecht
#[Out]# 28    28      Siem           Langestraat    Tilburg
#[Out]# 29    29     Ruben              Hofplein  Rotterdam
#[Out]# ..   ...       ...                   ...        ...
#[Out]# 160  160      Lara           Langestraat    Tilburg
#[Out]# 161  161     Floor             Eikenlaan    Tilburg
#[Out]# 162  162     Elena            Bergselaan  Rotterdam
#[Out]# 163  163      Cato          Kastanjelaan    Tilburg
#[Out]# 164  164       Evy      Rozemarijnstraat      Breda
#[Out]# 165  165     Hanna             Eikenlaan    Tilburg
#[Out]# 166  166   Rosalie           Stationsweg  Eindhoven
#[Out]# 167  167    Veerle        Ginnekenstraat      Breda
#[Out]# 168  168      Kiki          Keizerstraat  Rotterdam
#[Out]# 169  169      Lily        Gasthuisstraat    Utrecht
#[Out]# 170  170      Iris          Kastanjelaan  Eindhoven
#[Out]# 171  171     Tessa           Haringvliet  Rotterdam
#[Out]# 172  172      Lana             Eikenlaan    Tilburg
#[Out]# 173  173     Livia      Vierwindenstraat      Breda
#[Out]# 174  174      Romy           Parallelweg  Eindhoven
#[Out]# 175  175       Sam             Bredalaan  Eindhoven
#[Out]# 176  176     Amira           Parallelweg  Amsterdam
#[Out]# 177  177     Eline          Kalverstraat  Amsterdam
#[Out]# 178  178      Elif           Parallelweg    Utrecht
#[Out]# 179  179      Juul        Wilhelminapark    Tilburg
#[Out]# 180  180     Merel          Kalverstraat  Amsterdam
#[Out]# 181  181      Liva           Fredriklaan  Eindhoven
#[Out]# 182  182   Johanna         Beatrixstraat  Eindhoven
#[Out]# 183  183     Nikki         Julianastraat    Utrecht
#[Out]# 184  184     Wilko          Onbekendeweg  Eindhoven
#[Out]# 185  185      Nick                Verweg  Eindhoven
#[Out]# 186  186    Angela              Dichtweg  Eindhoven
#[Out]# 187  188      Pino            Maanstraat  Rotterdam
#[Out]# 188  189      Koen              Akkerweg        Oss
#[Out]# 189  190    Kostas              Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Wed, 09 Dec 2020 11:26:41
query4_5 = '''
    select count(city)
        from customer
    
        
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    count(city)
#[Out]# 0          190
# Wed, 09 Dec 2020 11:27:04
query4_5 = '''
    select city,count(city)
        from customer
        group by city
    
        
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(city)
#[Out]# 0  Amsterdam           26
#[Out]# 1      Breda           27
#[Out]# 2  Eindhoven           33
#[Out]# 3        Oss            1
#[Out]# 4  Rotterdam           29
#[Out]# 5    Tilburg           38
#[Out]# 6    Utrecht           36
# Wed, 09 Dec 2020 11:27:22
query4_5 = '''
    select city
        from customer
        group by city
    
        
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 11:27:42
query4_5 = '''
    select cID
        from customer
        where city is null
    
    
        
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:28:17
query4_5 = '''
    select *
        from customer
        where city is null    
        
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, street, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:29:31
query4_5 = '''
    select city, count(cID)
    from customer
    where not exists(
        select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    )
    group by city
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, count(cID)]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:29:41
query4_5 = '''
    select city, count(cID)
    from customer
    where exists(
        select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    )
    group by city
    ;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Wed, 09 Dec 2020 12:33:15
query4_4 = '''


select *
from purchase
    
    ;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15
#[Out]# 17    17    4   10   27  2018-08-24         9   9.05
#[Out]# 18    18    4   53   12  2018-08-25         5  13.60
#[Out]# 19    19    4   21    6  2018-08-24         2   1.05
#[Out]# 20    20    4    7   13  2018-08-25         9   3.05
#[Out]# 21    21    4   44   26  2018-08-25         4   2.75
#[Out]# 22    22    5    4   14  2018-08-17         6   4.70
#[Out]# 23    23    5   36   28  2018-08-22         6   8.25
#[Out]# 24    24    5   55    6  2018-08-23         9   1.10
#[Out]# 25    25    5   51   22  2018-08-23         2   1.55
#[Out]# 26    26    5    6   16  2018-08-23         2   1.85
#[Out]# 27    27    5   17   19  2018-08-23         1   2.20
#[Out]# 28    28    7    3   19  2018-08-23         2   2.10
#[Out]# 29    29    7   12    2  2018-08-23         6   1.70
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 479  818  190   34   28  2018-08-20         4   2.80
#[Out]# 480  819  190   35   27  2018-08-15         5   0.50
#[Out]# 481  820  190   36    5  2018-08-23         3   2.55
#[Out]# 482  821  190   37   28  2018-08-15         4   0.65
#[Out]# 483  822  190   38    7  2018-08-24         4   0.70
#[Out]# 484  823  190   39    0  2018-08-25         4   3.70
#[Out]# 485  824  190   40   11  2018-08-15         2   3.50
#[Out]# 486  825  190   41    6  2018-08-15         5   2.95
#[Out]# 487  826  190   42   19  2018-08-22         5   2.75
#[Out]# 488  827  190   43   17  2018-08-17         7   1.50
#[Out]# 489  828  190   44    9  2018-08-18         5   0.85
#[Out]# 490  829  190   45   11  2018-08-19         2   3.55
#[Out]# 491  830  190   46   22  2018-08-25         4   2.60
#[Out]# 492  831  190   47   17  2018-08-17         4   3.25
#[Out]# 493  832  190   48   20  2018-08-26         6   4.30
#[Out]# 494  833  190   49   11  2018-08-17         3   3.05
#[Out]# 495  834  190   50   21  2018-08-22         6   4.05
#[Out]# 496  835  190   51   23  2018-08-19         1   1.50
#[Out]# 497  836  190   52   23  2018-08-15         5   2.50
#[Out]# 498  837  190   53    8  2018-08-18         4   3.95
#[Out]# 499  838  190   54    0  2018-08-25         6   3.50
#[Out]# 500  839  190   55    8  2018-08-18         7   2.95
#[Out]# 501  840  190   56   11  2018-08-15         4   1.60
#[Out]# 502  841  190   57   15  2018-08-22         5   3.25
#[Out]# 503  842  190   58    2  2018-08-19         7   0.75
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Wed, 09 Dec 2020 12:34:06
query4_4 = '''

select cID,sum(price)
    from purchase
    group by date
    
    ;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID  sum(price)
#[Out]# 0    21       59.65
#[Out]# 1     2       88.25
#[Out]# 2     2      139.15
#[Out]# 3     3      126.40
#[Out]# 4     3      121.55
#[Out]# 5     1      103.75
#[Out]# 6     1       80.40
#[Out]# 7     0      115.80
#[Out]# 8     5      127.25
#[Out]# 9     4      167.50
#[Out]# 10    4      167.65
#[Out]# 11    7      217.20
#[Out]# 12   10      100.65
#[Out]# 13   22       47.10
#[Out]# 14   39       11.90
#[Out]# 15  188        1.00
# Wed, 09 Dec 2020 12:34:22
query4_4 = '''

select cID,date,sum(price)
    from purchase
    group by date
    
    ;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID        date  sum(price)
#[Out]# 0    21  2018-08-15       59.65
#[Out]# 1     2  2018-08-16       88.25
#[Out]# 2     2  2018-08-17      139.15
#[Out]# 3     3  2018-08-18      126.40
#[Out]# 4     3  2018-08-19      121.55
#[Out]# 5     1  2018-08-20      103.75
#[Out]# 6     1  2018-08-21       80.40
#[Out]# 7     0  2018-08-22      115.80
#[Out]# 8     5  2018-08-23      127.25
#[Out]# 9     4  2018-08-24      167.50
#[Out]# 10    4  2018-08-25      167.65
#[Out]# 11    7  2018-08-26      217.20
#[Out]# 12   10  2018-08-27      100.65
#[Out]# 13   22  2018-08-28       47.10
#[Out]# 14   39  2018-08-29       11.90
#[Out]# 15  188  2018-09-20        1.00
# Wed, 09 Dec 2020 12:36:26
query4_4 = '''

select *
    from purchase
    where cID=1

    
    ;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    tID  cID  sID  pID        date  quantity  price
#[Out]# 0    1    1   23   14  2018-08-20         2   4.65
#[Out]# 1    2    1    3   16  2018-08-20         3   1.60
#[Out]# 2    3    1   17    9  2018-08-20         2   1.25
#[Out]# 3    4    1   32   25  2018-08-20         4   3.95
#[Out]# 4    5    1   16   26  2018-08-20         4   2.75
#[Out]# 5    6    1   46   11  2018-08-21         8   0.90
#[Out]# 6    7    1   36   27  2018-08-21         6   9.10
# Wed, 09 Dec 2020 12:37:32
query4_4 = '''

select cID,date,sum(price)
    from purchase
    group by cID, date
    
    ;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sum(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# 5      3  2018-08-18        4.30
#[Out]# 6      3  2018-08-19        4.20
#[Out]# 7      4  2018-08-24       14.25
#[Out]# 8      4  2018-08-25       19.40
#[Out]# 9      5  2018-08-17        4.70
#[Out]# 10     5  2018-08-22        8.25
#[Out]# 11     5  2018-08-23        6.70
#[Out]# 12     7  2018-08-23        3.80
#[Out]# 13     7  2018-08-24        1.90
#[Out]# 14     7  2018-08-25       10.75
#[Out]# 15     7  2018-08-26        3.10
#[Out]# 16     8  2018-08-16        6.25
#[Out]# 17    10  2018-08-27        3.20
#[Out]# 18    11  2018-08-25        4.10
#[Out]# 19    13  2018-08-17       13.30
#[Out]# 20    13  2018-08-25        6.50
#[Out]# 21    13  2018-08-26        1.65
#[Out]# 22    13  2018-08-27        0.50
#[Out]# 23    15  2018-08-27        0.90
#[Out]# 24    16  2018-08-18        2.90
#[Out]# 25    16  2018-08-19       11.05
#[Out]# 26    16  2018-08-24        6.05
#[Out]# 27    16  2018-08-25        4.95
#[Out]# 28    16  2018-08-26        3.00
#[Out]# 29    16  2018-08-27        1.85
#[Out]# ..   ...         ...         ...
#[Out]# 255  178  2018-08-27        7.50
#[Out]# 256  179  2018-08-22       10.85
#[Out]# 257  179  2018-08-23        0.45
#[Out]# 258  179  2018-08-24        6.95
#[Out]# 259  180  2018-08-26        3.10
#[Out]# 260  180  2018-08-27        4.65
#[Out]# 261  181  2018-08-24        3.60
#[Out]# 262  181  2018-08-27        2.00
#[Out]# 263  182  2018-08-23        4.20
#[Out]# 264  182  2018-08-28       14.90
#[Out]# 265  184  2018-08-20        3.50
#[Out]# 266  185  2018-08-20        1.00
#[Out]# 267  186  2018-08-21        1.00
#[Out]# 268  188  2018-08-20        1.00
#[Out]# 269  188  2018-09-20        1.00
#[Out]# 270  189  2018-08-25        1.25
#[Out]# 271  189  2018-08-26        2.50
#[Out]# 272  190  2018-08-15       19.60
#[Out]# 273  190  2018-08-16       12.80
#[Out]# 274  190  2018-08-17       15.75
#[Out]# 275  190  2018-08-18       14.85
#[Out]# 276  190  2018-08-19       20.30
#[Out]# 277  190  2018-08-20       10.85
#[Out]# 278  190  2018-08-21        3.85
#[Out]# 279  190  2018-08-22       14.55
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:39:20
query4_4 = '''

with total_amount(price) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
)

    
    ;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:39:58
query4_4 = '''

with total_amount(price) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
);
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:40:25
query4_4 = '''

with customer_store(city) as(
    select city from customer
    union 
    select city from store)


'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:41:39
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
)

select date, max(amount)
from total_amount
group by date


'''

pd.read_sql_query(query4_4, conn)
#[Out]#           date  max(amount)
#[Out]# 0   2018-08-15        23.95
#[Out]# 1   2018-08-16        15.85
#[Out]# 2   2018-08-17        20.20
#[Out]# 3   2018-08-18        14.85
#[Out]# 4   2018-08-19        20.30
#[Out]# 5   2018-08-20        20.70
#[Out]# 6   2018-08-21        15.55
#[Out]# 7   2018-08-22        18.35
#[Out]# 8   2018-08-23        21.30
#[Out]# 9   2018-08-24        22.25
#[Out]# 10  2018-08-25        19.40
#[Out]# 11  2018-08-26        39.10
#[Out]# 12  2018-08-27        16.75
#[Out]# 13  2018-08-28        14.90
#[Out]# 14  2018-08-29        11.90
#[Out]# 15  2018-09-20         1.00
# Wed, 09 Dec 2020 12:45:28
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
)

with maxium(date,amount) as(
select date, max(amount)
from total_amount
group by date
)


select cID
from total_amount
where amount >= 0.75*max(amount);


'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:46:18
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
)

with maximum(date,amount) as(
select date, max(amount)
from total_amount
group by date
)


select t.cID
from total_amount t, maximum m
where t.amount >= m.0.75*max(amount);


'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:47:14
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
)
select * from total_amount





'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  amount
#[Out]# 0      0  2018-08-22    0.45
#[Out]# 1      1  2018-08-20   14.20
#[Out]# 2      1  2018-08-21   10.00
#[Out]# 3      2  2018-08-16    2.45
#[Out]# 4      2  2018-08-17    7.70
#[Out]# 5      3  2018-08-18    4.30
#[Out]# 6      3  2018-08-19    4.20
#[Out]# 7      4  2018-08-24   14.25
#[Out]# 8      4  2018-08-25   19.40
#[Out]# 9      5  2018-08-17    4.70
#[Out]# 10     5  2018-08-22    8.25
#[Out]# 11     5  2018-08-23    6.70
#[Out]# 12     7  2018-08-23    3.80
#[Out]# 13     7  2018-08-24    1.90
#[Out]# 14     7  2018-08-25   10.75
#[Out]# 15     7  2018-08-26    3.10
#[Out]# 16     8  2018-08-16    6.25
#[Out]# 17    10  2018-08-27    3.20
#[Out]# 18    11  2018-08-25    4.10
#[Out]# 19    13  2018-08-17   13.30
#[Out]# 20    13  2018-08-25    6.50
#[Out]# 21    13  2018-08-26    1.65
#[Out]# 22    13  2018-08-27    0.50
#[Out]# 23    15  2018-08-27    0.90
#[Out]# 24    16  2018-08-18    2.90
#[Out]# 25    16  2018-08-19   11.05
#[Out]# 26    16  2018-08-24    6.05
#[Out]# 27    16  2018-08-25    4.95
#[Out]# 28    16  2018-08-26    3.00
#[Out]# 29    16  2018-08-27    1.85
#[Out]# ..   ...         ...     ...
#[Out]# 255  178  2018-08-27    7.50
#[Out]# 256  179  2018-08-22   10.85
#[Out]# 257  179  2018-08-23    0.45
#[Out]# 258  179  2018-08-24    6.95
#[Out]# 259  180  2018-08-26    3.10
#[Out]# 260  180  2018-08-27    4.65
#[Out]# 261  181  2018-08-24    3.60
#[Out]# 262  181  2018-08-27    2.00
#[Out]# 263  182  2018-08-23    4.20
#[Out]# 264  182  2018-08-28   14.90
#[Out]# 265  184  2018-08-20    3.50
#[Out]# 266  185  2018-08-20    1.00
#[Out]# 267  186  2018-08-21    1.00
#[Out]# 268  188  2018-08-20    1.00
#[Out]# 269  188  2018-09-20    1.00
#[Out]# 270  189  2018-08-25    1.25
#[Out]# 271  189  2018-08-26    2.50
#[Out]# 272  190  2018-08-15   19.60
#[Out]# 273  190  2018-08-16   12.80
#[Out]# 274  190  2018-08-17   15.75
#[Out]# 275  190  2018-08-18   14.85
#[Out]# 276  190  2018-08-19   20.30
#[Out]# 277  190  2018-08-20   10.85
#[Out]# 278  190  2018-08-21    3.85
#[Out]# 279  190  2018-08-22   14.55
#[Out]# 280  190  2018-08-23   10.60
#[Out]# 281  190  2018-08-24    3.25
#[Out]# 282  190  2018-08-25    9.80
#[Out]# 283  190  2018-08-26   21.90
#[Out]# 284  190  2018-08-27    5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:47:54
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
)
with maximum(date,amount) as(
    select date, max(amount)
    from total_amount
    group by date
)
select t.cID
from total_amount t, maximum m
where t.amount >= 0.75*m.amount;





'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:49:11
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
)
with maximum(date,amount) as(
    select date, max(amount)
    from (select cID,date,sum(price)
    from purchase
    group by cID, date)
    group by date
)
select t.cID
from total_amount t, maximum m
where t.amount >= 0.75*m.amount;

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:49:28
query4_4 = '''

with maximum(date,amount) as(
    select date, max(amount)
    from (select cID,date,sum(price)
    from purchase
    group by cID, date)
    group by date
)
select t.cID
from total_amount t, maximum m
where t.amount >= 0.75*m.amount;

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:51:29
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
)
with maximum(date,amount) as(
    select date, max(amount)
    from(
        select cID,date,sum(price)
        from purchase
        group by cID, date
    )
    group by date
)
select t.cID
from total_amount t, maximum m
where t.amount >= 0.75*m.amount;

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:52:12
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
),
maximum(date,amount) as(
    select date, max(amount)
    from(
        select cID,date,sum(price)
        from purchase
        group by cID, date
    )
    group by date
)
select t.cID
from total_amount t, maximum m
where t.amount >= 0.75*m.amount;

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:54:09
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
),
maximum(date, amount) as(
    select date, max(amount)
    from(
        select cID,date,sum(price) as amount
        from purchase
        group by cID, date
    )
    group by date
)
select t.cID
from total_amount t, maximum m
where t.amount >= 0.75*m.amount;

'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# 5      1
#[Out]# 6      1
#[Out]# 7      1
#[Out]# 8      1
#[Out]# 9      1
#[Out]# 10     2
#[Out]# 11     2
#[Out]# 12     3
#[Out]# 13     3
#[Out]# 14     4
#[Out]# 15     4
#[Out]# 16     4
#[Out]# 17     4
#[Out]# 18     4
#[Out]# 19     4
#[Out]# 20     4
#[Out]# 21     4
#[Out]# 22     4
#[Out]# 23     4
#[Out]# 24     4
#[Out]# 25     4
#[Out]# 26     4
#[Out]# 27     4
#[Out]# 28     4
#[Out]# 29     4
#[Out]# ..   ...
#[Out]# 646  190
#[Out]# 647  190
#[Out]# 648  190
#[Out]# 649  190
#[Out]# 650  190
#[Out]# 651  190
#[Out]# 652  190
#[Out]# 653  190
#[Out]# 654  190
#[Out]# 655  190
#[Out]# 656  190
#[Out]# 657  190
#[Out]# 658  190
#[Out]# 659  190
#[Out]# 660  190
#[Out]# 661  190
#[Out]# 662  190
#[Out]# 663  190
#[Out]# 664  190
#[Out]# 665  190
#[Out]# 666  190
#[Out]# 667  190
#[Out]# 668  190
#[Out]# 669  190
#[Out]# 670  190
#[Out]# 671  190
#[Out]# 672  190
#[Out]# 673  190
#[Out]# 674  190
#[Out]# 675  190
#[Out]# 
#[Out]# [676 rows x 1 columns]
# Wed, 09 Dec 2020 12:54:55
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
),
maximum(date, amount) as(
    select date, max(amount)
    from total_amount
    group by date
)

select t.cID
from total_amount t, maximum m
where t.amount >= 0.75*m.amount;

'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# 5      1
#[Out]# 6      1
#[Out]# 7      1
#[Out]# 8      1
#[Out]# 9      1
#[Out]# 10     2
#[Out]# 11     2
#[Out]# 12     3
#[Out]# 13     3
#[Out]# 14     4
#[Out]# 15     4
#[Out]# 16     4
#[Out]# 17     4
#[Out]# 18     4
#[Out]# 19     4
#[Out]# 20     4
#[Out]# 21     4
#[Out]# 22     4
#[Out]# 23     4
#[Out]# 24     4
#[Out]# 25     4
#[Out]# 26     4
#[Out]# 27     4
#[Out]# 28     4
#[Out]# 29     4
#[Out]# ..   ...
#[Out]# 646  190
#[Out]# 647  190
#[Out]# 648  190
#[Out]# 649  190
#[Out]# 650  190
#[Out]# 651  190
#[Out]# 652  190
#[Out]# 653  190
#[Out]# 654  190
#[Out]# 655  190
#[Out]# 656  190
#[Out]# 657  190
#[Out]# 658  190
#[Out]# 659  190
#[Out]# 660  190
#[Out]# 661  190
#[Out]# 662  190
#[Out]# 663  190
#[Out]# 664  190
#[Out]# 665  190
#[Out]# 666  190
#[Out]# 667  190
#[Out]# 668  190
#[Out]# 669  190
#[Out]# 670  190
#[Out]# 671  190
#[Out]# 672  190
#[Out]# 673  190
#[Out]# 674  190
#[Out]# 675  190
#[Out]# 
#[Out]# [676 rows x 1 columns]
# Wed, 09 Dec 2020 12:55:39
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
),
maximum(date, amount) as(
    select date, max(amount)
    from total_amount
    group by date
)

select t.cID
from total_amount t, maximum m
where t.amount >= 0.75*m.amount
and t.date = m.date;

'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID
#[Out]# 0     4
#[Out]# 1    20
#[Out]# 2    24
#[Out]# 3    30
#[Out]# 4    33
#[Out]# 5    35
#[Out]# 6    39
#[Out]# 7    39
#[Out]# 8    51
#[Out]# 9    52
#[Out]# 10   71
#[Out]# 11   82
#[Out]# 12  108
#[Out]# 13  109
#[Out]# 14  113
#[Out]# 15  123
#[Out]# 16  161
#[Out]# 17  162
#[Out]# 18  170
#[Out]# 19  182
#[Out]# 20  188
#[Out]# 21  190
#[Out]# 22  190
#[Out]# 23  190
#[Out]# 24  190
#[Out]# 25  190
#[Out]# 26  190
# Wed, 09 Dec 2020 12:57:03
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
),
maximum(date, amount) as(
    select date, max(amount)
    from total_amount
    group by date
)

select t.cID, t.date
from total_amount t, maximum m
where t.amount >= 0.75*m.amount
and t.date = m.date;

'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID        date
#[Out]# 0     4  2018-08-25
#[Out]# 1    20  2018-08-18
#[Out]# 2    24  2018-08-20
#[Out]# 3    30  2018-08-18
#[Out]# 4    33  2018-08-27
#[Out]# 5    35  2018-08-18
#[Out]# 6    39  2018-08-28
#[Out]# 7    39  2018-08-29
#[Out]# 8    51  2018-08-19
#[Out]# 9    52  2018-08-25
#[Out]# 10   71  2018-08-24
#[Out]# 11   82  2018-08-23
#[Out]# 12  108  2018-08-15
#[Out]# 13  109  2018-08-18
#[Out]# 14  113  2018-08-21
#[Out]# 15  123  2018-08-17
#[Out]# 16  161  2018-08-26
#[Out]# 17  162  2018-08-22
#[Out]# 18  170  2018-08-16
#[Out]# 19  182  2018-08-28
#[Out]# 20  188  2018-09-20
#[Out]# 21  190  2018-08-15
#[Out]# 22  190  2018-08-16
#[Out]# 23  190  2018-08-17
#[Out]# 24  190  2018-08-18
#[Out]# 25  190  2018-08-19
#[Out]# 26  190  2018-08-22
# Wed, 09 Dec 2020 12:57:27
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
),
maximum(date, amount) as(
    select date, max(amount)
    from total_amount
    group by date
)

select distinct t.cID
from total_amount t, maximum m
where t.amount >= 0.75*m.amount
and t.date = m.date;

'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID
#[Out]# 0     4
#[Out]# 1    20
#[Out]# 2    24
#[Out]# 3    30
#[Out]# 4    33
#[Out]# 5    35
#[Out]# 6    39
#[Out]# 7    51
#[Out]# 8    52
#[Out]# 9    71
#[Out]# 10   82
#[Out]# 11  108
#[Out]# 12  109
#[Out]# 13  113
#[Out]# 14  123
#[Out]# 15  161
#[Out]# 16  162
#[Out]# 17  170
#[Out]# 18  182
#[Out]# 19  188
#[Out]# 20  190
# Wed, 09 Dec 2020 12:58:13
query4_4 = '''
with total_amount(cID, date, amount) as(
    select cID,date,sum(price)
    from purchase
    group by cID, date
),
maximum(date, amount) as(
    select date, max(amount)
    from total_amount
    group by date
)
select cName
from customer
where cID in(
    select distinct t.cID
    from total_amount t, maximum m
    where t.amount >= 0.75*m.amount
    and t.date = m.date)

'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Gijs
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5     Stijn
#[Out]# 6      Jack
#[Out]# 7      Ties
#[Out]# 8    Willem
#[Out]# 9      Dean
#[Out]# 10    Dylan
#[Out]# 11     Noor
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Milou
#[Out]# 15    Floor
#[Out]# 16    Elena
#[Out]# 17     Iris
#[Out]# 18  Johanna
#[Out]# 19     Pino
#[Out]# 20   Kostas
# Wed, 09 Dec 2020 12:59:31
query4_5 = '''

    select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    
    
    
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# 5      4
#[Out]# 6      4
#[Out]# 7      5
#[Out]# 8      5
#[Out]# 9      5
#[Out]# 10     7
#[Out]# 11    13
#[Out]# 12    13
#[Out]# 13    13
#[Out]# 14    13
#[Out]# 15    13
#[Out]# 16    13
#[Out]# 17    16
#[Out]# 18    24
#[Out]# 19    24
#[Out]# 20    25
#[Out]# 21    27
#[Out]# 22    30
#[Out]# 23    30
#[Out]# 24    31
#[Out]# 25    33
#[Out]# 26    33
#[Out]# 27    33
#[Out]# 28    33
#[Out]# 29    33
#[Out]# ..   ...
#[Out]# 103  169
#[Out]# 104  170
#[Out]# 105  171
#[Out]# 106  176
#[Out]# 107  176
#[Out]# 108  176
#[Out]# 109  178
#[Out]# 110  179
#[Out]# 111  180
#[Out]# 112  182
#[Out]# 113  182
#[Out]# 114  185
#[Out]# 115  186
#[Out]# 116  188
#[Out]# 117  188
#[Out]# 118  190
#[Out]# 119  190
#[Out]# 120  190
#[Out]# 121  190
#[Out]# 122  190
#[Out]# 123  190
#[Out]# 124  190
#[Out]# 125  190
#[Out]# 126  190
#[Out]# 127  190
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Wed, 09 Dec 2020 13:00:33
query4_5 = '''
    select city, count(cID)
    from customer
    where exists(
        select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    )
    group by city
    ;   
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Wed, 09 Dec 2020 13:19:31
query4_5 = '''

    select distinct cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# 5     7
#[Out]# 6    13
#[Out]# 7    16
#[Out]# 8    24
#[Out]# 9    25
#[Out]# 10   27
#[Out]# 11   30
#[Out]# 12   31
#[Out]# 13   33
#[Out]# 14   38
#[Out]# 15   39
#[Out]# 16   40
#[Out]# 17   41
#[Out]# 18   45
#[Out]# 19   51
#[Out]# 20   59
#[Out]# 21   60
#[Out]# 22   70
#[Out]# 23   71
#[Out]# 24   72
#[Out]# 25   75
#[Out]# 26   78
#[Out]# 27   80
#[Out]# 28   82
#[Out]# 29   85
#[Out]# ..  ...
#[Out]# 39  111
#[Out]# 40  116
#[Out]# 41  122
#[Out]# 42  123
#[Out]# 43  124
#[Out]# 44  126
#[Out]# 45  129
#[Out]# 46  134
#[Out]# 47  136
#[Out]# 48  147
#[Out]# 49  149
#[Out]# 50  157
#[Out]# 51  159
#[Out]# 52  161
#[Out]# 53  162
#[Out]# 54  163
#[Out]# 55  165
#[Out]# 56  167
#[Out]# 57  169
#[Out]# 58  170
#[Out]# 59  171
#[Out]# 60  176
#[Out]# 61  178
#[Out]# 62  179
#[Out]# 63  180
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Wed, 09 Dec 2020 13:20:47
query4_5 = '''
    select city, cID
    from customer
    where cID in(
        select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    )
    group by city
    ;   
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  cID
#[Out]# 0  Amsterdam    2
#[Out]# 1      Breda    1
#[Out]# 2  Eindhoven    7
#[Out]# 3  Rotterdam   25
#[Out]# 4    Tilburg   24
#[Out]# 5    Utrecht    5
# Wed, 09 Dec 2020 13:21:54
query4_5 = '''
    select city, count(cID)
    from customer
    where cID in(
        select cID
        from purchase p, store s
        where p.sID = s.sID
        and s.city ='Eindhoven'
    )
    group by city
    ;   
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(cID)
#[Out]# 0  Amsterdam          10
#[Out]# 1      Breda           9
#[Out]# 2  Eindhoven          15
#[Out]# 3  Rotterdam          13
#[Out]# 4    Tilburg          10
#[Out]# 5    Utrecht          12

# IPython log file

# Tue, 08 Dec 2020 11:14:15
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 11:14:16
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1d7db83dab0>
# Tue, 08 Dec 2020 11:20:33
query4_3 = '''SELECT sName, city
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 11:24:02
query4_3 = '''SELECT s.city c.city FROM customer c store s
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 11:24:25
query4_3 = SELECT s.city c.city FROM customer c store s

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 11:27:08
query4_3 = SELECTY city FROM customer UNION SELECT city FROM store

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 11:27:36
query4_3 = ''''SELECTY city FROM customer UNION SELECT city FROM store''''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 11:27:54
query4_3 = '''SELECTY city FROM customer UNION SELECT city FROM store'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 11:29:28
query4_3 = '''SELECT city FROM customer UNION SELECT city FROM store'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 11:37:42
query4_3 = '''SELECT sx.sName, sx,city FROM store as sx WHERE NOT EXISTS (SELECT s.city FROM store s EXCEPT SELECT city FROM (SELECT city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID)'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 11:38:28
query4_3 = '''SELECT sx.sName, sx.city FROM store as sx WHERE NOT EXISTS (
        SELECT s.city FROM store s
        EXCEPT
        SELECT city FROM (SELECT city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID
)'''
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 11:39:52
query4_3 = '''SELECT sx.sName, sx.city FROM store as sx WHERE NOT EXISTS (SELECT s.city FROM store s EXCEPT SELECT city FROM (SELECT city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID)'''
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 11:43:33
query4_4 = '''SELECT price FROM purchase
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.45
#[Out]# 1     4.65
#[Out]# 2     1.60
#[Out]# 3     1.25
#[Out]# 4     3.95
#[Out]# ..     ...
#[Out]# 504   3.80
#[Out]# 505   4.35
#[Out]# 506   2.85
#[Out]# 507   3.15
#[Out]# 508   3.30
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Tue, 08 Dec 2020 11:44:20
query4_4 = '''SELECT price cID FROM purchase
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cID
#[Out]# 0    0.45
#[Out]# 1    4.65
#[Out]# 2    1.60
#[Out]# 3    1.25
#[Out]# 4    3.95
#[Out]# ..    ...
#[Out]# 504  3.80
#[Out]# 505  4.35
#[Out]# 506  2.85
#[Out]# 507  3.15
#[Out]# 508  3.30
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Tue, 08 Dec 2020 11:44:35
query4_4 = '''SELECT price, cID FROM purchase
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price  cID
#[Out]# 0     0.45    0
#[Out]# 1     4.65    1
#[Out]# 2     1.60    1
#[Out]# 3     1.25    1
#[Out]# 4     3.95    1
#[Out]# ..     ...  ...
#[Out]# 504   3.80  190
#[Out]# 505   4.35  190
#[Out]# 506   2.85  190
#[Out]# 507   3.15  190
#[Out]# 508   3.30  190
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Tue, 08 Dec 2020 11:45:11
query4_4 = '''SELECT price, cID, date FROM purchase
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price  cID        date
#[Out]# 0     0.45    0  2018-08-22
#[Out]# 1     4.65    1  2018-08-20
#[Out]# 2     1.60    1  2018-08-20
#[Out]# 3     1.25    1  2018-08-20
#[Out]# 4     3.95    1  2018-08-20
#[Out]# ..     ...  ...         ...
#[Out]# 504   3.80  190  2018-08-26
#[Out]# 505   4.35  190  2018-08-27
#[Out]# 506   2.85  190  2018-08-23
#[Out]# 507   3.15  190  2018-08-16
#[Out]# 508   3.30  190  2018-08-21
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 08 Dec 2020 11:46:04
query4_4 = '''SELECT price, cID, date FROM purchase GROUP BY cID AND date SUM (price)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:46:30
query4_4 = '''SELECT price, cID, date, SUM (price) FROM purchase GROUP BY cID AND date 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price  cID        date  SUM (price)
#[Out]# 0   0.45    0  2018-08-22         0.45
#[Out]# 1   4.65    1  2018-08-20      1674.75
# Tue, 08 Dec 2020 11:47:21
query4_4 = '''SELECT price, cID, date, SUM (price) FROM purchase GROUP BY cID GROUP BY date 
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:47:33
query4_4 = '''SELECT price, cID, date, SUM (price) FROM purchase GROUP BY cIDC, date 
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:47:44
query4_4 = '''SELECT price, cID, date, SUM (price) FROM purchase GROUP BY cID, date 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price  cID        date  SUM (price)
#[Out]# 0     0.45    0  2018-08-22         0.45
#[Out]# 1     4.65    1  2018-08-20        14.20
#[Out]# 2     0.90    1  2018-08-21        10.00
#[Out]# 3     2.45    2  2018-08-16         2.45
#[Out]# 4     1.35    2  2018-08-17         7.70
#[Out]# ..     ...  ...         ...          ...
#[Out]# 280   0.50  190  2018-08-23        10.60
#[Out]# 281   2.55  190  2018-08-24         3.25
#[Out]# 282   3.70  190  2018-08-25         9.80
#[Out]# 283   1.30  190  2018-08-26        21.90
#[Out]# 284   1.20  190  2018-08-27         5.55
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Tue, 08 Dec 2020 11:48:43
query4_4 = '''SELECT price, cID, date, SUM(price) FROM purchase GROUP BY cID, date ORDER BY SUM(price) DESC
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price  cID        date  SUM(price)
#[Out]# 0     2.15  161  2018-08-26       39.10
#[Out]# 1     1.10  124  2018-08-26       28.80
#[Out]# 2     1.70  108  2018-08-15       23.95
#[Out]# 3     4.50   71  2018-08-24       22.25
#[Out]# 4     1.30  190  2018-08-26       21.90
#[Out]# ..     ...  ...         ...         ...
#[Out]# 280   0.45    0  2018-08-22        0.45
#[Out]# 281   0.45   22  2018-08-28        0.45
#[Out]# 282   0.45   77  2018-08-23        0.45
#[Out]# 283   0.45  179  2018-08-23        0.45
#[Out]# 284   0.40   72  2018-08-21        0.40
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Tue, 08 Dec 2020 11:52:53
query4_4 = '''WITH max_price AS (SELECT SUM(price) as price FROM purchase GROUP BY cID, date ORDER BY price DESC LIMIT 1)
SELECT .75 * price as price FROM max_price
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     price
#[Out]# 0  29.325
# Tue, 08 Dec 2020 11:55:34
query4_4 = '''SELECT cName FROM CUSTOMER (WITH max_price AS (SELECT SUM(price)
FROM purchase 
GROUP BY tID, date 
ORDER BY price DESC LIMIT 1)
SELECT .75 * price as price FROM max_price)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:55:44
query4_4 = '''SELECT cName FROM CUSTOMER (WITH max_price AS (SELECT SUM(price)
FROM purchase 
GROUP BY cID, date 
ORDER BY price DESC LIMIT 1)
SELECT .75 * price as price FROM max_price)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:55:57
query4_4 = '''SELECT cName FROM CUSTOMER (WITH max_price AS (SELECT SUM(price) as price
FROM purchase 
GROUP BY cID, date 
ORDER BY price DESC LIMIT 1)
SELECT .75 * price as price FROM max_price)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:56:26
query4_4 = '''SELECT price, cID, date, SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price  cID        date  SUM(price)
#[Out]# 0     2.15  161  2018-08-26       39.10
#[Out]# 1     1.10  124  2018-08-26       28.80
#[Out]# 2     1.70  108  2018-08-15       23.95
#[Out]# 3     4.50   71  2018-08-24       22.25
#[Out]# 4     1.30  190  2018-08-26       21.90
#[Out]# ..     ...  ...         ...         ...
#[Out]# 280   0.45    0  2018-08-22        0.45
#[Out]# 281   0.45   22  2018-08-28        0.45
#[Out]# 282   0.45   77  2018-08-23        0.45
#[Out]# 283   0.45  179  2018-08-23        0.45
#[Out]# 284   0.40   72  2018-08-21        0.40
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Tue, 08 Dec 2020 11:57:45
query4_4 = '''WITH max_price AS .75 *(SELECT price, cID, date, SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:58:02
query4_4 = '''(SELECT price, cID, date, SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:58:10
query4_4 = '''SELECT price, cID, date, SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price  cID        date  SUM(price)
#[Out]# 0   2.15  161  2018-08-26        39.1
# Tue, 08 Dec 2020 11:58:59
query4_4 = '''0.75 * (SELECT price, cID, date, SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:59:17
query4_4 = '''(SELECT price, cID, date, 0.75 * SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:59:35
query4_4 = '''(SELECT price, cID, date, SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 11:59:43
query4_4 = '''SELECT price, cID, date, SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price  cID        date  SUM(price)
#[Out]# 0   2.15  161  2018-08-26        39.1
# Tue, 08 Dec 2020 11:59:56
query4_4 = '''SELECT price, cID, date, 0 .75 * SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 12:00:01
query4_4 = '''SELECT price, cID, date, 0.75 * SUM(price) 
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price  cID        date  0.75 * SUM(price)
#[Out]# 0   2.15  161  2018-08-26             29.325
# Tue, 08 Dec 2020 12:00:27
query4_4 = '''SELECT price, cID, date, 0.75 * SUM(price) as 3/4 max price
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 12:00:37
query4_4 = '''SELECT price, cID, date, 0.75 * SUM(price) as "3/4 max price"
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price  cID        date  3/4 max price
#[Out]# 0   2.15  161  2018-08-26         29.325
# Tue, 08 Dec 2020 12:02:21
query4_4 = '''SELECT c.cName, p.price, p.cID, p.date, 0.75 * SUM(p.price) as "3/4 max price"
FROM purchase p, customer c
GROUP BY p.cID, p.date 
ORDER BY SUM(p.price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#   cName  price  cID        date  3/4 max price
#[Out]# 0  Noah   2.15  161  2018-08-26        5571.75
# Tue, 08 Dec 2020 12:04:01
query4_4 = '''SELECT c.cName, p.price, p.cID, p.date, 0.75 * SUM(p.price) as "3/4 max price"
FROM purchase p, customer c
GROUP BY p.cID, p.date SUM(p.price)
ORDER BY SUM(p.price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 12:04:42
query4_4 = '''SELECT price, cID, date, 0.75 * SUM(price) as "3/4 max price"
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price  cID        date  3/4 max price
#[Out]# 0   2.15  161  2018-08-26         29.325
# Tue, 08 Dec 2020 12:06:06
query4_4 = '''SELECT price, cID, date, 0.75 * SUM(price) as "3/4 max price"
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price  cID        date  3/4 max price
#[Out]# 0   2.15  161  2018-08-26         29.325
# Tue, 08 Dec 2020 12:13:19
query4_4 = '''SELECT c.cName, SUM(p.price) FROM  customer c, purchase p
GROUP BY cID, date
WHERE SUM(p.price) >= maxprise
WITH maxprice as (SELECT price, cID, date, 0.75 * SUM(price) as "3/4 max price"
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 12:16:35
query4_4 = '''SELECT price, cID, date, 0.75 * SUM(price) as "3/4 max price"
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price  cID        date  3/4 max price
#[Out]# 0   2.15  161  2018-08-26         29.325
# Tue, 08 Dec 2020 12:17:04
query4_4 = '''SELECT price, cID, date, 0.75 * SUM(price) as "3/4 max price"
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price  cID        date  3/4 max price
#[Out]# 0     2.15  161  2018-08-26        29.3250
#[Out]# 1     1.10  124  2018-08-26        21.6000
#[Out]# 2     1.70  108  2018-08-15        17.9625
#[Out]# 3     4.50   71  2018-08-24        16.6875
#[Out]# 4     1.30  190  2018-08-26        16.4250
#[Out]# ..     ...  ...         ...            ...
#[Out]# 280   0.45    0  2018-08-22         0.3375
#[Out]# 281   0.45   22  2018-08-28         0.3375
#[Out]# 282   0.45   77  2018-08-23         0.3375
#[Out]# 283   0.45  179  2018-08-23         0.3375
#[Out]# 284   0.40   72  2018-08-21         0.3000
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Tue, 08 Dec 2020 12:17:45
query4_4 = '''SELECT price, cID, date, SUM(price) as "3/4 max price"
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price  cID        date  3/4 max price
#[Out]# 0     2.15  161  2018-08-26          39.10
#[Out]# 1     1.10  124  2018-08-26          28.80
#[Out]# 2     1.70  108  2018-08-15          23.95
#[Out]# 3     4.50   71  2018-08-24          22.25
#[Out]# 4     1.30  190  2018-08-26          21.90
#[Out]# ..     ...  ...         ...            ...
#[Out]# 280   0.45    0  2018-08-22           0.45
#[Out]# 281   0.45   22  2018-08-28           0.45
#[Out]# 282   0.45   77  2018-08-23           0.45
#[Out]# 283   0.45  179  2018-08-23           0.45
#[Out]# 284   0.40   72  2018-08-21           0.40
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Tue, 08 Dec 2020 12:19:06
query4_4 = '''WITH max_price as (SELECT price, cID, date, SUM(price) as "3/4 max price"
FROM purchase 
GROUP BY cID, date 
ORDER BY SUM(price) DESC LIMIT 1)
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 12:21:17
query4_4 = '''WITH max_price AS (SELECT 0.75 * SUM(price) as price 
FROM purchase 
GROUP BY cID,date 
ORDER BY price DESC LIMIT 1) 
SELECT DISTINCT cName 
FROM customer 
WHERE cID IN (SELECT cID 
FROM (SELECT SUM(price) as price, c.cID 
FROM customer c, purchase p 
WHERE c.cID = p.cID 
GROUP BY date, c.cID) 
WHERE price >= (SELECT * FROM max_price))
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 12:26:32
query4_5 = '''SELECT city FROM store
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city
#[Out]# 0   Amsterdam
#[Out]# 1       Breda
#[Out]# 2   Rotterdam
#[Out]# 3   Rotterdam
#[Out]# 4   Eindhoven
#[Out]# ..        ...
#[Out]# 59      Breda
#[Out]# 60      Breda
#[Out]# 61      Breda
#[Out]# 62  Eindhoven
#[Out]# 63        Oss
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 08 Dec 2020 12:26:42
query4_5 = '''SELECT DISTINCT city FROM store
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Tue, 08 Dec 2020 12:27:55
query4_5 = '''SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven")
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      3    1   17    9  2018-08-20         2   1.25
#[Out]# 1      7    1   36   27  2018-08-21         6   9.10
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45
#[Out]# 3      9    2   39    9  2018-08-17         7   1.35
#[Out]# 4     14    3   30   26  2018-08-19         2   2.75
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 128  836  190   52   23  2018-08-15         5   2.50
#[Out]# 129  838  190   54    0  2018-08-25         6   3.50
#[Out]# 130  840  190   56   11  2018-08-15         4   1.60
#[Out]# 131  841  190   57   15  2018-08-22         5   3.25
#[Out]# 132  846  190   62    9  2018-08-16         2   3.15
#[Out]# 
#[Out]# [133 rows x 7 columns]
# Tue, 08 Dec 2020 12:29:21
query4_5 = '''WITH pur_Eind AS (SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:29:39
query4_5 = '''SELECT * FROM pur_EindWITH pur_Eind AS (SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:29:44
query4_5 = '''SELECT * FROM pur_Eind
WITH pur_Eind AS (SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:30:42
query4_5 = ''' WITH pur_Eind AS (SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT * FROM pur_Eind
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      3    1   17    9  2018-08-20         2   1.25
#[Out]# 1      7    1   36   27  2018-08-21         6   9.10
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45
#[Out]# 3      9    2   39    9  2018-08-17         7   1.35
#[Out]# 4     14    3   30   26  2018-08-19         2   2.75
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 128  836  190   52   23  2018-08-15         5   2.50
#[Out]# 129  838  190   54    0  2018-08-25         6   3.50
#[Out]# 130  840  190   56   11  2018-08-15         4   1.60
#[Out]# 131  841  190   57   15  2018-08-22         5   3.25
#[Out]# 132  846  190   62    9  2018-08-16         2   3.15
#[Out]# 
#[Out]# [133 rows x 7 columns]
# Tue, 08 Dec 2020 12:32:34
query4_5 = ''' WITH pur_Eind AS (SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT d.cID, c.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#        cID  cID
#[Out]# 0        1    0
#[Out]# 1        1    1
#[Out]# 2        1    2
#[Out]# 3        1    3
#[Out]# 4        1    4
#[Out]# ...    ...  ...
#[Out]# 25265  190  185
#[Out]# 25266  190  186
#[Out]# 25267  190  188
#[Out]# 25268  190  189
#[Out]# 25269  190  190
#[Out]# 
#[Out]# [25270 rows x 2 columns]
# Tue, 08 Dec 2020 12:32:45
query4_5 = ''' WITH pur_Eind AS (SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT d.cID, c.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#        cID  cID
#[Out]# 0        1    0
#[Out]# 1        1    1
#[Out]# 2        1    2
#[Out]# 3        1    3
#[Out]# 4        1    4
#[Out]# ...    ...  ...
#[Out]# 13105  190  185
#[Out]# 13106  190  186
#[Out]# 13107  190  188
#[Out]# 13108  190  189
#[Out]# 13109  190  190
#[Out]# 
#[Out]# [13110 rows x 2 columns]
# Tue, 08 Dec 2020 12:33:01
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT d.cID, c.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#        cID  cID
#[Out]# 0        1    0
#[Out]# 1        1    1
#[Out]# 2        1    2
#[Out]# 3        1    3
#[Out]# 4        1    4
#[Out]# ...    ...  ...
#[Out]# 25265  190  185
#[Out]# 25266  190  186
#[Out]# 25267  190  188
#[Out]# 25268  190  189
#[Out]# 25269  190  190
#[Out]# 
#[Out]# [25270 rows x 2 columns]
# Tue, 08 Dec 2020 12:33:18
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT * FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#        tID  cID  sID  pID        date  quantity  price  cID   cName  \
#[Out]# 0        3    1   17    9  2018-08-20         2   1.25    0    Noah   
#[Out]# 1        3    1   17    9  2018-08-20         2   1.25    1     Sem   
#[Out]# 2        3    1   17    9  2018-08-20         2   1.25    2   Lucas   
#[Out]# 3        3    1   17    9  2018-08-20         2   1.25    3    Finn   
#[Out]# 4        3    1   17    9  2018-08-20         2   1.25    4    Daan   
#[Out]# ...    ...  ...  ...  ...         ...       ...    ...  ...     ...   
#[Out]# 25265  846  190   62    9  2018-08-16         2   3.15  185    Nick   
#[Out]# 25266  846  190   62    9  2018-08-16         2   3.15  186  Angela   
#[Out]# 25267  846  190   62    9  2018-08-16         2   3.15  188    Pino   
#[Out]# 25268  846  190   62    9  2018-08-16         2   3.15  189    Koen   
#[Out]# 25269  846  190   62    9  2018-08-16         2   3.15  190  Kostas   
#[Out]# 
#[Out]#                  street       city  
#[Out]# 0             Koestraat    Utrecht  
#[Out]# 1      Rozemarijnstraat      Breda  
#[Out]# 2      Oude Leliestraat  Amsterdam  
#[Out]# 3         Stationsplein      Breda  
#[Out]# 4          Kalverstraat  Amsterdam  
#[Out]# ...                 ...        ...  
#[Out]# 25265            Verweg  Eindhoven  
#[Out]# 25266          Dichtweg  Eindhoven  
#[Out]# 25267        Maanstraat  Rotterdam  
#[Out]# 25268          Akkerweg        Oss  
#[Out]# 25269          Eindeweg    Utrecht  
#[Out]# 
#[Out]# [25270 rows x 11 columns]
# Tue, 08 Dec 2020 12:34:04
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT * FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#        tID  cID  sID  pID        date  quantity  price  cID   cName  \
#[Out]# 0        3    1   17    9  2018-08-20         2   1.25    0    Noah   
#[Out]# 1        3    1   17    9  2018-08-20         2   1.25    1     Sem   
#[Out]# 2        3    1   17    9  2018-08-20         2   1.25    2   Lucas   
#[Out]# 3        3    1   17    9  2018-08-20         2   1.25    3    Finn   
#[Out]# 4        3    1   17    9  2018-08-20         2   1.25    4    Daan   
#[Out]# ...    ...  ...  ...  ...         ...       ...    ...  ...     ...   
#[Out]# 25265  846  190   62    9  2018-08-16         2   3.15  185    Nick   
#[Out]# 25266  846  190   62    9  2018-08-16         2   3.15  186  Angela   
#[Out]# 25267  846  190   62    9  2018-08-16         2   3.15  188    Pino   
#[Out]# 25268  846  190   62    9  2018-08-16         2   3.15  189    Koen   
#[Out]# 25269  846  190   62    9  2018-08-16         2   3.15  190  Kostas   
#[Out]# 
#[Out]#                  street       city  
#[Out]# 0             Koestraat    Utrecht  
#[Out]# 1      Rozemarijnstraat      Breda  
#[Out]# 2      Oude Leliestraat  Amsterdam  
#[Out]# 3         Stationsplein      Breda  
#[Out]# 4          Kalverstraat  Amsterdam  
#[Out]# ...                 ...        ...  
#[Out]# 25265            Verweg  Eindhoven  
#[Out]# 25266          Dichtweg  Eindhoven  
#[Out]# 25267        Maanstraat  Rotterdam  
#[Out]# 25268          Akkerweg        Oss  
#[Out]# 25269          Eindeweg    Utrecht  
#[Out]# 
#[Out]# [25270 rows x 11 columns]
# Tue, 08 Dec 2020 12:34:23
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT d.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Tue, 08 Dec 2020 12:34:41
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:34:58
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT * FROM pur_Eind
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      3    1   17    9  2018-08-20         2   1.25
#[Out]# 1      7    1   36   27  2018-08-21         6   9.10
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45
#[Out]# 3      9    2   39    9  2018-08-17         7   1.35
#[Out]# 4     14    3   30   26  2018-08-19         2   2.75
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 128  836  190   52   23  2018-08-15         5   2.50
#[Out]# 129  838  190   54    0  2018-08-25         6   3.50
#[Out]# 130  840  190   56   11  2018-08-15         4   1.60
#[Out]# 131  841  190   57   15  2018-08-22         5   3.25
#[Out]# 132  846  190   62    9  2018-08-16         2   3.15
#[Out]# 
#[Out]# [133 rows x 7 columns]
# Tue, 08 Dec 2020 12:35:18
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT * FROM pur_Eind
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      3    1   17    9  2018-08-20         2   1.25
#[Out]# 1      7    1   36   27  2018-08-21         6   9.10
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45
#[Out]# 3      9    2   39    9  2018-08-17         7   1.35
#[Out]# 4     14    3   30   26  2018-08-19         2   2.75
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 128  836  190   52   23  2018-08-15         5   2.50
#[Out]# 129  838  190   54    0  2018-08-25         6   3.50
#[Out]# 130  840  190   56   11  2018-08-15         4   1.60
#[Out]# 131  841  190   57   15  2018-08-22         5   3.25
#[Out]# 132  846  190   62    9  2018-08-16         2   3.15
#[Out]# 
#[Out]# [133 rows x 7 columns]
# Tue, 08 Dec 2020 12:35:31
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT d.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Tue, 08 Dec 2020 12:36:09
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT d.cID c.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:36:13
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT d.cID c.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:36:19
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT d.cID, c.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#        cID  cID
#[Out]# 0        1    0
#[Out]# 1        1    1
#[Out]# 2        1    2
#[Out]# 3        1    3
#[Out]# 4        1    4
#[Out]# ...    ...  ...
#[Out]# 13105  190  185
#[Out]# 13106  190  186
#[Out]# 13107  190  188
#[Out]# 13108  190  189
#[Out]# 13109  190  190
#[Out]# 
#[Out]# [13110 rows x 2 columns]
# Tue, 08 Dec 2020 12:36:30
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT d.cID, DISTINCT c.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:36:35
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"))
SELECT DISTINCT d.cID, c.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#        cID  cID
#[Out]# 0        1    0
#[Out]# 1        1    1
#[Out]# 2        1    2
#[Out]# 3        1    3
#[Out]# 4        1    4
#[Out]# ...    ...  ...
#[Out]# 13105  190  185
#[Out]# 13106  190  186
#[Out]# 13107  190  188
#[Out]# 13108  190  189
#[Out]# 13109  190  190
#[Out]# 
#[Out]# [13110 rows x 2 columns]
# Tue, 08 Dec 2020 12:38:06
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID)
SELECT DISTINCT d.cID FROM pur_Eind d, customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Tue, 08 Dec 2020 12:38:58
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID)
SELECT city, COUNT(*) as nrOfPeople FROM customer WHERE cID IN pur_Eind GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:39:19
query4_5 = ''' WITH pur_Eind AS (SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID)
SELECT city, COUNT(*) as number FROM customer WHERE cID IN pur_Eind GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Tue, 08 Dec 2020 12:39:33
query4_5 = ''' WITH pur_Eind AS (SELECT DISTINCT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID)
SELECT city, COUNT(*) as number FROM customer WHERE cID IN pur_Eind GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Tue, 08 Dec 2020 12:39:39
query4_5 = ''' WITH pur_Eind AS (SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID)
SELECT city, COUNT(*) as number FROM customer WHERE cID IN pur_Eind GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Tue, 08 Dec 2020 12:47:27
query4_5 = ''' with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName, count(distinct pID)

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size <= 20);
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:47:43
query4_5 = ''' with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName, count(distinct pID)

            from store, purchase

            where sID not in (

                        select sID

                        from inventory_size

                        where size <= 20);
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:51:59
query4_5 = '''
            with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size <= 20);
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    sID  sName
#[Out]# 0   61   Lidl
#[Out]# 1   62  Jumbo
#[Out]# 2   63  Jumbo
# Tue, 08 Dec 2020 12:52:18
query4_4 = '''
            with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID in (

                        select sID

                        from inventory_size

                        where size <= 20);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 56   56      Jumbo
#[Out]# 57   57       Dirk
#[Out]# 58   58       Dirk
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 
#[Out]# [61 rows x 2 columns]
# Tue, 08 Dec 2020 12:52:45
query4_3 = '''
            with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size > 20);'''
pd.read_sql_query(query4_3, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 61   61       Lidl
#[Out]# 62   62      Jumbo
#[Out]# 63   63      Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 12:54:55
query4_5 = '''
            with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:55:43
query4_5 = '''
            with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )
            select size

            from inventory_size
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      size
#[Out]# 0       1
#[Out]# 1       3
#[Out]# 2       2
#[Out]# 3       1
#[Out]# 4       1
#[Out]# ..    ...
#[Out]# 517     1
#[Out]# 518     2
#[Out]# 519     2
#[Out]# 520     1
#[Out]# 521     1
#[Out]# 
#[Out]# [522 rows x 1 columns]
# Tue, 08 Dec 2020 12:55:53
query4_5 = '''
            with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )
            select size, sID

            from inventory_size
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      size  sID
#[Out]# 0       1    0
#[Out]# 1       3    0
#[Out]# 2       2    0
#[Out]# 3       1    0
#[Out]# 4       1    0
#[Out]# ..    ...  ...
#[Out]# 517     1   59
#[Out]# 518     2   59
#[Out]# 519     2   59
#[Out]# 520     1   59
#[Out]# 521     1   60
#[Out]# 
#[Out]# [522 rows x 2 columns]
# Tue, 08 Dec 2020 12:56:00
query4_5 = '''
            with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )
            select size, DISTINCT sID

            from inventory_size
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 12:56:08
query4_5 = '''
            with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )
            select DISTINCT size, sID

            from inventory_size
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      size  sID
#[Out]# 0       1    0
#[Out]# 1       3    0
#[Out]# 2       2    0
#[Out]# 3       4    0
#[Out]# 4       1    1
#[Out]# ..    ...  ...
#[Out]# 160     2   58
#[Out]# 161     1   59
#[Out]# 162     3   59
#[Out]# 163     2   59
#[Out]# 164     1   60
#[Out]# 
#[Out]# [165 rows x 2 columns]
# Tue, 08 Dec 2020 12:57:14
query4_5 = '''
                        select DISTINCT sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

'''

pd.read_sql_query(query4_5, conn)
#[Out]#      sID        date  count(distinct pID)
#[Out]# 0      0  2018-07-18                    1
#[Out]# 1      0  2018-08-15                    3
#[Out]# 2      0  2018-08-16                    2
#[Out]# 3      0  2018-08-17                    1
#[Out]# 4      0  2018-08-18                    1
#[Out]# ..   ...         ...                  ...
#[Out]# 517   59  2018-08-24                    1
#[Out]# 518   59  2018-08-25                    2
#[Out]# 519   59  2018-08-26                    2
#[Out]# 520   59  2018-08-27                    1
#[Out]# 521   60  2018-07-10                    1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Tue, 08 Dec 2020 12:57:22
query4_5 = '''
                        select DISTINCT sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

'''

pd.read_sql_query(query4_5, conn)
#[Out]#      sID        date  count(distinct pID)
#[Out]# 0      0  2018-07-18                    1
#[Out]# 1      0  2018-08-15                    3
#[Out]# 2      0  2018-08-16                    2
#[Out]# 3      0  2018-08-17                    1
#[Out]# 4      0  2018-08-18                    1
#[Out]# ..   ...         ...                  ...
#[Out]# 517   59  2018-08-24                    1
#[Out]# 518   59  2018-08-25                    2
#[Out]# 519   59  2018-08-26                    2
#[Out]# 520   59  2018-08-27                    1
#[Out]# 521   60  2018-07-10                    1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Tue, 08 Dec 2020 12:57:42
query4_5 = '''
                        select DISTINCT sID, date, count(distinct pID)

                        from inventory

                        group by sID, date
                        
                        order by count(distinct pID) DESC

'''

pd.read_sql_query(query4_5, conn)
#[Out]#      sID        date  count(distinct pID)
#[Out]# 0     35  2018-08-23                    5
#[Out]# 1     57  2018-08-22                    5
#[Out]# 2      0  2018-08-25                    4
#[Out]# 3      5  2018-08-23                    4
#[Out]# 4      8  2018-08-18                    4
#[Out]# ..   ...         ...                  ...
#[Out]# 517   59  2018-08-15                    1
#[Out]# 518   59  2018-08-17                    1
#[Out]# 519   59  2018-08-24                    1
#[Out]# 520   59  2018-08-27                    1
#[Out]# 521   60  2018-07-10                    1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Tue, 08 Dec 2020 12:59:46
query4_5 = '''
                        select DISTINCT sID

                        from inventory           

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID
#[Out]# 0     0
#[Out]# 1     1
#[Out]# 2     2
#[Out]# 3     3
#[Out]# 4     4
#[Out]# ..  ...
#[Out]# 56   56
#[Out]# 57   57
#[Out]# 58   58
#[Out]# 59   59
#[Out]# 60   60
#[Out]# 
#[Out]# [61 rows x 1 columns]

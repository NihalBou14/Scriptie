# IPython log file

# Tue, 08 Dec 2020 15:01:31
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 15:01:33
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1b0fe5759d0>
# Tue, 08 Dec 2020 15:26:38
query4_5 = '''
    SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
    GROUPBY c.city
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 15:26:46
query4_5 = '''
    SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count (distinct c.cID)
#[Out]# 0  Amsterdam                      10
#[Out]# 1      Breda                       9
#[Out]# 2  Eindhoven                      15
#[Out]# 3  Rotterdam                      13
#[Out]# 4    Tilburg                      10
#[Out]# 5    Utrecht                      12
# Tue, 08 Dec 2020 15:28:16
query4_4 = '''
    SELECT
    FROM
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:37:17
query4_3 = '''
    SELECT c.city
    FROM customer c
    UNION 
    SELECT s.city
    FROM store s
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 15:47:25
query4_3 = '''
    SELECT s.sName
    FROM store s
    WHERE s.city IN (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s)

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1     Hoogvliet
#[Out]# 2         Jumbo
#[Out]# 3        Sligro
#[Out]# 4     Hoogvliet
#[Out]# 5        Sligro
#[Out]# 6          Coop
#[Out]# 7        Sligro
#[Out]# 8   Albert Hein
#[Out]# 9   Albert Hein
#[Out]# 10        Jumbo
#[Out]# 11  Albert Hein
#[Out]# 12         Lidl
#[Out]# 13         Coop
#[Out]# 14         Coop
#[Out]# 15         Lidl
#[Out]# 16         Lidl
#[Out]# 17    Hoogvliet
#[Out]# 18       Sligro
#[Out]# 19         Coop
#[Out]# 20        Jumbo
#[Out]# 21         Coop
#[Out]# 22         Lidl
#[Out]# 23         Dirk
#[Out]# 24  Albert Hein
#[Out]# 25  Albert Hein
#[Out]# 26    Hoogvliet
#[Out]# 27       Sligro
#[Out]# 28    Hoogvliet
#[Out]# 29       Sligro
#[Out]# ..          ...
#[Out]# 34         Coop
#[Out]# 35         Lidl
#[Out]# 36         Lidl
#[Out]# 37        Jumbo
#[Out]# 38    Hoogvliet
#[Out]# 39       Sligro
#[Out]# 40    Hoogvliet
#[Out]# 41  Albert Hein
#[Out]# 42       Sligro
#[Out]# 43         Coop
#[Out]# 44  Albert Hein
#[Out]# 45         Coop
#[Out]# 46         Lidl
#[Out]# 47         Coop
#[Out]# 48    Hoogvliet
#[Out]# 49    Hoogvliet
#[Out]# 50       Sligro
#[Out]# 51         Coop
#[Out]# 52         Lidl
#[Out]# 53         Coop
#[Out]# 54         Dirk
#[Out]# 55         Coop
#[Out]# 56        Jumbo
#[Out]# 57         Dirk
#[Out]# 58         Dirk
#[Out]# 59        Jumbo
#[Out]# 60         Lidl
#[Out]# 61         Lidl
#[Out]# 62        Jumbo
#[Out]# 63        Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 08 Dec 2020 15:47:33
query4_3 = '''
    SELECT s.sName s.city
    FROM store s
    WHERE s.city IN (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s)

'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 15:47:49
query4_3 = '''
    SELECT s.sName, s.city
    FROM store s
    WHERE s.city IN (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s)

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 15:48:22
query4_3 = '''
    SELECT s.sName, s.city
    FROM store s
    WHERE s.city IN (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s)
    GROUP BY s.city

'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city
#[Out]# 0         Coop  Amsterdam
#[Out]# 1    Hoogvliet      Breda
#[Out]# 2    Hoogvliet  Eindhoven
#[Out]# 3        Jumbo        Oss
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5  Albert Hein    Tilburg
#[Out]# 6         Lidl    Utrecht
# Tue, 08 Dec 2020 15:48:43
query4_3 = '''
    SELECT s.sName, s.city
    FROM store s
    WHERE s.city IN (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s)
    GROUP BY s.sName

'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city
#[Out]# 0  Albert Hein  Eindhoven
#[Out]# 1         Coop  Amsterdam
#[Out]# 2         Dirk      Breda
#[Out]# 3    Hoogvliet      Breda
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5         Lidl  Eindhoven
#[Out]# 6       Sligro  Rotterdam
# Tue, 08 Dec 2020 15:48:49
query4_3 = '''
    SELECT s.sName, s.city
    FROM store s
    WHERE s.city IN (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s)

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 16:03:23
query4_3 = '''
    SELECT distinct s.sName
    FROM store s
    WHERE not exist (SELECT s.city
                    FROM store s
                    WHERE s.city NOT IN
                    (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:03:42
query4_3 = '''
    SELECT distinct s.sName
    FROM store s
    WHERE not exist (SELECT city
                    FROM store s
                    WHERE s.city NOT IN
                    (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s))
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 09:38:41
query4_5 = '''
    SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven" AND (SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven" AND c.ID is null)
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 09:38:57
query4_5 = '''
    SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven" AND (SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven" AND c.cID is null)
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 09:39:38
query4_5 = '''
    SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven" AND c.cID is null
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, count (distinct c.cID)]
#[Out]# Index: []
# Wed, 09 Dec 2020 09:40:16
query4_5 = '''
    SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven" \
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count (distinct c.cID)
#[Out]# 0  Amsterdam                      10
#[Out]# 1      Breda                       9
#[Out]# 2  Eindhoven                      15
#[Out]# 3  Rotterdam                      13
#[Out]# 4    Tilburg                      10
#[Out]# 5    Utrecht                      12
# Wed, 09 Dec 2020 11:15:41
query4_3 = '''
    SELECT distinct s.sName
    FROM store s
    WHERE not exist (SELECT city
                    FROM store s
                    WHERE s.city NOT IN
                    (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s));
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:16:01
query4_3 = '''
    SELECT distinct s.sName
    FROM store s
    WHERE not exist (SELECT s.city
                    FROM store s
                    WHERE s.city NOT IN
                    (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s));
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:17:44
query4_3 = '''
    SELECT distinct s.sName
    FROM store s
    WHERE exist (SELECT s.city
                    FROM store s
                    WHERE s.city IN
                    (SELECT c.city
                    FROM customer c
                    UNION 
                    SELECT s.city
                    FROM store s));
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:23:13
query4_5 = '''
    SELECT c.city, count (1)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count (1)
#[Out]# 0  Amsterdam         17
#[Out]# 1      Breda         27
#[Out]# 2  Eindhoven         24
#[Out]# 3  Rotterdam         16
#[Out]# 4    Tilburg         18
#[Out]# 5    Utrecht         31
# Wed, 09 Dec 2020 11:23:20
query4_5 = '''
    SELECT c.city, count (*)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count (*)
#[Out]# 0  Amsterdam         17
#[Out]# 1      Breda         27
#[Out]# 2  Eindhoven         24
#[Out]# 3  Rotterdam         16
#[Out]# 4    Tilburg         18
#[Out]# 5    Utrecht         31
# Wed, 09 Dec 2020 11:23:31
query4_5 = '''
    SELECT c.city, count (distinct cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 11:23:38
query4_5 = '''
    SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count (distinct c.cID)
#[Out]# 0  Amsterdam                      10
#[Out]# 1      Breda                       9
#[Out]# 2  Eindhoven                      15
#[Out]# 3  Rotterdam                      13
#[Out]# 4    Tilburg                      10
#[Out]# 5    Utrecht                      12
# Wed, 09 Dec 2020 11:28:42
query4_3 = '''
    WITH allstores(sName) AS (SELECT sName FROM store)
            allcities(city) AS ((SELECT city from store) UNION (SELECT city from customer))
            allpos (sName, city) AS (SELECT sName, city FROM allstores, allcities)
            actual(sName, city) AS (SELECT sName, city FROM store)
            missing (sName, city) AS (SELECT sName, city WHERE (sName, city) NOT IN (actual))
            
    SELECT sName
    FROM stores
    WHERE sName NOT IN (SELECT * FROM missing)
'''


WITH 	allstores(sName) AS (SELECT sName FROM store)
	allcities(city) AS ((SELECT city FROM store) UNION (SELECT city FROM customer))
	allpos(sName,city) AS (SELECT sName,city FROM allstores,allcities)
	actual(sName,city) AS (SELECT sName,city FROM store)
	missing(sName,city) AS (SELECT sName,city WHERE (sName,city) NOT IN (actual))
SELECT sName
FROM stores
WHERE sName NOT IN (SELECT * FROM missing)

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:28:51
query4_3 = '''
    WITH allstores(sName) AS (SELECT sName FROM store)
            allcities(city) AS ((SELECT city from store) UNION (SELECT city from customer))
            allpos (sName, city) AS (SELECT sName, city FROM allstores, allcities)
            actual(sName, city) AS (SELECT sName, city FROM store)
            missing (sName, city) AS (SELECT sName, city WHERE (sName, city) NOT IN (actual))
            
    SELECT sName
    FROM stores
    WHERE sName NOT IN (SELECT * FROM missing)
'''
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:31:33
query4_3 = '''
    WITH allstores(sName) AS (SELECT sName FROM store),
            allcities(city) AS (SELECT city from store UNION SELECT city from customer),
            allpos (sName, city) AS (SELECT sName, city FROM allstores, allcities),
            actual(sName, city) AS (SELECT sName, city FROM store),
            missing (sName, city) AS (SELECT sName, city FROM allpos WHERE (sName, city) NOT IN (actual)   
    SELECT sName
    FROM stores
    WHERE sName NOT IN (SELECT * FROM missing)
'''
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:50:58
query4_5 = '''
    SELECT c.city, count (distinct c.cID), ISNULL (NULL, 0)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 11:55:34
query4_5 = '''
    SELECT c.city, count (distinct c.cID)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven" 
    GROUP BY c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count (distinct c.cID)
#[Out]# 0  Amsterdam                      10
#[Out]# 1      Breda                       9
#[Out]# 2  Eindhoven                      15
#[Out]# 3  Rotterdam                      13
#[Out]# 4    Tilburg                      10
#[Out]# 5    Utrecht                      12
# Wed, 09 Dec 2020 11:57:23
query4_5 = '''
    
    SELECT ISNULL (count(distinct c.cID), 0) FROM customer  

'''

pd.read_sql_query(query4_5, conn)

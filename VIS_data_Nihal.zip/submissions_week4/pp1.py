# IPython log file

# Mon, 07 Dec 2020 08:59:36
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 08:59:37
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x2bfd2c4e810>
# Mon, 07 Dec 2020 09:03:55
query4_3 = '''
    SELECT sName, city FROM customer WHERE sID IN (
        SELECT city FROM customer UNION SELECT city FROM store
    )
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 09:04:12
query4_3 = '''
    SELECT sName, city FROM store WHERE sID IN (
        SELECT city FROM customer UNION SELECT city FROM store
    )
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Mon, 07 Dec 2020 09:10:19
query4_3 = '''
    SELECT city FROM customer
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# ..         ...
#[Out]# 185  Eindhoven
#[Out]# 186  Eindhoven
#[Out]# 187  Rotterdam
#[Out]# 188        Oss
#[Out]# 189    Utrecht
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Mon, 07 Dec 2020 09:10:35
query4_3 = '''
    SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          city
#[Out]# 0   Amsterdam
#[Out]# 1       Breda
#[Out]# 2   Rotterdam
#[Out]# 3   Rotterdam
#[Out]# 4   Eindhoven
#[Out]# ..        ...
#[Out]# 59      Breda
#[Out]# 60      Breda
#[Out]# 61      Breda
#[Out]# 62  Eindhoven
#[Out]# 63        Oss
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Mon, 07 Dec 2020 09:10:56
query4_3 = '''
    SELECT c.store, s.city FROM store s, customer c
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 09:11:05
query4_3 = '''
    SELECT c.city, s.city FROM store s, customer c
'''

pd.read_sql_query(query4_3, conn)
#[Out]#             city       city
#[Out]# 0        Utrecht  Amsterdam
#[Out]# 1          Breda  Amsterdam
#[Out]# 2      Amsterdam  Amsterdam
#[Out]# 3          Breda  Amsterdam
#[Out]# 4      Amsterdam  Amsterdam
#[Out]# ...          ...        ...
#[Out]# 12155  Eindhoven        Oss
#[Out]# 12156  Eindhoven        Oss
#[Out]# 12157  Rotterdam        Oss
#[Out]# 12158        Oss        Oss
#[Out]# 12159    Utrecht        Oss
#[Out]# 
#[Out]# [12160 rows x 2 columns]
# Mon, 07 Dec 2020 09:12:06
query4_3 = '''
    SELECT city FROM customer UNION SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 09:13:01
query4_3 = '''
    SELECt sName FROM store WHERE city IN (SELECT city FROM customer UNION SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Mon, 07 Dec 2020 09:13:24
query4_3 = '''
    SELECt DISTINCT sName FROM store WHERE city IN (SELECT city FROM customer UNION SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Mon, 07 Dec 2020 09:54:29
query4_3 = '''
    SELECt city FROM customer UNION SELECT city FROM 
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 09:54:34
query4_3 = '''
    SELECt city FROM customer UNION SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 09:54:55
query4_3 = '''
    SELECT * FROM (SELECt city FROM customer UNION SELECT city FROM store) as cities
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 09:55:40
query4_3 = '''
    (SELECt city FROM customer UNION SELECT city FROM store) as cities
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 09:55:49
query4_3 = '''
    sELECT * FROM (SELECt city FROM customer UNION SELECT city FROM store) as cities
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 10:17:00
query4_3 = '''
    SELECT sName, city FROM store as s WHERE NOT EXISTS ((SELECT city FROM store as c) EXCEPT SELECT city FROM city c WHERE c.city = s.city)(SELECT * FROM (SELECt city FROM customer UNION SELECT city FROM store) as cities)
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 10:17:05
query4_3 = '''
    SELECT sName, city FROM store as s WHERE NOT EXISTS ((SELECT city FROM store as c) EXCEPT SELECT city FROM city c WHERE c.city = s.city)
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 10:17:37
query4_3 = '''
    SELECT sName, city FROM store as s WHERE NOT EXISTS ( ( SELECT city FROM store as c) EXCEPT SELECT city FROM city c WHERE c.city = s.city)
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 10:17:57
query4_3 = '''
    (SELECT * FROM (SELECt city FROM customer UNION SELECT city FROM store) as cities)
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 10:18:03
query4_3 = '''
    SELECT * FROM (SELECt city FROM customer UNION SELECT city FROM store) as cities
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 11:35:14
query4_3 = '''
    SELECT * FROM store as sx WHERE NOT EXISTS (
        (SELECT s.city FROM store s)
        EXCEPT
        (SELECT c.city FROM (SELECT * FROM (SELECt city FROM customer UNION SELECT city FROM store)) c WHERE c.sID = sx.sID)
    )
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 11:45:52
query4_3 = '''
    SELECT * FROM store as sx WHERE NOT EXISTS (
        (SELECT s.city FROM store s)
        EXCEPT
        (SELECT c.city FROM (SELECT * FROM (SELECt city FROM customer UNION SELECT city FROM store)) c WHERE c.sID = sx.sID)
    );
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 11:47:04
query4_3 = '''
    SELECT * FROM store as sx WHERE NOT EXISTS (
        (SELECT s.city FROM store s)
        EXCEPT
        (SELECT c.city FROM (SELECT * FROM (SELECt city FROM customer UNION SELECT city FROM store)) c WHERE c.sID = sx.sID)
    );
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 11:53:30
query4_3 = '''
    SELECT * FROM store as sx WHERE NOT EXISTS (
        (SELECT s.city FROM store s)
        EXCEPT
        (SELECT c.city FROM (SELECt city FROM customer UNION SELECT city FROM store) c WHERE c.sID = sx.sID)
    );
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 11:54:15
query4_3 = '''
    SELECT * FROM store as sx WHERE NOT EXISTS (
        (SELECT s.city FROM store s)
        EXCEPT
        (SELECT city FROM (SELECt city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID)
    );
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 11:54:41
query4_3 = '''
    
        (SELECT s.city FROM store s)
        EXCEPT
        (SELECT city FROM (SELECt city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID)
    
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 11:54:50
query4_3 = '''
    
        SELECT s.city FROM store s
        EXCEPT
        SELECT city FROM (SELECt city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID
    
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 11:55:08
query4_3 = '''
    SELECT * FROM store as sx WHERE NOT EXISTS (
        SELECT s.city FROM store s
        EXCEPT
        SELECT city FROM (SELECt city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID
    );
'''

pd.read_sql_query(query4_3, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0     0       Coop      Kalverstraat  Amsterdam
#[Out]# 1     1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59   59      Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60       Lidl      Pannekoekweg      Breda
#[Out]# 61   61       Lidl      Pannekoekweg      Breda
#[Out]# 62   62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63      Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Mon, 07 Dec 2020 11:57:19
query4_3 = '''
    SELECT sc.sName, sx.city FROM store as sx WHERE NOT EXISTS (
        SELECT s.city FROM store s
        EXCEPT
        SELECT city FROM (SELECt city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID
    );
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 11:57:22
query4_3 = '''
    SELECT sx.sName, sx.city FROM store as sx WHERE NOT EXISTS (
        SELECT s.city FROM store s
        EXCEPT
        SELECT city FROM (SELECt city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID
    );
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Mon, 07 Dec 2020 11:58:14
query4_4 = '''
    SELECT * FROM purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Mon, 07 Dec 2020 11:58:24
query4_4 = '''
    SELECT price FROM purchase ORDER BY price
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.40
#[Out]# 1     0.40
#[Out]# 2     0.40
#[Out]# 3     0.40
#[Out]# 4     0.45
#[Out]# ..     ...
#[Out]# 504  13.25
#[Out]# 505  13.40
#[Out]# 506  13.60
#[Out]# 507  13.65
#[Out]# 508  13.80
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Mon, 07 Dec 2020 11:58:29
query4_4 = '''
    SELECT price FROM purchase ORDER BY DESC price
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 11:58:37
query4_4 = '''
    SELECT price FROM purchase ORDER DESC BY  price
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 11:58:42
query4_4 = '''
    SELECT price FROM purchase DESC ORDER BY price
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.40
#[Out]# 1     0.40
#[Out]# 2     0.40
#[Out]# 3     0.40
#[Out]# 4     0.45
#[Out]# ..     ...
#[Out]# 504  13.25
#[Out]# 505  13.40
#[Out]# 506  13.60
#[Out]# 507  13.65
#[Out]# 508  13.80
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Mon, 07 Dec 2020 11:58:47
query4_4 = '''
    SELECT price FROM purchase ASC ORDER BY price
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.40
#[Out]# 1     0.40
#[Out]# 2     0.40
#[Out]# 3     0.40
#[Out]# 4     0.45
#[Out]# ..     ...
#[Out]# 504  13.25
#[Out]# 505  13.40
#[Out]# 506  13.60
#[Out]# 507  13.65
#[Out]# 508  13.80
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Mon, 07 Dec 2020 11:58:49
query4_4 = '''
    SELECT price FROM purchase DSC ORDER BY price
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.40
#[Out]# 1     0.40
#[Out]# 2     0.40
#[Out]# 3     0.40
#[Out]# 4     0.45
#[Out]# ..     ...
#[Out]# 504  13.25
#[Out]# 505  13.40
#[Out]# 506  13.60
#[Out]# 507  13.65
#[Out]# 508  13.80
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Mon, 07 Dec 2020 11:58:51
query4_4 = '''
    SELECT price FROM purchase DESC ORDER BY price
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.40
#[Out]# 1     0.40
#[Out]# 2     0.40
#[Out]# 3     0.40
#[Out]# 4     0.45
#[Out]# ..     ...
#[Out]# 504  13.25
#[Out]# 505  13.40
#[Out]# 506  13.60
#[Out]# 507  13.65
#[Out]# 508  13.80
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Mon, 07 Dec 2020 11:59:11
query4_4 = '''
    SELECT price FROM purchase ORDER BY price DESC
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0    13.80
#[Out]# 1    13.65
#[Out]# 2    13.60
#[Out]# 3    13.40
#[Out]# 4    13.25
#[Out]# ..     ...
#[Out]# 504   0.45
#[Out]# 505   0.40
#[Out]# 506   0.40
#[Out]# 507   0.40
#[Out]# 508   0.40
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Mon, 07 Dec 2020 11:59:28
query4_4 = '''
    SELECT price FROM purchase ORDER BY price DESC GROUP BY price
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 12:08:29
query4_4 = '''
    SELECT TOP 1 price FROM purchase ORDER BY price DESC
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 12:08:31
query4_4 = '''
    SELECT TOP 1 price FROM purchase ORDER BY price DESC
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 12:08:34
query4_4 = '''
    SELECT TOP price FROM purchase ORDER BY price DESC
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 12:09:04
query4_4 = '''
    SELECT price FROM purchase ORDER BY price DESC limit 1
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price
#[Out]# 0   13.8
# Mon, 07 Dec 2020 12:09:08
query4_4 = '''
    SELECT price FROM purchase ORDER BY price DESC LIMIT 1
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price
#[Out]# 0   13.8
# Mon, 07 Dec 2020 12:09:54
query4_4 = '''
    SELECT .75 * price FROM (SELECT price FROM purchase ORDER BY price DESC LIMIT 1)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    .75 * price
#[Out]# 0        10.35
# Mon, 07 Dec 2020 12:12:54
query4_4 = '''
    SELECT .75 price FROM purchase ORDER BY price DESC LIMIT 1
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price
#[Out]# 0   0.75
# Mon, 07 Dec 2020 12:12:58
query4_4 = '''
    SELECT .75 * price FROM purchase ORDER BY price DESC LIMIT 1
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    .75 * price
#[Out]# 0        10.35
# Mon, 07 Dec 2020 12:13:27
query4_4 = '''
    SELECT cID FROM purchase WHERE price >= (SELECT .75 * price FROM purchase ORDER BY price DESC LIMIT 1)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID
#[Out]# 0     4
#[Out]# 1     7
#[Out]# 2    24
#[Out]# 3    30
#[Out]# 4    33
#[Out]# 5    51
#[Out]# 6    52
#[Out]# 7    71
#[Out]# 8    82
#[Out]# 9    82
#[Out]# 10   91
#[Out]# 11  103
#[Out]# 12  109
#[Out]# 13  113
#[Out]# 14  116
#[Out]# 15  124
#[Out]# 16  144
#[Out]# 17  159
#[Out]# 18  162
# Mon, 07 Dec 2020 12:14:09
query4_4 = '''
    SELECT DISTINCT cName FROM customer WHERE cID IN (SELECT cID FROM purchase WHERE price >= (SELECT .75 * price FROM purchase ORDER BY price DESC LIMIT 1))
'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9   Thijmen
#[Out]# 10    Lotte
#[Out]# 11     Lynn
#[Out]# 12    Fenna
#[Out]# 13    Lieke
#[Out]# 14    Sofie
#[Out]# 15      Ivy
#[Out]# 16    Fenne
#[Out]# 17    Elena
# Mon, 07 Dec 2020 12:21:05
query4_5 = '''
    SELECT * FROM purchase
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Mon, 07 Dec 2020 12:21:45
query4_5 = '''
    SELECT * FROM store
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0     0       Coop      Kalverstraat  Amsterdam
#[Out]# 1     1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59   59      Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60       Lidl      Pannekoekweg      Breda
#[Out]# 61   61       Lidl      Pannekoekweg      Breda
#[Out]# 62   62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63      Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Mon, 07 Dec 2020 12:21:58
query4_5 = '''
    SELECT sID FROM store WHERE city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID
#[Out]# 0     4
#[Out]# 1     7
#[Out]# 2     8
#[Out]# 3    12
#[Out]# 4    17
#[Out]# 5    30
#[Out]# 6    33
#[Out]# 7    36
#[Out]# 8    37
#[Out]# 9    39
#[Out]# 10   52
#[Out]# 11   54
#[Out]# 12   56
#[Out]# 13   57
#[Out]# 14   62
# Mon, 07 Dec 2020 12:22:13
query4_5 = '''
    SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID
#[Out]# 0     4
#[Out]# 1     7
#[Out]# 2     8
#[Out]# 3    12
#[Out]# 4    17
#[Out]# 5    30
#[Out]# 6    33
#[Out]# 7    36
#[Out]# 8    37
#[Out]# 9    39
#[Out]# 10   52
#[Out]# 11   54
#[Out]# 12   56
#[Out]# 13   57
#[Out]# 14   62
# Mon, 07 Dec 2020 12:22:32
query4_5 = '''
    SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven")
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      3    1   17    9  2018-08-20         2   1.25
#[Out]# 1      7    1   36   27  2018-08-21         6   9.10
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45
#[Out]# 3      9    2   39    9  2018-08-17         7   1.35
#[Out]# 4     14    3   30   26  2018-08-19         2   2.75
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 128  836  190   52   23  2018-08-15         5   2.50
#[Out]# 129  838  190   54    0  2018-08-25         6   3.50
#[Out]# 130  840  190   56   11  2018-08-15         4   1.60
#[Out]# 131  841  190   57   15  2018-08-22         5   3.25
#[Out]# 132  846  190   62    9  2018-08-16         2   3.15
#[Out]# 
#[Out]# [133 rows x 7 columns]
# Mon, 07 Dec 2020 12:26:28
query4_5 = '''
    SELECT * FROM customer
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID   cName            street       city
#[Out]# 0      0    Noah         Koestraat    Utrecht
#[Out]# 1      1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 3      3    Finn     Stationsplein      Breda
#[Out]# 4      4    Daan      Kalverstraat  Amsterdam
#[Out]# ..   ...     ...               ...        ...
#[Out]# 185  185    Nick            Verweg  Eindhoven
#[Out]# 186  186  Angela          Dichtweg  Eindhoven
#[Out]# 187  188    Pino        Maanstraat  Rotterdam
#[Out]# 188  189    Koen          Akkerweg        Oss
#[Out]# 189  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Mon, 07 Dec 2020 12:27:11
query4_5 = '''
    SELECT * FROM customer GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    cID  cName            street       city
#[Out]# 0    2  Lucas  Oude Leliestraat  Amsterdam
#[Out]# 1    1    Sem  Rozemarijnstraat      Breda
#[Out]# 2    7   Bram      Schoolstraat  Eindhoven
#[Out]# 3  189   Koen          Akkerweg        Oss
#[Out]# 4   25  Mason      Keizerstraat  Rotterdam
#[Out]# 5   10    Sam       Langestraat    Tilburg
#[Out]# 6    0   Noah         Koestraat    Utrecht
# Mon, 07 Dec 2020 12:28:29
query4_5 = '''
SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven")
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      3    1   17    9  2018-08-20         2   1.25
#[Out]# 1      7    1   36   27  2018-08-21         6   9.10
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45
#[Out]# 3      9    2   39    9  2018-08-17         7   1.35
#[Out]# 4     14    3   30   26  2018-08-19         2   2.75
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 128  836  190   52   23  2018-08-15         5   2.50
#[Out]# 129  838  190   54    0  2018-08-25         6   3.50
#[Out]# 130  840  190   56   11  2018-08-15         4   1.60
#[Out]# 131  841  190   57   15  2018-08-22         5   3.25
#[Out]# 132  846  190   62    9  2018-08-16         2   3.15
#[Out]# 
#[Out]# [133 rows x 7 columns]

# IPython log file

# Tue, 08 Dec 2020 08:23:42
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 08:23:42
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 08 Dec 2020 08:23:44
query4_3 = '''
    SELECT sx.sName, sx.city FROM store as sx WHERE NOT EXISTS (
        SELECT s.city FROM store s
        EXCEPT
        SELECT city FROM (SELECt city FROM customer UNION SELECT city FROM store) WHERE sID = sx.sID
    );
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 08:27:01
query4_5 = '''
SELECT DISTINCT sID FROM store WHERE city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID
#[Out]# 0     4
#[Out]# 1     7
#[Out]# 2     8
#[Out]# 3    12
#[Out]# 4    17
#[Out]# 5    30
#[Out]# 6    33
#[Out]# 7    36
#[Out]# 8    37
#[Out]# 9    39
#[Out]# 10   52
#[Out]# 11   54
#[Out]# 12   56
#[Out]# 13   57
#[Out]# 14   62
# Tue, 08 Dec 2020 08:32:19
query4_5 = '''
SELECT * FROM purchase GROUP BY cID
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45
#[Out]# 3     13    3   44   14  2018-08-18         2   4.30
#[Out]# 4     16    4   17    8  2018-08-24         2   4.15
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 127  778  185   62   29  2018-08-20         1   1.00
#[Out]# 128  779  186   62   29  2018-08-21         5   1.00
#[Out]# 129  780  188   62   30  2018-08-20         1   1.00
#[Out]# 130  782  189   63    7  2018-08-25         5   1.25
#[Out]# 131  784  190    0   27  2018-08-19         5   4.45
#[Out]# 
#[Out]# [132 rows x 7 columns]
# Tue, 08 Dec 2020 08:32:25
query4_5 = '''
SELECT * FROM purchase
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Tue, 08 Dec 2020 08:33:07
query4_5 = '''
SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven")
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      3    1   17    9  2018-08-20         2   1.25
#[Out]# 1      7    1   36   27  2018-08-21         6   9.10
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45
#[Out]# 3      9    2   39    9  2018-08-17         7   1.35
#[Out]# 4     14    3   30   26  2018-08-19         2   2.75
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 128  836  190   52   23  2018-08-15         5   2.50
#[Out]# 129  838  190   54    0  2018-08-25         6   3.50
#[Out]# 130  840  190   56   11  2018-08-15         4   1.60
#[Out]# 131  841  190   57   15  2018-08-22         5   3.25
#[Out]# 132  846  190   62    9  2018-08-16         2   3.15
#[Out]# 
#[Out]# [133 rows x 7 columns]
# Tue, 08 Dec 2020 08:33:16
query4_5 = '''
SELECT * FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price
#[Out]# 0     3    1   17    9  2018-08-20         2   1.25
#[Out]# 1     8    2   12   20  2018-08-16         1   2.45
#[Out]# 2    14    3   30   26  2018-08-19         2   2.75
#[Out]# 3    16    4   17    8  2018-08-24         2   4.15
#[Out]# 4    22    5    4   14  2018-08-17         6   4.70
#[Out]# ..  ...  ...  ...  ...         ...       ...    ...
#[Out]# 64  472  182   17   25  2018-08-28         8   3.90
#[Out]# 65  778  185   62   29  2018-08-20         1   1.00
#[Out]# 66  779  186   62   29  2018-08-21         5   1.00
#[Out]# 67  780  188   62   30  2018-08-20         1   1.00
#[Out]# 68  788  190    4    7  2018-08-26         7   1.30
#[Out]# 
#[Out]# [69 rows x 7 columns]
# Tue, 08 Dec 2020 08:34:05
query4_5 = '''
SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Tue, 08 Dec 2020 08:34:15
query4_5 = '''
SELECT * FROM (SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Tue, 08 Dec 2020 08:34:29
query4_5 = '''
SELECT * FROM customer WHERE cID IN (SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID    cName            street       city
#[Out]# 0     1      Sem  Rozemarijnstraat      Breda
#[Out]# 1     2    Lucas  Oude Leliestraat  Amsterdam
#[Out]# 2     3     Finn     Stationsplein      Breda
#[Out]# 3     4     Daan      Kalverstraat  Amsterdam
#[Out]# 4     5     Levi    Gasthuisstraat    Utrecht
#[Out]# ..  ...      ...               ...        ...
#[Out]# 64  182  Johanna     Beatrixstraat  Eindhoven
#[Out]# 65  185     Nick            Verweg  Eindhoven
#[Out]# 66  186   Angela          Dichtweg  Eindhoven
#[Out]# 67  188     Pino        Maanstraat  Rotterdam
#[Out]# 68  190   Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [69 rows x 4 columns]
# Tue, 08 Dec 2020 08:34:42
query4_5 = '''
SELECT DISTINCT * FROM customer WHERE cID IN (SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID    cName            street       city
#[Out]# 0     1      Sem  Rozemarijnstraat      Breda
#[Out]# 1     2    Lucas  Oude Leliestraat  Amsterdam
#[Out]# 2     3     Finn     Stationsplein      Breda
#[Out]# 3     4     Daan      Kalverstraat  Amsterdam
#[Out]# 4     5     Levi    Gasthuisstraat    Utrecht
#[Out]# ..  ...      ...               ...        ...
#[Out]# 64  182  Johanna     Beatrixstraat  Eindhoven
#[Out]# 65  185     Nick            Verweg  Eindhoven
#[Out]# 66  186   Angela          Dichtweg  Eindhoven
#[Out]# 67  188     Pino        Maanstraat  Rotterdam
#[Out]# 68  190   Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [69 rows x 4 columns]
# Tue, 08 Dec 2020 08:35:05
query4_5 = '''
SELECT DISTINCT * FROM customer WHERE cID IN (SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID) GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    cID  cName            street       city
#[Out]# 0    2  Lucas  Oude Leliestraat  Amsterdam
#[Out]# 1    1    Sem  Rozemarijnstraat      Breda
#[Out]# 2    7   Bram      Schoolstraat  Eindhoven
#[Out]# 3   25  Mason      Keizerstraat  Rotterdam
#[Out]# 4   24   Luca      Kasteeldreef    Tilburg
#[Out]# 5    5   Levi    Gasthuisstraat    Utrecht
# Tue, 08 Dec 2020 08:36:51
query4_5 = '''
SELECT COUNT(*) FROM customer WHERE cID IN (SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID) GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(*)
#[Out]# 0        10
#[Out]# 1         9
#[Out]# 2        15
#[Out]# 3        13
#[Out]# 4        10
#[Out]# 5        12
# Tue, 08 Dec 2020 08:37:01
query4_5 = '''
SELECT city, COUNT(*) FROM customer WHERE cID IN (SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID) GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(*)
#[Out]# 0  Amsterdam        10
#[Out]# 1      Breda         9
#[Out]# 2  Eindhoven        15
#[Out]# 3  Rotterdam        13
#[Out]# 4    Tilburg        10
#[Out]# 5    Utrecht        12
# Tue, 08 Dec 2020 08:37:14
query4_5 = '''
SELECT city, COUNT(*) as nrOfPeople FROM customer WHERE cID IN (SELECT cID FROM purchase WHERE sID IN (SELECT DISTINCT sID FROM store WHERE city = "Eindhoven") GROUP BY cID) GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  nrOfPeople
#[Out]# 0  Amsterdam          10
#[Out]# 1      Breda           9
#[Out]# 2  Eindhoven          15
#[Out]# 3  Rotterdam          13
#[Out]# 4    Tilburg          10
#[Out]# 5    Utrecht          12


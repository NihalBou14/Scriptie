# IPython log file

# Tue, 08 Dec 2020 17:39:15
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Tue, 08 Dec 2020 17:39:24
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import numpy
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Tue, 08 Dec 2020 17:40:15
import sys
print(sys.version_info)

# IPython log file

# Tue, 08 Dec 2020 17:41:48
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 17:41:53
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7fd742ab23b0>
# Tue, 08 Dec 2020 17:43:24
query4_3 = '''
SELECT sName, city
FROM store

EXCEPT

(SELECT city FROM customer UNION SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:43:30
query4_3 = '''
SELECT sName, city
FROM store

EXCEPT

(SELECT city FROM customer UNION SELECT city FROM store);
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:43:36
query4_3 = '''
(SELECT sName, city
FROM store)
EXCEPT
(SELECT city FROM customer UNION SELECT city FROM store);
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:43:52
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT city FROM customer UNION SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:44:05
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
(SELECT city FROM customer) UNION (SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:44:23
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
((SELECT city FROM customer) UNION (SELECT city FROM store))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:44:27
query4_3 = '''
SELECT sName, city
FROM store

'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 17:44:33
query4_3 = '''
(SELECT sName, city
FROM store)

'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:45:26
query4_3 = '''
SELECT sName, city
FROM store

'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 17:49:20
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city, store.city
FROM customer, city

'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:49:28
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city, store.city
FROM customer, store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 17:49:56
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city, store.city
FROM customer, store
UNION
SELECT customer.city, store.city
FROM customer, store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# ..          ...        ...
#[Out]# 76      Utrecht  Eindhoven
#[Out]# 77      Utrecht        Oss
#[Out]# 78      Utrecht  Rotterdam
#[Out]# 79      Utrecht    Tilburg
#[Out]# 80      Utrecht    Utrecht
#[Out]# 
#[Out]# [81 rows x 2 columns]
# Tue, 08 Dec 2020 17:50:02
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city, store.city
FROM customer, store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 17:50:19
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city
FROM customer
UNION
SELECT store.city
FROM store
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:51:53
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city
FROM customer
UNION ALL
SELECT store.city
FROM store
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:53:23
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
(SELECT customer.city
FROM customer
UNION ALL
SELECT store.city
FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:53:40
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
(SELECT customer.city, store.city
FROM customer
UNION ALL
SELECT store.city
FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:55:00
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x7fd742ab23b0>
query4_3 = '''
SELECT sName, city
FROM store

EXCEPT

(SELECT city FROM customer UNION SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store

EXCEPT

(SELECT city FROM customer UNION SELECT city FROM store);
'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
(SELECT sName, city
FROM store)
EXCEPT
(SELECT city FROM customer UNION SELECT city FROM store);
'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT city FROM customer UNION SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
(SELECT city FROM customer) UNION (SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
((SELECT city FROM customer) UNION (SELECT city FROM store))
'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store

'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
query4_3 = '''
(SELECT sName, city
FROM store)

'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store

'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city, store.city
FROM customer, city

'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city, store.city
FROM customer, store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city, store.city
FROM customer, store
UNION
SELECT customer.city, store.city
FROM customer, store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# ..          ...        ...
#[Out]# 76      Utrecht  Eindhoven
#[Out]# 77      Utrecht        Oss
#[Out]# 78      Utrecht  Rotterdam
#[Out]# 79      Utrecht    Tilburg
#[Out]# 80      Utrecht    Utrecht
#[Out]# 
#[Out]# [81 rows x 2 columns]
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city, store.city
FROM customer, store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city
FROM customer
UNION
SELECT store.city
FROM store
'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
SELECT customer.city
FROM customer
UNION ALL
SELECT store.city
FROM store
'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
(SELECT customer.city
FROM customer
UNION ALL
SELECT store.city
FROM store)
'''

pd.read_sql_query(query4_3, conn)
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
(SELECT customer.city, store.city
FROM customer
UNION ALL
SELECT store.city
FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:55:00
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 17:55:00
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
#db_location = 'shoppingDB.sql'

#f = open(db_location,'r')
#sql = f.read()
#cur.executescript(sql)
# Tue, 08 Dec 2020 17:55:00
query4_3 = '''
SELECT sName, city
FROM store
EXCEPT
(SELECT customer.city FROM customer)
UNION
SELECT store.city
FROM store
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:00:00
query4_4 = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUPBY cID, date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:00:04
query4_4 = '''
SELECT cName
FROM customer
GROUPBY cID, date
JOIN purchase ON customer.cID=purchase.cID
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:00:28
query4_4 = '''
SELECT cName
FROM customer
GROUP BY cID, date
JOIN purchase ON customer.cID=purchase.cID
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:00:30
query4_4 = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:00:35
query4_4 = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Noah
#[Out]# 1       Sem
#[Out]# 2       Sem
#[Out]# 3     Lucas
#[Out]# 4     Lucas
#[Out]# ..      ...
#[Out]# 280  Kostas
#[Out]# 281  Kostas
#[Out]# 282  Kostas
#[Out]# 283  Kostas
#[Out]# 284  Kostas
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Tue, 08 Dec 2020 18:02:02
query4_4 = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price > (SELECT MAX(price) FROM purchase)
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:02:17
query4_4 = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price > SELECT MAX(price) FROM purchase
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:03:29
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
SELECT MAX(price) FROM purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(price)
#[Out]# 0        13.8
# Tue, 08 Dec 2020 18:05:07
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
(SELECT MAX(price) FROM purchase).value
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:05:16
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
SELECT MAX(price) FROM purchase.value
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:06:35
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price >= max_price.price
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:07:23
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price >= max_price.price
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:10:47
query4_5 = '''
SELECT count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    count(customer.cID)
#[Out]# 0                  133
# Tue, 08 Dec 2020 18:11:20
query4_5 = '''
SELECT count(customer.cID)
FROM customer
GROUP BY customer.city
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:11:23
query4_5 = '''
SELECT count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
GROUP BY customer.city
WHERE store.city="Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:11:26
query4_5 = '''
SELECT count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    count(customer.cID)
#[Out]# 0                  133
# Tue, 08 Dec 2020 18:11:27
query4_5 = '''
SELECT count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    count(customer.cID)
#[Out]# 0                   17
#[Out]# 1                   27
#[Out]# 2                   24
#[Out]# 3                   16
#[Out]# 4                   18
#[Out]# 5                   31
# Tue, 08 Dec 2020 18:11:47
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cID)
#[Out]# 0  Amsterdam                   17
#[Out]# 1      Breda                   27
#[Out]# 2  Eindhoven                   24
#[Out]# 3  Rotterdam                   16
#[Out]# 4    Tilburg                   18
#[Out]# 5    Utrecht                   31
# Tue, 08 Dec 2020 18:12:29
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
UNION
SELECT customer.city, count(customer.cID)
FROM customer
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cID)
#[Out]# 0  Amsterdam                   17
#[Out]# 1      Breda                   27
#[Out]# 2  Eindhoven                   24
#[Out]# 3  Rotterdam                   16
#[Out]# 4    Tilburg                   18
#[Out]# 5    Utrecht                   31
#[Out]# 6    Utrecht                  190
# Tue, 08 Dec 2020 18:12:34
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cID)
#[Out]# 0  Amsterdam                   17
#[Out]# 1      Breda                   27
#[Out]# 2  Eindhoven                   24
#[Out]# 3  Rotterdam                   16
#[Out]# 4    Tilburg                   18
#[Out]# 5    Utrecht                   31
# Tue, 08 Dec 2020 18:12:40
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
UNION
SELECT customer.city, count(customer.cID)
FROM customer
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cID)
#[Out]# 0  Amsterdam                   17
#[Out]# 1      Breda                   27
#[Out]# 2  Eindhoven                   24
#[Out]# 3  Rotterdam                   16
#[Out]# 4    Tilburg                   18
#[Out]# 5    Utrecht                   31
#[Out]# 6    Utrecht                  190
# Tue, 08 Dec 2020 18:14:10
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
UNION
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  count(customer.cID)
#[Out]# 0   Amsterdam                   17
#[Out]# 1   Amsterdam                   26
#[Out]# 2       Breda                   27
#[Out]# 3   Eindhoven                   24
#[Out]# 4   Eindhoven                   33
#[Out]# 5         Oss                    1
#[Out]# 6   Rotterdam                   16
#[Out]# 7   Rotterdam                   29
#[Out]# 8     Tilburg                   18
#[Out]# 9     Tilburg                   38
#[Out]# 10    Utrecht                   31
#[Out]# 11    Utrecht                   36
# Tue, 08 Dec 2020 18:19:01
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
UNION
    SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
EXCEPT
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:19:02
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
UNION
    SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  count(customer.cID)
#[Out]# 0   Amsterdam                   17
#[Out]# 1   Amsterdam                   26
#[Out]# 2       Breda                   27
#[Out]# 3   Eindhoven                   24
#[Out]# 4   Eindhoven                   33
#[Out]# 5         Oss                    1
#[Out]# 6   Rotterdam                   16
#[Out]# 7   Rotterdam                   29
#[Out]# 8     Tilburg                   18
#[Out]# 9     Tilburg                   38
#[Out]# 10    Utrecht                   31
#[Out]# 11    Utrecht                   36
# Tue, 08 Dec 2020 18:20:02
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
)
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:20:26
query4_5 = '''

SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
)
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:20:40
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
)
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:21:19
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
)
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:21:55
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
old2 = '''
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
'''
query4_5 = '''
SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
)
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:21:58
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
old2 = '''
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
'''
query4_5 = '''
SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3  Rotterdam
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
# Tue, 08 Dec 2020 18:22:10
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
old2 = '''
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
'''
query4_5 = '''
(SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:22:27
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
old2 = '''
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
'''
query4_5 = '''
SELECT customer.city
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city
#[Out]# 0  Oss
# Tue, 08 Dec 2020 18:22:35
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
old2 = '''
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
'''
query4_5 = '''
SELECT customer.city
FROM customer
GROUP BY customer.cityt
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:22:36
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
old2 = '''
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
'''
query4_5 = '''
SELECT customer.city
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:22:39
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
old2 = '''
SELECT customer.city, count(customer.cID)
FROM customer
GROUP BY customer.city
WHERE customer.city NOT IN (
'''
query4_5 = '''
SELECT customer.city
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city
#[Out]# 0  Oss
# Tue, 08 Dec 2020 18:22:50
old = '''
'''
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

SELECT customer.city
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:22:57
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
query4_5 = '''
SELECT customer.city
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city
#[Out]# 0  Oss
# Tue, 08 Dec 2020 18:23:44
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
query4_5 = '''
SELECT customer.city, count(customer.cID)
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city  count(customer.cID)
#[Out]# 0  Oss                    1
# Tue, 08 Dec 2020 18:24:15
old = '''
SELECT customer.city, count(customer.cID)
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
query4_5 = '''
SELECT customer.city, count(customer.cID) = 0
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city  count(customer.cID) = 0
#[Out]# 0  Oss                        0
# Tue, 08 Dec 2020 18:24:45
old = '''
SELECT customer.city, count(customer.cID) AS customer_count
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
query4_5 = '''
SELECT customer.city, count(customer.cID) = 0 AS customer_count
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city  customer_count
#[Out]# 0  Oss               0
# Tue, 08 Dec 2020 18:24:55
old = '''
SELECT customer.city, count(customer.cID) AS customer_count
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

'''
query4_5 = '''
SELECT customer.city, count(customer.cID) AS customer_count
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

SELECT customer.city, count(customer.cID) = 0 AS customer_count
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  customer_count
#[Out]# 0  Amsterdam              17
#[Out]# 1      Breda              27
#[Out]# 2  Eindhoven              24
#[Out]# 3        Oss               0
#[Out]# 4  Rotterdam              16
#[Out]# 5    Tilburg              18
#[Out]# 6    Utrecht              31
# Tue, 08 Dec 2020 18:25:04
query4_5 = '''
SELECT customer.city, count(customer.cID) AS customer_count
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

SELECT customer.city, count(customer.cID) = 0 AS customer_count
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  customer_count
#[Out]# 0  Amsterdam              17
#[Out]# 1      Breda              27
#[Out]# 2  Eindhoven              24
#[Out]# 3        Oss               0
#[Out]# 4  Rotterdam              16
#[Out]# 5    Tilburg              18
#[Out]# 6    Utrecht              31
# Tue, 08 Dec 2020 18:26:53
query4_5 = '''
SELECT customer.city AS city, count(customer.cID) AS number
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city

UNION

SELECT customer.city AS city, count(customer.cID) = 0 AS number
FROM customer
WHERE customer.city NOT IN (SELECT customer.city
FROM customer
JOIN purchase ON customer.cID=purchase.cID
JOIN store ON purchase.sID=store.sID
WHERE store.city="Eindhoven"
GROUP BY customer.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      16
#[Out]# 5    Tilburg      18
#[Out]# 6    Utrecht      31
# Tue, 08 Dec 2020 18:30:44
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
GIVEN purchase.price >= max_price.price
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:30:46
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Noah
#[Out]# 1       Sem
#[Out]# 2       Sem
#[Out]# 3     Lucas
#[Out]# 4     Lucas
#[Out]# ..      ...
#[Out]# 280  Kostas
#[Out]# 281  Kostas
#[Out]# 282  Kostas
#[Out]# 283  Kostas
#[Out]# 284  Kostas
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Tue, 08 Dec 2020 18:30:57
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
WHERE purchase.price >= max_price.price
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:31:02
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= max_price.price
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cName
#[Out]# 0  Willem
# Tue, 08 Dec 2020 18:31:13
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= 0.75 * max_price.price
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9     Dylan
#[Out]# 10  Thijmen
#[Out]# 11    Lotte
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Lieke
#[Out]# 15    Sofie
#[Out]# 16      Ivy
#[Out]# 17    Fenne
#[Out]# 18    Elena
# Tue, 08 Dec 2020 18:31:37
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= 0.75 * SELECT MAX(price) FROM purchase
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:31:44
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= 0.75 * (SELECT MAX(price) FROM purchase)
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9     Dylan
#[Out]# 10  Thijmen
#[Out]# 11    Lotte
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Lieke
#[Out]# 15    Sofie
#[Out]# 16      Ivy
#[Out]# 17    Fenne
#[Out]# 18    Elena
# Tue, 08 Dec 2020 18:31:52
query4_4 = '''
SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= 0.75 * (SELECT MAX(price) FROM purchase)
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:31:56
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= 0.75 * (SELECT MAX(price) FROM purchase)
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:31:57
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''
WITH max_price(price) AS (
SELECT MAX(price) FROM purchase)

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= 0.75 * (SELECT MAX(price) FROM purchase)
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9     Dylan
#[Out]# 10  Thijmen
#[Out]# 11    Lotte
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Lieke
#[Out]# 15    Sofie
#[Out]# 16      Ivy
#[Out]# 17    Fenne
#[Out]# 18    Elena
# Tue, 08 Dec 2020 18:32:06
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''

SELECT cName
FROM customer, max_price
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= 0.75 * (SELECT MAX(price) FROM purchase)
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:32:11
temp = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
GROUP BY purchase.cID, date
GIVEN purchase.price
'''
query4_4 = '''

SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= 0.75 * (SELECT MAX(price) FROM purchase)
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9     Dylan
#[Out]# 10  Thijmen
#[Out]# 11    Lotte
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Lieke
#[Out]# 15    Sofie
#[Out]# 16      Ivy
#[Out]# 17    Fenne
#[Out]# 18    Elena
# Tue, 08 Dec 2020 18:32:17
query4_4 = '''
SELECT cName
FROM customer
JOIN purchase ON customer.cID=purchase.cID
WHERE purchase.price >= 0.75 * (SELECT MAX(price) FROM purchase)
GROUP BY purchase.cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9     Dylan
#[Out]# 10  Thijmen
#[Out]# 11    Lotte
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Lieke
#[Out]# 15    Sofie
#[Out]# 16      Ivy
#[Out]# 17    Fenne
#[Out]# 18    Elena
# Tue, 08 Dec 2020 18:39:16
query4_3 = '''
SELECT sName, city
FROM store
WHERE (sName, city) NOT IN
(SELECT customer.city FROM customer)
UNION
(SELECT store.city FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:39:23
query4_3 = '''
SELECT sName, city
FROM store
WHERE (sName, city) NOT IN
((SELECT customer.city FROM customer)
UNION
(SELECT store.city FROM store)
)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:42:55
query4_3 = '''
SELECT sName, city
FROM store
WHERE (sName, city) = ALL
(
(SELECT customer.city FROM customer)
UNION
(SELECT store.city FROM store)
)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:43:10
query4_3 = '''
SELECT sName, city
FROM store
WHERE (sName, city) = ALL
(SELECT customer.city FROM customer
UNION
SELECT store.city FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:43:23
query4_3 = '''
SELECT sName, city
FROM store
WHERE type = ALL
(SELECT customer.city FROM customer
UNION
SELECT store.city FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:44:28
test = '''
SELECT sName, city
FROM store
WHERE type = ALL
'''
query4_3 = '''
(SELECT customer.city FROM customer
UNION
SELECT store.city FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:44:31
test = '''
SELECT sName, city
FROM store
WHERE type = ALL
'''
query4_3 = '''
SELECT customer.city FROM customer
UNION
SELECT store.city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 18:45:33
test = '''
SELECT sName, city
FROM store
WHERE type = ALL
'''
query4_3 = '''
SELECT customer.city, store.city
FROM customer, store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           city       city
#[Out]# 0      Utrecht  Amsterdam
#[Out]# 1      Utrecht      Breda
#[Out]# 2      Utrecht  Rotterdam
#[Out]# 3      Utrecht  Rotterdam
#[Out]# 4      Utrecht  Eindhoven
#[Out]# ...        ...        ...
#[Out]# 12155  Utrecht      Breda
#[Out]# 12156  Utrecht      Breda
#[Out]# 12157  Utrecht      Breda
#[Out]# 12158  Utrecht  Eindhoven
#[Out]# 12159  Utrecht        Oss
#[Out]# 
#[Out]# [12160 rows x 2 columns]
# Tue, 08 Dec 2020 18:46:04
test = '''
SELECT sName, city
FROM store
WHERE type = ALL
'''
query4_3 = '''
SELECT city FROM customer
UNION
SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 18:46:11
test = '''
SELECT sName, city
FROM store
WHERE type = ALL
'''
query4_3 = '''
SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          city
#[Out]# 0   Amsterdam
#[Out]# 1       Breda
#[Out]# 2   Rotterdam
#[Out]# 3   Rotterdam
#[Out]# 4   Eindhoven
#[Out]# ..        ...
#[Out]# 59      Breda
#[Out]# 60      Breda
#[Out]# 61      Breda
#[Out]# 62  Eindhoven
#[Out]# 63        Oss
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 08 Dec 2020 18:46:19
test = '''
SELECT sName, city
FROM store
WHERE type = ALL
SELECT city FROM customer
UNION
'''
query4_3 = '''
SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          city
#[Out]# 0   Amsterdam
#[Out]# 1       Breda
#[Out]# 2   Rotterdam
#[Out]# 3   Rotterdam
#[Out]# 4   Eindhoven
#[Out]# ..        ...
#[Out]# 59      Breda
#[Out]# 60      Breda
#[Out]# 61      Breda
#[Out]# 62  Eindhoven
#[Out]# 63        Oss
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 08 Dec 2020 18:46:23
test = '''
SELECT sName, city
FROM store
WHERE type = ALL
SELECT city FROM customer
UNION
'''
query4_3 = '''
SELECT unique(city) FROM store
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:46:34
test = '''
SELECT sName, city
FROM store
WHERE type = ALL
SELECT city FROM customer
UNION
'''
query4_3 = '''
SELECT distinct city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Tue, 08 Dec 2020 18:46:59
test = '''
SELECT sName, city
FROM store
WHERE type = ALL
'''
query4_3 = '''
SELECT city FROM customer
UNION
SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 18:47:08
test = '''
'''
query4_3 = '''
SELECT sName, city
FROM store
WHERE type = ALL
(SELECT city FROM customer
UNION
SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:47:16
test = '''
'''
query4_3 = '''
SELECT sName, city
FROM store
WHERE city = ALL
(SELECT city FROM customer
UNION
SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:51:39
test = '''
'''
query4_3 = '''
SELECT sName, city
FROM store
WHERE city = ALL
(SELECT city FROM STORE
EXCEPT
(SELECT city FROM customer
UNION
SELECT city FROM store)
)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:51:48
test = '''
'''
query4_3 = '''
SELECT sName, city
FROM store
WHERE city NOT IN
(SELECT city FROM STORE
EXCEPT
(SELECT city FROM customer
UNION
SELECT city FROM store)
)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:54:58
test = '''
'''
query4_3 = '''
SELECT sName
FROM store
WHERE city NOT IN
(
SELECT city FROM STORE
EXCEPT
(SELECT city FROM customer
UNION
SELECT city FROM store)
)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:55:37
test = '''
'''
query4_3 = '''
SELECT sName
FROM store
WHERE city NOT IN
(SELECT city FROM customer
UNION
SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 18:55:44
query4_3 = '''
SELECT sName
FROM store
WHERE city NOT IN
(SELECT city FROM customer
UNION
SELECT city FROM store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []


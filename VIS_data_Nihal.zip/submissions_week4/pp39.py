# IPython log file

# Sat, 05 Dec 2020 18:45:11
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 05 Dec 2020 18:45:11
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x167b2291dc0>
# Sat, 05 Dec 2020 18:49:24
query4_3 = '''
    SELECT sName, city FROM store
    SELECT city FROM customer
    UNION
    SELECT city from store
'''
# Sat, 05 Dec 2020 18:49:33
query4_3 = '''
    SELECT sName, city FROM store
    EXCEPT
    SELECT city FROM customer
    UNION
    SELECT city from store
'''
# Sat, 05 Dec 2020 18:49:33
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 18:49:55
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x00000167B2291DC0>
query4_3 = '''
    SELECT sName, city FROM store
    SELECT city FROM customer
    UNION
    SELECT city from store
'''
query4_3 = '''
    SELECT sName, city FROM store
    EXCEPT
    SELECT city FROM customer
    UNION
    SELECT city from store
'''
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 18:50:01
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 05 Dec 2020 18:50:10
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Sat, 05 Dec 2020 18:50:17
query4_3 = '''
    SELECT sName, city
    SELECT city FROM customer
    UNION
    SELECT city from store
'''
# Sat, 05 Dec 2020 18:50:18
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 18:51:35
query4_3 = '''
    SELECT sName, city 
    FROM store
    WHERE city NOT IN (
    SELECT city FROM customer
    UNION
    SELECT city from store);
'''
# Sat, 05 Dec 2020 18:51:35
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 18:51:53
query4_3 = '''
    SELECT sName, city 
    FROM store
    WHERE city NOT IN (
    SELECT city FROM customer
    UNION
    SELECT city from store);
'''
# Sat, 05 Dec 2020 18:51:53
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 18:51:54
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 18:51:58
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 18:55:23
query4_3 = '''
    SELECT DISTINCT sName, city 
    FROM store
    WHERE city NOT IN (
    SELECT DISTINCT city FROM customer
    UNION
    SELECT DISTINCT city from store);
'''
# Sat, 05 Dec 2020 18:55:24
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 18:55:24
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 18:55:37
query4_3 = '''
    SELECT DISTINCT sName, city 
    FROM store
    WHERE city NOT IN (
    SELECT DISTINCT city FROM customer
    INTERSECTION
    SELECT DISTINCT city from store);
'''
# Sat, 05 Dec 2020 18:55:37
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 18:55:38
pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:55:50
query4_3 = '''
    SELECT DISTINCT sName, city 
    FROM store
    WHERE city NOT IN (
    SELECT DISTINCT city FROM customer
    INTERSECTS
    SELECT DISTINCT city from store);
'''
# Sat, 05 Dec 2020 18:55:50
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 18:55:50
pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:55:55
query4_3 = '''
    SELECT DISTINCT sName, city 
    FROM store
    WHERE city NOT IN (
    SELECT DISTINCT city FROM customer
    UNION
    SELECT DISTINCT city from store);
'''
# Sat, 05 Dec 2020 18:55:56
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 18:55:56
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:01:39
query4_3 = '''
    SELECT DISTINCT sName, city 
    FROM store
    WHERE city IN (
    SELECT DISTINCT city FROM customer
    UNION
    SELECT DISTINCT city from store);
'''
# Sat, 05 Dec 2020 19:01:40
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:01:40
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Sat, 05 Dec 2020 19:01:51
query4_3 = '''
    SELECT sName, city 
    FROM store
    WHERE city IN (
    SELECT DISTINCT city FROM customer
    UNION
    SELECT DISTINCT city from store);
'''
# Sat, 05 Dec 2020 19:01:51
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:01:51
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 05 Dec 2020 19:02:05
query4_3 = '''
    SELECT sName, city 
    FROM store
    WHERE city IN (
    SELECT DISTINCT city FROM customer
    UNION
    SELECT DISTINCT city from store)
    ORDER BY sName;
'''
# Sat, 05 Dec 2020 19:02:05
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:02:05
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein      Breda
#[Out]# ..          ...        ...
#[Out]# 59       Sligro  Amsterdam
#[Out]# 60       Sligro  Amsterdam
#[Out]# 61       Sligro  Eindhoven
#[Out]# 62       Sligro  Amsterdam
#[Out]# 63       Sligro      Breda
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 05 Dec 2020 19:02:26
query4_3 = '''
    SELECT sName, city 
    FROM store
    WHERE city IN (
    SELECT DISTINCT city FROM customer
    UNION
    SELECT DISTINCT city from store)
    ORDER BY sName, city;
'''
# Sat, 05 Dec 2020 19:02:26
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:02:27
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein      Breda
#[Out]# 2   Albert Hein  Eindhoven
#[Out]# 3   Albert Hein  Rotterdam
#[Out]# 4   Albert Hein  Rotterdam
#[Out]# ..          ...        ...
#[Out]# 59       Sligro      Breda
#[Out]# 60       Sligro  Eindhoven
#[Out]# 61       Sligro  Eindhoven
#[Out]# 62       Sligro  Rotterdam
#[Out]# 63       Sligro    Tilburg
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 05 Dec 2020 19:26:25
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store
    WHERE city NOT IN(
    SELECT DISTINCT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT DISTINCT city from store WHERE city <> 'Oss');
'''
# Sat, 05 Dec 2020 19:26:26
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:26:26
pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
# Sat, 05 Dec 2020 19:28:27
query4_3 = '''
    SELECT sName 
    FROM store
    WHERE city NOT IN(
    SELECT DISTINCT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT DISTINCT city from store WHERE city <> 'Oss');
'''
# Sat, 05 Dec 2020 19:28:28
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:28:28
pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
# Sat, 05 Dec 2020 19:29:27
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store
    WHERE city NOT IN(
    SELECT DISTINCT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT DISTINCT city from store WHERE city <> 'Oss');
'''
# Sat, 05 Dec 2020 19:29:27
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:29:28
pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
# Sat, 05 Dec 2020 19:29:51
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store
    WHERE city NOT IN(
    SELECT DISTINCT city FROM customer
    UNION
    SELECT DISTINCT city from store);
'''
# Sat, 05 Dec 2020 19:29:51
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:29:51
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:30:11
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store
    WHERE city IN(
    SELECT DISTINCT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT DISTINCT city from store WHERE city <> 'Oss');
'''
# Sat, 05 Dec 2020 19:30:11
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:30:12
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Sat, 05 Dec 2020 19:30:23
query4_3 = '''
    SELECT sName 
    FROM store
    WHERE city IN(
    SELECT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT city from store WHERE city <> 'Oss');
'''
# Sat, 05 Dec 2020 19:30:24
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:30:24
pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 58       Dirk
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 
#[Out]# [63 rows x 1 columns]
# Sat, 05 Dec 2020 19:30:30
query4_3 = '''
    SELECT sName 
    FROM store
    WHERE city =(
    SELECT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT city from store WHERE city <> 'Oss');
'''
# Sat, 05 Dec 2020 19:30:30
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:30:31
pd.read_sql_query(query4_3, conn)
#[Out]#     sName
#[Out]# 0    Coop
#[Out]# 1    Coop
#[Out]# 2    Lidl
#[Out]# 3    Lidl
#[Out]# 4  Sligro
#[Out]# 5  Sligro
#[Out]# 6    Coop
#[Out]# 7  Sligro
# Sat, 05 Dec 2020 19:30:47
query4_3 = '''
    SELECT sName 
    FROM store
    WHERE city NOT IN (
    SELECT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT city from store WHERE city <> 'Oss');
'''
# Sat, 05 Dec 2020 19:30:47
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:30:47
pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
# Sat, 05 Dec 2020 19:33:06
query4_3 = '''
    SELECT sName 
    FROM store as s1
    WHERE city NOT IN (
    SELECT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT city from store WHERE city <> 'Oss') EXCEPT SELECT city FROM store as s2 WHERE s2.sName = s1.sName ;
'''
# Sat, 05 Dec 2020 19:33:07
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:33:07
pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:33:39
query4_3 = '''
    SELECT sName 
    FROM store as s1
    WHERE city NOT IN (
    SELECT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT city from store WHERE city <> 'Oss' EXCEPT SELECT city FROM store as s2 WHERE s2.sName = s1.sName );
'''
# Sat, 05 Dec 2020 19:33:39
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:33:39
pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:33:58
query4_3 = '''
    SELECT sName 
    FROM store as s1
    WHERE NOT EXIST (
    SELECT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT city from store WHERE city <> 'Oss' EXCEPT SELECT city FROM store as s2 WHERE s2.sName = s1.sName );
'''
# Sat, 05 Dec 2020 19:33:58
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:33:58
pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:34:04
query4_3 = '''
    SELECT sName 
    FROM store as s1
    WHERE NOT EXISTS (
    SELECT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT city from store WHERE city <> 'Oss' EXCEPT SELECT city FROM store as s2 WHERE s2.sName = s1.sName );
'''
# Sat, 05 Dec 2020 19:34:04
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:34:04
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:34:40
query4_3 = '''
    SELECT sName 
    FROM store as s1
    WHERE NOT EXISTS (
    SELECT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT city from store WHERE city <> 'Oss');
'''
# Sat, 05 Dec 2020 19:34:40
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:34:40
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:34:49
query4_3 = '''
    SELECT sName 
    FROM store
    WHERE NOT EXISTS (
    SELECT city FROM customer WHERE city <> 'Oss'
    UNION
    SELECT city from store WHERE city <> 'Oss');
'''
# Sat, 05 Dec 2020 19:34:49
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:34:50
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:35:18
query4_3 = '''
    SELECT sName 
    FROM store
    WHERE NOT EXISTS (
    SELECT city FROM customer WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    UNION
    SELECT city from store WHERE city <> 'Utrecht' AND city <> 'Amsterdam');
'''
# Sat, 05 Dec 2020 19:35:18
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:35:19
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:35:44
query4_3 = '''
    SELECT sName 
    FROM store
    WHERE NOT EXISTS (
    SELECT city FROM customer WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    UNION
    SELECT city from store WHERE city <> 'Utrecht' AND city <> 'Amsterdam');
'''
# Sat, 05 Dec 2020 19:35:44
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:35:44
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:58:10
query4_3 = '''
    SELECT sName FROM store as s1
WHERE NOT EXISTS (
SELECT city FROM customer WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
UNION
SELECT city FROM store WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
EXCEPT 
SELECT city FROM store as s2 WHERE s1.sName = s2.sName);
'''
# Sat, 05 Dec 2020 19:58:10
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 19:58:11
pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
# Sat, 05 Dec 2020 20:15:41
query4_3 = '''
    SELECT DISTINCT sName FROM store as s1
    WHERE NOT EXISTS (
        SELECT city FROM customer
        UNION
        SELECT city FROM store
        EXCEPT 
        SELECT city FROM store as s2 WHERE s1.sName = s2.sName);
'''
# Sat, 05 Dec 2020 20:15:42
vis.visualize(query4_3, schema)
# Sat, 05 Dec 2020 20:15:42
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 20:21:02
query4_4 = '''
    CREATE VIEW total_date as SELECT date, SUM(price) as total
    FROM purchase
    GROUP BY date
'''
# Sat, 05 Dec 2020 20:21:03
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 20:21:04
pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:21:43
query4_4 = '''
    CREATE VIEW total_date as (SELECT date, SUM(price) as total
    FROM purchase
    GROUP BY date)
'''
# Sat, 05 Dec 2020 20:21:44
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 20:21:44
pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:47:23
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
SELECT cID, date, SUM(price) as total
FROM purchase
GROUP BY cID, date)
SELECT MAX(value) FROM customer_price_date)
SELECT cID, date, SUM(price) FROM purchase, max_spent 
GROUP BY cID, date
HAVING SUM(price) >= 0.75*value
'''
# Sat, 05 Dec 2020 20:47:23
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 20:47:23
pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  SUM(price)
#[Out]# 0  161  2018-08-26        39.1
# Sat, 05 Dec 2020 20:48:04
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT cID, date, SUM(price) FROM purchase, max_spent 
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*value
'''
# Sat, 05 Dec 2020 20:48:04
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 20:48:05
pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date, SUM(price)]
#[Out]# Index: []
# Sat, 05 Dec 2020 20:48:27
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT cID, date, SUM(price*quantity) FROM purchase, max_spent 
    GROUP BY cID, date
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 20:48:28
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 20:48:28
pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  SUM(price*quantity)
#[Out]# 0   33  2018-08-27               138.90
#[Out]# 1   71  2018-08-24               145.00
#[Out]# 2  109  2018-08-18               150.15
#[Out]# 3  124  2018-08-26               134.90
#[Out]# 4  161  2018-08-26               171.25
# Sat, 05 Dec 2020 20:56:10
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT cID, date, SUM(price*quantity) FROM purchase, max_spent 
    GROUP BY cID, date
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 20:56:10
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 20:56:10
pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  SUM(price*quantity)
#[Out]# 0   33  2018-08-27               138.90
#[Out]# 1   71  2018-08-24               145.00
#[Out]# 2  109  2018-08-18               150.15
#[Out]# 3  124  2018-08-26               134.90
#[Out]# 4  161  2018-08-26               171.25
# Sat, 05 Dec 2020 20:59:54
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT cID, date, SUM(price*quantity) 
    FROM customer as c, purchase, max_spent
    WHERE cID = c.cID
    GROUP BY cID, date
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 20:59:54
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 20:59:55
pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 21:00:10
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT cID, date, SUM(price*quantity) 
    FROM customer as c, purchase, max_spent as m
    WHERE m.cID = c.cID
    GROUP BY cID, date
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:00:10
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:00:11
pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 21:00:52
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT c.name 
    FROM customer as c, purchase as p, max_spent as m
    WHERE m.cID = c.cID
    GROUP BY cID, date
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:00:52
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:00:52
pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 21:01:16
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT c.cName 
    FROM customer as c, purchase as p, max_spent as m
    WHERE m.cID = c.cID
    GROUP BY cID, date
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:01:16
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:01:17
pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 21:01:31
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT c.cName 
    FROM customer as c, purchase as p, max_spent as m
    WHERE p.cID = c.cID
    GROUP BY cID, date
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:01:31
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:01:32
pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 21:01:40
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT c.cName 
    FROM customer as c, purchase as p, max_spent as m
    WHERE p.cID = c.cID
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:01:40
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:01:41
pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 21:01:59
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT c.cName 
    FROM customer as c, purchase as p, max_spent as m
    WHERE p.cID = c.cID
    GROUP BY c.cName
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:01:59
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:02:00
pd.read_sql_query(query4_4, conn)
#[Out]#      cName
#[Out]# 0     Daan
#[Out]# 1     Dean
#[Out]# 2    Dylan
#[Out]# 3    Elena
#[Out]# 4    Floor
#[Out]# 5      Ivy
#[Out]# 6     Joep
#[Out]# 7   Kostas
#[Out]# 8     Lily
#[Out]# 9     Lynn
#[Out]# 10   Sofie
#[Out]# 11    Sven
#[Out]# 12  Veerle
# Sat, 05 Dec 2020 21:02:21
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT DISTINCT c.cName 
    FROM customer as c, purchase as p, max_spent as m
    WHERE p.cID = c.cID
    GROUP BY c.cName
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:02:21
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:02:21
pd.read_sql_query(query4_4, conn)
#[Out]#      cName
#[Out]# 0     Daan
#[Out]# 1     Dean
#[Out]# 2    Dylan
#[Out]# 3    Elena
#[Out]# 4    Floor
#[Out]# 5      Ivy
#[Out]# 6     Joep
#[Out]# 7   Kostas
#[Out]# 8     Lily
#[Out]# 9     Lynn
#[Out]# 10   Sofie
#[Out]# 11    Sven
#[Out]# 12  Veerle
# Sat, 05 Dec 2020 21:02:59
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT c.cName 
    FROM customer as c, purchase as p, max_spent as m
    WHERE cID = c.cID
    GROUP BY c.cName
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:03:00
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:03:00
pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 21:03:36
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT c.cName 
    FROM customer as c, purchase as p, max_spent as m
    WHERE p.cID = c.cID
    GROUP BY c.cName
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:03:36
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:03:37
pd.read_sql_query(query4_4, conn)
#[Out]#      cName
#[Out]# 0     Daan
#[Out]# 1     Dean
#[Out]# 2    Dylan
#[Out]# 3    Elena
#[Out]# 4    Floor
#[Out]# 5      Ivy
#[Out]# 6     Joep
#[Out]# 7   Kostas
#[Out]# 8     Lily
#[Out]# 9     Lynn
#[Out]# 10   Sofie
#[Out]# 11    Sven
#[Out]# 12  Veerle
# Sat, 05 Dec 2020 21:04:00
query4_4 = '''
    with max_spent(value) as (with customer_price_date(cID, date, value) as (
    SELECT cID, date, SUM(price*quantity) as total
    FROM purchase
    GROUP BY cID, date)
    SELECT MAX(value) FROM customer_price_date)
    SELECT c.cName 
    FROM customer as c, purchase as p, max_spent as m
    WHERE p.cID = c.cID
    GROUP BY c.cName, date
    HAVING SUM(price*quantity) >= 0.75*value
'''
# Sat, 05 Dec 2020 21:04:01
vis.visualize(query4_4, schema)
# Sat, 05 Dec 2020 21:04:01
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Dean
#[Out]# 1  Floor
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4   Sven
# Sat, 05 Dec 2020 21:12:36
query4_5 = '''
    SELECT city, COUNT(*) as number
    FROM customer
    WHERE cID IN (
      SELECT cID
      FROM purchase as p, store as s
      WHERE p.sID = s.sID AND s.city = 'Eindhoven')
    GROUP BY city;
'''
# Sat, 05 Dec 2020 21:12:36
vis.visualize(query4_5, schema)
# Sat, 05 Dec 2020 21:12:37
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12


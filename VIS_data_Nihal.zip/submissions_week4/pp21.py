# IPython log file

# Mon, 07 Dec 2020 10:14:57
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 10:15:02
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1c7be2f0ab0>
# Mon, 07 Dec 2020 10:17:33
query4_4 = '''
    select max(price)
    from purchase as p
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    max(price)
#[Out]# 0        13.8
# Mon, 07 Dec 2020 10:18:28
query4_4 = '''
    select cID, date, max(price)
    from purchase as p
    group by cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  max(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20        4.65
#[Out]# 2      1  2018-08-21        9.10
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        3.70
#[Out]# 5      3  2018-08-18        4.30
#[Out]# 6      3  2018-08-19        2.75
#[Out]# 7      4  2018-08-24        9.05
#[Out]# 8      4  2018-08-25       13.60
#[Out]# 9      5  2018-08-17        4.70
#[Out]# 10     5  2018-08-22        8.25
#[Out]# 11     5  2018-08-23        2.20
#[Out]# 12     7  2018-08-23        2.10
#[Out]# 13     7  2018-08-24        1.90
#[Out]# 14     7  2018-08-25       10.75
#[Out]# 15     7  2018-08-26        2.05
#[Out]# 16     8  2018-08-16        5.30
#[Out]# 17    10  2018-08-27        3.20
#[Out]# 18    11  2018-08-25        4.10
#[Out]# 19    13  2018-08-17        5.40
#[Out]# 20    13  2018-08-25        2.40
#[Out]# 21    13  2018-08-26        1.65
#[Out]# 22    13  2018-08-27        0.50
#[Out]# 23    15  2018-08-27        0.90
#[Out]# 24    16  2018-08-18        2.90
#[Out]# 25    16  2018-08-19        9.25
#[Out]# 26    16  2018-08-24        3.70
#[Out]# 27    16  2018-08-25        2.50
#[Out]# 28    16  2018-08-26        3.00
#[Out]# 29    16  2018-08-27        1.85
#[Out]# ..   ...         ...         ...
#[Out]# 255  178  2018-08-27        3.90
#[Out]# 256  179  2018-08-22        9.00
#[Out]# 257  179  2018-08-23        0.45
#[Out]# 258  179  2018-08-24        3.70
#[Out]# 259  180  2018-08-26        3.10
#[Out]# 260  180  2018-08-27        4.05
#[Out]# 261  181  2018-08-24        2.70
#[Out]# 262  181  2018-08-27        2.00
#[Out]# 263  182  2018-08-23        4.20
#[Out]# 264  182  2018-08-28        9.70
#[Out]# 265  184  2018-08-20        3.50
#[Out]# 266  185  2018-08-20        1.00
#[Out]# 267  186  2018-08-21        1.00
#[Out]# 268  188  2018-08-20        1.00
#[Out]# 269  188  2018-09-20        1.00
#[Out]# 270  189  2018-08-25        1.25
#[Out]# 271  189  2018-08-26        2.50
#[Out]# 272  190  2018-08-15        4.15
#[Out]# 273  190  2018-08-16        3.25
#[Out]# 274  190  2018-08-17        3.80
#[Out]# 275  190  2018-08-18        4.35
#[Out]# 276  190  2018-08-19        4.45
#[Out]# 277  190  2018-08-20        3.20
#[Out]# 278  190  2018-08-21        3.30
#[Out]# 279  190  2018-08-22        4.05
#[Out]# 280  190  2018-08-23        2.85
#[Out]# 281  190  2018-08-24        2.55
#[Out]# 282  190  2018-08-25        3.70
#[Out]# 283  190  2018-08-26        4.30
#[Out]# 284  190  2018-08-27        4.35
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Mon, 07 Dec 2020 10:20:37
query4_4 = '''

select max(price)
from (select cID, date, max(price)
    from purchase as p
    group by cID, date) as maxpercusdate
    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:20:55
query4_4 = '''

select max(price)
from (select cID, date, max(price) as price
    from purchase as p
    group by cID, date) as maxpercusdate
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    max(price)
#[Out]# 0        13.8
# Mon, 07 Dec 2020 10:24:17
query4_4 = '''

with maxprice(maxprice) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )
   
select cID, date
from purchase
group by cID, date
having price > 0.75 * maxprice.maxprice
    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:24:41
query4_4 = '''

with maxprice (maxprice) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )
   
select cID, date
from purchase
group by cID, date
having price > 0.75 * maxprice.maxprice
    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:24:48
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )
   
select cID, date
from purchase
group by cID, date
having price > 0.75 * maxprice.value
    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:24:54
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )
   
select cID, date
from purchase
group by cID, date
having price > (0.75 * maxprice.value)
    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:25:38
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )
   
select cID, date
from purchase, maxprice
group by cID, date
having price > (0.75 * maxprice.value)
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID        date
#[Out]# 0     4  2018-08-25
#[Out]# 1     7  2018-08-25
#[Out]# 2    24  2018-08-20
#[Out]# 3    82  2018-08-23
#[Out]# 4    82  2018-08-24
#[Out]# 5   103  2018-08-23
#[Out]# 6   109  2018-08-18
#[Out]# 7   113  2018-08-21
#[Out]# 8   116  2018-08-24
#[Out]# 9   144  2018-08-23
#[Out]# 10  162  2018-08-24
# Mon, 07 Dec 2020 10:27:59
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as 75thcust, customer as c
where 75thcust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:28:43
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID as cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as 75thcust, customer as c
where 75thcust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:29:03
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as perc, customer as c
where perc.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Daan
#[Out]# 1   Bram
#[Out]# 2   Luca
#[Out]# 3  Dylan
#[Out]# 4  Lotte
#[Out]# 5   Lynn
#[Out]# 6  Fenna
#[Out]# 7  Lieke
#[Out]# 8    Ivy
#[Out]# 9  Elena
# Mon, 07 Dec 2020 10:29:16
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as 75thcust, customer as c
where 75thcust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:29:24
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as 3thcust, customer as c
where 3thcust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:29:31
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as cust, customer as c
where cust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Daan
#[Out]# 1   Bram
#[Out]# 2   Luca
#[Out]# 3  Dylan
#[Out]# 4  Lotte
#[Out]# 5   Lynn
#[Out]# 6  Fenna
#[Out]# 7  Lieke
#[Out]# 8    Ivy
#[Out]# 9  Elena
# Mon, 07 Dec 2020 10:29:49
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Daan
#[Out]# 1   Bram
#[Out]# 2   Luca
#[Out]# 3  Dylan
#[Out]# 4  Lotte
#[Out]# 5   Lynn
#[Out]# 6  Fenna
#[Out]# 7  Lieke
#[Out]# 8    Ivy
#[Out]# 9  Elena
# Mon, 07 Dec 2020 10:33:46
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

    
'''

pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 10:34:15
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, max(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select value
from maxprice
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    value
#[Out]# 0   13.8
# Mon, 07 Dec 2020 10:37:11
query4_4 = '''

select cID, date, max(price) as price
    from purchase
    group by cID, date


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   4.65
#[Out]# 2      1  2018-08-21   9.10
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   3.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   2.75
#[Out]# 7      4  2018-08-24   9.05
#[Out]# 8      4  2018-08-25  13.60
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   2.20
#[Out]# 12     7  2018-08-23   2.10
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   2.05
#[Out]# 16     8  2018-08-16   5.30
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17   5.40
#[Out]# 20    13  2018-08-25   2.40
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19   9.25
#[Out]# 26    16  2018-08-24   3.70
#[Out]# 27    16  2018-08-25   2.50
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   3.90
#[Out]# 256  179  2018-08-22   9.00
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   3.70
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.05
#[Out]# 261  181  2018-08-24   2.70
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28   9.70
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15   4.15
#[Out]# 273  190  2018-08-16   3.25
#[Out]# 274  190  2018-08-17   3.80
#[Out]# 275  190  2018-08-18   4.35
#[Out]# 276  190  2018-08-19   4.45
#[Out]# 277  190  2018-08-20   3.20
#[Out]# 278  190  2018-08-21   3.30
#[Out]# 279  190  2018-08-22   4.05
#[Out]# 280  190  2018-08-23   2.85
#[Out]# 281  190  2018-08-24   2.55
#[Out]# 282  190  2018-08-25   3.70
#[Out]# 283  190  2018-08-26   4.30
#[Out]# 284  190  2018-08-27   4.35
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Mon, 07 Dec 2020 10:37:26
query4_4 = '''

select cID, date, max(price) as price
from purchase
group by cID, date
order by price desc


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0     52  2018-08-25  13.80
#[Out]# 1    109  2018-08-18  13.65
#[Out]# 2      4  2018-08-25  13.60
#[Out]# 3     82  2018-08-24  13.40
#[Out]# 4    144  2018-08-23  13.25
#[Out]# 5    162  2018-08-24  13.15
#[Out]# 6     33  2018-08-27  12.80
#[Out]# 7     91  2018-08-26  12.65
#[Out]# 8    116  2018-08-24  12.55
#[Out]# 9    159  2018-08-26  12.30
#[Out]# 10   113  2018-08-21  12.20
#[Out]# 11    82  2018-08-23  12.00
#[Out]# 12   124  2018-08-26  11.65
#[Out]# 13    24  2018-08-20  11.55
#[Out]# 14    30  2018-08-18  11.45
#[Out]# 15   103  2018-08-23  11.20
#[Out]# 16     7  2018-08-25  10.75
#[Out]# 17    51  2018-08-19  10.60
#[Out]# 18    71  2018-08-24  10.50
#[Out]# 19    39  2018-08-28  10.30
#[Out]# 20   123  2018-08-17  10.15
#[Out]# 21   170  2018-08-16   9.85
#[Out]# 22    70  2018-08-25   9.70
#[Out]# 23   182  2018-08-28   9.70
#[Out]# 24   162  2018-08-22   9.65
#[Out]# 25    40  2018-08-16   9.60
#[Out]# 26    35  2018-08-18   9.45
#[Out]# 27    16  2018-08-19   9.25
#[Out]# 28   134  2018-08-26   9.25
#[Out]# 29     1  2018-08-21   9.10
#[Out]# ..   ...         ...    ...
#[Out]# 255  129  2018-08-24   1.10
#[Out]# 256  169  2018-08-20   1.10
#[Out]# 257   59  2018-08-25   1.05
#[Out]# 258  162  2018-08-21   1.05
#[Out]# 259  118  2018-08-22   1.00
#[Out]# 260  126  2018-08-22   1.00
#[Out]# 261  135  2018-08-19   1.00
#[Out]# 262  167  2018-08-18   1.00
#[Out]# 263  185  2018-08-20   1.00
#[Out]# 264  186  2018-08-21   1.00
#[Out]# 265  188  2018-08-20   1.00
#[Out]# 266  188  2018-09-20   1.00
#[Out]# 267  128  2018-08-25   0.95
#[Out]# 268   15  2018-08-27   0.90
#[Out]# 269   31  2018-08-27   0.90
#[Out]# 270  172  2018-08-27   0.90
#[Out]# 271  176  2018-08-22   0.90
#[Out]# 272   85  2018-08-18   0.85
#[Out]# 273   57  2018-08-16   0.80
#[Out]# 274   30  2018-08-15   0.60
#[Out]# 275   58  2018-08-27   0.55
#[Out]# 276  163  2018-08-22   0.55
#[Out]# 277  169  2018-08-27   0.55
#[Out]# 278   13  2018-08-27   0.50
#[Out]# 279   55  2018-08-17   0.50
#[Out]# 280    0  2018-08-22   0.45
#[Out]# 281   22  2018-08-28   0.45
#[Out]# 282   77  2018-08-23   0.45
#[Out]# 283  179  2018-08-23   0.45
#[Out]# 284   72  2018-08-21   0.40
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Mon, 07 Dec 2020 10:39:01
query4_4 = '''

select cID, date, sum(price) as price
from purchase
group by cID, date
order by price desc


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0    161  2018-08-26  39.10
#[Out]# 1    124  2018-08-26  28.80
#[Out]# 2    108  2018-08-15  23.95
#[Out]# 3     71  2018-08-24  22.25
#[Out]# 4    190  2018-08-26  21.90
#[Out]# 5     82  2018-08-23  21.30
#[Out]# 6     24  2018-08-20  20.70
#[Out]# 7    190  2018-08-19  20.30
#[Out]# 8    123  2018-08-17  20.20
#[Out]# 9    190  2018-08-15  19.60
#[Out]# 10     4  2018-08-25  19.40
#[Out]# 11   162  2018-08-22  18.35
#[Out]# 12    33  2018-08-27  16.75
#[Out]# 13   170  2018-08-16  15.85
#[Out]# 14    51  2018-08-19  15.75
#[Out]# 15   159  2018-08-26  15.75
#[Out]# 16   190  2018-08-17  15.75
#[Out]# 17   113  2018-08-21  15.55
#[Out]# 18    52  2018-08-25  15.20
#[Out]# 19    86  2018-08-17  15.10
#[Out]# 20   182  2018-08-28  14.90
#[Out]# 21   190  2018-08-18  14.85
#[Out]# 22   190  2018-08-22  14.55
#[Out]# 23     4  2018-08-24  14.25
#[Out]# 24     1  2018-08-20  14.20
#[Out]# 25   109  2018-08-18  13.65
#[Out]# 26    91  2018-08-26  13.55
#[Out]# 27    82  2018-08-24  13.40
#[Out]# 28    30  2018-08-18  13.35
#[Out]# 29    13  2018-08-17  13.30
#[Out]# ..   ...         ...    ...
#[Out]# 255   28  2018-08-27   1.10
#[Out]# 256  129  2018-08-24   1.10
#[Out]# 257   59  2018-08-25   1.05
#[Out]# 258  162  2018-08-21   1.05
#[Out]# 259  118  2018-08-22   1.00
#[Out]# 260  126  2018-08-22   1.00
#[Out]# 261  135  2018-08-19   1.00
#[Out]# 262  167  2018-08-18   1.00
#[Out]# 263  185  2018-08-20   1.00
#[Out]# 264  186  2018-08-21   1.00
#[Out]# 265  188  2018-08-20   1.00
#[Out]# 266  188  2018-09-20   1.00
#[Out]# 267  163  2018-08-22   0.95
#[Out]# 268  128  2018-08-25   0.95
#[Out]# 269   15  2018-08-27   0.90
#[Out]# 270   31  2018-08-27   0.90
#[Out]# 271  172  2018-08-27   0.90
#[Out]# 272  176  2018-08-22   0.90
#[Out]# 273   85  2018-08-18   0.85
#[Out]# 274   57  2018-08-16   0.80
#[Out]# 275   30  2018-08-15   0.60
#[Out]# 276   58  2018-08-27   0.55
#[Out]# 277  169  2018-08-27   0.55
#[Out]# 278   13  2018-08-27   0.50
#[Out]# 279   55  2018-08-17   0.50
#[Out]# 280    0  2018-08-22   0.45
#[Out]# 281   22  2018-08-28   0.45
#[Out]# 282   77  2018-08-23   0.45
#[Out]# 283  179  2018-08-23   0.45
#[Out]# 284   72  2018-08-21   0.40
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Mon, 07 Dec 2020 10:43:43
query4_4 = '''

select cID, price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  price
#[Out]# 0  161   39.1
# Mon, 07 Dec 2020 10:43:56
query4_4 = '''

select price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    price
#[Out]# 0   39.1
# Mon, 07 Dec 2020 10:46:14
query4_4 = '''

with maxprice (value) as (
select price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1
)

select cID, date
from purchase, maxprice
group by cID, date
having sum(price) > (0.75 * maxprice.value)



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date
#[Out]# 0  161  2018-08-26
# Mon, 07 Dec 2020 10:47:07
query4_4 = '''

with maxprice (value) as (
select price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1
)

select cID, date, maxprice.value
from purchase, maxprice
group by cID, date



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  value
#[Out]# 0      0  2018-08-22   39.1
#[Out]# 1      1  2018-08-20   39.1
#[Out]# 2      1  2018-08-21   39.1
#[Out]# 3      2  2018-08-16   39.1
#[Out]# 4      2  2018-08-17   39.1
#[Out]# 5      3  2018-08-18   39.1
#[Out]# 6      3  2018-08-19   39.1
#[Out]# 7      4  2018-08-24   39.1
#[Out]# 8      4  2018-08-25   39.1
#[Out]# 9      5  2018-08-17   39.1
#[Out]# 10     5  2018-08-22   39.1
#[Out]# 11     5  2018-08-23   39.1
#[Out]# 12     7  2018-08-23   39.1
#[Out]# 13     7  2018-08-24   39.1
#[Out]# 14     7  2018-08-25   39.1
#[Out]# 15     7  2018-08-26   39.1
#[Out]# 16     8  2018-08-16   39.1
#[Out]# 17    10  2018-08-27   39.1
#[Out]# 18    11  2018-08-25   39.1
#[Out]# 19    13  2018-08-17   39.1
#[Out]# 20    13  2018-08-25   39.1
#[Out]# 21    13  2018-08-26   39.1
#[Out]# 22    13  2018-08-27   39.1
#[Out]# 23    15  2018-08-27   39.1
#[Out]# 24    16  2018-08-18   39.1
#[Out]# 25    16  2018-08-19   39.1
#[Out]# 26    16  2018-08-24   39.1
#[Out]# 27    16  2018-08-25   39.1
#[Out]# 28    16  2018-08-26   39.1
#[Out]# 29    16  2018-08-27   39.1
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   39.1
#[Out]# 256  179  2018-08-22   39.1
#[Out]# 257  179  2018-08-23   39.1
#[Out]# 258  179  2018-08-24   39.1
#[Out]# 259  180  2018-08-26   39.1
#[Out]# 260  180  2018-08-27   39.1
#[Out]# 261  181  2018-08-24   39.1
#[Out]# 262  181  2018-08-27   39.1
#[Out]# 263  182  2018-08-23   39.1
#[Out]# 264  182  2018-08-28   39.1
#[Out]# 265  184  2018-08-20   39.1
#[Out]# 266  185  2018-08-20   39.1
#[Out]# 267  186  2018-08-21   39.1
#[Out]# 268  188  2018-08-20   39.1
#[Out]# 269  188  2018-09-20   39.1
#[Out]# 270  189  2018-08-25   39.1
#[Out]# 271  189  2018-08-26   39.1
#[Out]# 272  190  2018-08-15   39.1
#[Out]# 273  190  2018-08-16   39.1
#[Out]# 274  190  2018-08-17   39.1
#[Out]# 275  190  2018-08-18   39.1
#[Out]# 276  190  2018-08-19   39.1
#[Out]# 277  190  2018-08-20   39.1
#[Out]# 278  190  2018-08-21   39.1
#[Out]# 279  190  2018-08-22   39.1
#[Out]# 280  190  2018-08-23   39.1
#[Out]# 281  190  2018-08-24   39.1
#[Out]# 282  190  2018-08-25   39.1
#[Out]# 283  190  2018-08-26   39.1
#[Out]# 284  190  2018-08-27   39.1
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Mon, 07 Dec 2020 10:47:25
query4_4 = '''

with maxprice (value) as (
select price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1
)

select cID, date, sum(price), maxprice.value
from purchase, maxprice
group by cID, date



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sum(price)  value
#[Out]# 0      0  2018-08-22        0.45   39.1
#[Out]# 1      1  2018-08-20       14.20   39.1
#[Out]# 2      1  2018-08-21       10.00   39.1
#[Out]# 3      2  2018-08-16        2.45   39.1
#[Out]# 4      2  2018-08-17        7.70   39.1
#[Out]# 5      3  2018-08-18        4.30   39.1
#[Out]# 6      3  2018-08-19        4.20   39.1
#[Out]# 7      4  2018-08-24       14.25   39.1
#[Out]# 8      4  2018-08-25       19.40   39.1
#[Out]# 9      5  2018-08-17        4.70   39.1
#[Out]# 10     5  2018-08-22        8.25   39.1
#[Out]# 11     5  2018-08-23        6.70   39.1
#[Out]# 12     7  2018-08-23        3.80   39.1
#[Out]# 13     7  2018-08-24        1.90   39.1
#[Out]# 14     7  2018-08-25       10.75   39.1
#[Out]# 15     7  2018-08-26        3.10   39.1
#[Out]# 16     8  2018-08-16        6.25   39.1
#[Out]# 17    10  2018-08-27        3.20   39.1
#[Out]# 18    11  2018-08-25        4.10   39.1
#[Out]# 19    13  2018-08-17       13.30   39.1
#[Out]# 20    13  2018-08-25        6.50   39.1
#[Out]# 21    13  2018-08-26        1.65   39.1
#[Out]# 22    13  2018-08-27        0.50   39.1
#[Out]# 23    15  2018-08-27        0.90   39.1
#[Out]# 24    16  2018-08-18        2.90   39.1
#[Out]# 25    16  2018-08-19       11.05   39.1
#[Out]# 26    16  2018-08-24        6.05   39.1
#[Out]# 27    16  2018-08-25        4.95   39.1
#[Out]# 28    16  2018-08-26        3.00   39.1
#[Out]# 29    16  2018-08-27        1.85   39.1
#[Out]# ..   ...         ...         ...    ...
#[Out]# 255  178  2018-08-27        7.50   39.1
#[Out]# 256  179  2018-08-22       10.85   39.1
#[Out]# 257  179  2018-08-23        0.45   39.1
#[Out]# 258  179  2018-08-24        6.95   39.1
#[Out]# 259  180  2018-08-26        3.10   39.1
#[Out]# 260  180  2018-08-27        4.65   39.1
#[Out]# 261  181  2018-08-24        3.60   39.1
#[Out]# 262  181  2018-08-27        2.00   39.1
#[Out]# 263  182  2018-08-23        4.20   39.1
#[Out]# 264  182  2018-08-28       14.90   39.1
#[Out]# 265  184  2018-08-20        3.50   39.1
#[Out]# 266  185  2018-08-20        1.00   39.1
#[Out]# 267  186  2018-08-21        1.00   39.1
#[Out]# 268  188  2018-08-20        1.00   39.1
#[Out]# 269  188  2018-09-20        1.00   39.1
#[Out]# 270  189  2018-08-25        1.25   39.1
#[Out]# 271  189  2018-08-26        2.50   39.1
#[Out]# 272  190  2018-08-15       19.60   39.1
#[Out]# 273  190  2018-08-16       12.80   39.1
#[Out]# 274  190  2018-08-17       15.75   39.1
#[Out]# 275  190  2018-08-18       14.85   39.1
#[Out]# 276  190  2018-08-19       20.30   39.1
#[Out]# 277  190  2018-08-20       10.85   39.1
#[Out]# 278  190  2018-08-21        3.85   39.1
#[Out]# 279  190  2018-08-22       14.55   39.1
#[Out]# 280  190  2018-08-23       10.60   39.1
#[Out]# 281  190  2018-08-24        3.25   39.1
#[Out]# 282  190  2018-08-25        9.80   39.1
#[Out]# 283  190  2018-08-26       21.90   39.1
#[Out]# 284  190  2018-08-27        5.55   39.1
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Mon, 07 Dec 2020 10:50:24
query4_4 = '''

with maxprice (value) as (
select price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1
)

select cID, date, sum(price), maxprice.value
from purchase, maxprice
group by cID, date
having sum(price) > (maxprice.value * 0.75)



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  sum(price)  value
#[Out]# 0  161  2018-08-26        39.1   39.1
# Mon, 07 Dec 2020 10:50:41
query4_4 = '''

with maxprice (value) as (
select price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1
)

select cID, date, sum(price), maxprice.value * 0.75
from purchase, maxprice
group by cID, date



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sum(price)  maxprice.value * 0.75
#[Out]# 0      0  2018-08-22        0.45                 29.325
#[Out]# 1      1  2018-08-20       14.20                 29.325
#[Out]# 2      1  2018-08-21       10.00                 29.325
#[Out]# 3      2  2018-08-16        2.45                 29.325
#[Out]# 4      2  2018-08-17        7.70                 29.325
#[Out]# 5      3  2018-08-18        4.30                 29.325
#[Out]# 6      3  2018-08-19        4.20                 29.325
#[Out]# 7      4  2018-08-24       14.25                 29.325
#[Out]# 8      4  2018-08-25       19.40                 29.325
#[Out]# 9      5  2018-08-17        4.70                 29.325
#[Out]# 10     5  2018-08-22        8.25                 29.325
#[Out]# 11     5  2018-08-23        6.70                 29.325
#[Out]# 12     7  2018-08-23        3.80                 29.325
#[Out]# 13     7  2018-08-24        1.90                 29.325
#[Out]# 14     7  2018-08-25       10.75                 29.325
#[Out]# 15     7  2018-08-26        3.10                 29.325
#[Out]# 16     8  2018-08-16        6.25                 29.325
#[Out]# 17    10  2018-08-27        3.20                 29.325
#[Out]# 18    11  2018-08-25        4.10                 29.325
#[Out]# 19    13  2018-08-17       13.30                 29.325
#[Out]# 20    13  2018-08-25        6.50                 29.325
#[Out]# 21    13  2018-08-26        1.65                 29.325
#[Out]# 22    13  2018-08-27        0.50                 29.325
#[Out]# 23    15  2018-08-27        0.90                 29.325
#[Out]# 24    16  2018-08-18        2.90                 29.325
#[Out]# 25    16  2018-08-19       11.05                 29.325
#[Out]# 26    16  2018-08-24        6.05                 29.325
#[Out]# 27    16  2018-08-25        4.95                 29.325
#[Out]# 28    16  2018-08-26        3.00                 29.325
#[Out]# 29    16  2018-08-27        1.85                 29.325
#[Out]# ..   ...         ...         ...                    ...
#[Out]# 255  178  2018-08-27        7.50                 29.325
#[Out]# 256  179  2018-08-22       10.85                 29.325
#[Out]# 257  179  2018-08-23        0.45                 29.325
#[Out]# 258  179  2018-08-24        6.95                 29.325
#[Out]# 259  180  2018-08-26        3.10                 29.325
#[Out]# 260  180  2018-08-27        4.65                 29.325
#[Out]# 261  181  2018-08-24        3.60                 29.325
#[Out]# 262  181  2018-08-27        2.00                 29.325
#[Out]# 263  182  2018-08-23        4.20                 29.325
#[Out]# 264  182  2018-08-28       14.90                 29.325
#[Out]# 265  184  2018-08-20        3.50                 29.325
#[Out]# 266  185  2018-08-20        1.00                 29.325
#[Out]# 267  186  2018-08-21        1.00                 29.325
#[Out]# 268  188  2018-08-20        1.00                 29.325
#[Out]# 269  188  2018-09-20        1.00                 29.325
#[Out]# 270  189  2018-08-25        1.25                 29.325
#[Out]# 271  189  2018-08-26        2.50                 29.325
#[Out]# 272  190  2018-08-15       19.60                 29.325
#[Out]# 273  190  2018-08-16       12.80                 29.325
#[Out]# 274  190  2018-08-17       15.75                 29.325
#[Out]# 275  190  2018-08-18       14.85                 29.325
#[Out]# 276  190  2018-08-19       20.30                 29.325
#[Out]# 277  190  2018-08-20       10.85                 29.325
#[Out]# 278  190  2018-08-21        3.85                 29.325
#[Out]# 279  190  2018-08-22       14.55                 29.325
#[Out]# 280  190  2018-08-23       10.60                 29.325
#[Out]# 281  190  2018-08-24        3.25                 29.325
#[Out]# 282  190  2018-08-25        9.80                 29.325
#[Out]# 283  190  2018-08-26       21.90                 29.325
#[Out]# 284  190  2018-08-27        5.55                 29.325
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Mon, 07 Dec 2020 10:50:54
query4_4 = '''

with maxprice (value) as (
select price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1
)

select cID, date, sum(price), maxprice.value * 0.75 as perc
from purchase, maxprice
group by cID, date



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sum(price)    perc
#[Out]# 0      0  2018-08-22        0.45  29.325
#[Out]# 1      1  2018-08-20       14.20  29.325
#[Out]# 2      1  2018-08-21       10.00  29.325
#[Out]# 3      2  2018-08-16        2.45  29.325
#[Out]# 4      2  2018-08-17        7.70  29.325
#[Out]# 5      3  2018-08-18        4.30  29.325
#[Out]# 6      3  2018-08-19        4.20  29.325
#[Out]# 7      4  2018-08-24       14.25  29.325
#[Out]# 8      4  2018-08-25       19.40  29.325
#[Out]# 9      5  2018-08-17        4.70  29.325
#[Out]# 10     5  2018-08-22        8.25  29.325
#[Out]# 11     5  2018-08-23        6.70  29.325
#[Out]# 12     7  2018-08-23        3.80  29.325
#[Out]# 13     7  2018-08-24        1.90  29.325
#[Out]# 14     7  2018-08-25       10.75  29.325
#[Out]# 15     7  2018-08-26        3.10  29.325
#[Out]# 16     8  2018-08-16        6.25  29.325
#[Out]# 17    10  2018-08-27        3.20  29.325
#[Out]# 18    11  2018-08-25        4.10  29.325
#[Out]# 19    13  2018-08-17       13.30  29.325
#[Out]# 20    13  2018-08-25        6.50  29.325
#[Out]# 21    13  2018-08-26        1.65  29.325
#[Out]# 22    13  2018-08-27        0.50  29.325
#[Out]# 23    15  2018-08-27        0.90  29.325
#[Out]# 24    16  2018-08-18        2.90  29.325
#[Out]# 25    16  2018-08-19       11.05  29.325
#[Out]# 26    16  2018-08-24        6.05  29.325
#[Out]# 27    16  2018-08-25        4.95  29.325
#[Out]# 28    16  2018-08-26        3.00  29.325
#[Out]# 29    16  2018-08-27        1.85  29.325
#[Out]# ..   ...         ...         ...     ...
#[Out]# 255  178  2018-08-27        7.50  29.325
#[Out]# 256  179  2018-08-22       10.85  29.325
#[Out]# 257  179  2018-08-23        0.45  29.325
#[Out]# 258  179  2018-08-24        6.95  29.325
#[Out]# 259  180  2018-08-26        3.10  29.325
#[Out]# 260  180  2018-08-27        4.65  29.325
#[Out]# 261  181  2018-08-24        3.60  29.325
#[Out]# 262  181  2018-08-27        2.00  29.325
#[Out]# 263  182  2018-08-23        4.20  29.325
#[Out]# 264  182  2018-08-28       14.90  29.325
#[Out]# 265  184  2018-08-20        3.50  29.325
#[Out]# 266  185  2018-08-20        1.00  29.325
#[Out]# 267  186  2018-08-21        1.00  29.325
#[Out]# 268  188  2018-08-20        1.00  29.325
#[Out]# 269  188  2018-09-20        1.00  29.325
#[Out]# 270  189  2018-08-25        1.25  29.325
#[Out]# 271  189  2018-08-26        2.50  29.325
#[Out]# 272  190  2018-08-15       19.60  29.325
#[Out]# 273  190  2018-08-16       12.80  29.325
#[Out]# 274  190  2018-08-17       15.75  29.325
#[Out]# 275  190  2018-08-18       14.85  29.325
#[Out]# 276  190  2018-08-19       20.30  29.325
#[Out]# 277  190  2018-08-20       10.85  29.325
#[Out]# 278  190  2018-08-21        3.85  29.325
#[Out]# 279  190  2018-08-22       14.55  29.325
#[Out]# 280  190  2018-08-23       10.60  29.325
#[Out]# 281  190  2018-08-24        3.25  29.325
#[Out]# 282  190  2018-08-25        9.80  29.325
#[Out]# 283  190  2018-08-26       21.90  29.325
#[Out]# 284  190  2018-08-27        5.55  29.325
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Mon, 07 Dec 2020 10:51:10
query4_4 = '''

with maxprice (value) as (
select price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1
)

select cID, date, sum(price), maxprice.value * 0.75 as perc
from purchase, maxprice
group by cID, date
having sum(price) > perc


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  sum(price)    perc
#[Out]# 0  161  2018-08-26        39.1  29.325
# Mon, 07 Dec 2020 10:51:19
query4_4 = '''

with maxprice (value) as (
select price
from (
    select cID, date, sum(price) as price
    from purchase
    group by cID, date
    order by price desc)
limit 1
)

select cID, date, sum(price), maxprice.value * 0.75 as perc
from purchase, maxprice
group by cID, date
having sum(price) < perc


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sum(price)    perc
#[Out]# 0      0  2018-08-22        0.45  29.325
#[Out]# 1      1  2018-08-20       14.20  29.325
#[Out]# 2      1  2018-08-21       10.00  29.325
#[Out]# 3      2  2018-08-16        2.45  29.325
#[Out]# 4      2  2018-08-17        7.70  29.325
#[Out]# 5      3  2018-08-18        4.30  29.325
#[Out]# 6      3  2018-08-19        4.20  29.325
#[Out]# 7      4  2018-08-24       14.25  29.325
#[Out]# 8      4  2018-08-25       19.40  29.325
#[Out]# 9      5  2018-08-17        4.70  29.325
#[Out]# 10     5  2018-08-22        8.25  29.325
#[Out]# 11     5  2018-08-23        6.70  29.325
#[Out]# 12     7  2018-08-23        3.80  29.325
#[Out]# 13     7  2018-08-24        1.90  29.325
#[Out]# 14     7  2018-08-25       10.75  29.325
#[Out]# 15     7  2018-08-26        3.10  29.325
#[Out]# 16     8  2018-08-16        6.25  29.325
#[Out]# 17    10  2018-08-27        3.20  29.325
#[Out]# 18    11  2018-08-25        4.10  29.325
#[Out]# 19    13  2018-08-17       13.30  29.325
#[Out]# 20    13  2018-08-25        6.50  29.325
#[Out]# 21    13  2018-08-26        1.65  29.325
#[Out]# 22    13  2018-08-27        0.50  29.325
#[Out]# 23    15  2018-08-27        0.90  29.325
#[Out]# 24    16  2018-08-18        2.90  29.325
#[Out]# 25    16  2018-08-19       11.05  29.325
#[Out]# 26    16  2018-08-24        6.05  29.325
#[Out]# 27    16  2018-08-25        4.95  29.325
#[Out]# 28    16  2018-08-26        3.00  29.325
#[Out]# 29    16  2018-08-27        1.85  29.325
#[Out]# ..   ...         ...         ...     ...
#[Out]# 254  178  2018-08-27        7.50  29.325
#[Out]# 255  179  2018-08-22       10.85  29.325
#[Out]# 256  179  2018-08-23        0.45  29.325
#[Out]# 257  179  2018-08-24        6.95  29.325
#[Out]# 258  180  2018-08-26        3.10  29.325
#[Out]# 259  180  2018-08-27        4.65  29.325
#[Out]# 260  181  2018-08-24        3.60  29.325
#[Out]# 261  181  2018-08-27        2.00  29.325
#[Out]# 262  182  2018-08-23        4.20  29.325
#[Out]# 263  182  2018-08-28       14.90  29.325
#[Out]# 264  184  2018-08-20        3.50  29.325
#[Out]# 265  185  2018-08-20        1.00  29.325
#[Out]# 266  186  2018-08-21        1.00  29.325
#[Out]# 267  188  2018-08-20        1.00  29.325
#[Out]# 268  188  2018-09-20        1.00  29.325
#[Out]# 269  189  2018-08-25        1.25  29.325
#[Out]# 270  189  2018-08-26        2.50  29.325
#[Out]# 271  190  2018-08-15       19.60  29.325
#[Out]# 272  190  2018-08-16       12.80  29.325
#[Out]# 273  190  2018-08-17       15.75  29.325
#[Out]# 274  190  2018-08-18       14.85  29.325
#[Out]# 275  190  2018-08-19       20.30  29.325
#[Out]# 276  190  2018-08-20       10.85  29.325
#[Out]# 277  190  2018-08-21        3.85  29.325
#[Out]# 278  190  2018-08-22       14.55  29.325
#[Out]# 279  190  2018-08-23       10.60  29.325
#[Out]# 280  190  2018-08-24        3.25  29.325
#[Out]# 281  190  2018-08-25        9.80  29.325
#[Out]# 282  190  2018-08-26       21.90  29.325
#[Out]# 283  190  2018-08-27        5.55  29.325
#[Out]# 
#[Out]# [284 rows x 4 columns]
# Mon, 07 Dec 2020 10:55:01
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, sum(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Mon, 07 Dec 2020 10:57:02
query4_5 = '''

select p.cID
from purchase p, store s
where p.sID = s.sID and s.city = "Einhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Mon, 07 Dec 2020 10:57:07
query4_5 = '''

select p.cID
from purchase p, store s
where p.sID = s.sID and s.city = "Einhoven"

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Mon, 07 Dec 2020 10:57:17
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, sum(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Mon, 07 Dec 2020 10:57:19
query4_3 = '''
    PUT YOUR QUERY HERE
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 10:57:38
query4_3 = '''
    select *
    from customer
'''

pd.read_sql_query(query4_3, conn)
#[Out]#      cID     cName                street       city
#[Out]# 0      0      Noah             Koestraat    Utrecht
#[Out]# 1      1       Sem      Rozemarijnstraat      Breda
#[Out]# 2      2     Lucas      Oude Leliestraat  Amsterdam
#[Out]# 3      3      Finn         Stationsplein      Breda
#[Out]# 4      4      Daan          Kalverstraat  Amsterdam
#[Out]# 5      5      Levi        Gasthuisstraat    Utrecht
#[Out]# 6      6     Milan           Parallelweg    Utrecht
#[Out]# 7      7      Bram          Schoolstraat  Eindhoven
#[Out]# 8      8      Liam         Rijsbergseweg      Breda
#[Out]# 9      9    Thomas           Parallelweg  Amsterdam
#[Out]# 10    10       Sam           Langestraat    Tilburg
#[Out]# 11    11     Thijs             Koestraat    Tilburg
#[Out]# 12    12      Adam           Nieuwstraat  Eindhoven
#[Out]# 13    13     James       Sint Annastraat      Breda
#[Out]# 14    14       Max             Eikenlaan    Tilburg
#[Out]# 15    15      Noud          Koningshoeve    Tilburg
#[Out]# 16    16    Julian  Prins Bernhardstraat  Eindhoven
#[Out]# 17    17       Dex          Kasteeldreef    Tilburg
#[Out]# 18    18      Hugo          Kasteeldreef    Tilburg
#[Out]# 19    19      Lars         Rijsbergseweg      Breda
#[Out]# 20    20      Gijs            Heiligeweg  Amsterdam
#[Out]# 21    21  Benjamin           Stationsweg    Tilburg
#[Out]# 22    22      Mats           Molenstraat  Eindhoven
#[Out]# 23    23       Jan       Sint Annastraat      Breda
#[Out]# 24    24      Luca          Kasteeldreef    Tilburg
#[Out]# 25    25     Mason          Keizerstraat  Rotterdam
#[Out]# 26    26    Jayden          Schoolstraat  Eindhoven
#[Out]# 27    27       Tim             Koestraat    Utrecht
#[Out]# 28    28      Siem           Langestraat    Tilburg
#[Out]# 29    29     Ruben              Hofplein  Rotterdam
#[Out]# ..   ...       ...                   ...        ...
#[Out]# 160  160      Lara           Langestraat    Tilburg
#[Out]# 161  161     Floor             Eikenlaan    Tilburg
#[Out]# 162  162     Elena            Bergselaan  Rotterdam
#[Out]# 163  163      Cato          Kastanjelaan    Tilburg
#[Out]# 164  164       Evy      Rozemarijnstraat      Breda
#[Out]# 165  165     Hanna             Eikenlaan    Tilburg
#[Out]# 166  166   Rosalie           Stationsweg  Eindhoven
#[Out]# 167  167    Veerle        Ginnekenstraat      Breda
#[Out]# 168  168      Kiki          Keizerstraat  Rotterdam
#[Out]# 169  169      Lily        Gasthuisstraat    Utrecht
#[Out]# 170  170      Iris          Kastanjelaan  Eindhoven
#[Out]# 171  171     Tessa           Haringvliet  Rotterdam
#[Out]# 172  172      Lana             Eikenlaan    Tilburg
#[Out]# 173  173     Livia      Vierwindenstraat      Breda
#[Out]# 174  174      Romy           Parallelweg  Eindhoven
#[Out]# 175  175       Sam             Bredalaan  Eindhoven
#[Out]# 176  176     Amira           Parallelweg  Amsterdam
#[Out]# 177  177     Eline          Kalverstraat  Amsterdam
#[Out]# 178  178      Elif           Parallelweg    Utrecht
#[Out]# 179  179      Juul        Wilhelminapark    Tilburg
#[Out]# 180  180     Merel          Kalverstraat  Amsterdam
#[Out]# 181  181      Liva           Fredriklaan  Eindhoven
#[Out]# 182  182   Johanna         Beatrixstraat  Eindhoven
#[Out]# 183  183     Nikki         Julianastraat    Utrecht
#[Out]# 184  184     Wilko          Onbekendeweg  Eindhoven
#[Out]# 185  185      Nick                Verweg  Eindhoven
#[Out]# 186  186    Angela              Dichtweg  Eindhoven
#[Out]# 187  188      Pino            Maanstraat  Rotterdam
#[Out]# 188  189      Koen              Akkerweg        Oss
#[Out]# 189  190    Kostas              Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Mon, 07 Dec 2020 10:57:49
query4_3 = '''

'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 10:57:51
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, sum(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Mon, 07 Dec 2020 10:57:54
query4_5 = '''

select p.cID
from purchase p, store s
where p.sID = s.sID and s.city = "Einhoven"

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Mon, 07 Dec 2020 10:58:02
query4_5 = '''

select p.cID
from purchase p, store s
where p.sID = s.sID and s.city = "Eindhoven"

'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# 5      4
#[Out]# 6      4
#[Out]# 7      5
#[Out]# 8      5
#[Out]# 9      5
#[Out]# 10     7
#[Out]# 11    13
#[Out]# 12    13
#[Out]# 13    13
#[Out]# 14    13
#[Out]# 15    13
#[Out]# 16    13
#[Out]# 17    16
#[Out]# 18    24
#[Out]# 19    24
#[Out]# 20    25
#[Out]# 21    27
#[Out]# 22    30
#[Out]# 23    30
#[Out]# 24    31
#[Out]# 25    33
#[Out]# 26    33
#[Out]# 27    33
#[Out]# 28    33
#[Out]# 29    33
#[Out]# ..   ...
#[Out]# 103  169
#[Out]# 104  170
#[Out]# 105  171
#[Out]# 106  176
#[Out]# 107  176
#[Out]# 108  176
#[Out]# 109  178
#[Out]# 110  179
#[Out]# 111  180
#[Out]# 112  182
#[Out]# 113  182
#[Out]# 114  185
#[Out]# 115  186
#[Out]# 116  188
#[Out]# 117  188
#[Out]# 118  190
#[Out]# 119  190
#[Out]# 120  190
#[Out]# 121  190
#[Out]# 122  190
#[Out]# 123  190
#[Out]# 124  190
#[Out]# 125  190
#[Out]# 126  190
#[Out]# 127  190
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Mon, 07 Dec 2020 10:58:53
query4_5 = '''

select p.cID
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID

'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# 5      4
#[Out]# 6      4
#[Out]# 7      5
#[Out]# 8      5
#[Out]# 9      5
#[Out]# 10     7
#[Out]# 11    13
#[Out]# 12    13
#[Out]# 13    13
#[Out]# 14    13
#[Out]# 15    13
#[Out]# 16    13
#[Out]# 17    16
#[Out]# 18    24
#[Out]# 19    24
#[Out]# 20    25
#[Out]# 21    27
#[Out]# 22    30
#[Out]# 23    30
#[Out]# 24    31
#[Out]# 25    33
#[Out]# 26    33
#[Out]# 27    33
#[Out]# 28    33
#[Out]# 29    33
#[Out]# ..   ...
#[Out]# 103  169
#[Out]# 104  170
#[Out]# 105  171
#[Out]# 106  176
#[Out]# 107  176
#[Out]# 108  176
#[Out]# 109  178
#[Out]# 110  179
#[Out]# 111  180
#[Out]# 112  182
#[Out]# 113  182
#[Out]# 114  185
#[Out]# 115  186
#[Out]# 116  188
#[Out]# 117  188
#[Out]# 118  190
#[Out]# 119  190
#[Out]# 120  190
#[Out]# 121  190
#[Out]# 122  190
#[Out]# 123  190
#[Out]# 124  190
#[Out]# 125  190
#[Out]# 126  190
#[Out]# 127  190
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Mon, 07 Dec 2020 10:59:51
query4_5 = '''

select distinct c.city, count(c.cID)
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(c.cID)
#[Out]# 0  Amsterdam            17
#[Out]# 1      Breda            27
#[Out]# 2  Eindhoven            24
#[Out]# 3  Rotterdam            16
#[Out]# 4    Tilburg            18
#[Out]# 5    Utrecht            31
# Mon, 07 Dec 2020 11:00:12
query4_5 = '''

select distinct c.city, count(c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount_customers
#[Out]# 0  Amsterdam                17
#[Out]# 1      Breda                27
#[Out]# 2  Eindhoven                24
#[Out]# 3  Rotterdam                16
#[Out]# 4    Tilburg                18
#[Out]# 5    Utrecht                31
# Mon, 07 Dec 2020 11:01:56
query4_5 = '''



select c.cName
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID and c.city = "Amsterdam"

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cName
#[Out]# 0   Lucas
#[Out]# 1   Lucas
#[Out]# 2    Daan
#[Out]# 3    Daan
#[Out]# 4    Joep
#[Out]# 5     Kai
#[Out]# 6   Sofie
#[Out]# 7   Sofie
#[Out]# 8    Lina
#[Out]# 9    Lina
#[Out]# 10   Ella
#[Out]# 11   Puck
#[Out]# 12   Puck
#[Out]# 13  Amira
#[Out]# 14  Amira
#[Out]# 15  Amira
#[Out]# 16  Merel
# Mon, 07 Dec 2020 11:02:10
query4_5 = '''



select distinct c.cName
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID and c.city = "Amsterdam"

'''

pd.read_sql_query(query4_5, conn)
#[Out]#    cName
#[Out]# 0  Lucas
#[Out]# 1   Daan
#[Out]# 2   Joep
#[Out]# 3    Kai
#[Out]# 4  Sofie
#[Out]# 5   Lina
#[Out]# 6   Ella
#[Out]# 7   Puck
#[Out]# 8  Amira
#[Out]# 9  Merel
# Mon, 07 Dec 2020 11:02:39
query4_5 = '''

select distinct c.city, count(c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city


'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount_customers
#[Out]# 0  Amsterdam                17
#[Out]# 1      Breda                27
#[Out]# 2  Eindhoven                24
#[Out]# 3  Rotterdam                16
#[Out]# 4    Tilburg                18
#[Out]# 5    Utrecht                31
# Mon, 07 Dec 2020 11:02:59
query4_5 = '''

select c.city, count(c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city


'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount_customers
#[Out]# 0  Amsterdam                17
#[Out]# 1      Breda                27
#[Out]# 2  Eindhoven                24
#[Out]# 3  Rotterdam                16
#[Out]# 4    Tilburg                18
#[Out]# 5    Utrecht                31
# Mon, 07 Dec 2020 11:03:17
query4_5 = '''

select distinct count(c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city


'''

pd.read_sql_query(query4_5, conn)
#[Out]#    amount_customers
#[Out]# 0                17
#[Out]# 1                27
#[Out]# 2                24
#[Out]# 3                16
#[Out]# 4                18
#[Out]# 5                31
# Mon, 07 Dec 2020 11:03:35
query4_5 = '''

select c.city, count( distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city


'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount_customers
#[Out]# 0  Amsterdam                10
#[Out]# 1      Breda                 9
#[Out]# 2  Eindhoven                15
#[Out]# 3  Rotterdam                13
#[Out]# 4    Tilburg                10
#[Out]# 5    Utrecht                12

# IPython log file

# Tue, 08 Dec 2020 21:22:06
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 21:22:06
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 08 Dec 2020 21:22:11
query4_3 = '''
select city
from customer

union 

select city 
from store 
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 21:22:19
query4_3 = '''
select city
from customer

union 

select city 
from store 
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 21:23:13
query4_3 = '''
select c.city
from customer c

union 

select s.city 
from store s
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 21:24:20
query4_3 = '''
select sName, city
from store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 21:44:32
query4_3 = '''
with 	allCities (city) as 		(select city
					from customer
					union 
					select city 
					from store ),
	possible (sName, city) as	(select sName, city
					from store, allCities),
	actual(sName, city) as 		(select sName, city
					from store),
	missing(sName, city) as 	(select sName, city
					from possible
					where sName, city not in actual)
select sName, city
from store
where sName, city not in (select * from missing)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:46:42
query4_3 = '''
with    allCities (city) as ((select city from customer) union (select city from store)),
        possible (sName, city) as(select sName, city from store, allCities),
        actual(sName, city) as (select sName, city from store),
        missing(sName, city) as (select sName, city from possible where sName, city not in actual)
        
select sName, city
from store
where sName, city not in (select * from missing)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:47:36
query4_3 = '''
with    allCities (city) as ((select city from customer) union (select city from store)),
        possible (sName, city) as(select sName, city from store, allCities),
        actual(sName, city) as (select sName, city from store),
        missing(sName, city) as (select sName, city from possible where (sName, city) not in actual)
        
select sName, city
from store
where sName, city not in (select * from missing)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:47:53
query4_3 = '''
with    allCities (city) as ((select city from customer) union (select city from store)),
        possible (sName, city) as (select (sName, city) from (store, allCities),
        actual(sName, city) as (select sName, city from store),
        missing(sName, city) as (select sName, city from possible where (sName, city) not in actual)
        
select sName, city
from store
where sName, city not in (select * from missing)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:48:05
query4_3 = '''
with    allCities (city) as ((select city from customer) union (select city from store)),
        possible (sName, city) as (select (sName, city) from (store, allCities),
        actual(sName, city) as (select (sName, city) from store),
        missing(sName, city) as (select (sName, city) from possible where (sName, city) not in actual)
        
select sName, city
from store
where sName, city not in (select * from missing)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:48:45
query4_3 = '''
with    allCities (city) as ((select city from customer) union (select city from store)),
        possible (sName, city) as (select (sName, city) from (store, allCities),
        actual(sName, city) as (select (sName, city) from store),
        missing(sName, city) as (select (sName, city) from possible where (sName, city) not in actual)
        
select sName, city
from store
where (sName, city) not in (select * from missing)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:48:51
query4_3 = '''
with    allCities (city) as ((select city from customer) union (select city from store)),
        possible (sName, city) as (select (sName, city) from (store, allCities),
        actual(sName, city) as (select (sName, city) from store),
        missing(sName, city) as (select (sName, city) from possible where (sName, city) not in actual)
        
select (sName, city)
from store
where (sName, city) not in (select * from missing)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:48:53
query4_3 = '''
with    allCities (city) as ((select city from customer) union (select city from store)),
        possible (sName, city) as (select (sName, city) from (store, allCities),
        actual(sName, city) as (select (sName, city) from store),
        missing(sName, city) as (select (sName, city) from possible where (sName, city) not in actual)
        
select (sName, city)
from store
where (sName, city) not in (select * from missing)

'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:48:56
query4_3 = '''
with    allCities (city) as ((select city from customer) union (select city from store)),
        possible (sName, city) as (select (sName, city) from (store, allCities),
        actual(sName, city) as (select (sName, city) from store),
        missing(sName, city) as (select (sName, city) from possible where (sName, city) not in actual)
        
select (sName, city)
from store
where (sName, city) not in (select * from missing);

'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:52:14
query4_3 = '''
    with    allCities (city) as (   select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select sName, city 
                                    from store, allCities),
        actual(sName, city) as (    select sName, city
                                    from store),
        missing(sName, city) as (   select sName, city 
                                    from possible 
                                    where (sName, city) not in actual)
        
select (sName, city)
from store
where (sName, city) not in (select * from missing);

'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:53:15
query4_3 = '''
with    allCities (city) as (       select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select sName, city 
                                    from store, allCities),
        actual(sName, city) as (    select sName, city
                                    from store),
        missing(sName, city) as (   select sName, city 
                                    from possible 
                                    where (sName, city) not in actual)


'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:53:53
query4_3 = '''
with    allCities (city) as (       select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select sName, city 
                                    from store, allCities),
        actual(sName, city) as (    select sName, city
                                    from store),
        missing(sName, city) as (   select sName, city 
                                    from possible 
                                    where (sName, city) not in actual)

select sName, city
from store

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 21:54:21
query4_3 = '''
with    allCities (city) as (       select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select sName, city 
                                    from store, allCities),
        actual(sName, city) as (    select sName, city
                                    from store),
        missing(sName, city) as (   select sName, city 
                                    from possible 
                                    where (sName, city) not in actual)

select sName, city
from store
where sName, city not in (select * from missing)

'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:54:34
query4_3 = '''
with    allCities (city) as (       select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select sName, city 
                                    from store, allCities),
        actual(sName, city) as (    select sName, city
                                    from store),
        missing(sName, city) as (   select sName, city 
                                    from possible 
                                    where (sName, city) not in actual)

select *
from missing

'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:56:48
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)


'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:57:09
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select *
from missing


'''

pd.read_sql_query(query4_3, conn)
#[Out]#       store_name       city
#[Out]# 0           Coop  Eindhoven
#[Out]# 1           Coop        Oss
#[Out]# 2      Hoogvliet  Amsterdam
#[Out]# 3      Hoogvliet        Oss
#[Out]# 4      Hoogvliet    Utrecht
#[Out]# 5          Jumbo  Amsterdam
#[Out]# 6          Jumbo    Utrecht
#[Out]# 7         Sligro        Oss
#[Out]# 8         Sligro    Utrecht
#[Out]# 9      Hoogvliet  Amsterdam
#[Out]# 10     Hoogvliet        Oss
#[Out]# 11     Hoogvliet    Utrecht
#[Out]# 12        Sligro        Oss
#[Out]# 13        Sligro    Utrecht
#[Out]# 14          Coop  Eindhoven
#[Out]# 15          Coop        Oss
#[Out]# 16        Sligro        Oss
#[Out]# 17        Sligro    Utrecht
#[Out]# 18   Albert Hein  Amsterdam
#[Out]# 19   Albert Hein        Oss
#[Out]# 20   Albert Hein  Amsterdam
#[Out]# 21   Albert Hein        Oss
#[Out]# 22         Jumbo  Amsterdam
#[Out]# 23         Jumbo    Utrecht
#[Out]# 24   Albert Hein  Amsterdam
#[Out]# 25   Albert Hein        Oss
#[Out]# 26          Lidl        Oss
#[Out]# 27          Lidl    Tilburg
#[Out]# 28          Coop  Eindhoven
#[Out]# 29          Coop        Oss
#[Out]# ..           ...        ...
#[Out]# 119         Lidl        Oss
#[Out]# 120         Lidl    Tilburg
#[Out]# 121         Coop  Eindhoven
#[Out]# 122         Coop        Oss
#[Out]# 123         Dirk  Amsterdam
#[Out]# 124         Dirk        Oss
#[Out]# 125         Dirk    Tilburg
#[Out]# 126         Dirk    Utrecht
#[Out]# 127         Coop  Eindhoven
#[Out]# 128         Coop        Oss
#[Out]# 129        Jumbo  Amsterdam
#[Out]# 130        Jumbo    Utrecht
#[Out]# 131         Dirk  Amsterdam
#[Out]# 132         Dirk        Oss
#[Out]# 133         Dirk    Tilburg
#[Out]# 134         Dirk    Utrecht
#[Out]# 135         Dirk  Amsterdam
#[Out]# 136         Dirk        Oss
#[Out]# 137         Dirk    Tilburg
#[Out]# 138         Dirk    Utrecht
#[Out]# 139        Jumbo  Amsterdam
#[Out]# 140        Jumbo    Utrecht
#[Out]# 141         Lidl        Oss
#[Out]# 142         Lidl    Tilburg
#[Out]# 143         Lidl        Oss
#[Out]# 144         Lidl    Tilburg
#[Out]# 145        Jumbo  Amsterdam
#[Out]# 146        Jumbo    Utrecht
#[Out]# 147        Jumbo  Amsterdam
#[Out]# 148        Jumbo    Utrecht
#[Out]# 
#[Out]# [149 rows x 2 columns]
# Tue, 08 Dec 2020 21:58:05
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
select s.sName, s.city
from store s
where s.sName, s.city not in (  select *
                                from missing)



'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:58:14
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
select s.sName, s.city
from store s
where (s.sName, s.city) not in (  select *
                                from missing)



'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 21:58:24
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select s.sName, s.city
from store s
where (s.sName, s.city) not in (  select *
                                from missing)



'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 22:01:06
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select s.sName, s.city
from store s
where (s.sName, s.city) not in (  select *
                                from missing)

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 22:04:38
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, sum(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:06:21
query4_5 = '''

select city, 0
from store
group by city

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:06:24
query4_5 = '''

select city, 0
from store
group by city

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city   0
#[Out]# 0   Amsterdam   0
#[Out]# 1   Amsterdam  10
#[Out]# 2       Breda   0
#[Out]# 3       Breda   9
#[Out]# 4   Eindhoven   0
#[Out]# 5   Eindhoven  15
#[Out]# 6         Oss   0
#[Out]# 7   Rotterdam   0
#[Out]# 8   Rotterdam  13
#[Out]# 9     Tilburg   0
#[Out]# 10    Tilburg  10
#[Out]# 11    Utrecht   0
#[Out]# 12    Utrecht  12
# Tue, 08 Dec 2020 22:06:42
query4_5 = '''

select distinct city, 0
from store
group by city

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city   0
#[Out]# 0   Amsterdam   0
#[Out]# 1   Amsterdam  10
#[Out]# 2       Breda   0
#[Out]# 3       Breda   9
#[Out]# 4   Eindhoven   0
#[Out]# 5   Eindhoven  15
#[Out]# 6         Oss   0
#[Out]# 7   Rotterdam   0
#[Out]# 8   Rotterdam  13
#[Out]# 9     Tilburg   0
#[Out]# 10    Tilburg  10
#[Out]# 11    Utrecht   0
#[Out]# 12    Utrecht  12
# Tue, 08 Dec 2020 22:07:10
query4_5 = '''

select distinct city
from (
select distinct city, 0
from store
group by city

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city)

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 22:07:22
query4_5 = '''

select distinct city, count
from (
select distinct city, 0
from store
group by city

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city)

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:07:33
query4_5 = '''

select distinct city, 0
from store
group by city

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city   0
#[Out]# 0   Amsterdam   0
#[Out]# 1   Amsterdam  10
#[Out]# 2       Breda   0
#[Out]# 3       Breda   9
#[Out]# 4   Eindhoven   0
#[Out]# 5   Eindhoven  15
#[Out]# 6         Oss   0
#[Out]# 7   Rotterdam   0
#[Out]# 8   Rotterdam  13
#[Out]# 9     Tilburg   0
#[Out]# 10    Tilburg  10
#[Out]# 11    Utrecht   0
#[Out]# 12    Utrecht  12
# Tue, 08 Dec 2020 22:08:24
query4_5 = '''

select distinct city, 0
from store
group by city
where city not in ( select c.city, count(distinct c.cID) as amount_customers
                    from purchase p, store s, customer c
                    where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                    group by c.city)

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:08:35
query4_5 = '''

select distinct city, 0
from store
where city not in ( select c.city, count(distinct c.cID) as amount_customers
                    from purchase p, store s, customer c
                    where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                    group by c.city)

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:08:43
query4_5 = '''

select distinct city
from store
where city not in ( select c.city, count(distinct c.cID) as amount_customers
                    from purchase p, store s, customer c
                    where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                    group by c.city)

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:08:53
query4_5 = '''

select city
from store
where city not in ( select c.city, count(distinct c.cID) as amount_customers
                    from purchase p, store s, customer c
                    where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                    group by c.city)

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:09:01
query4_5 = '''

select city
from store

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:09:10
query4_5 = '''

select city, 0
from store

union

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city   0
#[Out]# 0   Amsterdam   0
#[Out]# 1   Amsterdam  10
#[Out]# 2       Breda   0
#[Out]# 3       Breda   9
#[Out]# 4   Eindhoven   0
#[Out]# 5   Eindhoven  15
#[Out]# 6         Oss   0
#[Out]# 7   Rotterdam   0
#[Out]# 8   Rotterdam  13
#[Out]# 9     Tilburg   0
#[Out]# 10    Tilburg  10
#[Out]# 11    Utrecht   0
#[Out]# 12    Utrecht  12
# Tue, 08 Dec 2020 22:09:30
query4_5 = '''

select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount_customers
#[Out]# 0  Amsterdam                10
#[Out]# 1      Breda                 9
#[Out]# 2  Eindhoven                15
#[Out]# 3  Rotterdam                13
#[Out]# 4    Tilburg                10
#[Out]# 5    Utrecht                12
# Tue, 08 Dec 2020 22:10:26
query4_5 = '''
with citieswithcust as (select c.city, count(distinct c.cID) as amount_customers
                        from purchase p, store s, customer c
                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                        group by c.city)
                        
select city 
from store
where city not in citieswithcust

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:10:34
query4_5 = '''
with citieswithcust as (select c.city, count(distinct c.cID) as amount_customers
                        from purchase p, store s, customer c
                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                        group by c.city)
                        
select city, 0
from store
where city not in citieswithcust

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:10:51
query4_5 = '''
with citieswithcust as (select c.city, count(distinct c.cID) as amount_customers
                        from purchase p, store s, customer c
                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                        group by c.city)
                        
select s.city, 0
from store s
where s.city not in citieswithcust

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:11:03
query4_5 = '''
with citieswithcust as (select c.city, count(distinct c.cID) as amount_customers
                        from purchase p, store s, customer c
                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                        group by c.city)
                        
select s.city, 0
from store s
where (s.city) not in citieswithcust

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:12:01
query4_5 = '''
with citieswithcust as (select c.city, count(distinct c.cID) as amount_customers
                        from purchase p, store s, customer c
                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                        group by c.city)
                        
select s.city, 0
from store s
group by s.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  0
#[Out]# 0  Amsterdam  0
#[Out]# 1      Breda  0
#[Out]# 2  Eindhoven  0
#[Out]# 3        Oss  0
#[Out]# 4  Rotterdam  0
#[Out]# 5    Tilburg  0
#[Out]# 6    Utrecht  0
# Tue, 08 Dec 2020 22:12:22
query4_5 = '''
with citieswithcust as (select c.city, count(distinct c.cID) as amount_customers
                        from purchase p, store s, customer c
                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                        group by c.city)
                        
select s.city, 0
from store s
group by s.city
having s.city not in citieswithcust

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:12:45
query4_5 = '''
with citieswithcust (city, count) as (select c.city, count(distinct c.cID) as amount_customers
                        from purchase p, store s, customer c
                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                        group by c.city)
                        
select s.city, 0
from store s
group by s.city
having s.city not in citieswithcust

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:12:53
query4_5 = '''
with citieswithcust (city) as (select c.city, count(distinct c.cID) as amount_customers
                        from purchase p, store s, customer c
                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                        group by c.city)
                        
select s.city, 0
from store s
group by s.city
having s.city not in citieswithcust

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:13:32
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, sum(s.sName)
from store s
group by s.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  sum(s.sName)
#[Out]# 0  Amsterdam           0.0
#[Out]# 1      Breda           0.0
#[Out]# 2  Eindhoven           0.0
#[Out]# 3        Oss           0.0
#[Out]# 4  Rotterdam           0.0
#[Out]# 5    Tilburg           0.0
#[Out]# 6    Utrecht           0.0
# Tue, 08 Dec 2020 22:13:41
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, count(s.sName)
from store s
group by s.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(s.sName)
#[Out]# 0  Amsterdam               8
#[Out]# 1      Breda              12
#[Out]# 2  Eindhoven              15
#[Out]# 3        Oss               1
#[Out]# 4  Rotterdam              12
#[Out]# 5    Tilburg               8
#[Out]# 6    Utrecht               8
# Tue, 08 Dec 2020 22:13:58
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, 0
from store s
group by s.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  0
#[Out]# 0  Amsterdam  0
#[Out]# 1      Breda  0
#[Out]# 2  Eindhoven  0
#[Out]# 3        Oss  0
#[Out]# 4  Rotterdam  0
#[Out]# 5    Tilburg  0
#[Out]# 6    Utrecht  0
# Tue, 08 Dec 2020 22:14:18
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, 0
from store s

'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  0
#[Out]# 0   Amsterdam  0
#[Out]# 1       Breda  0
#[Out]# 2   Rotterdam  0
#[Out]# 3   Rotterdam  0
#[Out]# 4   Eindhoven  0
#[Out]# 5       Breda  0
#[Out]# 6   Rotterdam  0
#[Out]# 7   Eindhoven  0
#[Out]# 8   Eindhoven  0
#[Out]# 9     Tilburg  0
#[Out]# 10  Rotterdam  0
#[Out]# 11  Rotterdam  0
#[Out]# 12  Eindhoven  0
#[Out]# 13    Tilburg  0
#[Out]# 14  Amsterdam  0
#[Out]# 15  Amsterdam  0
#[Out]# 16    Utrecht  0
#[Out]# 17  Eindhoven  0
#[Out]# 18    Tilburg  0
#[Out]# 19      Breda  0
#[Out]# 20    Tilburg  0
#[Out]# 21    Tilburg  0
#[Out]# 22  Amsterdam  0
#[Out]# 23      Breda  0
#[Out]# 24      Breda  0
#[Out]# 25      Breda  0
#[Out]# 26      Breda  0
#[Out]# 27  Amsterdam  0
#[Out]# 28    Tilburg  0
#[Out]# 29  Amsterdam  0
#[Out]# ..        ... ..
#[Out]# 34  Amsterdam  0
#[Out]# 35    Utrecht  0
#[Out]# 36  Eindhoven  0
#[Out]# 37  Eindhoven  0
#[Out]# 38  Rotterdam  0
#[Out]# 39  Eindhoven  0
#[Out]# 40  Rotterdam  0
#[Out]# 41  Rotterdam  0
#[Out]# 42  Amsterdam  0
#[Out]# 43    Utrecht  0
#[Out]# 44    Utrecht  0
#[Out]# 45    Tilburg  0
#[Out]# 46  Rotterdam  0
#[Out]# 47  Rotterdam  0
#[Out]# 48    Tilburg  0
#[Out]# 49  Rotterdam  0
#[Out]# 50      Breda  0
#[Out]# 51    Utrecht  0
#[Out]# 52  Eindhoven  0
#[Out]# 53    Utrecht  0
#[Out]# 54  Eindhoven  0
#[Out]# 55      Breda  0
#[Out]# 56  Eindhoven  0
#[Out]# 57  Eindhoven  0
#[Out]# 58  Rotterdam  0
#[Out]# 59      Breda  0
#[Out]# 60      Breda  0
#[Out]# 61      Breda  0
#[Out]# 62  Eindhoven  0
#[Out]# 63        Oss  0
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 22:14:37
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, 0
from store s
where s.city not in citieswithcust

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:14:50
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, 0
from store s
where s.city not in (select * from citieswithcust)

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:15:04
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, 0
from store s
where (s.city, 0) not in (select * from citieswithcust)

'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  0
#[Out]# 0   Amsterdam  0
#[Out]# 1       Breda  0
#[Out]# 2   Rotterdam  0
#[Out]# 3   Rotterdam  0
#[Out]# 4   Eindhoven  0
#[Out]# 5       Breda  0
#[Out]# 6   Rotterdam  0
#[Out]# 7   Eindhoven  0
#[Out]# 8   Eindhoven  0
#[Out]# 9     Tilburg  0
#[Out]# 10  Rotterdam  0
#[Out]# 11  Rotterdam  0
#[Out]# 12  Eindhoven  0
#[Out]# 13    Tilburg  0
#[Out]# 14  Amsterdam  0
#[Out]# 15  Amsterdam  0
#[Out]# 16    Utrecht  0
#[Out]# 17  Eindhoven  0
#[Out]# 18    Tilburg  0
#[Out]# 19      Breda  0
#[Out]# 20    Tilburg  0
#[Out]# 21    Tilburg  0
#[Out]# 22  Amsterdam  0
#[Out]# 23      Breda  0
#[Out]# 24      Breda  0
#[Out]# 25      Breda  0
#[Out]# 26      Breda  0
#[Out]# 27  Amsterdam  0
#[Out]# 28    Tilburg  0
#[Out]# 29  Amsterdam  0
#[Out]# ..        ... ..
#[Out]# 34  Amsterdam  0
#[Out]# 35    Utrecht  0
#[Out]# 36  Eindhoven  0
#[Out]# 37  Eindhoven  0
#[Out]# 38  Rotterdam  0
#[Out]# 39  Eindhoven  0
#[Out]# 40  Rotterdam  0
#[Out]# 41  Rotterdam  0
#[Out]# 42  Amsterdam  0
#[Out]# 43    Utrecht  0
#[Out]# 44    Utrecht  0
#[Out]# 45    Tilburg  0
#[Out]# 46  Rotterdam  0
#[Out]# 47  Rotterdam  0
#[Out]# 48    Tilburg  0
#[Out]# 49  Rotterdam  0
#[Out]# 50      Breda  0
#[Out]# 51    Utrecht  0
#[Out]# 52  Eindhoven  0
#[Out]# 53    Utrecht  0
#[Out]# 54  Eindhoven  0
#[Out]# 55      Breda  0
#[Out]# 56  Eindhoven  0
#[Out]# 57  Eindhoven  0
#[Out]# 58  Rotterdam  0
#[Out]# 59      Breda  0
#[Out]# 60      Breda  0
#[Out]# 61      Breda  0
#[Out]# 62  Eindhoven  0
#[Out]# 63        Oss  0
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 22:15:40
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, c.amount
from store s, citieswithcust c
where (s.city, 0) not in (select * from citieswithcust)

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  amount
#[Out]# 0    Amsterdam      10
#[Out]# 1    Amsterdam       9
#[Out]# 2    Amsterdam      15
#[Out]# 3    Amsterdam      13
#[Out]# 4    Amsterdam      10
#[Out]# 5    Amsterdam      12
#[Out]# 6        Breda      10
#[Out]# 7        Breda       9
#[Out]# 8        Breda      15
#[Out]# 9        Breda      13
#[Out]# 10       Breda      10
#[Out]# 11       Breda      12
#[Out]# 12   Rotterdam      10
#[Out]# 13   Rotterdam       9
#[Out]# 14   Rotterdam      15
#[Out]# 15   Rotterdam      13
#[Out]# 16   Rotterdam      10
#[Out]# 17   Rotterdam      12
#[Out]# 18   Rotterdam      10
#[Out]# 19   Rotterdam       9
#[Out]# 20   Rotterdam      15
#[Out]# 21   Rotterdam      13
#[Out]# 22   Rotterdam      10
#[Out]# 23   Rotterdam      12
#[Out]# 24   Eindhoven      10
#[Out]# 25   Eindhoven       9
#[Out]# 26   Eindhoven      15
#[Out]# 27   Eindhoven      13
#[Out]# 28   Eindhoven      10
#[Out]# 29   Eindhoven      12
#[Out]# ..         ...     ...
#[Out]# 354      Breda      10
#[Out]# 355      Breda       9
#[Out]# 356      Breda      15
#[Out]# 357      Breda      13
#[Out]# 358      Breda      10
#[Out]# 359      Breda      12
#[Out]# 360      Breda      10
#[Out]# 361      Breda       9
#[Out]# 362      Breda      15
#[Out]# 363      Breda      13
#[Out]# 364      Breda      10
#[Out]# 365      Breda      12
#[Out]# 366      Breda      10
#[Out]# 367      Breda       9
#[Out]# 368      Breda      15
#[Out]# 369      Breda      13
#[Out]# 370      Breda      10
#[Out]# 371      Breda      12
#[Out]# 372  Eindhoven      10
#[Out]# 373  Eindhoven       9
#[Out]# 374  Eindhoven      15
#[Out]# 375  Eindhoven      13
#[Out]# 376  Eindhoven      10
#[Out]# 377  Eindhoven      12
#[Out]# 378        Oss      10
#[Out]# 379        Oss       9
#[Out]# 380        Oss      15
#[Out]# 381        Oss      13
#[Out]# 382        Oss      10
#[Out]# 383        Oss      12
#[Out]# 
#[Out]# [384 rows x 2 columns]
# Tue, 08 Dec 2020 22:15:48
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, c.amount
from store s, citieswithcust c
where (s.city, c.amount) not in (select * from citieswithcust)

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  amount
#[Out]# 0    Amsterdam       9
#[Out]# 1    Amsterdam      15
#[Out]# 2    Amsterdam      13
#[Out]# 3    Amsterdam      12
#[Out]# 4        Breda      10
#[Out]# 5        Breda      15
#[Out]# 6        Breda      13
#[Out]# 7        Breda      10
#[Out]# 8        Breda      12
#[Out]# 9    Rotterdam      10
#[Out]# 10   Rotterdam       9
#[Out]# 11   Rotterdam      15
#[Out]# 12   Rotterdam      10
#[Out]# 13   Rotterdam      12
#[Out]# 14   Rotterdam      10
#[Out]# 15   Rotterdam       9
#[Out]# 16   Rotterdam      15
#[Out]# 17   Rotterdam      10
#[Out]# 18   Rotterdam      12
#[Out]# 19   Eindhoven      10
#[Out]# 20   Eindhoven       9
#[Out]# 21   Eindhoven      13
#[Out]# 22   Eindhoven      10
#[Out]# 23   Eindhoven      12
#[Out]# 24       Breda      10
#[Out]# 25       Breda      15
#[Out]# 26       Breda      13
#[Out]# 27       Breda      10
#[Out]# 28       Breda      12
#[Out]# 29   Rotterdam      10
#[Out]# ..         ...     ...
#[Out]# 275  Rotterdam       9
#[Out]# 276  Rotterdam      15
#[Out]# 277  Rotterdam      10
#[Out]# 278  Rotterdam      12
#[Out]# 279      Breda      10
#[Out]# 280      Breda      15
#[Out]# 281      Breda      13
#[Out]# 282      Breda      10
#[Out]# 283      Breda      12
#[Out]# 284      Breda      10
#[Out]# 285      Breda      15
#[Out]# 286      Breda      13
#[Out]# 287      Breda      10
#[Out]# 288      Breda      12
#[Out]# 289      Breda      10
#[Out]# 290      Breda      15
#[Out]# 291      Breda      13
#[Out]# 292      Breda      10
#[Out]# 293      Breda      12
#[Out]# 294  Eindhoven      10
#[Out]# 295  Eindhoven       9
#[Out]# 296  Eindhoven      13
#[Out]# 297  Eindhoven      10
#[Out]# 298  Eindhoven      12
#[Out]# 299        Oss      10
#[Out]# 300        Oss       9
#[Out]# 301        Oss      15
#[Out]# 302        Oss      13
#[Out]# 303        Oss      10
#[Out]# 304        Oss      12
#[Out]# 
#[Out]# [305 rows x 2 columns]
# Tue, 08 Dec 2020 22:16:27
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        
select s.city, c.amount
from store s, citieswithcust c
where (s.city, c.amount) not in (select * from citieswithcust) and s.city = c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, amount]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:16:43
query4_5 = '''
with citieswithcust (city, amount) as ( select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city)
                        

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:16:57
query4_5 = '''
select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city
                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount_customers
#[Out]# 0  Amsterdam                10
#[Out]# 1      Breda                 9
#[Out]# 2  Eindhoven                15
#[Out]# 3  Rotterdam                13
#[Out]# 4    Tilburg                10
#[Out]# 5    Utrecht                12
# Tue, 08 Dec 2020 22:20:30
query4_5 = '''
select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

union 

select s.city
from store s
where s.city not in (select c.city
                    from purchase p, store s, customer c
                    where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                    group by c.city)
                        

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:21:41
query4_5 = '''
select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

union 

select city
from store
                        

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:21:44
query4_5 = '''
select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

union 

select city
from store
                        

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:21:51
query4_5 = '''
select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

union 

select city, 0
from store
                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  amount_customers
#[Out]# 0   Amsterdam                 0
#[Out]# 1   Amsterdam                10
#[Out]# 2       Breda                 0
#[Out]# 3       Breda                 9
#[Out]# 4   Eindhoven                 0
#[Out]# 5   Eindhoven                15
#[Out]# 6         Oss                 0
#[Out]# 7   Rotterdam                 0
#[Out]# 8   Rotterdam                13
#[Out]# 9     Tilburg                 0
#[Out]# 10    Tilburg                10
#[Out]# 11    Utrecht                 0
#[Out]# 12    Utrecht                12
# Tue, 08 Dec 2020 22:22:19
query4_5 = '''
select c.city, count(distinct c.cID) as amount_customers
from purchase p, store s, customer c
where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
group by c.city

intersect 

select city, 0
from store
                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, amount_customers]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:24:22
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )

select c.city, c.amount, s.city
from citieswithcust c, store



                        

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:24:27
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )

select c.city, c.amount, s.city
from citieswithcust c, store s



                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  amount       city
#[Out]# 0    Amsterdam      10  Amsterdam
#[Out]# 1    Amsterdam      10      Breda
#[Out]# 2    Amsterdam      10  Rotterdam
#[Out]# 3    Amsterdam      10  Rotterdam
#[Out]# 4    Amsterdam      10  Eindhoven
#[Out]# 5    Amsterdam      10      Breda
#[Out]# 6    Amsterdam      10  Rotterdam
#[Out]# 7    Amsterdam      10  Eindhoven
#[Out]# 8    Amsterdam      10  Eindhoven
#[Out]# 9    Amsterdam      10    Tilburg
#[Out]# 10   Amsterdam      10  Rotterdam
#[Out]# 11   Amsterdam      10  Rotterdam
#[Out]# 12   Amsterdam      10  Eindhoven
#[Out]# 13   Amsterdam      10    Tilburg
#[Out]# 14   Amsterdam      10  Amsterdam
#[Out]# 15   Amsterdam      10  Amsterdam
#[Out]# 16   Amsterdam      10    Utrecht
#[Out]# 17   Amsterdam      10  Eindhoven
#[Out]# 18   Amsterdam      10    Tilburg
#[Out]# 19   Amsterdam      10      Breda
#[Out]# 20   Amsterdam      10    Tilburg
#[Out]# 21   Amsterdam      10    Tilburg
#[Out]# 22   Amsterdam      10  Amsterdam
#[Out]# 23   Amsterdam      10      Breda
#[Out]# 24   Amsterdam      10      Breda
#[Out]# 25   Amsterdam      10      Breda
#[Out]# 26   Amsterdam      10      Breda
#[Out]# 27   Amsterdam      10  Amsterdam
#[Out]# 28   Amsterdam      10    Tilburg
#[Out]# 29   Amsterdam      10  Amsterdam
#[Out]# ..         ...     ...        ...
#[Out]# 354    Utrecht      12  Amsterdam
#[Out]# 355    Utrecht      12    Utrecht
#[Out]# 356    Utrecht      12  Eindhoven
#[Out]# 357    Utrecht      12  Eindhoven
#[Out]# 358    Utrecht      12  Rotterdam
#[Out]# 359    Utrecht      12  Eindhoven
#[Out]# 360    Utrecht      12  Rotterdam
#[Out]# 361    Utrecht      12  Rotterdam
#[Out]# 362    Utrecht      12  Amsterdam
#[Out]# 363    Utrecht      12    Utrecht
#[Out]# 364    Utrecht      12    Utrecht
#[Out]# 365    Utrecht      12    Tilburg
#[Out]# 366    Utrecht      12  Rotterdam
#[Out]# 367    Utrecht      12  Rotterdam
#[Out]# 368    Utrecht      12    Tilburg
#[Out]# 369    Utrecht      12  Rotterdam
#[Out]# 370    Utrecht      12      Breda
#[Out]# 371    Utrecht      12    Utrecht
#[Out]# 372    Utrecht      12  Eindhoven
#[Out]# 373    Utrecht      12    Utrecht
#[Out]# 374    Utrecht      12  Eindhoven
#[Out]# 375    Utrecht      12      Breda
#[Out]# 376    Utrecht      12  Eindhoven
#[Out]# 377    Utrecht      12  Eindhoven
#[Out]# 378    Utrecht      12  Rotterdam
#[Out]# 379    Utrecht      12      Breda
#[Out]# 380    Utrecht      12      Breda
#[Out]# 381    Utrecht      12      Breda
#[Out]# 382    Utrecht      12  Eindhoven
#[Out]# 383    Utrecht      12        Oss
#[Out]# 
#[Out]# [384 rows x 3 columns]
# Tue, 08 Dec 2020 22:24:49
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )

select c.city, c.amount, s.city
from citieswithcust c, store s
where c.city = s.city



                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  amount       city
#[Out]# 0   Amsterdam      10  Amsterdam
#[Out]# 1       Breda       9      Breda
#[Out]# 2   Rotterdam      13  Rotterdam
#[Out]# 3   Rotterdam      13  Rotterdam
#[Out]# 4   Eindhoven      15  Eindhoven
#[Out]# 5       Breda       9      Breda
#[Out]# 6   Rotterdam      13  Rotterdam
#[Out]# 7   Eindhoven      15  Eindhoven
#[Out]# 8   Eindhoven      15  Eindhoven
#[Out]# 9     Tilburg      10    Tilburg
#[Out]# 10  Rotterdam      13  Rotterdam
#[Out]# 11  Rotterdam      13  Rotterdam
#[Out]# 12  Eindhoven      15  Eindhoven
#[Out]# 13    Tilburg      10    Tilburg
#[Out]# 14  Amsterdam      10  Amsterdam
#[Out]# 15  Amsterdam      10  Amsterdam
#[Out]# 16    Utrecht      12    Utrecht
#[Out]# 17  Eindhoven      15  Eindhoven
#[Out]# 18    Tilburg      10    Tilburg
#[Out]# 19      Breda       9      Breda
#[Out]# 20    Tilburg      10    Tilburg
#[Out]# 21    Tilburg      10    Tilburg
#[Out]# 22  Amsterdam      10  Amsterdam
#[Out]# 23      Breda       9      Breda
#[Out]# 24      Breda       9      Breda
#[Out]# 25      Breda       9      Breda
#[Out]# 26      Breda       9      Breda
#[Out]# 27  Amsterdam      10  Amsterdam
#[Out]# 28    Tilburg      10    Tilburg
#[Out]# 29  Amsterdam      10  Amsterdam
#[Out]# ..        ...     ...        ...
#[Out]# 33  Eindhoven      15  Eindhoven
#[Out]# 34  Amsterdam      10  Amsterdam
#[Out]# 35    Utrecht      12    Utrecht
#[Out]# 36  Eindhoven      15  Eindhoven
#[Out]# 37  Eindhoven      15  Eindhoven
#[Out]# 38  Rotterdam      13  Rotterdam
#[Out]# 39  Eindhoven      15  Eindhoven
#[Out]# 40  Rotterdam      13  Rotterdam
#[Out]# 41  Rotterdam      13  Rotterdam
#[Out]# 42  Amsterdam      10  Amsterdam
#[Out]# 43    Utrecht      12    Utrecht
#[Out]# 44    Utrecht      12    Utrecht
#[Out]# 45    Tilburg      10    Tilburg
#[Out]# 46  Rotterdam      13  Rotterdam
#[Out]# 47  Rotterdam      13  Rotterdam
#[Out]# 48    Tilburg      10    Tilburg
#[Out]# 49  Rotterdam      13  Rotterdam
#[Out]# 50      Breda       9      Breda
#[Out]# 51    Utrecht      12    Utrecht
#[Out]# 52  Eindhoven      15  Eindhoven
#[Out]# 53    Utrecht      12    Utrecht
#[Out]# 54  Eindhoven      15  Eindhoven
#[Out]# 55      Breda       9      Breda
#[Out]# 56  Eindhoven      15  Eindhoven
#[Out]# 57  Eindhoven      15  Eindhoven
#[Out]# 58  Rotterdam      13  Rotterdam
#[Out]# 59      Breda       9      Breda
#[Out]# 60      Breda       9      Breda
#[Out]# 61      Breda       9      Breda
#[Out]# 62  Eindhoven      15  Eindhoven
#[Out]# 
#[Out]# [63 rows x 3 columns]
# Tue, 08 Dec 2020 22:25:13
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )

select c.city, c.amount, s.city
from citieswithcust c, store s
where c.city = s.city
group by c.city



                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount       city
#[Out]# 0  Amsterdam      10  Amsterdam
#[Out]# 1      Breda       9      Breda
#[Out]# 2  Eindhoven      15  Eindhoven
#[Out]# 3  Rotterdam      13  Rotterdam
#[Out]# 4    Tilburg      10    Tilburg
#[Out]# 5    Utrecht      12    Utrecht
# Tue, 08 Dec 2020 22:25:41
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )

select c.city, c.amount, s.city, 0
from citieswithcust c, store s
where c.city = s.city
group by c.city



                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount       city  0
#[Out]# 0  Amsterdam      10  Amsterdam  0
#[Out]# 1      Breda       9      Breda  0
#[Out]# 2  Eindhoven      15  Eindhoven  0
#[Out]# 3  Rotterdam      13  Rotterdam  0
#[Out]# 4    Tilburg      10    Tilburg  0
#[Out]# 5    Utrecht      12    Utrecht  0
# Tue, 08 Dec 2020 22:26:04
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )

select c.city, c.amount, s.city, 0 as number
from citieswithcust c, store s
where c.city = s.city or number = 0



                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  amount       city  number
#[Out]# 0    Amsterdam      10  Amsterdam       0
#[Out]# 1    Amsterdam      10      Breda       0
#[Out]# 2    Amsterdam      10  Rotterdam       0
#[Out]# 3    Amsterdam      10  Rotterdam       0
#[Out]# 4    Amsterdam      10  Eindhoven       0
#[Out]# 5    Amsterdam      10      Breda       0
#[Out]# 6    Amsterdam      10  Rotterdam       0
#[Out]# 7    Amsterdam      10  Eindhoven       0
#[Out]# 8    Amsterdam      10  Eindhoven       0
#[Out]# 9    Amsterdam      10    Tilburg       0
#[Out]# 10   Amsterdam      10  Rotterdam       0
#[Out]# 11   Amsterdam      10  Rotterdam       0
#[Out]# 12   Amsterdam      10  Eindhoven       0
#[Out]# 13   Amsterdam      10    Tilburg       0
#[Out]# 14   Amsterdam      10  Amsterdam       0
#[Out]# 15   Amsterdam      10  Amsterdam       0
#[Out]# 16   Amsterdam      10    Utrecht       0
#[Out]# 17   Amsterdam      10  Eindhoven       0
#[Out]# 18   Amsterdam      10    Tilburg       0
#[Out]# 19   Amsterdam      10      Breda       0
#[Out]# 20   Amsterdam      10    Tilburg       0
#[Out]# 21   Amsterdam      10    Tilburg       0
#[Out]# 22   Amsterdam      10  Amsterdam       0
#[Out]# 23   Amsterdam      10      Breda       0
#[Out]# 24   Amsterdam      10      Breda       0
#[Out]# 25   Amsterdam      10      Breda       0
#[Out]# 26   Amsterdam      10      Breda       0
#[Out]# 27   Amsterdam      10  Amsterdam       0
#[Out]# 28   Amsterdam      10    Tilburg       0
#[Out]# 29   Amsterdam      10  Amsterdam       0
#[Out]# ..         ...     ...        ...     ...
#[Out]# 354    Utrecht      12  Amsterdam       0
#[Out]# 355    Utrecht      12    Utrecht       0
#[Out]# 356    Utrecht      12  Eindhoven       0
#[Out]# 357    Utrecht      12  Eindhoven       0
#[Out]# 358    Utrecht      12  Rotterdam       0
#[Out]# 359    Utrecht      12  Eindhoven       0
#[Out]# 360    Utrecht      12  Rotterdam       0
#[Out]# 361    Utrecht      12  Rotterdam       0
#[Out]# 362    Utrecht      12  Amsterdam       0
#[Out]# 363    Utrecht      12    Utrecht       0
#[Out]# 364    Utrecht      12    Utrecht       0
#[Out]# 365    Utrecht      12    Tilburg       0
#[Out]# 366    Utrecht      12  Rotterdam       0
#[Out]# 367    Utrecht      12  Rotterdam       0
#[Out]# 368    Utrecht      12    Tilburg       0
#[Out]# 369    Utrecht      12  Rotterdam       0
#[Out]# 370    Utrecht      12      Breda       0
#[Out]# 371    Utrecht      12    Utrecht       0
#[Out]# 372    Utrecht      12  Eindhoven       0
#[Out]# 373    Utrecht      12    Utrecht       0
#[Out]# 374    Utrecht      12  Eindhoven       0
#[Out]# 375    Utrecht      12      Breda       0
#[Out]# 376    Utrecht      12  Eindhoven       0
#[Out]# 377    Utrecht      12  Eindhoven       0
#[Out]# 378    Utrecht      12  Rotterdam       0
#[Out]# 379    Utrecht      12      Breda       0
#[Out]# 380    Utrecht      12      Breda       0
#[Out]# 381    Utrecht      12      Breda       0
#[Out]# 382    Utrecht      12  Eindhoven       0
#[Out]# 383    Utrecht      12        Oss       0
#[Out]# 
#[Out]# [384 rows x 4 columns]
# Tue, 08 Dec 2020 22:26:10
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )




                        

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:26:52
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )
                                        
select *
from citieswithcust




                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Tue, 08 Dec 2020 22:28:11
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )
                                        
select s.city
from store s
where s.city not in (select city from citieswithoutcust)




                        

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:28:22
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )
                                        
select s.city
from store s
where s.city not in (select city from citieswithcust)




                        

'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city
#[Out]# 0  Oss
# Tue, 08 Dec 2020 22:29:32
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city )
                                        
with citieswithoutcust (city, 0) as (   select s.city
                                        from store s
                                        where s.city not in (select city from citieswithcust) )
                                        
select * from citieswithcust
union
select * from citieswithoutcust






                        

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:29:57
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city ),
                                        
    citieswithoutcust (city, 0) as (   select s.city
                                        from store s
                                        where s.city not in (select city from citieswithcust) )
                                        
select * from citieswithcust
union
select * from citieswithoutcust                      

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:30:34
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city ),
                                        
      citieswithoutcust (city, 0) as (  select s.city, 0
                                        from store s
                                        where s.city not in (select city from citieswithcust) )
                                        
select * from citieswithcust
union
select * from citieswithoutcust                      

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:30:46
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city ),
                                        
      citieswithoutcust (city, amount) as (  select s.city, 0
                                        from store s
                                        where s.city not in (select city from citieswithcust) )
                                        
select * from citieswithcust
union
select * from citieswithoutcust                      

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 22:31:56
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select s.sName, s.city
from store s
where (s.sName, s.city) not in (  select *
                                from missing)

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 22:32:17
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, sum(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:33:06
query4_4 = '''

select cID
from purchase
where price > 30
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:33:11
query4_4 = '''

select cID
from purchase
where price 25 30
    
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 22:33:17
query4_4 = '''

select cID
from purchase
where price > 25
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:33:26
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, sum(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:33:31
query4_5 = '''

with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city ),
                                        
      citieswithoutcust (city, amount) as (  select s.city, 0
                                        from store s
                                        where s.city not in (select city from citieswithcust) )
                                        
select * from citieswithcust
union
select * from citieswithoutcust                      

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 22:34:40
query4_5 = '''

with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID in (
	select sID
	from inventory_size
	where size <= 20);

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# 5     5       Sligro
#[Out]# 6     6         Coop
#[Out]# 7     7       Sligro
#[Out]# 8     8  Albert Hein
#[Out]# 9     9  Albert Hein
#[Out]# 10   10        Jumbo
#[Out]# 11   11  Albert Hein
#[Out]# 12   12         Lidl
#[Out]# 13   13         Coop
#[Out]# 14   14         Coop
#[Out]# 15   15         Lidl
#[Out]# 16   16         Lidl
#[Out]# 17   17    Hoogvliet
#[Out]# 18   18       Sligro
#[Out]# 19   19         Coop
#[Out]# 20   20        Jumbo
#[Out]# 21   21         Coop
#[Out]# 22   22         Lidl
#[Out]# 23   23         Dirk
#[Out]# 24   24  Albert Hein
#[Out]# 25   25  Albert Hein
#[Out]# 26   26    Hoogvliet
#[Out]# 27   27       Sligro
#[Out]# 28   28    Hoogvliet
#[Out]# 29   29       Sligro
#[Out]# ..  ...          ...
#[Out]# 31   31         Coop
#[Out]# 32   32  Albert Hein
#[Out]# 33   33         Dirk
#[Out]# 34   34         Coop
#[Out]# 35   35         Lidl
#[Out]# 36   36         Lidl
#[Out]# 37   37        Jumbo
#[Out]# 38   38    Hoogvliet
#[Out]# 39   39       Sligro
#[Out]# 40   40    Hoogvliet
#[Out]# 41   41  Albert Hein
#[Out]# 42   42       Sligro
#[Out]# 43   43         Coop
#[Out]# 44   44  Albert Hein
#[Out]# 45   45         Coop
#[Out]# 46   46         Lidl
#[Out]# 47   47         Coop
#[Out]# 48   48    Hoogvliet
#[Out]# 49   49    Hoogvliet
#[Out]# 50   50       Sligro
#[Out]# 51   51         Coop
#[Out]# 52   52         Lidl
#[Out]# 53   53         Coop
#[Out]# 54   54         Dirk
#[Out]# 55   55         Coop
#[Out]# 56   56        Jumbo
#[Out]# 57   57         Dirk
#[Out]# 58   58         Dirk
#[Out]# 59   59        Jumbo
#[Out]# 60   60         Lidl
#[Out]# 
#[Out]# [61 rows x 2 columns]
# Tue, 08 Dec 2020 22:35:01
query4_5 = '''

with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID not in (
	select sID
	from inventory_size
	where size > 20);

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# 5     5       Sligro
#[Out]# 6     6         Coop
#[Out]# 7     7       Sligro
#[Out]# 8     8  Albert Hein
#[Out]# 9     9  Albert Hein
#[Out]# 10   10        Jumbo
#[Out]# 11   11  Albert Hein
#[Out]# 12   12         Lidl
#[Out]# 13   13         Coop
#[Out]# 14   14         Coop
#[Out]# 15   15         Lidl
#[Out]# 16   16         Lidl
#[Out]# 17   17    Hoogvliet
#[Out]# 18   18       Sligro
#[Out]# 19   19         Coop
#[Out]# 20   20        Jumbo
#[Out]# 21   21         Coop
#[Out]# 22   22         Lidl
#[Out]# 23   23         Dirk
#[Out]# 24   24  Albert Hein
#[Out]# 25   25  Albert Hein
#[Out]# 26   26    Hoogvliet
#[Out]# 27   27       Sligro
#[Out]# 28   28    Hoogvliet
#[Out]# 29   29       Sligro
#[Out]# ..  ...          ...
#[Out]# 34   34         Coop
#[Out]# 35   35         Lidl
#[Out]# 36   36         Lidl
#[Out]# 37   37        Jumbo
#[Out]# 38   38    Hoogvliet
#[Out]# 39   39       Sligro
#[Out]# 40   40    Hoogvliet
#[Out]# 41   41  Albert Hein
#[Out]# 42   42       Sligro
#[Out]# 43   43         Coop
#[Out]# 44   44  Albert Hein
#[Out]# 45   45         Coop
#[Out]# 46   46         Lidl
#[Out]# 47   47         Coop
#[Out]# 48   48    Hoogvliet
#[Out]# 49   49    Hoogvliet
#[Out]# 50   50       Sligro
#[Out]# 51   51         Coop
#[Out]# 52   52         Lidl
#[Out]# 53   53         Coop
#[Out]# 54   54         Dirk
#[Out]# 55   55         Coop
#[Out]# 56   56        Jumbo
#[Out]# 57   57         Dirk
#[Out]# 58   58         Dirk
#[Out]# 59   59        Jumbo
#[Out]# 60   60         Lidl
#[Out]# 61   61         Lidl
#[Out]# 62   62        Jumbo
#[Out]# 63   63        Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 22:35:17
query4_5 = '''

with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID in (
	select sID
	from inventory_size
	where size <= 20);

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# 5     5       Sligro
#[Out]# 6     6         Coop
#[Out]# 7     7       Sligro
#[Out]# 8     8  Albert Hein
#[Out]# 9     9  Albert Hein
#[Out]# 10   10        Jumbo
#[Out]# 11   11  Albert Hein
#[Out]# 12   12         Lidl
#[Out]# 13   13         Coop
#[Out]# 14   14         Coop
#[Out]# 15   15         Lidl
#[Out]# 16   16         Lidl
#[Out]# 17   17    Hoogvliet
#[Out]# 18   18       Sligro
#[Out]# 19   19         Coop
#[Out]# 20   20        Jumbo
#[Out]# 21   21         Coop
#[Out]# 22   22         Lidl
#[Out]# 23   23         Dirk
#[Out]# 24   24  Albert Hein
#[Out]# 25   25  Albert Hein
#[Out]# 26   26    Hoogvliet
#[Out]# 27   27       Sligro
#[Out]# 28   28    Hoogvliet
#[Out]# 29   29       Sligro
#[Out]# ..  ...          ...
#[Out]# 31   31         Coop
#[Out]# 32   32  Albert Hein
#[Out]# 33   33         Dirk
#[Out]# 34   34         Coop
#[Out]# 35   35         Lidl
#[Out]# 36   36         Lidl
#[Out]# 37   37        Jumbo
#[Out]# 38   38    Hoogvliet
#[Out]# 39   39       Sligro
#[Out]# 40   40    Hoogvliet
#[Out]# 41   41  Albert Hein
#[Out]# 42   42       Sligro
#[Out]# 43   43         Coop
#[Out]# 44   44  Albert Hein
#[Out]# 45   45         Coop
#[Out]# 46   46         Lidl
#[Out]# 47   47         Coop
#[Out]# 48   48    Hoogvliet
#[Out]# 49   49    Hoogvliet
#[Out]# 50   50       Sligro
#[Out]# 51   51         Coop
#[Out]# 52   52         Lidl
#[Out]# 53   53         Coop
#[Out]# 54   54         Dirk
#[Out]# 55   55         Coop
#[Out]# 56   56        Jumbo
#[Out]# 57   57         Dirk
#[Out]# 58   58         Dirk
#[Out]# 59   59        Jumbo
#[Out]# 60   60         Lidl
#[Out]# 
#[Out]# [61 rows x 2 columns]
# Tue, 08 Dec 2020 22:36:48
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID not in (
	select sID
	from inventory_size
	where size > 20);
    
    except 
    
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID in (
	select sID
	from inventory_size
	where size <= 20);

'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:37:04
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID not in (
	select sID
	from inventory_size
	where size > 20);
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# 5     5       Sligro
#[Out]# 6     6         Coop
#[Out]# 7     7       Sligro
#[Out]# 8     8  Albert Hein
#[Out]# 9     9  Albert Hein
#[Out]# 10   10        Jumbo
#[Out]# 11   11  Albert Hein
#[Out]# 12   12         Lidl
#[Out]# 13   13         Coop
#[Out]# 14   14         Coop
#[Out]# 15   15         Lidl
#[Out]# 16   16         Lidl
#[Out]# 17   17    Hoogvliet
#[Out]# 18   18       Sligro
#[Out]# 19   19         Coop
#[Out]# 20   20        Jumbo
#[Out]# 21   21         Coop
#[Out]# 22   22         Lidl
#[Out]# 23   23         Dirk
#[Out]# 24   24  Albert Hein
#[Out]# 25   25  Albert Hein
#[Out]# 26   26    Hoogvliet
#[Out]# 27   27       Sligro
#[Out]# 28   28    Hoogvliet
#[Out]# 29   29       Sligro
#[Out]# ..  ...          ...
#[Out]# 34   34         Coop
#[Out]# 35   35         Lidl
#[Out]# 36   36         Lidl
#[Out]# 37   37        Jumbo
#[Out]# 38   38    Hoogvliet
#[Out]# 39   39       Sligro
#[Out]# 40   40    Hoogvliet
#[Out]# 41   41  Albert Hein
#[Out]# 42   42       Sligro
#[Out]# 43   43         Coop
#[Out]# 44   44  Albert Hein
#[Out]# 45   45         Coop
#[Out]# 46   46         Lidl
#[Out]# 47   47         Coop
#[Out]# 48   48    Hoogvliet
#[Out]# 49   49    Hoogvliet
#[Out]# 50   50       Sligro
#[Out]# 51   51         Coop
#[Out]# 52   52         Lidl
#[Out]# 53   53         Coop
#[Out]# 54   54         Dirk
#[Out]# 55   55         Coop
#[Out]# 56   56        Jumbo
#[Out]# 57   57         Dirk
#[Out]# 58   58         Dirk
#[Out]# 59   59        Jumbo
#[Out]# 60   60         Lidl
#[Out]# 61   61         Lidl
#[Out]# 62   62        Jumbo
#[Out]# 63   63        Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 22:37:43
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID not in (
	select sID
	from inventory_size
	where size <= 20);
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#    sID  sName
#[Out]# 0   61   Lidl
#[Out]# 1   62  Jumbo
#[Out]# 2   63  Jumbo
# Tue, 08 Dec 2020 22:37:57
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID in (
	select sID
	from inventory_size
	where size > 20);
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:38:04
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID in (
	select sID
	from inventory_size
	where size < 20);
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# 5     5       Sligro
#[Out]# 6     6         Coop
#[Out]# 7     7       Sligro
#[Out]# 8     8  Albert Hein
#[Out]# 9     9  Albert Hein
#[Out]# 10   10        Jumbo
#[Out]# 11   11  Albert Hein
#[Out]# 12   12         Lidl
#[Out]# 13   13         Coop
#[Out]# 14   14         Coop
#[Out]# 15   15         Lidl
#[Out]# 16   16         Lidl
#[Out]# 17   17    Hoogvliet
#[Out]# 18   18       Sligro
#[Out]# 19   19         Coop
#[Out]# 20   20        Jumbo
#[Out]# 21   21         Coop
#[Out]# 22   22         Lidl
#[Out]# 23   23         Dirk
#[Out]# 24   24  Albert Hein
#[Out]# 25   25  Albert Hein
#[Out]# 26   26    Hoogvliet
#[Out]# 27   27       Sligro
#[Out]# 28   28    Hoogvliet
#[Out]# 29   29       Sligro
#[Out]# ..  ...          ...
#[Out]# 31   31         Coop
#[Out]# 32   32  Albert Hein
#[Out]# 33   33         Dirk
#[Out]# 34   34         Coop
#[Out]# 35   35         Lidl
#[Out]# 36   36         Lidl
#[Out]# 37   37        Jumbo
#[Out]# 38   38    Hoogvliet
#[Out]# 39   39       Sligro
#[Out]# 40   40    Hoogvliet
#[Out]# 41   41  Albert Hein
#[Out]# 42   42       Sligro
#[Out]# 43   43         Coop
#[Out]# 44   44  Albert Hein
#[Out]# 45   45         Coop
#[Out]# 46   46         Lidl
#[Out]# 47   47         Coop
#[Out]# 48   48    Hoogvliet
#[Out]# 49   49    Hoogvliet
#[Out]# 50   50       Sligro
#[Out]# 51   51         Coop
#[Out]# 52   52         Lidl
#[Out]# 53   53         Coop
#[Out]# 54   54         Dirk
#[Out]# 55   55         Coop
#[Out]# 56   56        Jumbo
#[Out]# 57   57         Dirk
#[Out]# 58   58         Dirk
#[Out]# 59   59        Jumbo
#[Out]# 60   60         Lidl
#[Out]# 
#[Out]# [61 rows x 2 columns]
# Tue, 08 Dec 2020 22:38:10
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID in (
	select sID
	from inventory_size
	where size > 20);
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:38:42
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID
	from inventory_size
	where size > 20;
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:38:51
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, size
	from inventory_size
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#      sID  size
#[Out]# 0      0     1
#[Out]# 1      0     3
#[Out]# 2      0     2
#[Out]# 3      0     1
#[Out]# 4      0     1
#[Out]# 5      0     1
#[Out]# 6      0     1
#[Out]# 7      0     2
#[Out]# 8      0     1
#[Out]# 9      0     3
#[Out]# 10     0     4
#[Out]# 11     0     1
#[Out]# 12     1     1
#[Out]# 13     1     2
#[Out]# 14     1     1
#[Out]# 15     1     3
#[Out]# 16     1     1
#[Out]# 17     1     1
#[Out]# 18     1     1
#[Out]# 19     1     1
#[Out]# 20     1     3
#[Out]# 21     2     1
#[Out]# 22     2     1
#[Out]# 23     2     2
#[Out]# 24     2     1
#[Out]# 25     2     2
#[Out]# 26     2     2
#[Out]# 27     2     2
#[Out]# 28     3     1
#[Out]# 29     3     1
#[Out]# ..   ...   ...
#[Out]# 492   56     1
#[Out]# 493   56     2
#[Out]# 494   56     1
#[Out]# 495   56     2
#[Out]# 496   56     2
#[Out]# 497   56     1
#[Out]# 498   56     1
#[Out]# 499   57     1
#[Out]# 500   57     1
#[Out]# 501   57     2
#[Out]# 502   57     2
#[Out]# 503   57     1
#[Out]# 504   57     5
#[Out]# 505   57     1
#[Out]# 506   57     2
#[Out]# 507   57     1
#[Out]# 508   58     1
#[Out]# 509   58     2
#[Out]# 510   58     1
#[Out]# 511   58     1
#[Out]# 512   58     1
#[Out]# 513   59     1
#[Out]# 514   59     1
#[Out]# 515   59     3
#[Out]# 516   59     2
#[Out]# 517   59     1
#[Out]# 518   59     2
#[Out]# 519   59     2
#[Out]# 520   59     1
#[Out]# 521   60     1
#[Out]# 
#[Out]# [522 rows x 2 columns]
# Tue, 08 Dec 2020 22:39:04
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, size
	from inventory_size
    where size > 15
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, size]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:39:18
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, size
	from inventory_size
    where size > 10
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, size]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:39:23
query4_5 = '''
with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, size
	from inventory_size
    where size < 20
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#      sID  size
#[Out]# 0      0     1
#[Out]# 1      0     3
#[Out]# 2      0     2
#[Out]# 3      0     1
#[Out]# 4      0     1
#[Out]# 5      0     1
#[Out]# 6      0     1
#[Out]# 7      0     2
#[Out]# 8      0     1
#[Out]# 9      0     3
#[Out]# 10     0     4
#[Out]# 11     0     1
#[Out]# 12     1     1
#[Out]# 13     1     2
#[Out]# 14     1     1
#[Out]# 15     1     3
#[Out]# 16     1     1
#[Out]# 17     1     1
#[Out]# 18     1     1
#[Out]# 19     1     1
#[Out]# 20     1     3
#[Out]# 21     2     1
#[Out]# 22     2     1
#[Out]# 23     2     2
#[Out]# 24     2     1
#[Out]# 25     2     2
#[Out]# 26     2     2
#[Out]# 27     2     2
#[Out]# 28     3     1
#[Out]# 29     3     1
#[Out]# ..   ...   ...
#[Out]# 492   56     1
#[Out]# 493   56     2
#[Out]# 494   56     1
#[Out]# 495   56     2
#[Out]# 496   56     2
#[Out]# 497   56     1
#[Out]# 498   56     1
#[Out]# 499   57     1
#[Out]# 500   57     1
#[Out]# 501   57     2
#[Out]# 502   57     2
#[Out]# 503   57     1
#[Out]# 504   57     5
#[Out]# 505   57     1
#[Out]# 506   57     2
#[Out]# 507   57     1
#[Out]# 508   58     1
#[Out]# 509   58     2
#[Out]# 510   58     1
#[Out]# 511   58     1
#[Out]# 512   58     1
#[Out]# 513   59     1
#[Out]# 514   59     1
#[Out]# 515   59     3
#[Out]# 516   59     2
#[Out]# 517   59     1
#[Out]# 518   59     2
#[Out]# 519   59     2
#[Out]# 520   59     1
#[Out]# 521   60     1
#[Out]# 
#[Out]# [522 rows x 2 columns]
# Tue, 08 Dec 2020 22:40:23
query4_5 = '''

	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#      sID        date  count(distinct pID)
#[Out]# 0      0  2018-07-18                    1
#[Out]# 1      0  2018-08-15                    3
#[Out]# 2      0  2018-08-16                    2
#[Out]# 3      0  2018-08-17                    1
#[Out]# 4      0  2018-08-18                    1
#[Out]# 5      0  2018-08-19                    1
#[Out]# 6      0  2018-08-20                    1
#[Out]# 7      0  2018-08-21                    2
#[Out]# 8      0  2018-08-22                    1
#[Out]# 9      0  2018-08-24                    3
#[Out]# 10     0  2018-08-25                    4
#[Out]# 11     0  2018-08-27                    1
#[Out]# 12     1  2018-08-15                    1
#[Out]# 13     1  2018-08-17                    2
#[Out]# 14     1  2018-08-18                    1
#[Out]# 15     1  2018-08-20                    3
#[Out]# 16     1  2018-08-21                    1
#[Out]# 17     1  2018-08-23                    1
#[Out]# 18     1  2018-08-24                    1
#[Out]# 19     1  2018-08-25                    1
#[Out]# 20     1  2018-08-26                    3
#[Out]# 21     2  2018-08-15                    1
#[Out]# 22     2  2018-08-16                    1
#[Out]# 23     2  2018-08-18                    2
#[Out]# 24     2  2018-08-22                    1
#[Out]# 25     2  2018-08-23                    2
#[Out]# 26     2  2018-08-24                    2
#[Out]# 27     2  2018-08-25                    2
#[Out]# 28     3  2018-08-15                    1
#[Out]# 29     3  2018-08-17                    1
#[Out]# ..   ...         ...                  ...
#[Out]# 492   56  2018-08-18                    1
#[Out]# 493   56  2018-08-20                    2
#[Out]# 494   56  2018-08-21                    1
#[Out]# 495   56  2018-08-22                    2
#[Out]# 496   56  2018-08-23                    2
#[Out]# 497   56  2018-08-24                    1
#[Out]# 498   56  2018-08-27                    1
#[Out]# 499   57  2018-08-15                    1
#[Out]# 500   57  2018-08-16                    1
#[Out]# 501   57  2018-08-17                    2
#[Out]# 502   57  2018-08-18                    2
#[Out]# 503   57  2018-08-21                    1
#[Out]# 504   57  2018-08-22                    5
#[Out]# 505   57  2018-08-23                    1
#[Out]# 506   57  2018-08-24                    2
#[Out]# 507   57  2018-08-26                    1
#[Out]# 508   58  2018-08-16                    1
#[Out]# 509   58  2018-08-20                    2
#[Out]# 510   58  2018-08-21                    1
#[Out]# 511   58  2018-08-24                    1
#[Out]# 512   58  2018-08-25                    1
#[Out]# 513   59  2018-08-15                    1
#[Out]# 514   59  2018-08-17                    1
#[Out]# 515   59  2018-08-18                    3
#[Out]# 516   59  2018-08-20                    2
#[Out]# 517   59  2018-08-24                    1
#[Out]# 518   59  2018-08-25                    2
#[Out]# 519   59  2018-08-26                    2
#[Out]# 520   59  2018-08-27                    1
#[Out]# 521   60  2018-07-10                    1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Tue, 08 Dec 2020 22:41:34
query4_5 = '''

with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID not in (
	select sID
	from inventory_size
	where size <= 20);
 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#    sID  sName
#[Out]# 0   61   Lidl
#[Out]# 1   62  Jumbo
#[Out]# 2   63  Jumbo
# Tue, 08 Dec 2020 22:42:17
query4_5 = '''


	select sID, date, count(distinct pID)
	from inventory
    where sID = 61
	group by sID, date
	

 

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, date, count(distinct pID)]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:43:35
query4_5 = '''


	select sID, date, count(distinct pID)
	from inventory
    where sID = 62
	group by sID, date
	

 

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, date, count(distinct pID)]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:43:38
query4_5 = '''


	select sID, date, count(distinct pID)
	from inventory
    where sID = 63
	group by sID, date
	

 

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, date, count(distinct pID)]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:43:48
query4_5 = '''


	select sID, date, count(distinct pID)
	from inventory
    where sID = 63
	

 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID  date  count(distinct pID)
#[Out]# 0  None  None                    0
# Tue, 08 Dec 2020 22:43:59
query4_5 = '''


	select sID, date, count(distinct pID)
	from inventory
    where sID = 61
	

 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID  date  count(distinct pID)
#[Out]# 0  None  None                    0
# Tue, 08 Dec 2020 22:44:08
query4_5 = '''


	select sID, date, count(distinct pID)
	from inventory
	

 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#    sID        date  count(distinct pID)
#[Out]# 0    0  2018-07-18                   29
# Tue, 08 Dec 2020 22:44:16
query4_5 = '''


select sID, date, count(distinct pID)
from inventory


 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#    sID        date  count(distinct pID)
#[Out]# 0    0  2018-07-18                   29
# Tue, 08 Dec 2020 22:44:26
query4_5 = '''


select sID, date, count(distinct pID)
from inventory
group by sID, date

 

'''

pd.read_sql_query(query4_5, conn)
#[Out]#      sID        date  count(distinct pID)
#[Out]# 0      0  2018-07-18                    1
#[Out]# 1      0  2018-08-15                    3
#[Out]# 2      0  2018-08-16                    2
#[Out]# 3      0  2018-08-17                    1
#[Out]# 4      0  2018-08-18                    1
#[Out]# 5      0  2018-08-19                    1
#[Out]# 6      0  2018-08-20                    1
#[Out]# 7      0  2018-08-21                    2
#[Out]# 8      0  2018-08-22                    1
#[Out]# 9      0  2018-08-24                    3
#[Out]# 10     0  2018-08-25                    4
#[Out]# 11     0  2018-08-27                    1
#[Out]# 12     1  2018-08-15                    1
#[Out]# 13     1  2018-08-17                    2
#[Out]# 14     1  2018-08-18                    1
#[Out]# 15     1  2018-08-20                    3
#[Out]# 16     1  2018-08-21                    1
#[Out]# 17     1  2018-08-23                    1
#[Out]# 18     1  2018-08-24                    1
#[Out]# 19     1  2018-08-25                    1
#[Out]# 20     1  2018-08-26                    3
#[Out]# 21     2  2018-08-15                    1
#[Out]# 22     2  2018-08-16                    1
#[Out]# 23     2  2018-08-18                    2
#[Out]# 24     2  2018-08-22                    1
#[Out]# 25     2  2018-08-23                    2
#[Out]# 26     2  2018-08-24                    2
#[Out]# 27     2  2018-08-25                    2
#[Out]# 28     3  2018-08-15                    1
#[Out]# 29     3  2018-08-17                    1
#[Out]# ..   ...         ...                  ...
#[Out]# 492   56  2018-08-18                    1
#[Out]# 493   56  2018-08-20                    2
#[Out]# 494   56  2018-08-21                    1
#[Out]# 495   56  2018-08-22                    2
#[Out]# 496   56  2018-08-23                    2
#[Out]# 497   56  2018-08-24                    1
#[Out]# 498   56  2018-08-27                    1
#[Out]# 499   57  2018-08-15                    1
#[Out]# 500   57  2018-08-16                    1
#[Out]# 501   57  2018-08-17                    2
#[Out]# 502   57  2018-08-18                    2
#[Out]# 503   57  2018-08-21                    1
#[Out]# 504   57  2018-08-22                    5
#[Out]# 505   57  2018-08-23                    1
#[Out]# 506   57  2018-08-24                    2
#[Out]# 507   57  2018-08-26                    1
#[Out]# 508   58  2018-08-16                    1
#[Out]# 509   58  2018-08-20                    2
#[Out]# 510   58  2018-08-21                    1
#[Out]# 511   58  2018-08-24                    1
#[Out]# 512   58  2018-08-25                    1
#[Out]# 513   59  2018-08-15                    1
#[Out]# 514   59  2018-08-17                    1
#[Out]# 515   59  2018-08-18                    3
#[Out]# 516   59  2018-08-20                    2
#[Out]# 517   59  2018-08-24                    1
#[Out]# 518   59  2018-08-25                    2
#[Out]# 519   59  2018-08-26                    2
#[Out]# 520   59  2018-08-27                    1
#[Out]# 521   60  2018-07-10                    1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Tue, 08 Dec 2020 22:44:56
query4_5 = '''
 
 with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID in (
	select sID
	from inventory_size
	where size <= 20);

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# 5     5       Sligro
#[Out]# 6     6         Coop
#[Out]# 7     7       Sligro
#[Out]# 8     8  Albert Hein
#[Out]# 9     9  Albert Hein
#[Out]# 10   10        Jumbo
#[Out]# 11   11  Albert Hein
#[Out]# 12   12         Lidl
#[Out]# 13   13         Coop
#[Out]# 14   14         Coop
#[Out]# 15   15         Lidl
#[Out]# 16   16         Lidl
#[Out]# 17   17    Hoogvliet
#[Out]# 18   18       Sligro
#[Out]# 19   19         Coop
#[Out]# 20   20        Jumbo
#[Out]# 21   21         Coop
#[Out]# 22   22         Lidl
#[Out]# 23   23         Dirk
#[Out]# 24   24  Albert Hein
#[Out]# 25   25  Albert Hein
#[Out]# 26   26    Hoogvliet
#[Out]# 27   27       Sligro
#[Out]# 28   28    Hoogvliet
#[Out]# 29   29       Sligro
#[Out]# ..  ...          ...
#[Out]# 31   31         Coop
#[Out]# 32   32  Albert Hein
#[Out]# 33   33         Dirk
#[Out]# 34   34         Coop
#[Out]# 35   35         Lidl
#[Out]# 36   36         Lidl
#[Out]# 37   37        Jumbo
#[Out]# 38   38    Hoogvliet
#[Out]# 39   39       Sligro
#[Out]# 40   40    Hoogvliet
#[Out]# 41   41  Albert Hein
#[Out]# 42   42       Sligro
#[Out]# 43   43         Coop
#[Out]# 44   44  Albert Hein
#[Out]# 45   45         Coop
#[Out]# 46   46         Lidl
#[Out]# 47   47         Coop
#[Out]# 48   48    Hoogvliet
#[Out]# 49   49    Hoogvliet
#[Out]# 50   50       Sligro
#[Out]# 51   51         Coop
#[Out]# 52   52         Lidl
#[Out]# 53   53         Coop
#[Out]# 54   54         Dirk
#[Out]# 55   55         Coop
#[Out]# 56   56        Jumbo
#[Out]# 57   57         Dirk
#[Out]# 58   58         Dirk
#[Out]# 59   59        Jumbo
#[Out]# 60   60         Lidl
#[Out]# 
#[Out]# [61 rows x 2 columns]

# IPython log file

# Wed, 09 Dec 2020 11:00:21
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 11:00:21
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 09 Dec 2020 11:00:27
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select s.sName, s.city
from store s
where (s.sName, s.city) not in (  select *
                                from missing)

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 11:01:18
query4_3 = '''

                                
select city 
from customer 
union 
select city 
from store

'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 11:02:39
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select s.sName, s.city
from store s
where (s.sName, s.city) not in (  select *
                                from missing)


'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 11:03:19
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select * from missing


'''

pd.read_sql_query(query4_3, conn)
#[Out]#       store_name       city
#[Out]# 0           Coop  Eindhoven
#[Out]# 1           Coop        Oss
#[Out]# 2      Hoogvliet  Amsterdam
#[Out]# 3      Hoogvliet        Oss
#[Out]# 4      Hoogvliet    Utrecht
#[Out]# 5          Jumbo  Amsterdam
#[Out]# 6          Jumbo    Utrecht
#[Out]# 7         Sligro        Oss
#[Out]# 8         Sligro    Utrecht
#[Out]# 9      Hoogvliet  Amsterdam
#[Out]# 10     Hoogvliet        Oss
#[Out]# 11     Hoogvliet    Utrecht
#[Out]# 12        Sligro        Oss
#[Out]# 13        Sligro    Utrecht
#[Out]# 14          Coop  Eindhoven
#[Out]# 15          Coop        Oss
#[Out]# 16        Sligro        Oss
#[Out]# 17        Sligro    Utrecht
#[Out]# 18   Albert Hein  Amsterdam
#[Out]# 19   Albert Hein        Oss
#[Out]# 20   Albert Hein  Amsterdam
#[Out]# 21   Albert Hein        Oss
#[Out]# 22         Jumbo  Amsterdam
#[Out]# 23         Jumbo    Utrecht
#[Out]# 24   Albert Hein  Amsterdam
#[Out]# 25   Albert Hein        Oss
#[Out]# 26          Lidl        Oss
#[Out]# 27          Lidl    Tilburg
#[Out]# 28          Coop  Eindhoven
#[Out]# 29          Coop        Oss
#[Out]# ..           ...        ...
#[Out]# 119         Lidl        Oss
#[Out]# 120         Lidl    Tilburg
#[Out]# 121         Coop  Eindhoven
#[Out]# 122         Coop        Oss
#[Out]# 123         Dirk  Amsterdam
#[Out]# 124         Dirk        Oss
#[Out]# 125         Dirk    Tilburg
#[Out]# 126         Dirk    Utrecht
#[Out]# 127         Coop  Eindhoven
#[Out]# 128         Coop        Oss
#[Out]# 129        Jumbo  Amsterdam
#[Out]# 130        Jumbo    Utrecht
#[Out]# 131         Dirk  Amsterdam
#[Out]# 132         Dirk        Oss
#[Out]# 133         Dirk    Tilburg
#[Out]# 134         Dirk    Utrecht
#[Out]# 135         Dirk  Amsterdam
#[Out]# 136         Dirk        Oss
#[Out]# 137         Dirk    Tilburg
#[Out]# 138         Dirk    Utrecht
#[Out]# 139        Jumbo  Amsterdam
#[Out]# 140        Jumbo    Utrecht
#[Out]# 141         Lidl        Oss
#[Out]# 142         Lidl    Tilburg
#[Out]# 143         Lidl        Oss
#[Out]# 144         Lidl    Tilburg
#[Out]# 145        Jumbo  Amsterdam
#[Out]# 146        Jumbo    Utrecht
#[Out]# 147        Jumbo  Amsterdam
#[Out]# 148        Jumbo    Utrecht
#[Out]# 
#[Out]# [149 rows x 2 columns]
# Wed, 09 Dec 2020 11:04:53
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select store_name, count(city) 
from missing 
group by store_name


'''

pd.read_sql_query(query4_3, conn)
#[Out]#     store_name  count(city)
#[Out]# 0  Albert Hein           16
#[Out]# 1         Coop           28
#[Out]# 2         Dirk           24
#[Out]# 3    Hoogvliet           27
#[Out]# 4        Jumbo           16
#[Out]# 5         Lidl           20
#[Out]# 6       Sligro           18
# Wed, 09 Dec 2020 11:05:00
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select store_name, count(distinct city) 
from missing 
group by store_name


'''

pd.read_sql_query(query4_3, conn)
#[Out]#     store_name  count(distinct city)
#[Out]# 0  Albert Hein                     2
#[Out]# 1         Coop                     2
#[Out]# 2         Dirk                     4
#[Out]# 3    Hoogvliet                     3
#[Out]# 4        Jumbo                     2
#[Out]# 5         Lidl                     2
#[Out]# 6       Sligro                     2
# Wed, 09 Dec 2020 11:06:59
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select s.sName, s.city
from store s
where (s.sName) not in (  select store_name
                                from missing);


'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:07:31
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select s.sName, s.city
from store s
where (s.sName) not in (  select store_name
                                from missing);


'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:07:41
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, sum(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select distinct c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:07:55
query4_4 = '''

with maxprice (value) as (
select max(price)
from (select cID, date, sum(price) as price
    from purchase
    group by cID, date) as maxpercusdate
    )

select c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:09:06
query4_4 = '''

with maxprice (value) as (  select max(price)
                            from (select cID, date, sum(price) as price
                                  from purchase
                                  group by cID, date) )

select c.cName
from (
    select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    ) as percentilecust, customer as c
where percentilecust.cID = c.cID 
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:09:44
query4_4 = '''

with maxprice (value) as (  select max(price)
                            from (select cID, date, sum(price) as price
                                  from purchase
                                  group by cID, date) )

select cID, date
    from purchase, maxprice
    group by cID, date
    having price > (0.75 * maxprice.value)
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:09:56
query4_4 = '''

with maxprice (value) as (  select max(price)
                            from (select cID, date, sum(price) as price
                                  from purchase
                                  group by cID, date) )

select cID, date
from purchase, maxprice
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date
#[Out]# 0      0  2018-08-22
#[Out]# 1      1  2018-08-20
#[Out]# 2      1  2018-08-20
#[Out]# 3      1  2018-08-20
#[Out]# 4      1  2018-08-20
#[Out]# 5      1  2018-08-20
#[Out]# 6      1  2018-08-21
#[Out]# 7      1  2018-08-21
#[Out]# 8      2  2018-08-16
#[Out]# 9      2  2018-08-17
#[Out]# 10     2  2018-08-17
#[Out]# 11     2  2018-08-17
#[Out]# 12     2  2018-08-17
#[Out]# 13     3  2018-08-18
#[Out]# 14     3  2018-08-19
#[Out]# 15     3  2018-08-19
#[Out]# 16     4  2018-08-24
#[Out]# 17     4  2018-08-24
#[Out]# 18     4  2018-08-25
#[Out]# 19     4  2018-08-24
#[Out]# 20     4  2018-08-25
#[Out]# 21     4  2018-08-25
#[Out]# 22     5  2018-08-17
#[Out]# 23     5  2018-08-22
#[Out]# 24     5  2018-08-23
#[Out]# 25     5  2018-08-23
#[Out]# 26     5  2018-08-23
#[Out]# 27     5  2018-08-23
#[Out]# 28     7  2018-08-23
#[Out]# 29     7  2018-08-23
#[Out]# ..   ...         ...
#[Out]# 479  190  2018-08-20
#[Out]# 480  190  2018-08-15
#[Out]# 481  190  2018-08-23
#[Out]# 482  190  2018-08-15
#[Out]# 483  190  2018-08-24
#[Out]# 484  190  2018-08-25
#[Out]# 485  190  2018-08-15
#[Out]# 486  190  2018-08-15
#[Out]# 487  190  2018-08-22
#[Out]# 488  190  2018-08-17
#[Out]# 489  190  2018-08-18
#[Out]# 490  190  2018-08-19
#[Out]# 491  190  2018-08-25
#[Out]# 492  190  2018-08-17
#[Out]# 493  190  2018-08-26
#[Out]# 494  190  2018-08-17
#[Out]# 495  190  2018-08-22
#[Out]# 496  190  2018-08-19
#[Out]# 497  190  2018-08-15
#[Out]# 498  190  2018-08-18
#[Out]# 499  190  2018-08-25
#[Out]# 500  190  2018-08-18
#[Out]# 501  190  2018-08-15
#[Out]# 502  190  2018-08-22
#[Out]# 503  190  2018-08-19
#[Out]# 504  190  2018-08-26
#[Out]# 505  190  2018-08-27
#[Out]# 506  190  2018-08-23
#[Out]# 507  190  2018-08-16
#[Out]# 508  190  2018-08-21
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Wed, 09 Dec 2020 11:10:15
query4_4 = '''

with maxprice (value) as (  select max(price)
                            from (select cID, date, sum(price) as price
                                  from purchase
                                  group by cID, date) )

select cID, date
from purchase, maxprice
group by cID, date
having price > (0.75 * maxprice.value)
    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:11:18
query4_4 = '''

                                  
select p.cID, p.date, p.sum(price) as price
from purchase p
group by p.cID, p.date


    
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:11:27
query4_4 = '''

                                  
select p.cID, p.date, sum(price) as price
from purchase p
group by p.cID, p.date


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   4.20
#[Out]# 7      4  2018-08-24  14.25
#[Out]# 8      4  2018-08-25  19.40
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   6.70
#[Out]# 12     7  2018-08-23   3.80
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   3.10
#[Out]# 16     8  2018-08-16   6.25
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17  13.30
#[Out]# 20    13  2018-08-25   6.50
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19  11.05
#[Out]# 26    16  2018-08-24   6.05
#[Out]# 27    16  2018-08-25   4.95
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   7.50
#[Out]# 256  179  2018-08-22  10.85
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   6.95
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.65
#[Out]# 261  181  2018-08-24   3.60
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28  14.90
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15  19.60
#[Out]# 273  190  2018-08-16  12.80
#[Out]# 274  190  2018-08-17  15.75
#[Out]# 275  190  2018-08-18  14.85
#[Out]# 276  190  2018-08-19  20.30
#[Out]# 277  190  2018-08-20  10.85
#[Out]# 278  190  2018-08-21   3.85
#[Out]# 279  190  2018-08-22  14.55
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 11:13:10
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )
                                    
select *
from maxvalue


    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    value
#[Out]# 0   39.1
# Wed, 09 Dec 2020 11:15:00
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

from purchase p, customer c
where p.cID = c.cID
group by p.cID, p.date
                                    



    
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:15:11
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.cID, p.date
from purchase p, customer c
where p.cID = c.cID
group by p.cID, p.date
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date
#[Out]# 0      0  2018-08-22
#[Out]# 1      1  2018-08-20
#[Out]# 2      1  2018-08-21
#[Out]# 3      2  2018-08-16
#[Out]# 4      2  2018-08-17
#[Out]# 5      3  2018-08-18
#[Out]# 6      3  2018-08-19
#[Out]# 7      4  2018-08-24
#[Out]# 8      4  2018-08-25
#[Out]# 9      5  2018-08-17
#[Out]# 10     5  2018-08-22
#[Out]# 11     5  2018-08-23
#[Out]# 12     7  2018-08-23
#[Out]# 13     7  2018-08-24
#[Out]# 14     7  2018-08-25
#[Out]# 15     7  2018-08-26
#[Out]# 16     8  2018-08-16
#[Out]# 17    10  2018-08-27
#[Out]# 18    11  2018-08-25
#[Out]# 19    13  2018-08-17
#[Out]# 20    13  2018-08-25
#[Out]# 21    13  2018-08-26
#[Out]# 22    13  2018-08-27
#[Out]# 23    15  2018-08-27
#[Out]# 24    16  2018-08-18
#[Out]# 25    16  2018-08-19
#[Out]# 26    16  2018-08-24
#[Out]# 27    16  2018-08-25
#[Out]# 28    16  2018-08-26
#[Out]# 29    16  2018-08-27
#[Out]# ..   ...         ...
#[Out]# 255  178  2018-08-27
#[Out]# 256  179  2018-08-22
#[Out]# 257  179  2018-08-23
#[Out]# 258  179  2018-08-24
#[Out]# 259  180  2018-08-26
#[Out]# 260  180  2018-08-27
#[Out]# 261  181  2018-08-24
#[Out]# 262  181  2018-08-27
#[Out]# 263  182  2018-08-23
#[Out]# 264  182  2018-08-28
#[Out]# 265  184  2018-08-20
#[Out]# 266  185  2018-08-20
#[Out]# 267  186  2018-08-21
#[Out]# 268  188  2018-08-20
#[Out]# 269  188  2018-09-20
#[Out]# 270  189  2018-08-25
#[Out]# 271  189  2018-08-26
#[Out]# 272  190  2018-08-15
#[Out]# 273  190  2018-08-16
#[Out]# 274  190  2018-08-17
#[Out]# 275  190  2018-08-18
#[Out]# 276  190  2018-08-19
#[Out]# 277  190  2018-08-20
#[Out]# 278  190  2018-08-21
#[Out]# 279  190  2018-08-22
#[Out]# 280  190  2018-08-23
#[Out]# 281  190  2018-08-24
#[Out]# 282  190  2018-08-25
#[Out]# 283  190  2018-08-26
#[Out]# 284  190  2018-08-27
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Wed, 09 Dec 2020 11:15:22
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.*
from purchase p, customer c
where p.cID = c.cID
group by p.cID, p.date
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      6    1   46   11  2018-08-21         8   0.90
#[Out]# 3      8    2   12   20  2018-08-16         1   2.45
#[Out]# 4      9    2   39    9  2018-08-17         7   1.35
#[Out]# 5     13    3   44   14  2018-08-18         2   4.30
#[Out]# 6     14    3   30   26  2018-08-19         2   2.75
#[Out]# 7     16    4   17    8  2018-08-24         2   4.15
#[Out]# 8     18    4   53   12  2018-08-25         5  13.60
#[Out]# 9     22    5    4   14  2018-08-17         6   4.70
#[Out]# 10    23    5   36   28  2018-08-22         6   8.25
#[Out]# 11    24    5   55    6  2018-08-23         9   1.10
#[Out]# 12    28    7    3   19  2018-08-23         2   2.10
#[Out]# 13    30    7   11   16  2018-08-24         4   1.90
#[Out]# 14    31    7   32   12  2018-08-25         2  10.75
#[Out]# 15    32    7   38    6  2018-08-26         4   1.05
#[Out]# 16    34    8   43    6  2018-08-16         7   0.95
#[Out]# 17    36   10   34   24  2018-08-27         5   3.20
#[Out]# 18    37   11    0   14  2018-08-25         8   4.10
#[Out]# 19    38   13   33    0  2018-08-17         5   5.35
#[Out]# 20    41   13   33   17  2018-08-25         5   2.00
#[Out]# 21    45   13   26    9  2018-08-26         3   1.65
#[Out]# 22    46   13    8    5  2018-08-27         6   0.50
#[Out]# 23    47   15   25   11  2018-08-27         5   0.90
#[Out]# 24    55   16   36   13  2018-08-18         1   2.90
#[Out]# 25    56   16   13    7  2018-08-19         3   1.80
#[Out]# 26    48   16   50    0  2018-08-24         1   3.70
#[Out]# 27    50   16   22    5  2018-08-25         7   0.55
#[Out]# 28    53   16   27   19  2018-08-26         8   3.00
#[Out]# 29    54   16   55   16  2018-08-27         8   1.85
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 255  458  178   34   25  2018-08-27         9   3.60
#[Out]# 256  463  179   43   27  2018-08-22         8   9.00
#[Out]# 257  465  179   45   10  2018-08-23         7   0.45
#[Out]# 258  460  179   25   14  2018-08-24         5   3.70
#[Out]# 259  466  180   34   26  2018-08-26         3   3.10
#[Out]# 260  467  180   34   13  2018-08-27         8   4.05
#[Out]# 261  469  181    6   26  2018-08-24         4   2.70
#[Out]# 262  471  181   27   21  2018-08-27         5   2.00
#[Out]# 263  474  182    4   13  2018-08-23         9   4.20
#[Out]# 264  472  182   17   25  2018-08-28         8   3.90
#[Out]# 265  777  184    0    0  2018-08-20         2   3.50
#[Out]# 266  778  185   62   29  2018-08-20         1   1.00
#[Out]# 267  779  186   62   29  2018-08-21         5   1.00
#[Out]# 268  780  188   62   30  2018-08-20         1   1.00
#[Out]# 269  781  188   62   30  2018-09-20         1   1.00
#[Out]# 270  782  189   63    7  2018-08-25         5   1.25
#[Out]# 271  783  189   20   19  2018-08-26         3   2.50
#[Out]# 272  790  190    6   10  2018-08-15         2   4.15
#[Out]# 273  792  190    8   20  2018-08-16         7   3.25
#[Out]# 274  796  190   12   26  2018-08-17         6   2.75
#[Out]# 275  807  190   23    3  2018-08-18         1   2.75
#[Out]# 276  784  190    0   27  2018-08-19         5   4.45
#[Out]# 277  791  190    7   22  2018-08-20         4   3.20
#[Out]# 278  802  190   18   27  2018-08-21         4   0.55
#[Out]# 279  794  190   10   19  2018-08-22         7   0.90
#[Out]# 280  787  190    3   28  2018-08-23         5   0.50
#[Out]# 281  785  190    1   19  2018-08-24         6   2.55
#[Out]# 282  823  190   39    0  2018-08-25         4   3.70
#[Out]# 283  788  190    4    7  2018-08-26         7   1.30
#[Out]# 284  813  190   29   17  2018-08-27         5   1.20
#[Out]# 
#[Out]# [285 rows x 7 columns]
# Wed, 09 Dec 2020 11:16:18
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.*
from purchase p, customer c, maxvalue m
where p.cID = c.cID
group by p.cID, p.date
having p.price > m.value 
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:16:25
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.*
from purchase p, customer c, maxvalue m
where p.cID = c.cID
group by p.cID, p.date
having p.price > 0.75 * m.value 
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:16:30
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.*
from purchase p, customer c, maxvalue m
where p.cID = c.cID
group by p.cID, p.date
having p.price > (0.75 * m.value)
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:16:54
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.*
from purchase p, customer c, maxvalue m
where p.cID = c.cID
group by p.cID, p.date
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      6    1   46   11  2018-08-21         8   0.90
#[Out]# 3      8    2   12   20  2018-08-16         1   2.45
#[Out]# 4      9    2   39    9  2018-08-17         7   1.35
#[Out]# 5     13    3   44   14  2018-08-18         2   4.30
#[Out]# 6     14    3   30   26  2018-08-19         2   2.75
#[Out]# 7     16    4   17    8  2018-08-24         2   4.15
#[Out]# 8     18    4   53   12  2018-08-25         5  13.60
#[Out]# 9     22    5    4   14  2018-08-17         6   4.70
#[Out]# 10    23    5   36   28  2018-08-22         6   8.25
#[Out]# 11    24    5   55    6  2018-08-23         9   1.10
#[Out]# 12    28    7    3   19  2018-08-23         2   2.10
#[Out]# 13    30    7   11   16  2018-08-24         4   1.90
#[Out]# 14    31    7   32   12  2018-08-25         2  10.75
#[Out]# 15    32    7   38    6  2018-08-26         4   1.05
#[Out]# 16    34    8   43    6  2018-08-16         7   0.95
#[Out]# 17    36   10   34   24  2018-08-27         5   3.20
#[Out]# 18    37   11    0   14  2018-08-25         8   4.10
#[Out]# 19    38   13   33    0  2018-08-17         5   5.35
#[Out]# 20    41   13   33   17  2018-08-25         5   2.00
#[Out]# 21    45   13   26    9  2018-08-26         3   1.65
#[Out]# 22    46   13    8    5  2018-08-27         6   0.50
#[Out]# 23    47   15   25   11  2018-08-27         5   0.90
#[Out]# 24    55   16   36   13  2018-08-18         1   2.90
#[Out]# 25    56   16   13    7  2018-08-19         3   1.80
#[Out]# 26    48   16   50    0  2018-08-24         1   3.70
#[Out]# 27    50   16   22    5  2018-08-25         7   0.55
#[Out]# 28    53   16   27   19  2018-08-26         8   3.00
#[Out]# 29    54   16   55   16  2018-08-27         8   1.85
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 255  458  178   34   25  2018-08-27         9   3.60
#[Out]# 256  463  179   43   27  2018-08-22         8   9.00
#[Out]# 257  465  179   45   10  2018-08-23         7   0.45
#[Out]# 258  460  179   25   14  2018-08-24         5   3.70
#[Out]# 259  466  180   34   26  2018-08-26         3   3.10
#[Out]# 260  467  180   34   13  2018-08-27         8   4.05
#[Out]# 261  469  181    6   26  2018-08-24         4   2.70
#[Out]# 262  471  181   27   21  2018-08-27         5   2.00
#[Out]# 263  474  182    4   13  2018-08-23         9   4.20
#[Out]# 264  472  182   17   25  2018-08-28         8   3.90
#[Out]# 265  777  184    0    0  2018-08-20         2   3.50
#[Out]# 266  778  185   62   29  2018-08-20         1   1.00
#[Out]# 267  779  186   62   29  2018-08-21         5   1.00
#[Out]# 268  780  188   62   30  2018-08-20         1   1.00
#[Out]# 269  781  188   62   30  2018-09-20         1   1.00
#[Out]# 270  782  189   63    7  2018-08-25         5   1.25
#[Out]# 271  783  189   20   19  2018-08-26         3   2.50
#[Out]# 272  790  190    6   10  2018-08-15         2   4.15
#[Out]# 273  792  190    8   20  2018-08-16         7   3.25
#[Out]# 274  796  190   12   26  2018-08-17         6   2.75
#[Out]# 275  807  190   23    3  2018-08-18         1   2.75
#[Out]# 276  784  190    0   27  2018-08-19         5   4.45
#[Out]# 277  791  190    7   22  2018-08-20         4   3.20
#[Out]# 278  802  190   18   27  2018-08-21         4   0.55
#[Out]# 279  794  190   10   19  2018-08-22         7   0.90
#[Out]# 280  787  190    3   28  2018-08-23         5   0.50
#[Out]# 281  785  190    1   19  2018-08-24         6   2.55
#[Out]# 282  823  190   39    0  2018-08-25         4   3.70
#[Out]# 283  788  190    4    7  2018-08-26         7   1.30
#[Out]# 284  813  190   29   17  2018-08-27         5   1.20
#[Out]# 
#[Out]# [285 rows x 7 columns]
# Wed, 09 Dec 2020 11:17:16
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.*
from purchase p, customer c, maxvalue m
where p.cID = c.cID
group by p.cID, p.date
having price = m.value
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:17:20
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.*
from purchase p, customer c, maxvalue m
where p.cID = c.cID
group by p.cID, p.date
having p.price = m.value
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:18:45
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.cID, p.date, sum(price) as price
from purchase p, maxvalue m
group by p.cID, p.date
having p.price > 0.75 * m.value
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date, price]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:18:54
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.cID, p.date, sum(price) as price
from purchase p, maxvalue m
group by p.cID, p.date
having p.price > (0.75 * m.value)
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date, price]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:19:01
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.cID, p.date, sum(price) as price
from purchase p, maxvalue m
group by p.cID, p.date
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   4.20
#[Out]# 7      4  2018-08-24  14.25
#[Out]# 8      4  2018-08-25  19.40
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   6.70
#[Out]# 12     7  2018-08-23   3.80
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   3.10
#[Out]# 16     8  2018-08-16   6.25
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17  13.30
#[Out]# 20    13  2018-08-25   6.50
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19  11.05
#[Out]# 26    16  2018-08-24   6.05
#[Out]# 27    16  2018-08-25   4.95
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   7.50
#[Out]# 256  179  2018-08-22  10.85
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   6.95
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.65
#[Out]# 261  181  2018-08-24   3.60
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28  14.90
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15  19.60
#[Out]# 273  190  2018-08-16  12.80
#[Out]# 274  190  2018-08-17  15.75
#[Out]# 275  190  2018-08-18  14.85
#[Out]# 276  190  2018-08-19  20.30
#[Out]# 277  190  2018-08-20  10.85
#[Out]# 278  190  2018-08-21   3.85
#[Out]# 279  190  2018-08-22  14.55
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 11:19:40
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select max(price) from (
select p.cID, p.date, sum(price) as price
from purchase p, maxvalue m
group by p.cID, p.date)
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    max(price)
#[Out]# 0        39.1
# Wed, 09 Dec 2020 11:19:54
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select p.cID, p.date, max(price) from (
select p.cID, p.date, sum(price) as price
from purchase p, maxvalue m
group by p.cID, p.date)
                                    



    
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:20:02
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select cID, date, max(price) from (
select p.cID, p.date, sum(price) as price
from purchase p, maxvalue m
group by p.cID, p.date)
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  max(price)
#[Out]# 0  161  2018-08-26        39.1
# Wed, 09 Dec 2020 11:20:30
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select 0.75 * max(price) from (
select p.cID, p.date, sum(price) as price
from purchase p, maxvalue m
group by p.cID, p.date)
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    0.75 * max(price)
#[Out]# 0             29.325
# Wed, 09 Dec 2020 11:22:06
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select *
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     )

                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   4.20
#[Out]# 7      4  2018-08-24  14.25
#[Out]# 8      4  2018-08-25  19.40
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   6.70
#[Out]# 12     7  2018-08-23   3.80
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   3.10
#[Out]# 16     8  2018-08-16   6.25
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17  13.30
#[Out]# 20    13  2018-08-25   6.50
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19  11.05
#[Out]# 26    16  2018-08-24   6.05
#[Out]# 27    16  2018-08-25   4.95
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   7.50
#[Out]# 256  179  2018-08-22  10.85
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   6.95
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.65
#[Out]# 261  181  2018-08-24   3.60
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28  14.90
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15  19.60
#[Out]# 273  190  2018-08-16  12.80
#[Out]# 274  190  2018-08-17  15.75
#[Out]# 275  190  2018-08-18  14.85
#[Out]# 276  190  2018-08-19  20.30
#[Out]# 277  190  2018-08-20  10.85
#[Out]# 278  190  2018-08-21   3.85
#[Out]# 279  190  2018-08-22  14.55
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 11:22:36
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select *
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     )
having price > 0.75 * maxvalue.value
                                    



    
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:22:48
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select *
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     )
where price > 0.75 * maxvalue.value
                                    



    
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:22:55
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select *
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     ), maxvalue m
where price > 0.75 * maxvalue.value
                                    



    
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:23:02
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select *
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     ), maxvalue m
where price > 0.75 * m.value
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price  value
#[Out]# 0  161  2018-08-26   39.1   39.1
# Wed, 09 Dec 2020 11:23:41
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select c.cID, c.cName
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     ), maxvalue m, customer c
where price > 0.75 * m.value and p.cID = c.cID
                                    



    
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 11:23:55
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select c.cID, c.cName
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     ), maxvalue m, customer c
where price > 0.75 * m.value 
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID     cName
#[Out]# 0      0      Noah
#[Out]# 1      1       Sem
#[Out]# 2      2     Lucas
#[Out]# 3      3      Finn
#[Out]# 4      4      Daan
#[Out]# 5      5      Levi
#[Out]# 6      6     Milan
#[Out]# 7      7      Bram
#[Out]# 8      8      Liam
#[Out]# 9      9    Thomas
#[Out]# 10    10       Sam
#[Out]# 11    11     Thijs
#[Out]# 12    12      Adam
#[Out]# 13    13     James
#[Out]# 14    14       Max
#[Out]# 15    15      Noud
#[Out]# 16    16    Julian
#[Out]# 17    17       Dex
#[Out]# 18    18      Hugo
#[Out]# 19    19      Lars
#[Out]# 20    20      Gijs
#[Out]# 21    21  Benjamin
#[Out]# 22    22      Mats
#[Out]# 23    23       Jan
#[Out]# 24    24      Luca
#[Out]# 25    25     Mason
#[Out]# 26    26    Jayden
#[Out]# 27    27       Tim
#[Out]# 28    28      Siem
#[Out]# 29    29     Ruben
#[Out]# ..   ...       ...
#[Out]# 160  160      Lara
#[Out]# 161  161     Floor
#[Out]# 162  162     Elena
#[Out]# 163  163      Cato
#[Out]# 164  164       Evy
#[Out]# 165  165     Hanna
#[Out]# 166  166   Rosalie
#[Out]# 167  167    Veerle
#[Out]# 168  168      Kiki
#[Out]# 169  169      Lily
#[Out]# 170  170      Iris
#[Out]# 171  171     Tessa
#[Out]# 172  172      Lana
#[Out]# 173  173     Livia
#[Out]# 174  174      Romy
#[Out]# 175  175       Sam
#[Out]# 176  176     Amira
#[Out]# 177  177     Eline
#[Out]# 178  178      Elif
#[Out]# 179  179      Juul
#[Out]# 180  180     Merel
#[Out]# 181  181      Liva
#[Out]# 182  182   Johanna
#[Out]# 183  183     Nikki
#[Out]# 184  184     Wilko
#[Out]# 185  185      Nick
#[Out]# 186  186    Angela
#[Out]# 187  188      Pino
#[Out]# 188  189      Koen
#[Out]# 189  190    Kostas
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Wed, 09 Dec 2020 11:24:14
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select *
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     ), maxvalue m, customer c
where price > 0.75 * m.value 
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price  value  cID     cName                street  \
#[Out]# 0    161  2018-08-26   39.1   39.1    0      Noah             Koestraat   
#[Out]# 1    161  2018-08-26   39.1   39.1    1       Sem      Rozemarijnstraat   
#[Out]# 2    161  2018-08-26   39.1   39.1    2     Lucas      Oude Leliestraat   
#[Out]# 3    161  2018-08-26   39.1   39.1    3      Finn         Stationsplein   
#[Out]# 4    161  2018-08-26   39.1   39.1    4      Daan          Kalverstraat   
#[Out]# 5    161  2018-08-26   39.1   39.1    5      Levi        Gasthuisstraat   
#[Out]# 6    161  2018-08-26   39.1   39.1    6     Milan           Parallelweg   
#[Out]# 7    161  2018-08-26   39.1   39.1    7      Bram          Schoolstraat   
#[Out]# 8    161  2018-08-26   39.1   39.1    8      Liam         Rijsbergseweg   
#[Out]# 9    161  2018-08-26   39.1   39.1    9    Thomas           Parallelweg   
#[Out]# 10   161  2018-08-26   39.1   39.1   10       Sam           Langestraat   
#[Out]# 11   161  2018-08-26   39.1   39.1   11     Thijs             Koestraat   
#[Out]# 12   161  2018-08-26   39.1   39.1   12      Adam           Nieuwstraat   
#[Out]# 13   161  2018-08-26   39.1   39.1   13     James       Sint Annastraat   
#[Out]# 14   161  2018-08-26   39.1   39.1   14       Max             Eikenlaan   
#[Out]# 15   161  2018-08-26   39.1   39.1   15      Noud          Koningshoeve   
#[Out]# 16   161  2018-08-26   39.1   39.1   16    Julian  Prins Bernhardstraat   
#[Out]# 17   161  2018-08-26   39.1   39.1   17       Dex          Kasteeldreef   
#[Out]# 18   161  2018-08-26   39.1   39.1   18      Hugo          Kasteeldreef   
#[Out]# 19   161  2018-08-26   39.1   39.1   19      Lars         Rijsbergseweg   
#[Out]# 20   161  2018-08-26   39.1   39.1   20      Gijs            Heiligeweg   
#[Out]# 21   161  2018-08-26   39.1   39.1   21  Benjamin           Stationsweg   
#[Out]# 22   161  2018-08-26   39.1   39.1   22      Mats           Molenstraat   
#[Out]# 23   161  2018-08-26   39.1   39.1   23       Jan       Sint Annastraat   
#[Out]# 24   161  2018-08-26   39.1   39.1   24      Luca          Kasteeldreef   
#[Out]# 25   161  2018-08-26   39.1   39.1   25     Mason          Keizerstraat   
#[Out]# 26   161  2018-08-26   39.1   39.1   26    Jayden          Schoolstraat   
#[Out]# 27   161  2018-08-26   39.1   39.1   27       Tim             Koestraat   
#[Out]# 28   161  2018-08-26   39.1   39.1   28      Siem           Langestraat   
#[Out]# 29   161  2018-08-26   39.1   39.1   29     Ruben              Hofplein   
#[Out]# ..   ...         ...    ...    ...  ...       ...                   ...   
#[Out]# 160  161  2018-08-26   39.1   39.1  160      Lara           Langestraat   
#[Out]# 161  161  2018-08-26   39.1   39.1  161     Floor             Eikenlaan   
#[Out]# 162  161  2018-08-26   39.1   39.1  162     Elena            Bergselaan   
#[Out]# 163  161  2018-08-26   39.1   39.1  163      Cato          Kastanjelaan   
#[Out]# 164  161  2018-08-26   39.1   39.1  164       Evy      Rozemarijnstraat   
#[Out]# 165  161  2018-08-26   39.1   39.1  165     Hanna             Eikenlaan   
#[Out]# 166  161  2018-08-26   39.1   39.1  166   Rosalie           Stationsweg   
#[Out]# 167  161  2018-08-26   39.1   39.1  167    Veerle        Ginnekenstraat   
#[Out]# 168  161  2018-08-26   39.1   39.1  168      Kiki          Keizerstraat   
#[Out]# 169  161  2018-08-26   39.1   39.1  169      Lily        Gasthuisstraat   
#[Out]# 170  161  2018-08-26   39.1   39.1  170      Iris          Kastanjelaan   
#[Out]# 171  161  2018-08-26   39.1   39.1  171     Tessa           Haringvliet   
#[Out]# 172  161  2018-08-26   39.1   39.1  172      Lana             Eikenlaan   
#[Out]# 173  161  2018-08-26   39.1   39.1  173     Livia      Vierwindenstraat   
#[Out]# 174  161  2018-08-26   39.1   39.1  174      Romy           Parallelweg   
#[Out]# 175  161  2018-08-26   39.1   39.1  175       Sam             Bredalaan   
#[Out]# 176  161  2018-08-26   39.1   39.1  176     Amira           Parallelweg   
#[Out]# 177  161  2018-08-26   39.1   39.1  177     Eline          Kalverstraat   
#[Out]# 178  161  2018-08-26   39.1   39.1  178      Elif           Parallelweg   
#[Out]# 179  161  2018-08-26   39.1   39.1  179      Juul        Wilhelminapark   
#[Out]# 180  161  2018-08-26   39.1   39.1  180     Merel          Kalverstraat   
#[Out]# 181  161  2018-08-26   39.1   39.1  181      Liva           Fredriklaan   
#[Out]# 182  161  2018-08-26   39.1   39.1  182   Johanna         Beatrixstraat   
#[Out]# 183  161  2018-08-26   39.1   39.1  183     Nikki         Julianastraat   
#[Out]# 184  161  2018-08-26   39.1   39.1  184     Wilko          Onbekendeweg   
#[Out]# 185  161  2018-08-26   39.1   39.1  185      Nick                Verweg   
#[Out]# 186  161  2018-08-26   39.1   39.1  186    Angela              Dichtweg   
#[Out]# 187  161  2018-08-26   39.1   39.1  188      Pino            Maanstraat   
#[Out]# 188  161  2018-08-26   39.1   39.1  189      Koen              Akkerweg   
#[Out]# 189  161  2018-08-26   39.1   39.1  190    Kostas              Eindeweg   
#[Out]# 
#[Out]#           city  
#[Out]# 0      Utrecht  
#[Out]# 1        Breda  
#[Out]# 2    Amsterdam  
#[Out]# 3        Breda  
#[Out]# 4    Amsterdam  
#[Out]# 5      Utrecht  
#[Out]# 6      Utrecht  
#[Out]# 7    Eindhoven  
#[Out]# 8        Breda  
#[Out]# 9    Amsterdam  
#[Out]# 10     Tilburg  
#[Out]# 11     Tilburg  
#[Out]# 12   Eindhoven  
#[Out]# 13       Breda  
#[Out]# 14     Tilburg  
#[Out]# 15     Tilburg  
#[Out]# 16   Eindhoven  
#[Out]# 17     Tilburg  
#[Out]# 18     Tilburg  
#[Out]# 19       Breda  
#[Out]# 20   Amsterdam  
#[Out]# 21     Tilburg  
#[Out]# 22   Eindhoven  
#[Out]# 23       Breda  
#[Out]# 24     Tilburg  
#[Out]# 25   Rotterdam  
#[Out]# 26   Eindhoven  
#[Out]# 27     Utrecht  
#[Out]# 28     Tilburg  
#[Out]# 29   Rotterdam  
#[Out]# ..         ...  
#[Out]# 160    Tilburg  
#[Out]# 161    Tilburg  
#[Out]# 162  Rotterdam  
#[Out]# 163    Tilburg  
#[Out]# 164      Breda  
#[Out]# 165    Tilburg  
#[Out]# 166  Eindhoven  
#[Out]# 167      Breda  
#[Out]# 168  Rotterdam  
#[Out]# 169    Utrecht  
#[Out]# 170  Eindhoven  
#[Out]# 171  Rotterdam  
#[Out]# 172    Tilburg  
#[Out]# 173      Breda  
#[Out]# 174  Eindhoven  
#[Out]# 175  Eindhoven  
#[Out]# 176  Amsterdam  
#[Out]# 177  Amsterdam  
#[Out]# 178    Utrecht  
#[Out]# 179    Tilburg  
#[Out]# 180  Amsterdam  
#[Out]# 181  Eindhoven  
#[Out]# 182  Eindhoven  
#[Out]# 183    Utrecht  
#[Out]# 184  Eindhoven  
#[Out]# 185  Eindhoven  
#[Out]# 186  Eindhoven  
#[Out]# 187  Rotterdam  
#[Out]# 188        Oss  
#[Out]# 189    Utrecht  
#[Out]# 
#[Out]# [190 rows x 8 columns]
# Wed, 09 Dec 2020 11:24:24
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select *
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     ), maxvalue m
where price > 0.75 * m.value 
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price  value
#[Out]# 0  161  2018-08-26   39.1   39.1
# Wed, 09 Dec 2020 11:25:20
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select temp.cID, c.cName
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     ) as temp, maxvalue m, customer c
where price > 0.75 * m.value and c.cID = temp.cID
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Wed, 09 Dec 2020 11:25:30
query4_4 = '''

with maxvalue(value) as (   select max(price)
                            from (  select p.cID, p.date, sum(price) as price
                                    from purchase p
                                    group by p.cID, p.date ) )

select c.cName
from (      select p.cID, p.date, sum(price) as price
            from purchase p, maxvalue m
            group by p.cID, p.date     ) as temp, maxvalue m, customer c
where price > 0.75 * m.value and c.cID = temp.cID
                                    



    
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 11:26:06
query4_5 = '''
 
 with inventory_size(sID, date, size) as (
	select sID, date, count(distinct pID)
	from inventory
	group by sID, date
	)
            
select sID, sName
from store
where sID in (
	select sID
	from inventory_size
	where size <= 20);

'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# 5     5       Sligro
#[Out]# 6     6         Coop
#[Out]# 7     7       Sligro
#[Out]# 8     8  Albert Hein
#[Out]# 9     9  Albert Hein
#[Out]# 10   10        Jumbo
#[Out]# 11   11  Albert Hein
#[Out]# 12   12         Lidl
#[Out]# 13   13         Coop
#[Out]# 14   14         Coop
#[Out]# 15   15         Lidl
#[Out]# 16   16         Lidl
#[Out]# 17   17    Hoogvliet
#[Out]# 18   18       Sligro
#[Out]# 19   19         Coop
#[Out]# 20   20        Jumbo
#[Out]# 21   21         Coop
#[Out]# 22   22         Lidl
#[Out]# 23   23         Dirk
#[Out]# 24   24  Albert Hein
#[Out]# 25   25  Albert Hein
#[Out]# 26   26    Hoogvliet
#[Out]# 27   27       Sligro
#[Out]# 28   28    Hoogvliet
#[Out]# 29   29       Sligro
#[Out]# ..  ...          ...
#[Out]# 31   31         Coop
#[Out]# 32   32  Albert Hein
#[Out]# 33   33         Dirk
#[Out]# 34   34         Coop
#[Out]# 35   35         Lidl
#[Out]# 36   36         Lidl
#[Out]# 37   37        Jumbo
#[Out]# 38   38    Hoogvliet
#[Out]# 39   39       Sligro
#[Out]# 40   40    Hoogvliet
#[Out]# 41   41  Albert Hein
#[Out]# 42   42       Sligro
#[Out]# 43   43         Coop
#[Out]# 44   44  Albert Hein
#[Out]# 45   45         Coop
#[Out]# 46   46         Lidl
#[Out]# 47   47         Coop
#[Out]# 48   48    Hoogvliet
#[Out]# 49   49    Hoogvliet
#[Out]# 50   50       Sligro
#[Out]# 51   51         Coop
#[Out]# 52   52         Lidl
#[Out]# 53   53         Coop
#[Out]# 54   54         Dirk
#[Out]# 55   55         Coop
#[Out]# 56   56        Jumbo
#[Out]# 57   57         Dirk
#[Out]# 58   58         Dirk
#[Out]# 59   59        Jumbo
#[Out]# 60   60         Lidl
#[Out]# 
#[Out]# [61 rows x 2 columns]
# Wed, 09 Dec 2020 11:26:23
query4_5 = '''
 
with citieswithcust(city, amount) as (  select c.city, count(distinct c.cID) as amount_customers
                                        from purchase p, store s, customer c
                                        where p.sID = s.sID and s.city = "Eindhoven" and p.cID = c.cID
                                        group by c.city ),
                                        
      citieswithoutcust (city, amount) as (  select s.city, 0
                                        from store s
                                        where s.city not in (select city from citieswithcust) )
                                        
select * from citieswithcust
union
select * from citieswithoutcust  ;

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Wed, 09 Dec 2020 11:26:55
query4_3 = '''
with    allCities (allcities) as (  select city 
                                    from customer 
                                    union 
                                    select city 
                                    from store    ),
        possible (sName, city) as ( select s.sName, a.allcities 
                                    from store s, allCities a),
        actual(sName, city) as (    select s.sName, s.city
                                    from store s),
        missing(store_name, city) as (select p.sName, p.city 
                                    from possible p
                                    where (p.sName, p.city) not in actual)
                                    
select s.sName, s.city
from store s
where (s.sName) not in (  select store_name
                                from missing);


'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []


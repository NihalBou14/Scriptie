# IPython log file

query4_3 = '''
    SELECT DISTINCT s.sName, s.city FROM store as s 
        WHERE NOT EXISTS (
    SELECT c.city from customer as c
        UNION
    SELECT s1.city from store as s1
        EXCEPT 
    SELECT s2.city from store as s2 WHERE s2.sName = s.sName)
'''
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 13:46:28
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 13:46:30
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 08 Dec 2020 13:46:33
query4_3 = '''
    SELECT DISTINCT s.sName, s.city FROM store as s 
        WHERE NOT EXISTS (
    SELECT c.city from customer as c
        UNION
    SELECT s1.city from store as s1
        EXCEPT 
    SELECT s2.city from store as s2 WHERE s2.sName = s.sName)
'''
# Tue, 08 Dec 2020 13:46:34
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 13:48:52
query4_3 = '''
    SELECT DISTINCT s.sName FROM store as s 
        WHERE NOT EXISTS (
    SELECT c.city from customer as c
        UNION
    SELECT s1.city from store as s1
        EXCEPT 
    SELECT s2.city from store as s2 WHERE s2.sName = s.sName)
'''
# Tue, 08 Dec 2020 13:48:53
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 13:49:58
query4_5 = '''
    WITH EhvPurchasers (ident, custcity) as (SELECT c.cID, s.city from customer as c, purchase as p, store as s 
    WHERE p.cId = c.cID AND p.sID = s.sID AND s.city = "Eindhoven")
    SELECT c.city, count(distinct ident) from customer as c, EhvPurchasers WHERE c.cID = EhvPurchasers.ident GROUP BY c.city
'''
# Tue, 08 Dec 2020 13:50:00
pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(distinct ident)
#[Out]# 0  Amsterdam                     10
#[Out]# 1      Breda                      9
#[Out]# 2  Eindhoven                     15
#[Out]# 3  Rotterdam                     13
#[Out]# 4    Tilburg                     10
#[Out]# 5    Utrecht                     12


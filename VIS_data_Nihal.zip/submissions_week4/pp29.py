# IPython log file

# Tue, 08 Dec 2020 15:43:34
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Tue, 08 Dec 2020 15:43:47
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 15:43:52
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x21f02b6db90>
# Tue, 08 Dec 2020 16:15:54
query4_3 = '''
SELECT s1.sName
FROM store s1
WHERE
    NOT EXISTS( (SELECT c1.city
                FROM customer c1)
                EXCEPT
                (SELECT s2.city
                FROM store as s2
                WHERE s2.sName = s1.sName) )
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:16:53
query4_3 = '''
SELECT s1.sName
FROM store s1
WHERE
    NOT EXISTS ( (SELECT c1.city
                FROM customer c1)
                EXCEPT
                (SELECT s2.city
                FROM store as s2
                WHERE s2.sName = s1.sName) )
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:17:15
query4_3 = '''
SELECT s1.sName
FROM store s1
WHERE (
    NOT EXISTS ( (SELECT c1.city
                FROM customer c1)
                EXCEPT
                (SELECT s2.city
                FROM store as s2
                WHERE s2.sName = s1.sName) ) )
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:17:29
query4_3 = '''
SELECT s1.sName
FROM store s1
WHERE 
    NOT EXISTS  (SELECT c1.city
                FROM customer c1)
                EXCEPT
                (SELECT s2.city
                FROM store as s2
                WHERE s2.sName = s1.sName) ) 
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:17:39
query4_3 = '''
SELECT s1.sName
FROM store s1
WHERE 
    (NOT EXISTS  (SELECT c1.city
                FROM customer c1)
                EXCEPT
                (SELECT s2.city
                FROM store as s2
                WHERE s2.sName = s1.sName) ) 
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:18:36
query4_3 = '''
SELECT s1.sName
FROM store s1
WHERE NOT EXISTS (SELECT c1.city
                 FROM customer c1)
                 EXCEPT
                 (SELECT s2.city
                 FROM store as s2
                 WHERE s2.sName = s1.sName)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:18:42
query4_3 = '''
SELECT s1.sName
FROM store s1
WHERE NOT EXISTS ((SELECT c1.city
                 FROM customer c1)
                 EXCEPT
                 (SELECT s2.city
                 FROM store as s2
                 WHERE s2.sName = s1.sName))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:19:32
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS ((SELECT c1.city
                 FROM customer AS c1)
                 EXCEPT
                 (SELECT s2.city
                 FROM store AS s2
                 WHERE s2.sName = s1.sName))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:21:12
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS(SELECT c1.city
                 FROM customer AS c1)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 16:21:16
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS (SELECT c1.city
                 FROM customer AS c1)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 16:21:42
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS ((SELECT c1.city
                 FROM customer AS c1)
                 EXCEPT (SELECT s2.city
                         FROM store AS s2
                         WHERE s2.sName = s1.sName))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:21:51
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS (SELECT c1.city
                 FROM customer AS c1)
                 EXCEPT (SELECT s2.city
                         FROM store AS s2
                         WHERE s2.sName = s1.sName)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:22:42
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS ((SELECT c1.city
                 FROM customer AS c1)
                 EXCEPT (SELECT s2.city
                         FROM store AS s2
                         WHERE s2.sName = s1.sName))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:23:04
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS ((SELECT c1.city
                 FROM customer AS c1)
                 EXCEPT 
                 (SELECT s2.city
                  FROM store AS s2
                WHERE s2.sName = s1.sName))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:23:18
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS ((SELECT c1.city
                 FROM customer AS c1)
                 EXCEPT 
                 (SELECT s2.city
                  FROM store AS s2))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:23:53
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS ((SELECT c1.city
                 FROM customer AS c1)
                 WHERE (c1.city) NOT IN
                 (SELECT s2.city
                  FROM store AS s2))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:25:55
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS ((SELECT c1.city
                 FROM customer AS c1)
                 WHERE (c1.city) NOT IN
                 (SELECT s2.city
                  FROM store AS s2))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:26:02
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS (SELECT c1.city
                 FROM customer AS c1)
                 WHERE (c1.city) NOT IN
                 (SELECT s2.city
                  FROM store AS s2)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:27:07
query4_3 = '''
WITH try AS (SELECT c1.city
                 FROM customer AS c1)
                 EXCEPT 
                 (SELECT s2.city
                FROM store AS s2
                WHERE s2.sName = s1.sName)
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS (try)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:27:34
query4_3 = '''
(SELECT c1.city
            FROM customer AS c1)
            EXCEPT 
            (SELECT s2.city
            FROM store AS s2
            WHERE s2.sName = s1.sName)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:28:05
query4_3 = '''
(SELECT c1.city AS city
FROM customer AS c1)
EXCEPT 
(SELECT s2.city AS city
FROM store AS s2
WHERE s2.sName = s1.sName)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:28:15
query4_3 = '''
(SELECT c1.city
FROM customer AS c1)
EXCEPT 
(SELECT s2.city AS city
FROM store AS s2
WHERE s2.sName = s1.sName)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:28:51
query4_3 = '''
(SELECT c1.city
FROM customer AS c1
WHERE (c1.city) NOT IN
(SELECT s2.city AS city
FROM store AS s2
WHERE s2.sName = s1.sName)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:28:57
query4_3 = '''
(SELECT c1.city
FROM customer AS c1
WHERE (c1.city) NOT IN
SELECT s2.city AS city
FROM store AS s2
WHERE s2.sName = s1.sName
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:29:01
query4_3 = '''
SELECT c1.city
FROM customer AS c1
WHERE (c1.city) NOT IN
SELECT s2.city AS city
FROM store AS s2
WHERE s2.sName = s1.sName
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:29:12
query4_3 = '''
SELECT c1.city
FROM customer AS c1
WHERE (c1.city) NOT IN (SELECT s2.city AS city
FROM store AS s2
WHERE s2.sName = s1.sName)
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:29:18
query4_3 = '''
SELECT c1.city
FROM customer AS c1
WHERE (c1.city) NOT IN (SELECT s2.city AS city
FROM store AS s2)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Tue, 08 Dec 2020 16:30:02
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS SELECT c1.city
FROM customer AS c1
WHERE (c1.city) NOT IN (SELECT s2.city AS city
FROM store AS s2
                 WHERE s2.sName = s1.sName))
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:30:44
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS 
            SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city AS city
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName)
                                
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:30:58
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS 
            SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName)
                                
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:31:08
query4_3 = '''
SELECT s1.sName
FROM store 
WHERE NOT EXISTS 
            SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName)
                                
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:31:31
query4_3 = '''
SELECT s1.sName
FROM store AS s1
WHERE NOT EXISTS 
            SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName)
                                
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:31:43
query4_3 = '''
SELECT *
FROM store AS s1
WHERE NOT EXISTS 
            SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName)
                                
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:31:59
query4_3 = '''
SELECT *
FROM store AS s1
WHERE NOT EXISTS 
            (SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName))
                                
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, sName, street, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 16:32:46
query4_3 = '''
SELECT sName
FROM store AS s1
WHERE NOT EXISTS 
            (SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName))
                                
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 16:35:52
query4_3 = '''
SELECT sName
FROM store AS s1
WHERE (NOT EXISTS 
            (SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName)))
       AND
       (NOT EXISTS 
            (SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName)))
                                
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 16:37:05
query4_3 = '''
SELECT sName
FROM store AS s1
WHERE (NOT EXISTS 
            (SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName)))
       AND
       (NOT EXISTS 
            (SELECT s3.city
            FROM store AS s3
            WHERE (s1.city) NOT IN (SELECT s4.city 
                                    FROM store AS s4
                                    WHERE s4.sName = s1.sName)))
                                
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 16:37:29
query4_3 = '''
SELECT DISTINCT sName
FROM store AS s1
WHERE (NOT EXISTS 
            (SELECT c1.city
            FROM customer AS c1
            WHERE (c1.city) NOT IN (SELECT s2.city 
                                    FROM store AS s2
                                    WHERE s2.sName = s1.sName)))
       AND
       (NOT EXISTS 
            (SELECT s3.city
            FROM store AS s3
            WHERE (s1.city) NOT IN (SELECT s4.city 
                                    FROM store AS s4
                                    WHERE s4.sName = s1.sName)))
                                
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 16:59:21
query4_4 = '''
(SELECT date, cID, SUM(price)
                  FROM purchase p
                  GROUP BY date, cID
                  ORDER BY SUM(price)
                  LIMIT 1)
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 16:59:32
query4_4 = '''
(SELECT date, cID, SUM(price)
                  FROM purchase p
                  GROUP BY date, cID
                  ORDER BY sum_price)
                  LIMIT 1)
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 16:59:40
query4_4 = '''
(SELECT date, cID, SUM(price)
                  FROM purchase p
                  GROUP BY date, cID
                  ORDER BY sum_price
                  LIMIT 1
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 16:59:47
query4_4 = '''
SELECT date, cID, SUM(price)
                  FROM purchase p
                  GROUP BY date, cID
                  ORDER BY sum_price
                  LIMIT 1
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:00:00
query4_4 = '''
SELECT date, cID, SUM(price)
FROM purchase p
GROUP BY date, cID

'''

pd.read_sql_query(query4_4, conn)
#[Out]#            date  cID  SUM(price)
#[Out]# 0    2018-08-15   21        3.45
#[Out]# 1    2018-08-15   30        0.60
#[Out]# 2    2018-08-15   37        4.90
#[Out]# 3    2018-08-15   42        1.20
#[Out]# 4    2018-08-15   59        2.20
#[Out]# 5    2018-08-15  108       23.95
#[Out]# 6    2018-08-15  167        3.75
#[Out]# 7    2018-08-15  190       19.60
#[Out]# 8    2018-08-16    2        2.45
#[Out]# 9    2018-08-16    8        6.25
#[Out]# 10   2018-08-16   18        4.40
#[Out]# 11   2018-08-16   21        2.40
#[Out]# 12   2018-08-16   27        1.20
#[Out]# 13   2018-08-16   33        2.30
#[Out]# 14   2018-08-16   40       11.50
#[Out]# 15   2018-08-16   45        1.80
#[Out]# 16   2018-08-16   55        3.45
#[Out]# 17   2018-08-16   57        0.80
#[Out]# 18   2018-08-16   59        1.75
#[Out]# 19   2018-08-16   66        5.25
#[Out]# 20   2018-08-16   80        5.55
#[Out]# 21   2018-08-16   96        1.30
#[Out]# 22   2018-08-16  162        1.65
#[Out]# 23   2018-08-16  168        5.65
#[Out]# 24   2018-08-16  169        1.90
#[Out]# 25   2018-08-16  170       15.85
#[Out]# 26   2018-08-16  190       12.80
#[Out]# 27   2018-08-17    2        7.70
#[Out]# 28   2018-08-17    5        4.70
#[Out]# 29   2018-08-17   13       13.30
#[Out]# ..          ...  ...         ...
#[Out]# 255  2018-08-27   16        1.85
#[Out]# 256  2018-08-27   22        8.05
#[Out]# 257  2018-08-27   27        1.65
#[Out]# 258  2018-08-27   28        1.10
#[Out]# 259  2018-08-27   31        0.90
#[Out]# 260  2018-08-27   33       16.75
#[Out]# 261  2018-08-27   58        0.55
#[Out]# 262  2018-08-27   67        6.35
#[Out]# 263  2018-08-27   68        1.65
#[Out]# 264  2018-08-27   91        6.60
#[Out]# 265  2018-08-27   92        9.85
#[Out]# 266  2018-08-27  110        5.15
#[Out]# 267  2018-08-27  157        6.25
#[Out]# 268  2018-08-27  163        8.20
#[Out]# 269  2018-08-27  169        0.55
#[Out]# 270  2018-08-27  172        0.90
#[Out]# 271  2018-08-27  178        7.50
#[Out]# 272  2018-08-27  180        4.65
#[Out]# 273  2018-08-27  181        2.00
#[Out]# 274  2018-08-27  190        5.55
#[Out]# 275  2018-08-28   22        0.45
#[Out]# 276  2018-08-28   25        2.55
#[Out]# 277  2018-08-28   31        3.90
#[Out]# 278  2018-08-28   39       12.80
#[Out]# 279  2018-08-28   69        6.05
#[Out]# 280  2018-08-28  157        1.80
#[Out]# 281  2018-08-28  169        4.65
#[Out]# 282  2018-08-28  182       14.90
#[Out]# 283  2018-08-29   39       11.90
#[Out]# 284  2018-09-20  188        1.00
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 17:01:00
query4_4 = '''
SELECT MAX(SUM(price))
FROM (SELECT date, cID, SUM(price)
FROM purchase p
GROUP BY date, cID)

'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:01:16
query4_4 = '''
SELECT MAX(m.SUM(price))
FROM (SELECT date, cID, SUM(price)
FROM purchase p
GROUP BY date, cID) AS m

'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:01:31
query4_4 = '''
SELECT MAX(m.SUM(price))
FROM (SELECT date, cID, SUM(price)
        FROM purchase p
        GROUP BY date, cID) AS m

'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:01:38
query4_4 = '''
SELECT MAX(m.SUM(price))
FROM (SELECT date, cID, SUM(price) AS price_sum
        FROM purchase p
        GROUP BY date, cID) AS m

'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:01:45
query4_4 = '''
SELECT date, cID, SUM(price) AS price_sum
        FROM purchase p
        GROUP BY date, cID

'''

pd.read_sql_query(query4_4, conn)
#[Out]#            date  cID  price_sum
#[Out]# 0    2018-08-15   21       3.45
#[Out]# 1    2018-08-15   30       0.60
#[Out]# 2    2018-08-15   37       4.90
#[Out]# 3    2018-08-15   42       1.20
#[Out]# 4    2018-08-15   59       2.20
#[Out]# 5    2018-08-15  108      23.95
#[Out]# 6    2018-08-15  167       3.75
#[Out]# 7    2018-08-15  190      19.60
#[Out]# 8    2018-08-16    2       2.45
#[Out]# 9    2018-08-16    8       6.25
#[Out]# 10   2018-08-16   18       4.40
#[Out]# 11   2018-08-16   21       2.40
#[Out]# 12   2018-08-16   27       1.20
#[Out]# 13   2018-08-16   33       2.30
#[Out]# 14   2018-08-16   40      11.50
#[Out]# 15   2018-08-16   45       1.80
#[Out]# 16   2018-08-16   55       3.45
#[Out]# 17   2018-08-16   57       0.80
#[Out]# 18   2018-08-16   59       1.75
#[Out]# 19   2018-08-16   66       5.25
#[Out]# 20   2018-08-16   80       5.55
#[Out]# 21   2018-08-16   96       1.30
#[Out]# 22   2018-08-16  162       1.65
#[Out]# 23   2018-08-16  168       5.65
#[Out]# 24   2018-08-16  169       1.90
#[Out]# 25   2018-08-16  170      15.85
#[Out]# 26   2018-08-16  190      12.80
#[Out]# 27   2018-08-17    2       7.70
#[Out]# 28   2018-08-17    5       4.70
#[Out]# 29   2018-08-17   13      13.30
#[Out]# ..          ...  ...        ...
#[Out]# 255  2018-08-27   16       1.85
#[Out]# 256  2018-08-27   22       8.05
#[Out]# 257  2018-08-27   27       1.65
#[Out]# 258  2018-08-27   28       1.10
#[Out]# 259  2018-08-27   31       0.90
#[Out]# 260  2018-08-27   33      16.75
#[Out]# 261  2018-08-27   58       0.55
#[Out]# 262  2018-08-27   67       6.35
#[Out]# 263  2018-08-27   68       1.65
#[Out]# 264  2018-08-27   91       6.60
#[Out]# 265  2018-08-27   92       9.85
#[Out]# 266  2018-08-27  110       5.15
#[Out]# 267  2018-08-27  157       6.25
#[Out]# 268  2018-08-27  163       8.20
#[Out]# 269  2018-08-27  169       0.55
#[Out]# 270  2018-08-27  172       0.90
#[Out]# 271  2018-08-27  178       7.50
#[Out]# 272  2018-08-27  180       4.65
#[Out]# 273  2018-08-27  181       2.00
#[Out]# 274  2018-08-27  190       5.55
#[Out]# 275  2018-08-28   22       0.45
#[Out]# 276  2018-08-28   25       2.55
#[Out]# 277  2018-08-28   31       3.90
#[Out]# 278  2018-08-28   39      12.80
#[Out]# 279  2018-08-28   69       6.05
#[Out]# 280  2018-08-28  157       1.80
#[Out]# 281  2018-08-28  169       4.65
#[Out]# 282  2018-08-28  182      14.90
#[Out]# 283  2018-08-29   39      11.90
#[Out]# 284  2018-09-20  188       1.00
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 17:04:02
query4_4 = '''
WITH tot_cust_date AS SELECT date, cID, SUM(price) AS total_spent
                      FROM purchase p
                      GROUP BY date, cID
SELECT MAX(total_spent)
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:05:04
query4_4 = '''
WITH tot_cust_date AS SELECT date, cID, SUM(price) AS total_spent
                      FROM purchase p
                      GROUP BY date, cID
SELECT MAX(total_spent) AS maxim
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:05:16
query4_4 = '''
SELECT date, cID, SUM(price) AS total_spent
                      FROM purchase p
                      GROUP BY date, cID

'''

pd.read_sql_query(query4_4, conn)
#[Out]#            date  cID  total_spent
#[Out]# 0    2018-08-15   21         3.45
#[Out]# 1    2018-08-15   30         0.60
#[Out]# 2    2018-08-15   37         4.90
#[Out]# 3    2018-08-15   42         1.20
#[Out]# 4    2018-08-15   59         2.20
#[Out]# 5    2018-08-15  108        23.95
#[Out]# 6    2018-08-15  167         3.75
#[Out]# 7    2018-08-15  190        19.60
#[Out]# 8    2018-08-16    2         2.45
#[Out]# 9    2018-08-16    8         6.25
#[Out]# 10   2018-08-16   18         4.40
#[Out]# 11   2018-08-16   21         2.40
#[Out]# 12   2018-08-16   27         1.20
#[Out]# 13   2018-08-16   33         2.30
#[Out]# 14   2018-08-16   40        11.50
#[Out]# 15   2018-08-16   45         1.80
#[Out]# 16   2018-08-16   55         3.45
#[Out]# 17   2018-08-16   57         0.80
#[Out]# 18   2018-08-16   59         1.75
#[Out]# 19   2018-08-16   66         5.25
#[Out]# 20   2018-08-16   80         5.55
#[Out]# 21   2018-08-16   96         1.30
#[Out]# 22   2018-08-16  162         1.65
#[Out]# 23   2018-08-16  168         5.65
#[Out]# 24   2018-08-16  169         1.90
#[Out]# 25   2018-08-16  170        15.85
#[Out]# 26   2018-08-16  190        12.80
#[Out]# 27   2018-08-17    2         7.70
#[Out]# 28   2018-08-17    5         4.70
#[Out]# 29   2018-08-17   13        13.30
#[Out]# ..          ...  ...          ...
#[Out]# 255  2018-08-27   16         1.85
#[Out]# 256  2018-08-27   22         8.05
#[Out]# 257  2018-08-27   27         1.65
#[Out]# 258  2018-08-27   28         1.10
#[Out]# 259  2018-08-27   31         0.90
#[Out]# 260  2018-08-27   33        16.75
#[Out]# 261  2018-08-27   58         0.55
#[Out]# 262  2018-08-27   67         6.35
#[Out]# 263  2018-08-27   68         1.65
#[Out]# 264  2018-08-27   91         6.60
#[Out]# 265  2018-08-27   92         9.85
#[Out]# 266  2018-08-27  110         5.15
#[Out]# 267  2018-08-27  157         6.25
#[Out]# 268  2018-08-27  163         8.20
#[Out]# 269  2018-08-27  169         0.55
#[Out]# 270  2018-08-27  172         0.90
#[Out]# 271  2018-08-27  178         7.50
#[Out]# 272  2018-08-27  180         4.65
#[Out]# 273  2018-08-27  181         2.00
#[Out]# 274  2018-08-27  190         5.55
#[Out]# 275  2018-08-28   22         0.45
#[Out]# 276  2018-08-28   25         2.55
#[Out]# 277  2018-08-28   31         3.90
#[Out]# 278  2018-08-28   39        12.80
#[Out]# 279  2018-08-28   69         6.05
#[Out]# 280  2018-08-28  157         1.80
#[Out]# 281  2018-08-28  169         4.65
#[Out]# 282  2018-08-28  182        14.90
#[Out]# 283  2018-08-29   39        11.90
#[Out]# 284  2018-09-20  188         1.00
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 17:05:44
query4_4 = '''
WITH tot_cust_date AS SELECT date, cID, SUM(price) AS total_spent
                      FROM purchase p
                      GROUP BY date, cID
SELECT MAX(tot_cust_date.total_spent) AS maxim
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:07:32
query4_4 = '''
WITH tot_cust_date(tot) AS SELECT date, cID, SUM(price) AS total_spent
                            FROM purchase p
                            GROUP BY date, cID
SELECT MAX(tot) AS maxim
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:07:43
query4_4 = '''
WITH tot_cust_date(tot) AS SELECT date, cID, SUM(price) AS total_spent
                            FROM purchase p
                            GROUP BY date, cID
SELECT *
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:07:51
query4_4 = '''
WITH tot_cust_date(tot) AS (SELECT date, cID, SUM(price) AS total_spent
                            FROM purchase p
                            GROUP BY date, cID)
SELECT *
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:08:08
query4_4 = '''
WITH tot_cust_date(total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                            FROM purchase p
                            GROUP BY date, cID)
SELECT *
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 17:08:21
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                            FROM purchase p
                            GROUP BY date, cID)
SELECT *
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#            date  cID  total_spent
#[Out]# 0    2018-08-15   21         3.45
#[Out]# 1    2018-08-15   30         0.60
#[Out]# 2    2018-08-15   37         4.90
#[Out]# 3    2018-08-15   42         1.20
#[Out]# 4    2018-08-15   59         2.20
#[Out]# 5    2018-08-15  108        23.95
#[Out]# 6    2018-08-15  167         3.75
#[Out]# 7    2018-08-15  190        19.60
#[Out]# 8    2018-08-16    2         2.45
#[Out]# 9    2018-08-16    8         6.25
#[Out]# 10   2018-08-16   18         4.40
#[Out]# 11   2018-08-16   21         2.40
#[Out]# 12   2018-08-16   27         1.20
#[Out]# 13   2018-08-16   33         2.30
#[Out]# 14   2018-08-16   40        11.50
#[Out]# 15   2018-08-16   45         1.80
#[Out]# 16   2018-08-16   55         3.45
#[Out]# 17   2018-08-16   57         0.80
#[Out]# 18   2018-08-16   59         1.75
#[Out]# 19   2018-08-16   66         5.25
#[Out]# 20   2018-08-16   80         5.55
#[Out]# 21   2018-08-16   96         1.30
#[Out]# 22   2018-08-16  162         1.65
#[Out]# 23   2018-08-16  168         5.65
#[Out]# 24   2018-08-16  169         1.90
#[Out]# 25   2018-08-16  170        15.85
#[Out]# 26   2018-08-16  190        12.80
#[Out]# 27   2018-08-17    2         7.70
#[Out]# 28   2018-08-17    5         4.70
#[Out]# 29   2018-08-17   13        13.30
#[Out]# ..          ...  ...          ...
#[Out]# 255  2018-08-27   16         1.85
#[Out]# 256  2018-08-27   22         8.05
#[Out]# 257  2018-08-27   27         1.65
#[Out]# 258  2018-08-27   28         1.10
#[Out]# 259  2018-08-27   31         0.90
#[Out]# 260  2018-08-27   33        16.75
#[Out]# 261  2018-08-27   58         0.55
#[Out]# 262  2018-08-27   67         6.35
#[Out]# 263  2018-08-27   68         1.65
#[Out]# 264  2018-08-27   91         6.60
#[Out]# 265  2018-08-27   92         9.85
#[Out]# 266  2018-08-27  110         5.15
#[Out]# 267  2018-08-27  157         6.25
#[Out]# 268  2018-08-27  163         8.20
#[Out]# 269  2018-08-27  169         0.55
#[Out]# 270  2018-08-27  172         0.90
#[Out]# 271  2018-08-27  178         7.50
#[Out]# 272  2018-08-27  180         4.65
#[Out]# 273  2018-08-27  181         2.00
#[Out]# 274  2018-08-27  190         5.55
#[Out]# 275  2018-08-28   22         0.45
#[Out]# 276  2018-08-28   25         2.55
#[Out]# 277  2018-08-28   31         3.90
#[Out]# 278  2018-08-28   39        12.80
#[Out]# 279  2018-08-28   69         6.05
#[Out]# 280  2018-08-28  157         1.80
#[Out]# 281  2018-08-28  169         4.65
#[Out]# 282  2018-08-28  182        14.90
#[Out]# 283  2018-08-29   39        11.90
#[Out]# 284  2018-09-20  188         1.00
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 17:09:34
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID)
SELECT MAX(total_spent)
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(total_spent)
#[Out]# 0              39.1
# Tue, 08 Dec 2020 17:09:47
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID)
SELECT MAX(total_spent) AS maximum
FROM tot_cust_date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    maximum
#[Out]# 0     39.1
# Tue, 08 Dec 2020 17:29:41
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, date
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 0.75 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName        date
#[Out]# 0  Floor  2018-08-26
# Tue, 08 Dec 2020 17:30:00
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, date, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 0.75 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName        date  total_spent
#[Out]# 0  Floor  2018-08-26         39.1
# Tue, 08 Dec 2020 17:30:14
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, date, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent < 0.75 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#         cName        date  total_spent
#[Out]# 0    Benjamin  2018-08-15         3.45
#[Out]# 1        Teun  2018-08-15         0.60
#[Out]# 2        Guus  2018-08-15         4.90
#[Out]# 3        Tijn  2018-08-15         1.20
#[Out]# 4        Joep  2018-08-15         2.20
#[Out]# 5        Noor  2018-08-15        23.95
#[Out]# 6      Veerle  2018-08-15         3.75
#[Out]# 7      Kostas  2018-08-15        19.60
#[Out]# 8       Lucas  2018-08-16         2.45
#[Out]# 9        Liam  2018-08-16         6.25
#[Out]# 10       Hugo  2018-08-16         4.40
#[Out]# 11   Benjamin  2018-08-16         2.40
#[Out]# 12        Tim  2018-08-16         1.20
#[Out]# 13       Sven  2018-08-16         2.30
#[Out]# 14       Jens  2018-08-16        11.50
#[Out]# 15       Ryan  2018-08-16         1.80
#[Out]# 16      Aiden  2018-08-16         3.45
#[Out]# 17     Nathan  2018-08-16         0.80
#[Out]# 18       Joep  2018-08-16         1.75
#[Out]# 19    Mohamed  2018-08-16         5.25
#[Out]# 20       Niek  2018-08-16         5.55
#[Out]# 21       Tess  2018-08-16         1.30
#[Out]# 22      Elena  2018-08-16         1.65
#[Out]# 23       Kiki  2018-08-16         5.65
#[Out]# 24       Lily  2018-08-16         1.90
#[Out]# 25       Iris  2018-08-16        15.85
#[Out]# 26     Kostas  2018-08-16        12.80
#[Out]# 27      Lucas  2018-08-17         7.70
#[Out]# 28       Levi  2018-08-17         4.70
#[Out]# 29      James  2018-08-17        13.30
#[Out]# ..        ...         ...          ...
#[Out]# 254    Julian  2018-08-27         1.85
#[Out]# 255      Mats  2018-08-27         8.05
#[Out]# 256       Tim  2018-08-27         1.65
#[Out]# 257      Siem  2018-08-27         1.10
#[Out]# 258   Olivier  2018-08-27         0.90
#[Out]# 259      Sven  2018-08-27        16.75
#[Out]# 260     Jurre  2018-08-27         0.55
#[Out]# 261     Rayan  2018-08-27         6.35
#[Out]# 262     Boris  2018-08-27         1.65
#[Out]# 263   Thijmen  2018-08-27         6.60
#[Out]# 264     Jelte  2018-08-27         9.85
#[Out]# 265      Saar  2018-08-27         5.15
#[Out]# 266      Puck  2018-08-27         6.25
#[Out]# 267      Cato  2018-08-27         8.20
#[Out]# 268      Lily  2018-08-27         0.55
#[Out]# 269      Lana  2018-08-27         0.90
#[Out]# 270      Elif  2018-08-27         7.50
#[Out]# 271     Merel  2018-08-27         4.65
#[Out]# 272      Liva  2018-08-27         2.00
#[Out]# 273    Kostas  2018-08-27         5.55
#[Out]# 274      Mats  2018-08-28         0.45
#[Out]# 275     Mason  2018-08-28         2.55
#[Out]# 276   Olivier  2018-08-28         3.90
#[Out]# 277      Jack  2018-08-28        12.80
#[Out]# 278      Roan  2018-08-28         6.05
#[Out]# 279      Puck  2018-08-28         1.80
#[Out]# 280      Lily  2018-08-28         4.65
#[Out]# 281   Johanna  2018-08-28        14.90
#[Out]# 282      Jack  2018-08-29        11.90
#[Out]# 283      Pino  2018-09-20         1.00
#[Out]# 
#[Out]# [284 rows x 3 columns]
# Tue, 08 Dec 2020 17:30:31
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, date, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 0.60 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName        date  total_spent
#[Out]# 0   Noor  2018-08-15        23.95
#[Out]# 1  Sofie  2018-08-26        28.80
#[Out]# 2  Floor  2018-08-26        39.10
# Tue, 08 Dec 2020 17:30:42
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, date, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 0.75 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName        date  total_spent
#[Out]# 0  Floor  2018-08-26         39.1
# Tue, 08 Dec 2020 17:33:13
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price*quantity) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, date, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 0.75 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName        date  total_spent
#[Out]# 0   Lynn  2018-08-18       150.15
#[Out]# 1   Dean  2018-08-24       145.00
#[Out]# 2  Sofie  2018-08-26       134.90
#[Out]# 3  Floor  2018-08-26       171.25
#[Out]# 4   Sven  2018-08-27       138.90
# Tue, 08 Dec 2020 17:49:50
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price*quantity) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 0.75 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Lynn
#[Out]# 1   Dean
#[Out]# 2  Sofie
#[Out]# 3  Floor
#[Out]# 4   Sven
# Tue, 08 Dec 2020 17:55:26
query4_5 = '''
SELECT city, COUNT(c.cID)
FROM customer c
WHERE EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")
GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam            10
#[Out]# 1      Breda             9
#[Out]# 2  Eindhoven            15
#[Out]# 3  Rotterdam            13
#[Out]# 4    Tilburg            10
#[Out]# 5    Utrecht            12
# Tue, 08 Dec 2020 17:57:47
query4_5 = '''
SELECT city, COUNT(c.cID)
FROM customer c
GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam            26
#[Out]# 1      Breda            27
#[Out]# 2  Eindhoven            33
#[Out]# 3        Oss             1
#[Out]# 4  Rotterdam            29
#[Out]# 5    Tilburg            38
#[Out]# 6    Utrecht            36
# Tue, 08 Dec 2020 17:59:15
query4_5 = '''


SELECT city, COUNT(c.cID)
FROM customer c
WHERE NOT EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")
GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam            16
#[Out]# 1      Breda            18
#[Out]# 2  Eindhoven            18
#[Out]# 3        Oss             1
#[Out]# 4  Rotterdam            16
#[Out]# 5    Tilburg            28
#[Out]# 6    Utrecht            24
# Tue, 08 Dec 2020 18:02:16
query4_5 = '''

WITH total(city, count) AS SELECT city, COUNT(c.cID)
                            FROM customer c
                            GROUP BY c.city,

     no_purch(city, count) AS SELECT city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city
SELECT total.city, (total.count - no_purch.count) AS count
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:03:07
query4_5 = '''

WITH total(city, count) AS SELECT city, COUNT(c.cID)
                            FROM customer c
                            GROUP BY c.city,

     no_purch(city, count) AS SELECT city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city
SELECT total.city, (total.count-no_purch.count) AS count
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:03:32
query4_5 = '''

WITH total(city, count) AS SELECT city, COUNT(c.cID)
                            FROM customer c
                            GROUP BY c.city,
     no_purch(city, count) AS SELECT city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city
SELECT total.city, (total.count-no_purch.count) AS count
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:03:40
query4_5 = '''

WITH total(city, count) AS SELECT city, COUNT(c.cID)
                            FROM customer c
                            GROUP BY c.city,
     no_purch(city, count) AS SELECT city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city
SELECT total.city, total.count
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:04:15
query4_5 = '''

WITH total(city, count) AS SELECT city, COUNT(cID)
                            FROM customer
                            GROUP BY city,
     no_purch(city, count) AS SELECT city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city
SELECT total.city, total.count
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:04:32
query4_5 = '''

WITH total(city, count) AS SELECT city, COUNT(cID)
                            FROM customer
                            GROUP BY city,
     no_purch(city, count) AS SELECT c.city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city
SELECT total.city, total.count
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:05:04
query4_5 = '''

WITH total(city, count) AS (SELECT city, COUNT(cID)
                            FROM customer
                            GROUP BY city),
     no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city
SELECT total.city, total.count
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:05:12
query4_5 = '''

WITH total(city, count) AS (SELECT city, COUNT(cID)
                            FROM customer
                            GROUP BY city),
     no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city)
SELECT total.city, total.count
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     26
#[Out]# 1      Breda     27
#[Out]# 2  Eindhoven     33
#[Out]# 3        Oss      1
#[Out]# 4  Rotterdam     29
#[Out]# 5    Tilburg     38
#[Out]# 6    Utrecht     36
# Tue, 08 Dec 2020 18:05:28
query4_5 = '''

WITH total(city, count) AS (SELECT city, COUNT(cID)
                            FROM customer
                            GROUP BY city),
     no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city)
SELECT total.city, (total.count-no_purch.count)
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  (total.count-no_purch.count)
#[Out]# 0  Amsterdam                            10
#[Out]# 1      Breda                             9
#[Out]# 2  Eindhoven                            15
#[Out]# 3        Oss                             0
#[Out]# 4  Rotterdam                            13
#[Out]# 5    Tilburg                            10
#[Out]# 6    Utrecht                            12
# Tue, 08 Dec 2020 18:06:32
query4_5 = '''
(SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")


'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
# pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:06:36
query4_5 = '''
(SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")


'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
# pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:06:42
query4_5 = '''
SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")

'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
# pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:06:50
query4_5 = '''
SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")

'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
pd.read_sql_query(query4_5, conn)
#[Out]#     city  COUNT(c.cID)
#[Out]# 0  Breda            69
# Tue, 08 Dec 2020 18:06:59
query4_5 = '''
SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")

'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
pd.read_sql_query(query4_5, conn)
#[Out]#     city  COUNT(c.cID)
#[Out]# 0  Breda            69
# Tue, 08 Dec 2020 18:07:25
query4_5 = '''
SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")

'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
pd.read_sql_query(query4_5, conn)
#[Out]#     city  COUNT(c.cID)
#[Out]# 0  Breda            69
# Tue, 08 Dec 2020 18:07:48
query4_5 = '''
SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")

'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
pd.read_sql_query(query4_5, conn)
#[Out]#     city  COUNT(c.cID)
#[Out]# 0  Breda            69
# Tue, 08 Dec 2020 18:08:06
query4_5 = '''
SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE NOT EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")

'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
pd.read_sql_query(query4_5, conn)
#[Out]#       city  COUNT(c.cID)
#[Out]# 0  Utrecht           121
# Tue, 08 Dec 2020 18:08:12
query4_5 = '''
SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE NOT EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")
'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
pd.read_sql_query(query4_5, conn)
#[Out]#       city  COUNT(c.cID)
#[Out]# 0  Utrecht           121
# Tue, 08 Dec 2020 18:08:37
query4_5 = '''
SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE NOT EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")
GROUP BY c.city
'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam            16
#[Out]# 1      Breda            18
#[Out]# 2  Eindhoven            18
#[Out]# 3        Oss             1
#[Out]# 4  Rotterdam            16
#[Out]# 5    Tilburg            28
#[Out]# 6    Utrecht            24
# Tue, 08 Dec 2020 18:08:43
query4_5 = '''
SELECT c.city, COUNT(c.cID)
FROM customer c
WHERE EXISTS (SELECT *
              FROM purchase p, store s
              WHERE c.cID = p.cID AND
                    p.sID = s.sID AND
                    s.city = "Eindhoven")
GROUP BY c.city
'''
# WITH total(city, count) AS (SELECT city, COUNT(cID)
#                             FROM customer
#                             GROUP BY city),
#      no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
#                                 FROM customer c
#                                 WHERE NOT EXISTS (SELECT *
#                                               FROM purchase p, store s
#                                               WHERE c.cID = p.cID AND
#                                                     p.sID = s.sID AND
#                                                     s.city = "Eindhoven")
#                                 GROUP BY c.city)
# SELECT total.city, (total.count-no_purch.count)
# FROM total, no_purch
# WHERE total.city = no_purch.city
pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam            10
#[Out]# 1      Breda             9
#[Out]# 2  Eindhoven            15
#[Out]# 3  Rotterdam            13
#[Out]# 4    Tilburg            10
#[Out]# 5    Utrecht            12
# Tue, 08 Dec 2020 18:09:07
query4_5 = '''
WITH total(city, count) AS (SELECT city, COUNT(cID)
                            FROM customer
                            GROUP BY city),
     no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city)
SELECT total.city, (total.count-no_purch.count)
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  (total.count-no_purch.count)
#[Out]# 0  Amsterdam                            10
#[Out]# 1      Breda                             9
#[Out]# 2  Eindhoven                            15
#[Out]# 3        Oss                             0
#[Out]# 4  Rotterdam                            13
#[Out]# 5    Tilburg                            10
#[Out]# 6    Utrecht                            12
# Tue, 08 Dec 2020 18:09:12
query4_5 = '''
WITH total(city, count) AS (SELECT city, COUNT(cID)
                            FROM customer
                            GROUP BY city),
     no_purch(city, count) AS (SELECT c.city, COUNT(c.cID)
                                FROM customer c
                                WHERE NOT EXISTS (SELECT *
                                              FROM purchase p, store s
                                              WHERE c.cID = p.cID AND
                                                    p.sID = s.sID AND
                                                    s.city = "Eindhoven")
                                GROUP BY c.city)
SELECT total.city, (total.count-no_purch.count)
FROM total, no_purch
WHERE total.city = no_purch.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  (total.count-no_purch.count)
#[Out]# 0  Amsterdam                            10
#[Out]# 1      Breda                             9
#[Out]# 2  Eindhoven                            15
#[Out]# 3        Oss                             0
#[Out]# 4  Rotterdam                            13
#[Out]# 5    Tilburg                            10
#[Out]# 6    Utrecht                            12
# Tue, 08 Dec 2020 18:50:02
query = '''
SELECT date, cID, SUM(price*quantity) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID
                                                
'''

pd.read_sql_query(query, conn)
#[Out]#            date  cID  total_spent
#[Out]# 0    2018-08-15   21        10.35
#[Out]# 1    2018-08-15   30         5.40
#[Out]# 2    2018-08-15   37        29.60
#[Out]# 3    2018-08-15   42         4.80
#[Out]# 4    2018-08-15   59        13.20
#[Out]# 5    2018-08-15  108        77.60
#[Out]# 6    2018-08-15  167        21.85
#[Out]# 7    2018-08-15  190        80.30
#[Out]# 8    2018-08-16    2         2.45
#[Out]# 9    2018-08-16    8        33.15
#[Out]# 10   2018-08-16   18        21.00
#[Out]# 11   2018-08-16   21         7.20
#[Out]# 12   2018-08-16   27         9.60
#[Out]# 13   2018-08-16   33         6.90
#[Out]# 14   2018-08-16   40        90.20
#[Out]# 15   2018-08-16   45        12.60
#[Out]# 16   2018-08-16   55        10.35
#[Out]# 17   2018-08-16   57         5.60
#[Out]# 18   2018-08-16   59         5.25
#[Out]# 19   2018-08-16   66        32.65
#[Out]# 20   2018-08-16   80        49.95
#[Out]# 21   2018-08-16   96         1.30
#[Out]# 22   2018-08-16  162         3.30
#[Out]# 23   2018-08-16  168        33.90
#[Out]# 24   2018-08-16  169         3.80
#[Out]# 25   2018-08-16  170        57.60
#[Out]# 26   2018-08-16  190        64.20
#[Out]# 27   2018-08-17    2        32.40
#[Out]# 28   2018-08-17    5        28.20
#[Out]# 29   2018-08-17   13        58.25
#[Out]# ..          ...  ...          ...
#[Out]# 255  2018-08-27   16        14.80
#[Out]# 256  2018-08-27   22        24.15
#[Out]# 257  2018-08-27   27         9.90
#[Out]# 258  2018-08-27   28         2.20
#[Out]# 259  2018-08-27   31         8.10
#[Out]# 260  2018-08-27   33       138.90
#[Out]# 261  2018-08-27   58         4.95
#[Out]# 262  2018-08-27   67        21.20
#[Out]# 263  2018-08-27   68         4.95
#[Out]# 264  2018-08-27   91        20.20
#[Out]# 265  2018-08-27   92        53.75
#[Out]# 266  2018-08-27  110        16.65
#[Out]# 267  2018-08-27  157        24.90
#[Out]# 268  2018-08-27  163        24.60
#[Out]# 269  2018-08-27  169         3.85
#[Out]# 270  2018-08-27  172         3.60
#[Out]# 271  2018-08-27  178        36.30
#[Out]# 272  2018-08-27  180        34.20
#[Out]# 273  2018-08-27  181        10.00
#[Out]# 274  2018-08-27  190        32.10
#[Out]# 275  2018-08-28   22         2.70
#[Out]# 276  2018-08-28   25        22.95
#[Out]# 277  2018-08-28   31        15.60
#[Out]# 278  2018-08-28   39        25.30
#[Out]# 279  2018-08-28   69        48.40
#[Out]# 280  2018-08-28  157        12.60
#[Out]# 281  2018-08-28  169        32.55
#[Out]# 282  2018-08-28  182        50.00
#[Out]# 283  2018-08-29   39        29.25
#[Out]# 284  2018-09-20  188         1.00
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 18:50:45
query = '''
SELECT MAX(i.total_spent)
FROM (SELECT date, cID, SUM(price*quantity) AS total_spent
FROM purchase p
GROUP BY date, cID) AS i
                                                
'''

pd.read_sql_query(query, conn)
#[Out]#    MAX(i.total_spent)
#[Out]# 0              171.25
# Tue, 08 Dec 2020 18:51:01
query = '''
SELECT MAX(i.total_spent)*0.75
FROM (SELECT date, cID, SUM(price*quantity) AS total_spent
FROM purchase p
GROUP BY date, cID) AS i
                                                
'''

pd.read_sql_query(query, conn)
#[Out]#    MAX(i.total_spent)*0.75
#[Out]# 0                 128.4375
# Tue, 08 Dec 2020 18:51:13
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price*quantity) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 0.75 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName  total_spent
#[Out]# 0   Lynn       150.15
#[Out]# 1   Dean       145.00
#[Out]# 2  Sofie       134.90
#[Out]# 3  Floor       171.25
#[Out]# 4   Sven       138.90
# Tue, 08 Dec 2020 18:51:36
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price*quantity) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 120
                )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName  total_spent
#[Out]# 0   Lynn       150.15
#[Out]# 1   Dean       145.00
#[Out]# 2  Sofie       134.90
#[Out]# 3  Floor       171.25
#[Out]# 4   Sven       138.90
# Tue, 08 Dec 2020 18:51:40
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price*quantity) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 100
                )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName  total_spent
#[Out]# 0   Lynn       150.15
#[Out]# 1   Joep       102.70
#[Out]# 2    Ivy       119.25
#[Out]# 3   Dean       145.00
#[Out]# 4  Dylan       107.20
#[Out]# 5  Elena       118.35
#[Out]# 6   Daan       106.45
#[Out]# 7  Sofie       134.90
#[Out]# 8  Floor       171.25
#[Out]# 9   Sven       138.90
# Tue, 08 Dec 2020 18:51:53
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price*quantity) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 128.4375
                )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName  total_spent
#[Out]# 0   Lynn       150.15
#[Out]# 1   Dean       145.00
#[Out]# 2  Sofie       134.90
#[Out]# 3  Floor       171.25
#[Out]# 4   Sven       138.90
# Tue, 08 Dec 2020 18:52:01
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price*quantity) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 0.75 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName  total_spent
#[Out]# 0   Lynn       150.15
#[Out]# 1   Dean       145.00
#[Out]# 2  Sofie       134.90
#[Out]# 3  Floor       171.25
#[Out]# 4   Sven       138.90
# Wed, 09 Dec 2020 11:01:05
query = '''
SELECT MAX(i.total_spent)*0.75
FROM (SELECT date, cID, SUM(price) AS total_spent
FROM purchase p
GROUP BY date, cID) AS i
                                                
'''

pd.read_sql_query(query, conn)
#[Out]#    MAX(i.total_spent)*0.75
#[Out]# 0                   29.325
# Wed, 09 Dec 2020 11:01:23
query4_4 = '''
WITH tot_cust_date(date, cID, total_spent) AS (SELECT date, cID, SUM(price) AS total_spent
                                                FROM purchase p
                                                GROUP BY date, cID),
      ma(maximum) AS (SELECT MAX(total_spent) AS maximum
                      FROM tot_cust_date)
SELECT cName, total_spent
FROM customer c, tot_cust_date t
WHERE t.cID = c.cID 
    AND EXISTS (SELECT maximum
                FROM ma
                WHERE t.total_spent >= 0.75 * maximum)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName  total_spent
#[Out]# 0  Floor         39.1

   Bud1            %                       l o g sdsclbool                   dsclbool                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             @                                              @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   E   %                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       DSDB                             `                                                     @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              

# IPython log file

# Sat, 05 Dec 2020 16:37:24
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 05 Dec 2020 16:37:40
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1029775e0>
# Sat, 05 Dec 2020 16:39:56
query4_3 = '''
    with all_cities(city) as (
        select city
        from store
        union
        select city 
        from customer
    )
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 16:44:16
query4_3 = '''
    select city
    from (
        select city
        from store
        union
        select city
        from customer
    ) as all_cities
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sat, 05 Dec 2020 16:45:20
query4_3 = '''
    select city
    from store
    union
    select city
    from customer
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sat, 05 Dec 2020 16:47:05
query4_3 = '''
    select city
    from (
        select city
        from store
        union
        select city
        from customer
    ) as all_cities
    
    select sName, all_cities.city
    from store, all_cities
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 16:48:50
query4_3 = '''
    select sName, all_cities.city
    from store, select city
        from (
            select city
            from store
            union
            select city
            from customer
        ) as all_cities
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 16:48:54
query4_3 = '''
    select sName, all_cities.city
    from store, select city
        from (
            select city
            from store
            union
            select city
            from customer
        ) as all_cities
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 16:54:35
query4_3 = '''
    with cities as (
        select city
        from store
        union
        select city
        from customer
    )
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 16:55:46
query4_3 = '''
    select sName
    from store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 16:56:11
query4_3 = '''
    select distinct sName
    from store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Sat, 05 Dec 2020 17:03:57
query4_3 = '''
    with unique_stores as (
        select distinct sName
        from store
    )
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 17:13:50
query4_3 = '''
    with cities(city) as (
        select city
        from store
        union
        select city
        from customer
    )
    select city
    from cities
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sat, 05 Dec 2020 17:14:57
query4_3 = '''
    with cities(city) as (
        select city
        from store
        union
        select city
        from customer
    )
    select sName, cities.city
    from store, cities
'''

pd.read_sql_query(query4_3, conn)
#[Out]#      sName       city
#[Out]# 0     Coop  Amsterdam
#[Out]# 1     Coop      Breda
#[Out]# 2     Coop  Eindhoven
#[Out]# 3     Coop        Oss
#[Out]# 4     Coop  Rotterdam
#[Out]# ..     ...        ...
#[Out]# 443  Jumbo  Eindhoven
#[Out]# 444  Jumbo        Oss
#[Out]# 445  Jumbo  Rotterdam
#[Out]# 446  Jumbo    Tilburg
#[Out]# 447  Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Sat, 05 Dec 2020 17:15:28
query4_3 = '''
    with cities(city) as (
        select city
        from store
        union
        select city
        from customer
    )
    select sName, cities.city
    from store, cities
    except
    select sName, city
    from store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Sat, 05 Dec 2020 17:16:08
query4_3 = '''
    with cities(city) as (
        select city
        from store
        union
        select city
        from customer
    )
    select sName
    from (
        select sName, cities.city
        from store, cities
        except
        select sName, city
        from store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0   Albert Hein
#[Out]# 1   Albert Hein
#[Out]# 2          Coop
#[Out]# 3          Coop
#[Out]# 4          Dirk
#[Out]# 5          Dirk
#[Out]# 6          Dirk
#[Out]# 7          Dirk
#[Out]# 8     Hoogvliet
#[Out]# 9     Hoogvliet
#[Out]# 10    Hoogvliet
#[Out]# 11        Jumbo
#[Out]# 12        Jumbo
#[Out]# 13         Lidl
#[Out]# 14         Lidl
#[Out]# 15       Sligro
#[Out]# 16       Sligro
# Sat, 05 Dec 2020 17:16:34
query4_3 = '''
    with cities(city) as (
        select city
        from store
        union
        select city
        from customer
    )
    select sName
    from store
    except
    select sName
    from (
        select sName, cities.city
        from store, cities
        except
        select sName, city
        from store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 17:17:32
query4_3 = '''
    select city
    from store
    union
    select city
    from customer
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sat, 05 Dec 2020 17:19:53
test = '''
    select sName, city
    from store
'''

pd.read_sql_query(test, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 05 Dec 2020 17:20:06
test = '''
    select sName, city
    from store
    order by sName
'''

pd.read_sql_query(test, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein      Breda
#[Out]# ..          ...        ...
#[Out]# 59       Sligro  Amsterdam
#[Out]# 60       Sligro  Amsterdam
#[Out]# 61       Sligro  Eindhoven
#[Out]# 62       Sligro  Amsterdam
#[Out]# 63       Sligro      Breda
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 05 Dec 2020 17:20:14
test = '''
    select distinct sName, city
    from store
    order by sName
'''

pd.read_sql_query(test, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop  Rotterdam
#[Out]# 7          Coop    Tilburg
#[Out]# 8          Coop      Breda
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet    Tilburg
#[Out]# 16    Hoogvliet  Rotterdam
#[Out]# 17        Jumbo  Rotterdam
#[Out]# 18        Jumbo    Tilburg
#[Out]# 19        Jumbo  Eindhoven
#[Out]# 20        Jumbo      Breda
#[Out]# 21        Jumbo        Oss
#[Out]# 22         Lidl  Eindhoven
#[Out]# 23         Lidl  Amsterdam
#[Out]# 24         Lidl    Utrecht
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl      Breda
#[Out]# 27       Sligro  Rotterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro    Tilburg
#[Out]# 31       Sligro  Amsterdam
# Sat, 05 Dec 2020 17:21:36
test = '''
    select distinct count(sName)
    from store
    order by sName
'''

pd.read_sql_query(test, conn)
#[Out]#    count(sName)
#[Out]# 0            64
# Sat, 05 Dec 2020 17:22:12
test = '''
    select distinct sName count(sName)
    from store
    group by sName
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 17:22:37
test = '''
    select distinct sName, count(sName)
    from store
    group by sName
'''

pd.read_sql_query(test, conn)
#[Out]#          sName  count(sName)
#[Out]# 0  Albert Hein             8
#[Out]# 1         Coop            14
#[Out]# 2         Dirk             6
#[Out]# 3    Hoogvliet             9
#[Out]# 4        Jumbo             8
#[Out]# 5         Lidl            10
#[Out]# 6       Sligro             9
# Sat, 05 Dec 2020 17:23:16
test = '''
    select sName, count(sName)
    from (select distinct sName, city from store)
    group by sName
'''

pd.read_sql_query(test, conn)
#[Out]#          sName  count(sName)
#[Out]# 0  Albert Hein             5
#[Out]# 1         Coop             5
#[Out]# 2         Dirk             3
#[Out]# 3    Hoogvliet             4
#[Out]# 4        Jumbo             5
#[Out]# 5         Lidl             5
#[Out]# 6       Sligro             5
# Sat, 05 Dec 2020 17:24:04
test = '''
    select sName, city
    from (select distinct sName, city from store)
'''

pd.read_sql_query(test, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Sat, 05 Dec 2020 17:24:10
test = '''
    select sName, city
    from (select distinct sName, city from store)
    order by sName
'''

pd.read_sql_query(test, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop  Rotterdam
#[Out]# 7          Coop    Tilburg
#[Out]# 8          Coop      Breda
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet    Tilburg
#[Out]# 16    Hoogvliet  Rotterdam
#[Out]# 17        Jumbo  Rotterdam
#[Out]# 18        Jumbo    Tilburg
#[Out]# 19        Jumbo  Eindhoven
#[Out]# 20        Jumbo      Breda
#[Out]# 21        Jumbo        Oss
#[Out]# 22         Lidl  Eindhoven
#[Out]# 23         Lidl  Amsterdam
#[Out]# 24         Lidl    Utrecht
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl      Breda
#[Out]# 27       Sligro  Rotterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro    Tilburg
#[Out]# 31       Sligro  Amsterdam
# Sat, 05 Dec 2020 17:24:14
test = '''
    select sName, city
    from (select distinct sName, city from store)
    order by sName, city
'''

pd.read_sql_query(test, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Sat, 05 Dec 2020 17:26:30
test = '''
    INSERT INTO store VALUES (60,"Albert Hein","test1","Amsterdam");
    INSERT INTO store VALUES (61,"Albert Hein","test2","Oss");
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 17:26:46
test = '''
    INSERT INTO store VALUES (60,"Albert Hein","test1","Amsterdam");
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 17:26:50
test = '''
    INSERT INTO store VALUES (60,"Albert Hein","test1","Amsterdam")
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 17:27:22
test = '''
    SELECT *
    FROM STORE
    WHERE sName = 'Albert Hein'
'''

pd.read_sql_query(test, conn)
#[Out]#    sID        sName         street       city
#[Out]# 0    8  Albert Hein    Molenstraat  Eindhoven
#[Out]# 1    9  Albert Hein      Koestraat    Tilburg
#[Out]# 2   11  Albert Hein       Hofplein  Rotterdam
#[Out]# 3   24  Albert Hein  Stationsplein      Breda
#[Out]# 4   25  Albert Hein  Stationsplein      Breda
#[Out]# 5   32  Albert Hein     Hoogstraat    Utrecht
#[Out]# 6   41  Albert Hein     Bergselaan  Rotterdam
#[Out]# 7   44  Albert Hein  Ambachtstraat    Utrecht
# Sat, 05 Dec 2020 17:27:42
test = '''
    SELECT *
    FROM STORE
    WHERE sId = 60
'''

pd.read_sql_query(test, conn)
#[Out]#    sID sName        street   city
#[Out]# 0   60  Lidl  Pannekoekweg  Breda
# Sat, 05 Dec 2020 17:27:52
test = '''
    SELECT max(sId)
    FROM STORE
'''

pd.read_sql_query(test, conn)
#[Out]#    max(sId)
#[Out]# 0        63
# Sat, 05 Dec 2020 17:27:57
test = '''
    SELECT sName, max(sId)
    FROM STORE
'''

pd.read_sql_query(test, conn)
#[Out]#    sName  max(sId)
#[Out]# 0  Jumbo        63
# Sat, 05 Dec 2020 17:28:14
test = '''
    INSERT INTO store VALUES (64,"Albert Hein","test2","Oss");
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 17:28:46
test = '''
    select * 
    from store
    order by sId desc
'''

pd.read_sql_query(test, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0    64  Albert Hein             test2        Oss
#[Out]# 1    63        Jumbo     Stationstraat        Oss
#[Out]# 2    62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 3    61         Lidl      Pannekoekweg      Breda
#[Out]# 4    60         Lidl      Pannekoekweg      Breda
#[Out]# ..  ...          ...               ...        ...
#[Out]# 60    4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 61    3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 62    2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 63    1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 64    0         Coop      Kalverstraat  Amsterdam
#[Out]# 
#[Out]# [65 rows x 4 columns]
# Sat, 05 Dec 2020 17:29:03
test = '''
    INSERT INTO store VALUES (62,"Albert Hein","test2","Amsterdam");
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 17:29:29
test = '''
    select *
    from store
    order by id desc
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 17:29:37
test = '''
    select *
    from store
    order by sId desc
'''

pd.read_sql_query(test, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0    63      Jumbo     Stationstraat        Oss
#[Out]# 1    62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 2    61       Lidl      Pannekoekweg      Breda
#[Out]# 3    60       Lidl      Pannekoekweg      Breda
#[Out]# 4    59      Jumbo  Rozemarijnstraat      Breda
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59    4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# 60    3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 61    2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 62    1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 63    0       Coop      Kalverstraat  Amsterdam
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Sat, 05 Dec 2020 17:31:56
test = '''
    select *
    from store
    order by sId desc
'''

pd.read_sql_query(test, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0    63      Jumbo     Stationstraat        Oss
#[Out]# 1    62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 2    61       Lidl      Pannekoekweg      Breda
#[Out]# 3    60       Lidl      Pannekoekweg      Breda
#[Out]# 4    59      Jumbo  Rozemarijnstraat      Breda
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59    4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# 60    3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 61    2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 62    1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 63    0       Coop      Kalverstraat  Amsterdam
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Sat, 05 Dec 2020 17:32:01
test = '''
    select *
    from store
    order by sId desc
'''

pd.read_sql_query(test, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0    63      Jumbo     Stationstraat        Oss
#[Out]# 1    62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 2    61       Lidl      Pannekoekweg      Breda
#[Out]# 3    60       Lidl      Pannekoekweg      Breda
#[Out]# 4    59      Jumbo  Rozemarijnstraat      Breda
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59    4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# 60    3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 61    2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 62    1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 63    0       Coop      Kalverstraat  Amsterdam
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Sat, 05 Dec 2020 17:42:29
test = '''
    select *
    from store
    order by sId desc
'''

pd.read_sql_query(test, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0    65  Albert Hein             test1  Amsterdam
#[Out]# 1    64  Albert Hein             test1        Oss
#[Out]# 2    63        Jumbo     Stationstraat        Oss
#[Out]# 3    62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 4    61         Lidl      Pannekoekweg      Breda
#[Out]# ..  ...          ...               ...        ...
#[Out]# 61    4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 62    3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 63    2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 64    1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 65    0         Coop      Kalverstraat  Amsterdam
#[Out]# 
#[Out]# [66 rows x 4 columns]
# Sat, 05 Dec 2020 17:43:27
query4_3 = '''
    with cities(city) as (
        select city
        from store
        union
        select city
        from customer
    )
    select sName
    from store
    except
    select sName
    from (
        select sName, cities.city
        from store, cities
        except
        select sName, city
        from store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0  Albert Hein
# Sat, 05 Dec 2020 17:51:49
query4_4 = '''
    select *
    from purchase
    limit 10
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    tID  cID  sID  pID        date  quantity  price
#[Out]# 0    0    0    3   10  2018-08-22         1   0.45
#[Out]# 1    1    1   23   14  2018-08-20         2   4.65
#[Out]# 2    2    1    3   16  2018-08-20         3   1.60
#[Out]# 3    3    1   17    9  2018-08-20         2   1.25
#[Out]# 4    4    1   32   25  2018-08-20         4   3.95
#[Out]# 5    5    1   16   26  2018-08-20         4   2.75
#[Out]# 6    6    1   46   11  2018-08-21         8   0.90
#[Out]# 7    7    1   36   27  2018-08-21         6   9.10
#[Out]# 8    8    2   12   20  2018-08-16         1   2.45
#[Out]# 9    9    2   39    9  2018-08-17         7   1.35
# Sat, 05 Dec 2020 17:53:42
query4_4 = '''
    select cId, date, max(sum(price))
    from purchase
    group by cId, date
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 17:53:54
query4_4 = '''
    select cId, date, sum(price)
    from purchase
    group by cId, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sum(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 17:55:37
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select max(day_total)
    from cust_day_total
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    max(day_total)
#[Out]# 0            39.1
# Sat, 05 Dec 2020 17:55:54
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select cId, date, max(day_total)
    from cust_day_total
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cId        date  max(day_total)
#[Out]# 0  161  2018-08-26            39.1
# Sat, 05 Dec 2020 17:56:42
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select cId, date, day_total
    from cust_day_total
    where date = '2018-08-26'
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cId        date  day_total
#[Out]# 0     7  2018-08-26       3.10
#[Out]# 1    13  2018-08-26       1.65
#[Out]# 2    16  2018-08-26       3.00
#[Out]# 3    27  2018-08-26       4.45
#[Out]# 4    33  2018-08-26       7.00
#[Out]# 5    34  2018-08-26       3.45
#[Out]# 6    44  2018-08-26       6.45
#[Out]# 7    51  2018-08-26       5.55
#[Out]# 8    59  2018-08-26       5.85
#[Out]# 9    68  2018-08-26       2.30
#[Out]# 10   76  2018-08-26       3.30
#[Out]# 11   91  2018-08-26      13.55
#[Out]# 12   92  2018-08-26       7.70
#[Out]# 13  113  2018-08-26      10.30
#[Out]# 14  123  2018-08-26       2.60
#[Out]# 15  124  2018-08-26      28.80
#[Out]# 16  127  2018-08-26       8.35
#[Out]# 17  134  2018-08-26       9.25
#[Out]# 18  159  2018-08-26      15.75
#[Out]# 19  161  2018-08-26      39.10
#[Out]# 20  162  2018-08-26       1.70
#[Out]# 21  169  2018-08-26       3.85
#[Out]# 22  176  2018-08-26       2.65
#[Out]# 23  180  2018-08-26       3.10
#[Out]# 24  189  2018-08-26       2.50
#[Out]# 25  190  2018-08-26      21.90
# Sat, 05 Dec 2020 17:57:12
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select cId, date, day_total
    from cust_day_total
    where date = '2018-08-26'
    order by day_total desc
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cId        date  day_total
#[Out]# 0   161  2018-08-26      39.10
#[Out]# 1   124  2018-08-26      28.80
#[Out]# 2   190  2018-08-26      21.90
#[Out]# 3   159  2018-08-26      15.75
#[Out]# 4    91  2018-08-26      13.55
#[Out]# 5   113  2018-08-26      10.30
#[Out]# 6   134  2018-08-26       9.25
#[Out]# 7   127  2018-08-26       8.35
#[Out]# 8    92  2018-08-26       7.70
#[Out]# 9    33  2018-08-26       7.00
#[Out]# 10   44  2018-08-26       6.45
#[Out]# 11   59  2018-08-26       5.85
#[Out]# 12   51  2018-08-26       5.55
#[Out]# 13   27  2018-08-26       4.45
#[Out]# 14  169  2018-08-26       3.85
#[Out]# 15   34  2018-08-26       3.45
#[Out]# 16   76  2018-08-26       3.30
#[Out]# 17  180  2018-08-26       3.10
#[Out]# 18    7  2018-08-26       3.10
#[Out]# 19   16  2018-08-26       3.00
#[Out]# 20  176  2018-08-26       2.65
#[Out]# 21  123  2018-08-26       2.60
#[Out]# 22  189  2018-08-26       2.50
#[Out]# 23   68  2018-08-26       2.30
#[Out]# 24  162  2018-08-26       1.70
#[Out]# 25   13  2018-08-26       1.65
# Sat, 05 Dec 2020 17:59:37
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select cName
    from customer
    where cId in (
        select cId
        from cust_day_total
        where day_total >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Sat, 05 Dec 2020 18:11:30
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    
    select max(day_total) * 0.75
    from cust_day_total
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    max(day_total) * 0.75
#[Out]# 0                 29.325
# Sat, 05 Dec 2020 18:11:49
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    
    select cId, date, day_total, max(day_total) * 0.75
    from cust_day_total
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cId        date  day_total  max(day_total) * 0.75
#[Out]# 0  161  2018-08-26       39.1                 29.325
# Sat, 05 Dec 2020 18:12:49
query4_4 = '''
select *
from purchase
where cId = 161
and date = '2018-08-26'
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     tID  cID  sID  pID        date  quantity  price
#[Out]# 0   386  161   15   19  2018-08-26         9   2.15
#[Out]# 1   387  161   51   22  2018-08-26         1   1.90
#[Out]# 2   387  161   51   24  2018-08-26         5   2.95
#[Out]# 3   388  161    1   27  2018-08-26         5   6.95
#[Out]# 4   389  161   55    1  2018-08-26         2   6.15
#[Out]# 5   390  161    3   16  2018-08-26         1   1.90
#[Out]# 6   391  161   18    7  2018-08-26         1   1.85
#[Out]# 7   392  161   31   14  2018-08-26         8   3.25
#[Out]# 8   393  161   36   13  2018-08-26         8   3.05
#[Out]# 9   394  161   47   17  2018-08-26         3   1.75
#[Out]# 10  393  161   36   28  2018-08-26         4   7.20
# Sat, 05 Dec 2020 18:14:53
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select cName
    from customer
    where cId in (
        select cId
        from purchase
        where price >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Sat, 05 Dec 2020 18:21:22
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city
query4_5 = '''
    select cId
    from purchase
    where sId in (
        select sId
        from store
        where lower(city) = 'eindhoven'
    )
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# ..   ...
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Sat, 05 Dec 2020 18:22:55
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city
query4_5 = '''
    select cId, city
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID       city
#[Out]# 0     1      Breda
#[Out]# 1     2  Amsterdam
#[Out]# 2     3      Breda
#[Out]# 3     4  Amsterdam
#[Out]# 4     5    Utrecht
#[Out]# ..  ...        ...
#[Out]# 64  182  Eindhoven
#[Out]# 65  185  Eindhoven
#[Out]# 66  186  Eindhoven
#[Out]# 67  188  Rotterdam
#[Out]# 68  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Sat, 05 Dec 2020 18:23:07
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city
query4_5 = '''
    select cId, city
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    order by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID       city
#[Out]# 0     2  Amsterdam
#[Out]# 1     4  Amsterdam
#[Out]# 2    59  Amsterdam
#[Out]# 3    70  Amsterdam
#[Out]# 4   124  Amsterdam
#[Out]# ..  ...        ...
#[Out]# 64  147    Utrecht
#[Out]# 65  159    Utrecht
#[Out]# 66  169    Utrecht
#[Out]# 67  178    Utrecht
#[Out]# 68  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Sat, 05 Dec 2020 18:23:47
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city
query4_5 = '''
    select city count(*)
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 18:23:55
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city
query4_5 = '''
    select city, count(*)
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(*)
#[Out]# 0  Amsterdam        10
#[Out]# 1      Breda         9
#[Out]# 2  Eindhoven        15
#[Out]# 3  Rotterdam        13
#[Out]# 4    Tilburg        10
#[Out]# 5    Utrecht        12
# Sat, 05 Dec 2020 18:25:40
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city
query4_5 = '''
    select city, count(cId)
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(cId)
#[Out]# 0  Amsterdam          10
#[Out]# 1      Breda           9
#[Out]# 2  Eindhoven          15
#[Out]# 3  Rotterdam          13
#[Out]# 4    Tilburg          10
#[Out]# 5    Utrecht          12
# Sat, 05 Dec 2020 18:28:34
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# all other cities should display 0

query4_5 = '''
    select city, count(*)
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(*)
#[Out]# 0  Amsterdam        10
#[Out]# 1      Breda         9
#[Out]# 2  Eindhoven        15
#[Out]# 3  Rotterdam        13
#[Out]# 4    Tilburg        10
#[Out]# 5    Utrecht        12
# Sat, 05 Dec 2020 18:28:54
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# all other cities should display 0

query4_5 = '''
    select city, count(*) number_of_customers
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number_of_customers
#[Out]# 0  Amsterdam                   10
#[Out]# 1      Breda                    9
#[Out]# 2  Eindhoven                   15
#[Out]# 3  Rotterdam                   13
#[Out]# 4    Tilburg                   10
#[Out]# 5    Utrecht                   12
# Sat, 05 Dec 2020 18:30:55
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    select city, 0
    from customer
    union
    select city, count(*) number_of_customers
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city   0
#[Out]# 0   Amsterdam   0
#[Out]# 1   Amsterdam  10
#[Out]# 2       Breda   0
#[Out]# 3       Breda   9
#[Out]# 4   Eindhoven   0
#[Out]# 5   Eindhoven  15
#[Out]# 6         Oss   0
#[Out]# 7   Rotterdam   0
#[Out]# 8   Rotterdam  13
#[Out]# 9     Tilburg   0
#[Out]# 10    Tilburg  10
#[Out]# 11    Utrecht   0
#[Out]# 12    Utrecht  12
# Sat, 05 Dec 2020 18:32:07
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    select city, 0 number_of_customers
    from customer
    union
    select city, count(*) number_of_customers
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  number_of_customers
#[Out]# 0   Amsterdam                    0
#[Out]# 1   Amsterdam                   10
#[Out]# 2       Breda                    0
#[Out]# 3       Breda                    9
#[Out]# 4   Eindhoven                    0
#[Out]# 5   Eindhoven                   15
#[Out]# 6         Oss                    0
#[Out]# 7   Rotterdam                    0
#[Out]# 8   Rotterdam                   13
#[Out]# 9     Tilburg                    0
#[Out]# 10    Tilburg                   10
#[Out]# 11    Utrecht                    0
#[Out]# 12    Utrecht                   12
# Sat, 05 Dec 2020 18:32:39
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    select city, count(*) number_of_customers
    from customer
    where cId in (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number_of_customers
#[Out]# 0  Amsterdam                   10
#[Out]# 1      Breda                    9
#[Out]# 2  Eindhoven                   15
#[Out]# 3  Rotterdam                   13
#[Out]# 4    Tilburg                   10
#[Out]# 5    Utrecht                   12
# Sat, 05 Dec 2020 20:04:46
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with customer_cities as (
        select city
        from customer
        where cId in (
            select cId
            from purchase
            where sId in (
                select sId
                from store
                where lower(city) = 'eindhoven'
            )
        )
    )
    select *
    from customer_cities
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city
#[Out]# 0       Breda
#[Out]# 1   Amsterdam
#[Out]# 2       Breda
#[Out]# 3   Amsterdam
#[Out]# 4     Utrecht
#[Out]# ..        ...
#[Out]# 64  Eindhoven
#[Out]# 65  Eindhoven
#[Out]# 66  Eindhoven
#[Out]# 67  Rotterdam
#[Out]# 68    Utrecht
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Sat, 05 Dec 2020 20:05:02
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with customer_cities as (
        select distinct city
        from customer
        where cId in (
            select cId
            from purchase
            where sId in (
                select sId
                from store
                where lower(city) = 'eindhoven'
            )
        )
    )
    select *
    from customer_cities
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0      Breda
#[Out]# 1  Amsterdam
#[Out]# 2    Utrecht
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
# Sat, 05 Dec 2020 20:05:31
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with customer_cities as (
        select distinct city
        from customer
        where cId in (
            select cId
            from purchase
            where sId in (
                select sId
                from store
                where lower(city) = 'eindhoven'
            )
        )
    )
    select distinct city
    from customer
    except customer_cities
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:05:39
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with customer_cities as (
        select distinct city
        from customer
        where cId in (
            select cId
            from purchase
            where sId in (
                select sId
                from store
                where lower(city) = 'eindhoven'
            )
        )
    )
    select distinct city
    from customer
    except 
    select *
    from customer_cities
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city
#[Out]# 0  Oss
# Sat, 05 Dec 2020 20:06:38
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with customer_cities as (
        select distinct city
        from customer
        where cId in (
            select cId
            from purchase
            where sId in (
                select sId
                from store
                where lower(city) = 'eindhoven'
            )
        )
    )
    
    (select distinct city, 0
    from customer)
    except 
    (select *
    from customer_cities)
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:08:15
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    
    select cId
    from shopped_ehv
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cId
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# ..   ...
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Sat, 05 Dec 2020 20:08:20
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_ehv as (
        select distinct cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    
    select cId
    from shopped_ehv
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cId
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Sat, 05 Dec 2020 20:10:52
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_in_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    with per_city as (
        select city, count(*)
        from customer
        where cId in (
            select cId 
            from shopped_in_ehv
        )
        group by city
    )
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:11:00
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_in_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    with per_city as (
        select city, count(*)
        from customer
        where cId in (
            select cId 
            from shopped_in_ehv
        )
        group by city
    )
    select *
    from per_city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:11:05
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_in_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    per_city as (
        select city, count(*)
        from customer
        where cId in (
            select cId 
            from shopped_in_ehv
        )
        group by city
    )
    select *
    from per_city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:11:42
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_in_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    );
    per_city as (
        select city, count(*)
        from customer
        where cId in (
            select cId 
            from shopped_in_ehv
        )
        group by city
    )
    select *
    from per_city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:11:52
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_in_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    );
    with per_city as (
        select city, count(*)
        from customer
        where cId in (
            select cId 
            from shopped_in_ehv
        )
        group by city
    )
    select *
    from per_city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:13:18
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_in_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    select city, count(*)
    from customer
    where cId in (
        select cId 
        from shopped_in_ehv
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(*)
#[Out]# 0  Amsterdam        10
#[Out]# 1      Breda         9
#[Out]# 2  Eindhoven        15
#[Out]# 3  Rotterdam        13
#[Out]# 4    Tilburg        10
#[Out]# 5    Utrecht        12
# Sat, 05 Dec 2020 20:13:40
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_in_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    select city, count(*) number_of_customers
    from customer
    where cId in (
        select cId 
        from shopped_in_ehv
    )
    group by city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number_of_customers
#[Out]# 0  Amsterdam                   10
#[Out]# 1      Breda                    9
#[Out]# 2  Eindhoven                   15
#[Out]# 3  Rotterdam                   13
#[Out]# 4    Tilburg                   10
#[Out]# 5    Utrecht                   12
# Sat, 05 Dec 2020 20:15:02
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_in_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    select city, count(*) number_of_customers
    from customer
    where cId in (
        select cId 
        from shopped_in_ehv
    )
    group by city
    select city, 0
    from customer
    where city not in (
        select city
        from customer
        where cId in (
            select cId
            from shopped_in_ehv
        )
    )
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:15:09
# Get customer ids of people that made a purchase at a 
# store in eindhoven.
# Map those ids onto customers including their cities
# count the occurences of cities and group by city

# +

# all other cities should display 0

query4_5 = '''
    with shopped_in_ehv as (
        select cId
        from purchase
        where sId in (
            select sId
            from store
            where lower(city) = 'eindhoven'
        )
    )
    select city, count(*) number_of_customers
    from customer
    where cId in (
        select cId 
        from shopped_in_ehv
    )
    group by city
    union
    select city, 0
    from customer
    where city not in (
        select city
        from customer
        where cId in (
            select cId
            from shopped_in_ehv
        )
    )
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number_of_customers
#[Out]# 0  Amsterdam                   10
#[Out]# 1      Breda                    9
#[Out]# 2  Eindhoven                   15
#[Out]# 3        Oss                    0
#[Out]# 4  Rotterdam                   13
#[Out]# 5    Tilburg                   10
#[Out]# 6    Utrecht                   12
# Sat, 05 Dec 2020 20:38:44
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
'''
# Sat, 05 Dec 2020 20:39:24
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sID, sName
    from store
    where sID not in (
        select sID
        from inventory_size
        where size > 20
    );
'''
# Sat, 05 Dec 2020 20:39:36
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sID, sName
    from store
    where sID not in (
        select sID
        from inventory_size
        where size > 20
    );
'''

pd.read_sql_query(test, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# ..  ...          ...
#[Out]# 61   61         Lidl
#[Out]# 62   62        Jumbo
#[Out]# 63   63        Jumbo
#[Out]# 64   64  Albert Hein
#[Out]# 65   65  Albert Hein
#[Out]# 
#[Out]# [66 rows x 2 columns]
# Sat, 05 Dec 2020 20:40:02
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select count(*)
    from store
'''

pd.read_sql_query(test, conn)
#[Out]#    count(*)
#[Out]# 0        66
# Sat, 05 Dec 2020 20:40:15
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select *
    from inventory_size
'''

pd.read_sql_query(test, conn)
#[Out]#      sID        date  size
#[Out]# 0      0  2018-07-18     1
#[Out]# 1      0  2018-08-15     3
#[Out]# 2      0  2018-08-16     2
#[Out]# 3      0  2018-08-17     1
#[Out]# 4      0  2018-08-18     1
#[Out]# ..   ...         ...   ...
#[Out]# 517   59  2018-08-24     1
#[Out]# 518   59  2018-08-25     2
#[Out]# 519   59  2018-08-26     2
#[Out]# 520   59  2018-08-27     1
#[Out]# 521   60  2018-07-10     1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Sat, 05 Dec 2020 20:40:33
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sId, date, max(size)
    from inventory_size
'''

pd.read_sql_query(test, conn)
#[Out]#    sID        date  max(size)
#[Out]# 0   35  2018-08-23          5
# Sat, 05 Dec 2020 20:40:47
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sID, sName
    from store
    where sID not in (
        select sID
        from inventory_size
        where size > 4
    );
'''

pd.read_sql_query(test, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# ..  ...          ...
#[Out]# 59   61         Lidl
#[Out]# 60   62        Jumbo
#[Out]# 61   63        Jumbo
#[Out]# 62   64  Albert Hein
#[Out]# 63   65  Albert Hein
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 05 Dec 2020 20:41:01
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sID, sName
    from store
    where sID in (
        select sID
        from inventory_size
        where size > 4
    );
'''

pd.read_sql_query(test, conn)
#[Out]#    sID sName
#[Out]# 0   35  Lidl
#[Out]# 1   57  Dirk
# Sat, 05 Dec 2020 20:42:05
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select *
    from store s, inventory_size is
    where s.sId = is.sID
    and is.sID in (35, 57)
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 20:42:33
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select *
    from store, inventory_size
    where sId = sID
    and sID in (35, 57)
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 20:42:52
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select *
    from store s, inventory_size i
    where s.sId = i.sID
    and i.sID in (35, 57)
'''

pd.read_sql_query(test, conn)
#[Out]#     sID sName         street       city  sID        date  size
#[Out]# 0    35  Lidl  Julianastraat    Utrecht   35  2018-08-15     1
#[Out]# 1    35  Lidl  Julianastraat    Utrecht   35  2018-08-16     2
#[Out]# 2    35  Lidl  Julianastraat    Utrecht   35  2018-08-19     1
#[Out]# 3    35  Lidl  Julianastraat    Utrecht   35  2018-08-20     1
#[Out]# 4    35  Lidl  Julianastraat    Utrecht   35  2018-08-21     2
#[Out]# 5    35  Lidl  Julianastraat    Utrecht   35  2018-08-22     1
#[Out]# 6    35  Lidl  Julianastraat    Utrecht   35  2018-08-23     5
#[Out]# 7    35  Lidl  Julianastraat    Utrecht   35  2018-08-24     2
#[Out]# 8    35  Lidl  Julianastraat    Utrecht   35  2018-08-25     3
#[Out]# 9    57  Dirk    Molenstraat  Eindhoven   57  2018-08-15     1
#[Out]# 10   57  Dirk    Molenstraat  Eindhoven   57  2018-08-16     1
#[Out]# 11   57  Dirk    Molenstraat  Eindhoven   57  2018-08-17     2
#[Out]# 12   57  Dirk    Molenstraat  Eindhoven   57  2018-08-18     2
#[Out]# 13   57  Dirk    Molenstraat  Eindhoven   57  2018-08-21     1
#[Out]# 14   57  Dirk    Molenstraat  Eindhoven   57  2018-08-22     5
#[Out]# 15   57  Dirk    Molenstraat  Eindhoven   57  2018-08-23     1
#[Out]# 16   57  Dirk    Molenstraat  Eindhoven   57  2018-08-24     2
#[Out]# 17   57  Dirk    Molenstraat  Eindhoven   57  2018-08-26     1
# Sat, 05 Dec 2020 20:43:21
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select i.sId, s.sName, date, size
    from store s, inventory_size i
    where s.sId = i.sID
    and i.sID in (35, 57)
'''

pd.read_sql_query(test, conn)
#[Out]#     sID sName        date  size
#[Out]# 0    35  Lidl  2018-08-15     1
#[Out]# 1    35  Lidl  2018-08-16     2
#[Out]# 2    35  Lidl  2018-08-19     1
#[Out]# 3    35  Lidl  2018-08-20     1
#[Out]# 4    35  Lidl  2018-08-21     2
#[Out]# 5    35  Lidl  2018-08-22     1
#[Out]# 6    35  Lidl  2018-08-23     5
#[Out]# 7    35  Lidl  2018-08-24     2
#[Out]# 8    35  Lidl  2018-08-25     3
#[Out]# 9    57  Dirk  2018-08-15     1
#[Out]# 10   57  Dirk  2018-08-16     1
#[Out]# 11   57  Dirk  2018-08-17     2
#[Out]# 12   57  Dirk  2018-08-18     2
#[Out]# 13   57  Dirk  2018-08-21     1
#[Out]# 14   57  Dirk  2018-08-22     5
#[Out]# 15   57  Dirk  2018-08-23     1
#[Out]# 16   57  Dirk  2018-08-24     2
#[Out]# 17   57  Dirk  2018-08-26     1
# Sat, 05 Dec 2020 20:43:43
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select i.sId, s.sName, date, size
    from store s, inventory_size i
    where s.sId = i.sID
    and i.sID in (35, 57)
    and where size = 5
'''

pd.read_sql_query(test, conn)
# Sat, 05 Dec 2020 20:43:49
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select i.sId, s.sName, date, size
    from store s, inventory_size i
    where s.sId = i.sID
    and i.sID in (35, 57)
    and size = 5
'''

pd.read_sql_query(test, conn)
#[Out]#    sID sName        date  size
#[Out]# 0   35  Lidl  2018-08-23     5
#[Out]# 1   57  Dirk  2018-08-22     5
# Sat, 05 Dec 2020 20:44:06
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sID, sName
    from store
    where sID not in (
        select sID
        from inventory_size
        where size > 20
    );
'''

pd.read_sql_query(test, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# ..  ...          ...
#[Out]# 61   61         Lidl
#[Out]# 62   62        Jumbo
#[Out]# 63   63        Jumbo
#[Out]# 64   64  Albert Hein
#[Out]# 65   65  Albert Hein
#[Out]# 
#[Out]# [66 rows x 2 columns]
# Sat, 05 Dec 2020 20:44:12
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sID, sName
    from store
    where sID not in (
        select sID
        from inventory_size
        where size > 4
    );
'''

pd.read_sql_query(test, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# ..  ...          ...
#[Out]# 59   61         Lidl
#[Out]# 60   62        Jumbo
#[Out]# 61   63        Jumbo
#[Out]# 62   64  Albert Hein
#[Out]# 63   65  Albert Hein
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 05 Dec 2020 20:44:17
test = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sID, sName
    from store
    where sID not in (
        select sID
        from inventory_size
        where size > 20
    );
'''

pd.read_sql_query(test, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# ..  ...          ...
#[Out]# 61   61         Lidl
#[Out]# 62   62        Jumbo
#[Out]# 63   63        Jumbo
#[Out]# 64   64  Albert Hein
#[Out]# 65   65  Albert Hein
#[Out]# 
#[Out]# [66 rows x 2 columns]

# IPython log file

query4_6 = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sID, sName
    from store
    where sID not in (
        select sID
        from inventory_size
        where size > 20
    );
'''

pd.read_sql_query(query4_6, conn)
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Sun, 06 Dec 2020 15:41:40
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 06 Dec 2020 15:41:51
query4_6 = '''
    with inventory_size(sID, date, size) as (
        select sID, date, count(distinct pID)
        from inventory
        group by sID, date
    )
    select sID, sName
    from store
    where sID not in (
        select sID
        from inventory_size
        where size > 20
    );
'''

pd.read_sql_query(query4_6, conn)
#[Out]#     sID        sName
#[Out]# 0     0         Coop
#[Out]# 1     1    Hoogvliet
#[Out]# 2     2        Jumbo
#[Out]# 3     3       Sligro
#[Out]# 4     4    Hoogvliet
#[Out]# ..  ...          ...
#[Out]# 61   61         Lidl
#[Out]# 62   62        Jumbo
#[Out]# 63   63        Jumbo
#[Out]# 64   64  Albert Hein
#[Out]# 65   65  Albert Hein
#[Out]# 
#[Out]# [66 rows x 2 columns]
# Sun, 06 Dec 2020 16:15:47
q1_a = '''
    select *
    from shoppinglist sl
    where not exists (
        select *
        from purchase p
        where sl.date = p.date
        and sl.cId = p.cId
    )
'''

pd.read_sql_query(q1_a, conn)
#[Out]#      cID  pID  quantity        date
#[Out]# 0      8    8         5  2018-08-15
#[Out]# 1     18   20         4  2018-08-15
#[Out]# 2     21   27         9  2018-08-20
#[Out]# 3     25   26         9  2018-08-27
#[Out]# 4     27    6         1  2018-08-25
#[Out]# ..   ...  ...       ...         ...
#[Out]# 98   183   12         9  2018-08-21
#[Out]# 99   183   18         8  2018-08-21
#[Out]# 100  183    6         3  2018-08-22
#[Out]# 101  183   14         7  2018-08-22
#[Out]# 102  183   25         4  2018-08-22
#[Out]# 
#[Out]# [103 rows x 4 columns]
# Sun, 06 Dec 2020 16:17:48
a = '''
    select count(*)
    from shoppinglist
    union
    select count(*)
    from purchase
'''

pd.read_sql_query(a, conn)
#[Out]#    count(*)
#[Out]# 0       492
#[Out]# 1       509
# Sun, 06 Dec 2020 16:51:01
# exclude those sl tuples for which no purchases were made
# that means we have sl tuples for which at least one result exists

# exclude those users that made a purchase for a product that was on the sl
q1_a = '''
    select *
    from shoppinglist sl
    where (sl.cId, sl.date) not in (
        select cId, date
        from purchase
    )
'''

pd.read_sql_query(q1_a, conn)
#[Out]#      cID  pID  quantity        date
#[Out]# 0      8    8         5  2018-08-15
#[Out]# 1     18   20         4  2018-08-15
#[Out]# 2     21   27         9  2018-08-20
#[Out]# 3     25   26         9  2018-08-27
#[Out]# 4     27    6         1  2018-08-25
#[Out]# ..   ...  ...       ...         ...
#[Out]# 98   183   12         9  2018-08-21
#[Out]# 99   183   18         8  2018-08-21
#[Out]# 100  183    6         3  2018-08-22
#[Out]# 101  183   14         7  2018-08-22
#[Out]# 102  183   25         4  2018-08-22
#[Out]# 
#[Out]# [103 rows x 4 columns]
# Sun, 06 Dec 2020 16:51:20
a = '''
    select *
    from shoppinglist sl
    where not exists (
        select *
        from purchase p
        where sl.date = p.date
        and sl.cId = p.cId
    )
'''

pd.read_sql_query(a, conn)
#[Out]#      cID  pID  quantity        date
#[Out]# 0      8    8         5  2018-08-15
#[Out]# 1     18   20         4  2018-08-15
#[Out]# 2     21   27         9  2018-08-20
#[Out]# 3     25   26         9  2018-08-27
#[Out]# 4     27    6         1  2018-08-25
#[Out]# ..   ...  ...       ...         ...
#[Out]# 98   183   12         9  2018-08-21
#[Out]# 99   183   18         8  2018-08-21
#[Out]# 100  183    6         3  2018-08-22
#[Out]# 101  183   14         7  2018-08-22
#[Out]# 102  183   25         4  2018-08-22
#[Out]# 
#[Out]# [103 rows x 4 columns]
# Sun, 06 Dec 2020 17:00:57
# exclude those sl tuples for which no purchases were made
# that means we have sl tuples for which at least one result exists

# exclude those users that made a purchase for a product that was on the sl
q1_a = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId not in (
        select cId
        from list_no_purchase
        union
        select cId
        from list_same_prod_purchased
    )
'''

pd.read_sql_query(q1_a, conn)
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     4      Daan
#[Out]# 2     6     Milan
#[Out]# 3     9    Thomas
#[Out]# 4    12      Adam
#[Out]# 5    14       Max
#[Out]# 6    16    Julian
#[Out]# 7    23       Jan
#[Out]# 8    32     Vince
#[Out]# 9    44     Jason
#[Out]# 10   48      Tygo
#[Out]# 11   49       Cas
#[Out]# 12   53       Job
#[Out]# 13   54       Jax
#[Out]# 14   56    Tobias
#[Out]# 15   60  Mohammed
#[Out]# 16   61    Morris
#[Out]# 17   65    Pepijn
#[Out]# 18   69      Roan
#[Out]# 19   75      Jace
#[Out]# 20   78      Mick
#[Out]# 21   79    Joshua
#[Out]# 22   81     Simon
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  105      Nora
#[Out]# 27  106     Fleur
#[Out]# 28  107    Olivia
#[Out]# 29  114      Maud
#[Out]# 30  120     Sarah
#[Out]# 31  125       Noa
#[Out]# 32  126      Lina
#[Out]# 33  129     Esmee
#[Out]# 34  130     Sanne
#[Out]# 35  132    Hannah
#[Out]# 36  135     Sofia
#[Out]# 37  139     Elise
#[Out]# 38  140      Vera
#[Out]# 39  141       Mia
#[Out]# 40  142        Bo
#[Out]# 41  143     Naomi
#[Out]# 42  146     Norah
#[Out]# 43  153     Amber
#[Out]# 44  155     Linde
#[Out]# 45  156      Luna
#[Out]# 46  160      Lara
#[Out]# 47  173     Livia
#[Out]# 48  174      Romy
#[Out]# 49  177     Eline
#[Out]# 50  182   Johanna
#[Out]# 51  184     Wilko
#[Out]# 52  185      Nick
#[Out]# 53  186    Angela
#[Out]# 54  188      Pino
#[Out]# 55  189      Koen
#[Out]# 56  190    Kostas
# Sun, 06 Dec 2020 17:09:52
# Similar to a but now exclude the cIds of people who violated our rule.

# So if we exclude those invalid shoppinglist tuples first
# If we then exclude the customer ids who ever purchase a product on their sl
# we should be left with those customers that never purchase something of their sl
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId not in (
        select distinct sl.cId
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select *
            from list_no_purchase
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID   cName
#[Out]# 0     0    Noah
#[Out]# 1     4    Daan
#[Out]# 2     6   Milan
#[Out]# 3     9  Thomas
#[Out]# 4    12    Adam
#[Out]# ..  ...     ...
#[Out]# 81  185    Nick
#[Out]# 82  186  Angela
#[Out]# 83  188    Pino
#[Out]# 84  189    Koen
#[Out]# 85  190  Kostas
#[Out]# 
#[Out]# [86 rows x 2 columns]
# Sun, 06 Dec 2020 17:11:28
# Similar to a but now exclude the cIds of people who violated our rule.

# So if we exclude those invalid shoppinglist tuples first
# If we then exclude the customer ids who ever purchase a product on their sl
# we should be left with those customers that never purchase something of their sl
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId not in (
        select distinct sl.cId
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from list_no_purchase
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID   cName
#[Out]# 0     0    Noah
#[Out]# 1     4    Daan
#[Out]# 2     6   Milan
#[Out]# 3     9  Thomas
#[Out]# 4    12    Adam
#[Out]# ..  ...     ...
#[Out]# 81  185    Nick
#[Out]# 82  186  Angela
#[Out]# 83  188    Pino
#[Out]# 84  189    Koen
#[Out]# 85  190  Kostas
#[Out]# 
#[Out]# [86 rows x 2 columns]
# Sun, 06 Dec 2020 17:17:56
# Similar to a but now exclude the cIds of people who violated our rule.

# So if we exclude those invalid shoppinglist tuples first
# If we then exclude the customer ids who ever purchase a product on their sl
# we should be left with those customers that never purchase something of their sl
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId not in (
        select distinct sl.cId
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from list_no_purchase
        )
        and (cId, date) not in (
            select cId, date
            from list_same_prod_purchased
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 164  185    Nick
#[Out]# 165  186  Angela
#[Out]# 166  188    Pino
#[Out]# 167  189    Koen
#[Out]# 168  190  Kostas
#[Out]# 
#[Out]# [169 rows x 2 columns]
# Sun, 06 Dec 2020 17:18:16
# Similar to a but now exclude the cIds of people who violated our rule.

# So if we exclude those invalid shoppinglist tuples first
# If we then exclude the customer ids who ever purchase a product on their sl
# we should be left with those customers that never purchase something of their sl
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId not in (
        select distinct sl.cId
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from list_no_purchase
        )
        or (cId, date) not in (
            select cId, date
            from list_same_prod_purchased
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     4      Daan
#[Out]# 2     6     Milan
#[Out]# 3     9    Thomas
#[Out]# 4    12      Adam
#[Out]# 5    14       Max
#[Out]# 6    16    Julian
#[Out]# 7    23       Jan
#[Out]# 8    32     Vince
#[Out]# 9    44     Jason
#[Out]# 10   48      Tygo
#[Out]# 11   49       Cas
#[Out]# 12   53       Job
#[Out]# 13   54       Jax
#[Out]# 14   56    Tobias
#[Out]# 15   60  Mohammed
#[Out]# 16   61    Morris
#[Out]# 17   65    Pepijn
#[Out]# 18   69      Roan
#[Out]# 19   75      Jace
#[Out]# 20   78      Mick
#[Out]# 21   79    Joshua
#[Out]# 22   81     Simon
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  105      Nora
#[Out]# 27  106     Fleur
#[Out]# 28  107    Olivia
#[Out]# 29  114      Maud
#[Out]# 30  120     Sarah
#[Out]# 31  125       Noa
#[Out]# 32  126      Lina
#[Out]# 33  129     Esmee
#[Out]# 34  130     Sanne
#[Out]# 35  132    Hannah
#[Out]# 36  135     Sofia
#[Out]# 37  139     Elise
#[Out]# 38  140      Vera
#[Out]# 39  141       Mia
#[Out]# 40  142        Bo
#[Out]# 41  143     Naomi
#[Out]# 42  146     Norah
#[Out]# 43  153     Amber
#[Out]# 44  155     Linde
#[Out]# 45  156      Luna
#[Out]# 46  160      Lara
#[Out]# 47  173     Livia
#[Out]# 48  174      Romy
#[Out]# 49  177     Eline
#[Out]# 50  182   Johanna
#[Out]# 51  184     Wilko
#[Out]# 52  185      Nick
#[Out]# 53  186    Angela
#[Out]# 54  188      Pino
#[Out]# 55  189      Koen
#[Out]# 56  190    Kostas
# Sun, 06 Dec 2020 17:20:04
# Similar to a but now exclude the cIds of people who violated our rule.

# So if we exclude those invalid shoppinglist tuples first
# If we then exclude the customer ids who ever purchase a product on their sl
# we should be left with those customers that never purchase something of their sl
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId in (
        select distinct sl.cId
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from list_no_purchase
        )
        and (cId, date) not in (
            select cId, date
            from list_same_prod_purchased
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID   cName
#[Out]# 0     7    Bram
#[Out]# 1    13   James
#[Out]# 2    27     Tim
#[Out]# 3    33    Sven
#[Out]# 4    38  Floris
#[Out]# 5    43     Tom
#[Out]# 6    59    Joep
#[Out]# 7    64    Stan
#[Out]# 8    68   Boris
#[Out]# 9    82   Dylan
#[Out]# 10   92   Jelte
#[Out]# 11   95    Emma
#[Out]# 12  100    Sara
#[Out]# 13  109    Lynn
#[Out]# 14  112    Yara
#[Out]# 15  116   Lieke
#[Out]# 16  123   Milou
#[Out]# 17  144     Ivy
#[Out]# 18  162   Elena
#[Out]# 19  167  Veerle
#[Out]# 20  169    Lily
# Sun, 06 Dec 2020 17:20:39
# Similar to a but now exclude the cIds of people who violated our rule.

# So if we exclude those invalid shoppinglist tuples first
# If we then exclude the customer ids who ever purchase a product on their sl
# we should be left with those customers that never purchase something of their sl
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId in (
        select distinct cId
        from shoppinglist
        where (cId, date) not in (
            select cId, date
            from list_no_purchase
        )
        and (cId, date) not in (
            select cId, date
            from list_same_prod_purchased
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID   cName
#[Out]# 0     7    Bram
#[Out]# 1    13   James
#[Out]# 2    27     Tim
#[Out]# 3    33    Sven
#[Out]# 4    38  Floris
#[Out]# 5    43     Tom
#[Out]# 6    59    Joep
#[Out]# 7    64    Stan
#[Out]# 8    68   Boris
#[Out]# 9    82   Dylan
#[Out]# 10   92   Jelte
#[Out]# 11   95    Emma
#[Out]# 12  100    Sara
#[Out]# 13  109    Lynn
#[Out]# 14  112    Yara
#[Out]# 15  116   Lieke
#[Out]# 16  123   Milou
#[Out]# 17  144     Ivy
#[Out]# 18  162   Elena
#[Out]# 19  167  Veerle
#[Out]# 20  169    Lily
# Sun, 06 Dec 2020 17:22:17
# Similar but now we want those cIds 
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId not in (
        select cId
        from list_no_purchase
        intersection
        select cId
        from list_same_prod_purchased
    )
'''

pd.read_sql_query(q1_b, conn)
# Sun, 06 Dec 2020 17:22:26
# Similar but now we want those cIds 
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId not in (
        select cId
        from list_no_purchase
        intersect
        select cId
        from list_same_prod_purchased
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#      cID   cName
#[Out]# 0      0    Noah
#[Out]# 1      1     Sem
#[Out]# 2      2   Lucas
#[Out]# 3      3    Finn
#[Out]# 4      4    Daan
#[Out]# ..   ...     ...
#[Out]# 158  185    Nick
#[Out]# 159  186  Angela
#[Out]# 160  188    Pino
#[Out]# 161  189    Koen
#[Out]# 162  190  Kostas
#[Out]# 
#[Out]# [163 rows x 2 columns]
# Sun, 06 Dec 2020 17:22:42
# Similar but now we want those cIds 
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId not in (
        select cId
        from list_no_purchase
        union
        select cId
        from list_same_prod_purchased
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID     cName
#[Out]# 0     0      Noah
#[Out]# 1     4      Daan
#[Out]# 2     6     Milan
#[Out]# 3     9    Thomas
#[Out]# 4    12      Adam
#[Out]# 5    14       Max
#[Out]# 6    16    Julian
#[Out]# 7    23       Jan
#[Out]# 8    32     Vince
#[Out]# 9    44     Jason
#[Out]# 10   48      Tygo
#[Out]# 11   49       Cas
#[Out]# 12   53       Job
#[Out]# 13   54       Jax
#[Out]# 14   56    Tobias
#[Out]# 15   60  Mohammed
#[Out]# 16   61    Morris
#[Out]# 17   65    Pepijn
#[Out]# 18   69      Roan
#[Out]# 19   75      Jace
#[Out]# 20   78      Mick
#[Out]# 21   79    Joshua
#[Out]# 22   81     Simon
#[Out]# 23   89  Johannes
#[Out]# 24   93     Oscar
#[Out]# 25   98     Julia
#[Out]# 26  105      Nora
#[Out]# 27  106     Fleur
#[Out]# 28  107    Olivia
#[Out]# 29  114      Maud
#[Out]# 30  120     Sarah
#[Out]# 31  125       Noa
#[Out]# 32  126      Lina
#[Out]# 33  129     Esmee
#[Out]# 34  130     Sanne
#[Out]# 35  132    Hannah
#[Out]# 36  135     Sofia
#[Out]# 37  139     Elise
#[Out]# 38  140      Vera
#[Out]# 39  141       Mia
#[Out]# 40  142        Bo
#[Out]# 41  143     Naomi
#[Out]# 42  146     Norah
#[Out]# 43  153     Amber
#[Out]# 44  155     Linde
#[Out]# 45  156      Luna
#[Out]# 46  160      Lara
#[Out]# 47  173     Livia
#[Out]# 48  174      Romy
#[Out]# 49  177     Eline
#[Out]# 50  182   Johanna
#[Out]# 51  184     Wilko
#[Out]# 52  185      Nick
#[Out]# 53  186    Angela
#[Out]# 54  188      Pino
#[Out]# 55  189      Koen
#[Out]# 56  190    Kostas
# Sun, 06 Dec 2020 17:22:58
# Similar but now we want those cIds 
q1_b = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId in (
        select distinct cId
        from shoppinglist
        where (cId, date) not in (
            select cId, date
            from list_no_purchase
        )
        and (cId, date) not in (
            select cId, date
            from list_same_prod_purchased
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID   cName
#[Out]# 0     7    Bram
#[Out]# 1    13   James
#[Out]# 2    27     Tim
#[Out]# 3    33    Sven
#[Out]# 4    38  Floris
#[Out]# 5    43     Tom
#[Out]# 6    59    Joep
#[Out]# 7    64    Stan
#[Out]# 8    68   Boris
#[Out]# 9    82   Dylan
#[Out]# 10   92   Jelte
#[Out]# 11   95    Emma
#[Out]# 12  100    Sara
#[Out]# 13  109    Lynn
#[Out]# 14  112    Yara
#[Out]# 15  116   Lieke
#[Out]# 16  123   Milou
#[Out]# 17  144     Ivy
#[Out]# 18  162   Elena
#[Out]# 19  167  Veerle
#[Out]# 20  169    Lily
# Mon, 07 Dec 2020 13:55:17
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select city
    from (
        select cId, city
        from customer c
        join (
            select sId, city
            from store s
        )
        on c.city = s.city
    )
'''

pd.read_sql_query(query4_7, conn)
# Mon, 07 Dec 2020 13:55:45
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select c.city
    from (
        select cId, city
        from customer c
        join (
            select sId, city
            from store s
        )
        on c.city = s.city
    )
'''

pd.read_sql_query(query4_7, conn)
# Mon, 07 Dec 2020 13:56:02
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select c.city
    from (
        select cId, c.city
        from customer c
        join (
            select sId, s.city
            from store s
        )
        on c.city = s.city
    )
'''

pd.read_sql_query(query4_7, conn)
# Mon, 07 Dec 2020 13:56:33
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select *
    from store
'''

pd.read_sql_query(query4_7, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     0         Coop      Kalverstraat  Amsterdam
#[Out]# 1     1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...          ...               ...        ...
#[Out]# 61   61         Lidl      Pannekoekweg      Breda
#[Out]# 62   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63        Jumbo     Stationstraat        Oss
#[Out]# 64   64  Albert Hein             test1        Oss
#[Out]# 65   65  Albert Hein             test1  Amsterdam
#[Out]# 
#[Out]# [66 rows x 4 columns]
# Mon, 07 Dec 2020 13:56:52
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select sId, city
    from store
'''

pd.read_sql_query(query4_7, conn)
#[Out]#     sID       city
#[Out]# 0     0  Amsterdam
#[Out]# 1     1      Breda
#[Out]# 2     2  Rotterdam
#[Out]# 3     3  Rotterdam
#[Out]# 4     4  Eindhoven
#[Out]# ..  ...        ...
#[Out]# 61   61      Breda
#[Out]# 62   62  Eindhoven
#[Out]# 63   63        Oss
#[Out]# 64   64        Oss
#[Out]# 65   65  Amsterdam
#[Out]# 
#[Out]# [66 rows x 2 columns]
# Mon, 07 Dec 2020 13:57:18
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select cId, city
    from customer
    join
    select sId, city
    from store
'''

pd.read_sql_query(query4_7, conn)
# Mon, 07 Dec 2020 14:01:33
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select cId, c.city, sId, s.city
    from customer c
    inner join store s
    on c.city = s.city
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID     city  sID     city
#[Out]# 0       0  Utrecht   16  Utrecht
#[Out]# 1       0  Utrecht   31  Utrecht
#[Out]# 2       0  Utrecht   32  Utrecht
#[Out]# 3       0  Utrecht   35  Utrecht
#[Out]# 4       0  Utrecht   43  Utrecht
#[Out]# ...   ...      ...  ...      ...
#[Out]# 1990  190  Utrecht   35  Utrecht
#[Out]# 1991  190  Utrecht   43  Utrecht
#[Out]# 1992  190  Utrecht   44  Utrecht
#[Out]# 1993  190  Utrecht   51  Utrecht
#[Out]# 1994  190  Utrecht   53  Utrecht
#[Out]# 
#[Out]# [1995 rows x 4 columns]
# Mon, 07 Dec 2020 14:02:35
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select city, count(*)
    from store
    group by city
'''

pd.read_sql_query(query4_7, conn)
#[Out]#         city  count(*)
#[Out]# 0  Amsterdam         9
#[Out]# 1      Breda        12
#[Out]# 2  Eindhoven        15
#[Out]# 3        Oss         2
#[Out]# 4  Rotterdam        12
#[Out]# 5    Tilburg         8
#[Out]# 6    Utrecht         8
# Mon, 07 Dec 2020 14:03:01
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select cId, c.city, sId, s.city
    from customer c
    inner join store s
    on c.city = s.city
    where city <> 'Utrecht'
    limit 10
'''

pd.read_sql_query(query4_7, conn)
# Mon, 07 Dec 2020 14:03:17
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select cId, c.city, sId, s.city
    from customer c
    inner join store s
    on c.city = s.city
    where s.city <> 'Utrecht'
    limit 10
'''

pd.read_sql_query(query4_7, conn)
#[Out]#    cID       city  sID       city
#[Out]# 0    2  Amsterdam    0  Amsterdam
#[Out]# 1    4  Amsterdam    0  Amsterdam
#[Out]# 2    9  Amsterdam    0  Amsterdam
#[Out]# 3   20  Amsterdam    0  Amsterdam
#[Out]# 4   42  Amsterdam    0  Amsterdam
#[Out]# 5   57  Amsterdam    0  Amsterdam
#[Out]# 6   59  Amsterdam    0  Amsterdam
#[Out]# 7   62  Amsterdam    0  Amsterdam
#[Out]# 8   64  Amsterdam    0  Amsterdam
#[Out]# 9   66  Amsterdam    0  Amsterdam
# Mon, 07 Dec 2020 14:03:57
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select cId, c.city, sId, s.city
    from customer c
    inner join store s
    on c.city = s.city
    where s.city <> 'Utrecht'
    and cId = 2
    limit 10
'''

pd.read_sql_query(query4_7, conn)
#[Out]#    cID       city  sID       city
#[Out]# 0    2  Amsterdam    0  Amsterdam
#[Out]# 1    2  Amsterdam   14  Amsterdam
#[Out]# 2    2  Amsterdam   15  Amsterdam
#[Out]# 3    2  Amsterdam   22  Amsterdam
#[Out]# 4    2  Amsterdam   27  Amsterdam
#[Out]# 5    2  Amsterdam   29  Amsterdam
#[Out]# 6    2  Amsterdam   34  Amsterdam
#[Out]# 7    2  Amsterdam   42  Amsterdam
#[Out]# 8    2  Amsterdam   65  Amsterdam
# Mon, 07 Dec 2020 14:05:29
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select cId, c.city, sId, s.city
    from customer c
    inner join store s
    on c.city = s.city
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID     city  sID     city
#[Out]# 0       0  Utrecht   16  Utrecht
#[Out]# 1       0  Utrecht   31  Utrecht
#[Out]# 2       0  Utrecht   32  Utrecht
#[Out]# 3       0  Utrecht   35  Utrecht
#[Out]# 4       0  Utrecht   43  Utrecht
#[Out]# ...   ...      ...  ...      ...
#[Out]# 1990  190  Utrecht   35  Utrecht
#[Out]# 1991  190  Utrecht   43  Utrecht
#[Out]# 1992  190  Utrecht   44  Utrecht
#[Out]# 1993  190  Utrecht   51  Utrecht
#[Out]# 1994  190  Utrecht   53  Utrecht
#[Out]# 
#[Out]# [1995 rows x 4 columns]
# Mon, 07 Dec 2020 14:07:05
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select distinct city
    from customer
'''

pd.read_sql_query(query4_7, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Mon, 07 Dec 2020 14:07:18
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select distinct city
    from customer
    except
    select distinct city
    from store
'''

pd.read_sql_query(query4_7, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Mon, 07 Dec 2020 14:07:24
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select distinct city
    from store
'''

pd.read_sql_query(query4_7, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Mon, 07 Dec 2020 14:07:38
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select count(*) as number_of_customers
    from customer
    union
    select count(*) as number_of_stores
    from store
'''

pd.read_sql_query(query4_7, conn)
#[Out]#    number_of_customers
#[Out]# 0                   66
#[Out]# 1                  190
# Mon, 07 Dec 2020 14:17:57
# All customers
# minus those customers that

# all customer, store combinations
# where the city of residence of the customer matches that of the store
# minus those customer store combinations where the customer made a purchase

# Thus those customer store combination in the same city where the customer never made a purchase

###
# Thus we are looking for those customers that made a purchase at every store in their city of residence #
###
query4_7 = '''
    select *
    from customer
    except
    select cId
    from customer
'''

pd.read_sql_query(query4_7, conn)
# Mon, 07 Dec 2020 14:25:01
test = '''
    select count(tId)
    from purchase
'''

pd.read_sql_query(test, conn)
#[Out]#    count(tId)
#[Out]# 0         509
# Mon, 07 Dec 2020 14:25:40
test = '''
    select tId count(*)
    from purchase
    group by tId
    having count(*) > 1
'''

pd.read_sql_query(test, conn)
# Mon, 07 Dec 2020 14:25:54
test = '''
    select tId, count(*)
    from purchase
    group by tId
    having count(*) > 1
'''

pd.read_sql_query(test, conn)
#[Out]#    tID  count(*)
#[Out]# 0  228         2
#[Out]# 1  288         2
#[Out]# 2  387         2
#[Out]# 3  393         2
#[Out]# 4  473         2
# Mon, 07 Dec 2020 14:31:23
# Comparing price to day totals
query4_4_2 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select cName
    from customer
    where cId in (
        select cId
        from purchase
        where price >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4_2, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Mon, 07 Dec 2020 14:31:54
# Comparing day totals with the max day total
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select cName
    from customer
    where cId in (
        select cId
        from cust_day_total
        where day_total >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Mon, 07 Dec 2020 14:32:01
# Comparing transaction totals to day totals
query4_4_3 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select cName
    from customer
    where cId in (
        select cId
        from purchase
        where price >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Mon, 07 Dec 2020 14:33:48
# Comparing day totals with the max day total
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(quantity * price) day_total
        from purchase
        group by cId, date)
    select cName
    from customer
    where cId in (
        select cId
        from cust_day_total
        where day_total >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Mon, 07 Dec 2020 14:35:55
# Comparing individual tuples to day totals
query4_4_2 = '''
    with cust_day_total as (
        select cId, date, sum(quantity * price) day_total
        from purchase
        group by cId, date)
    select cName
    from customer
    where cId in (
        select cId
        from purchase
        where (quantity * price) >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4_2, conn)
#[Out]#   cName
#[Out]# 0  Lynn
# Mon, 07 Dec 2020 14:39:54
# Comparing transaction totals to day totals
query4_4_3 = '''
    with cust_day_total as (
        select cId, date, sum(quantity * price) day_total
        from purchase
        group by cId, date),
        transaction_totals as (
            select tId, sum(quantity * price) transaction_total
            from purchase
            group by tId
        )
    select cName
    from customer
    where cId in (
        select cId
        from purchase p, transaction_totals tt
        where p.tId = tt.tId
        and tt.transaction_total >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4_3, conn)
#[Out]#   cName
#[Out]# 0  Lynn
# Mon, 07 Dec 2020 14:41:08
# Comparing transaction totals to day totals
q = '''
    select *
    from purchase
    where cId = (
        select cId
        from customer
        where cName = 'Lynn'
    )
'''

pd.read_sql_query(q, conn)
#[Out]#    tID  cID  sID  pID        date  quantity  price
#[Out]# 0  285  109   38    9  2018-08-20         5   1.50
#[Out]# 1  286  109   44    6  2018-08-20         4   1.05
#[Out]# 2  287  109   56   26  2018-08-21         2   3.25
#[Out]# 3  288  109    4    1  2018-08-22         5   5.70
#[Out]# 4  288  109    4   13  2018-08-22         8   4.20
#[Out]# 5  289  109   29   12  2018-08-18        11  13.65
# Mon, 07 Dec 2020 14:41:32
# Comparing transaction totals to day totals
q = '''
    select *
    from customer
    where cName = 'Lynn'
'''

pd.read_sql_query(q, conn)
#[Out]#    cID cName         street   city
#[Out]# 0  109  Lynn  Stationsplein  Breda
# Mon, 07 Dec 2020 14:41:45
# Comparing transaction totals to day totals
q = '''
    select *
    from purchase
    where cId = (
        select cId
        from customer
        where cName = 'Lynn'
    )
'''

pd.read_sql_query(q, conn)
#[Out]#    tID  cID  sID  pID        date  quantity  price
#[Out]# 0  285  109   38    9  2018-08-20         5   1.50
#[Out]# 1  286  109   44    6  2018-08-20         4   1.05
#[Out]# 2  287  109   56   26  2018-08-21         2   3.25
#[Out]# 3  288  109    4    1  2018-08-22         5   5.70
#[Out]# 4  288  109    4   13  2018-08-22         8   4.20
#[Out]# 5  289  109   29   12  2018-08-18        11  13.65
# Mon, 07 Dec 2020 14:42:53
q = '''
    with cust_day_total as (
        select cId, date, sum(quantity * price) day_total
        from purchase
        group by cId, date)
    select max(day_total)
    from cust_day_total
'''
pd.read_sql_query(q, conn)
#[Out]#    max(day_total)
#[Out]# 0          171.25
# Mon, 07 Dec 2020 14:44:04
# Comparing transaction totals to day totals
q = '''
    select cID, tID, sum(quantity * price) t_total 
    from purchase
    where cId = (
        select cId
        from customer
        where cName = 'Lynn'
    )
    group by cId, tId
'''

pd.read_sql_query(q, conn)
#[Out]#    cID  tID  t_total
#[Out]# 0  109  285     7.50
#[Out]# 1  109  286     4.20
#[Out]# 2  109  287     6.50
#[Out]# 3  109  288    62.10
#[Out]# 4  109  289   150.15
# Mon, 07 Dec 2020 14:44:59
q = '''
    150.15 / 171.25
'''
pd.read_sql_query(q, conn)
# Mon, 07 Dec 2020 14:45:30
print(150.15 / 171.25)
# Mon, 07 Dec 2020 14:46:17
# Comparing transaction totals to day totals
q = '''
    select *
    from purchase
    where cId = (
        select cId
        from customer
        where cName = 'Lynn'
    )
'''

pd.read_sql_query(q, conn)
#[Out]#    tID  cID  sID  pID        date  quantity  price
#[Out]# 0  285  109   38    9  2018-08-20         5   1.50
#[Out]# 1  286  109   44    6  2018-08-20         4   1.05
#[Out]# 2  287  109   56   26  2018-08-21         2   3.25
#[Out]# 3  288  109    4    1  2018-08-22         5   5.70
#[Out]# 4  288  109    4   13  2018-08-22         8   4.20
#[Out]# 5  289  109   29   12  2018-08-18        11  13.65
# Mon, 07 Dec 2020 14:49:36
q = '''    
    with cust_day_total as (
        select cId, date, sum(quantity * price) day_total
        from purchase
        group by cId, date)
    select *
    from cust_day_total
'''
pd.read_sql_query(q, conn)
#[Out]#      cId        date  day_total
#[Out]# 0      0  2018-08-22       0.45
#[Out]# 1      1  2018-08-20      43.40
#[Out]# 2      1  2018-08-21      61.80
#[Out]# 3      2  2018-08-16       2.45
#[Out]# 4      2  2018-08-17      32.40
#[Out]# ..   ...         ...        ...
#[Out]# 280  190  2018-08-23      52.85
#[Out]# 281  190  2018-08-24      18.10
#[Out]# 282  190  2018-08-25      46.20
#[Out]# 283  190  2018-08-26      89.55
#[Out]# 284  190  2018-08-27      32.10
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Mon, 07 Dec 2020 14:49:48
q = '''    
    with cust_day_total as (
        select cId, date, sum(quantity * price) day_total
        from purchase
        group by cId, date)
    select *
    from cust_day_total
    order by day_total desc
'''
pd.read_sql_query(q, conn)
#[Out]#      cId        date  day_total
#[Out]# 0    161  2018-08-26     171.25
#[Out]# 1    109  2018-08-18     150.15
#[Out]# 2     71  2018-08-24     145.00
#[Out]# 3     33  2018-08-27     138.90
#[Out]# 4    124  2018-08-26     134.90
#[Out]# ..   ...         ...        ...
#[Out]# 280  185  2018-08-20       1.00
#[Out]# 281  188  2018-08-20       1.00
#[Out]# 282  188  2018-09-20       1.00
#[Out]# 283   85  2018-08-18       0.85
#[Out]# 284    0  2018-08-22       0.45
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Mon, 07 Dec 2020 14:50:28
# Comparing transaction totals to day totals
query4_4_3 = '''
    with cust_day_total as (
        select cId, date, sum(quantity * price) day_total
        from purchase
        group by cId, date),
        transaction_totals as (
            select tId, sum(quantity * price) transaction_total
            from purchase
            group by tId)
    select cName
    from customer
    where cId in (
        select cId
        from purchase p, transaction_totals tt
        where p.tId = tt.tId
        and tt.transaction_total >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4_3, conn)
#[Out]#   cName
#[Out]# 0  Lynn
# Mon, 07 Dec 2020 16:58:27
# Comparing day totals with the max day total
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(quantity * price) day_total
        from purchase
        group by cId, date)
    select cName
    from customer
    where cId in (
        select cId
        from cust_day_total
        where day_total >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor

# IPython log file

# Mon, 07 Dec 2020 17:00:49
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 17:19:47
# exclude those sl tuples for which no purchases were made
# that means we have sl tuples for which at least one result exists

# exclude those users that made a purchase for a product that was on their sl on some date
q1_a = '''
    with list_no_purchase(cId, date) as (
        select sl.cId, sl.date 
        from shoppinglist sl
        where (sl.cId, sl.date) not in (
            select cId, date
            from purchase
        )
    ),
    list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    )
    select cId, cName
    from customer
    where cId in (
        select cId
        from purchase
        where (cId, date) not in (
            select *
            from list_same_prod_purchased
        )
    )
'''

pd.read_sql_query(q1_a, conn)
#[Out]#     cID   cName
#[Out]# 0     0    Noah
#[Out]# 1     4    Daan
#[Out]# 2     7    Bram
#[Out]# 3    13   James
#[Out]# 4    16  Julian
#[Out]# ..  ...     ...
#[Out]# 67  185    Nick
#[Out]# 68  186  Angela
#[Out]# 69  188    Pino
#[Out]# 70  189    Koen
#[Out]# 71  190  Kostas
#[Out]# 
#[Out]# [72 rows x 2 columns]
# Mon, 07 Dec 2020 17:25:09
# But perhaps purchases for which no shoppinglist exists
# should be excluded aswell.
q1_a = '''
    with list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    ),
    missing_sl(cId, date) as (
        select cId, date
        from purchase
        where (cId, date) not in (
            select cId, date
            from shoppinglist 
        )
    )
    select cId, cName
    from customer
    where cId in (
        select cId
        from purchase
        where (cId, date) not in (
            select *
            from list_same_prod_purchased
            union
            select *
            from missing_sl
        )
    )
'''

pd.read_sql_query(q1_a, conn)
#[Out]#     cID   cName
#[Out]# 0     7    Bram
#[Out]# 1    13   James
#[Out]# 2    27     Tim
#[Out]# 3    33    Sven
#[Out]# 4    38  Floris
#[Out]# 5    43     Tom
#[Out]# 6    59    Joep
#[Out]# 7    64    Stan
#[Out]# 8    68   Boris
#[Out]# 9    82   Dylan
#[Out]# 10   92   Jelte
#[Out]# 11   95    Emma
#[Out]# 12  100    Sara
#[Out]# 13  109    Lynn
#[Out]# 14  112    Yara
#[Out]# 15  116   Lieke
#[Out]# 16  123   Milou
#[Out]# 17  144     Ivy
#[Out]# 18  162   Elena
#[Out]# 19  167  Veerle
#[Out]# 20  169    Lily
# Mon, 07 Dec 2020 17:26:49
q1_c = '''
    missing_sl(cId, date) as (
        select cId, date
        from purchase
        where (cId, date) not in (
            select cId, date
            from shoppinglist 
        )
    )
'''

pd.read_sql_query(q1_c, conn)
# Mon, 07 Dec 2020 17:26:58
q1_c = '''
        select cId, date
        from purchase
        where (cId, date) not in (
            select cId, date
            from shoppinglist 
        )
'''

pd.read_sql_query(q1_c, conn)
#[Out]#      cID        date
#[Out]# 0      0  2018-08-22
#[Out]# 1      4  2018-08-24
#[Out]# 2      4  2018-08-24
#[Out]# 3      4  2018-08-25
#[Out]# 4      4  2018-08-24
#[Out]# ..   ...         ...
#[Out]# 165  190  2018-08-26
#[Out]# 166  190  2018-08-27
#[Out]# 167  190  2018-08-23
#[Out]# 168  190  2018-08-16
#[Out]# 169  190  2018-08-21
#[Out]# 
#[Out]# [170 rows x 2 columns]
# Mon, 07 Dec 2020 17:27:52
q1_c = '''
            select cId, date
            from shoppinglist
            where cId = 0
            and date = '2018-08-22'
'''

pd.read_sql_query(q1_c, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date]
#[Out]# Index: []
# Tue, 08 Dec 2020 12:06:17
# Exclude if one witness for sl.cId, pId, date matches purchase
q1_b = '''
    select *
    from purchase p
    where exists (
        select 1
        from shoppinglist sl
        where p.cId = sl.cId
        and p.pId = sl.pId
        and p.date = sl.date
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      1    1   23   14  2018-08-20         2   4.65
#[Out]# 1      2    1    3   16  2018-08-20         3   1.60
#[Out]# 2      3    1   17    9  2018-08-20         2   1.25
#[Out]# 3      4    1   32   25  2018-08-20         4   3.95
#[Out]# 4      5    1   16   26  2018-08-20         4   2.75
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 249  466  180   34   26  2018-08-26         3   3.10
#[Out]# 250  468  180   56   10  2018-08-27         3   0.60
#[Out]# 251  469  181    6   26  2018-08-24         4   2.70
#[Out]# 252  470  181   45    6  2018-08-24         3   0.90
#[Out]# 253  471  181   27   21  2018-08-27         5   2.00
#[Out]# 
#[Out]# [254 rows x 7 columns]
# Tue, 08 Dec 2020 12:06:59
# Exclude if one witness for sl.cId, pId, date matches purchase
q1_b = '''
    select cId, cName
    from customer 
    where cId not in (
        select cId
        from purchase p
        where exists (
            select 1
            from shoppinglist sl
            where p.cId = sl.cId
            and p.pId = sl.pId
            and p.date = sl.date
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID   cName
#[Out]# 0     0    Noah
#[Out]# 1     4    Daan
#[Out]# 2     6   Milan
#[Out]# 3     9  Thomas
#[Out]# 4    12    Adam
#[Out]# ..  ...     ...
#[Out]# 86  185    Nick
#[Out]# 87  186  Angela
#[Out]# 88  188    Pino
#[Out]# 89  189    Koen
#[Out]# 90  190  Kostas
#[Out]# 
#[Out]# [91 rows x 2 columns]
# Tue, 08 Dec 2020 12:07:57
# Exclude if one witness for sl.cId, pId, date matches purchase
q1_b = '''
    select count(distinct cId)
    from shoppinglist
'''

pd.read_sql_query(q1_b, conn)
#[Out]#    count(distinct cId)
#[Out]# 0                  133
# Tue, 08 Dec 2020 12:08:30
# Exclude if one witness for sl.cId, pId, date matches purchase
q1_b = '''
    select count(*)
    from customer
    union
    select count(distinct cId)
    from shoppinglist
'''

pd.read_sql_query(q1_b, conn)
#[Out]#    count(*)
#[Out]# 0       133
#[Out]# 1       190
# Tue, 08 Dec 2020 12:09:01
# Exclude if one witness for sl.cId, pId, date matches purchase
q1_b = '''
    select cId, cName
    from customer 
    where cId not in (
        select cId
        from purchase p
        where exists (
            select 1
            from shoppinglist sl
            where p.cId = sl.cId
            and p.pId = sl.pId
            and p.date = sl.date
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID   cName
#[Out]# 0     0    Noah
#[Out]# 1     4    Daan
#[Out]# 2     6   Milan
#[Out]# 3     9  Thomas
#[Out]# 4    12    Adam
#[Out]# ..  ...     ...
#[Out]# 86  185    Nick
#[Out]# 87  186  Angela
#[Out]# 88  188    Pino
#[Out]# 89  189    Koen
#[Out]# 90  190  Kostas
#[Out]# 
#[Out]# [91 rows x 2 columns]
# Tue, 08 Dec 2020 12:15:42
# 
q1_b = '''
    select cId, cName
    from customer 
        where cId in (
        select cId
        from shoppinglist
            where cId in (
            select cId
            from purchase 
            where cId not in (
                select cId
                from purchase p
                where exists (
                    select 1
                    from shoppinglist sl
                    where p.cId = sl.cId
                    and p.pId = sl.pId
                    and p.date = sl.date
                )
            )
        )
    )
'''

pd.read_sql_query(q1_b, conn)
#[Out]#     cID   cName
#[Out]# 0    25   Mason
#[Out]# 1    38  Floris
#[Out]# 2    58   Jurre
#[Out]# 3    64    Stan
#[Out]# 4    68   Boris
#[Out]# 5    80    Niek
#[Out]# 6    88   Joris
#[Out]# 7    99    Anna
#[Out]# 8   103   Lotte
#[Out]# 9   116   Lieke
#[Out]# 10  131     Amy
#[Out]# 11  136   Femke
#[Out]# 12  144     Ivy
# Tue, 08 Dec 2020 12:33:35
q1_c = '''
    select cId, pId, date
    from purchase
    except
    select cId, pId, date
    from shoppinglist sl
'''

pd.read_sql_query(q1_c, conn)
#[Out]#      cID  pID        date
#[Out]# 0      0   10  2018-08-22
#[Out]# 1      1   11  2018-08-21
#[Out]# 2      2    9  2018-08-17
#[Out]# 3      3   26  2018-08-19
#[Out]# 4      4    6  2018-08-24
#[Out]# ..   ...  ...         ...
#[Out]# 240  190   27  2018-08-19
#[Out]# 241  190   27  2018-08-21
#[Out]# 242  190   28  2018-08-15
#[Out]# 243  190   28  2018-08-20
#[Out]# 244  190   28  2018-08-23
#[Out]# 
#[Out]# [245 rows x 3 columns]
# Tue, 08 Dec 2020 12:33:59
q1_c = '''
    select cId
    from (
    select cId, pId, date
    from purchase
    except
    select cId, pId, date
    from shoppinglist sl)
'''

pd.read_sql_query(q1_c, conn)
#[Out]#      cId
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 240  190
#[Out]# 241  190
#[Out]# 242  190
#[Out]# 243  190
#[Out]# 244  190
#[Out]# 
#[Out]# [245 rows x 1 columns]
# Tue, 08 Dec 2020 12:35:21
q1_c = '''
    select cid, cname
    from customer
    where cid in (
        select cId
        from purchase
        where cId not in (
            select cId
            from (
                select cId, pId, date
                from purchase
                except
                select cId, pId, date
                from shoppinglist sl
            )
        )
    )
'''

pd.read_sql_query(q1_c, conn)
#[Out]#     cID      cName
#[Out]# 0    10        Sam
#[Out]# 1    11      Thijs
#[Out]# 2    15       Noud
#[Out]# 3    17        Dex
#[Out]# 4    26     Jayden
#[Out]# 5    28       Siem
#[Out]# 6    30       Teun
#[Out]# 7    34      David
#[Out]# 8    37       Guus
#[Out]# 9    41      Quinn
#[Out]# 10   42       Tijn
#[Out]# 11   47       Xavi
#[Out]# 12   63       Senn
#[Out]# 13   67      Rayan
#[Out]# 14   70        Kai
#[Out]# 15   71       Dean
#[Out]# 16   76  Alexander
#[Out]# 17   77      Hidde
#[Out]# 18   90       Lenn
#[Out]# 19  104        Liv
#[Out]# 20  108       Noor
#[Out]# 21  111     Lauren
#[Out]# 22  113      Fenna
#[Out]# 23  122       Elin
#[Out]# 24  124      Sofie
#[Out]# 25  128    Jasmijn
#[Out]# 26  133     Sophia
#[Out]# 27  137       Lena
#[Out]# 28  145       Fien
#[Out]# 29  151       Jill
#[Out]# 30  163       Cato
#[Out]# 31  168       Kiki
#[Out]# 32  170       Iris
#[Out]# 33  171      Tessa
#[Out]# 34  172       Lana
#[Out]# 35  178       Elif
#[Out]# 36  181       Liva
# Tue, 08 Dec 2020 12:35:47
q1_c = '''
    select cId, cName
    from customer 
        where cId in (
        select cId
        from shoppinglist
            where cId in (
            select cId
            from purchase 
            where cId not in (
                select cId
                from purchase p
                where exists (
                    select 1
                    from shoppinglist sl
                    where p.cId = sl.cId
                    and p.pId = sl.pId
                    and p.date = sl.date
                )
            )
        )
    )
    intersect
    select cid, cname
    from customer
    where cid in (
        select cId
        from purchase
        where cId not in (
            select cId
            from (
                select cId, pId, date
                from purchase
                except
                select cId, pId, date
                from shoppinglist sl
            )
        )
    )
'''

pd.read_sql_query(q1_c, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 08 Dec 2020 12:35:57
q1_c = '''
    select cid, cname
    from customer
    where cid in (
        select cId
        from purchase
        where cId not in (
            select cId
            from (
                select cId, pId, date
                from purchase
                except
                select cId, pId, date
                from shoppinglist sl
            )
        )
    )
'''

pd.read_sql_query(q1_c, conn)
#[Out]#     cID      cName
#[Out]# 0    10        Sam
#[Out]# 1    11      Thijs
#[Out]# 2    15       Noud
#[Out]# 3    17        Dex
#[Out]# 4    26     Jayden
#[Out]# 5    28       Siem
#[Out]# 6    30       Teun
#[Out]# 7    34      David
#[Out]# 8    37       Guus
#[Out]# 9    41      Quinn
#[Out]# 10   42       Tijn
#[Out]# 11   47       Xavi
#[Out]# 12   63       Senn
#[Out]# 13   67      Rayan
#[Out]# 14   70        Kai
#[Out]# 15   71       Dean
#[Out]# 16   76  Alexander
#[Out]# 17   77      Hidde
#[Out]# 18   90       Lenn
#[Out]# 19  104        Liv
#[Out]# 20  108       Noor
#[Out]# 21  111     Lauren
#[Out]# 22  113      Fenna
#[Out]# 23  122       Elin
#[Out]# 24  124      Sofie
#[Out]# 25  128    Jasmijn
#[Out]# 26  133     Sophia
#[Out]# 27  137       Lena
#[Out]# 28  145       Fien
#[Out]# 29  151       Jill
#[Out]# 30  163       Cato
#[Out]# 31  168       Kiki
#[Out]# 32  170       Iris
#[Out]# 33  171      Tessa
#[Out]# 34  172       Lana
#[Out]# 35  178       Elif
#[Out]# 36  181       Liva

# IPython log file

# Tue, 08 Dec 2020 12:44:11
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 12:53:36
# 
q1_a = '''
    select cid, cname
    from customer
    where cid in (
        select cid
        from shoppinglist
        where (cid, date) in (
            select cid, date 
            from purchase
            where (cid, date) not in (
                select cid, date
                from shoppinglist sl, purchase p
                where sl.cid = p.cid
                and sl.pid = p.pid
                and sl.date = p.date
            )
        )
    )
'''

pd.read_sql_query(q1_a, conn)
# Tue, 08 Dec 2020 12:54:04
# 
q1_a = '''
    select cid, cname
    from customer
    where cid in (
        select cid
        from shoppinglist
        where (cid, date) in (
            select cid, date 
            from purchase
            where (cid, date) not in (
                select p.cid, p.date
                from shoppinglist sl, purchase p
                where sl.cid = p.cid
                and sl.pid = p.pid
                and sl.date = p.date
            )
        )
    )
'''

pd.read_sql_query(q1_a, conn)
#[Out]#     cID   cName
#[Out]# 0     7    Bram
#[Out]# 1    13   James
#[Out]# 2    27     Tim
#[Out]# 3    33    Sven
#[Out]# 4    38  Floris
#[Out]# 5    43     Tom
#[Out]# 6    59    Joep
#[Out]# 7    64    Stan
#[Out]# 8    68   Boris
#[Out]# 9    82   Dylan
#[Out]# 10   92   Jelte
#[Out]# 11   95    Emma
#[Out]# 12  100    Sara
#[Out]# 13  109    Lynn
#[Out]# 14  112    Yara
#[Out]# 15  116   Lieke
#[Out]# 16  123   Milou
#[Out]# 17  144     Ivy
#[Out]# 18  162   Elena
#[Out]# 19  167  Veerle
#[Out]# 20  169    Lily
# Tue, 08 Dec 2020 12:54:46
lol = '''    with list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    ),
    missing_sl(cId, date) as (
        select cId, date
        from purchase
        where (cId, date) not in (
            select cId, date
            from shoppinglist 
        )
    )
    select cId, cName
    from customer
    where cId in (
        select cId
        from purchase
        where (cId, date) not in (
            select *
            from list_same_prod_purchased
            union
            select *
            from missing_sl
        )
    )'''
pd.read_sql_query(lol, conn)
#[Out]#     cID   cName
#[Out]# 0     7    Bram
#[Out]# 1    13   James
#[Out]# 2    27     Tim
#[Out]# 3    33    Sven
#[Out]# 4    38  Floris
#[Out]# 5    43     Tom
#[Out]# 6    59    Joep
#[Out]# 7    64    Stan
#[Out]# 8    68   Boris
#[Out]# 9    82   Dylan
#[Out]# 10   92   Jelte
#[Out]# 11   95    Emma
#[Out]# 12  100    Sara
#[Out]# 13  109    Lynn
#[Out]# 14  112    Yara
#[Out]# 15  116   Lieke
#[Out]# 16  123   Milou
#[Out]# 17  144     Ivy
#[Out]# 18  162   Elena
#[Out]# 19  167  Veerle
#[Out]# 20  169    Lily
# Tue, 08 Dec 2020 12:55:21
# 
q1_a = '''
    with list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    ),
    missing_sl(cId, date) as (
        select cId, date
        from purchase
        where (cId, date) not in (
            select cId, date
            from shoppinglist 
        )
    )
    select cId, cName
    from customer
    where cId in (
        select cId
        from purchase
        where (cId, date) not in (
            select *
            from list_same_prod_purchased
            union
            select *
            from missing_sl
        )
    )
    except
    select cid, cname
    from customer
    where cid in (
        select cid
        from shoppinglist
        where (cid, date) in (
            select cid, date 
            from purchase
            where (cid, date) not in (
                select p.cid, p.date
                from shoppinglist sl, purchase p
                where sl.cid = p.cid
                and sl.pid = p.pid
                and sl.date = p.date
            )
        )
    )
'''

pd.read_sql_query(q1_a, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName]
#[Out]# Index: []
# Tue, 08 Dec 2020 12:55:30
# 
q1_a = '''
    with list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    ),
    missing_sl(cId, date) as (
        select cId, date
        from purchase
        where (cId, date) not in (
            select cId, date
            from shoppinglist 
        )
    )
    select cId, cName
    from customer
    where cId in (
        select cId
        from purchase
        where (cId, date) not in (
            select *
            from list_same_prod_purchased
            union
            select *
            from missing_sl
        )
    )
    intersect
    select cid, cname
    from customer
    where cid in (
        select cid
        from shoppinglist
        where (cid, date) in (
            select cid, date 
            from purchase
            where (cid, date) not in (
                select p.cid, p.date
                from shoppinglist sl, purchase p
                where sl.cid = p.cid
                and sl.pid = p.pid
                and sl.date = p.date
            )
        )
    )
'''

pd.read_sql_query(q1_a, conn)
#[Out]#     cID   cName
#[Out]# 0     7    Bram
#[Out]# 1    13   James
#[Out]# 2    27     Tim
#[Out]# 3    33    Sven
#[Out]# 4    38  Floris
#[Out]# 5    43     Tom
#[Out]# 6    59    Joep
#[Out]# 7    64    Stan
#[Out]# 8    68   Boris
#[Out]# 9    82   Dylan
#[Out]# 10   92   Jelte
#[Out]# 11   95    Emma
#[Out]# 12  100    Sara
#[Out]# 13  109    Lynn
#[Out]# 14  112    Yara
#[Out]# 15  116   Lieke
#[Out]# 16  123   Milou
#[Out]# 17  144     Ivy
#[Out]# 18  162   Elena
#[Out]# 19  167  Veerle
#[Out]# 20  169    Lily
# Tue, 08 Dec 2020 12:56:00
q_1_a_alternative_lol = '''    
    with list_same_prod_purchased(cId, date) as (
        select sl.cId, sl.date
        from shoppinglist sl, purchase p
        where sl.cId = p.cId
        and sl.date = p.date
        and sl.pId = p.pId
    ),
    missing_sl(cId, date) as (
        select cId, date
        from purchase
        where (cId, date) not in (
            select cId, date
            from shoppinglist 
        )
    )
    select cId, cName
    from customer
    where cId in (
        select cId
        from purchase
        where (cId, date) not in (
            select *
            from list_same_prod_purchased
            union
            select *
            from missing_sl
        )
    )
'''
pd.read_sql_query(lol, conn)
#[Out]#     cID   cName
#[Out]# 0     7    Bram
#[Out]# 1    13   James
#[Out]# 2    27     Tim
#[Out]# 3    33    Sven
#[Out]# 4    38  Floris
#[Out]# 5    43     Tom
#[Out]# 6    59    Joep
#[Out]# 7    64    Stan
#[Out]# 8    68   Boris
#[Out]# 9    82   Dylan
#[Out]# 10   92   Jelte
#[Out]# 11   95    Emma
#[Out]# 12  100    Sara
#[Out]# 13  109    Lynn
#[Out]# 14  112    Yara
#[Out]# 15  116   Lieke
#[Out]# 16  123   Milou
#[Out]# 17  144     Ivy
#[Out]# 18  162   Elena
#[Out]# 19  167  Veerle
#[Out]# 20  169    Lily
# Tue, 08 Dec 2020 14:15:06
q1_d = '''
    select *
    from product
    where lower(pname) = 'kelloggs rice crispies'
'''

pd.read_sql_query(q1_d, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [pID, pName, suffix]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:15:26
q1_d = '''
    select *
    from product
    where lower(pname) like '%kelloggs%'
'''

pd.read_sql_query(q1_d, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [pID, pName, suffix]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:15:33
q1_d = '''
    select *
    from product
'''

pd.read_sql_query(q1_d, conn)
#[Out]#     pID             pName suffix
#[Out]# 0     0       Cashew Nuts       
#[Out]# 1     1        Mixed Nuts       
#[Out]# 2     2          Potatoes       
#[Out]# 3     3      Green Pepper       
#[Out]# 4     4            Onions       
#[Out]# 5     5         Mushrooms       
#[Out]# 6     6           Carrots       
#[Out]# 7     7          Tomatoes       
#[Out]# 8     8  Hot Dog Sausages       
#[Out]# 9     9           Bananas       
#[Out]# 10   10             Water       
#[Out]# 11   11              Milk       
#[Out]# 12   12              Beef       
#[Out]# 13   13              Eggs       
#[Out]# 14   14            Apples       
#[Out]# 15   15         Cucumbers       
#[Out]# 16   16              Rice       
#[Out]# 17   17             Bread       
#[Out]# 18   18            Cheese       
#[Out]# 19   19              Coca       
#[Out]# 20   20             Fanta       
#[Out]# 21   21            Coffee       
#[Out]# 22   22               Tea       
#[Out]# 23   23   Spiced Biscuits       
#[Out]# 24   24           Oranges       
#[Out]# 25   25            Donuts       
#[Out]# 26   26             Pasta       
#[Out]# 27   27             Pizza       
#[Out]# 28   28           Lasanga       
#[Out]# 29   29            Salmon       
#[Out]# 30   30           Ketchup       
#[Out]# 31   31   French baguette       
# Tue, 08 Dec 2020 14:16:23
q1_d = '''
    select *
    from product
    where lower(pname) = 'potatoes'
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    pID     pName suffix
#[Out]# 0    2  Potatoes       
# Tue, 08 Dec 2020 14:19:33
# pname is not unique so we might have to sum
# the quantities for that date.
q1_d = '''
    select *
    from inventory
    where date = '2016-12-10'
    and quantity = (
        select max(quantity)
        from inventory 
        where date = '2016-12-10'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, pID, date, quantity, unit_price]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:21:00
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select *
    from inventory
    where pid in (
        select pId
        from product
        where lower(pname) = 'potatoes'
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#     sID  pID        date  quantity  unit_price
#[Out]# 0    57    2  2018-08-22        24        2.05
#[Out]# 1    32    2  2018-08-15        22        2.35
#[Out]# 2    23    2  2018-08-20        28        1.80
#[Out]# 3     0    2  2018-08-20        11        2.20
#[Out]# 4    59    2  2018-08-18        52        1.65
#[Out]# 5     1    2  2018-08-20         2        1.75
#[Out]# 6    11    2  2018-08-23        22        2.10
#[Out]# 7     0    2  2018-08-21        43        2.15
#[Out]# 8    43    2  2018-08-20        16        2.10
#[Out]# 9    15    2  2018-08-16        51        2.35
#[Out]# 10   18    2  2018-08-25        37        2.00
#[Out]# 11   46    2  2018-08-22        19        1.80
#[Out]# 12   29    2  2018-08-20        50        2.00
#[Out]# 13    8    2  2018-08-24         9        1.70
#[Out]# 14   24    2  2018-08-21        52        1.65
#[Out]# 15   44    2  2018-08-21        45        1.80
#[Out]# 16   12    2  2018-08-23         3        1.70
#[Out]# 17   47    2  2018-08-26        14        1.65
#[Out]# 18   34    2  2018-08-16         6        2.30
#[Out]# 19   37    2  2018-08-18         1        2.25
#[Out]# 20   47    2  2018-08-27         5        2.00
#[Out]# 21   26    2  2018-08-25        23        1.95
#[Out]# 22    0    2  2018-08-25         4        1.70
#[Out]# 23   57    2  2018-08-18         2        2.30
# Tue, 08 Dec 2020 14:22:01
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select date, count(*)
    from inventory
    where pid in (
        select pId
        from product
        where lower(pname) = 'potatoes'
    )
    group by date

'''

pd.read_sql_query(q1_d, conn)
#[Out]#           date  count(*)
#[Out]# 0   2018-08-15         1
#[Out]# 1   2018-08-16         2
#[Out]# 2   2018-08-18         3
#[Out]# 3   2018-08-20         5
#[Out]# 4   2018-08-21         3
#[Out]# 5   2018-08-22         2
#[Out]# 6   2018-08-23         2
#[Out]# 7   2018-08-24         1
#[Out]# 8   2018-08-25         3
#[Out]# 9   2018-08-26         1
#[Out]# 10  2018-08-27         1
# Tue, 08 Dec 2020 14:22:35
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select date, count(*)
    from inventory
    where pid in (
        select pId
        from product
        where lower(pname) = 'potatoes'
    )
    group by date
    select *
    from inventory
    where date = '2018-08-20'
    and quantity = (
        select max(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
    )
'''

pd.read_sql_query(q1_d, conn)
# Tue, 08 Dec 2020 14:22:40
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select *
    from inventory
    where date = '2018-08-20'
    and quantity = (
        select max(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sID  pID        date  quantity  unit_price
#[Out]# 0   29    2  2018-08-20        50           2
# Tue, 08 Dec 2020 14:23:31
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select *
    from inventory
    where pid = 2
    and date = '2018-08-20'
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sID  pID        date  quantity  unit_price
#[Out]# 0   23    2  2018-08-20        28        1.80
#[Out]# 1    0    2  2018-08-20        11        2.20
#[Out]# 2    1    2  2018-08-20         2        1.75
#[Out]# 3   43    2  2018-08-20        16        2.10
#[Out]# 4   29    2  2018-08-20        50        2.00
# Tue, 08 Dec 2020 14:24:18
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName 'potatoes', convert back to date in exercise and productname
q1_d = '''
    select *
    from inventory
    where date = '2018-08-20'
    and quantity = (
        select max(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid in (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sID  pID        date  quantity  unit_price
#[Out]# 0   29    2  2018-08-20        50           2
# Tue, 08 Dec 2020 14:25:06
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName 'potatoes', convert back to date in exercise and productname
q1_d = '''
    select *
    from inventory
    where date = '2018-08-20'
    and quantity = (
        select max(sum(quantity))
        from inventory 
        where date = '2018-08-20'
        and pid in (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
'''

pd.read_sql_query(q1_d, conn)
# Tue, 08 Dec 2020 14:25:42
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName 'potatoes', convert back to date in exercise and productname
q1_d = '''
    select *
    from inventory
    where date = '2018-08-20'
    and quantity = (
        select sid, sum(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid in (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
'''

pd.read_sql_query(q1_d, conn)
# Tue, 08 Dec 2020 14:25:44
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName 'potatoes', convert back to date in exercise and productname
q1_d = '''
    select *
    from inventory
    where date = '2018-08-20'
    and quantity = (
        select sid, sum(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid in (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
'''

pd.read_sql_query(q1_d, conn)
# Tue, 08 Dec 2020 14:26:57
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select *
    from inventory
    where date = '2018-08-20'
    and quantity = (
        select max(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sID  pID        date  quantity  unit_price
#[Out]# 0   29    2  2018-08-20        50           2
# Tue, 08 Dec 2020 14:27:25
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select max(quantity)
    from inventory 
    where date = '2018-08-20'
    and pid = (
        select pid
        from product
        where lower(pname) = 'potatoes'
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    max(quantity)
#[Out]# 0             50
# Tue, 08 Dec 2020 14:27:31
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select max(sum(quantity))
    from inventory 
    where date = '2018-08-20'
    and pid = (
        select pid
        from product
        where lower(pname) = 'potatoes'
    )
'''

pd.read_sql_query(q1_d, conn)
# Tue, 08 Dec 2020 14:27:40
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select max(sum(quantity))
    from inventory 
    where date = '2018-08-20'
    and pid = (
        select pid
        from product
        where lower(pname) = 'potatoes'
    )
    group by sId
'''

pd.read_sql_query(q1_d, conn)
# Tue, 08 Dec 2020 14:27:49
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select sum(quantity)
    from inventory 
    where date = '2018-08-20'
    and pid = (
        select pid
        from product
        where lower(pname) = 'potatoes'
    )
    group by sid
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sum(quantity)
#[Out]# 0             11
#[Out]# 1              2
#[Out]# 2             28
#[Out]# 3             50
#[Out]# 4             16
# Tue, 08 Dec 2020 14:27:57
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select sid, sum(quantity)
    from inventory 
    where date = '2018-08-20'
    and pid = (
        select pid
        from product
        where lower(pname) = 'potatoes'
    )
    group by sid
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sID  sum(quantity)
#[Out]# 0    0             11
#[Out]# 1    1              2
#[Out]# 2   23             28
#[Out]# 3   29             50
#[Out]# 4   43             16
# Tue, 08 Dec 2020 14:28:36
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select max(sum(quantity))
    from inventory 
    where date = '2018-08-20'
    and pid = (
        select pid
        from product
        where lower(pname) = 'potatoes'
    )
    group by sid
'''

pd.read_sql_query(q1_d, conn)
# Tue, 08 Dec 2020 14:29:22
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select *
    from (select sid, sum(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sid  sum(quantity)
#[Out]# 0    0             11
#[Out]# 1    1              2
#[Out]# 2   23             28
#[Out]# 3   29             50
#[Out]# 4   43             16
# Tue, 08 Dec 2020 14:29:31
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select *
    from (select sid, sum(quantity) as total_qty
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sid  total_qty
#[Out]# 0    0         11
#[Out]# 1    1          2
#[Out]# 2   23         28
#[Out]# 3   29         50
#[Out]# 4   43         16
# Tue, 08 Dec 2020 14:29:35
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select total_qty
    from (select sid, sum(quantity) as total_qty
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    total_qty
#[Out]# 0         11
#[Out]# 1          2
#[Out]# 2         28
#[Out]# 3         50
#[Out]# 4         16
# Tue, 08 Dec 2020 14:29:39
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select *
    from (select sid, sum(quantity) as total_qty
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sid  total_qty
#[Out]# 0    0         11
#[Out]# 1    1          2
#[Out]# 2   23         28
#[Out]# 3   29         50
#[Out]# 4   43         16
# Tue, 08 Dec 2020 14:30:01
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select max(total_qty)
    from (
        select sid, sum(quantity) as total_qty
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    max(total_qty)
#[Out]# 0              50
# Tue, 08 Dec 2020 14:30:09
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    select max(total_qty) max_inventory
    from (
        select sid, sum(quantity) as total_qty
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    max_inventory
#[Out]# 0             50
# Tue, 08 Dec 2020 14:31:46
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    with product_inventory(sid, total_qty) as (
        select sid, sum(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
    
    select max(product_inventory.total_qty) max_inventory
    from product_inventory
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    max_inventory
#[Out]# 0             50
# Tue, 08 Dec 2020 14:32:32
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    with product_inventory(sid, total_qty) as (
        select sid, sum(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
    
    select sid
    from product_inventory
    where total_qty = (
        select max(product_inventory.total_qty) max_inventory
        from product_inventory
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sid
#[Out]# 0   29
# Tue, 08 Dec 2020 14:33:02
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName, convert back to date in exercise and productname
q1_d = '''
    with product_inventory(sid, total_qty) as (
        select sid, sum(quantity)
        from inventory 
        where date = '2018-08-20'
        and pid = (
            select pid
            from product
            where lower(pname) = 'potatoes'
        )
        group by sid
    )
    
    select sid, sName
    from store
    where sid in (
        select sid
        from product_inventory
        where total_qty = (
            select max(product_inventory.total_qty) max_inventory
            from product_inventory
        )
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]#    sID   sName
#[Out]# 0   29  Sligro
# Tue, 08 Dec 2020 14:33:43
# pname is not unique so we might have to sum
# the quantities for that date.

# take an existing date '2018-08-20'
# take an existing pName 'potatoes', convert back to date in exercise and productname
q1_d = '''
    with product_inventory(sid, total_qty) as (
        select sid, sum(quantity)
        from inventory 
        where date = '2016-12-10'
        and pid = (
            select pid
            from product
            where lower(pname) = 'kelloggs rice crispies'
        )
        group by sid
    )
    
    select sid, sName
    from store
    where sid in (
        select sid
        from product_inventory
        where total_qty = (
            select max(product_inventory.total_qty) max_inventory
            from product_inventory
        )
    )
'''

pd.read_sql_query(q1_d, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:45:42
q1_e = '''
    create view as expense
        select cid, cname, sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by, cid, cname, sid, sname, date
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:46:11
q1_e = '''
    create view expense as
        select cid, cname, sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by, cid, cname, sid, sname, date
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:46:26
q1_e = '''
    create view expense as
        select cid, cname, sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by cid, cname, sid, sname, date
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:46:42
q1_e = '''
    create view expense as
        select cid, cname, sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by cid, cname, sid, sname, date
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:47:43
q1_e = '''
    create view if not exists expense as
        select cid, cname, sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by cid, cname, sid, sname, date
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:48:20
q1_e = '''
    create view expense as
    select cid, cname, sid, sname, date, sum(quantity * price) totalprice
    from customer c, store s, purchase p
    where c.cid = p.cid
    and s.sid = p.sid
    group by cid, cname, sid, sname, date
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:48:30
q1_e = '''
    create view expense as (
    select cid, cname, sid, sname, date, sum(quantity * price) totalprice
    from customer c, store s, purchase p
    where c.cid = p.cid
    and s.sid = p.sid
    group by cid, cname, sid, sname, date)
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:50:07
q1_e = '''

        select cid, cname, sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by cid, cname, sid, sname, date
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:50:45
q1_e = '''
    create view expense as (
        select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by cid, cname, sid, sname, date
    )
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:50:54
q1_e = '''
        select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by cid, cname, sid, sname, date
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:51:06
q1_e = '''
        select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by c.cid, cname, s.sid, sname, date
'''

pd.read_sql_query(q1_e, conn)
#[Out]#      cID   cName  sID      sName        date  totalprice
#[Out]# 0      0    Noah    3     Sligro  2018-08-22        0.45
#[Out]# 1      1     Sem    3     Sligro  2018-08-20        4.80
#[Out]# 2      1     Sem   16       Lidl  2018-08-20       11.00
#[Out]# 3      1     Sem   17  Hoogvliet  2018-08-20        2.50
#[Out]# 4      1     Sem   23       Dirk  2018-08-20        9.30
#[Out]# ..   ...     ...  ...        ...         ...         ...
#[Out]# 499  190  Kostas   59      Jumbo  2018-08-26        7.60
#[Out]# 500  190  Kostas   60       Lidl  2018-08-27       26.10
#[Out]# 501  190  Kostas   61       Lidl  2018-08-23       14.25
#[Out]# 502  190  Kostas   62      Jumbo  2018-08-16        6.30
#[Out]# 503  190  Kostas   63      Jumbo  2018-08-21        3.30
#[Out]# 
#[Out]# [504 rows x 6 columns]
# Tue, 08 Dec 2020 14:51:13
q1_e = '''
 create view expense as (
        select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by c.cid, cname, s.sid, sname, date
    )
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:51:32
q1_e = '''
     create view expense as (
            select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
            from customer c, store s, purchase p
            where c.cid = p.cid
            and s.sid = p.sid
            group by c.cid, cname, s.sid, sname, date
    )
    select *
    from expense

'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:51:42
q1_e = '''
     create view expense as
            select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
            from customer c, store s, purchase p
            where c.cid = p.cid
            and s.sid = p.sid
            group by c.cid, cname, s.sid, sname, date
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:51:51
q1_e = '''
     create view expense as
        select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by c.cid, cname, s.sid, sname, date
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:53:10
q1_e = '''
     create view expense as
    select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
    from customer c, store s, purchase p
    where c.cid = p.cid
    and s.sid = p.sid
    group by c.cid, cname, s.sid, sname, date
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:53:12
q1_e = '''
    create view expense as
    select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
    from customer c, store s, purchase p
    where c.cid = p.cid
    and s.sid = p.sid
    group by c.cid, cname, s.sid, sname, date
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:53:26
q1_e = '''
    select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
    from customer c, store s, purchase p
    where c.cid = p.cid
    and s.sid = p.sid
    group by c.cid, cname, s.sid, sname, date
'''

pd.read_sql_query(q1_e, conn)
#[Out]#      cID   cName  sID      sName        date  totalprice
#[Out]# 0      0    Noah    3     Sligro  2018-08-22        0.45
#[Out]# 1      1     Sem    3     Sligro  2018-08-20        4.80
#[Out]# 2      1     Sem   16       Lidl  2018-08-20       11.00
#[Out]# 3      1     Sem   17  Hoogvliet  2018-08-20        2.50
#[Out]# 4      1     Sem   23       Dirk  2018-08-20        9.30
#[Out]# ..   ...     ...  ...        ...         ...         ...
#[Out]# 499  190  Kostas   59      Jumbo  2018-08-26        7.60
#[Out]# 500  190  Kostas   60       Lidl  2018-08-27       26.10
#[Out]# 501  190  Kostas   61       Lidl  2018-08-23       14.25
#[Out]# 502  190  Kostas   62      Jumbo  2018-08-16        6.30
#[Out]# 503  190  Kostas   63      Jumbo  2018-08-21        3.30
#[Out]# 
#[Out]# [504 rows x 6 columns]
# Tue, 08 Dec 2020 14:54:42
q1_e = '''
    drop view expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:55:19
q1_e = '''
    create view if not exists expense as
    select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
    from customer c, store s, purchase p
    where c.cid = p.cid
    and s.sid = p.sid
    group by c.cid, cname, s.sid, sname, date
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:56:07
q1_e = '''
    create view expense as
    select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
    from customer c, store s, purchase p
    where c.cid = p.cid
    and s.sid = p.sid
    group by c.cid, cname, s.sid, sname, date
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:56:32
q1_e = '''
    create view expense as
    select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
    from customer c, store s, purchase p
    where c.cid = p.cid
    and s.sid = p.sid
    group by c.cid, cname, s.sid, sname, date
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:57:02
q1_e = '''
    create view if not exists expense as
        select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by c.cid, cname, s.sid, sname, date;
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:57:11
q1_e = '''
    create view if not exists expense as
        select c.cid, cname, s.sid, sname, date, sum(quantity * price) totalprice
        from customer c, store s, purchase p
        where c.cid = p.cid
        and s.sid = p.sid
        group by c.cid, cname, s.sid, sname, date;
        
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:57:48
q1_e_test = '''
    select *
    from expense
'''

pd.read_sql_query(q1_e, conn)
# Tue, 08 Dec 2020 14:57:51
q1_e_test = '''
    select *
    from expense
'''

pd.read_sql_query(q1_e_test, conn)
#[Out]#      cID   cName  sID      sName        date  totalprice
#[Out]# 0      0    Noah    3     Sligro  2018-08-22        0.45
#[Out]# 1      1     Sem    3     Sligro  2018-08-20        4.80
#[Out]# 2      1     Sem   16       Lidl  2018-08-20       11.00
#[Out]# 3      1     Sem   17  Hoogvliet  2018-08-20        2.50
#[Out]# 4      1     Sem   23       Dirk  2018-08-20        9.30
#[Out]# ..   ...     ...  ...        ...         ...         ...
#[Out]# 499  190  Kostas   59      Jumbo  2018-08-26        7.60
#[Out]# 500  190  Kostas   60       Lidl  2018-08-27       26.10
#[Out]# 501  190  Kostas   61       Lidl  2018-08-23       14.25
#[Out]# 502  190  Kostas   62      Jumbo  2018-08-16        6.30
#[Out]# 503  190  Kostas   63      Jumbo  2018-08-21        3.30
#[Out]# 
#[Out]# [504 rows x 6 columns]
# Tue, 08 Dec 2020 15:29:06
# Comparing day totals with the max day total
query4_4 = '''
    with cust_day_total as (
        select cId, date, sum(price) day_total
        from purchase
        group by cId, date)
    select cName
    from customer
    where cId in (
        select cId
        from cust_day_total
        where day_total >= (
            select max(day_total) * 0.75
            from cust_day_total)
    )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 15:30:31
# Comparing day totals with the max day total
query4_4 = '''
with cust_day_total as (
    select cId, date, sum(price) day_total
    from purchase
    group by cId, date)
select cName
from customer
where cId in (
    select cId
    from cust_day_total
    where day_total >= (
        select max(day_total) * 0.75
        from cust_day_total)
);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 17:03:28
q_1_a_alternative_lol = '''    
SELECT c.cID, c.cNameFROM customer AS c, shoppinglist AS s, purchase AS pWHERE c.cID=s.cID AND c.cID=p.cID AND s.date=p.dateAND NOT EXISTS ( SELECT *FROM customer AS c1, shoppinglist AS s1, purchase AS p1WHERE c.cID=c1.cID AND c.cID=s1.cID AND c.cID=p1.cIDAND s1.pID=p1.pID AND s.date=s1.date AND s.date=p1.dateAND p.sID=p1.sID );
'''
pd.read_sql_query(lol, conn)
#[Out]#     cID   cName
#[Out]# 0     7    Bram
#[Out]# 1    13   James
#[Out]# 2    27     Tim
#[Out]# 3    33    Sven
#[Out]# 4    38  Floris
#[Out]# 5    43     Tom
#[Out]# 6    59    Joep
#[Out]# 7    64    Stan
#[Out]# 8    68   Boris
#[Out]# 9    82   Dylan
#[Out]# 10   92   Jelte
#[Out]# 11   95    Emma
#[Out]# 12  100    Sara
#[Out]# 13  109    Lynn
#[Out]# 14  112    Yara
#[Out]# 15  116   Lieke
#[Out]# 16  123   Milou
#[Out]# 17  144     Ivy
#[Out]# 18  162   Elena
#[Out]# 19  167  Veerle
#[Out]# 20  169    Lily

   Bud1            %                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 @                                              @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   E   %                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       DSDB                             `                                                     @                                                @                                                @                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              

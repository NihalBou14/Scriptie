# IPython log file

# Tue, 08 Dec 2020 21:08:09
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 21:08:11
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x253c8cbe490>
# Tue, 08 Dec 2020 21:32:53
query4_3 = '''
    with biep(boep) as (select sName from store)
    select boep from biep
'''
# Tue, 08 Dec 2020 21:32:54
pd.read_sql_query(query4_3, conn)
#[Out]#          boep
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 08 Dec 2020 21:35:36
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store)
    select city from cities
'''
# Tue, 08 Dec 2020 21:35:36
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 21:35:38
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 21:36:59
# In order to allow for visualization, we need to extract the schema.
# Pulled from W3
schema = vis.schema_from_conn(conn)
# Tue, 08 Dec 2020 21:37:01
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 21:37:05
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 21:37:22
query4_3 = '''
    with cities(city) as (
        select city from customer)
    select city from cities
'''
# Tue, 08 Dec 2020 21:37:23
pd.read_sql_query(query4_3, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# ..         ...
#[Out]# 185  Eindhoven
#[Out]# 186  Eindhoven
#[Out]# 187  Rotterdam
#[Out]# 188        Oss
#[Out]# 189    Utrecht
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 08 Dec 2020 21:37:30
query4_3 = '''
    with cities(city) as (
        select city from store)
    select city from cities
'''
# Tue, 08 Dec 2020 21:37:32
pd.read_sql_query(query4_3, conn)
#[Out]#          city
#[Out]# 0   Amsterdam
#[Out]# 1       Breda
#[Out]# 2   Rotterdam
#[Out]# 3   Rotterdam
#[Out]# 4   Eindhoven
#[Out]# ..        ...
#[Out]# 59      Breda
#[Out]# 60      Breda
#[Out]# 61      Breda
#[Out]# 62  Eindhoven
#[Out]# 63        Oss
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 08 Dec 2020 21:42:30
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store)
    select city from cities
'''
# Tue, 08 Dec 2020 21:42:31
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 21:44:25
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store)
        
    select sName
    from store, cities
    where store.city in cities.city
'''
# Tue, 08 Dec 2020 21:44:26
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:45:01
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store)
        
    select sName
    from store, cities
    where store.city in (select city from cities)
'''
# Tue, 08 Dec 2020 21:45:02
pd.read_sql_query(query4_3, conn)
#[Out]#      sName
#[Out]# 0     Coop
#[Out]# 1     Coop
#[Out]# 2     Coop
#[Out]# 3     Coop
#[Out]# 4     Coop
#[Out]# ..     ...
#[Out]# 443  Jumbo
#[Out]# 444  Jumbo
#[Out]# 445  Jumbo
#[Out]# 446  Jumbo
#[Out]# 447  Jumbo
#[Out]# 
#[Out]# [448 rows x 1 columns]
# Tue, 08 Dec 2020 21:52:28
query4_3 = '''
    with cities(city) as (
        select city from customer)
        
    select distinct city from cities
'''
# Tue, 08 Dec 2020 21:52:28
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Tue, 08 Dec 2020 21:52:37
query4_3 = '''
    with cities(city) as (
        select city from store)
        
    select distinct city from cities
'''
# Tue, 08 Dec 2020 21:52:38
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Tue, 08 Dec 2020 21:57:49
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where store.city not in (select badstores.city from badstores))
        
    select distinct sName
    from store, badstores
    where store.sName in (select badstores.sName from badstores)
'''
# Tue, 08 Dec 2020 21:57:50
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:58:23
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where store.city not in (select badstores.city from badstores))
        
    select distinct sName
    from store
    where store.sName not in (select badstores.sName from badstores)
'''
# Tue, 08 Dec 2020 21:58:23
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 21:58:43
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where store.city not in (select badstores.city from badstores))
        
    select distinct sName
    from store
    where store.sName not in (select bad.sName from badstores bas)
'''
# Tue, 08 Dec 2020 21:58:47
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where store.city not in (select badstores.city from badstores))
        
    select distinct sName
    from store
    where store.sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 21:58:48
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 22:00:00
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store)
    with badstores(sName) as (
        select sName 
        from store
        where store.city not in (select badstores.city from badstores))
        
    select distinct sName
    from store
    where store.sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 22:00:01
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 22:00:50
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where store.city not in cities)
        
    select distinct sName
    from store
    where store.sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 22:00:51
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 22:07:27
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where exists (select sName from store s, cities c where c.city not in s.city)
        
    select distinct sName
    from store
    where store.sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 22:07:28
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 22:08:51
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where exists (select sName from store as s, cities as c where c.city not in s.city)
        
    select distinct sName
    from store
    where store.sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 22:08:52
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 22:09:09
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where exists (select sName from store as s, cities as c where c.city not in s.city)
        
    select sName
    from store
    where store.sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 22:09:10
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 22:10:23
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where exists (select sName from store as s, cities as c where c.city not in s.city)
        
    select * from store
'''
# Tue, 08 Dec 2020 22:10:24
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 22:10:50
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where exists (select sName from store as s, cities as c where c.city not in s.city))
        
    select sName
    from store
    where sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 22:10:51
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 22:14:23
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where exists (select s.city 
                      from store as s
                      where s.city not in (select c.city from cities as c))
        
    select sName
    from store
    where sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 22:14:24
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 22:14:32
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where exists (select s.city 
                      from store as s
                      where s.city not in (select c.city from cities as c)))
        
    select sName
    from store
    where sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 22:14:33
pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 08 Dec 2020 22:18:13
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store
        where exists (select s.city 
                      from store as s
                      where s.city not in (select c.city from cities as c)))
        
    select sName
    from badstores
'''
# Tue, 08 Dec 2020 22:18:14
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:22:54
query4_3 = '''
    with cities(city) as (
        select city from customer
        union
        select city from store),
        badstores(sName) as (
        select sName 
        from store s1
        where exists (select s2.city 
                      from store as s2
                      where s1.sName = s2.sName and 
                      s2.city not in (select c.city from cities as c)))
        
    select distinct sName
    from store
    where sName not in (select bad.sName from badstores bad)
'''
# Tue, 08 Dec 2020 22:22:55
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 22:30:17
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum(value) as (
            select 0,75*max(price)
            from totalpercust)
            

    select distinct cID
    from totalpercust
    having price >= 0.75 * (select value from maximum)
'''
# Tue, 08 Dec 2020 22:30:17
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 22:30:57
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum(value) as (
            select 0,75*max(price)
            from totalpercust)
            

    select value from maximum)
'''
# Tue, 08 Dec 2020 22:30:57
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 22:31:07
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum(value) as (
            select 0,75*max(price)
            from totalpercust)
            

    select value from maximum
'''
# Tue, 08 Dec 2020 22:31:08
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 22:32:14
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum(value) as (
            select 0,75*max(distinct price)
            from totalpercust)
            

    select distinct cID
    from totalpercust
    having price >= 0.75 * (select value from maximum)
'''
# Tue, 08 Dec 2020 22:32:15
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 22:33:59
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum(value) as (
            select max(price)
            from totalpercust)
            

    select value from maximum
'''
# Tue, 08 Dec 2020 22:34:00
pd.read_sql_query(query4_4, conn)
#[Out]#    value
#[Out]# 0   39.1
# Tue, 08 Dec 2020 22:34:27
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select value from maximum
'''
# Tue, 08 Dec 2020 22:34:28
pd.read_sql_query(query4_4, conn)
#[Out]#     value
#[Out]# 0  29.325
# Tue, 08 Dec 2020 22:34:56
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum75percent(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select distinct cID
    from totalpercust
    having price >= 0.75 * (select value from maximum75percent)
'''
# Tue, 08 Dec 2020 22:34:57
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 22:35:13
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum75percent(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select distinct cID
    from totalpercust
    where price >= 0.75 * (select value from maximum75percent)
'''
# Tue, 08 Dec 2020 22:35:14
pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   71
#[Out]# 1  108
#[Out]# 2  124
#[Out]# 3  161
# Tue, 08 Dec 2020 22:38:11
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum75percent(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select distinct cID
    from totalpercust
    where price >= (select value from maximum75percent)
'''
# Tue, 08 Dec 2020 22:38:12
pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0  161
# Tue, 08 Dec 2020 22:38:18
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 22:51:37
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        
    select city, count(cID)
    from customer as c, store as s, purchase as p
    where c.cID = p.cID and s.sID = p.sID and
        s.city = "Eindhoven"
    group by city)
    
    union
    
    select city, 0
    from allcities
    where city not in (select city from purchase)
'''
# Tue, 08 Dec 2020 22:51:48
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        
    select city, 0
    from allcities
    where city not in (select city from purchase)
'''
# Tue, 08 Dec 2020 22:51:50
pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, 0]
#[Out]# Index: []
# Tue, 08 Dec 2020 22:51:58
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        
    select city, 0
    from allcities
    
'''
# Tue, 08 Dec 2020 22:51:59
pd.read_sql_query(query4_5, conn)
#[Out]#         city  0
#[Out]# 0  Amsterdam  0
#[Out]# 1      Breda  0
#[Out]# 2  Eindhoven  0
#[Out]# 3        Oss  0
#[Out]# 4  Rotterdam  0
#[Out]# 5    Tilburg  0
#[Out]# 6    Utrecht  0
# Tue, 08 Dec 2020 22:52:32
query4_5 = '''
    select city from customer
    
'''
# Tue, 08 Dec 2020 22:52:32
pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# ..         ...
#[Out]# 185  Eindhoven
#[Out]# 186  Eindhoven
#[Out]# 187  Rotterdam
#[Out]# 188        Oss
#[Out]# 189    Utrecht
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 08 Dec 2020 22:52:40
query4_5 = '''
    select distinct city from customer
    
'''
# Tue, 08 Dec 2020 22:52:41
pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Tue, 08 Dec 2020 22:52:46
query4_5 = '''
    select distinct city from store
    
'''
# Tue, 08 Dec 2020 22:52:48
pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Tue, 08 Dec 2020 22:53:00
query4_5 = '''
    select distinct city from customer
    
'''
# Tue, 08 Dec 2020 22:53:02
pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Tue, 08 Dec 2020 22:55:35
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        
    select city, count(cID)
    from customer as c, store as s, purchase as p
    where c.cID = p.cID and s.sID = p.sID and
        s.city = "Eindhoven"
    group by city)
    
    union
    
    select city, 0
    from allcities
    where city not in (select city from purchase)
'''
# Tue, 08 Dec 2020 22:55:36
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 22:55:52
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        
    select city, count(cID)
    from customer as c, store as s, purchase as p
    where c.cID = p.cID and s.sID = p.sID and
        s.city = "Eindhoven"
    group by city
    
    union
    
    select city, 0
    from allcities
    where city not in (select city from purchase)
'''
# Tue, 08 Dec 2020 22:55:53
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 23:00:14
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 23:01:46
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        
    select c.city, count(cID)
    from customer as c, store as s, purchase as p
    where c.cID = p.cID and s.sID = p.sID and
        s.city = "Eindhoven"
    group by city
    
    union
    
    select city, 0
    from allcities
    where city not in (select city from purchase)
'''
# Tue, 08 Dec 2020 23:01:47
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 23:01:54
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        
    select c.city, count(cID)
    from customer as c, store as s, purchase as p
    where c.cID = p.cID and s.sID = p.sID and
        s.city = "Eindhoven"
    group by city
    
    union
    
    select city, 0
    from allcities
    where city not in (select purchase.city from purchase)
'''
# Tue, 08 Dec 2020 23:01:55
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 23:02:06
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        
    select c.city, count(cID)
    from customer as c, store as s, purchase as p
    where c.cID = p.cID and s.sID = p.sID and
        s.city = "Eindhoven"
    group by c.city
    
    union
    
    select city, 0
    from allcities
    where city not in (select purchase.city from purchase)
'''
# Tue, 08 Dec 2020 23:02:07
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 23:10:46
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        goal(city, custcount) as (
            select c.city, count(cID)
            from customer as c, store as s, purchase as p
            where c.cID = p.cID and s.sID = p.sID and
                s.city = "Eindhoven"
            group by city)
        
    select * from goal
    
    union
    
    select city, 0
    from allcities
    where city not in (select goal.city from goal)
'''
# Tue, 08 Dec 2020 23:10:47
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 23:11:09
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 23:11:49
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store)
        goal(city, custcount) as (
            select c.city, count(cID)
            from customer as c, store as s, purchase as p
            where c.cID = p.cID and s.sID = p.sID and
                s.city = "Eindhoven"
            group by city)
        
    select * from goal
'''
# Tue, 08 Dec 2020 23:11:49
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 23:12:00
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store),
        goal(city, custcount) as (
            select c.city, count(cID)
            from customer as c, store as s, purchase as p
            where c.cID = p.cID and s.sID = p.sID and
                s.city = "Eindhoven"
            group by city)
        
    select * from goal
    
    union
    
    select city, 0
    from allcities
    where city not in (select goal.city from goal)
'''
# Tue, 08 Dec 2020 23:12:00
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 23:12:04
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 23:12:55
query4_5 = '''
    with allcities(city) as (
        select city from customer
        union
        select city from store),
        goal(city, custcount) as (
            select c.city, count(p.cID)
            from customer as c, store as s, purchase as p
            where c.cID = p.cID and s.sID = p.sID and
                s.city = "Eindhoven"
            group by c.city)
        
    select * from goal
    
    union
    
    select city, 0
    from allcities
    where city not in (select goal.city from goal)
'''
# Tue, 08 Dec 2020 23:12:56
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 23:12:59
pd.read_sql_query(query4_5, conn)
#[Out]#         city  custcount
#[Out]# 0  Amsterdam         17
#[Out]# 1      Breda         27
#[Out]# 2  Eindhoven         24
#[Out]# 3        Oss          0
#[Out]# 4  Rotterdam         16
#[Out]# 5    Tilburg         18
#[Out]# 6    Utrecht         31
# Tue, 08 Dec 2020 23:15:01
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum75percent(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select cID
    from totalpercust
    where price >= (select value from maximum75percent)
'''
# Tue, 08 Dec 2020 23:15:03
pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0  161
# Tue, 08 Dec 2020 23:15:25
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum75percent(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select distinct cID
    from totalpercust
    where price >= (select value from maximum75percent)
'''
# Tue, 08 Dec 2020 23:15:26
pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0  161

# IPython log file

query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum75percent(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select distinct cName
    from customer,totalpercust
    where customer.cID = totalpercust.cID and 
          price >= (select value from maximum75percent)
'''
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:57:41
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 10:57:43
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 09 Dec 2020 10:57:46
# In order to allow for visualization, we need to extract the schema.
# Pulled from W3
schema = vis.schema_from_conn(conn)
# Wed, 09 Dec 2020 10:57:49
query4_5 = '''
    with allcities(city) as (
            select city from customer
            union
            select city from store),
        goal(city, custcount) as (
            select c.city, count(p.cID)
            from customer as c, store as s, purchase as p
            where c.cID = p.cID and s.sID = p.sID and
                s.city = "Eindhoven"
            group by c.city)
        
    select * from goal
    
    union
    
    select city, 0
    from allcities
    where city not in (select goal.city from goal)
'''
# Wed, 09 Dec 2020 10:57:51
pd.read_sql_query(query4_5, conn)
#[Out]#         city  custcount
#[Out]# 0  Amsterdam         17
#[Out]# 1      Breda         27
#[Out]# 2  Eindhoven         24
#[Out]# 3        Oss          0
#[Out]# 4  Rotterdam         16
#[Out]# 5    Tilburg         18
#[Out]# 6    Utrecht         31
# Wed, 09 Dec 2020 10:57:56
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum75percent(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select distinct cName
    from customer,totalpercust
    where customer.cID = totalpercust.cID and 
          price >= (select value from maximum75percent)
'''
# Wed, 09 Dec 2020 10:57:57
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 11:58:05
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 12:13:17
query4_3 = '''
    with cities(city) as (
            select city from customer
            union
            select city from store),
        invalidcombos(sName, city) as (
            select s.sName, c.city
            from store as s, cities as c
            except
            select sName, city
            from store)
        invalidcombos(sName, city) as (
        
    select distinct sName
    from store
    except
    select sName from invalidcombos
'''
# Wed, 09 Dec 2020 12:13:17
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:13:34
query4_3 = '''
    with cities(city) as (
            select city from customer
            union
            select city from store),
        invalidcombos(sName, city) as (
            select s.sName, c.city
            from store as s, cities as c
            except
            select sName, city
            from store)
        
    select distinct sName
    from store
    except
    select sName from invalidcombos
'''
# Wed, 09 Dec 2020 12:13:34
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:14:02
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum75percent(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select distinct cName
    from customer,totalpercust
    where customer.cID = totalpercust.cID and 
          price >= maximum75percent.value
'''
# Wed, 09 Dec 2020 12:14:03
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:14:20
query4_4 = '''
    with totalpercust(cID, date, price) as (
            select cID, date, sum(price)
            from purchase
            group by cID, date),
        maximum75percent(value) as (
            select max(0.75*price)
            from totalpercust)
            

    select distinct cName
    from customer,totalpercust
    where customer.cID = totalpercust.cID and 
          price >= (select value from maximum75percent)
'''
# Wed, 09 Dec 2020 12:14:21
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 12:16:03
query4_3 = '''
    with cities(city) as (
            select city from customer
            union
            select city from store),
        invalidcombos(sName, city) as (
            select s.sName, c.city
            from store as s, cities as c
            except
            select sName, city
            from store)
        
    select distinct sName
    from store
    except
    select sName from invalidcombos
'''
# Wed, 09 Dec 2020 12:16:04
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 12:16:07
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:21:56
query4_5 = '''
    with allcities(city) as (
            select city from customer
            union
            select city from store),
        goal(city, custcount) as (
            select c.city, count(p.cID)
            from customer as c, store as s, purchase as p
            where c.cID = p.cID and s.sID = p.sID and
                s.city = "Eindhoven"
            group by c.city)
        
    select * from goal
    
    union
    
    select city, 0
    from allcities
    where city not in (select goal.city from goal)
'''
# Wed, 09 Dec 2020 12:21:58
pd.read_sql_query(query4_5, conn)
#[Out]#         city  custcount
#[Out]# 0  Amsterdam         17
#[Out]# 1      Breda         27
#[Out]# 2  Eindhoven         24
#[Out]# 3        Oss          0
#[Out]# 4  Rotterdam         16
#[Out]# 5    Tilburg         18
#[Out]# 6    Utrecht         31
# Wed, 09 Dec 2020 12:23:06
query4_5 = '''
    with allcities(city) as (
            select city from customer
            union
            select city from store),
        goal(city, custcount) as (
            select c.city, count(p.cID)
            from customer as c, store as s, purchase as p
            where c.cID = p.cID and s.sID = p.sID and
                s.city = "Eindhoven"
            group by c.city)
        
    select city, custcount as number from goal
    
    union
    
    select city, 0
    from allcities
    where city not in (select goal.city from goal)
'''
# Wed, 09 Dec 2020 12:23:07
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      16
#[Out]# 5    Tilburg      18
#[Out]# 6    Utrecht      31


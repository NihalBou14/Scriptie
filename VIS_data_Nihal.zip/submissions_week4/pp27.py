# IPython log file

# Wed, 09 Dec 2020 10:40:58

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 

# Wed, 09 Dec 2020 10:40:58

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

#[Out]# <sqlite3.Cursor at 0x10d24b3b0>
# Wed, 09 Dec 2020 10:41:01

query4_3 = '''
    PUT YOUR QUERY HERE
'''

pd.read_sql_query(query4_3, conn)

# Wed, 09 Dec 2020 10:41:21

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 

# Wed, 09 Dec 2020 10:41:28

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# Wed, 09 Dec 2020 10:48:39

query4_3 = '''
    SELECT sName, city
    FROM store
'''

pd.read_sql_query(query4_3, conn)

#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 10:56:15

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )
    
'''

pd.read_sql_query(query4_3, conn)

#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Wed, 09 Dec 2020 10:56:49

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName       city
#[Out]# 0  Albert Hein  Eindhoven
#[Out]# 1         Coop  Amsterdam
#[Out]# 2         Dirk      Breda
#[Out]# 3    Hoogvliet      Breda
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5         Lidl  Eindhoven
#[Out]# 6       Sligro  Rotterdam
# Wed, 09 Dec 2020 11:00:06

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/
    
    SELECT sName
    FROM store
    GROUP BY sName

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Wed, 09 Dec 2020 11:00:14

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/

    SELECT sName, city
    FROM store
    GROUP BY sName

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName       city
#[Out]# 0  Albert Hein  Eindhoven
#[Out]# 1         Coop  Amsterdam
#[Out]# 2         Dirk      Breda
#[Out]# 3    Hoogvliet      Breda
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5         Lidl  Eindhoven
#[Out]# 6       Sligro  Rotterdam
# Wed, 09 Dec 2020 11:00:21

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/

    SELECT sName, city
    FROM store
    GROUP BY city

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName       city
#[Out]# 0         Coop  Amsterdam
#[Out]# 1    Hoogvliet      Breda
#[Out]# 2    Hoogvliet  Eindhoven
#[Out]# 3        Jumbo        Oss
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5  Albert Hein    Tilburg
#[Out]# 6         Lidl    Utrecht
# Wed, 09 Dec 2020 11:00:35

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/

    SELECT sName, city
    FROM store

'''

pd.read_sql_query(query4_3, conn)

#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 11:00:53

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/

    SELECT sName, city
    FROM store
    GROUP BY sName, city

'''

pd.read_sql_query(query4_3, conn)

#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Wed, 09 Dec 2020 11:01:12

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/

    SELECT sName, city
    FROM store
    GROUP BY sName, city
    ORDER BY city

'''

pd.read_sql_query(query4_3, conn)

#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Lidl  Amsterdam
#[Out]# 2        Sligro  Amsterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4          Coop      Breda
#[Out]# 5          Dirk      Breda
#[Out]# 6     Hoogvliet      Breda
#[Out]# 7         Jumbo      Breda
#[Out]# 8          Lidl      Breda
#[Out]# 9        Sligro      Breda
#[Out]# 10  Albert Hein  Eindhoven
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12    Hoogvliet  Eindhoven
#[Out]# 13        Jumbo  Eindhoven
#[Out]# 14         Lidl  Eindhoven
#[Out]# 15       Sligro  Eindhoven
#[Out]# 16        Jumbo        Oss
#[Out]# 17  Albert Hein  Rotterdam
#[Out]# 18         Coop  Rotterdam
#[Out]# 19         Dirk  Rotterdam
#[Out]# 20    Hoogvliet  Rotterdam
#[Out]# 21        Jumbo  Rotterdam
#[Out]# 22         Lidl  Rotterdam
#[Out]# 23       Sligro  Rotterdam
#[Out]# 24  Albert Hein    Tilburg
#[Out]# 25         Coop    Tilburg
#[Out]# 26    Hoogvliet    Tilburg
#[Out]# 27        Jumbo    Tilburg
#[Out]# 28       Sligro    Tilburg
#[Out]# 29  Albert Hein    Utrecht
#[Out]# 30         Coop    Utrecht
#[Out]# 31         Lidl    Utrecht
# Wed, 09 Dec 2020 11:01:22

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/

    SELECT sName, city
    FROM store
    ORDER BY city
    GROUP BY sName, city

'''

pd.read_sql_query(query4_3, conn)

# Wed, 09 Dec 2020 11:01:29

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/

    SELECT sName, city
    FROM store
    GROUP BY sName
    ORDER BY city

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName       city
#[Out]# 0         Coop  Amsterdam
#[Out]# 1         Dirk      Breda
#[Out]# 2    Hoogvliet      Breda
#[Out]# 3  Albert Hein  Eindhoven
#[Out]# 4         Lidl  Eindhoven
#[Out]# 5        Jumbo  Rotterdam
#[Out]# 6       Sligro  Rotterdam
# Wed, 09 Dec 2020 11:01:44

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/

    SELECT sName, count(city)
    FROM store
    GROUP BY sName
    ORDER BY city

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName  count(city)
#[Out]# 0         Coop           14
#[Out]# 1         Dirk            6
#[Out]# 2    Hoogvliet            9
#[Out]# 3  Albert Hein            8
#[Out]# 4         Lidl           10
#[Out]# 5        Jumbo            8
#[Out]# 6       Sligro            9
# Wed, 09 Dec 2020 11:01:51

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )*/

    SELECT sName, count(distinct city)
    FROM store
    GROUP BY sName
    ORDER BY city

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName  count(distinct city)
#[Out]# 0         Coop                     5
#[Out]# 1         Dirk                     3
#[Out]# 2    Hoogvliet                     4
#[Out]# 3  Albert Hein                     5
#[Out]# 4         Lidl                     5
#[Out]# 5        Jumbo                     5
#[Out]# 6       Sligro                     5
# Wed, 09 Dec 2020 11:02:25

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )

    /*
    SELECT sName, count(distinct city)
    FROM store
    GROUP BY sName
    ORDER BY city
    */

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName       city
#[Out]# 0  Albert Hein  Eindhoven
#[Out]# 1         Coop  Amsterdam
#[Out]# 2         Dirk      Breda
#[Out]# 3    Hoogvliet      Breda
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5         Lidl  Eindhoven
#[Out]# 6       Sligro  Rotterdam
# Wed, 09 Dec 2020 11:02:52

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    )

    /*
    SELECT sName, count(distinct city)
    FROM store
    GROUP BY sName
    ORDER BY city
    */

'''

pd.read_sql_query(query4_3, conn)

#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Wed, 09 Dec 2020 11:03:14

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ) */
    
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store

    /*
    SELECT sName, count(distinct city)
    FROM store
    GROUP BY sName
    ORDER BY city
    */

'''

pd.read_sql_query(query4_3, conn)

#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 11:03:52

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ) */

        SELECT city
        FROM customer


    /*
    SELECT sName, count(distinct city)
    FROM store
    GROUP BY sName
    ORDER BY city
    */

'''

pd.read_sql_query(query4_3, conn)

#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# 5      Utrecht
#[Out]# 6      Utrecht
#[Out]# 7    Eindhoven
#[Out]# 8        Breda
#[Out]# 9    Amsterdam
#[Out]# 10     Tilburg
#[Out]# 11     Tilburg
#[Out]# 12   Eindhoven
#[Out]# 13       Breda
#[Out]# 14     Tilburg
#[Out]# 15     Tilburg
#[Out]# 16   Eindhoven
#[Out]# 17     Tilburg
#[Out]# 18     Tilburg
#[Out]# 19       Breda
#[Out]# 20   Amsterdam
#[Out]# 21     Tilburg
#[Out]# 22   Eindhoven
#[Out]# 23       Breda
#[Out]# 24     Tilburg
#[Out]# 25   Rotterdam
#[Out]# 26   Eindhoven
#[Out]# 27     Utrecht
#[Out]# 28     Tilburg
#[Out]# 29   Rotterdam
#[Out]# ..         ...
#[Out]# 160    Tilburg
#[Out]# 161    Tilburg
#[Out]# 162  Rotterdam
#[Out]# 163    Tilburg
#[Out]# 164      Breda
#[Out]# 165    Tilburg
#[Out]# 166  Eindhoven
#[Out]# 167      Breda
#[Out]# 168  Rotterdam
#[Out]# 169    Utrecht
#[Out]# 170  Eindhoven
#[Out]# 171  Rotterdam
#[Out]# 172    Tilburg
#[Out]# 173      Breda
#[Out]# 174  Eindhoven
#[Out]# 175  Eindhoven
#[Out]# 176  Amsterdam
#[Out]# 177  Amsterdam
#[Out]# 178    Utrecht
#[Out]# 179    Tilburg
#[Out]# 180  Amsterdam
#[Out]# 181  Eindhoven
#[Out]# 182  Eindhoven
#[Out]# 183    Utrecht
#[Out]# 184  Eindhoven
#[Out]# 185  Eindhoven
#[Out]# 186  Eindhoven
#[Out]# 187  Rotterdam
#[Out]# 188        Oss
#[Out]# 189    Utrecht
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Wed, 09 Dec 2020 11:03:58

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ) */

        SELECT distinct city
        FROM customer


    /*
    SELECT sName, count(distinct city)
    FROM store
    GROUP BY sName
    ORDER BY city
    */

'''

pd.read_sql_query(query4_3, conn)

#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Wed, 09 Dec 2020 11:04:12

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ) */


        SELECT distinct city
        FROM store


    /*
    SELECT sName, count(distinct city)
    FROM store
    GROUP BY sName
    ORDER BY city
    */

'''

pd.read_sql_query(query4_3, conn)

#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Wed, 09 Dec 2020 11:04:21

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ) */

        SELECT distinct city
        FROM customer
        


    /*
    SELECT sName, count(distinct city)
    FROM store
    GROUP BY sName
    ORDER BY city
    */

'''

pd.read_sql_query(query4_3, conn)

#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Wed, 09 Dec 2020 11:04:45

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ) */



    
    SELECT sName, count(distinct city)
    FROM store
    GROUP BY sName
    ORDER BY city
    

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName  count(distinct city)
#[Out]# 0         Coop                     5
#[Out]# 1         Dirk                     3
#[Out]# 2    Hoogvliet                     4
#[Out]# 3  Albert Hein                     5
#[Out]# 4         Lidl                     5
#[Out]# 5        Jumbo                     5
#[Out]# 6       Sligro                     5
# Wed, 09 Dec 2020 11:05:03

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ) */



    
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    ORDER BY city


'''

pd.read_sql_query(query4_3, conn)

#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Lidl  Amsterdam
#[Out]# 2        Sligro  Amsterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4          Coop      Breda
#[Out]# 5          Dirk      Breda
#[Out]# 6     Hoogvliet      Breda
#[Out]# 7         Jumbo      Breda
#[Out]# 8          Lidl      Breda
#[Out]# 9        Sligro      Breda
#[Out]# 10  Albert Hein  Eindhoven
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12    Hoogvliet  Eindhoven
#[Out]# 13        Jumbo  Eindhoven
#[Out]# 14         Lidl  Eindhoven
#[Out]# 15       Sligro  Eindhoven
#[Out]# 16        Jumbo        Oss
#[Out]# 17  Albert Hein  Rotterdam
#[Out]# 18         Coop  Rotterdam
#[Out]# 19         Dirk  Rotterdam
#[Out]# 20    Hoogvliet  Rotterdam
#[Out]# 21        Jumbo  Rotterdam
#[Out]# 22         Lidl  Rotterdam
#[Out]# 23       Sligro  Rotterdam
#[Out]# 24  Albert Hein    Tilburg
#[Out]# 25         Coop    Tilburg
#[Out]# 26    Hoogvliet    Tilburg
#[Out]# 27        Jumbo    Tilburg
#[Out]# 28       Sligro    Tilburg
#[Out]# 29  Albert Hein    Utrecht
#[Out]# 30         Coop    Utrecht
#[Out]# 31         Lidl    Utrecht
# Wed, 09 Dec 2020 11:05:18

query4_3 = '''
    /*SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING city in (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ) */




    SELECT sName, city
    FROM store
    GROUP BY sName, city
    ORDER BY sName


'''

pd.read_sql_query(query4_3, conn)

#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Wed, 09 Dec 2020 11:09:45

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING count(distinct city) = (
        
        SELECT count(distinct city)
        FROM (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
        )

    )
'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:11:29

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING count(distinct city) = 3 /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:11:32

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING count(distinct city) = 3 /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:11:37

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING count(distinct city) > 3 /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:11:43

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING count(distinct city) > 3 /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:11:47

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING count(distinct city) > 1 /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:11:49

query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING count(distinct city) > 1 /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:12:23

query4_3 = '''
    SELECT sName, count( DISTINCT city)
    FROM store
    GROUP BY sName, city
    HAVING count(distinct city) > 1 
    /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, count( DISTINCT city)]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:12:27

query4_3 = '''
    SELECT sName, count( DISTINCT city)
    FROM store
    GROUP BY sName, city
    /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]#           sName  count( DISTINCT city)
#[Out]# 0   Albert Hein                      1
#[Out]# 1   Albert Hein                      1
#[Out]# 2   Albert Hein                      1
#[Out]# 3   Albert Hein                      1
#[Out]# 4   Albert Hein                      1
#[Out]# 5          Coop                      1
#[Out]# 6          Coop                      1
#[Out]# 7          Coop                      1
#[Out]# 8          Coop                      1
#[Out]# 9          Coop                      1
#[Out]# 10         Dirk                      1
#[Out]# 11         Dirk                      1
#[Out]# 12         Dirk                      1
#[Out]# 13    Hoogvliet                      1
#[Out]# 14    Hoogvliet                      1
#[Out]# 15    Hoogvliet                      1
#[Out]# 16    Hoogvliet                      1
#[Out]# 17        Jumbo                      1
#[Out]# 18        Jumbo                      1
#[Out]# 19        Jumbo                      1
#[Out]# 20        Jumbo                      1
#[Out]# 21        Jumbo                      1
#[Out]# 22         Lidl                      1
#[Out]# 23         Lidl                      1
#[Out]# 24         Lidl                      1
#[Out]# 25         Lidl                      1
#[Out]# 26         Lidl                      1
#[Out]# 27       Sligro                      1
#[Out]# 28       Sligro                      1
#[Out]# 29       Sligro                      1
#[Out]# 30       Sligro                      1
#[Out]# 31       Sligro                      1
# Wed, 09 Dec 2020 11:12:33

query4_3 = '''
    SELECT sName, count( DISTINCT city)
    FROM store
    GROUP BY sName
    HAVING count(distinct city) > 1
    /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName  count( DISTINCT city)
#[Out]# 0  Albert Hein                      5
#[Out]# 1         Coop                      5
#[Out]# 2         Dirk                      3
#[Out]# 3    Hoogvliet                      4
#[Out]# 4        Jumbo                      5
#[Out]# 5         Lidl                      5
#[Out]# 6       Sligro                      5
# Wed, 09 Dec 2020 11:12:44

query4_3 = '''
    SELECT sName, count( DISTINCT city)
    FROM store
    GROUP BY sName
    HAVING count(distinct city) = 3
    /*(

         SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/

'''

pd.read_sql_query(query4_3, conn)

#[Out]#   sName  count( DISTINCT city)
#[Out]# 0  Dirk                      3
# Wed, 09 Dec 2020 11:13:23

query4_3 = '''
    /*
    SELECT sName, count( DISTINCT city)
    FROM store
    GROUP BY sName
    HAVING count(distinct city) = (

        SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )*/
    
    SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )

'''

pd.read_sql_query(query4_3, conn)

#[Out]#    count(distinct city)
#[Out]# 0                     7
# Wed, 09 Dec 2020 11:24:17

query4_3 = '''
    
    SELECT sName, count( DISTINCT city)
    FROM store
    GROUP BY sName
    HAVING count(distinct city) = (

        SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )
'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, count( DISTINCT city)]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:24:25

query4_3 = '''

    SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING count(distinct city) = (

        SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )
'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:24:38

query4_3 = '''

    SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING count(distinct city) = 3 /* (

        SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    ) 
'''

pd.read_sql_query(query4_3, conn)

#[Out]#   sName   city
#[Out]# 0  Dirk  Breda
# Wed, 09 Dec 2020 11:24:47

query4_3 = '''

    SELECT sName, city
    FROM store
    GROUP BY sName, city
    HAVING count(distinct city) = 3 /* (

        SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    ) 
'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:24:52

query4_3 = '''

    SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING count(distinct city) = 3 /* (

        SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    ) 
'''

pd.read_sql_query(query4_3, conn)

#[Out]#   sName   city
#[Out]# 0  Dirk  Breda
# Wed, 09 Dec 2020 11:25:06

query4_3 = '''

    SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING count(distinct city) > 1 /* (

        SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        )
    )
'''

pd.read_sql_query(query4_3, conn)

#[Out]#          sName       city
#[Out]# 0  Albert Hein  Eindhoven
#[Out]# 1         Coop  Amsterdam
#[Out]# 2         Dirk      Breda
#[Out]# 3    Hoogvliet      Breda
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5         Lidl  Eindhoven
#[Out]# 6       Sligro  Rotterdam
# Wed, 09 Dec 2020 11:28:53

query4_4 = '''
    SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price > 0.75 * (
        SELECT MAX price
        FROM purchase
    )
    

'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:29:04

query4_4 = '''
    SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price > 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )
    

'''

pd.read_sql_query(query4_4, conn)

#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9     Dylan
#[Out]# 10  Thijmen
#[Out]# 11    Lotte
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Lieke
#[Out]# 15    Sofie
#[Out]# 16      Ivy
#[Out]# 17    Fenne
#[Out]# 18    Elena
# Wed, 09 Dec 2020 11:29:43

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/
    
            
            SELECT MAX(price)
        FROM purchase


'''

pd.read_sql_query(query4_4, conn)

#[Out]#    MAX(price)
#[Out]# 0        13.8
# Wed, 09 Dec 2020 11:30:07

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price
        FROM purchase


'''

pd.read_sql_query(query4_4, conn)

#[Out]#      price
#[Out]# 0     0.45
#[Out]# 1     4.65
#[Out]# 2     1.60
#[Out]# 3     1.25
#[Out]# 4     3.95
#[Out]# 5     2.75
#[Out]# 6     0.90
#[Out]# 7     9.10
#[Out]# 8     2.45
#[Out]# 9     1.35
#[Out]# 10    1.10
#[Out]# 11    3.70
#[Out]# 12    1.55
#[Out]# 13    4.30
#[Out]# 14    2.75
#[Out]# 15    1.45
#[Out]# 16    4.15
#[Out]# 17    9.05
#[Out]# 18   13.60
#[Out]# 19    1.05
#[Out]# 20    3.05
#[Out]# 21    2.75
#[Out]# 22    4.70
#[Out]# 23    8.25
#[Out]# 24    1.10
#[Out]# 25    1.55
#[Out]# 26    1.85
#[Out]# 27    2.20
#[Out]# 28    2.10
#[Out]# 29    1.70
#[Out]# ..     ...
#[Out]# 479   2.80
#[Out]# 480   0.50
#[Out]# 481   2.55
#[Out]# 482   0.65
#[Out]# 483   0.70
#[Out]# 484   3.70
#[Out]# 485   3.50
#[Out]# 486   2.95
#[Out]# 487   2.75
#[Out]# 488   1.50
#[Out]# 489   0.85
#[Out]# 490   3.55
#[Out]# 491   2.60
#[Out]# 492   3.25
#[Out]# 493   4.30
#[Out]# 494   3.05
#[Out]# 495   4.05
#[Out]# 496   1.50
#[Out]# 497   2.50
#[Out]# 498   3.95
#[Out]# 499   3.50
#[Out]# 500   2.95
#[Out]# 501   1.60
#[Out]# 502   3.25
#[Out]# 503   0.75
#[Out]# 504   3.80
#[Out]# 505   4.35
#[Out]# 506   2.85
#[Out]# 507   3.15
#[Out]# 508   3.30
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Wed, 09 Dec 2020 11:30:45

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price
        FROM purchase
        GROUP BY cID, date


'''

pd.read_sql_query(query4_4, conn)

#[Out]#      price
#[Out]# 0     0.45
#[Out]# 1     4.65
#[Out]# 2     0.90
#[Out]# 3     2.45
#[Out]# 4     1.35
#[Out]# 5     4.30
#[Out]# 6     2.75
#[Out]# 7     4.15
#[Out]# 8    13.60
#[Out]# 9     4.70
#[Out]# 10    8.25
#[Out]# 11    1.10
#[Out]# 12    2.10
#[Out]# 13    1.90
#[Out]# 14   10.75
#[Out]# 15    1.05
#[Out]# 16    0.95
#[Out]# 17    3.20
#[Out]# 18    4.10
#[Out]# 19    5.35
#[Out]# 20    2.00
#[Out]# 21    1.65
#[Out]# 22    0.50
#[Out]# 23    0.90
#[Out]# 24    2.90
#[Out]# 25    1.80
#[Out]# 26    3.70
#[Out]# 27    0.55
#[Out]# 28    3.00
#[Out]# 29    1.85
#[Out]# ..     ...
#[Out]# 255   3.60
#[Out]# 256   9.00
#[Out]# 257   0.45
#[Out]# 258   3.70
#[Out]# 259   3.10
#[Out]# 260   4.05
#[Out]# 261   2.70
#[Out]# 262   2.00
#[Out]# 263   4.20
#[Out]# 264   3.90
#[Out]# 265   3.50
#[Out]# 266   1.00
#[Out]# 267   1.00
#[Out]# 268   1.00
#[Out]# 269   1.00
#[Out]# 270   1.25
#[Out]# 271   2.50
#[Out]# 272   4.15
#[Out]# 273   3.25
#[Out]# 274   2.75
#[Out]# 275   2.75
#[Out]# 276   4.45
#[Out]# 277   3.20
#[Out]# 278   0.55
#[Out]# 279   0.90
#[Out]# 280   0.50
#[Out]# 281   2.55
#[Out]# 282   3.70
#[Out]# 283   1.30
#[Out]# 284   1.20
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 11:31:04

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price, pID
        FROM purchase
        GROUP BY cID, date


'''

pd.read_sql_query(query4_4, conn)

#[Out]#      price  pID
#[Out]# 0     0.45   10
#[Out]# 1     4.65   14
#[Out]# 2     0.90   11
#[Out]# 3     2.45   20
#[Out]# 4     1.35    9
#[Out]# 5     4.30   14
#[Out]# 6     2.75   26
#[Out]# 7     4.15    8
#[Out]# 8    13.60   12
#[Out]# 9     4.70   14
#[Out]# 10    8.25   28
#[Out]# 11    1.10    6
#[Out]# 12    2.10   19
#[Out]# 13    1.90   16
#[Out]# 14   10.75   12
#[Out]# 15    1.05    6
#[Out]# 16    0.95    6
#[Out]# 17    3.20   24
#[Out]# 18    4.10   14
#[Out]# 19    5.35    0
#[Out]# 20    2.00   17
#[Out]# 21    1.65    9
#[Out]# 22    0.50    5
#[Out]# 23    0.90   11
#[Out]# 24    2.90   13
#[Out]# 25    1.80    7
#[Out]# 26    3.70    0
#[Out]# 27    0.55    5
#[Out]# 28    3.00   19
#[Out]# 29    1.85   16
#[Out]# ..     ...  ...
#[Out]# 255   3.60   25
#[Out]# 256   9.00   27
#[Out]# 257   0.45   10
#[Out]# 258   3.70   14
#[Out]# 259   3.10   26
#[Out]# 260   4.05   13
#[Out]# 261   2.70   26
#[Out]# 262   2.00   21
#[Out]# 263   4.20   13
#[Out]# 264   3.90   25
#[Out]# 265   3.50    0
#[Out]# 266   1.00   29
#[Out]# 267   1.00   29
#[Out]# 268   1.00   30
#[Out]# 269   1.00   30
#[Out]# 270   1.25    7
#[Out]# 271   2.50   19
#[Out]# 272   4.15   10
#[Out]# 273   3.25   20
#[Out]# 274   2.75   26
#[Out]# 275   2.75    3
#[Out]# 276   4.45   27
#[Out]# 277   3.20   22
#[Out]# 278   0.55   27
#[Out]# 279   0.90   19
#[Out]# 280   0.50   28
#[Out]# 281   2.55   19
#[Out]# 282   3.70    0
#[Out]# 283   1.30    7
#[Out]# 284   1.20   17
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Wed, 09 Dec 2020 11:31:10

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price, pID
        FROM purchase
        GROUP BY cID, date, pID


'''

pd.read_sql_query(query4_4, conn)

#[Out]#      price  pID
#[Out]# 0     0.45   10
#[Out]# 1     1.25    9
#[Out]# 2     4.65   14
#[Out]# 3     1.60   16
#[Out]# 4     3.95   25
#[Out]# 5     2.75   26
#[Out]# 6     0.90   11
#[Out]# 7     9.10   27
#[Out]# 8     2.45   20
#[Out]# 9     1.10    4
#[Out]# 10    1.35    9
#[Out]# 11    3.70   13
#[Out]# 12    1.55   22
#[Out]# 13    4.30   14
#[Out]# 14    1.45    9
#[Out]# 15    2.75   26
#[Out]# 16    1.05    6
#[Out]# 17    4.15    8
#[Out]# 18    9.05   27
#[Out]# 19   13.60   12
#[Out]# 20    3.05   13
#[Out]# 21    2.75   26
#[Out]# 22    4.70   14
#[Out]# 23    8.25   28
#[Out]# 24    1.10    6
#[Out]# 25    1.85   16
#[Out]# 26    2.20   19
#[Out]# 27    1.55   22
#[Out]# 28    1.70    2
#[Out]# 29    2.10   19
#[Out]# ..     ...  ...
#[Out]# 469   1.50   23
#[Out]# 470   3.20   25
#[Out]# 471   4.45   27
#[Out]# 472   1.75    5
#[Out]# 473   3.10   21
#[Out]# 474   3.20   22
#[Out]# 475   2.80   28
#[Out]# 476   3.30   18
#[Out]# 477   0.55   27
#[Out]# 478   3.00    9
#[Out]# 479   3.25   15
#[Out]# 480   0.90   19
#[Out]# 481   0.60   21
#[Out]# 482   2.00    2
#[Out]# 483   2.55    5
#[Out]# 484   0.95   10
#[Out]# 485   1.75   19
#[Out]# 486   0.50   28
#[Out]# 487   0.70    7
#[Out]# 488   2.55   19
#[Out]# 489   3.70    0
#[Out]# 490   2.60   22
#[Out]# 491   2.00    0
#[Out]# 492   2.40    4
#[Out]# 493   1.30    7
#[Out]# 494   3.80   17
#[Out]# 495   4.30   20
#[Out]# 496   4.25   21
#[Out]# 497   4.35    5
#[Out]# 498   1.20   17
#[Out]# 
#[Out]# [499 rows x 2 columns]
# Wed, 09 Dec 2020 11:31:17

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price,
        FROM purchase
        GROUP BY cID, date


'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:31:18

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price
        FROM purchase
        GROUP BY cID, date


'''

pd.read_sql_query(query4_4, conn)

#[Out]#      price
#[Out]# 0     0.45
#[Out]# 1     4.65
#[Out]# 2     0.90
#[Out]# 3     2.45
#[Out]# 4     1.35
#[Out]# 5     4.30
#[Out]# 6     2.75
#[Out]# 7     4.15
#[Out]# 8    13.60
#[Out]# 9     4.70
#[Out]# 10    8.25
#[Out]# 11    1.10
#[Out]# 12    2.10
#[Out]# 13    1.90
#[Out]# 14   10.75
#[Out]# 15    1.05
#[Out]# 16    0.95
#[Out]# 17    3.20
#[Out]# 18    4.10
#[Out]# 19    5.35
#[Out]# 20    2.00
#[Out]# 21    1.65
#[Out]# 22    0.50
#[Out]# 23    0.90
#[Out]# 24    2.90
#[Out]# 25    1.80
#[Out]# 26    3.70
#[Out]# 27    0.55
#[Out]# 28    3.00
#[Out]# 29    1.85
#[Out]# ..     ...
#[Out]# 255   3.60
#[Out]# 256   9.00
#[Out]# 257   0.45
#[Out]# 258   3.70
#[Out]# 259   3.10
#[Out]# 260   4.05
#[Out]# 261   2.70
#[Out]# 262   2.00
#[Out]# 263   4.20
#[Out]# 264   3.90
#[Out]# 265   3.50
#[Out]# 266   1.00
#[Out]# 267   1.00
#[Out]# 268   1.00
#[Out]# 269   1.00
#[Out]# 270   1.25
#[Out]# 271   2.50
#[Out]# 272   4.15
#[Out]# 273   3.25
#[Out]# 274   2.75
#[Out]# 275   2.75
#[Out]# 276   4.45
#[Out]# 277   3.20
#[Out]# 278   0.55
#[Out]# 279   0.90
#[Out]# 280   0.50
#[Out]# 281   2.55
#[Out]# 282   3.70
#[Out]# 283   1.30
#[Out]# 284   1.20
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 11:31:31

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price, cID
        FROM purchase
        GROUP BY cID, date


'''

pd.read_sql_query(query4_4, conn)

#[Out]#      price  cID
#[Out]# 0     0.45    0
#[Out]# 1     4.65    1
#[Out]# 2     0.90    1
#[Out]# 3     2.45    2
#[Out]# 4     1.35    2
#[Out]# 5     4.30    3
#[Out]# 6     2.75    3
#[Out]# 7     4.15    4
#[Out]# 8    13.60    4
#[Out]# 9     4.70    5
#[Out]# 10    8.25    5
#[Out]# 11    1.10    5
#[Out]# 12    2.10    7
#[Out]# 13    1.90    7
#[Out]# 14   10.75    7
#[Out]# 15    1.05    7
#[Out]# 16    0.95    8
#[Out]# 17    3.20   10
#[Out]# 18    4.10   11
#[Out]# 19    5.35   13
#[Out]# 20    2.00   13
#[Out]# 21    1.65   13
#[Out]# 22    0.50   13
#[Out]# 23    0.90   15
#[Out]# 24    2.90   16
#[Out]# 25    1.80   16
#[Out]# 26    3.70   16
#[Out]# 27    0.55   16
#[Out]# 28    3.00   16
#[Out]# 29    1.85   16
#[Out]# ..     ...  ...
#[Out]# 255   3.60  178
#[Out]# 256   9.00  179
#[Out]# 257   0.45  179
#[Out]# 258   3.70  179
#[Out]# 259   3.10  180
#[Out]# 260   4.05  180
#[Out]# 261   2.70  181
#[Out]# 262   2.00  181
#[Out]# 263   4.20  182
#[Out]# 264   3.90  182
#[Out]# 265   3.50  184
#[Out]# 266   1.00  185
#[Out]# 267   1.00  186
#[Out]# 268   1.00  188
#[Out]# 269   1.00  188
#[Out]# 270   1.25  189
#[Out]# 271   2.50  189
#[Out]# 272   4.15  190
#[Out]# 273   3.25  190
#[Out]# 274   2.75  190
#[Out]# 275   2.75  190
#[Out]# 276   4.45  190
#[Out]# 277   3.20  190
#[Out]# 278   0.55  190
#[Out]# 279   0.90  190
#[Out]# 280   0.50  190
#[Out]# 281   2.55  190
#[Out]# 282   3.70  190
#[Out]# 283   1.30  190
#[Out]# 284   1.20  190
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Wed, 09 Dec 2020 11:31:41

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price, cID, date
        FROM purchase
        GROUP BY cID, date


'''

pd.read_sql_query(query4_4, conn)

#[Out]#      price  cID        date
#[Out]# 0     0.45    0  2018-08-22
#[Out]# 1     4.65    1  2018-08-20
#[Out]# 2     0.90    1  2018-08-21
#[Out]# 3     2.45    2  2018-08-16
#[Out]# 4     1.35    2  2018-08-17
#[Out]# 5     4.30    3  2018-08-18
#[Out]# 6     2.75    3  2018-08-19
#[Out]# 7     4.15    4  2018-08-24
#[Out]# 8    13.60    4  2018-08-25
#[Out]# 9     4.70    5  2018-08-17
#[Out]# 10    8.25    5  2018-08-22
#[Out]# 11    1.10    5  2018-08-23
#[Out]# 12    2.10    7  2018-08-23
#[Out]# 13    1.90    7  2018-08-24
#[Out]# 14   10.75    7  2018-08-25
#[Out]# 15    1.05    7  2018-08-26
#[Out]# 16    0.95    8  2018-08-16
#[Out]# 17    3.20   10  2018-08-27
#[Out]# 18    4.10   11  2018-08-25
#[Out]# 19    5.35   13  2018-08-17
#[Out]# 20    2.00   13  2018-08-25
#[Out]# 21    1.65   13  2018-08-26
#[Out]# 22    0.50   13  2018-08-27
#[Out]# 23    0.90   15  2018-08-27
#[Out]# 24    2.90   16  2018-08-18
#[Out]# 25    1.80   16  2018-08-19
#[Out]# 26    3.70   16  2018-08-24
#[Out]# 27    0.55   16  2018-08-25
#[Out]# 28    3.00   16  2018-08-26
#[Out]# 29    1.85   16  2018-08-27
#[Out]# ..     ...  ...         ...
#[Out]# 255   3.60  178  2018-08-27
#[Out]# 256   9.00  179  2018-08-22
#[Out]# 257   0.45  179  2018-08-23
#[Out]# 258   3.70  179  2018-08-24
#[Out]# 259   3.10  180  2018-08-26
#[Out]# 260   4.05  180  2018-08-27
#[Out]# 261   2.70  181  2018-08-24
#[Out]# 262   2.00  181  2018-08-27
#[Out]# 263   4.20  182  2018-08-23
#[Out]# 264   3.90  182  2018-08-28
#[Out]# 265   3.50  184  2018-08-20
#[Out]# 266   1.00  185  2018-08-20
#[Out]# 267   1.00  186  2018-08-21
#[Out]# 268   1.00  188  2018-08-20
#[Out]# 269   1.00  188  2018-09-20
#[Out]# 270   1.25  189  2018-08-25
#[Out]# 271   2.50  189  2018-08-26
#[Out]# 272   4.15  190  2018-08-15
#[Out]# 273   3.25  190  2018-08-16
#[Out]# 274   2.75  190  2018-08-17
#[Out]# 275   2.75  190  2018-08-18
#[Out]# 276   4.45  190  2018-08-19
#[Out]# 277   3.20  190  2018-08-20
#[Out]# 278   0.55  190  2018-08-21
#[Out]# 279   0.90  190  2018-08-22
#[Out]# 280   0.50  190  2018-08-23
#[Out]# 281   2.55  190  2018-08-24
#[Out]# 282   3.70  190  2018-08-25
#[Out]# 283   1.30  190  2018-08-26
#[Out]# 284   1.20  190  2018-08-27
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 11:31:50

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price, cID
        FROM purchase
        GROUP BY cID, date


'''

pd.read_sql_query(query4_4, conn)

#[Out]#      price  cID
#[Out]# 0     0.45    0
#[Out]# 1     4.65    1
#[Out]# 2     0.90    1
#[Out]# 3     2.45    2
#[Out]# 4     1.35    2
#[Out]# 5     4.30    3
#[Out]# 6     2.75    3
#[Out]# 7     4.15    4
#[Out]# 8    13.60    4
#[Out]# 9     4.70    5
#[Out]# 10    8.25    5
#[Out]# 11    1.10    5
#[Out]# 12    2.10    7
#[Out]# 13    1.90    7
#[Out]# 14   10.75    7
#[Out]# 15    1.05    7
#[Out]# 16    0.95    8
#[Out]# 17    3.20   10
#[Out]# 18    4.10   11
#[Out]# 19    5.35   13
#[Out]# 20    2.00   13
#[Out]# 21    1.65   13
#[Out]# 22    0.50   13
#[Out]# 23    0.90   15
#[Out]# 24    2.90   16
#[Out]# 25    1.80   16
#[Out]# 26    3.70   16
#[Out]# 27    0.55   16
#[Out]# 28    3.00   16
#[Out]# 29    1.85   16
#[Out]# ..     ...  ...
#[Out]# 255   3.60  178
#[Out]# 256   9.00  179
#[Out]# 257   0.45  179
#[Out]# 258   3.70  179
#[Out]# 259   3.10  180
#[Out]# 260   4.05  180
#[Out]# 261   2.70  181
#[Out]# 262   2.00  181
#[Out]# 263   4.20  182
#[Out]# 264   3.90  182
#[Out]# 265   3.50  184
#[Out]# 266   1.00  185
#[Out]# 267   1.00  186
#[Out]# 268   1.00  188
#[Out]# 269   1.00  188
#[Out]# 270   1.25  189
#[Out]# 271   2.50  189
#[Out]# 272   4.15  190
#[Out]# 273   3.25  190
#[Out]# 274   2.75  190
#[Out]# 275   2.75  190
#[Out]# 276   4.45  190
#[Out]# 277   3.20  190
#[Out]# 278   0.55  190
#[Out]# 279   0.90  190
#[Out]# 280   0.50  190
#[Out]# 281   2.55  190
#[Out]# 282   3.70  190
#[Out]# 283   1.30  190
#[Out]# 284   1.20  190
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Wed, 09 Dec 2020 11:31:55

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT price, cID, date
        FROM purchase
        GROUP BY cID, date


'''

pd.read_sql_query(query4_4, conn)

#[Out]#      price  cID        date
#[Out]# 0     0.45    0  2018-08-22
#[Out]# 1     4.65    1  2018-08-20
#[Out]# 2     0.90    1  2018-08-21
#[Out]# 3     2.45    2  2018-08-16
#[Out]# 4     1.35    2  2018-08-17
#[Out]# 5     4.30    3  2018-08-18
#[Out]# 6     2.75    3  2018-08-19
#[Out]# 7     4.15    4  2018-08-24
#[Out]# 8    13.60    4  2018-08-25
#[Out]# 9     4.70    5  2018-08-17
#[Out]# 10    8.25    5  2018-08-22
#[Out]# 11    1.10    5  2018-08-23
#[Out]# 12    2.10    7  2018-08-23
#[Out]# 13    1.90    7  2018-08-24
#[Out]# 14   10.75    7  2018-08-25
#[Out]# 15    1.05    7  2018-08-26
#[Out]# 16    0.95    8  2018-08-16
#[Out]# 17    3.20   10  2018-08-27
#[Out]# 18    4.10   11  2018-08-25
#[Out]# 19    5.35   13  2018-08-17
#[Out]# 20    2.00   13  2018-08-25
#[Out]# 21    1.65   13  2018-08-26
#[Out]# 22    0.50   13  2018-08-27
#[Out]# 23    0.90   15  2018-08-27
#[Out]# 24    2.90   16  2018-08-18
#[Out]# 25    1.80   16  2018-08-19
#[Out]# 26    3.70   16  2018-08-24
#[Out]# 27    0.55   16  2018-08-25
#[Out]# 28    3.00   16  2018-08-26
#[Out]# 29    1.85   16  2018-08-27
#[Out]# ..     ...  ...         ...
#[Out]# 255   3.60  178  2018-08-27
#[Out]# 256   9.00  179  2018-08-22
#[Out]# 257   0.45  179  2018-08-23
#[Out]# 258   3.70  179  2018-08-24
#[Out]# 259   3.10  180  2018-08-26
#[Out]# 260   4.05  180  2018-08-27
#[Out]# 261   2.70  181  2018-08-24
#[Out]# 262   2.00  181  2018-08-27
#[Out]# 263   4.20  182  2018-08-23
#[Out]# 264   3.90  182  2018-08-28
#[Out]# 265   3.50  184  2018-08-20
#[Out]# 266   1.00  185  2018-08-20
#[Out]# 267   1.00  186  2018-08-21
#[Out]# 268   1.00  188  2018-08-20
#[Out]# 269   1.00  188  2018-09-20
#[Out]# 270   1.25  189  2018-08-25
#[Out]# 271   2.50  189  2018-08-26
#[Out]# 272   4.15  190  2018-08-15
#[Out]# 273   3.25  190  2018-08-16
#[Out]# 274   2.75  190  2018-08-17
#[Out]# 275   2.75  190  2018-08-18
#[Out]# 276   4.45  190  2018-08-19
#[Out]# 277   3.20  190  2018-08-20
#[Out]# 278   0.55  190  2018-08-21
#[Out]# 279   0.90  190  2018-08-22
#[Out]# 280   0.50  190  2018-08-23
#[Out]# 281   2.55  190  2018-08-24
#[Out]# 282   3.70  190  2018-08-25
#[Out]# 283   1.30  190  2018-08-26
#[Out]# 284   1.20  190  2018-08-27
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 11:32:48

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT MAX(price)
    FROM purchase
    GROUP BY cID, date



'''

pd.read_sql_query(query4_4, conn)

#[Out]#      MAX(price)
#[Out]# 0          0.45
#[Out]# 1          4.65
#[Out]# 2          9.10
#[Out]# 3          2.45
#[Out]# 4          3.70
#[Out]# 5          4.30
#[Out]# 6          2.75
#[Out]# 7          9.05
#[Out]# 8         13.60
#[Out]# 9          4.70
#[Out]# 10         8.25
#[Out]# 11         2.20
#[Out]# 12         2.10
#[Out]# 13         1.90
#[Out]# 14        10.75
#[Out]# 15         2.05
#[Out]# 16         5.30
#[Out]# 17         3.20
#[Out]# 18         4.10
#[Out]# 19         5.40
#[Out]# 20         2.40
#[Out]# 21         1.65
#[Out]# 22         0.50
#[Out]# 23         0.90
#[Out]# 24         2.90
#[Out]# 25         9.25
#[Out]# 26         3.70
#[Out]# 27         2.50
#[Out]# 28         3.00
#[Out]# 29         1.85
#[Out]# ..          ...
#[Out]# 255        3.90
#[Out]# 256        9.00
#[Out]# 257        0.45
#[Out]# 258        3.70
#[Out]# 259        3.10
#[Out]# 260        4.05
#[Out]# 261        2.70
#[Out]# 262        2.00
#[Out]# 263        4.20
#[Out]# 264        9.70
#[Out]# 265        3.50
#[Out]# 266        1.00
#[Out]# 267        1.00
#[Out]# 268        1.00
#[Out]# 269        1.00
#[Out]# 270        1.25
#[Out]# 271        2.50
#[Out]# 272        4.15
#[Out]# 273        3.25
#[Out]# 274        3.80
#[Out]# 275        4.35
#[Out]# 276        4.45
#[Out]# 277        3.20
#[Out]# 278        3.30
#[Out]# 279        4.05
#[Out]# 280        2.85
#[Out]# 281        2.55
#[Out]# 282        3.70
#[Out]# 283        4.30
#[Out]# 284        4.35
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 11:33:21

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT price
    FROM purchase
    GROUP BY cID, date
    HAVING price > any



'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:33:27

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT price
    FROM purchase
    GROUP BY cID, date
    HAVING price > some



'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:34:50

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT price
    FROM purchase
    GROUP BY cID, date
    HAVING price any



'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:35:06

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT SUM(price)
    FROM purchase
    GROUP BY cID, date



'''

pd.read_sql_query(query4_4, conn)

#[Out]#      SUM(price)
#[Out]# 0          0.45
#[Out]# 1         14.20
#[Out]# 2         10.00
#[Out]# 3          2.45
#[Out]# 4          7.70
#[Out]# 5          4.30
#[Out]# 6          4.20
#[Out]# 7         14.25
#[Out]# 8         19.40
#[Out]# 9          4.70
#[Out]# 10         8.25
#[Out]# 11         6.70
#[Out]# 12         3.80
#[Out]# 13         1.90
#[Out]# 14        10.75
#[Out]# 15         3.10
#[Out]# 16         6.25
#[Out]# 17         3.20
#[Out]# 18         4.10
#[Out]# 19        13.30
#[Out]# 20         6.50
#[Out]# 21         1.65
#[Out]# 22         0.50
#[Out]# 23         0.90
#[Out]# 24         2.90
#[Out]# 25        11.05
#[Out]# 26         6.05
#[Out]# 27         4.95
#[Out]# 28         3.00
#[Out]# 29         1.85
#[Out]# ..          ...
#[Out]# 255        7.50
#[Out]# 256       10.85
#[Out]# 257        0.45
#[Out]# 258        6.95
#[Out]# 259        3.10
#[Out]# 260        4.65
#[Out]# 261        3.60
#[Out]# 262        2.00
#[Out]# 263        4.20
#[Out]# 264       14.90
#[Out]# 265        3.50
#[Out]# 266        1.00
#[Out]# 267        1.00
#[Out]# 268        1.00
#[Out]# 269        1.00
#[Out]# 270        1.25
#[Out]# 271        2.50
#[Out]# 272       19.60
#[Out]# 273       12.80
#[Out]# 274       15.75
#[Out]# 275       14.85
#[Out]# 276       20.30
#[Out]# 277       10.85
#[Out]# 278        3.85
#[Out]# 279       14.55
#[Out]# 280       10.60
#[Out]# 281        3.25
#[Out]# 282        9.80
#[Out]# 283       21.90
#[Out]# 284        5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 11:35:20

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT MAX(SUM(price))
    FROM purchase
    GROUP BY cID, date



'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:35:58

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT MAX(Price)
    FROM purchase
    GROUP BY cID, date



'''

pd.read_sql_query(query4_4, conn)

#[Out]#      MAX(Price)
#[Out]# 0          0.45
#[Out]# 1          4.65
#[Out]# 2          9.10
#[Out]# 3          2.45
#[Out]# 4          3.70
#[Out]# 5          4.30
#[Out]# 6          2.75
#[Out]# 7          9.05
#[Out]# 8         13.60
#[Out]# 9          4.70
#[Out]# 10         8.25
#[Out]# 11         2.20
#[Out]# 12         2.10
#[Out]# 13         1.90
#[Out]# 14        10.75
#[Out]# 15         2.05
#[Out]# 16         5.30
#[Out]# 17         3.20
#[Out]# 18         4.10
#[Out]# 19         5.40
#[Out]# 20         2.40
#[Out]# 21         1.65
#[Out]# 22         0.50
#[Out]# 23         0.90
#[Out]# 24         2.90
#[Out]# 25         9.25
#[Out]# 26         3.70
#[Out]# 27         2.50
#[Out]# 28         3.00
#[Out]# 29         1.85
#[Out]# ..          ...
#[Out]# 255        3.90
#[Out]# 256        9.00
#[Out]# 257        0.45
#[Out]# 258        3.70
#[Out]# 259        3.10
#[Out]# 260        4.05
#[Out]# 261        2.70
#[Out]# 262        2.00
#[Out]# 263        4.20
#[Out]# 264        9.70
#[Out]# 265        3.50
#[Out]# 266        1.00
#[Out]# 267        1.00
#[Out]# 268        1.00
#[Out]# 269        1.00
#[Out]# 270        1.25
#[Out]# 271        2.50
#[Out]# 272        4.15
#[Out]# 273        3.25
#[Out]# 274        3.80
#[Out]# 275        4.35
#[Out]# 276        4.45
#[Out]# 277        3.20
#[Out]# 278        3.30
#[Out]# 279        4.05
#[Out]# 280        2.85
#[Out]# 281        2.55
#[Out]# 282        3.70
#[Out]# 283        4.30
#[Out]# 284        4.35
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 11:36:19

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date, price
    FROM purchase
    GROUP BY cID, date, price



'''

pd.read_sql_query(query4_4, conn)

#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   1.25
#[Out]# 2      1  2018-08-20   1.60
#[Out]# 3      1  2018-08-20   2.75
#[Out]# 4      1  2018-08-20   3.95
#[Out]# 5      1  2018-08-20   4.65
#[Out]# 6      1  2018-08-21   0.90
#[Out]# 7      1  2018-08-21   9.10
#[Out]# 8      2  2018-08-16   2.45
#[Out]# 9      2  2018-08-17   1.10
#[Out]# 10     2  2018-08-17   1.35
#[Out]# 11     2  2018-08-17   1.55
#[Out]# 12     2  2018-08-17   3.70
#[Out]# 13     3  2018-08-18   4.30
#[Out]# 14     3  2018-08-19   1.45
#[Out]# 15     3  2018-08-19   2.75
#[Out]# 16     4  2018-08-24   1.05
#[Out]# 17     4  2018-08-24   4.15
#[Out]# 18     4  2018-08-24   9.05
#[Out]# 19     4  2018-08-25   2.75
#[Out]# 20     4  2018-08-25   3.05
#[Out]# 21     4  2018-08-25  13.60
#[Out]# 22     5  2018-08-17   4.70
#[Out]# 23     5  2018-08-22   8.25
#[Out]# 24     5  2018-08-23   1.10
#[Out]# 25     5  2018-08-23   1.55
#[Out]# 26     5  2018-08-23   1.85
#[Out]# 27     5  2018-08-23   2.20
#[Out]# 28     7  2018-08-23   1.70
#[Out]# 29     7  2018-08-23   2.10
#[Out]# ..   ...         ...    ...
#[Out]# 476  190  2018-08-20   3.10
#[Out]# 477  190  2018-08-20   3.20
#[Out]# 478  190  2018-08-21   0.55
#[Out]# 479  190  2018-08-21   3.30
#[Out]# 480  190  2018-08-22   0.60
#[Out]# 481  190  2018-08-22   0.90
#[Out]# 482  190  2018-08-22   2.75
#[Out]# 483  190  2018-08-22   3.00
#[Out]# 484  190  2018-08-22   3.25
#[Out]# 485  190  2018-08-22   4.05
#[Out]# 486  190  2018-08-23   0.50
#[Out]# 487  190  2018-08-23   0.95
#[Out]# 488  190  2018-08-23   1.75
#[Out]# 489  190  2018-08-23   2.00
#[Out]# 490  190  2018-08-23   2.55
#[Out]# 491  190  2018-08-23   2.85
#[Out]# 492  190  2018-08-24   0.70
#[Out]# 493  190  2018-08-24   2.55
#[Out]# 494  190  2018-08-25   2.60
#[Out]# 495  190  2018-08-25   3.50
#[Out]# 496  190  2018-08-25   3.70
#[Out]# 497  190  2018-08-26   1.30
#[Out]# 498  190  2018-08-26   2.00
#[Out]# 499  190  2018-08-26   2.40
#[Out]# 500  190  2018-08-26   3.80
#[Out]# 501  190  2018-08-26   3.85
#[Out]# 502  190  2018-08-26   4.25
#[Out]# 503  190  2018-08-26   4.30
#[Out]# 504  190  2018-08-27   1.20
#[Out]# 505  190  2018-08-27   4.35
#[Out]# 
#[Out]# [506 rows x 3 columns]
# Wed, 09 Dec 2020 11:36:40

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date, max(price)
    FROM purchase
    GROUP BY cID, date, price



'''

pd.read_sql_query(query4_4, conn)

#[Out]#      cID        date  max(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20        1.25
#[Out]# 2      1  2018-08-20        1.60
#[Out]# 3      1  2018-08-20        2.75
#[Out]# 4      1  2018-08-20        3.95
#[Out]# 5      1  2018-08-20        4.65
#[Out]# 6      1  2018-08-21        0.90
#[Out]# 7      1  2018-08-21        9.10
#[Out]# 8      2  2018-08-16        2.45
#[Out]# 9      2  2018-08-17        1.10
#[Out]# 10     2  2018-08-17        1.35
#[Out]# 11     2  2018-08-17        1.55
#[Out]# 12     2  2018-08-17        3.70
#[Out]# 13     3  2018-08-18        4.30
#[Out]# 14     3  2018-08-19        1.45
#[Out]# 15     3  2018-08-19        2.75
#[Out]# 16     4  2018-08-24        1.05
#[Out]# 17     4  2018-08-24        4.15
#[Out]# 18     4  2018-08-24        9.05
#[Out]# 19     4  2018-08-25        2.75
#[Out]# 20     4  2018-08-25        3.05
#[Out]# 21     4  2018-08-25       13.60
#[Out]# 22     5  2018-08-17        4.70
#[Out]# 23     5  2018-08-22        8.25
#[Out]# 24     5  2018-08-23        1.10
#[Out]# 25     5  2018-08-23        1.55
#[Out]# 26     5  2018-08-23        1.85
#[Out]# 27     5  2018-08-23        2.20
#[Out]# 28     7  2018-08-23        1.70
#[Out]# 29     7  2018-08-23        2.10
#[Out]# ..   ...         ...         ...
#[Out]# 476  190  2018-08-20        3.10
#[Out]# 477  190  2018-08-20        3.20
#[Out]# 478  190  2018-08-21        0.55
#[Out]# 479  190  2018-08-21        3.30
#[Out]# 480  190  2018-08-22        0.60
#[Out]# 481  190  2018-08-22        0.90
#[Out]# 482  190  2018-08-22        2.75
#[Out]# 483  190  2018-08-22        3.00
#[Out]# 484  190  2018-08-22        3.25
#[Out]# 485  190  2018-08-22        4.05
#[Out]# 486  190  2018-08-23        0.50
#[Out]# 487  190  2018-08-23        0.95
#[Out]# 488  190  2018-08-23        1.75
#[Out]# 489  190  2018-08-23        2.00
#[Out]# 490  190  2018-08-23        2.55
#[Out]# 491  190  2018-08-23        2.85
#[Out]# 492  190  2018-08-24        0.70
#[Out]# 493  190  2018-08-24        2.55
#[Out]# 494  190  2018-08-25        2.60
#[Out]# 495  190  2018-08-25        3.50
#[Out]# 496  190  2018-08-25        3.70
#[Out]# 497  190  2018-08-26        1.30
#[Out]# 498  190  2018-08-26        2.00
#[Out]# 499  190  2018-08-26        2.40
#[Out]# 500  190  2018-08-26        3.80
#[Out]# 501  190  2018-08-26        3.85
#[Out]# 502  190  2018-08-26        4.25
#[Out]# 503  190  2018-08-26        4.30
#[Out]# 504  190  2018-08-27        1.20
#[Out]# 505  190  2018-08-27        4.35
#[Out]# 
#[Out]# [506 rows x 3 columns]
# Wed, 09 Dec 2020 11:37:15

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date
    FROM purchase




'''

pd.read_sql_query(query4_4, conn)

#[Out]#      cID        date
#[Out]# 0      0  2018-08-22
#[Out]# 1      1  2018-08-20
#[Out]# 2      1  2018-08-20
#[Out]# 3      1  2018-08-20
#[Out]# 4      1  2018-08-20
#[Out]# 5      1  2018-08-20
#[Out]# 6      1  2018-08-21
#[Out]# 7      1  2018-08-21
#[Out]# 8      2  2018-08-16
#[Out]# 9      2  2018-08-17
#[Out]# 10     2  2018-08-17
#[Out]# 11     2  2018-08-17
#[Out]# 12     2  2018-08-17
#[Out]# 13     3  2018-08-18
#[Out]# 14     3  2018-08-19
#[Out]# 15     3  2018-08-19
#[Out]# 16     4  2018-08-24
#[Out]# 17     4  2018-08-24
#[Out]# 18     4  2018-08-25
#[Out]# 19     4  2018-08-24
#[Out]# 20     4  2018-08-25
#[Out]# 21     4  2018-08-25
#[Out]# 22     5  2018-08-17
#[Out]# 23     5  2018-08-22
#[Out]# 24     5  2018-08-23
#[Out]# 25     5  2018-08-23
#[Out]# 26     5  2018-08-23
#[Out]# 27     5  2018-08-23
#[Out]# 28     7  2018-08-23
#[Out]# 29     7  2018-08-23
#[Out]# ..   ...         ...
#[Out]# 479  190  2018-08-20
#[Out]# 480  190  2018-08-15
#[Out]# 481  190  2018-08-23
#[Out]# 482  190  2018-08-15
#[Out]# 483  190  2018-08-24
#[Out]# 484  190  2018-08-25
#[Out]# 485  190  2018-08-15
#[Out]# 486  190  2018-08-15
#[Out]# 487  190  2018-08-22
#[Out]# 488  190  2018-08-17
#[Out]# 489  190  2018-08-18
#[Out]# 490  190  2018-08-19
#[Out]# 491  190  2018-08-25
#[Out]# 492  190  2018-08-17
#[Out]# 493  190  2018-08-26
#[Out]# 494  190  2018-08-17
#[Out]# 495  190  2018-08-22
#[Out]# 496  190  2018-08-19
#[Out]# 497  190  2018-08-15
#[Out]# 498  190  2018-08-18
#[Out]# 499  190  2018-08-25
#[Out]# 500  190  2018-08-18
#[Out]# 501  190  2018-08-15
#[Out]# 502  190  2018-08-22
#[Out]# 503  190  2018-08-19
#[Out]# 504  190  2018-08-26
#[Out]# 505  190  2018-08-27
#[Out]# 506  190  2018-08-23
#[Out]# 507  190  2018-08-16
#[Out]# 508  190  2018-08-21
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Wed, 09 Dec 2020 11:37:44

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date
    FROM purchase
    WHERE date = "2018-08-20"
    




'''

pd.read_sql_query(query4_4, conn)

#[Out]#     cID        date
#[Out]# 0     1  2018-08-20
#[Out]# 1     1  2018-08-20
#[Out]# 2     1  2018-08-20
#[Out]# 3     1  2018-08-20
#[Out]# 4     1  2018-08-20
#[Out]# 5    24  2018-08-20
#[Out]# 6    24  2018-08-20
#[Out]# 7    24  2018-08-20
#[Out]# 8    24  2018-08-20
#[Out]# 9    24  2018-08-20
#[Out]# 10   24  2018-08-20
#[Out]# 11   72  2018-08-20
#[Out]# 12   82  2018-08-20
#[Out]# 13  100  2018-08-20
#[Out]# 14  100  2018-08-20
#[Out]# 15  109  2018-08-20
#[Out]# 16  109  2018-08-20
#[Out]# 17  118  2018-08-20
#[Out]# 18  129  2018-08-20
#[Out]# 19  129  2018-08-20
#[Out]# 20  129  2018-08-20
#[Out]# 21  152  2018-08-20
#[Out]# 22  152  2018-08-20
#[Out]# 23  167  2018-08-20
#[Out]# 24  167  2018-08-20
#[Out]# 25  167  2018-08-20
#[Out]# 26  167  2018-08-20
#[Out]# 27  169  2018-08-20
#[Out]# 28  169  2018-08-20
#[Out]# 29  171  2018-08-20
#[Out]# 30  171  2018-08-20
#[Out]# 31  175  2018-08-20
#[Out]# 32  177  2018-08-20
#[Out]# 33  184  2018-08-20
#[Out]# 34  185  2018-08-20
#[Out]# 35  188  2018-08-20
#[Out]# 36  190  2018-08-20
#[Out]# 37  190  2018-08-20
#[Out]# 38  190  2018-08-20
#[Out]# 39  190  2018-08-20
# Wed, 09 Dec 2020 11:37:56

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date
    FROM purchase
    WHERE date = "2018-08-20" and cID = 1
    




'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cID        date
#[Out]# 0    1  2018-08-20
#[Out]# 1    1  2018-08-20
#[Out]# 2    1  2018-08-20
#[Out]# 3    1  2018-08-20
#[Out]# 4    1  2018-08-20
# Wed, 09 Dec 2020 11:38:06

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date
    FROM purchase
    WHERE date = "2018-08-20" and cID = 1
    GROUP BY cID, date





'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cID        date
#[Out]# 0    1  2018-08-20
# Wed, 09 Dec 2020 11:38:11

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date, price
    FROM purchase
    WHERE date = "2018-08-20" and cID = 1
    





'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cID        date  price
#[Out]# 0    1  2018-08-20   4.65
#[Out]# 1    1  2018-08-20   1.60
#[Out]# 2    1  2018-08-20   1.25
#[Out]# 3    1  2018-08-20   3.95
#[Out]# 4    1  2018-08-20   2.75
# Wed, 09 Dec 2020 11:38:35

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date, SUM(price)
    FROM purchase
    WHERE date = "2018-08-20" and cID = 1






'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cID        date  SUM(price)
#[Out]# 0    1  2018-08-20        14.2
# Wed, 09 Dec 2020 11:38:49

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date, SUM(price)
    FROM purchase
    WHERE date = "2018-08-20" and cID = 1
    GROUP BY cID, date






'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cID        date  SUM(price)
#[Out]# 0    1  2018-08-20        14.2
# Wed, 09 Dec 2020 11:38:57

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date






'''

pd.read_sql_query(query4_4, conn)

#[Out]#      cID        date  SUM(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# 5      3  2018-08-18        4.30
#[Out]# 6      3  2018-08-19        4.20
#[Out]# 7      4  2018-08-24       14.25
#[Out]# 8      4  2018-08-25       19.40
#[Out]# 9      5  2018-08-17        4.70
#[Out]# 10     5  2018-08-22        8.25
#[Out]# 11     5  2018-08-23        6.70
#[Out]# 12     7  2018-08-23        3.80
#[Out]# 13     7  2018-08-24        1.90
#[Out]# 14     7  2018-08-25       10.75
#[Out]# 15     7  2018-08-26        3.10
#[Out]# 16     8  2018-08-16        6.25
#[Out]# 17    10  2018-08-27        3.20
#[Out]# 18    11  2018-08-25        4.10
#[Out]# 19    13  2018-08-17       13.30
#[Out]# 20    13  2018-08-25        6.50
#[Out]# 21    13  2018-08-26        1.65
#[Out]# 22    13  2018-08-27        0.50
#[Out]# 23    15  2018-08-27        0.90
#[Out]# 24    16  2018-08-18        2.90
#[Out]# 25    16  2018-08-19       11.05
#[Out]# 26    16  2018-08-24        6.05
#[Out]# 27    16  2018-08-25        4.95
#[Out]# 28    16  2018-08-26        3.00
#[Out]# 29    16  2018-08-27        1.85
#[Out]# ..   ...         ...         ...
#[Out]# 255  178  2018-08-27        7.50
#[Out]# 256  179  2018-08-22       10.85
#[Out]# 257  179  2018-08-23        0.45
#[Out]# 258  179  2018-08-24        6.95
#[Out]# 259  180  2018-08-26        3.10
#[Out]# 260  180  2018-08-27        4.65
#[Out]# 261  181  2018-08-24        3.60
#[Out]# 262  181  2018-08-27        2.00
#[Out]# 263  182  2018-08-23        4.20
#[Out]# 264  182  2018-08-28       14.90
#[Out]# 265  184  2018-08-20        3.50
#[Out]# 266  185  2018-08-20        1.00
#[Out]# 267  186  2018-08-21        1.00
#[Out]# 268  188  2018-08-20        1.00
#[Out]# 269  188  2018-09-20        1.00
#[Out]# 270  189  2018-08-25        1.25
#[Out]# 271  189  2018-08-26        2.50
#[Out]# 272  190  2018-08-15       19.60
#[Out]# 273  190  2018-08-16       12.80
#[Out]# 274  190  2018-08-17       15.75
#[Out]# 275  190  2018-08-18       14.85
#[Out]# 276  190  2018-08-19       20.30
#[Out]# 277  190  2018-08-20       10.85
#[Out]# 278  190  2018-08-21        3.85
#[Out]# 279  190  2018-08-22       14.55
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 11:39:11

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT cID, date, MAX(SUM(price))
    FROM purchase
    GROUP BY cID, date






'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:39:21

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/
    
    
    SELECT SUM(price)
    FROM purchase
    GROUP BY cID, date






'''

pd.read_sql_query(query4_4, conn)

#[Out]#      SUM(price)
#[Out]# 0          0.45
#[Out]# 1         14.20
#[Out]# 2         10.00
#[Out]# 3          2.45
#[Out]# 4          7.70
#[Out]# 5          4.30
#[Out]# 6          4.20
#[Out]# 7         14.25
#[Out]# 8         19.40
#[Out]# 9          4.70
#[Out]# 10         8.25
#[Out]# 11         6.70
#[Out]# 12         3.80
#[Out]# 13         1.90
#[Out]# 14        10.75
#[Out]# 15         3.10
#[Out]# 16         6.25
#[Out]# 17         3.20
#[Out]# 18         4.10
#[Out]# 19        13.30
#[Out]# 20         6.50
#[Out]# 21         1.65
#[Out]# 22         0.50
#[Out]# 23         0.90
#[Out]# 24         2.90
#[Out]# 25        11.05
#[Out]# 26         6.05
#[Out]# 27         4.95
#[Out]# 28         3.00
#[Out]# 29         1.85
#[Out]# ..          ...
#[Out]# 255        7.50
#[Out]# 256       10.85
#[Out]# 257        0.45
#[Out]# 258        6.95
#[Out]# 259        3.10
#[Out]# 260        4.65
#[Out]# 261        3.60
#[Out]# 262        2.00
#[Out]# 263        4.20
#[Out]# 264       14.90
#[Out]# 265        3.50
#[Out]# 266        1.00
#[Out]# 267        1.00
#[Out]# 268        1.00
#[Out]# 269        1.00
#[Out]# 270        1.25
#[Out]# 271        2.50
#[Out]# 272       19.60
#[Out]# 273       12.80
#[Out]# 274       15.75
#[Out]# 275       14.85
#[Out]# 276       20.30
#[Out]# 277       10.85
#[Out]# 278        3.85
#[Out]# 279       14.55
#[Out]# 280       10.60
#[Out]# 281        3.25
#[Out]# 282        9.80
#[Out]# 283       21.90
#[Out]# 284        5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 11:39:49

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/
    
    SELECT MAX(sumprice) 
    FROM (
        SELECT SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
    )






'''

pd.read_sql_query(query4_4, conn)

#[Out]#    MAX(sumprice)
#[Out]# 0           39.1
# Wed, 09 Dec 2020 11:39:57

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
    






'''

pd.read_sql_query(query4_4, conn)

#[Out]#      sumPrice
#[Out]# 0        0.45
#[Out]# 1       14.20
#[Out]# 2       10.00
#[Out]# 3        2.45
#[Out]# 4        7.70
#[Out]# 5        4.30
#[Out]# 6        4.20
#[Out]# 7       14.25
#[Out]# 8       19.40
#[Out]# 9        4.70
#[Out]# 10       8.25
#[Out]# 11       6.70
#[Out]# 12       3.80
#[Out]# 13       1.90
#[Out]# 14      10.75
#[Out]# 15       3.10
#[Out]# 16       6.25
#[Out]# 17       3.20
#[Out]# 18       4.10
#[Out]# 19      13.30
#[Out]# 20       6.50
#[Out]# 21       1.65
#[Out]# 22       0.50
#[Out]# 23       0.90
#[Out]# 24       2.90
#[Out]# 25      11.05
#[Out]# 26       6.05
#[Out]# 27       4.95
#[Out]# 28       3.00
#[Out]# 29       1.85
#[Out]# ..        ...
#[Out]# 255      7.50
#[Out]# 256     10.85
#[Out]# 257      0.45
#[Out]# 258      6.95
#[Out]# 259      3.10
#[Out]# 260      4.65
#[Out]# 261      3.60
#[Out]# 262      2.00
#[Out]# 263      4.20
#[Out]# 264     14.90
#[Out]# 265      3.50
#[Out]# 266      1.00
#[Out]# 267      1.00
#[Out]# 268      1.00
#[Out]# 269      1.00
#[Out]# 270      1.25
#[Out]# 271      2.50
#[Out]# 272     19.60
#[Out]# 273     12.80
#[Out]# 274     15.75
#[Out]# 275     14.85
#[Out]# 276     20.30
#[Out]# 277     10.85
#[Out]# 278      3.85
#[Out]# 279     14.55
#[Out]# 280     10.60
#[Out]# 281      3.25
#[Out]# 282      9.80
#[Out]# 283     21.90
#[Out]# 284      5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 11:40:18

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
        ORDER BY SUM(price)
    






'''

pd.read_sql_query(query4_4, conn)

#[Out]#      sumPrice
#[Out]# 0        0.40
#[Out]# 1        0.45
#[Out]# 2        0.45
#[Out]# 3        0.45
#[Out]# 4        0.45
#[Out]# 5        0.50
#[Out]# 6        0.50
#[Out]# 7        0.55
#[Out]# 8        0.55
#[Out]# 9        0.60
#[Out]# 10       0.80
#[Out]# 11       0.85
#[Out]# 12       0.90
#[Out]# 13       0.90
#[Out]# 14       0.90
#[Out]# 15       0.90
#[Out]# 16       0.95
#[Out]# 17       0.95
#[Out]# 18       1.00
#[Out]# 19       1.00
#[Out]# 20       1.00
#[Out]# 21       1.00
#[Out]# 22       1.00
#[Out]# 23       1.00
#[Out]# 24       1.00
#[Out]# 25       1.00
#[Out]# 26       1.05
#[Out]# 27       1.05
#[Out]# 28       1.10
#[Out]# 29       1.10
#[Out]# ..        ...
#[Out]# 255     13.30
#[Out]# 256     13.35
#[Out]# 257     13.40
#[Out]# 258     13.55
#[Out]# 259     13.65
#[Out]# 260     14.20
#[Out]# 261     14.25
#[Out]# 262     14.55
#[Out]# 263     14.85
#[Out]# 264     14.90
#[Out]# 265     15.10
#[Out]# 266     15.20
#[Out]# 267     15.55
#[Out]# 268     15.75
#[Out]# 269     15.75
#[Out]# 270     15.75
#[Out]# 271     15.85
#[Out]# 272     16.75
#[Out]# 273     18.35
#[Out]# 274     19.40
#[Out]# 275     19.60
#[Out]# 276     20.20
#[Out]# 277     20.30
#[Out]# 278     20.70
#[Out]# 279     21.30
#[Out]# 280     21.90
#[Out]# 281     22.25
#[Out]# 282     23.95
#[Out]# 283     28.80
#[Out]# 284     39.10
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 11:40:28

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
        DESC ORDER BY SUM(price)







'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:40:37

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
        ORDER BY DESC SUM(price)







'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:41:06

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/


        SELECT SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
        ORDER BY SUM(price) DESC







'''

pd.read_sql_query(query4_4, conn)

#[Out]#      sumPrice
#[Out]# 0       39.10
#[Out]# 1       28.80
#[Out]# 2       23.95
#[Out]# 3       22.25
#[Out]# 4       21.90
#[Out]# 5       21.30
#[Out]# 6       20.70
#[Out]# 7       20.30
#[Out]# 8       20.20
#[Out]# 9       19.60
#[Out]# 10      19.40
#[Out]# 11      18.35
#[Out]# 12      16.75
#[Out]# 13      15.85
#[Out]# 14      15.75
#[Out]# 15      15.75
#[Out]# 16      15.75
#[Out]# 17      15.55
#[Out]# 18      15.20
#[Out]# 19      15.10
#[Out]# 20      14.90
#[Out]# 21      14.85
#[Out]# 22      14.55
#[Out]# 23      14.25
#[Out]# 24      14.20
#[Out]# 25      13.65
#[Out]# 26      13.55
#[Out]# 27      13.40
#[Out]# 28      13.35
#[Out]# 29      13.30
#[Out]# ..        ...
#[Out]# 255      1.10
#[Out]# 256      1.10
#[Out]# 257      1.05
#[Out]# 258      1.05
#[Out]# 259      1.00
#[Out]# 260      1.00
#[Out]# 261      1.00
#[Out]# 262      1.00
#[Out]# 263      1.00
#[Out]# 264      1.00
#[Out]# 265      1.00
#[Out]# 266      1.00
#[Out]# 267      0.95
#[Out]# 268      0.95
#[Out]# 269      0.90
#[Out]# 270      0.90
#[Out]# 271      0.90
#[Out]# 272      0.90
#[Out]# 273      0.85
#[Out]# 274      0.80
#[Out]# 275      0.60
#[Out]# 276      0.55
#[Out]# 277      0.55
#[Out]# 278      0.50
#[Out]# 279      0.50
#[Out]# 280      0.45
#[Out]# 281      0.45
#[Out]# 282      0.45
#[Out]# 283      0.45
#[Out]# 284      0.40
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 11:41:16

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT MAX(sumprice)
    FROM (
        SELECT SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
    )






'''

pd.read_sql_query(query4_4, conn)

#[Out]#    MAX(sumprice)
#[Out]# 0           39.1
# Wed, 09 Dec 2020 11:41:23

query4_4 = '''
    /*SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(price)
        FROM purchase
    )*/

    SELECT MAX(sumPrice)
    FROM (
        SELECT SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
    )






'''

pd.read_sql_query(query4_4, conn)

#[Out]#    MAX(sumPrice)
#[Out]# 0           39.1
# Wed, 09 Dec 2020 11:41:53

query4_4 = '''
    SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price >= 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )








'''

pd.read_sql_query(query4_4, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:42:06

query4_4 = '''
    SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price > 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )








'''

pd.read_sql_query(query4_4, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:42:12

query4_4 = '''
    SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )








'''

pd.read_sql_query(query4_4, conn)

#[Out]#       cName
#[Out]# 0      Noah
#[Out]# 1       Sem
#[Out]# 2       Sem
#[Out]# 3       Sem
#[Out]# 4       Sem
#[Out]# 5       Sem
#[Out]# 6       Sem
#[Out]# 7       Sem
#[Out]# 8     Lucas
#[Out]# 9     Lucas
#[Out]# 10    Lucas
#[Out]# 11    Lucas
#[Out]# 12    Lucas
#[Out]# 13     Finn
#[Out]# 14     Finn
#[Out]# 15     Finn
#[Out]# 16     Daan
#[Out]# 17     Daan
#[Out]# 18     Daan
#[Out]# 19     Daan
#[Out]# 20     Daan
#[Out]# 21     Daan
#[Out]# 22     Levi
#[Out]# 23     Levi
#[Out]# 24     Levi
#[Out]# 25     Levi
#[Out]# 26     Levi
#[Out]# 27     Levi
#[Out]# 28     Bram
#[Out]# 29     Bram
#[Out]# ..      ...
#[Out]# 479  Kostas
#[Out]# 480  Kostas
#[Out]# 481  Kostas
#[Out]# 482  Kostas
#[Out]# 483  Kostas
#[Out]# 484  Kostas
#[Out]# 485  Kostas
#[Out]# 486  Kostas
#[Out]# 487  Kostas
#[Out]# 488  Kostas
#[Out]# 489  Kostas
#[Out]# 490  Kostas
#[Out]# 491  Kostas
#[Out]# 492  Kostas
#[Out]# 493  Kostas
#[Out]# 494  Kostas
#[Out]# 495  Kostas
#[Out]# 496  Kostas
#[Out]# 497  Kostas
#[Out]# 498  Kostas
#[Out]# 499  Kostas
#[Out]# 500  Kostas
#[Out]# 501  Kostas
#[Out]# 502  Kostas
#[Out]# 503  Kostas
#[Out]# 504  Kostas
#[Out]# 505  Kostas
#[Out]# 506  Kostas
#[Out]# 507  Kostas
#[Out]# 508  Kostas
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Wed, 09 Dec 2020 11:42:35

query4_4 = '''
    SELECT c.cName, SUM(p.price)
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )








'''

pd.read_sql_query(query4_4, conn)

#[Out]#   cName  SUM(p.price)
#[Out]# 0  Noah        1675.2
# Wed, 09 Dec 2020 11:43:02

query4_4 = '''
    SELECT c.cName, SUM(p.price)
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )
    GROUP BY c.cName, p.tID








'''

pd.read_sql_query(query4_4, conn)

#[Out]#          cName  SUM(p.price)
#[Out]# 0        Aiden          3.45
#[Out]# 1        Aiden          0.50
#[Out]# 2    Alexander          3.30
#[Out]# 3        Amira          0.90
#[Out]# 4        Amira          3.85
#[Out]# 5        Amira          4.35
#[Out]# 6        Amira          0.90
#[Out]# 7        Amira          2.15
#[Out]# 8        Amira          0.50
#[Out]# 9          Amy          6.40
#[Out]# 10      Angela          1.00
#[Out]# 11        Anna          2.95
#[Out]# 12        Anne          1.85
#[Out]# 13        Anne          2.00
#[Out]# 14        Anne          2.20
#[Out]# 15    Benjamin          3.45
#[Out]# 16    Benjamin          2.40
#[Out]# 17    Benjamin          7.05
#[Out]# 18       Boris          1.15
#[Out]# 19       Boris          2.95
#[Out]# 20       Boris          2.30
#[Out]# 21       Boris          1.65
#[Out]# 22        Bram          2.10
#[Out]# 23        Bram          1.70
#[Out]# 24        Bram          1.90
#[Out]# 25        Bram         10.75
#[Out]# 26        Bram          1.05
#[Out]# 27        Bram          2.05
#[Out]# 28      Casper          6.70
#[Out]# 29        Cato          4.65
#[Out]# ..         ...           ...
#[Out]# 474       Tijn          1.20
#[Out]# 475       Tijn          1.90
#[Out]# 476        Tim          0.95
#[Out]# 477        Tim          3.50
#[Out]# 478        Tim          1.65
#[Out]# 479        Tim          1.20
#[Out]# 480        Tim          3.55
#[Out]# 481        Tim          1.60
#[Out]# 482        Tom          2.90
#[Out]# 483        Tom          1.60
#[Out]# 484        Tom          3.85
#[Out]# 485        Tom          6.90
#[Out]# 486     Veerle          1.00
#[Out]# 487     Veerle          2.30
#[Out]# 488     Veerle          2.25
#[Out]# 489     Veerle          3.00
#[Out]# 490     Veerle          2.10
#[Out]# 491     Veerle          1.15
#[Out]# 492     Veerle          5.00
#[Out]# 493     Veerle          4.00
#[Out]# 494     Veerle          1.70
#[Out]# 495     Veerle          2.05
#[Out]# 496      Wilko          3.50
#[Out]# 497     Willem          0.50
#[Out]# 498     Willem          0.90
#[Out]# 499     Willem         13.80
#[Out]# 500       Xavi          2.10
#[Out]# 501       Yara          1.20
#[Out]# 502       Yara          4.80
#[Out]# 503       Yara          1.40
#[Out]# 
#[Out]# [504 rows x 2 columns]
# Wed, 09 Dec 2020 11:43:14

query4_4 = '''
    SELECT c.cName, SUM(p.price)
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )
    GROUP BY c.cName, p.tID
    ORDER BY p.price DESC








'''

pd.read_sql_query(query4_4, conn)

#[Out]#        cName  SUM(p.price)
#[Out]# 0     Willem         13.80
#[Out]# 1       Lynn         13.65
#[Out]# 2       Daan         13.60
#[Out]# 3      Dylan         13.40
#[Out]# 4        Ivy         13.25
#[Out]# 5      Elena         13.15
#[Out]# 6       Sven         12.80
#[Out]# 7    Thijmen         12.65
#[Out]# 8      Lieke         12.55
#[Out]# 9      Fenne         12.30
#[Out]# 10     Fenna         12.20
#[Out]# 11     Dylan         12.00
#[Out]# 12     Sofie         11.65
#[Out]# 13      Luca         11.55
#[Out]# 14      Teun         11.45
#[Out]# 15     Lotte         11.20
#[Out]# 16      Bram         10.75
#[Out]# 17      Ties         10.60
#[Out]# 18      Dean         10.50
#[Out]# 19      Jack         10.30
#[Out]# 20     Milou         10.15
#[Out]# 21      Iris          9.85
#[Out]# 22   Johanna         11.00
#[Out]# 23       Kai          9.70
#[Out]# 24     Elena          9.65
#[Out]# 25      Jens          9.60
#[Out]# 26     Stijn          9.45
#[Out]# 27      Ella          9.25
#[Out]# 28    Julian          9.25
#[Out]# 29       Sem          9.10
#[Out]# ..       ...           ...
#[Out]# 474     Luca          0.60
#[Out]# 475    Merel          0.60
#[Out]# 476     Teun          0.60
#[Out]# 477     Cato          0.55
#[Out]# 478   Julian          0.55
#[Out]# 479    Jurre          0.55
#[Out]# 480   Kostas          0.55
#[Out]# 481     Lily          0.55
#[Out]# 482     Luca          0.55
#[Out]# 483    Aiden          0.50
#[Out]# 484    Amira          0.50
#[Out]# 485     Dani          0.50
#[Out]# 486    Dylan          0.50
#[Out]# 487    James          0.50
#[Out]# 488   Kostas          0.50
#[Out]# 489   Kostas          0.50
#[Out]# 490   Kostas          0.50
#[Out]# 491     Sara          0.50
#[Out]# 492    Sofie          0.50
#[Out]# 493   Willem          0.50
#[Out]# 494    Esmee          0.45
#[Out]# 495    Hanna          0.45
#[Out]# 496    Hidde          0.45
#[Out]# 497     Juul          0.45
#[Out]# 498     Mats          0.45
#[Out]# 499     Noah          0.45
#[Out]# 500     Cato          0.40
#[Out]# 501     Dani          0.40
#[Out]# 502    James          0.40
#[Out]# 503     Lily          0.40
#[Out]# 
#[Out]# [504 rows x 2 columns]
# Wed, 09 Dec 2020 11:43:31

query4_4 = '''
    SELECT c.cName, SUM(p.price)
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )








'''

pd.read_sql_query(query4_4, conn)

#[Out]#   cName  SUM(p.price)
#[Out]# 0  Noah        1675.2
# Wed, 09 Dec 2020 11:43:38

query4_4 = '''
    SELECT c.cName
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )








'''

pd.read_sql_query(query4_4, conn)

#[Out]#       cName
#[Out]# 0      Noah
#[Out]# 1       Sem
#[Out]# 2       Sem
#[Out]# 3       Sem
#[Out]# 4       Sem
#[Out]# 5       Sem
#[Out]# 6       Sem
#[Out]# 7       Sem
#[Out]# 8     Lucas
#[Out]# 9     Lucas
#[Out]# 10    Lucas
#[Out]# 11    Lucas
#[Out]# 12    Lucas
#[Out]# 13     Finn
#[Out]# 14     Finn
#[Out]# 15     Finn
#[Out]# 16     Daan
#[Out]# 17     Daan
#[Out]# 18     Daan
#[Out]# 19     Daan
#[Out]# 20     Daan
#[Out]# 21     Daan
#[Out]# 22     Levi
#[Out]# 23     Levi
#[Out]# 24     Levi
#[Out]# 25     Levi
#[Out]# 26     Levi
#[Out]# 27     Levi
#[Out]# 28     Bram
#[Out]# 29     Bram
#[Out]# ..      ...
#[Out]# 479  Kostas
#[Out]# 480  Kostas
#[Out]# 481  Kostas
#[Out]# 482  Kostas
#[Out]# 483  Kostas
#[Out]# 484  Kostas
#[Out]# 485  Kostas
#[Out]# 486  Kostas
#[Out]# 487  Kostas
#[Out]# 488  Kostas
#[Out]# 489  Kostas
#[Out]# 490  Kostas
#[Out]# 491  Kostas
#[Out]# 492  Kostas
#[Out]# 493  Kostas
#[Out]# 494  Kostas
#[Out]# 495  Kostas
#[Out]# 496  Kostas
#[Out]# 497  Kostas
#[Out]# 498  Kostas
#[Out]# 499  Kostas
#[Out]# 500  Kostas
#[Out]# 501  Kostas
#[Out]# 502  Kostas
#[Out]# 503  Kostas
#[Out]# 504  Kostas
#[Out]# 505  Kostas
#[Out]# 506  Kostas
#[Out]# 507  Kostas
#[Out]# 508  Kostas
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Wed, 09 Dec 2020 11:43:45

query4_4 = '''
    SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )








'''

pd.read_sql_query(query4_4, conn)

#[Out]#       cName  price
#[Out]# 0      Noah   0.45
#[Out]# 1       Sem   4.65
#[Out]# 2       Sem   1.60
#[Out]# 3       Sem   1.25
#[Out]# 4       Sem   3.95
#[Out]# 5       Sem   2.75
#[Out]# 6       Sem   0.90
#[Out]# 7       Sem   9.10
#[Out]# 8     Lucas   2.45
#[Out]# 9     Lucas   1.35
#[Out]# 10    Lucas   1.10
#[Out]# 11    Lucas   3.70
#[Out]# 12    Lucas   1.55
#[Out]# 13     Finn   4.30
#[Out]# 14     Finn   2.75
#[Out]# 15     Finn   1.45
#[Out]# 16     Daan   4.15
#[Out]# 17     Daan   9.05
#[Out]# 18     Daan  13.60
#[Out]# 19     Daan   1.05
#[Out]# 20     Daan   3.05
#[Out]# 21     Daan   2.75
#[Out]# 22     Levi   4.70
#[Out]# 23     Levi   8.25
#[Out]# 24     Levi   1.10
#[Out]# 25     Levi   1.55
#[Out]# 26     Levi   1.85
#[Out]# 27     Levi   2.20
#[Out]# 28     Bram   2.10
#[Out]# 29     Bram   1.70
#[Out]# ..      ...    ...
#[Out]# 479  Kostas   2.80
#[Out]# 480  Kostas   0.50
#[Out]# 481  Kostas   2.55
#[Out]# 482  Kostas   0.65
#[Out]# 483  Kostas   0.70
#[Out]# 484  Kostas   3.70
#[Out]# 485  Kostas   3.50
#[Out]# 486  Kostas   2.95
#[Out]# 487  Kostas   2.75
#[Out]# 488  Kostas   1.50
#[Out]# 489  Kostas   0.85
#[Out]# 490  Kostas   3.55
#[Out]# 491  Kostas   2.60
#[Out]# 492  Kostas   3.25
#[Out]# 493  Kostas   4.30
#[Out]# 494  Kostas   3.05
#[Out]# 495  Kostas   4.05
#[Out]# 496  Kostas   1.50
#[Out]# 497  Kostas   2.50
#[Out]# 498  Kostas   3.95
#[Out]# 499  Kostas   3.50
#[Out]# 500  Kostas   2.95
#[Out]# 501  Kostas   1.60
#[Out]# 502  Kostas   3.25
#[Out]# 503  Kostas   0.75
#[Out]# 504  Kostas   3.80
#[Out]# 505  Kostas   4.35
#[Out]# 506  Kostas   2.85
#[Out]# 507  Kostas   3.15
#[Out]# 508  Kostas   3.30
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Wed, 09 Dec 2020 11:43:59

query4_4 = '''
    SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )
    ORDER BY p.price DESC








'''

pd.read_sql_query(query4_4, conn)

#[Out]#        cName  price
#[Out]# 0     Willem  13.80
#[Out]# 1       Lynn  13.65
#[Out]# 2       Daan  13.60
#[Out]# 3      Dylan  13.40
#[Out]# 4        Ivy  13.25
#[Out]# 5      Elena  13.15
#[Out]# 6       Sven  12.80
#[Out]# 7    Thijmen  12.65
#[Out]# 8      Lieke  12.55
#[Out]# 9      Fenne  12.30
#[Out]# 10     Fenna  12.20
#[Out]# 11     Dylan  12.00
#[Out]# 12     Sofie  11.65
#[Out]# 13      Luca  11.55
#[Out]# 14      Teun  11.45
#[Out]# 15     Lotte  11.20
#[Out]# 16      Bram  10.75
#[Out]# 17      Ties  10.60
#[Out]# 18      Dean  10.50
#[Out]# 19      Jack  10.30
#[Out]# 20     Milou  10.15
#[Out]# 21      Iris   9.85
#[Out]# 22       Kai   9.70
#[Out]# 23   Johanna   9.70
#[Out]# 24     Elena   9.65
#[Out]# 25      Jens   9.60
#[Out]# 26     Stijn   9.45
#[Out]# 27    Julian   9.25
#[Out]# 28      Ella   9.25
#[Out]# 29       Sem   9.10
#[Out]# ..       ...    ...
#[Out]# 479     Teun   0.60
#[Out]# 480    Merel   0.60
#[Out]# 481   Kostas   0.60
#[Out]# 482   Julian   0.55
#[Out]# 483     Luca   0.55
#[Out]# 484    Jurre   0.55
#[Out]# 485     Cato   0.55
#[Out]# 486     Lily   0.55
#[Out]# 487   Kostas   0.55
#[Out]# 488    James   0.50
#[Out]# 489   Willem   0.50
#[Out]# 490    Aiden   0.50
#[Out]# 491     Dani   0.50
#[Out]# 492    Dylan   0.50
#[Out]# 493     Sara   0.50
#[Out]# 494    Sofie   0.50
#[Out]# 495    Amira   0.50
#[Out]# 496   Kostas   0.50
#[Out]# 497   Kostas   0.50
#[Out]# 498   Kostas   0.50
#[Out]# 499     Noah   0.45
#[Out]# 500     Mats   0.45
#[Out]# 501    Hidde   0.45
#[Out]# 502    Esmee   0.45
#[Out]# 503    Hanna   0.45
#[Out]# 504     Juul   0.45
#[Out]# 505    James   0.40
#[Out]# 506     Dani   0.40
#[Out]# 507     Cato   0.40
#[Out]# 508     Lily   0.40
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Wed, 09 Dec 2020 11:44:02

query4_4 = '''
    SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )
    ORDER BY p.price DESC








'''

pd.read_sql_query(query4_4, conn)

#[Out]#        cName  price
#[Out]# 0     Willem  13.80
#[Out]# 1       Lynn  13.65
#[Out]# 2       Daan  13.60
#[Out]# 3      Dylan  13.40
#[Out]# 4        Ivy  13.25
#[Out]# 5      Elena  13.15
#[Out]# 6       Sven  12.80
#[Out]# 7    Thijmen  12.65
#[Out]# 8      Lieke  12.55
#[Out]# 9      Fenne  12.30
#[Out]# 10     Fenna  12.20
#[Out]# 11     Dylan  12.00
#[Out]# 12     Sofie  11.65
#[Out]# 13      Luca  11.55
#[Out]# 14      Teun  11.45
#[Out]# 15     Lotte  11.20
#[Out]# 16      Bram  10.75
#[Out]# 17      Ties  10.60
#[Out]# 18      Dean  10.50
#[Out]# 19      Jack  10.30
#[Out]# 20     Milou  10.15
#[Out]# 21      Iris   9.85
#[Out]# 22       Kai   9.70
#[Out]# 23   Johanna   9.70
#[Out]# 24     Elena   9.65
#[Out]# 25      Jens   9.60
#[Out]# 26     Stijn   9.45
#[Out]# 27    Julian   9.25
#[Out]# 28      Ella   9.25
#[Out]# 29       Sem   9.10
#[Out]# ..       ...    ...
#[Out]# 479     Teun   0.60
#[Out]# 480    Merel   0.60
#[Out]# 481   Kostas   0.60
#[Out]# 482   Julian   0.55
#[Out]# 483     Luca   0.55
#[Out]# 484    Jurre   0.55
#[Out]# 485     Cato   0.55
#[Out]# 486     Lily   0.55
#[Out]# 487   Kostas   0.55
#[Out]# 488    James   0.50
#[Out]# 489   Willem   0.50
#[Out]# 490    Aiden   0.50
#[Out]# 491     Dani   0.50
#[Out]# 492    Dylan   0.50
#[Out]# 493     Sara   0.50
#[Out]# 494    Sofie   0.50
#[Out]# 495    Amira   0.50
#[Out]# 496   Kostas   0.50
#[Out]# 497   Kostas   0.50
#[Out]# 498   Kostas   0.50
#[Out]# 499     Noah   0.45
#[Out]# 500     Mats   0.45
#[Out]# 501    Hidde   0.45
#[Out]# 502    Esmee   0.45
#[Out]# 503    Hanna   0.45
#[Out]# 504     Juul   0.45
#[Out]# 505    James   0.40
#[Out]# 506     Dani   0.40
#[Out]# 507     Cato   0.40
#[Out]# 508     Lily   0.40
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Wed, 09 Dec 2020 11:52:35

query4_4 = '''

    select p.cID, date, price
    FROM purchase as p 

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID
    
    
    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/

    






'''

pd.read_sql_query(query4_4, conn)

#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   4.65
#[Out]# 2      1  2018-08-20   1.60
#[Out]# 3      1  2018-08-20   1.25
#[Out]# 4      1  2018-08-20   3.95
#[Out]# 5      1  2018-08-20   2.75
#[Out]# 6      1  2018-08-21   0.90
#[Out]# 7      1  2018-08-21   9.10
#[Out]# 8      2  2018-08-16   2.45
#[Out]# 9      2  2018-08-17   1.35
#[Out]# 10     2  2018-08-17   1.10
#[Out]# 11     2  2018-08-17   3.70
#[Out]# 12     2  2018-08-17   1.55
#[Out]# 13     3  2018-08-18   4.30
#[Out]# 14     3  2018-08-19   2.75
#[Out]# 15     3  2018-08-19   1.45
#[Out]# 16     4  2018-08-24   4.15
#[Out]# 17     4  2018-08-24   9.05
#[Out]# 18     4  2018-08-25  13.60
#[Out]# 19     4  2018-08-24   1.05
#[Out]# 20     4  2018-08-25   3.05
#[Out]# 21     4  2018-08-25   2.75
#[Out]# 22     5  2018-08-17   4.70
#[Out]# 23     5  2018-08-22   8.25
#[Out]# 24     5  2018-08-23   1.10
#[Out]# 25     5  2018-08-23   1.55
#[Out]# 26     5  2018-08-23   1.85
#[Out]# 27     5  2018-08-23   2.20
#[Out]# 28     7  2018-08-23   2.10
#[Out]# 29     7  2018-08-23   1.70
#[Out]# ..   ...         ...    ...
#[Out]# 479  190  2018-08-20   2.80
#[Out]# 480  190  2018-08-15   0.50
#[Out]# 481  190  2018-08-23   2.55
#[Out]# 482  190  2018-08-15   0.65
#[Out]# 483  190  2018-08-24   0.70
#[Out]# 484  190  2018-08-25   3.70
#[Out]# 485  190  2018-08-15   3.50
#[Out]# 486  190  2018-08-15   2.95
#[Out]# 487  190  2018-08-22   2.75
#[Out]# 488  190  2018-08-17   1.50
#[Out]# 489  190  2018-08-18   0.85
#[Out]# 490  190  2018-08-19   3.55
#[Out]# 491  190  2018-08-25   2.60
#[Out]# 492  190  2018-08-17   3.25
#[Out]# 493  190  2018-08-26   4.30
#[Out]# 494  190  2018-08-17   3.05
#[Out]# 495  190  2018-08-22   4.05
#[Out]# 496  190  2018-08-19   1.50
#[Out]# 497  190  2018-08-15   2.50
#[Out]# 498  190  2018-08-18   3.95
#[Out]# 499  190  2018-08-25   3.50
#[Out]# 500  190  2018-08-18   2.95
#[Out]# 501  190  2018-08-15   1.60
#[Out]# 502  190  2018-08-22   3.25
#[Out]# 503  190  2018-08-19   0.75
#[Out]# 504  190  2018-08-26   3.80
#[Out]# 505  190  2018-08-27   4.35
#[Out]# 506  190  2018-08-23   2.85
#[Out]# 507  190  2018-08-16   3.15
#[Out]# 508  190  2018-08-21   3.30
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Wed, 09 Dec 2020 11:52:38

query4_4 = '''

    select p.cID, date, price
    FROM purchase as p 

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   4.65
#[Out]# 2      1  2018-08-20   1.60
#[Out]# 3      1  2018-08-20   1.25
#[Out]# 4      1  2018-08-20   3.95
#[Out]# 5      1  2018-08-20   2.75
#[Out]# 6      1  2018-08-21   0.90
#[Out]# 7      1  2018-08-21   9.10
#[Out]# 8      2  2018-08-16   2.45
#[Out]# 9      2  2018-08-17   1.35
#[Out]# 10     2  2018-08-17   1.10
#[Out]# 11     2  2018-08-17   3.70
#[Out]# 12     2  2018-08-17   1.55
#[Out]# 13     3  2018-08-18   4.30
#[Out]# 14     3  2018-08-19   2.75
#[Out]# 15     3  2018-08-19   1.45
#[Out]# 16     4  2018-08-24   4.15
#[Out]# 17     4  2018-08-24   9.05
#[Out]# 18     4  2018-08-25  13.60
#[Out]# 19     4  2018-08-24   1.05
#[Out]# 20     4  2018-08-25   3.05
#[Out]# 21     4  2018-08-25   2.75
#[Out]# 22     5  2018-08-17   4.70
#[Out]# 23     5  2018-08-22   8.25
#[Out]# 24     5  2018-08-23   1.10
#[Out]# 25     5  2018-08-23   1.55
#[Out]# 26     5  2018-08-23   1.85
#[Out]# 27     5  2018-08-23   2.20
#[Out]# 28     7  2018-08-23   2.10
#[Out]# 29     7  2018-08-23   1.70
#[Out]# ..   ...         ...    ...
#[Out]# 479  190  2018-08-20   2.80
#[Out]# 480  190  2018-08-15   0.50
#[Out]# 481  190  2018-08-23   2.55
#[Out]# 482  190  2018-08-15   0.65
#[Out]# 483  190  2018-08-24   0.70
#[Out]# 484  190  2018-08-25   3.70
#[Out]# 485  190  2018-08-15   3.50
#[Out]# 486  190  2018-08-15   2.95
#[Out]# 487  190  2018-08-22   2.75
#[Out]# 488  190  2018-08-17   1.50
#[Out]# 489  190  2018-08-18   0.85
#[Out]# 490  190  2018-08-19   3.55
#[Out]# 491  190  2018-08-25   2.60
#[Out]# 492  190  2018-08-17   3.25
#[Out]# 493  190  2018-08-26   4.30
#[Out]# 494  190  2018-08-17   3.05
#[Out]# 495  190  2018-08-22   4.05
#[Out]# 496  190  2018-08-19   1.50
#[Out]# 497  190  2018-08-15   2.50
#[Out]# 498  190  2018-08-18   3.95
#[Out]# 499  190  2018-08-25   3.50
#[Out]# 500  190  2018-08-18   2.95
#[Out]# 501  190  2018-08-15   1.60
#[Out]# 502  190  2018-08-22   3.25
#[Out]# 503  190  2018-08-19   0.75
#[Out]# 504  190  2018-08-26   3.80
#[Out]# 505  190  2018-08-27   4.35
#[Out]# 506  190  2018-08-23   2.85
#[Out]# 507  190  2018-08-16   3.15
#[Out]# 508  190  2018-08-21   3.30
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Wed, 09 Dec 2020 11:53:07

query4_4 = '''

    select p.cID, date, SUM(price)
    FROM purchase as p
    GROUP BY DATE 

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

#[Out]#     cID        date  SUM(price)
#[Out]# 0    21  2018-08-15       59.65
#[Out]# 1     2  2018-08-16       88.25
#[Out]# 2     2  2018-08-17      139.15
#[Out]# 3     3  2018-08-18      126.40
#[Out]# 4     3  2018-08-19      121.55
#[Out]# 5     1  2018-08-20      103.75
#[Out]# 6     1  2018-08-21       80.40
#[Out]# 7     0  2018-08-22      115.80
#[Out]# 8     5  2018-08-23      127.25
#[Out]# 9     4  2018-08-24      167.50
#[Out]# 10    4  2018-08-25      167.65
#[Out]# 11    7  2018-08-26      217.20
#[Out]# 12   10  2018-08-27      100.65
#[Out]# 13   22  2018-08-28       47.10
#[Out]# 14   39  2018-08-29       11.90
#[Out]# 15  188  2018-09-20        1.00
# Wed, 09 Dec 2020 11:53:22

query4_4 = '''

    select p.cID, date, SUM(price)
    FROM purchase as p
    GROUP BY p.date, p.cID

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

#[Out]#      cID        date  SUM(price)
#[Out]# 0     21  2018-08-15        3.45
#[Out]# 1     30  2018-08-15        0.60
#[Out]# 2     37  2018-08-15        4.90
#[Out]# 3     42  2018-08-15        1.20
#[Out]# 4     59  2018-08-15        2.20
#[Out]# 5    108  2018-08-15       23.95
#[Out]# 6    167  2018-08-15        3.75
#[Out]# 7    190  2018-08-15       19.60
#[Out]# 8      2  2018-08-16        2.45
#[Out]# 9      8  2018-08-16        6.25
#[Out]# 10    18  2018-08-16        4.40
#[Out]# 11    21  2018-08-16        2.40
#[Out]# 12    27  2018-08-16        1.20
#[Out]# 13    33  2018-08-16        2.30
#[Out]# 14    40  2018-08-16       11.50
#[Out]# 15    45  2018-08-16        1.80
#[Out]# 16    55  2018-08-16        3.45
#[Out]# 17    57  2018-08-16        0.80
#[Out]# 18    59  2018-08-16        1.75
#[Out]# 19    66  2018-08-16        5.25
#[Out]# 20    80  2018-08-16        5.55
#[Out]# 21    96  2018-08-16        1.30
#[Out]# 22   162  2018-08-16        1.65
#[Out]# 23   168  2018-08-16        5.65
#[Out]# 24   169  2018-08-16        1.90
#[Out]# 25   170  2018-08-16       15.85
#[Out]# 26   190  2018-08-16       12.80
#[Out]# 27     2  2018-08-17        7.70
#[Out]# 28     5  2018-08-17        4.70
#[Out]# 29    13  2018-08-17       13.30
#[Out]# ..   ...         ...         ...
#[Out]# 255   16  2018-08-27        1.85
#[Out]# 256   22  2018-08-27        8.05
#[Out]# 257   27  2018-08-27        1.65
#[Out]# 258   28  2018-08-27        1.10
#[Out]# 259   31  2018-08-27        0.90
#[Out]# 260   33  2018-08-27       16.75
#[Out]# 261   58  2018-08-27        0.55
#[Out]# 262   67  2018-08-27        6.35
#[Out]# 263   68  2018-08-27        1.65
#[Out]# 264   91  2018-08-27        6.60
#[Out]# 265   92  2018-08-27        9.85
#[Out]# 266  110  2018-08-27        5.15
#[Out]# 267  157  2018-08-27        6.25
#[Out]# 268  163  2018-08-27        8.20
#[Out]# 269  169  2018-08-27        0.55
#[Out]# 270  172  2018-08-27        0.90
#[Out]# 271  178  2018-08-27        7.50
#[Out]# 272  180  2018-08-27        4.65
#[Out]# 273  181  2018-08-27        2.00
#[Out]# 274  190  2018-08-27        5.55
#[Out]# 275   22  2018-08-28        0.45
#[Out]# 276   25  2018-08-28        2.55
#[Out]# 277   31  2018-08-28        3.90
#[Out]# 278   39  2018-08-28       12.80
#[Out]# 279   69  2018-08-28        6.05
#[Out]# 280  157  2018-08-28        1.80
#[Out]# 281  169  2018-08-28        4.65
#[Out]# 282  182  2018-08-28       14.90
#[Out]# 283   39  2018-08-29       11.90
#[Out]# 284  188  2018-09-20        1.00
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 11:53:51

query4_4 = '''

    select p.cID, date, SUM(price)
    FROM purchase as p
    GROUP BY p.date, p.cID
    WHERE SUM(p.price) > 10

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:53:58

query4_4 = '''

    select p.cID, date, SUM(price)
    FROM purchase as p
    GROUP BY p.date, p.cID
    HAVING SUM(p.price) > 10

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

#[Out]#     cID        date  SUM(price)
#[Out]# 0   108  2018-08-15       23.95
#[Out]# 1   190  2018-08-15       19.60
#[Out]# 2    40  2018-08-16       11.50
#[Out]# 3   170  2018-08-16       15.85
#[Out]# 4   190  2018-08-16       12.80
#[Out]# 5    13  2018-08-17       13.30
#[Out]# 6    86  2018-08-17       15.10
#[Out]# 7   123  2018-08-17       20.20
#[Out]# 8   190  2018-08-17       15.75
#[Out]# 9    20  2018-08-18       12.50
#[Out]# 10   30  2018-08-18       13.35
#[Out]# 11   35  2018-08-18       12.25
#[Out]# 12  109  2018-08-18       13.65
#[Out]# 13  190  2018-08-18       14.85
#[Out]# 14   16  2018-08-19       11.05
#[Out]# 15   51  2018-08-19       15.75
#[Out]# 16   75  2018-08-19       10.60
#[Out]# 17  190  2018-08-19       20.30
#[Out]# 18    1  2018-08-20       14.20
#[Out]# 19   24  2018-08-20       20.70
#[Out]# 20  190  2018-08-20       10.85
#[Out]# 21  113  2018-08-21       15.55
#[Out]# 22  162  2018-08-22       18.35
#[Out]# 23  179  2018-08-22       10.85
#[Out]# 24  190  2018-08-22       14.55
#[Out]# 25   59  2018-08-23       12.05
#[Out]# 26   82  2018-08-23       21.30
#[Out]# 27  103  2018-08-23       11.20
#[Out]# 28  144  2018-08-23       13.25
#[Out]# 29  190  2018-08-23       10.60
#[Out]# 30    4  2018-08-24       14.25
#[Out]# 31   71  2018-08-24       22.25
#[Out]# 32   82  2018-08-24       13.40
#[Out]# 33   95  2018-08-24       12.35
#[Out]# 34  116  2018-08-24       12.55
#[Out]# 35  162  2018-08-24       13.15
#[Out]# 36    4  2018-08-25       19.40
#[Out]# 37    7  2018-08-25       10.75
#[Out]# 38   52  2018-08-25       15.20
#[Out]# 39   70  2018-08-25       11.75
#[Out]# 40   91  2018-08-26       13.55
#[Out]# 41  113  2018-08-26       10.30
#[Out]# 42  124  2018-08-26       28.80
#[Out]# 43  159  2018-08-26       15.75
#[Out]# 44  161  2018-08-26       39.10
#[Out]# 45  190  2018-08-26       21.90
#[Out]# 46   33  2018-08-27       16.75
#[Out]# 47   39  2018-08-28       12.80
#[Out]# 48  182  2018-08-28       14.90
#[Out]# 49   39  2018-08-29       11.90
# Wed, 09 Dec 2020 11:54:15

query4_4 = '''

    select p.cID, date, SUM(price)
    FROM purchase as p
    GROUP BY p.date, p.cID
    HAVING SUM(p.price) > 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:54:54

query4_4 = '''

    select p.cID, date, SUM(price)
    FROM purchase as p
    GROUP BY p.date, p.cID
    HAVING SUM(p.price) > 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cID        date  SUM(price)
#[Out]# 0  161  2018-08-26        39.1
# Wed, 09 Dec 2020 11:55:12

query4_4 = '''

    select p.cID, date, SUM(price)
    FROM purchase as p
    GROUP BY p.date, p.cID
    HAVING SUM(p.price) > 0.5 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cID        date  SUM(price)
#[Out]# 0  108  2018-08-15       23.95
#[Out]# 1  190  2018-08-15       19.60
#[Out]# 2  123  2018-08-17       20.20
#[Out]# 3  190  2018-08-19       20.30
#[Out]# 4   24  2018-08-20       20.70
#[Out]# 5   82  2018-08-23       21.30
#[Out]# 6   71  2018-08-24       22.25
#[Out]# 7  124  2018-08-26       28.80
#[Out]# 8  161  2018-08-26       39.10
#[Out]# 9  190  2018-08-26       21.90
# Wed, 09 Dec 2020 11:56:09

query4_4 = '''

    
    select p.cID, date, SUM(price)
    FROM purchase as p
    GROUP BY p.date, p.cID
    HAVING SUM(p.price) > 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )
    INNER JOIN customer

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

# Wed, 09 Dec 2020 11:56:39

query4_4 = '''


    select p.cID, date, SUM(price)
    FROM purchase as p
    INNER JOIN customer as c ON c.cID = p.cID
    GROUP BY p.date, p.cID
    HAVING SUM(p.price) > 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cID        date  SUM(price)
#[Out]# 0  161  2018-08-26        39.1
# Wed, 09 Dec 2020 11:56:55

query4_4 = '''


    select c.cname
    FROM purchase as p
    INNER JOIN customer as c ON c.cID = p.cID
    GROUP BY p.date, p.cID
    HAVING SUM(p.price) > 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )

    /*SELECT c.cName, p.price
    FROM customer as c
    INNER JOIN purchase as p on c.cID = p.cID


    WHERE p.price < 0.75 * (
        SELECT MAX(sumPrice)
        FROM (
            SELECT SUM(price) as sumPrice
            FROM purchase
            GROUP BY cID, date
        )
    )*/








'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 11:59:25

query4_5 = '''
    SELECT c.cname
    From city as c
'''

pd.read_sql_query(query4_5, conn)

# Wed, 09 Dec 2020 11:59:35

query4_5 = '''
    SELECT c.cName
    From city as c
'''

pd.read_sql_query(query4_5, conn)

# Wed, 09 Dec 2020 11:59:48

query4_5 = '''
    SELECT c.cName
    From customer as c
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         cName
#[Out]# 0        Noah
#[Out]# 1         Sem
#[Out]# 2       Lucas
#[Out]# 3        Finn
#[Out]# 4        Daan
#[Out]# 5        Levi
#[Out]# 6       Milan
#[Out]# 7        Bram
#[Out]# 8        Liam
#[Out]# 9      Thomas
#[Out]# 10        Sam
#[Out]# 11      Thijs
#[Out]# 12       Adam
#[Out]# 13      James
#[Out]# 14        Max
#[Out]# 15       Noud
#[Out]# 16     Julian
#[Out]# 17        Dex
#[Out]# 18       Hugo
#[Out]# 19       Lars
#[Out]# 20       Gijs
#[Out]# 21   Benjamin
#[Out]# 22       Mats
#[Out]# 23        Jan
#[Out]# 24       Luca
#[Out]# 25      Mason
#[Out]# 26     Jayden
#[Out]# 27        Tim
#[Out]# 28       Siem
#[Out]# 29      Ruben
#[Out]# ..        ...
#[Out]# 160      Lara
#[Out]# 161     Floor
#[Out]# 162     Elena
#[Out]# 163      Cato
#[Out]# 164       Evy
#[Out]# 165     Hanna
#[Out]# 166   Rosalie
#[Out]# 167    Veerle
#[Out]# 168      Kiki
#[Out]# 169      Lily
#[Out]# 170      Iris
#[Out]# 171     Tessa
#[Out]# 172      Lana
#[Out]# 173     Livia
#[Out]# 174      Romy
#[Out]# 175       Sam
#[Out]# 176     Amira
#[Out]# 177     Eline
#[Out]# 178      Elif
#[Out]# 179      Juul
#[Out]# 180     Merel
#[Out]# 181      Liva
#[Out]# 182   Johanna
#[Out]# 183     Nikki
#[Out]# 184     Wilko
#[Out]# 185      Nick
#[Out]# 186    Angela
#[Out]# 187      Pino
#[Out]# 188      Koen
#[Out]# 189    Kostas
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Wed, 09 Dec 2020 11:59:52

query4_5 = '''
    SELECT c.city
    From customer as c
'''

pd.read_sql_query(query4_5, conn)

#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# 5      Utrecht
#[Out]# 6      Utrecht
#[Out]# 7    Eindhoven
#[Out]# 8        Breda
#[Out]# 9    Amsterdam
#[Out]# 10     Tilburg
#[Out]# 11     Tilburg
#[Out]# 12   Eindhoven
#[Out]# 13       Breda
#[Out]# 14     Tilburg
#[Out]# 15     Tilburg
#[Out]# 16   Eindhoven
#[Out]# 17     Tilburg
#[Out]# 18     Tilburg
#[Out]# 19       Breda
#[Out]# 20   Amsterdam
#[Out]# 21     Tilburg
#[Out]# 22   Eindhoven
#[Out]# 23       Breda
#[Out]# 24     Tilburg
#[Out]# 25   Rotterdam
#[Out]# 26   Eindhoven
#[Out]# 27     Utrecht
#[Out]# 28     Tilburg
#[Out]# 29   Rotterdam
#[Out]# ..         ...
#[Out]# 160    Tilburg
#[Out]# 161    Tilburg
#[Out]# 162  Rotterdam
#[Out]# 163    Tilburg
#[Out]# 164      Breda
#[Out]# 165    Tilburg
#[Out]# 166  Eindhoven
#[Out]# 167      Breda
#[Out]# 168  Rotterdam
#[Out]# 169    Utrecht
#[Out]# 170  Eindhoven
#[Out]# 171  Rotterdam
#[Out]# 172    Tilburg
#[Out]# 173      Breda
#[Out]# 174  Eindhoven
#[Out]# 175  Eindhoven
#[Out]# 176  Amsterdam
#[Out]# 177  Amsterdam
#[Out]# 178    Utrecht
#[Out]# 179    Tilburg
#[Out]# 180  Amsterdam
#[Out]# 181  Eindhoven
#[Out]# 182  Eindhoven
#[Out]# 183    Utrecht
#[Out]# 184  Eindhoven
#[Out]# 185  Eindhoven
#[Out]# 186  Eindhoven
#[Out]# 187  Rotterdam
#[Out]# 188        Oss
#[Out]# 189    Utrecht
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Wed, 09 Dec 2020 12:00:53

query4_5 = '''
    SELECT c.city
    From customer as c
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 12:01:05

query4_5 = '''
    SELECT c.city, sum(sName)
    From customer as c
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)

# Wed, 09 Dec 2020 12:01:15

query4_5 = '''
    SELECT c.city, SUM(c.cName)
    From customer as c
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  SUM(c.cName)
#[Out]# 0  Amsterdam           0.0
#[Out]# 1      Breda           0.0
#[Out]# 2  Eindhoven           0.0
#[Out]# 3        Oss           0.0
#[Out]# 4  Rotterdam           0.0
#[Out]# 5    Tilburg           0.0
#[Out]# 6    Utrecht           0.0
# Wed, 09 Dec 2020 12:01:23

query4_5 = '''
    SELECT c.city, COUNT(c.cName)
    From customer as c
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cName)
#[Out]# 0  Amsterdam              26
#[Out]# 1      Breda              27
#[Out]# 2  Eindhoven              33
#[Out]# 3        Oss               1
#[Out]# 4  Rotterdam              29
#[Out]# 5    Tilburg              38
#[Out]# 6    Utrecht              36
# Wed, 09 Dec 2020 12:02:58

query4_5 = '''
    SELECT c.city, COUNT(c.cName)
    From customer as c
    GROUP BY c.city
    HAVING c.cID EXISTS in (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
    
    )
'''

pd.read_sql_query(query4_5, conn)

# Wed, 09 Dec 2020 12:03:03

query4_5 = '''
    SELECT c.city, COUNT(c.cName)
    From customer as c
    GROUP BY c.city
    HAVING c.cID EXISTS  (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID

    )
'''

pd.read_sql_query(query4_5, conn)

# Wed, 09 Dec 2020 12:03:09

query4_5 = '''
    SELECT c.city, COUNT(c.cName)
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cName)
#[Out]# 0  Amsterdam              26
#[Out]# 1      Breda              27
#[Out]# 2  Eindhoven              33
#[Out]# 3        Oss               1
#[Out]# 4  Rotterdam              29
#[Out]# 5    Tilburg              38
#[Out]# 6    Utrecht              36
# Wed, 09 Dec 2020 12:03:47

query4_5 = '''
    SELECT c.city, COUNT(c.cName)
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cName)
#[Out]# 0  Amsterdam              26
#[Out]# 1      Breda              27
#[Out]# 2  Eindhoven              33
#[Out]# 3  Rotterdam              29
# Wed, 09 Dec 2020 12:03:55

query4_5 = '''
    SELECT c.city, COUNT(c.cName), city
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cName)       city
#[Out]# 0  Amsterdam              26  Amsterdam
#[Out]# 1      Breda              27      Breda
#[Out]# 2  Eindhoven              33  Eindhoven
#[Out]# 3  Rotterdam              29  Rotterdam
# Wed, 09 Dec 2020 12:04:17

query4_5 = '''
    SELECT c.city, COUNT(c.cID)
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam            26
#[Out]# 1      Breda            27
#[Out]# 2  Eindhoven            33
#[Out]# 3  Rotterdam            29
# Wed, 09 Dec 2020 12:04:20

query4_5 = '''
    SELECT c.city, COUNT(c.cName)
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cName)
#[Out]# 0  Amsterdam              26
#[Out]# 1      Breda              27
#[Out]# 2  Eindhoven              33
#[Out]# 3  Rotterdam              29
# Wed, 09 Dec 2020 12:04:23

query4_5 = '''
    SELECT c.city, COUNT(c.cName)
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cName)
#[Out]# 0  Amsterdam              26
#[Out]# 1      Breda              27
#[Out]# 2  Eindhoven              33
#[Out]# 3  Rotterdam              29
# Wed, 09 Dec 2020 12:04:23

query4_5 = '''
    SELECT c.city, COUNT(c.cName)
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cName)
#[Out]# 0  Amsterdam              26
#[Out]# 1      Breda              27
#[Out]# 2  Eindhoven              33
#[Out]# 3  Rotterdam              29
# Wed, 09 Dec 2020 12:04:33

query4_5 = '''
    SELECT c.city, COUNT(c.cName), COUNT(c.cID)
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cName)  COUNT(c.cID)
#[Out]# 0  Amsterdam              26            26
#[Out]# 1      Breda              27            27
#[Out]# 2  Eindhoven              33            33
#[Out]# 3  Rotterdam              29            29
# Wed, 09 Dec 2020 12:04:41

query4_5 = '''
    SELECT c.city, COUNT(c.cName)
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  COUNT(c.cName)
#[Out]# 0  Amsterdam              26
#[Out]# 1      Breda              27
#[Out]# 2  Eindhoven              33
#[Out]# 3  Rotterdam              29
# Wed, 09 Dec 2020 12:04:53

query4_5 = '''
    SELECT c.city, COUNT(c.cName) as customerCount
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  customerCount
#[Out]# 0  Amsterdam             26
#[Out]# 1      Breda             27
#[Out]# 2  Eindhoven             33
#[Out]# 3  Rotterdam             29
# Wed, 09 Dec 2020 12:05:00

query4_5 = '''
    SELECT c.city, COUNT(c.cName) as customerCountFromEindhoven
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  customerCountFromEindhoven
#[Out]# 0  Amsterdam                          26
#[Out]# 1      Breda                          27
#[Out]# 2  Eindhoven                          33
#[Out]# 3  Rotterdam                          29
# Wed, 09 Dec 2020 12:05:28

query4_5 = '''
    SELECT c.city, c.cName as customerCountFromEindhoven
    From customer as c
    GROUP BY c.city, c.cName
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#          city customerCountFromEindhoven
#[Out]# 0   Amsterdam                      Amira
#[Out]# 1   Amsterdam                       Daan
#[Out]# 2   Amsterdam                       Ella
#[Out]# 3   Amsterdam                       Joep
#[Out]# 4   Amsterdam                        Kai
#[Out]# 5   Amsterdam                       Lina
#[Out]# 6   Amsterdam                      Lucas
#[Out]# 7   Amsterdam                      Merel
#[Out]# 8   Amsterdam                       Puck
#[Out]# 9   Amsterdam                      Sofie
#[Out]# 10      Breda                       Dani
#[Out]# 11      Breda                       Finn
#[Out]# 12      Breda                       Jace
#[Out]# 13      Breda                      James
#[Out]# 14      Breda                       Lynn
#[Out]# 15      Breda                       Niek
#[Out]# 16      Breda                        Sem
#[Out]# 17      Breda                       Sven
#[Out]# 18      Breda                     Veerle
#[Out]# 19  Eindhoven                     Angela
#[Out]# 20  Eindhoven                       Bram
#[Out]# 21  Eindhoven                      Dylan
#[Out]# 22  Eindhoven                       Emma
#[Out]# 23  Eindhoven                     Floris
#[Out]# 24  Eindhoven                       Iris
#[Out]# 25  Eindhoven                       Jack
#[Out]# 26  Eindhoven                    Johanna
#[Out]# 27  Eindhoven                     Julian
#[Out]# 28  Eindhoven                      Lizzy
#[Out]# 29  Eindhoven                       Mick
#[Out]# ..        ...                        ...
#[Out]# 39  Rotterdam                     Lauren
#[Out]# 40  Rotterdam                      Mason
#[Out]# 41  Rotterdam                      Milou
#[Out]# 42  Rotterdam                    Olivier
#[Out]# 43  Rotterdam                       Pino
#[Out]# 44  Rotterdam                     Sophie
#[Out]# 45  Rotterdam                      Tessa
#[Out]# 46  Rotterdam                       Teun
#[Out]# 47    Tilburg                       Cato
#[Out]# 48    Tilburg                       Elin
#[Out]# 49    Tilburg                      Floor
#[Out]# 50    Tilburg                      Hanna
#[Out]# 51    Tilburg                       Juul
#[Out]# 52    Tilburg                       Lenn
#[Out]# 53    Tilburg                      Lieke
#[Out]# 54    Tilburg                       Luca
#[Out]# 55    Tilburg                       Noor
#[Out]# 56    Tilburg                       Sara
#[Out]# 57    Utrecht                       Elif
#[Out]# 58    Utrecht                      Esmee
#[Out]# 59    Utrecht                      Fenne
#[Out]# 60    Utrecht                     Isabel
#[Out]# 61    Utrecht                     Kostas
#[Out]# 62    Utrecht                       Levi
#[Out]# 63    Utrecht                       Lily
#[Out]# 64    Utrecht                   Mohammed
#[Out]# 65    Utrecht                     Pieter
#[Out]# 66    Utrecht                      Quinn
#[Out]# 67    Utrecht                       Ryan
#[Out]# 68    Utrecht                        Tim
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Wed, 09 Dec 2020 12:05:40

query4_5 = '''
    SELECT c.city, COUNT(c.cName) as customerCountFromEindhoven
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  customerCountFromEindhoven
#[Out]# 0  Amsterdam                          26
#[Out]# 1      Breda                          27
#[Out]# 2  Eindhoven                          33
#[Out]# 3  Rotterdam                          29
# Wed, 09 Dec 2020 12:05:44

query4_5 = '''
    SELECT c.city, COUNT(c.cName) as customerCountFromEindhoven
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  customerCountFromEindhoven
#[Out]# 0  Amsterdam                          26
#[Out]# 1      Breda                          27
#[Out]# 2  Eindhoven                          33
#[Out]# 3  Rotterdam                          29

# IPython log file

# Wed, 09 Dec 2020 12:32:59

# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 

# Wed, 09 Dec 2020 12:32:59

# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)

# Wed, 09 Dec 2020 12:33:09

query4_3 = '''

    SELECT sName, city
    FROM store
    GROUP BY sName
    HAVING count(distinct city) = (

        SELECT count(distinct city)
        FROM (
            SELECT city
            FROM customer
            UNION
            SELECT city
            FROM store
        ) as ccsc
    )
'''

pd.read_sql_query(query4_3, conn)

#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:34:27

query4_4 = '''
select c.cname
FROM purchase as p
INNER JOIN customer as c ON c.cID = p.cID
GROUP BY p.date, p.cID
HAVING SUM(p.price) > 0.75 * (
    SELECT MAX(sumPrice)
    FROM (
        SELECT SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
    ) as psP
)
'''

pd.read_sql_query(query4_4, conn)

#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 12:34:47

query4_5 = '''
    SELECT c.city, COUNT(c.cName) as customerCountFromEindhoven
    From customer as c
    GROUP BY c.city
    HAVING c.cID IN (
        SELECT c.Cid
        FROM customer as c
        INNER JOIN purchase as p ON c.cID = p.cID
        INNER JOIN store as s ON p.sID = s.sID
        WHERE s.city = "Eindhoven"

    )
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  customerCountFromEindhoven
#[Out]# 0  Amsterdam                          26
#[Out]# 1      Breda                          27
#[Out]# 2  Eindhoven                          33
#[Out]# 3  Rotterdam                          29
# Wed, 09 Dec 2020 12:35:07

query4_5 = '''
SELECT c.city, COUNT(c.cName) as customerCount
From customer as c
GROUP BY c.city
HAVING c.cID IN (
    SELECT c.Cid
    FROM customer as c
    INNER JOIN purchase as p ON c.cID = p.cID
    INNER JOIN store as s ON p.sID = s.sID
    WHERE s.city = "Eindhoven"

)
'''

pd.read_sql_query(query4_5, conn)

#[Out]#         city  customerCount
#[Out]# 0  Amsterdam             26
#[Out]# 1      Breda             27
#[Out]# 2  Eindhoven             33
#[Out]# 3  Rotterdam             29


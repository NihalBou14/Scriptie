# IPython log file


# IPython log file

# Sun, 06 Dec 2020 16:53:20
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 06 Dec 2020 16:53:27
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7f4203daf3b0>
# Sun, 06 Dec 2020 17:00:24
query4_3 = '''
    SELECT *
'''
# Sun, 06 Dec 2020 17:00:31
query4_3 = '''
    SELECT *
    FROM customer
'''
# Sun, 06 Dec 2020 17:00:46
query4_3 = '''
    SELECT *
    FROM customer
'''
pd.read_sql_query(query4_3, conn)
#[Out]#      cID   cName            street       city
#[Out]# 0      0    Noah         Koestraat    Utrecht
#[Out]# 1      1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 3      3    Finn     Stationsplein      Breda
#[Out]# 4      4    Daan      Kalverstraat  Amsterdam
#[Out]# ..   ...     ...               ...        ...
#[Out]# 185  185    Nick            Verweg  Eindhoven
#[Out]# 186  186  Angela          Dichtweg  Eindhoven
#[Out]# 187  188    Pino        Maanstraat  Rotterdam
#[Out]# 188  189    Koen          Akkerweg        Oss
#[Out]# 189  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Sun, 06 Dec 2020 17:01:23
query4_3 = '''
    (SELECT c.city
    FROM customer c) UNION 
    (SELECT s.city
    FROM store s)
'''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:02:08
query4_3 = '''
    SELECT c.city
    FROM customer c UNION 
    SELECT s.city
    FROM store s
'''
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 17:02:58
query4_3 = '''
    SELECT s.sName, s.city
    FROM store
'''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:03:03
query4_3 = '''
    SELECT s.sName, s.city
    FROM store s
'''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sun, 06 Dec 2020 17:03:42
query4_3 = '''
    SELECT s.sName, s.city
    FROM store s
'''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sun, 06 Dec 2020 17:12:06
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s.sName
    FROM store s
'''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Sun, 06 Dec 2020 17:13:16
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT s.sName, s.city
    FROM store s
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sun, 06 Dec 2020 17:13:25
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s.sName, s.city
    FROM store s
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Sun, 06 Dec 2020 17:13:42
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = 
# '''
#     SELECT DISTINCT s.sName, s.city
#     FROM store s
# '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
'''
    SELECT c.city
    FROM customer c UNION 
    SELECT s.city
    FROM store s
'''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:13:51
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
# '''
#     SELECT DISTINCT s.sName, s.city
#     FROM store s
# '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
#'''
    SELECT c.city
    FROM customer c UNION 
    SELECT s.city
    FROM store s
'''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:14:07
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''    SELECT c.city
    FROM customer c UNION 
    SELECT s.city
    FROM store s
'''
# '''
#     SELECT DISTINCT s.sName, s.city
#     FROM store s
# '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
#'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 17:14:26
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = 
'''
    SELECT DISTINCT s.sName, s.city
    FROM store s
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:14:31
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s.sName, s.city
    FROM store s
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Sun, 06 Dec 2020 17:14:44
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s.sName
    FROM store s
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Sun, 06 Dec 2020 17:15:01
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s.sName, s.city
    FROM store s
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Sun, 06 Dec 2020 17:16:00
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s.sName, s.city
    FROM store s
    ORDER BY s.sName ASC, s.city ASC
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Sun, 06 Dec 2020 17:20:07
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s.sName
    FROM store s
    ORDER BY s.sName ASC
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Sun, 06 Dec 2020 17:20:18
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT s.sName
    FROM store s
    ORDER BY s.sName ASC
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0   Albert Hein
#[Out]# 1   Albert Hein
#[Out]# 2   Albert Hein
#[Out]# 3   Albert Hein
#[Out]# 4   Albert Hein
#[Out]# ..          ...
#[Out]# 59       Sligro
#[Out]# 60       Sligro
#[Out]# 61       Sligro
#[Out]# 62       Sligro
#[Out]# 63       Sligro
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sun, 06 Dec 2020 17:21:47
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT *
    FROM customer c, store s
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#        cID   cName     street     city  sID      sName            street  \
#[Out]# 0        0    Noah  Koestraat  Utrecht    0       Coop      Kalverstraat   
#[Out]# 1        0    Noah  Koestraat  Utrecht    1  Hoogvliet  Rozemarijnstraat   
#[Out]# 2        0    Noah  Koestraat  Utrecht    2      Jumbo    Stadhoudersweg   
#[Out]# 3        0    Noah  Koestraat  Utrecht    3     Sligro    Stadhoudersweg   
#[Out]# 4        0    Noah  Koestraat  Utrecht    4  Hoogvliet       Molenstraat   
#[Out]# ...    ...     ...        ...      ...  ...        ...               ...   
#[Out]# 12155  190  Kostas   Eindeweg  Utrecht   59      Jumbo  Rozemarijnstraat   
#[Out]# 12156  190  Kostas   Eindeweg  Utrecht   60       Lidl      Pannekoekweg   
#[Out]# 12157  190  Kostas   Eindeweg  Utrecht   61       Lidl      Pannekoekweg   
#[Out]# 12158  190  Kostas   Eindeweg  Utrecht   62      Jumbo     Poffertjesweg   
#[Out]# 12159  190  Kostas   Eindeweg  Utrecht   63      Jumbo     Stationstraat   
#[Out]# 
#[Out]#             city  
#[Out]# 0      Amsterdam  
#[Out]# 1          Breda  
#[Out]# 2      Rotterdam  
#[Out]# 3      Rotterdam  
#[Out]# 4      Eindhoven  
#[Out]# ...          ...  
#[Out]# 12155      Breda  
#[Out]# 12156      Breda  
#[Out]# 12157      Breda  
#[Out]# 12158  Eindhoven  
#[Out]# 12159        Oss  
#[Out]# 
#[Out]# [12160 rows x 8 columns]
# Sun, 06 Dec 2020 17:22:19
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT *
    FROM customer c, store s
    WHERE s.city = c.city
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#       cID   cName     street     city  sID        sName          street  \
#[Out]# 0       0    Noah  Koestraat  Utrecht   44  Albert Hein   Ambachtstraat   
#[Out]# 1       0    Noah  Koestraat  Utrecht   32  Albert Hein      Hoogstraat   
#[Out]# 2       0    Noah  Koestraat  Utrecht   43         Coop  Gasthuisstraat   
#[Out]# 3       0    Noah  Koestraat  Utrecht   53         Coop      Hoogstraat   
#[Out]# 4       0    Noah  Koestraat  Utrecht   31         Coop     Parallelweg   
#[Out]# ...   ...     ...        ...      ...  ...          ...             ...   
#[Out]# 1963  190  Kostas   Eindeweg  Utrecht   53         Coop      Hoogstraat   
#[Out]# 1964  190  Kostas   Eindeweg  Utrecht   31         Coop     Parallelweg   
#[Out]# 1965  190  Kostas   Eindeweg  Utrecht   51         Coop     Parallelweg   
#[Out]# 1966  190  Kostas   Eindeweg  Utrecht   16         Lidl   Ambachtstraat   
#[Out]# 1967  190  Kostas   Eindeweg  Utrecht   35         Lidl   Julianastraat   
#[Out]# 
#[Out]#          city  
#[Out]# 0     Utrecht  
#[Out]# 1     Utrecht  
#[Out]# 2     Utrecht  
#[Out]# 3     Utrecht  
#[Out]# 4     Utrecht  
#[Out]# ...       ...  
#[Out]# 1963  Utrecht  
#[Out]# 1964  Utrecht  
#[Out]# 1965  Utrecht  
#[Out]# 1966  Utrecht  
#[Out]# 1967  Utrecht  
#[Out]# 
#[Out]# [1968 rows x 8 columns]
# Sun, 06 Dec 2020 17:24:31
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT *
    store s
    '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:24:37
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT *
    FROM store s
    '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0     0       Coop      Kalverstraat  Amsterdam
#[Out]# 1     1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59   59      Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60       Lidl      Pannekoekweg      Breda
#[Out]# 61   61       Lidl      Pannekoekweg      Breda
#[Out]# 62   62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63      Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Sun, 06 Dec 2020 17:24:45
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3_2 = '''
    SELECT *
    FROM store s
    '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3_2, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0     0       Coop      Kalverstraat  Amsterdam
#[Out]# 1     1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59   59      Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60       Lidl      Pannekoekweg      Breda
#[Out]# 61   61       Lidl      Pannekoekweg      Breda
#[Out]# 62   62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63      Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Sun, 06 Dec 2020 17:25:24
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3_2 = '''
    SELECT *
    FROM store
    ORDER BY sName ASC, city ASC
    '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3_2, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0    24  Albert Hein     Stationsplein      Breda
#[Out]# 1    25  Albert Hein     Stationsplein      Breda
#[Out]# 2     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 3    11  Albert Hein          Hofplein  Rotterdam
#[Out]# 4    41  Albert Hein        Bergselaan  Rotterdam
#[Out]# ..  ...          ...               ...        ...
#[Out]# 59   50       Sligro     Stationsplein      Breda
#[Out]# 60    7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 61   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 62    3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 63   18       Sligro       Parallelweg    Tilburg
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Sun, 06 Dec 2020 17:26:12
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3_2 = '''
    SELECT DISTINCT (sName, city)
    FROM store
    ORDER BY sName ASC, city ASC
    '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3_2, conn)
# Sun, 06 Dec 2020 17:26:33
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3_2 = '''
    SELECT DISTINCT sName, city
    FROM store
    ORDER BY sName ASC, city ASC
    '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3_2, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Sun, 06 Dec 2020 17:27:35
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT sName, city, sID
    FROM customer c, store s
    WHERE s.city = c.city
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:27:41
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT sName, s.city, sID
    FROM customer c, store s
    WHERE s.city = c.city
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#             sName     city  sID
#[Out]# 0     Albert Hein  Utrecht   32
#[Out]# 1     Albert Hein  Utrecht   44
#[Out]# 2            Coop  Utrecht   31
#[Out]# 3            Coop  Utrecht   43
#[Out]# 4            Coop  Utrecht   51
#[Out]# ...           ...      ...  ...
#[Out]# 1963         Coop  Utrecht   43
#[Out]# 1964         Coop  Utrecht   51
#[Out]# 1965         Coop  Utrecht   53
#[Out]# 1966         Lidl  Utrecht   16
#[Out]# 1967         Lidl  Utrecht   35
#[Out]# 
#[Out]# [1968 rows x 3 columns]
# Sun, 06 Dec 2020 17:28:41
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT sName
    FROM customer c, store s
    WHERE s.city = c.city
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#             sName
#[Out]# 0     Albert Hein
#[Out]# 1     Albert Hein
#[Out]# 2            Coop
#[Out]# 3            Coop
#[Out]# 4            Coop
#[Out]# ...           ...
#[Out]# 1963         Coop
#[Out]# 1964         Coop
#[Out]# 1965         Coop
#[Out]# 1966         Lidl
#[Out]# 1967         Lidl
#[Out]# 
#[Out]# [1968 rows x 1 columns]
# Sun, 06 Dec 2020 17:28:48
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT *
    FROM customer c, store s
    WHERE s.city = c.city
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#       cID   cName     street     city  sID        sName          street  \
#[Out]# 0       0    Noah  Koestraat  Utrecht   44  Albert Hein   Ambachtstraat   
#[Out]# 1       0    Noah  Koestraat  Utrecht   32  Albert Hein      Hoogstraat   
#[Out]# 2       0    Noah  Koestraat  Utrecht   43         Coop  Gasthuisstraat   
#[Out]# 3       0    Noah  Koestraat  Utrecht   53         Coop      Hoogstraat   
#[Out]# 4       0    Noah  Koestraat  Utrecht   31         Coop     Parallelweg   
#[Out]# ...   ...     ...        ...      ...  ...          ...             ...   
#[Out]# 1963  190  Kostas   Eindeweg  Utrecht   53         Coop      Hoogstraat   
#[Out]# 1964  190  Kostas   Eindeweg  Utrecht   31         Coop     Parallelweg   
#[Out]# 1965  190  Kostas   Eindeweg  Utrecht   51         Coop     Parallelweg   
#[Out]# 1966  190  Kostas   Eindeweg  Utrecht   16         Lidl   Ambachtstraat   
#[Out]# 1967  190  Kostas   Eindeweg  Utrecht   35         Lidl   Julianastraat   
#[Out]# 
#[Out]#          city  
#[Out]# 0     Utrecht  
#[Out]# 1     Utrecht  
#[Out]# 2     Utrecht  
#[Out]# 3     Utrecht  
#[Out]# 4     Utrecht  
#[Out]# ...       ...  
#[Out]# 1963  Utrecht  
#[Out]# 1964  Utrecht  
#[Out]# 1965  Utrecht  
#[Out]# 1966  Utrecht  
#[Out]# 1967  Utrecht  
#[Out]# 
#[Out]# [1968 rows x 8 columns]
# Sun, 06 Dec 2020 17:30:19
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT * 
    FROM store s
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0     0       Coop      Kalverstraat  Amsterdam
#[Out]# 1     1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59   59      Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60       Lidl      Pannekoekweg      Breda
#[Out]# 61   61       Lidl      Pannekoekweg      Breda
#[Out]# 62   62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63      Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Sun, 06 Dec 2020 17:31:12
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT city
    FROM store s
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Sun, 06 Dec 2020 17:31:29
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT *
    FROM store s1, store s2
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#       sID  sName         street       city  sID      sName            street  \
#[Out]# 0       0   Coop   Kalverstraat  Amsterdam    0       Coop      Kalverstraat   
#[Out]# 1       0   Coop   Kalverstraat  Amsterdam    1  Hoogvliet  Rozemarijnstraat   
#[Out]# 2       0   Coop   Kalverstraat  Amsterdam    2      Jumbo    Stadhoudersweg   
#[Out]# 3       0   Coop   Kalverstraat  Amsterdam    3     Sligro    Stadhoudersweg   
#[Out]# 4       0   Coop   Kalverstraat  Amsterdam    4  Hoogvliet       Molenstraat   
#[Out]# ...   ...    ...            ...        ...  ...        ...               ...   
#[Out]# 4091   63  Jumbo  Stationstraat        Oss   59      Jumbo  Rozemarijnstraat   
#[Out]# 4092   63  Jumbo  Stationstraat        Oss   60       Lidl      Pannekoekweg   
#[Out]# 4093   63  Jumbo  Stationstraat        Oss   61       Lidl      Pannekoekweg   
#[Out]# 4094   63  Jumbo  Stationstraat        Oss   62      Jumbo     Poffertjesweg   
#[Out]# 4095   63  Jumbo  Stationstraat        Oss   63      Jumbo     Stationstraat   
#[Out]# 
#[Out]#            city  
#[Out]# 0     Amsterdam  
#[Out]# 1         Breda  
#[Out]# 2     Rotterdam  
#[Out]# 3     Rotterdam  
#[Out]# 4     Eindhoven  
#[Out]# ...         ...  
#[Out]# 4091      Breda  
#[Out]# 4092      Breda  
#[Out]# 4093      Breda  
#[Out]# 4094  Eindhoven  
#[Out]# 4095        Oss  
#[Out]# 
#[Out]# [4096 rows x 8 columns]
# Sun, 06 Dec 2020 17:33:54
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT s1.sName, s2.city
    FROM store s1 CROSS JOIN store s2
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#       sName       city
#[Out]# 0      Coop  Amsterdam
#[Out]# 1      Coop      Breda
#[Out]# 2      Coop  Rotterdam
#[Out]# 3      Coop  Rotterdam
#[Out]# 4      Coop  Eindhoven
#[Out]# ...     ...        ...
#[Out]# 4091  Jumbo      Breda
#[Out]# 4092  Jumbo      Breda
#[Out]# 4093  Jumbo      Breda
#[Out]# 4094  Jumbo  Eindhoven
#[Out]# 4095  Jumbo        Oss
#[Out]# 
#[Out]# [4096 rows x 2 columns]
# Sun, 06 Dec 2020 17:34:05
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName, s2.city
    FROM store s1 CROSS JOIN store s2
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Rotterdam
#[Out]# 3          Coop  Eindhoven
#[Out]# 4          Coop    Tilburg
#[Out]# 5          Coop    Utrecht
#[Out]# 6          Coop        Oss
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Rotterdam
#[Out]# 10    Hoogvliet  Eindhoven
#[Out]# 11    Hoogvliet    Tilburg
#[Out]# 12    Hoogvliet    Utrecht
#[Out]# 13    Hoogvliet        Oss
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Rotterdam
#[Out]# 17        Jumbo  Eindhoven
#[Out]# 18        Jumbo    Tilburg
#[Out]# 19        Jumbo    Utrecht
#[Out]# 20        Jumbo        Oss
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Rotterdam
#[Out]# 24       Sligro  Eindhoven
#[Out]# 25       Sligro    Tilburg
#[Out]# 26       Sligro    Utrecht
#[Out]# 27       Sligro        Oss
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Rotterdam
#[Out]# 31  Albert Hein  Eindhoven
#[Out]# 32  Albert Hein    Tilburg
#[Out]# 33  Albert Hein    Utrecht
#[Out]# 34  Albert Hein        Oss
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Rotterdam
#[Out]# 38         Lidl  Eindhoven
#[Out]# 39         Lidl    Tilburg
#[Out]# 40         Lidl    Utrecht
#[Out]# 41         Lidl        Oss
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Rotterdam
#[Out]# 45         Dirk  Eindhoven
#[Out]# 46         Dirk    Tilburg
#[Out]# 47         Dirk    Utrecht
#[Out]# 48         Dirk        Oss
# Sun, 06 Dec 2020 17:36:22
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName, s2.city
    FROM store s1 CROSS JOIN store s2
    MINUS
    SELECT st.sName, st.city
    FROM store st
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:37:28
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName as sName, s2.city as city
    FROM store s1 CROSS JOIN store s2
    MINUS
    SELECT sName, city
    FROM store
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:39:09
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    (SELECT DISTINCT s1.sName as sName, s2.city as city
    FROM store s1 CROSS JOIN store s2)
    MINUS
    SELECT sName, city
    FROM store
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:39:42
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName as sName, s2.city as city
    FROM store s1 CROSS JOIN store s2
    MINUS
    (SELECT sName, city
    FROM store)
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:39:55
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName as sName, s2.city as city
    FROM store s1 CROSS JOIN store s2
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Rotterdam
#[Out]# 3          Coop  Eindhoven
#[Out]# 4          Coop    Tilburg
#[Out]# 5          Coop    Utrecht
#[Out]# 6          Coop        Oss
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Rotterdam
#[Out]# 10    Hoogvliet  Eindhoven
#[Out]# 11    Hoogvliet    Tilburg
#[Out]# 12    Hoogvliet    Utrecht
#[Out]# 13    Hoogvliet        Oss
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Rotterdam
#[Out]# 17        Jumbo  Eindhoven
#[Out]# 18        Jumbo    Tilburg
#[Out]# 19        Jumbo    Utrecht
#[Out]# 20        Jumbo        Oss
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Rotterdam
#[Out]# 24       Sligro  Eindhoven
#[Out]# 25       Sligro    Tilburg
#[Out]# 26       Sligro    Utrecht
#[Out]# 27       Sligro        Oss
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Rotterdam
#[Out]# 31  Albert Hein  Eindhoven
#[Out]# 32  Albert Hein    Tilburg
#[Out]# 33  Albert Hein    Utrecht
#[Out]# 34  Albert Hein        Oss
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Rotterdam
#[Out]# 38         Lidl  Eindhoven
#[Out]# 39         Lidl    Tilburg
#[Out]# 40         Lidl    Utrecht
#[Out]# 41         Lidl        Oss
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Rotterdam
#[Out]# 45         Dirk  Eindhoven
#[Out]# 46         Dirk    Tilburg
#[Out]# 47         Dirk    Utrecht
#[Out]# 48         Dirk        Oss
# Sun, 06 Dec 2020 17:41:00
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName as sName, s2.city as city
    FROM store s1 CROSS JOIN store s2
    EXCEPT
    SELECT sName, city
    FROM store
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Sun, 06 Dec 2020 17:43:00
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3_2 = # '''
    SELECT c.city
    FROM customer c UNION 
    SELECT s.city
    FROM store s
'''

# '''
#     SELECT DISTINCT sName, city
#     FROM store
#     ORDER BY sName ASC, city ASC
#     '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3_2, conn)
# Sun, 06 Dec 2020 17:43:07
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3_2 =  '''
    SELECT c.city
    FROM customer c UNION 
    SELECT s.city
    FROM store s
'''

# '''
#     SELECT DISTINCT sName, city
#     FROM store
#     ORDER BY sName ASC, city ASC
#     '''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3_2, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 17:43:24
vis.visualize(query4_3, schema)
# Sun, 06 Dec 2020 17:46:32
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName as sName, ci.city as city
    FROM store s1 CROSS JOIN (
                             SELECT c.city
                             FROM customer c UNION 
                             SELECT s.city
                             FROM store s) ci
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Sun, 06 Dec 2020 17:47:23
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName as sName, ci.city as city
    FROM store s1 CROSS JOIN (
                             SELECT c.city
                             FROM customer c UNION 
                             SELECT s.city
                             FROM store s) ci
    WHERE (sName, city) NOT IN
    SELECT st.sName, st.city 
    FROM store st
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:47:39
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName as sName, ci.city as city
    FROM store s1 CROSS JOIN (
                             SELECT c.city
                             FROM customer c UNION 
                             SELECT s.city
                             FROM store s) ci
    WHERE (sName, city) NOT IN
    (SELECT sName, city 
    FROM store)
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:47:50
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName as sName, ci.city as city
    FROM store s1 CROSS JOIN (
                             SELECT c.city
                             FROM customer c UNION 
                             SELECT s.city
                             FROM store s) ci
    WHERE (sName, city) NOT IN
    (SELECT s.sName, s.city 
    FROM store s)
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:48:18
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT s1.sName as sName, ci.city as city
    FROM store s1 CROSS JOIN (
                             SELECT c.city
                             FROM customer c UNION 
                             SELECT s.city
                             FROM store s) ci
    WHERE (s1.sName, ci.city) NOT IN
    (SELECT s.sName, s.city 
    FROM store s)
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Eindhoven
#[Out]# 1          Coop        Oss
#[Out]# 2     Hoogvliet  Amsterdam
#[Out]# 3     Hoogvliet        Oss
#[Out]# 4     Hoogvliet    Utrecht
#[Out]# 5         Jumbo  Amsterdam
#[Out]# 6         Jumbo    Utrecht
#[Out]# 7        Sligro        Oss
#[Out]# 8        Sligro    Utrecht
#[Out]# 9   Albert Hein  Amsterdam
#[Out]# 10  Albert Hein        Oss
#[Out]# 11         Lidl        Oss
#[Out]# 12         Lidl    Tilburg
#[Out]# 13         Dirk  Amsterdam
#[Out]# 14         Dirk        Oss
#[Out]# 15         Dirk    Tilburg
#[Out]# 16         Dirk    Utrecht
# Sun, 06 Dec 2020 17:49:51
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT DISTINCT sName
    FROM (
    SELECT DISTINCT s1.sName as sName, ci.city as city
    FROM store s1 CROSS JOIN (
                             SELECT c.city
                             FROM customer c UNION 
                             SELECT s.city
                             FROM store s) ci
    WHERE (s1.sName, ci.city) NOT IN
    (SELECT s.sName, s.city 
    FROM store s)
    )
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Sun, 06 Dec 2020 17:50:27
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT reg.sName FROM store reg
    MINUS
    SELECT DISTINCT sName
    FROM (
    SELECT DISTINCT s1.sName as sName, ci.city as city
    FROM store s1 CROSS JOIN (
                             SELECT c.city
                             FROM customer c UNION 
                             SELECT s.city
                             FROM store s) ci
    WHERE (s1.sName, ci.city) NOT IN
    (SELECT s.sName, s.city 
    FROM store s)
    )
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 17:51:04
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT reg.sName FROM store reg
    WHERE reg.sName NOT IN
    (
    SELECT DISTINCT sName
    FROM (
    SELECT DISTINCT s1.sName as sName, ci.city as city
    FROM store s1 CROSS JOIN (
                             SELECT c.city
                             FROM customer c UNION 
                             SELECT s.city
                             FROM store s) ci
    WHERE (s1.sName, ci.city) NOT IN
    (SELECT s.sName, s.city 
    FROM store s)
    )
    )
'''
# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sun, 06 Dec 2020 17:58:45
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3 = '''
    SELECT reg.sName FROM store reg
    WHERE reg.sName NOT IN
    (
    SELECT DISTINCT sName
    FROM (
    SELECT DISTINCT s1.sName as sName, ci.city as city
    FROM store s1 CROSS JOIN (
                             SELECT c.city
                             FROM customer c UNION 
                             SELECT s.city
                             FROM store s) ci
    WHERE (s1.sName, ci.city) NOT IN
    (SELECT s.sName, s.city 
    FROM store s)
    )
    )
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sun, 06 Dec 2020 17:59:14
# Koje prodavnice ima u svakom gradu??
# Output su samo imena prodavnica
query4_3_2 =  '''
    SELECT DISTINCT sName, city
    FROM store
    ORDER BY sName ASC, city ASC
    '''

# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''

# Sva imena prodza
# '''
#     SELECT DISTINCT s.sName
#     FROM store s
# '''
# '''
#     SELECT c.city
#     FROM customer c UNION 
#     SELECT s.city
#     FROM store s
# '''
pd.read_sql_query(query4_3_2, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Sun, 06 Dec 2020 18:00:07
get_ipython().run_cell_magic('writefile', 'question2.txt', 'SELECT reg.sName FROM store reg\n    WHERE reg.sName NOT IN\n    (\n    SELECT DISTINCT sName\n    FROM (\n    SELECT DISTINCT s1.sName as sName, ci.city as city\n    FROM store s1 CROSS JOIN (\n                             SELECT c.city\n                             FROM customer c UNION \n                             SELECT s.city\n                             FROM store s) ci\n    WHERE (s1.sName, ci.city) NOT IN\n    (SELECT s.sName, s.city \n    FROM store s)));\n')
# Sun, 06 Dec 2020 18:02:36
query4_4 = '''
    SELECT * 
    FROM purchase
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Sun, 06 Dec 2020 18:03:03
query4_4 = '''
    SELECT cID, quantity, price
    FROM purchase
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      cID  quantity  price
#[Out]# 0      0         1   0.45
#[Out]# 1      1         2   4.65
#[Out]# 2      1         3   1.60
#[Out]# 3      1         2   1.25
#[Out]# 4      1         4   3.95
#[Out]# ..   ...       ...    ...
#[Out]# 504  190         2   3.80
#[Out]# 505  190         6   4.35
#[Out]# 506  190         5   2.85
#[Out]# 507  190         2   3.15
#[Out]# 508  190         1   3.30
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Sun, 06 Dec 2020 18:03:13
query4_4 = '''
    SELECT cID, date, price
    FROM purchase
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   4.65
#[Out]# 2      1  2018-08-20   1.60
#[Out]# 3      1  2018-08-20   1.25
#[Out]# 4      1  2018-08-20   3.95
#[Out]# ..   ...         ...    ...
#[Out]# 504  190  2018-08-26   3.80
#[Out]# 505  190  2018-08-27   4.35
#[Out]# 506  190  2018-08-23   2.85
#[Out]# 507  190  2018-08-16   3.15
#[Out]# 508  190  2018-08-21   3.30
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Sun, 06 Dec 2020 18:04:50
query4_4 = '''
    SELECT cID, SUM(price)
    FROM purchase
    GROUPBY cID, date
'''
pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 18:05:04
query4_4 = '''
    SELECT cID, SUM(price)
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      cID  SUM(price)
#[Out]# 0      0        0.45
#[Out]# 1      1       14.20
#[Out]# 2      1       10.00
#[Out]# 3      2        2.45
#[Out]# 4      2        7.70
#[Out]# ..   ...         ...
#[Out]# 280  190       10.60
#[Out]# 281  190        3.25
#[Out]# 282  190        9.80
#[Out]# 283  190       21.90
#[Out]# 284  190        5.55
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Sun, 06 Dec 2020 18:05:09
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  SUM(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sun, 06 Dec 2020 18:05:24
query4_4 = '''
    SELECT SUM(price)
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      SUM(price)
#[Out]# 0          0.45
#[Out]# 1         14.20
#[Out]# 2         10.00
#[Out]# 3          2.45
#[Out]# 4          7.70
#[Out]# ..          ...
#[Out]# 280       10.60
#[Out]# 281        3.25
#[Out]# 282        9.80
#[Out]# 283       21.90
#[Out]# 284        5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Sun, 06 Dec 2020 18:05:30
query4_4 = '''
    SELECT MAX(SUM(price))
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 18:06:05
query4_4 = '''
    SELECT SUM(price) as agg_price
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      agg_price
#[Out]# 0         0.45
#[Out]# 1        14.20
#[Out]# 2        10.00
#[Out]# 3         2.45
#[Out]# 4         7.70
#[Out]# ..         ...
#[Out]# 280      10.60
#[Out]# 281       3.25
#[Out]# 282       9.80
#[Out]# 283      21.90
#[Out]# 284       5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Sun, 06 Dec 2020 18:06:24
query4_4 = '''
    SELECT MAX(agg_price) FROM )
    SELECT SUM(price) as agg_price
    FROM purchase
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 18:06:36
query4_4 = '''
    SELECT MAX(agg_price) FROM (
    SELECT SUM(price) as agg_price
    FROM purchase
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(agg_price)
#[Out]# 0            39.1
# Sun, 06 Dec 2020 18:06:58
query4_4 = '''
    SELECT MAX(agg_spent) as max_spent FROM (
    SELECT SUM(price) as agg_spent
    FROM purchase
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#    max_spent
#[Out]# 0       39.1
# Sun, 06 Dec 2020 18:14:45
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''
(
    SELECT SUM(price) as agg_spent
    FROM purchase
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 18:14:54
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''SELECT SUM(price) as agg_spent
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      agg_spent
#[Out]# 0         0.45
#[Out]# 1        14.20
#[Out]# 2        10.00
#[Out]# 3         2.45
#[Out]# 4         7.70
#[Out]# ..         ...
#[Out]# 280      10.60
#[Out]# 281       3.25
#[Out]# 282       9.80
#[Out]# 283      21.90
#[Out]# 284       5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Sun, 06 Dec 2020 18:15:10
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''SELECT cID, date, price, unit_price, SUM(price) as agg_spent
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 18:15:20
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''SELECT *, SUM(price) as agg_spent
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  agg_spent
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45       0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65      14.20
#[Out]# 2      6    1   46   11  2018-08-21         8   0.90      10.00
#[Out]# 3      8    2   12   20  2018-08-16         1   2.45       2.45
#[Out]# 4      9    2   39    9  2018-08-17         7   1.35       7.70
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...        ...
#[Out]# 280  787  190    3   28  2018-08-23         5   0.50      10.60
#[Out]# 281  785  190    1   19  2018-08-24         6   2.55       3.25
#[Out]# 282  823  190   39    0  2018-08-25         4   3.70       9.80
#[Out]# 283  788  190    4    7  2018-08-26         7   1.30      21.90
#[Out]# 284  813  190   29   17  2018-08-27         5   1.20       5.55
#[Out]# 
#[Out]# [285 rows x 8 columns]
# Sun, 06 Dec 2020 18:15:56
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''SELECT cID, date, quantity, price, quantity*price as total_price, SUM(total_price) as agg_spent
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 18:16:09
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''SELECT cID, date, quantity, price, quantity*price as total_price
    FROM purchase
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  quantity  price  total_price
#[Out]# 0      0  2018-08-22         1   0.45         0.45
#[Out]# 1      1  2018-08-20         2   4.65         9.30
#[Out]# 2      1  2018-08-21         8   0.90         7.20
#[Out]# 3      2  2018-08-16         1   2.45         2.45
#[Out]# 4      2  2018-08-17         7   1.35         9.45
#[Out]# ..   ...         ...       ...    ...          ...
#[Out]# 280  190  2018-08-23         5   0.50         2.50
#[Out]# 281  190  2018-08-24         6   2.55        15.30
#[Out]# 282  190  2018-08-25         4   3.70        14.80
#[Out]# 283  190  2018-08-26         7   1.30         9.10
#[Out]# 284  190  2018-08-27         5   1.20         6.00
#[Out]# 
#[Out]# [285 rows x 5 columns]
# Sun, 06 Dec 2020 18:17:45
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''SELECT cID, date, quantity, price, quantity*price as total_price
    FROM purchase

'''
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  quantity  price  total_price
#[Out]# 0      0  2018-08-22         1   0.45         0.45
#[Out]# 1      1  2018-08-20         2   4.65         9.30
#[Out]# 2      1  2018-08-20         3   1.60         4.80
#[Out]# 3      1  2018-08-20         2   1.25         2.50
#[Out]# 4      1  2018-08-20         4   3.95        15.80
#[Out]# ..   ...         ...       ...    ...          ...
#[Out]# 504  190  2018-08-26         2   3.80         7.60
#[Out]# 505  190  2018-08-27         6   4.35        26.10
#[Out]# 506  190  2018-08-23         5   2.85        14.25
#[Out]# 507  190  2018-08-16         2   3.15         6.30
#[Out]# 508  190  2018-08-21         1   3.30         3.30
#[Out]# 
#[Out]# [509 rows x 5 columns]
# Sun, 06 Dec 2020 18:17:58
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''SELECT *, quantity*price as total_price
    FROM purchase

'''
pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  total_price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45         0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65         9.30
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60         4.80
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25         2.50
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95        15.80
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...          ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80         7.60
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35        26.10
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85        14.25
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15         6.30
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30         3.30
#[Out]# 
#[Out]# [509 rows x 8 columns]
# Sun, 06 Dec 2020 18:18:17
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  total_price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45         0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65         9.30
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60         4.80
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25         2.50
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95        15.80
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...          ...
#[Out]# 504  816  190   32    0  2018-08-26         4   3.85        15.40
#[Out]# 505  832  190   48   20  2018-08-26         6   4.30        25.80
#[Out]# 506  843  190   59   17  2018-08-26         2   3.80         7.60
#[Out]# 507  813  190   29   17  2018-08-27         5   1.20         6.00
#[Out]# 508  844  190   60    5  2018-08-27         6   4.35        26.10
#[Out]# 
#[Out]# [509 rows x 8 columns]
# Sun, 06 Dec 2020 18:19:15
#     SELECT MAX(agg_spent) as max_spent FROM 
query4_4 = '''
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      agg_spent
#[Out]# 0         0.45
#[Out]# 1        43.40
#[Out]# 2        61.80
#[Out]# 3         2.45
#[Out]# 4        32.40
#[Out]# ..         ...
#[Out]# 280      52.85
#[Out]# 281      18.10
#[Out]# 282      46.20
#[Out]# 283      89.55
#[Out]# 284      32.10
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Sun, 06 Dec 2020 18:19:39
#     
query4_4 = '''
    SELECT MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#    max_spent
#[Out]# 0     171.25
# Sun, 06 Dec 2020 18:19:51
#     
query4_4 = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#    max_spent
#[Out]# 0   128.4375
# Sun, 06 Dec 2020 18:21:26
query4_4 = '''
    SELECT * FROM customer
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      cID   cName            street       city
#[Out]# 0      0    Noah         Koestraat    Utrecht
#[Out]# 1      1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 3      3    Finn     Stationsplein      Breda
#[Out]# 4      4    Daan      Kalverstraat  Amsterdam
#[Out]# ..   ...     ...               ...        ...
#[Out]# 185  185    Nick            Verweg  Eindhoven
#[Out]# 186  186  Angela          Dichtweg  Eindhoven
#[Out]# 187  188    Pino        Maanstraat  Rotterdam
#[Out]# 188  189    Koen          Akkerweg        Oss
#[Out]# 189  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Sun, 06 Dec 2020 18:21:51
query4_4 = '''
    SELECT * FROM customer c, purchase p WHERE p.cID = c.cID
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      cID   cName            street     city  tID  cID  sID  pID        date  \
#[Out]# 0      0    Noah         Koestraat  Utrecht    0    0    3   10  2018-08-22   
#[Out]# 1      1     Sem  Rozemarijnstraat    Breda    1    1   23   14  2018-08-20   
#[Out]# 2      1     Sem  Rozemarijnstraat    Breda    2    1    3   16  2018-08-20   
#[Out]# 3      1     Sem  Rozemarijnstraat    Breda    3    1   17    9  2018-08-20   
#[Out]# 4      1     Sem  Rozemarijnstraat    Breda    4    1   32   25  2018-08-20   
#[Out]# ..   ...     ...               ...      ...  ...  ...  ...  ...         ...   
#[Out]# 504  190  Kostas          Eindeweg  Utrecht  843  190   59   17  2018-08-26   
#[Out]# 505  190  Kostas          Eindeweg  Utrecht  844  190   60    5  2018-08-27   
#[Out]# 506  190  Kostas          Eindeweg  Utrecht  845  190   61   19  2018-08-23   
#[Out]# 507  190  Kostas          Eindeweg  Utrecht  846  190   62    9  2018-08-16   
#[Out]# 508  190  Kostas          Eindeweg  Utrecht  847  190   63   18  2018-08-21   
#[Out]# 
#[Out]#      quantity  price  
#[Out]# 0           1   0.45  
#[Out]# 1           2   4.65  
#[Out]# 2           3   1.60  
#[Out]# 3           2   1.25  
#[Out]# 4           4   3.95  
#[Out]# ..        ...    ...  
#[Out]# 504         2   3.80  
#[Out]# 505         6   4.35  
#[Out]# 506         5   2.85  
#[Out]# 507         2   3.15  
#[Out]# 508         1   3.30  
#[Out]# 
#[Out]# [509 rows x 11 columns]
# Sun, 06 Dec 2020 18:22:15
query4_4 = '''
    SELECT * FROM purchase p, customer c WHERE p.cID = c.cID
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  cID   cName  \
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45    0    Noah   
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65    1     Sem   
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60    1     Sem   
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25    1     Sem   
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95    1     Sem   
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  ...     ...   
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80  190  Kostas   
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35  190  Kostas   
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85  190  Kostas   
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15  190  Kostas   
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30  190  Kostas   
#[Out]# 
#[Out]#                street     city  
#[Out]# 0           Koestraat  Utrecht  
#[Out]# 1    Rozemarijnstraat    Breda  
#[Out]# 2    Rozemarijnstraat    Breda  
#[Out]# 3    Rozemarijnstraat    Breda  
#[Out]# 4    Rozemarijnstraat    Breda  
#[Out]# ..                ...      ...  
#[Out]# 504          Eindeweg  Utrecht  
#[Out]# 505          Eindeweg  Utrecht  
#[Out]# 506          Eindeweg  Utrecht  
#[Out]# 507          Eindeweg  Utrecht  
#[Out]# 508          Eindeweg  Utrecht  
#[Out]# 
#[Out]# [509 rows x 11 columns]
# Sun, 06 Dec 2020 18:23:11
query4_4 = '''
    SELECT p.cID, pID, date, quantity, price, quantity*price as total_price, cName
    FROM purchase p, customer c WHERE p.cID = c.cID
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      cID  pID        date  quantity  price  total_price   cName
#[Out]# 0      0   10  2018-08-22         1   0.45         0.45    Noah
#[Out]# 1      1   14  2018-08-20         2   4.65         9.30     Sem
#[Out]# 2      1   16  2018-08-20         3   1.60         4.80     Sem
#[Out]# 3      1    9  2018-08-20         2   1.25         2.50     Sem
#[Out]# 4      1   25  2018-08-20         4   3.95        15.80     Sem
#[Out]# ..   ...  ...         ...       ...    ...          ...     ...
#[Out]# 504  190   17  2018-08-26         2   3.80         7.60  Kostas
#[Out]# 505  190    5  2018-08-27         6   4.35        26.10  Kostas
#[Out]# 506  190   19  2018-08-23         5   2.85        14.25  Kostas
#[Out]# 507  190    9  2018-08-16         2   3.15         6.30  Kostas
#[Out]# 508  190   18  2018-08-21         1   3.30         3.30  Kostas
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Sun, 06 Dec 2020 18:24:23
query4_4 = '''
    SELECT cName, SUM(total_price), date FROM 
    (SELECT p.cID, pID, date, quantity, price, quantity*price as total_price, cName
    FROM purchase p, customer c WHERE p.cID = c.cID)
    GROUP BY cID, date
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#       cName  SUM(total_price)        date
#[Out]# 0      Noah              0.45  2018-08-22
#[Out]# 1       Sem             43.40  2018-08-20
#[Out]# 2       Sem             61.80  2018-08-21
#[Out]# 3     Lucas              2.45  2018-08-16
#[Out]# 4     Lucas             32.40  2018-08-17
#[Out]# ..      ...               ...         ...
#[Out]# 280  Kostas             52.85  2018-08-23
#[Out]# 281  Kostas             18.10  2018-08-24
#[Out]# 282  Kostas             46.20  2018-08-25
#[Out]# 283  Kostas             89.55  2018-08-26
#[Out]# 284  Kostas             32.10  2018-08-27
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sun, 06 Dec 2020 18:25:32
query4_4 = '''
    SELECT MAX(total_spent_per_person) FROM
    (SELECT cName, SUM(total_price) as total_spent_per_person, date FROM 
    (SELECT p.cID, pID, date, quantity, price, quantity*price as total_price, cName
    FROM purchase p, customer c WHERE p.cID = c.cID)
    GROUP BY cID, date)
    GROUP BY cName
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      MAX(total_spent_per_person)
#[Out]# 0                          10.35
#[Out]# 1                           3.30
#[Out]# 2                          48.75
#[Out]# 3                          12.80
#[Out]# 4                           5.00
#[Out]# ..                           ...
#[Out]# 126                        71.00
#[Out]# 127                         7.00
#[Out]# 128                        88.50
#[Out]# 129                        14.70
#[Out]# 130                         5.60
#[Out]# 
#[Out]# [131 rows x 1 columns]
# Sun, 06 Dec 2020 18:25:38
query4_4 = '''
    SELECT MAX(total_spent_per_person), cName FROM
    (SELECT cName, SUM(total_price) as total_spent_per_person, date FROM 
    (SELECT p.cID, pID, date, quantity, price, quantity*price as total_price, cName
    FROM purchase p, customer c WHERE p.cID = c.cID)
    GROUP BY cID, date)
    GROUP BY cName
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#      MAX(total_spent_per_person)      cName
#[Out]# 0                          10.35      Aiden
#[Out]# 1                           3.30  Alexander
#[Out]# 2                          48.75      Amira
#[Out]# 3                          12.80        Amy
#[Out]# 4                           5.00     Angela
#[Out]# ..                           ...        ...
#[Out]# 126                        71.00     Veerle
#[Out]# 127                         7.00      Wilko
#[Out]# 128                        88.50     Willem
#[Out]# 129                        14.70       Xavi
#[Out]# 130                         5.60       Yara
#[Out]# 
#[Out]# [131 rows x 2 columns]
# Sun, 06 Dec 2020 18:26:45
query4_4 = '''
    SELECT cName FROM 
    (SELECT MAX(total_spent_per_person) max_per_person, cName FROM
    (SELECT cName, SUM(total_price) as total_spent_per_person, date FROM 
    (SELECT p.cID, pID, date, quantity, price, quantity*price as total_price, cName
    FROM purchase p, customer c WHERE p.cID = c.cID)
    GROUP BY cID, date)
    GROUP BY cName)
    WHERE max_per_person >= (
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
)
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Dean
#[Out]# 1  Floor
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4   Sven
# Sun, 06 Dec 2020 18:27:52
query4_4 = '''
    SELECT cName, max_per_person FROM 
    (SELECT MAX(total_spent_per_person) max_per_person, cName FROM
    (SELECT cName, SUM(total_price) as total_spent_per_person, date FROM 
    (SELECT p.cID, pID, date, quantity, price, quantity*price as total_price, cName
    FROM purchase p, customer c WHERE p.cID = c.cID)
    GROUP BY cID, date)
    GROUP BY cName)
    WHERE max_per_person >= (
    /* Here we find the 75% of the max spent by a single person in a single day */
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
)
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#    cName  max_per_person
#[Out]# 0   Dean          145.00
#[Out]# 1  Floor          171.25
#[Out]# 2   Lynn          150.15
#[Out]# 3  Sofie          134.90
#[Out]# 4   Sven          138.90
# Sun, 06 Dec 2020 18:28:07
query4_4 = '''
    SELECT cName, max_per_person FROM 
    (SELECT MAX(total_spent_per_person) max_per_person, cName FROM
    (SELECT cName, SUM(total_price) as total_spent_per_person, date FROM 
    (SELECT p.cID, pID, date, quantity, price, quantity*price as total_price, cName
    FROM purchase p, customer c WHERE p.cID = c.cID)
    GROUP BY cID, date)
    GROUP BY cName)
    WHERE max_per_person >= (
    /* Here we find the 75% of the max spent by a single person in a single day */
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
)
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4_sevfivepercent, conn)
#[Out]#    max_spent
#[Out]# 0   128.4375
# Sun, 06 Dec 2020 18:28:12
query4_4 = '''
    SELECT cName, max_per_person FROM 
    (SELECT MAX(total_spent_per_person) max_per_person, cName FROM
    (SELECT cName, SUM(total_price) as total_spent_per_person, date FROM 
    (SELECT p.cID, pID, date, quantity, price, quantity*price as total_price, cName
    FROM purchase p, customer c WHERE p.cID = c.cID)
    GROUP BY cID, date)
    GROUP BY cName)
    WHERE max_per_person >= (
    /* Here we find the 75% of the max spent by a single person in a single day */
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
)
'''


#     
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#    cName  max_per_person
#[Out]# 0   Dean          145.00
#[Out]# 1  Floor          171.25
#[Out]# 2   Lynn          150.15
#[Out]# 3  Sofie          134.90
#[Out]# 4   Sven          138.90
# Sun, 06 Dec 2020 18:34:13
query4_4 = '''

    /* 4. Take the names of the persons whose maximum in a day is larger than 
    the subquery for 75%. */
    SELECT cName, max_per_person FROM 
    
    /* 3. Take the maximum amount each person has spent in a day. */
    (SELECT MAX(total_spent_per_person) max_per_person, cName FROM
    
    /* 2. Then we take the names and the total amount spent per person in a day. */
    (SELECT cName, SUM(total_price) as total_spent_per_person, date FROM 
    
    /* 1. First we make the cross of purchases and customers 
    to bring the customer names into the equation. */
    (SELECT p.cID, pID, date, quantity, price, 
            quantity*price as total_price, cName
    FROM purchase p, customer c 
    WHERE p.cID = c.cID)
    
    GROUP BY cID, date) /* 2. */
    GROUP BY cName) /* 3. */
    WHERE max_per_person >= ( /* 4. */
    
    /* Here we find the 75% of the max spent by a single person in a single day */
    
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    /* Here we take the sum for the whole day for one person*/
    SELECT SUM(total_price) as agg_spent FROM (
    /* Here we calculate the total price per purchase */
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    /* Here we group by customer and date, as we're taking
    the aggregate for one customer per day. */
    GROUP BY cID, date)
)
'''


# ~128
query4_4_sevfivepercent = '''
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    SELECT SUM(total_price) as agg_spent FROM (
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    GROUP BY cID, date)
'''
pd.read_sql_query(query4_4, conn)
#[Out]#    cName  max_per_person
#[Out]# 0   Dean          145.00
#[Out]# 1  Floor          171.25
#[Out]# 2   Lynn          150.15
#[Out]# 3  Sofie          134.90
#[Out]# 4   Sven          138.90
# Sun, 06 Dec 2020 18:35:14
query4_4 = '''

    /* 4. Take the names of the persons whose maximum in a day is larger than 
    the subquery for 75%. */
    SELECT cName, max_per_person FROM 
    
    /* 3. Take the maximum amount each person has spent in a day. */
    (SELECT MAX(total_spent_per_person) max_per_person, cName FROM
    
    /* 2. Then we take the names and the total amount spent per person in a day. */
    (SELECT cName, SUM(total_price) as total_spent_per_person, date FROM 
    
    /* 1. First we make the cross of purchases and customers 
    to bring the customer names into the equation. */
    (SELECT p.cID, pID, date, quantity, price, 
            quantity*price as total_price, cName
    FROM purchase p, customer c 
    WHERE p.cID = c.cID)
    
    GROUP BY cID, date) /* 2. */
    GROUP BY cName) /* 3. */
    WHERE max_per_person >= ( /* 4. */
    
    /* Here we find the 75% of the max spent by a single person in a single day */
    
    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (
    /* Here we take the sum for the whole day for one person*/
    SELECT SUM(total_price) as agg_spent FROM (
    /* Here we calculate the total price per purchase */
    SELECT *, quantity*price as total_price
    FROM purchase
    ORDER BY cID, date)
    /* Here we group by customer and date, as we're taking
    the aggregate for one customer per day. */
    GROUP BY cID, date)
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName  max_per_person
#[Out]# 0   Dean          145.00
#[Out]# 1  Floor          171.25
#[Out]# 2   Lynn          150.15
#[Out]# 3  Sofie          134.90
#[Out]# 4   Sven          138.90
# Sun, 06 Dec 2020 18:35:38
get_ipython().run_cell_magic('writefile', 'question4.txt', '')
# Sun, 06 Dec 2020 18:35:43
get_ipython().run_cell_magic('writefile', 'question4.txt', "\n    /* 4. Take the names of the persons whose maximum in a day is larger than \n    the subquery for 75%. */\n    SELECT cName, max_per_person FROM \n    \n    /* 3. Take the maximum amount each person has spent in a day. */\n    (SELECT MAX(total_spent_per_person) max_per_person, cName FROM\n    \n    /* 2. Then we take the names and the total amount spent per person in a day. */\n    (SELECT cName, SUM(total_price) as total_spent_per_person, date FROM \n    \n    /* 1. First we make the cross of purchases and customers \n    to bring the customer names into the equation. */\n    (SELECT p.cID, pID, date, quantity, price, \n            quantity*price as total_price, cName\n    FROM purchase p, customer c \n    WHERE p.cID = c.cID)\n    \n    GROUP BY cID, date) /* 2. */\n    GROUP BY cName) /* 3. */\n    WHERE max_per_person >= ( /* 4. */\n    \n    /* Here we find the 75% of the max spent by a single person in a single day */\n    \n    SELECT 0.75 * MAX(agg_spent) as max_spent FROM (\n    /* Here we take the sum for the whole day for one person*/\n    SELECT SUM(total_price) as agg_spent FROM (\n    /* Here we calculate the total price per purchase */\n    SELECT *, quantity*price as total_price\n    FROM purchase\n    ORDER BY cID, date)\n    /* Here we group by customer and date, as we're taking\n    the aggregate for one customer per day. */\n    GROUP BY cID, date)\n);\n")
# Sun, 06 Dec 2020 18:36:22
get_ipython().run_cell_magic('writefile', 'question4.txt', "\n/* 4. Take the names of the persons whose maximum in a day is larger than \nthe subquery for 75%. */\nSELECT cName, max_per_person FROM \n\n/* 3. Take the maximum amount each person has spent in a day. */\n(SELECT MAX(total_spent_per_person) max_per_person, cName FROM\n\n/* 2. Then we take the names and the total amount spent per person in a day. */\n(SELECT cName, SUM(total_price) as total_spent_per_person, date FROM \n\n/* 1. First we make the cross of purchases and customers \nto bring the customer names into the equation. */\n(SELECT p.cID, pID, date, quantity, price, \n        quantity*price as total_price, cName\nFROM purchase p, customer c \nWHERE p.cID = c.cID)\n\nGROUP BY cID, date) /* 2. */\nGROUP BY cName) /* 3. */\nWHERE max_per_person >= ( /* 4. */\n\n/* Here we find the 75% of the max spent by a single person in a single day */\n\nSELECT 0.75 * MAX(agg_spent) as max_spent FROM (\n/* Here we take the sum for the whole day for one person*/\nSELECT SUM(total_price) as agg_spent FROM (\n/* Here we calculate the total price per purchase */\nSELECT *, quantity*price as total_price\nFROM purchase\nORDER BY cID, date)\n/* Here we group by customer and date, as we're taking\nthe aggregate for one customer per day. */\nGROUP BY cID, date)\n);\n")
# Sun, 06 Dec 2020 18:46:36
query4_5_trials = '''
    SELECT * FROM customer
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#      cID   cName            street       city
#[Out]# 0      0    Noah         Koestraat    Utrecht
#[Out]# 1      1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 3      3    Finn     Stationsplein      Breda
#[Out]# 4      4    Daan      Kalverstraat  Amsterdam
#[Out]# ..   ...     ...               ...        ...
#[Out]# 185  185    Nick            Verweg  Eindhoven
#[Out]# 186  186  Angela          Dichtweg  Eindhoven
#[Out]# 187  188    Pino        Maanstraat  Rotterdam
#[Out]# 188  189    Koen          Akkerweg        Oss
#[Out]# 189  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Sun, 06 Dec 2020 18:46:54
query4_5_trials = '''
    SELECT * FROM customer
    ORDER BY city
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#      cID   cName            street       city
#[Out]# 0      2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 1      4    Daan      Kalverstraat  Amsterdam
#[Out]# 2      9  Thomas       Parallelweg  Amsterdam
#[Out]# 3     20    Gijs        Heiligeweg  Amsterdam
#[Out]# 4     42    Tijn     Keizersgracht  Amsterdam
#[Out]# ..   ...     ...               ...        ...
#[Out]# 185  159   Fenne    Gasthuisstraat    Utrecht
#[Out]# 186  169    Lily    Gasthuisstraat    Utrecht
#[Out]# 187  178    Elif       Parallelweg    Utrecht
#[Out]# 188  183   Nikki     Julianastraat    Utrecht
#[Out]# 189  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Sun, 06 Dec 2020 18:47:23
query4_5_trials = '''
    SELECT * FROM purchase
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Sun, 06 Dec 2020 18:47:48
query4_5_trials = '''
    SELECT * FROM purchase p, store s
    WHERE p.sID = s.sID
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  sID        sName  \
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45    3       Sligro   
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65   23         Dirk   
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60    3       Sligro   
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25   17    Hoogvliet   
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95   32  Albert Hein   
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  ...          ...   
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80   59        Jumbo   
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35   60         Lidl   
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85   61         Lidl   
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15   62        Jumbo   
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30   63        Jumbo   
#[Out]# 
#[Out]#                street       city  
#[Out]# 0      Stadhoudersweg  Rotterdam  
#[Out]# 1       Stationsplein      Breda  
#[Out]# 2      Stadhoudersweg  Rotterdam  
#[Out]# 3          Kerkstraat  Eindhoven  
#[Out]# 4          Hoogstraat    Utrecht  
#[Out]# ..                ...        ...  
#[Out]# 504  Rozemarijnstraat      Breda  
#[Out]# 505      Pannekoekweg      Breda  
#[Out]# 506      Pannekoekweg      Breda  
#[Out]# 507     Poffertjesweg  Eindhoven  
#[Out]# 508     Stationstraat        Oss  
#[Out]# 
#[Out]# [509 rows x 11 columns]
# Sun, 06 Dec 2020 18:48:08
query4_5_trials = '''
    SELECT * FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven"
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  sID      sName  \
#[Out]# 0      3    1   17    9  2018-08-20         2   1.25   17  Hoogvliet   
#[Out]# 1      7    1   36   27  2018-08-21         6   9.10   36       Lidl   
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45   12       Lidl   
#[Out]# 3      9    2   39    9  2018-08-17         7   1.35   39     Sligro   
#[Out]# 4     14    3   30   26  2018-08-19         2   2.75   30       Dirk   
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  ...        ...   
#[Out]# 128  836  190   52   23  2018-08-15         5   2.50   52       Lidl   
#[Out]# 129  838  190   54    0  2018-08-25         6   3.50   54       Dirk   
#[Out]# 130  840  190   56   11  2018-08-15         4   1.60   56      Jumbo   
#[Out]# 131  841  190   57   15  2018-08-22         5   3.25   57       Dirk   
#[Out]# 132  846  190   62    9  2018-08-16         2   3.15   62      Jumbo   
#[Out]# 
#[Out]#                street       city  
#[Out]# 0          Kerkstraat  Eindhoven  
#[Out]# 1       Julianastraat  Eindhoven  
#[Out]# 2    Wilhelminastraat  Eindhoven  
#[Out]# 3         Dorpsstraat  Eindhoven  
#[Out]# 4         Nieuwstraat  Eindhoven  
#[Out]# ..                ...        ...  
#[Out]# 128       Nieuwstraat  Eindhoven  
#[Out]# 129     Julianastraat  Eindhoven  
#[Out]# 130       Parallelweg  Eindhoven  
#[Out]# 131       Molenstraat  Eindhoven  
#[Out]# 132     Poffertjesweg  Eindhoven  
#[Out]# 
#[Out]# [133 rows x 11 columns]
# Sun, 06 Dec 2020 18:49:36
query4_5_trials = '''
    SELECT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven"
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# ..   ...
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Sun, 06 Dec 2020 18:50:17
query4_5_trials = '''
    SELECT * FROM 
    customer c, (SELECT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#      cID   cName            street       city  cID
#[Out]# 0      1     Sem  Rozemarijnstraat      Breda    1
#[Out]# 1      1     Sem  Rozemarijnstraat      Breda    1
#[Out]# 2      2   Lucas  Oude Leliestraat  Amsterdam    2
#[Out]# 3      2   Lucas  Oude Leliestraat  Amsterdam    2
#[Out]# 4      3    Finn     Stationsplein      Breda    3
#[Out]# ..   ...     ...               ...        ...  ...
#[Out]# 128  190  Kostas          Eindeweg    Utrecht  190
#[Out]# 129  190  Kostas          Eindeweg    Utrecht  190
#[Out]# 130  190  Kostas          Eindeweg    Utrecht  190
#[Out]# 131  190  Kostas          Eindeweg    Utrecht  190
#[Out]# 132  190  Kostas          Eindeweg    Utrecht  190
#[Out]# 
#[Out]# [133 rows x 5 columns]
# Sun, 06 Dec 2020 18:50:57
query4_5_trials = '''
    SELECT * FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#     cID    cName            street       city  cID
#[Out]# 0     1      Sem  Rozemarijnstraat      Breda    1
#[Out]# 1     2    Lucas  Oude Leliestraat  Amsterdam    2
#[Out]# 2     3     Finn     Stationsplein      Breda    3
#[Out]# 3     4     Daan      Kalverstraat  Amsterdam    4
#[Out]# 4     5     Levi    Gasthuisstraat    Utrecht    5
#[Out]# ..  ...      ...               ...        ...  ...
#[Out]# 64  182  Johanna     Beatrixstraat  Eindhoven  182
#[Out]# 65  185     Nick            Verweg  Eindhoven  185
#[Out]# 66  186   Angela          Dichtweg  Eindhoven  186
#[Out]# 67  188     Pino        Maanstraat  Rotterdam  188
#[Out]# 68  190   Kostas          Eindeweg    Utrecht  190
#[Out]# 
#[Out]# [69 rows x 5 columns]
# Sun, 06 Dec 2020 18:51:07
query4_5_trials = '''
    SELECT * FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    ORDER BY city
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#     cID   cName            street       city  cID
#[Out]# 0     2   Lucas  Oude Leliestraat  Amsterdam    2
#[Out]# 1     4    Daan      Kalverstraat  Amsterdam    4
#[Out]# 2    59    Joep            Amstel  Amsterdam   59
#[Out]# 3    70     Kai        Heiligeweg  Amsterdam   70
#[Out]# 4   124   Sofie     Keizersgracht  Amsterdam  124
#[Out]# ..  ...     ...               ...        ...  ...
#[Out]# 64  147  Isabel         Damstraat    Utrecht  147
#[Out]# 65  159   Fenne    Gasthuisstraat    Utrecht  159
#[Out]# 66  169    Lily    Gasthuisstraat    Utrecht  169
#[Out]# 67  178    Elif       Parallelweg    Utrecht  178
#[Out]# 68  190  Kostas          Eindeweg    Utrecht  190
#[Out]# 
#[Out]# [69 rows x 5 columns]
# Sun, 06 Dec 2020 18:51:51
query4_5_trials = '''
    SELECT *, COUNT(cName) FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#    cID  cName            street       city  cID  COUNT(cName)
#[Out]# 0    2  Lucas  Oude Leliestraat  Amsterdam    2            10
#[Out]# 1    1    Sem  Rozemarijnstraat      Breda    1             9
#[Out]# 2    7   Bram      Schoolstraat  Eindhoven    7            15
#[Out]# 3   25  Mason      Keizerstraat  Rotterdam   25            13
#[Out]# 4   24   Luca      Kasteeldreef    Tilburg   24            10
#[Out]# 5    5   Levi    Gasthuisstraat    Utrecht    5            12
# Sun, 06 Dec 2020 18:52:45
query4_5_trials = '''
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 18:52:53
query4_5_trials = '''
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

query4_5 = '''
    SELECT city, ... as number
    FROM 
'''
pd.read_sql_query(query4_5_trials, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 18:53:33
query4_5 = '''
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 18:54:36
query4_5 = '''
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

query4_5 = '''
    SELECT DISTINCT city
    FROM customer
'''
pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Sun, 06 Dec 2020 18:54:53
query4_5 = '''
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

query4_5_temp = '''
    SELECT DISTINCT city
    FROM customer
'''
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 18:55:00
query4_5 = '''
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

query4_5_temp = '''
    SELECT DISTINCT city
    FROM customer
'''
pd.read_sql_query(query4_5_temp, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Sun, 06 Dec 2020 18:55:16
query4_5 = '''
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

query4_5_temp = '''
    SELECT DISTINCT city
    FROM customer
    ORDER BY city
'''
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 18:55:23
query4_5 = '''
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

query4_5_temp = '''
    SELECT DISTINCT city
    FROM customer
    ORDER BY city
'''
pd.read_sql_query(query4_5_temp, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 19:01:41
query4_5 = '''
    /* We have to add those cities from which customers haven't bought anything in Eindhoven*/
    SELECT city, 0
    
    /* Counting the customers that have bought something in Eindhoven*/
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

query4_5_temp = '''
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city LIKE "%Ein%"
'''
pd.read_sql_query(query4_5_temp, conn)
#[Out]#         city  number
#[Out]# 0  Eindhoven       0
# Sun, 06 Dec 2020 19:04:26
query4_5 = '''
    /* We have to add those cities from which customers haven't bought anything in Eindhoven*/
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city NOT IN (
    
    /* Counting the customers that have bought something in Eindhoven*/
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city);
'''

query4_5_temp = '''
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city LIKE "%Ein%"
'''
pd.read_sql_query(query4_5_temp, conn)
#[Out]#         city  number
#[Out]# 0  Eindhoven       0
# Sun, 06 Dec 2020 19:04:30
query4_5 = '''
    /* We have to add those cities from which customers haven't bought anything in Eindhoven*/
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city NOT IN (
    
    /* Counting the customers that have bought something in Eindhoven*/
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city);
'''

query4_5_temp = '''
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city LIKE "%Ein%"
'''
pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 19:04:57
query4_5 = '''
    /* We have to add those cities from which customers haven't bought anything in Eindhoven*/
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city NOT IN (
    
    /* Counting the customers that have bought something in Eindhoven*/
    SELECT city FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city);
'''

query4_5_temp = '''
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city LIKE "%Ein%"
'''
pd.read_sql_query(query4_5, conn)
#[Out]#   city  number
#[Out]# 0  Oss       0
# Sun, 06 Dec 2020 19:05:43
query4_5 = '''
    /* We have to add those cities from which customers haven't bought anything in Eindhoven*/
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city NOT IN (
    
    /* Counting the customers that have bought something in Eindhoven*/
    SELECT city FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city)
    UNION 
    /* Counting the customers that have bought something in Eindhoven*/
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

query4_5_temp = '''
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city LIKE "%Ein%"
'''
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 19:07:32
query4_5 = '''
    /* We have to add those cities from which customers haven't bought anything in Eindhoven
    So add a 0 for each city that IS NOT in the list of cities that have customers that 
    have bought something in Eindhoven. */
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city NOT IN (
    
    /* Getting names of cities from which there exists a customer
    that has bought something in Eindhoven*/
    SELECT city FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city)
    
    /* Connect these cities with 0 customers with the schema that counted the customers. */
    UNION 
    
    /* Counting the customers that have bought something in Eindhoven*/
    SELECT city, COUNT(cName) as number FROM 
    customer c, (SELECT DISTINCT cID FROM purchase p, store s
    WHERE p.sID = s.sID AND s.city = "Eindhoven") ehv
    WHERE ehv.cID = c.cID
    GROUP BY city;
'''

query4_5_temp = '''
    SELECT DISTINCT city, 0 as number
    FROM customer
    WHERE city LIKE "%Ein%"
'''
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 19:07:59
get_ipython().run_cell_magic('writefile', 'question5.txt', '/* We have to add those cities from which customers haven\'t bought anything in Eindhoven\nSo add a 0 for each city that IS NOT in the list of cities that have customers that \nhave bought something in Eindhoven. */\nSELECT DISTINCT city, 0 as number\nFROM customer\nWHERE city NOT IN (\n\n/* Getting names of cities from which there exists a customer\nthat has bought something in Eindhoven*/\nSELECT city FROM \ncustomer c, (SELECT DISTINCT cID FROM purchase p, store s\nWHERE p.sID = s.sID AND s.city = "Eindhoven") ehv\nWHERE ehv.cID = c.cID\nGROUP BY city)\n\n/* Connect these cities with 0 customers with the schema that counted the customers. */\nUNION \n\n/* Counting the customers that have bought something in Eindhoven*/\nSELECT city, COUNT(cName) as number FROM \ncustomer c, (SELECT DISTINCT cID FROM purchase p, store s\nWHERE p.sID = s.sID AND s.city = "Eindhoven") ehv\nWHERE ehv.cID = c.cID\nGROUP BY city;\n')


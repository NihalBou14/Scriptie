# IPython log file

# Sat, 05 Dec 2020 13:18:22
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# Sat, 05 Dec 2020 13:18:32
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 05 Dec 2020 13:18:35
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x20dde4ffb20>
# Sat, 05 Dec 2020 13:20:01
query4_4 = '''
SELECT c.cID, p.date, SUM (quantity*price) as sumprice
FROM customer as c, purchase as p
WHERE c.cID=p.cID 
GROUP BY c.cID, p.date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sumprice
#[Out]# 0      0  2018-08-22      0.45
#[Out]# 1      1  2018-08-20     43.40
#[Out]# 2      1  2018-08-21     61.80
#[Out]# 3      2  2018-08-16      2.45
#[Out]# 4      2  2018-08-17     32.40
#[Out]# ..   ...         ...       ...
#[Out]# 280  190  2018-08-23     52.85
#[Out]# 281  190  2018-08-24     18.10
#[Out]# 282  190  2018-08-25     46.20
#[Out]# 283  190  2018-08-26     89.55
#[Out]# 284  190  2018-08-27     32.10
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 13:20:46
query4_4 = '''
SELECT MAX(sumprice) as maxPrice
FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
      FROM customer as c, purchase as p
      WHERE c.cID=p.cID 
      GROUP BY c.cID, p.date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    maxPrice
#[Out]# 0    171.25
# Sat, 05 Dec 2020 13:22:55
query4_4 = '''
SELECT DISTINCT c.cID
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 13:23:14
query4_4 = '''
SELECT DISTINCT c.cID
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date))
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 13:23:21
query4_4 = '''
SELECT DISTINCT c.cID
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   33
#[Out]# 1   71
#[Out]# 2  109
#[Out]# 3  124
#[Out]# 4  161
# Sat, 05 Dec 2020 13:24:10
query4_4 = '''
SELECT c.cID, 
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING m.sumprice>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 13:24:21
query4_4 = '''
SELECT c.cID, SUM(p.quantity*p.price), m.maxprice
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  SUM(p.quantity*p.price)  maxPrice
#[Out]# 0   33                   138.90    171.25
#[Out]# 1   71                   145.00    171.25
#[Out]# 2  109                   150.15    171.25
#[Out]# 3  124                   134.90    171.25
#[Out]# 4  161                   171.25    171.25
# Sat, 05 Dec 2020 13:25:50
query4_4 = '''
SELECT c.cID, SUM(p.quantity*p.price), m.maxprice
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date           
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID  SUM(p.quantity*p.price)  maxPrice
#[Out]# 0      0                     0.45    171.25
#[Out]# 1      1                    43.40    171.25
#[Out]# 2      1                    61.80    171.25
#[Out]# 3      2                     2.45    171.25
#[Out]# 4      2                    32.40    171.25
#[Out]# ..   ...                      ...       ...
#[Out]# 280  190                    52.85    171.25
#[Out]# 281  190                    18.10    171.25
#[Out]# 282  190                    46.20    171.25
#[Out]# 283  190                    89.55    171.25
#[Out]# 284  190                    32.10    171.25
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 13:25:58
query4_4 = '''
SELECT c.cID, SUM(p.quantity*p.price), m.maxprice
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  SUM(p.quantity*p.price)  maxPrice
#[Out]# 0   33                   138.90    171.25
#[Out]# 1   71                   145.00    171.25
#[Out]# 2  109                   150.15    171.25
#[Out]# 3  124                   134.90    171.25
#[Out]# 4  161                   171.25    171.25
# Sat, 05 Dec 2020 13:26:08
query4_4 = '''
SELECT c.cID, SUM(p.quantity*p.price), m.maxprice
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  SUM(p.quantity*p.price)  maxPrice
#[Out]# 0   33                   138.90    171.25
#[Out]# 1   71                   145.00    171.25
#[Out]# 2  109                   150.15    171.25
#[Out]# 3  124                   134.90    171.25
#[Out]# 4  161                   171.25    171.25
# Sat, 05 Dec 2020 13:26:38
query4_4 = '''
SELECT DISTINCT c.cID
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   33
#[Out]# 1   71
#[Out]# 2  109
#[Out]# 3  124
#[Out]# 4  161
# Sat, 05 Dec 2020 13:27:43
query4_5 = '''
SELECT c.city, COUNT (c.cID)
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.city="Eindhoven"
GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT (c.cID)
#[Out]# 0  Amsterdam             17
#[Out]# 1      Breda             27
#[Out]# 2  Eindhoven             24
#[Out]# 3  Rotterdam             16
#[Out]# 4    Tilburg             18
#[Out]# 5    Utrecht             31
# Sat, 05 Dec 2020 13:53:33
query4_5 = '''
SELECT c.city, COUNT (c.cID) as number
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.city="Eindhoven"
GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3  Rotterdam      16
#[Out]# 4    Tilburg      18
#[Out]# 5    Utrecht      31
# Sat, 05 Dec 2020 13:53:59
query4_4 = '''
SELECT DISTINCT c.cID, c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  cName
#[Out]# 0   33   Sven
#[Out]# 1   71   Dean
#[Out]# 2  109   Lynn
#[Out]# 3  124  Sofie
#[Out]# 4  161  Floor
# Sat, 05 Dec 2020 13:54:17
query4_4 = '''
SELECT DISTINCT c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Sun, 06 Dec 2020 15:05:41
query4_4 = '''
SELECT DISTINCT c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Sun, 06 Dec 2020 15:05:51
query4_4 = '''
SELECT DISTINCT c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Mon, 07 Dec 2020 12:32:56
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x0000020DDE4FFB20>
query4_4 = '''
SELECT c.cID, p.date, SUM (quantity*price) as sumprice
FROM customer as c, purchase as p
WHERE c.cID=p.cID 
GROUP BY c.cID, p.date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sumprice
#[Out]# 0      0  2018-08-22      0.45
#[Out]# 1      1  2018-08-20     43.40
#[Out]# 2      1  2018-08-21     61.80
#[Out]# 3      2  2018-08-16      2.45
#[Out]# 4      2  2018-08-17     32.40
#[Out]# ..   ...         ...       ...
#[Out]# 280  190  2018-08-23     52.85
#[Out]# 281  190  2018-08-24     18.10
#[Out]# 282  190  2018-08-25     46.20
#[Out]# 283  190  2018-08-26     89.55
#[Out]# 284  190  2018-08-27     32.10
#[Out]# 
#[Out]# [285 rows x 3 columns]
query4_4 = '''
SELECT MAX(sumprice) as maxPrice
FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
      FROM customer as c, purchase as p
      WHERE c.cID=p.cID 
      GROUP BY c.cID, p.date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    maxPrice
#[Out]# 0    171.25
query4_4 = '''
SELECT DISTINCT c.cID
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
query4_4 = '''
SELECT DISTINCT c.cID
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date))
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
query4_4 = '''
SELECT DISTINCT c.cID
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   33
#[Out]# 1   71
#[Out]# 2  109
#[Out]# 3  124
#[Out]# 4  161
query4_4 = '''
SELECT c.cID, 
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING m.sumprice>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
query4_4 = '''
SELECT c.cID, SUM(p.quantity*p.price), m.maxprice
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice            
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  SUM(p.quantity*p.price)  maxPrice
#[Out]# 0   33                   138.90    171.25
#[Out]# 1   71                   145.00    171.25
#[Out]# 2  109                   150.15    171.25
#[Out]# 3  124                   134.90    171.25
#[Out]# 4  161                   171.25    171.25
query4_4 = '''
SELECT c.cID, SUM(p.quantity*p.price), m.maxprice
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date           
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID  SUM(p.quantity*p.price)  maxPrice
#[Out]# 0      0                     0.45    171.25
#[Out]# 1      1                    43.40    171.25
#[Out]# 2      1                    61.80    171.25
#[Out]# 3      2                     2.45    171.25
#[Out]# 4      2                    32.40    171.25
#[Out]# ..   ...                      ...       ...
#[Out]# 280  190                    52.85    171.25
#[Out]# 281  190                    18.10    171.25
#[Out]# 282  190                    46.20    171.25
#[Out]# 283  190                    89.55    171.25
#[Out]# 284  190                    32.10    171.25
#[Out]# 
#[Out]# [285 rows x 3 columns]
query4_4 = '''
SELECT c.cID, SUM(p.quantity*p.price), m.maxprice
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  SUM(p.quantity*p.price)  maxPrice
#[Out]# 0   33                   138.90    171.25
#[Out]# 1   71                   145.00    171.25
#[Out]# 2  109                   150.15    171.25
#[Out]# 3  124                   134.90    171.25
#[Out]# 4  161                   171.25    171.25
query4_4 = '''
SELECT c.cID, SUM(p.quantity*p.price), m.maxprice
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  SUM(p.quantity*p.price)  maxPrice
#[Out]# 0   33                   138.90    171.25
#[Out]# 1   71                   145.00    171.25
#[Out]# 2  109                   150.15    171.25
#[Out]# 3  124                   134.90    171.25
#[Out]# 4  161                   171.25    171.25
query4_4 = '''
SELECT DISTINCT c.cID
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   33
#[Out]# 1   71
#[Out]# 2  109
#[Out]# 3  124
#[Out]# 4  161
query4_5 = '''
SELECT c.city, COUNT (c.cID)
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.city="Eindhoven"
GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT (c.cID)
#[Out]# 0  Amsterdam             17
#[Out]# 1      Breda             27
#[Out]# 2  Eindhoven             24
#[Out]# 3  Rotterdam             16
#[Out]# 4    Tilburg             18
#[Out]# 5    Utrecht             31
query4_5 = '''
SELECT c.city, COUNT (c.cID) as number
FROM customer as c, purchase as p, store as s
WHERE c.cID=p.cID AND p.sID=s.sID AND s.city="Eindhoven"
GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3  Rotterdam      16
#[Out]# 4    Tilburg      18
#[Out]# 5    Utrecht      31
query4_4 = '''
SELECT DISTINCT c.cID, c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID  cName
#[Out]# 0   33   Sven
#[Out]# 1   71   Dean
#[Out]# 2  109   Lynn
#[Out]# 3  124  Sofie
#[Out]# 4  161  Floor
query4_4 = '''
SELECT DISTINCT c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
query4_4 = '''
SELECT DISTINCT c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
query4_4 = '''
SELECT DISTINCT c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (quantity*price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.quantity*p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Mon, 07 Dec 2020 12:33:00
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 12:33:14
query4_3 = '''
SELECT sName
FROM store as sx 
WHERE NOT EXISTS (
SELECT s.sName, unions.city
FROM store as s, (
SELECT city
 FROM customer
 UNION
 SELECT city
 FROM store) as unions
EXCEPT
SELECT sName, city
FROM store as sp
WHERE sp.city = sx.city );
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 12:36:13
query4_3 = '''
SELECT s.sName, unions.city
FROM store as s, (
SELECT city
 FROM customer
 UNION
 SELECT city
 FROM store) as unions
EXCEPT
SELECT sName, city
FROM store as sp
WHERE sp.city = sx.city 
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 12:36:30
query4_3 = '''
SELECT sName
FROM store as sx 
WHERE NOT EXISTS (
SELECT s.sName, unions.city
FROM store as s, (
SELECT city
 FROM customer
 UNION
 SELECT city
 FROM store) as unions
EXCEPT
SELECT sName, city
FROM store as sp
WHERE sp.city = sx.city );
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 12:36:32
query4_3 = '''
SELECT s.sName, unions.city
FROM store as s, (
SELECT city
 FROM customer
 UNION
 SELECT city
 FROM store) as unions
EXCEPT
SELECT sName, city
FROM store as sp
WHERE sp.city = sx.city 
'''

pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 12:36:42
query4_3 = '''
SELECT s.sName, unions.city
FROM store as s, (
SELECT city
 FROM customer
 UNION
 SELECT city
 FROM store) as unions
EXCEPT
SELECT sName, city
FROM store as sp
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Mon, 07 Dec 2020 16:12:14
# Those store names that are in every city
query4_3 = '''
SELECT sName FROM store
EXCEPT
SELECT sName FROM ( SELECT s.sName, unions.city
                    FROM store as s, (SELECT city
                                      FROM customer
                                      UNION
                                      SELECT city
                                      FROM store) as unions                    
                    EXCEPT
                    SELECT sName, city
                    FROM store
                    )
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []

# IPython log file

# Wed, 09 Dec 2020 12:49:12
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 12:49:17
# Those store names that are in every city
query4_3 = '''
SELECT DISTINCT sName FROM store
EXCEPT
SELECT sName FROM ( SELECT s.sName, unions.city
                    FROM store as s, (SELECT city
                                      FROM customer
                                      UNION
                                      SELECT city
                                      FROM store) as unions                    
                    EXCEPT
                    SELECT sName, city
                    FROM store
                    )
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:49:32
query4_4 = '''
SELECT DISTINCT c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 12:51:15
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Those store names that are in every city
query4_3 = '''
SELECT DISTINCT sName FROM store
EXCEPT
SELECT sName FROM ( SELECT s.sName, unions.city
                    FROM store as s, (SELECT city
                                      FROM customer
                                      UNION
                                      SELECT city
                                      FROM store) as unions                    
                    EXCEPT
                    SELECT sName, city
                    FROM store
                    )
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
query4_4 = '''
SELECT DISTINCT c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 12:51:19
# Those store names that are in every city
query4_3 = '''
SELECT DISTINCT sName FROM store
EXCEPT
SELECT sName FROM ( SELECT s.sName, unions.city
                    FROM store as s, (SELECT city
                                      FROM customer
                                      UNION
                                      SELECT city
                                      FROM store) as unions                    
                    EXCEPT
                    SELECT sName, city
                    FROM store
                    )
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:51:22
query4_4 = '''
SELECT DISTINCT c.cName
FROM customer as c, purchase as p, 
        (SELECT MAX(sumprice) as maxPrice
         FROM (SELECT c.cID, p.date, SUM (price) as sumprice
               FROM customer as c, purchase as p
               WHERE c.cID=p.cID 
               GROUP BY c.cID, p.date)) as m
WHERE c.cID=p.cID
GROUP BY c.cID,p.date     
HAVING SUM(p.price)>=0.75*m.maxPrice 
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 12:51:27
query4_5 = '''
WITH cities(city) as (
        select city from customer
        union
        select city from store),
     citycount(city, number) as (
     SELECT c.city, COUNT (c.cID)
     FROM customer as c, purchase as p, store as s
     WHERE c.cID=p.cID AND p.sID=s.sID AND s.city="Eindhoven"
     GROUP BY c.city
)
SELECT * FROM citycount
UNION
SELECT city, 0 as number
FROM cities
WHERE city NOT IN (SELECT city FROM citycount )
GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      16
#[Out]# 5    Tilburg      18
#[Out]# 6    Utrecht      31


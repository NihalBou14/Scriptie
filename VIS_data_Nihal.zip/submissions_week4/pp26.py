# IPython log file

# Tue, 08 Dec 2020 23:14:36
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 23:15:02
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x20a4af86b20>
# Tue, 08 Dec 2020 23:31:44
query4_3 = '''
    WITH scUnion(city) as (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store),
        
        sNamesCities(name, city) as (
        SELECT sName, city
        FROM store)
    
    SELECT s.name, s.city
    FROM sNamesCities as s
    WHERE NOT EXISTS (
        SELECT u.city
        FROM scUnion as u
        
        EXCEPT
        
        SELECT sc.city
        FROM sNamesCities as sc
        WHERE sc.name = s.name)
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [name, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 23:31:59
query4_3 = '''
    WITH scUnion(city) as (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store),
        
        sNamesCities(name, city) as (
        SELECT sName, city
        FROM store)
    
    SELECT s.name, s.city
    FROM sNamesCities as s
    WHERE NOT EXISTS (
        (SELECT u.city
        FROM scUnion as u)
        
        EXCEPT
        
        (SELECT sc.city
        FROM sNamesCities as sc
        WHERE sc.name = s.name)
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 23:32:04
query4_3 = '''
    WITH scUnion(city) as (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store),
        
        sNamesCities(name, city) as (
        SELECT sName, city
        FROM store)
    
    SELECT s.name, s.city
    FROM sNamesCities as s
    WHERE NOT EXISTS (
        (SELECT u.city
        FROM scUnion as u)
        
        EXCEPT
        
        (SELECT sc.city
        FROM sNamesCities as sc
        WHERE sc.name = s.name))
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 23:32:16
query4_3 = '''
    WITH scUnion(city) as (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store),
        
        sNamesCities(name, city) as (
        SELECT sName, city
        FROM store)
    
    SELECT s.name, s.city
    FROM sNamesCities as s
    WHERE NOT EXISTS (
        (SELECT u.city
        FROM scUnion as u)
        
        EXCEPT
        
        (SELECT sc.city
        FROM sNamesCities as sc
        WHERE sc.name = s.name) )
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 23:32:41
query4_3 = '''
    WITH scUnion(city) as (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store),
        
        sNamesCities(name, city) as (
        SELECT sName, city
        FROM store)
    
    SELECT s.name, s.city
    FROM sNamesCities as s
    WHERE NOT EXISTS (
        SELECT u.city
        FROM scUnion as u
        
        EXCEPT
        
        SELECT sc.city
        FROM sNamesCities as sc
        WHERE sc.name = s.name)
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [name, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 23:46:54
query4_4 = '''
    WITH dateSums(cID, date, price) as (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date)
    
    SELECT *
    FROM dateSums
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   4.20
#[Out]# 7      4  2018-08-24  14.25
#[Out]# 8      4  2018-08-25  19.40
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   6.70
#[Out]# 12     7  2018-08-23   3.80
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   3.10
#[Out]# 16     8  2018-08-16   6.25
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17  13.30
#[Out]# 20    13  2018-08-25   6.50
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19  11.05
#[Out]# 26    16  2018-08-24   6.05
#[Out]# 27    16  2018-08-25   4.95
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   7.50
#[Out]# 256  179  2018-08-22  10.85
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   6.95
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.65
#[Out]# 261  181  2018-08-24   3.60
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28  14.90
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15  19.60
#[Out]# 273  190  2018-08-16  12.80
#[Out]# 274  190  2018-08-17  15.75
#[Out]# 275  190  2018-08-18  14.85
#[Out]# 276  190  2018-08-19  20.30
#[Out]# 277  190  2018-08-20  10.85
#[Out]# 278  190  2018-08-21   3.85
#[Out]# 279  190  2018-08-22  14.55
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 23:47:08
query4_4 = '''
    WITH dateSums(cID, date, price) as (
        SELECT cID, date, max(price)
        FROM purchase
        GROUP BY cID, date)
    
    SELECT *
    FROM dateSums
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   4.65
#[Out]# 2      1  2018-08-21   9.10
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   3.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   2.75
#[Out]# 7      4  2018-08-24   9.05
#[Out]# 8      4  2018-08-25  13.60
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   2.20
#[Out]# 12     7  2018-08-23   2.10
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   2.05
#[Out]# 16     8  2018-08-16   5.30
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17   5.40
#[Out]# 20    13  2018-08-25   2.40
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19   9.25
#[Out]# 26    16  2018-08-24   3.70
#[Out]# 27    16  2018-08-25   2.50
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   3.90
#[Out]# 256  179  2018-08-22   9.00
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   3.70
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.05
#[Out]# 261  181  2018-08-24   2.70
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28   9.70
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15   4.15
#[Out]# 273  190  2018-08-16   3.25
#[Out]# 274  190  2018-08-17   3.80
#[Out]# 275  190  2018-08-18   4.35
#[Out]# 276  190  2018-08-19   4.45
#[Out]# 277  190  2018-08-20   3.20
#[Out]# 278  190  2018-08-21   3.30
#[Out]# 279  190  2018-08-22   4.05
#[Out]# 280  190  2018-08-23   2.85
#[Out]# 281  190  2018-08-24   2.55
#[Out]# 282  190  2018-08-25   3.70
#[Out]# 283  190  2018-08-26   4.30
#[Out]# 284  190  2018-08-27   4.35
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 23:47:18
query4_4 = '''
    WITH dateSums(cID, date, price) as (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date)
    
    SELECT *
    FROM dateSums
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   4.20
#[Out]# 7      4  2018-08-24  14.25
#[Out]# 8      4  2018-08-25  19.40
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   6.70
#[Out]# 12     7  2018-08-23   3.80
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   3.10
#[Out]# 16     8  2018-08-16   6.25
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17  13.30
#[Out]# 20    13  2018-08-25   6.50
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19  11.05
#[Out]# 26    16  2018-08-24   6.05
#[Out]# 27    16  2018-08-25   4.95
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   7.50
#[Out]# 256  179  2018-08-22  10.85
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   6.95
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.65
#[Out]# 261  181  2018-08-24   3.60
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28  14.90
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15  19.60
#[Out]# 273  190  2018-08-16  12.80
#[Out]# 274  190  2018-08-17  15.75
#[Out]# 275  190  2018-08-18  14.85
#[Out]# 276  190  2018-08-19  20.30
#[Out]# 277  190  2018-08-20  10.85
#[Out]# 278  190  2018-08-21   3.85
#[Out]# 279  190  2018-08-22  14.55
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 23:47:23
query4_4 = '''
    WITH dateSums(cID, date, price) as (
        SELECT cID, date, count(price)
        FROM purchase
        GROUP BY cID, date)
    
    SELECT *
    FROM dateSums
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22      1
#[Out]# 1      1  2018-08-20      5
#[Out]# 2      1  2018-08-21      2
#[Out]# 3      2  2018-08-16      1
#[Out]# 4      2  2018-08-17      4
#[Out]# 5      3  2018-08-18      1
#[Out]# 6      3  2018-08-19      2
#[Out]# 7      4  2018-08-24      3
#[Out]# 8      4  2018-08-25      3
#[Out]# 9      5  2018-08-17      1
#[Out]# 10     5  2018-08-22      1
#[Out]# 11     5  2018-08-23      4
#[Out]# 12     7  2018-08-23      2
#[Out]# 13     7  2018-08-24      1
#[Out]# 14     7  2018-08-25      1
#[Out]# 15     7  2018-08-26      2
#[Out]# 16     8  2018-08-16      2
#[Out]# 17    10  2018-08-27      1
#[Out]# 18    11  2018-08-25      1
#[Out]# 19    13  2018-08-17      3
#[Out]# 20    13  2018-08-25      4
#[Out]# 21    13  2018-08-26      1
#[Out]# 22    13  2018-08-27      1
#[Out]# 23    15  2018-08-27      1
#[Out]# 24    16  2018-08-18      1
#[Out]# 25    16  2018-08-19      2
#[Out]# 26    16  2018-08-24      2
#[Out]# 27    16  2018-08-25      3
#[Out]# 28    16  2018-08-26      1
#[Out]# 29    16  2018-08-27      1
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27      2
#[Out]# 256  179  2018-08-22      2
#[Out]# 257  179  2018-08-23      1
#[Out]# 258  179  2018-08-24      3
#[Out]# 259  180  2018-08-26      1
#[Out]# 260  180  2018-08-27      2
#[Out]# 261  181  2018-08-24      2
#[Out]# 262  181  2018-08-27      1
#[Out]# 263  182  2018-08-23      1
#[Out]# 264  182  2018-08-28      3
#[Out]# 265  184  2018-08-20      1
#[Out]# 266  185  2018-08-20      1
#[Out]# 267  186  2018-08-21      1
#[Out]# 268  188  2018-08-20      1
#[Out]# 269  188  2018-09-20      1
#[Out]# 270  189  2018-08-25      1
#[Out]# 271  189  2018-08-26      1
#[Out]# 272  190  2018-08-15      8
#[Out]# 273  190  2018-08-16      4
#[Out]# 274  190  2018-08-17      7
#[Out]# 275  190  2018-08-18      5
#[Out]# 276  190  2018-08-19      8
#[Out]# 277  190  2018-08-20      4
#[Out]# 278  190  2018-08-21      2
#[Out]# 279  190  2018-08-22      6
#[Out]# 280  190  2018-08-23      6
#[Out]# 281  190  2018-08-24      2
#[Out]# 282  190  2018-08-25      3
#[Out]# 283  190  2018-08-26      7
#[Out]# 284  190  2018-08-27      2
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 23:47:28
query4_4 = '''
    WITH dateSums(cID, date, price) as (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date)
    
    SELECT *
    FROM dateSums
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   4.20
#[Out]# 7      4  2018-08-24  14.25
#[Out]# 8      4  2018-08-25  19.40
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   6.70
#[Out]# 12     7  2018-08-23   3.80
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   3.10
#[Out]# 16     8  2018-08-16   6.25
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17  13.30
#[Out]# 20    13  2018-08-25   6.50
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19  11.05
#[Out]# 26    16  2018-08-24   6.05
#[Out]# 27    16  2018-08-25   4.95
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   7.50
#[Out]# 256  179  2018-08-22  10.85
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   6.95
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.65
#[Out]# 261  181  2018-08-24   3.60
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28  14.90
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15  19.60
#[Out]# 273  190  2018-08-16  12.80
#[Out]# 274  190  2018-08-17  15.75
#[Out]# 275  190  2018-08-18  14.85
#[Out]# 276  190  2018-08-19  20.30
#[Out]# 277  190  2018-08-20  10.85
#[Out]# 278  190  2018-08-21   3.85
#[Out]# 279  190  2018-08-22  14.55
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 23:49:20
query4_4 = '''
    WITH dateSums(cID, date, price) as (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date),
        
        maxDateSum(value) as (
        SELECT max(price)
        FROM dateSums)
    
    SELECT *
    FROM maxDateSum
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    value
#[Out]# 0   39.1
# Tue, 08 Dec 2020 23:52:46
query4_4 = '''
    WITH dateSums(cID, date, price) as (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date),
        
        maxDateSum(value) as (
        SELECT max(price)
        FROM dateSums)
    
    SELECT c.cName
    FROM customer as c, dateSums as d, maxDateSum
    WHERE c.cID = d.cID
        AND d.price >= maxDateSum.value*0.75
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 23:59:04
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, DISTINCT c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.sName = "Eindhoven")
    
    SELECT city, count(cID)
    FROM ePurchases
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 00:00:56
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT DISTINCT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.sName = "Eindhoven")
    
    SELECT city, count(cID)
    FROM ePurchases
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, count(cID)]
#[Out]# Index: []
# Wed, 09 Dec 2020 00:01:03
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.sName = "Eindhoven")
    
    SELECT city, count(cID)
    FROM ePurchases
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, count(cID)]
#[Out]# Index: []
# Wed, 09 Dec 2020 00:02:04
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.sName = "Tilburg")
    
    SELECT city, count(cID)
    FROM ePurchases
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, count(cID)]
#[Out]# Index: []
# Wed, 09 Dec 2020 00:04:24
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.sName = "Eindhoven")
    
    SELECT *
    FROM ePurchases
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, cID]
#[Out]# Index: []
# Wed, 09 Dec 2020 00:06:00
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID)
    
    SELECT *
    FROM ePurchases
'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  cID
#[Out]# 0      Utrecht    0
#[Out]# 1        Breda    1
#[Out]# 2        Breda    1
#[Out]# 3        Breda    1
#[Out]# 4        Breda    1
#[Out]# 5        Breda    1
#[Out]# 6        Breda    1
#[Out]# 7        Breda    1
#[Out]# 8    Amsterdam    2
#[Out]# 9    Amsterdam    2
#[Out]# 10   Amsterdam    2
#[Out]# 11   Amsterdam    2
#[Out]# 12   Amsterdam    2
#[Out]# 13       Breda    3
#[Out]# 14       Breda    3
#[Out]# 15       Breda    3
#[Out]# 16   Amsterdam    4
#[Out]# 17   Amsterdam    4
#[Out]# 18   Amsterdam    4
#[Out]# 19   Amsterdam    4
#[Out]# 20   Amsterdam    4
#[Out]# 21   Amsterdam    4
#[Out]# 22     Utrecht    5
#[Out]# 23     Utrecht    5
#[Out]# 24     Utrecht    5
#[Out]# 25     Utrecht    5
#[Out]# 26     Utrecht    5
#[Out]# 27     Utrecht    5
#[Out]# 28   Eindhoven    7
#[Out]# 29   Eindhoven    7
#[Out]# ..         ...  ...
#[Out]# 479    Utrecht  190
#[Out]# 480    Utrecht  190
#[Out]# 481    Utrecht  190
#[Out]# 482    Utrecht  190
#[Out]# 483    Utrecht  190
#[Out]# 484    Utrecht  190
#[Out]# 485    Utrecht  190
#[Out]# 486    Utrecht  190
#[Out]# 487    Utrecht  190
#[Out]# 488    Utrecht  190
#[Out]# 489    Utrecht  190
#[Out]# 490    Utrecht  190
#[Out]# 491    Utrecht  190
#[Out]# 492    Utrecht  190
#[Out]# 493    Utrecht  190
#[Out]# 494    Utrecht  190
#[Out]# 495    Utrecht  190
#[Out]# 496    Utrecht  190
#[Out]# 497    Utrecht  190
#[Out]# 498    Utrecht  190
#[Out]# 499    Utrecht  190
#[Out]# 500    Utrecht  190
#[Out]# 501    Utrecht  190
#[Out]# 502    Utrecht  190
#[Out]# 503    Utrecht  190
#[Out]# 504    Utrecht  190
#[Out]# 505    Utrecht  190
#[Out]# 506    Utrecht  190
#[Out]# 507    Utrecht  190
#[Out]# 508    Utrecht  190
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Wed, 09 Dec 2020 00:06:23
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.sName = "Eindhoven")
    
    SELECT *
    FROM ePurchases
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, cID]
#[Out]# Index: []
# Wed, 09 Dec 2020 00:06:29
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.sName = "Utrecht")
    
    SELECT *
    FROM ePurchases
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, cID]
#[Out]# Index: []
# Wed, 09 Dec 2020 00:06:44
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.city = "Utrecht")
    
    SELECT *
    FROM ePurchases
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  cID
#[Out]# 0       Breda    1
#[Out]# 1       Breda    1
#[Out]# 2   Amsterdam    2
#[Out]# 3       Breda    3
#[Out]# 4   Amsterdam    4
#[Out]# 5   Amsterdam    4
#[Out]# 6     Utrecht    5
#[Out]# 7   Eindhoven    7
#[Out]# 8       Breda    8
#[Out]# 9       Breda    8
#[Out]# 10  Eindhoven   16
#[Out]# 11    Tilburg   17
#[Out]# 12    Tilburg   17
#[Out]# 13    Tilburg   28
#[Out]# 14  Rotterdam   29
#[Out]# 15  Eindhoven   39
#[Out]# 16  Rotterdam   43
#[Out]# 17  Rotterdam   44
#[Out]# 18  Rotterdam   58
#[Out]# 19  Amsterdam   59
#[Out]# 20  Amsterdam   66
#[Out]# 21  Rotterdam   67
#[Out]# 22  Rotterdam   67
#[Out]# 23  Eindhoven   82
#[Out]# 24  Rotterdam   92
#[Out]# 25      Breda   99
#[Out]# 26      Breda  109
#[Out]# 27    Tilburg  112
#[Out]# 28    Tilburg  113
#[Out]# 29    Tilburg  116
#[Out]# ..        ...  ...
#[Out]# 32  Amsterdam  124
#[Out]# 33  Amsterdam  124
#[Out]# 34    Utrecht  129
#[Out]# 35  Rotterdam  131
#[Out]# 36  Amsterdam  134
#[Out]# 37  Amsterdam  134
#[Out]# 38  Rotterdam  144
#[Out]# 39    Utrecht  152
#[Out]# 40    Tilburg  161
#[Out]# 41    Tilburg  161
#[Out]# 42    Tilburg  161
#[Out]# 43  Rotterdam  162
#[Out]# 44    Tilburg  163
#[Out]# 45    Utrecht  169
#[Out]# 46    Utrecht  169
#[Out]# 47    Utrecht  169
#[Out]# 48  Rotterdam  171
#[Out]# 49  Eindhoven  175
#[Out]# 50  Amsterdam  176
#[Out]# 51  Amsterdam  177
#[Out]# 52    Tilburg  179
#[Out]# 53    Tilburg  179
#[Out]# 54    Utrecht  190
#[Out]# 55    Utrecht  190
#[Out]# 56    Utrecht  190
#[Out]# 57    Utrecht  190
#[Out]# 58    Utrecht  190
#[Out]# 59    Utrecht  190
#[Out]# 60    Utrecht  190
#[Out]# 61    Utrecht  190
#[Out]# 
#[Out]# [62 rows x 2 columns]
# Wed, 09 Dec 2020 00:06:54
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.city = "Eindhoven")
    
    SELECT *
    FROM ePurchases
'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  cID
#[Out]# 0        Breda    1
#[Out]# 1        Breda    1
#[Out]# 2    Amsterdam    2
#[Out]# 3    Amsterdam    2
#[Out]# 4        Breda    3
#[Out]# 5    Amsterdam    4
#[Out]# 6    Amsterdam    4
#[Out]# 7      Utrecht    5
#[Out]# 8      Utrecht    5
#[Out]# 9      Utrecht    5
#[Out]# 10   Eindhoven    7
#[Out]# 11       Breda   13
#[Out]# 12       Breda   13
#[Out]# 13       Breda   13
#[Out]# 14       Breda   13
#[Out]# 15       Breda   13
#[Out]# 16       Breda   13
#[Out]# 17   Eindhoven   16
#[Out]# 18     Tilburg   24
#[Out]# 19     Tilburg   24
#[Out]# 20   Rotterdam   25
#[Out]# 21     Utrecht   27
#[Out]# 22   Rotterdam   30
#[Out]# 23   Rotterdam   30
#[Out]# 24   Rotterdam   31
#[Out]# 25       Breda   33
#[Out]# 26       Breda   33
#[Out]# 27       Breda   33
#[Out]# 28       Breda   33
#[Out]# 29       Breda   33
#[Out]# ..         ...  ...
#[Out]# 103    Utrecht  169
#[Out]# 104  Eindhoven  170
#[Out]# 105  Rotterdam  171
#[Out]# 106  Amsterdam  176
#[Out]# 107  Amsterdam  176
#[Out]# 108  Amsterdam  176
#[Out]# 109    Utrecht  178
#[Out]# 110    Tilburg  179
#[Out]# 111  Amsterdam  180
#[Out]# 112  Eindhoven  182
#[Out]# 113  Eindhoven  182
#[Out]# 114  Eindhoven  185
#[Out]# 115  Eindhoven  186
#[Out]# 116  Rotterdam  188
#[Out]# 117  Rotterdam  188
#[Out]# 118    Utrecht  190
#[Out]# 119    Utrecht  190
#[Out]# 120    Utrecht  190
#[Out]# 121    Utrecht  190
#[Out]# 122    Utrecht  190
#[Out]# 123    Utrecht  190
#[Out]# 124    Utrecht  190
#[Out]# 125    Utrecht  190
#[Out]# 126    Utrecht  190
#[Out]# 127    Utrecht  190
#[Out]# 128    Utrecht  190
#[Out]# 129    Utrecht  190
#[Out]# 130    Utrecht  190
#[Out]# 131    Utrecht  190
#[Out]# 132    Utrecht  190
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Wed, 09 Dec 2020 00:07:26
query4_5 = '''
    WITH ePurchases(city, cID) as (
        SELECT c.city, c.cID
        FROM customer as c, purchase as p, store as s
        WHERE c.cID = p.cID
            AND p.sID = s.sID
            AND s.city = "Eindhoven")
    
    SELECT city, count(cID)
    FROM ePurchases
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(cID)
#[Out]# 0  Amsterdam          17
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          24
#[Out]# 3  Rotterdam          16
#[Out]# 4    Tilburg          18
#[Out]# 5    Utrecht          31


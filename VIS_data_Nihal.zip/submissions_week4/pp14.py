# IPython log file

# Sat, 05 Dec 2020 18:41:36
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sat, 05 Dec 2020 18:41:36
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1dfd578b2d0>
# Sat, 05 Dec 2020 18:45:02
query4_3 = '''
    PUT YOUR QUERY HERE
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:46:10
query4_3 = '''
    SELECT sName, city
    FROM store;
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sat, 05 Dec 2020 18:51:01
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s
    WHERE NOT EXISTS (
    (SELECT city FROM customer
     UNION city FROM store) AS cs
    EXCEPT
    (SELECT s.city FROM store s WHERE s.Sname = cs.sName ) );

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:51:10
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s
    WHERE NOT EXISTS (
    (SELECT city FROM customer
     UNION 
     SELECT city FROM store) AS cs
    EXCEPT
    (SELECT s.city FROM store s WHERE s.Sname = cs.sName ) );

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:51:16
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s
    WHERE NOT EXISTS (
    (SELECT city FROM customer
     UNION 
     SELECT city FROM store)) AS cs
    EXCEPT
    (SELECT s.city FROM store s WHERE s.Sname = cs.sName ) );

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:51:23
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s
    WHERE NOT EXISTS (
    (SELECT city FROM customer
     UNION 
     SELECT city FROM store)) AS cs
    EXCEPT
    SELECT s.city FROM store s WHERE s.Sname = cs.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:51:32
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store) AS cs
    EXCEPT
    SELECT s.city FROM store s WHERE s.Sname = cs.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:51:51
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s.city FROM store s WHERE s.Sname = cs.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:52:05
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.Sname = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:52:08
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.Sname = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:52:37
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:53:02
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT * FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:53:19
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store as s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:53:35
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:57:16
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)


'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 18:57:17
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:58:50
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    )
    ;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 18:58:53
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:58:54
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 18:59:12
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    
    SELECT city FROM store)
    ;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:01:10
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    
    SELECT city FROM store)
    ;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:01:16
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:02:31
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    WITH s1(sName, city) as (
    SELECT sName, city FROM store
    )
    SELECT s1.sName, s1.city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:02:40
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    WITH s1(sName, city) as (
    SELECT sName, city FROM store
    )
    SELECT sName, city FROM store
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:03:57
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS ((
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:04:11
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:04:25
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:04:29
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:04:30
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName, city FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:05:37
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:06:22
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:06:28
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:07:32
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    );

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:07:33
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:07:50
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:07:55
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    );

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:07:57
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:07:58
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE  EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:07:59
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE  EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:08:00
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE NOT EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:09:09
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE NOT EXISTS ((
    SELECT city FROM customer
    UNION 
    SELECT city FROM store)
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:12:48
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

# query4_3 = '''
#     SELECT sName FROM store s1
#     WHERE NOT EXISTS (
#     SELECT city FROM customer
#     UNION 
#     SELECT city FROM store
#     EXCEPT
#     SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

# '''

query4_3 = '''
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    ;

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sat, 05 Dec 2020 19:13:12
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

# query4_3 = '''
#     SELECT sName FROM store s1
#     WHERE NOT EXISTS (
#     SELECT city FROM customer
#     UNION 
#     SELECT city FROM store
#     EXCEPT
#     SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

# '''

query4_3 = '''
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT city FROM store WHERE city = "Amsterdam";

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0      Breda
#[Out]# 1  Eindhoven
#[Out]# 2        Oss
#[Out]# 3  Rotterdam
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
# Sat, 05 Dec 2020 19:13:23
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

# query4_3 = '''
#     SELECT sName FROM store s1
#     WHERE NOT EXISTS (
#     SELECT city FROM customer
#     UNION 
#     SELECT city FROM store
#     EXCEPT
#     SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

# '''

query4_3 = '''
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT city FROM store WHERE city = "s1.sName";

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sat, 05 Dec 2020 19:15:15
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# query4_3 = '''
#     SELECT city FROM customer
#     UNION 
#     SELECT city FROM store
#     EXCEPT
#     SELECT city FROM store WHERE city = "Amsterdam";

# '''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:15:32
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

# query4_3 = '''
#     SELECT sName FROM store s1
#     WHERE EXISTS (
#     SELECT city FROM customer
#     UNION 
#     SELECT city FROM store
#     EXCEPT
#     SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

# '''

query4_3 = '''
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT city FROM store WHERE sName = "Jumbo";

'''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1    Utrecht
# Sat, 05 Dec 2020 19:15:36
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName FROM store s1
    WHERE EXISTS (
    SELECT city FROM customer
    UNION 
    SELECT city FROM store
    EXCEPT
    SELECT s2.city FROM store s2 WHERE s2.sName = s1.sName);

'''

# query4_3 = '''
#     SELECT city FROM customer
#     UNION 
#     SELECT city FROM store
#     EXCEPT
#     SELECT city FROM store WHERE city = "Amsterdam";

# '''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:15:59
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);

'''

# query4_3 = '''
#     SELECT city FROM customer
#     UNION 
#     SELECT city FROM store
#     EXCEPT
#     SELECT city FROM store WHERE city = "Amsterdam";

# '''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:17:14
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store);

'''

# query4_3 = '''
#     SELECT city FROM customer
#     UNION 
#     SELECT city FROM store
#     EXCEPT
#     SELECT city FROM store WHERE city = "Amsterdam";

# '''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:17:15
# query4_3 = '''
#     SELECT sName, city
#     FROM store;
# '''

query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);

'''

# query4_3 = '''
#     SELECT city FROM customer
#     UNION 
#     SELECT city FROM store
#     EXCEPT
#     SELECT city FROM store WHERE city = "Amsterdam";

# '''

# SELECT * FROM R as sx
# WHERE NOT EXISTS (
# (SELECT p.y FROM S as p )
# EXCEPT
# (SELECT sp.y FROM  R as sp WHERE sp.x = sx.x ) );


pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:18:26
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);

'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:18:29
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:21:17
query4_3 = '''
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sat, 05 Dec 2020 19:21:56
query4_3 = '''
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    WHERE cName = "Jumbo"
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:21:59
query4_3 = '''
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    WHERE sName = "Jumbo"
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sat, 05 Dec 2020 19:22:02
query4_3 = '''
    SELECT city 
    FROM store
    WHERE sName = "Jumbo"
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Rotterdam
#[Out]# 1  Rotterdam
#[Out]# 2    Tilburg
#[Out]# 3  Eindhoven
#[Out]# 4  Eindhoven
#[Out]# 5      Breda
#[Out]# 6  Eindhoven
#[Out]# 7        Oss
# Sat, 05 Dec 2020 19:22:10
query4_3 = '''
    SELECT DISTINCT city 
    FROM store
    WHERE sName = "Jumbo"
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Rotterdam
#[Out]# 1    Tilburg
#[Out]# 2  Eindhoven
#[Out]# 3      Breda
#[Out]# 4        Oss
# Sat, 05 Dec 2020 19:22:47
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName
    AND s2.city <> "Amsterdam"
    AND s2.city <> "Utrecht");
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:23:23
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    
    WHERE s2.city <> "Amsterdam"
    AND s2.city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE s2.city <> "Amsterdam"
    AND s2.city <> "Utrecht"
    
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:23:32
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
# Sat, 05 Dec 2020 19:24:12
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    

    
    UNION 
    SELECT city 
    FROM store
    

    
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:24:14
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
# Sat, 05 Dec 2020 19:24:32
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    
    WHERE city <> "Oss"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Oss"
    
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:25:18
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    
    WHERE city <> "Oss"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Oss"
    
    );
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:25:21
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
# Sat, 05 Dec 2020 19:36:00
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht");
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:36:01
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
# Sat, 05 Dec 2020 19:37:22
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE city NOT IN (
    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Sat, 05 Dec 2020 19:37:27
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
# Sat, 05 Dec 2020 19:37:58
SELECT city 
FROM customer

WHERE city <> "Amsterdam"
AND city <> "Utrecht"

UNION 
SELECT city 
FROM store

WHERE city <> "Amsterdam"
AND city <> "Utrecht"

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:38:09
query4_3 = '''

    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0      Breda
#[Out]# 1  Eindhoven
#[Out]# 2        Oss
#[Out]# 3  Rotterdam
#[Out]# 4    Tilburg
# Sat, 05 Dec 2020 19:38:25
query4_3 = '''

    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Jumbo");
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:38:32
query4_3 = '''

    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Jumbo";
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:38:46
query4_3 = '''

    SELECT city 
    FROM customer
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    UNION 
    SELECT city 
    FROM store
    
    WHERE city <> "Amsterdam"
    AND city <> "Utrecht"
    
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:39:11
query4_3 = '''

    SELECT city 
    FROM customer

    
    UNION 
    SELECT city 
    FROM store

    
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:39:14
query4_3 = '''

    SELECT city 
    FROM customer
    
    UNION 
    SELECT city 
    FROM store
    
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:39:17
query4_3 = '''
    SELECT city 
    FROM customer
    
    UNION 
    SELECT city 
    FROM store
    
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:39:20
query4_3 = '''
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:39:35
query4_3 = '''
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:40:49
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE sName = "Lidl"
    AND city NOT IN (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl");
'''

pd.read_sql_query(query4_3, conn)
#[Out]#   sName
#[Out]# 0  Lidl
#[Out]# 1  Lidl
#[Out]# 2  Lidl
#[Out]# 3  Lidl
#[Out]# 4  Lidl
#[Out]# 5  Lidl
#[Out]# 6  Lidl
#[Out]# 7  Lidl
#[Out]# 8  Lidl
#[Out]# 9  Lidl
# Sat, 05 Dec 2020 19:40:56
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE sName = "Lidl"
    AND NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl");
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:41:01
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE sName = "Lidl"
    AND city NOT IN (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl");
'''

pd.read_sql_query(query4_3, conn)
#[Out]#   sName
#[Out]# 0  Lidl
#[Out]# 1  Lidl
#[Out]# 2  Lidl
#[Out]# 3  Lidl
#[Out]# 4  Lidl
#[Out]# 5  Lidl
#[Out]# 6  Lidl
#[Out]# 7  Lidl
#[Out]# 8  Lidl
#[Out]# 9  Lidl
# Sat, 05 Dec 2020 19:42:16
query4_3 = '''
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:42:21
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE sName = "Lidl"
    AND city NOT IN (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl");
'''

pd.read_sql_query(query4_3, conn)
#[Out]#   sName
#[Out]# 0  Lidl
#[Out]# 1  Lidl
#[Out]# 2  Lidl
#[Out]# 3  Lidl
#[Out]# 4  Lidl
#[Out]# 5  Lidl
#[Out]# 6  Lidl
#[Out]# 7  Lidl
#[Out]# 8  Lidl
#[Out]# 9  Lidl
# Sat, 05 Dec 2020 19:42:40
query4_3 = '''
    SELECT sName, city
    FROM store s1
    WHERE sName = "Lidl"
    AND city NOT IN (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl");
'''

pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Lidl  Eindhoven
#[Out]# 1  Lidl  Amsterdam
#[Out]# 2  Lidl    Utrecht
#[Out]# 3  Lidl  Amsterdam
#[Out]# 4  Lidl    Utrecht
#[Out]# 5  Lidl  Eindhoven
#[Out]# 6  Lidl  Rotterdam
#[Out]# 7  Lidl  Eindhoven
#[Out]# 8  Lidl      Breda
#[Out]# 9  Lidl      Breda
# Sat, 05 Dec 2020 19:43:06
query4_3 = '''
    SELECT sName, city
    FROM store s1
    WHERE sName = "Lidl"
    AND NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl");
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:43:10
query4_3 = '''
    SELECT sName, city
    FROM store s1
    WHERE sName = "Lidl"
    AND city NOT IN (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl");
'''

pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Lidl  Eindhoven
#[Out]# 1  Lidl  Amsterdam
#[Out]# 2  Lidl    Utrecht
#[Out]# 3  Lidl  Amsterdam
#[Out]# 4  Lidl    Utrecht
#[Out]# 5  Lidl  Eindhoven
#[Out]# 6  Lidl  Rotterdam
#[Out]# 7  Lidl  Eindhoven
#[Out]# 8  Lidl      Breda
#[Out]# 9  Lidl      Breda
# Sat, 05 Dec 2020 19:46:33
query4_3 = '''
    SELECT city 
    FROM customer WHERE sName = "Lidl"
    UNION 
    SELECT city 
    FROM store WHERE sName = "Lidl"
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:46:36
query4_3 = '''
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store WHERE sName = "Lidl"
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:46:39
query4_3 = '''
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:47:32
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer

    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:47:35
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:48:31
query4_3 = '''
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl";
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       city
#[Out]# 0      Oss
#[Out]# 1  Tilburg
# Sat, 05 Dec 2020 19:48:59
query4_3 = '''
    SELECT sName, city
    FROM store s1
    WHERE sName = "Lidl"
    AND city NOT IN (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl");
'''

pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Lidl  Eindhoven
#[Out]# 1  Lidl  Amsterdam
#[Out]# 2  Lidl    Utrecht
#[Out]# 3  Lidl  Amsterdam
#[Out]# 4  Lidl    Utrecht
#[Out]# 5  Lidl  Eindhoven
#[Out]# 6  Lidl  Rotterdam
#[Out]# 7  Lidl  Eindhoven
#[Out]# 8  Lidl      Breda
#[Out]# 9  Lidl      Breda
# Sat, 05 Dec 2020 19:50:01
query4_3 = '''
    SELECT sName, city
    FROM store s1
    WHERE sName = "Lidl"
    AND NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT city 
    FROM store 
    WHERE sName = "Lidl");
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:54:24
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 19:57:26
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    UNION 
    SELECT city 
    FROM store WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
# Sat, 05 Dec 2020 19:57:30
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    UNION 
    SELECT city 
    FROM store WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName WHERE city <> 'Utrecht' AND city <> 'Amsterdam');
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:57:38
query4_3 = '''
    SELECT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    UNION 
    SELECT city 
    FROM store WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    EXCEPT
    SELECT s2.city 
    FROM store s2 
    WHERE s2.sName = s1.sName AND city <> 'Utrecht' AND city <> 'Amsterdam' );
'''

pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
# Sat, 05 Dec 2020 19:59:02
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    UNION 
    SELECT city 
    FROM store WHERE city <> 'Utrecht' AND city <> 'Amsterdam'
    EXCEPT
    SELECT s2.city
    FROM store s2 
    WHERE s2.sName = s1.sName AND city <> 'Utrecht' AND city <> 'Amsterdam');
'''

pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
# Sat, 05 Dec 2020 19:59:33
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city
    FROM store s2 
    WHERE s2.sName = s1.sName;
'''

pd.read_sql_query(query4_3, conn)
# Sat, 05 Dec 2020 19:59:40
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city
    FROM store s2
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 20:10:44
query4_4 = '''
    SELECT cID, SUM(price)
    FROM purchase p
    GROUP BY cID
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID  SUM(price)
#[Out]# 0      0        0.45
#[Out]# 1      1       24.20
#[Out]# 2      2       10.15
#[Out]# 3      3        8.50
#[Out]# 4      4       33.65
#[Out]# ..   ...         ...
#[Out]# 127  185        1.00
#[Out]# 128  186        1.00
#[Out]# 129  188        2.00
#[Out]# 130  189        3.75
#[Out]# 131  190      163.65
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Sat, 05 Dec 2020 20:11:09
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  SUM(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 20:11:23
query4_4 = '''
    SELECT cID, date, MAX(SUM(price))
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:11:25
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  SUM(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 20:12:07
query4_4 = '''
    SELECT cID, date, SUM(price) as sum
    FROM purchase p
    GROUP BY cID, date
    HAVING MAX(sum)
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:12:30
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  SUM(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 20:16:24
query4_4 = '''
    SELECT MAX(sum)
    FROM (SELECT cID, date, SUM(price) sum
    FROM purchase p
    GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0      39.1
# Sat, 05 Dec 2020 20:16:36
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  SUM(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 20:16:56
query4_4 = '''
    SELECT MAX(sum)
    FROM (SELECT cID, date, SUM(price) sum
    FROM purchase p
    GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0      39.1
# Sat, 05 Dec 2020 20:20:12
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase p
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:21:09
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:21:18
query4_4 = '''
    SELECT SUM(price)
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      SUM(price)
#[Out]# 0          0.45
#[Out]# 1         14.20
#[Out]# 2         10.00
#[Out]# 3          2.45
#[Out]# 4          7.70
#[Out]# ..          ...
#[Out]# 280       10.60
#[Out]# 281        3.25
#[Out]# 282        9.80
#[Out]# 283       21.90
#[Out]# 284        5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Sat, 05 Dec 2020 20:21:29
query4_4 = '''
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0      39.1
# Sat, 05 Dec 2020 20:21:37
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:22:02
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.MAX(sum)
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:22:08
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:22:44
query4_4 = '''
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0      39.1
# Sat, 05 Dec 2020 20:23:19
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:23:37
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
    WHERE max_money.value = 39.1
    HAVING SUM(price) >= 0.75*max_money
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:23:41
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
    WHERE max_money.value = 39.1
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:23:53
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase
    WHERE max_money.value = 39.1
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:24:28
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  SUM(price)
#[Out]# 0  161  2018-08-26        39.1
# Sat, 05 Dec 2020 20:24:38
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.5*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  SUM(price)
#[Out]# 0   24  2018-08-20       20.70
#[Out]# 1   71  2018-08-24       22.25
#[Out]# 2   82  2018-08-23       21.30
#[Out]# 3  108  2018-08-15       23.95
#[Out]# 4  123  2018-08-17       20.20
#[Out]# 5  124  2018-08-26       28.80
#[Out]# 6  161  2018-08-26       39.10
#[Out]# 7  190  2018-08-15       19.60
#[Out]# 8  190  2018-08-19       20.30
#[Out]# 9  190  2018-08-26       21.90
# Sat, 05 Dec 2020 20:24:41
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID, date, SUM(price)
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  SUM(price)
#[Out]# 0  161  2018-08-26        39.1
# Sat, 05 Dec 2020 20:24:49
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0  161
# Sat, 05 Dec 2020 20:25:20
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT cID
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.5*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   24
#[Out]# 1   71
#[Out]# 2   82
#[Out]# 3  108
#[Out]# 4  123
#[Out]# 5  124
#[Out]# 6  161
#[Out]# 7  190
#[Out]# 8  190
#[Out]# 9  190
# Sat, 05 Dec 2020 20:25:27
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cID
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.5*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   24
#[Out]# 1   71
#[Out]# 2   82
#[Out]# 3  108
#[Out]# 4  123
#[Out]# 5  124
#[Out]# 6  161
#[Out]# 7  190
# Sat, 05 Dec 2020 20:25:31
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cID
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0  161
# Sat, 05 Dec 2020 20:26:22
query4_4 = '''
       SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date    sum
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# ..   ...         ...    ...
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 20:26:31
query4_4 = '''
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0      39.1
# Sat, 05 Dec 2020 20:31:31
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sat, 05 Dec 2020 20:35:06
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cID
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.5*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   24
#[Out]# 1   71
#[Out]# 2   82
#[Out]# 3  108
#[Out]# 4  123
#[Out]# 5  124
#[Out]# 6  161
#[Out]# 7  190
# Sat, 05 Dec 2020 20:35:31
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cID
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.7*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0  124
#[Out]# 1  161
# Sat, 05 Dec 2020 20:35:34
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cID
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0  161
# Sat, 05 Dec 2020 20:38:21
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:38:28
query4_5 = '''
    SELECT c.city, COUNT(cID)
    FROM customer, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:38:31
query4_5 = '''
    SELECT c.city, COUNT(cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:38:34
query4_5 = '''
    SELECT c.city, COUNT(c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:38:40
query4_5 = '''
    SELECT c.city, COUNT(c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam         13234
#[Out]# 1      Breda         13743
#[Out]# 2  Eindhoven         16797
#[Out]# 3        Oss           509
#[Out]# 4  Rotterdam         14761
#[Out]# 5    Tilburg         19342
#[Out]# 6    Utrecht         18324
# Sat, 05 Dec 2020 20:38:56
query4_5 = '''
    SELECT DISTINCT c.city, COUNT(c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam         13234
#[Out]# 1      Breda         13743
#[Out]# 2  Eindhoven         16797
#[Out]# 3        Oss           509
#[Out]# 4  Rotterdam         14761
#[Out]# 5    Tilburg         19342
#[Out]# 6    Utrecht         18324
# Sat, 05 Dec 2020 20:40:12
query4_5 = '''
    SELECT c.city, COUNT(c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam            76
#[Out]# 1      Breda            67
#[Out]# 2  Eindhoven            84
#[Out]# 3        Oss             2
#[Out]# 4  Rotterdam            68
#[Out]# 5    Tilburg            90
#[Out]# 6    Utrecht           122
# Sat, 05 Dec 2020 20:40:29
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
# Sat, 05 Dec 2020 20:40:32
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sat, 05 Dec 2020 20:40:57
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     20
#[Out]# 1      Breda                     16
#[Out]# 2  Eindhoven                     22
#[Out]# 3        Oss                      1
#[Out]# 4  Rotterdam                     25
#[Out]# 5    Tilburg                     26
#[Out]# 6    Utrecht                     22
# Sat, 05 Dec 2020 20:41:04
query4_5 = '''
    SELECT city, COUNT(DISTINCT cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT cID)
#[Out]# 0  Amsterdam                   26
#[Out]# 1      Breda                   27
#[Out]# 2  Eindhoven                   33
#[Out]# 3        Oss                    1
#[Out]# 4  Rotterdam                   29
#[Out]# 5    Tilburg                   38
#[Out]# 6    Utrecht                   36
# Sat, 05 Dec 2020 20:41:15
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     26
#[Out]# 1      Breda                     27
#[Out]# 2  Eindhoven                     33
#[Out]# 3        Oss                      1
#[Out]# 4  Rotterdam                     29
#[Out]# 5    Tilburg                     38
#[Out]# 6    Utrecht                     36
# Sat, 05 Dec 2020 20:41:17
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sat, 05 Dec 2020 20:41:25
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sat, 05 Dec 2020 20:41:28
query4_5 = '''
    SELECT city, COUNT(DISTINCT cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT cID)
#[Out]# 0  Amsterdam                   26
#[Out]# 1      Breda                   27
#[Out]# 2  Eindhoven                   33
#[Out]# 3        Oss                    1
#[Out]# 4  Rotterdam                   29
#[Out]# 5    Tilburg                   38
#[Out]# 6    Utrecht                   36
# Sat, 05 Dec 2020 20:41:30
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sat, 05 Dec 2020 20:46:22
query4_4 = '''
    SELECT SUM(price)
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      SUM(price)
#[Out]# 0          0.45
#[Out]# 1         14.20
#[Out]# 2         10.00
#[Out]# 3          2.45
#[Out]# 4          7.70
#[Out]# ..          ...
#[Out]# 280       10.60
#[Out]# 281        3.25
#[Out]# 282        9.80
#[Out]# 283       21.90
#[Out]# 284        5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Sat, 05 Dec 2020 20:46:25
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  SUM(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 20:46:37
query4_4 = '''
    SELECT cID, date, SUM(price*quantity)
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  SUM(price*quantity)
#[Out]# 0      0  2018-08-22                 0.45
#[Out]# 1      1  2018-08-20                43.40
#[Out]# 2      1  2018-08-21                61.80
#[Out]# 3      2  2018-08-16                 2.45
#[Out]# 4      2  2018-08-17                32.40
#[Out]# ..   ...         ...                  ...
#[Out]# 280  190  2018-08-23                52.85
#[Out]# 281  190  2018-08-24                18.10
#[Out]# 282  190  2018-08-25                46.20
#[Out]# 283  190  2018-08-26                89.55
#[Out]# 284  190  2018-08-27                32.10
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 20:46:55
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase p
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  SUM(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sat, 05 Dec 2020 20:47:20
query4_4 = '''
    SELECT MAX(sum)
    FROM (SELECT cID, date, SUM(price) sum
    FROM purchase
    GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0      39.1
# Sat, 05 Dec 2020 20:47:27
query4_4 = '''
    SELECT MAX(sum)
    FROM (SELECT cID, date, SUM(price*quantity) sum
    FROM purchase
    GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0    171.25
# Sat, 05 Dec 2020 20:47:35
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price*quantity) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cID
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID]
#[Out]# Index: []
# Sat, 05 Dec 2020 20:47:43
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price*quantity) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cID
    FROM purchase, max_money
    GROUP BY cID, date
    HAVING SUM(price*quantity) >= 0.75*max_money.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   33
#[Out]# 1   71
#[Out]# 2  109
#[Out]# 3  124
#[Out]# 4  161
# Sat, 05 Dec 2020 20:55:46
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND c.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Eindhoven                     22
# Sat, 05 Dec 2020 20:56:08
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     10
#[Out]# 1      Breda                      9
#[Out]# 2  Eindhoven                     15
#[Out]# 3  Rotterdam                     13
#[Out]# 4    Tilburg                     10
#[Out]# 5    Utrecht                     12
# Sat, 05 Dec 2020 20:59:39
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price*quantity) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cName
    FROM purchase p, customer c, max_money mm
    WHERE p.cID = c.cID
    GROUP BY cID, date
    HAVING SUM(price*quantity) >= 0.75*mm.value
'''

pd.read_sql_query(query4_4, conn)
# Sat, 05 Dec 2020 20:59:51
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price*quantity) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cName
    FROM purchase p, customer c, max_money mm
    WHERE p.cID = c.cID
    GROUP BY p.cID, date
    HAVING SUM(price*quantity) >= 0.75*mm.value
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Sat, 05 Dec 2020 21:01:07
query4_5 = '''
    SELECT c.city, COUNT(c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam            17
#[Out]# 1      Breda            27
#[Out]# 2  Eindhoven            24
#[Out]# 3  Rotterdam            16
#[Out]# 4    Tilburg            18
#[Out]# 5    Utrecht            31
# Sat, 05 Dec 2020 21:01:09
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     10
#[Out]# 1      Breda                      9
#[Out]# 2  Eindhoven                     15
#[Out]# 3  Rotterdam                     13
#[Out]# 4    Tilburg                     10
#[Out]# 5    Utrecht                     12
# Sat, 05 Dec 2020 21:10:26
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city
    FROM store s2
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sat, 05 Dec 2020 21:11:32
query4_5 = '''
    SELECT c.city, COUNT(c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.cID)
#[Out]# 0  Amsterdam            17
#[Out]# 1      Breda            27
#[Out]# 2  Eindhoven            24
#[Out]# 3  Rotterdam            16
#[Out]# 4    Tilburg            18
#[Out]# 5    Utrecht            31
# Sat, 05 Dec 2020 21:11:33
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     10
#[Out]# 1      Breda                      9
#[Out]# 2  Eindhoven                     15
#[Out]# 3  Rotterdam                     13
#[Out]# 4    Tilburg                     10
#[Out]# 5    Utrecht                     12
# Sat, 05 Dec 2020 21:12:18
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sat, 05 Dec 2020 21:13:40
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price*quantity) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cName
    FROM purchase p, customer c, max_money mm
    WHERE p.cID = c.cID
    GROUP BY p.cID, date
    HAVING SUM(price*quantity) >= 0.75*mm.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Sat, 05 Dec 2020 21:13:57
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12

# IPython log file

query4_5 = '''
    SELECT city
    FROM customer
    EXCEPT
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:24:26
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 06 Dec 2020 12:24:32
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city
    FROM store s2
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sun, 06 Dec 2020 12:24:32
query4_4 = '''
    SELECT MAX(sum)
    FROM (SELECT cID, date, SUM(price*quantity) sum
    FROM purchase
    GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0    171.25
# Sun, 06 Dec 2020 12:24:32
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price*quantity) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cName
    FROM purchase p, customer c, max_money mm
    WHERE p.cID = c.cID
    GROUP BY p.cID, date
    HAVING SUM(price*quantity) >= 0.75*mm.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Sun, 06 Dec 2020 12:24:32
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sun, 06 Dec 2020 12:24:32
query4_5 = '''
    SELECT city
    FROM customer
    EXCEPT
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:24:53
query4_5 = '''
    SELECT city, 0
    FROM customer
    EXCEPT
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  0
#[Out]# 0  Amsterdam  0
#[Out]# 1      Breda  0
#[Out]# 2  Eindhoven  0
#[Out]# 3        Oss  0
#[Out]# 4  Rotterdam  0
#[Out]# 5    Tilburg  0
#[Out]# 6    Utrecht  0
# Sun, 06 Dec 2020 12:25:03
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sun, 06 Dec 2020 12:25:04
query4_5 = '''
    SELECT city
    FROM customer
    EXCEPT
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:25:22
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
    EXCEPT
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sun, 06 Dec 2020 12:25:34
query4_5 = '''
    SELECT city, COUNT(cID) as number
    FROM customer
    GROUP BY city
    EXCEPT
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 12:25:45
query4_5 = '''
    SELECT city, COUNT(DISTINCT cID) as number
    FROM customer
    GROUP BY city
    EXCEPT
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 12:25:48
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sun, 06 Dec 2020 12:26:21
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 12:26:23
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:26:27
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:26:32
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 12:26:34
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:28:00
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city;
    EXCEPT
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:28:06
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
    EXCEPT
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:28:20
query4_5 = '''
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    EXCEPT
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       0
#[Out]# 1      Breda       0
#[Out]# 2  Eindhoven       0
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       0
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:28:36
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:29:18
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE  c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      20
#[Out]# 1      Breda      16
#[Out]# 2  Eindhoven      22
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      25
#[Out]# 5    Tilburg      26
#[Out]# 6    Utrecht      22
# Sun, 06 Dec 2020 12:29:20
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:29:35
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
    HAVING s.sID = p.sID
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, number]
#[Out]# Index: []
# Sun, 06 Dec 2020 12:29:48
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND s.city = "Eindhoven"
    GROUP BY c.city
    HAVING c.cID = p.cID
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, number]
#[Out]# Index: []
# Sun, 06 Dec 2020 12:30:05
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    GROUP BY c.city
    HAVING s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      20
#[Out]# 1  Rotterdam      25
# Sun, 06 Dec 2020 12:30:16
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
    HAVING s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:30:23
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
    HAVING c.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Eindhoven      15
# Sun, 06 Dec 2020 12:30:25
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
    HAVING s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:30:28
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    GROUP BY c.city
    HAVING s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      20
#[Out]# 1  Rotterdam      25
# Sun, 06 Dec 2020 12:30:30
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    GROUP BY c.city
    HAVING c.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Eindhoven      22
# Sun, 06 Dec 2020 12:30:31
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    GROUP BY c.city
    HAVING s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      20
#[Out]# 1  Rotterdam      25
# Sun, 06 Dec 2020 12:30:38
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY c.city
    HAVING s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, number]
#[Out]# Index: []
# Sun, 06 Dec 2020 12:30:42
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY c.city
    HAVING     AND c.cID = p.cID

'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:30:45
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    GROUP BY c.city
    HAVING c.cID = p.cID

'''

pd.read_sql_query(query4_5, conn)
#[Out]#       city  number
#[Out]# 0  Utrecht      36
# Sun, 06 Dec 2020 12:30:53
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:31:25
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 12:33:33
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT c.cID)
                    FROM store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city) as number
    FROM customer c;
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:33:53
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT s.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven"
                    GROUP BY c.city) as number
    FROM customer c;
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:34:19
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT c.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven"
                    GROUP BY c.city) as number
    FROM customer c;
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:34:26
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT c.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven"
                    GROUP BY s.city) as number
    FROM customer c;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#       city number
#[Out]# 0  Utrecht   None
# Sun, 06 Dec 2020 12:34:36
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT c.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam    26.0
#[Out]# 1      Breda    27.0
#[Out]# 2  Eindhoven    33.0
#[Out]# 3        Oss     NaN
#[Out]# 4  Rotterdam    29.0
#[Out]# 5    Tilburg     NaN
#[Out]# 6    Utrecht     NaN
# Sun, 06 Dec 2020 12:34:43
query4_5 = '''
    SELECT c.city, (SELECT COUNT( c.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam    26.0
#[Out]# 1      Breda    27.0
#[Out]# 2  Eindhoven    33.0
#[Out]# 3        Oss     NaN
#[Out]# 4  Rotterdam    29.0
#[Out]# 5    Tilburg     NaN
#[Out]# 6    Utrecht     NaN
# Sun, 06 Dec 2020 12:34:45
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT c.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam    26.0
#[Out]# 1      Breda    27.0
#[Out]# 2  Eindhoven    33.0
#[Out]# 3        Oss     NaN
#[Out]# 4  Rotterdam    29.0
#[Out]# 5    Tilburg     NaN
#[Out]# 6    Utrecht     NaN
# Sun, 06 Dec 2020 12:35:03
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:35:20
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID) as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       5
#[Out]# 1      Breda       7
#[Out]# 2  Eindhoven       6
#[Out]# 3        Oss       2
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       1
#[Out]# 6    Utrecht       1
# Sun, 06 Dec 2020 12:35:29
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:35:42
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    ) as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       5
#[Out]# 1      Breda       7
#[Out]# 2  Eindhoven       6
#[Out]# 3        Oss       2
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       1
#[Out]# 6    Utrecht       1
# Sun, 06 Dec 2020 12:35:55
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:35:58
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam     133
#[Out]# 1      Breda     133
#[Out]# 2  Eindhoven     133
#[Out]# 3        Oss     133
#[Out]# 4  Rotterdam     133
#[Out]# 5    Tilburg     133
#[Out]# 6    Utrecht     133
# Sun, 06 Dec 2020 12:36:00
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:37:06
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND c.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       0
#[Out]# 1      Breda       0
#[Out]# 2  Eindhoven       6
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       0
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:37:12
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:38:11
query4_5 = '''
    SELECT c.city, (SELECT COUNT(c.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam    26.0
#[Out]# 1      Breda    27.0
#[Out]# 2  Eindhoven    33.0
#[Out]# 3        Oss     NaN
#[Out]# 4  Rotterdam    29.0
#[Out]# 5    Tilburg     NaN
#[Out]# 6    Utrecht     NaN
# Sun, 06 Dec 2020 12:38:17
query4_5 = '''
    SELECT c.city, (SELECT COUNT(p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:38:22
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:38:35
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       1
#[Out]# 1      Breda       1
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:38:39
query4_5 = '''
    SELECT c.city, (SELECT COUNT(p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:39:00
query4_5 = '''
    SELECT c.city, (SELECT COUNT(p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  number
#[Out]# 0      Utrecht       0
#[Out]# 1        Breda       2
#[Out]# 2    Amsterdam       2
#[Out]# 3        Breda       1
#[Out]# 4    Amsterdam       2
#[Out]# ..         ...     ...
#[Out]# 185  Eindhoven       1
#[Out]# 186  Eindhoven       1
#[Out]# 187  Rotterdam       2
#[Out]# 188        Oss       0
#[Out]# 189    Utrecht      15
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 06 Dec 2020 12:39:04
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  number
#[Out]# 0      Utrecht       0
#[Out]# 1        Breda       2
#[Out]# 2    Amsterdam       2
#[Out]# 3        Breda       1
#[Out]# 4    Amsterdam       2
#[Out]# ..         ...     ...
#[Out]# 185  Eindhoven       1
#[Out]# 186  Eindhoven       1
#[Out]# 187  Rotterdam       2
#[Out]# 188        Oss       0
#[Out]# 189    Utrecht      15
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 06 Dec 2020 12:39:14
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven"
                    GROUP BY s.city) as number
    FROM customer c;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  number
#[Out]# 0      Utrecht     NaN
#[Out]# 1        Breda     2.0
#[Out]# 2    Amsterdam     2.0
#[Out]# 3        Breda     1.0
#[Out]# 4    Amsterdam     2.0
#[Out]# ..         ...     ...
#[Out]# 185  Eindhoven     1.0
#[Out]# 186  Eindhoven     1.0
#[Out]# 187  Rotterdam     2.0
#[Out]# 188        Oss     NaN
#[Out]# 189    Utrecht    15.0
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 06 Dec 2020 12:39:28
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  number
#[Out]# 0      Utrecht       0
#[Out]# 1        Breda       2
#[Out]# 2    Amsterdam       2
#[Out]# 3        Breda       1
#[Out]# 4    Amsterdam       2
#[Out]# ..         ...     ...
#[Out]# 185  Eindhoven       1
#[Out]# 186  Eindhoven       1
#[Out]# 187  Rotterdam       2
#[Out]# 188        Oss       0
#[Out]# 189    Utrecht      15
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 06 Dec 2020 12:39:48
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:40:19
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam     133
#[Out]# 1      Breda     133
#[Out]# 2  Eindhoven     133
#[Out]# 3        Oss     133
#[Out]# 4  Rotterdam     133
#[Out]# 5    Tilburg     133
#[Out]# 6    Utrecht     133
# Sun, 06 Dec 2020 12:40:20
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:40:31
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:40:34
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND c.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       0
#[Out]# 1      Breda       0
#[Out]# 2  Eindhoven       6
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       0
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:40:39
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       2
#[Out]# 1      Breda       2
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:40:55
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT *)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:41:04
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT c.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam    26.0
#[Out]# 1      Breda    27.0
#[Out]# 2  Eindhoven    33.0
#[Out]# 3        Oss     NaN
#[Out]# 4  Rotterdam    29.0
#[Out]# 5    Tilburg     NaN
#[Out]# 6    Utrecht     NaN
# Sun, 06 Dec 2020 12:41:11
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       1
#[Out]# 1      Breda       1
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:41:24
query4_5 = '''
SELECT COUNT(DISTINCT p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:41:33
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sun, 06 Dec 2020 12:41:36
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      69
#[Out]# 1      Breda      69
#[Out]# 2  Eindhoven      69
#[Out]# 3        Oss      69
#[Out]# 4  Rotterdam      69
#[Out]# 5    Tilburg      69
#[Out]# 6    Utrecht      69
# Sun, 06 Dec 2020 12:41:42
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       1
#[Out]# 1      Breda       1
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:41:46
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  number
#[Out]# 0      Utrecht       0
#[Out]# 1        Breda       1
#[Out]# 2    Amsterdam       1
#[Out]# 3        Breda       1
#[Out]# 4    Amsterdam       1
#[Out]# ..         ...     ...
#[Out]# 185  Eindhoven       1
#[Out]# 186  Eindhoven       1
#[Out]# 187  Rotterdam       1
#[Out]# 188        Oss       0
#[Out]# 189    Utrecht       1
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 06 Dec 2020 12:41:48
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT p.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
    GROUP BY c.city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam       1
#[Out]# 1      Breda       1
#[Out]# 2  Eindhoven       1
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam       1
#[Out]# 5    Tilburg       0
#[Out]# 6    Utrecht       0
# Sun, 06 Dec 2020 12:42:49
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:42:58
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 12:43:29
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as COUNT number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:43:41
query4_5 = '''
    SELECT c.city, (COUNT(DISTINCT c.cID) as COUNT) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 12:44:46
query4_5 = '''
    SELECT c.city, (SELECT COUNT(DISTINCT c.cID)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#       city number
#[Out]# 0  Utrecht   None
# Sun, 06 Dec 2020 12:44:55
query4_5 = '''
    SELECT c.city, (SELECT COUNT(*)
                    FROM store s, purchase p
                    WHERE s.sID = p.sID
                    AND c.cID = p.cID
                    AND s.city = "Eindhoven") as number
    FROM customer c
'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city  number
#[Out]# 0      Utrecht       0
#[Out]# 1        Breda       2
#[Out]# 2    Amsterdam       2
#[Out]# 3        Breda       1
#[Out]# 4    Amsterdam       2
#[Out]# ..         ...     ...
#[Out]# 185  Eindhoven       1
#[Out]# 186  Eindhoven       1
#[Out]# 187  Rotterdam       2
#[Out]# 188        Oss       0
#[Out]# 189    Utrecht      15
#[Out]# 
#[Out]# [190 rows x 2 columns]
# Sun, 06 Dec 2020 12:45:36
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:45:39
query4_5 = '''
    SELECT c.city, COUNT(*) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3  Rotterdam      16
#[Out]# 4    Tilburg      18
#[Out]# 5    Utrecht      31
# Sun, 06 Dec 2020 12:45:41
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:46:04
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    OR s.city is NULL
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:46:10
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    OR c.city is NULL
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:46:14
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:47:56
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number, count(case when c.cID is null then 1 end)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number  count(case when c.cID is null then 1 end)
#[Out]# 0  Amsterdam      10                                          0
#[Out]# 1      Breda       9                                          0
#[Out]# 2  Eindhoven      15                                          0
#[Out]# 3  Rotterdam      13                                          0
#[Out]# 4    Tilburg      10                                          0
#[Out]# 5    Utrecht      12                                          0
# Sun, 06 Dec 2020 12:48:01
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number, count(case when c.cID is null then 0 end)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number  count(case when c.cID is null then 0 end)
#[Out]# 0  Amsterdam      10                                          0
#[Out]# 1      Breda       9                                          0
#[Out]# 2  Eindhoven      15                                          0
#[Out]# 3  Rotterdam      13                                          0
#[Out]# 4    Tilburg      10                                          0
#[Out]# 5    Utrecht      12                                          0
# Sun, 06 Dec 2020 12:48:09
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number, count(case when c.cID is null then 2 end)
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number  count(case when c.cID is null then 2 end)
#[Out]# 0  Amsterdam      10                                          0
#[Out]# 1      Breda       9                                          0
#[Out]# 2  Eindhoven      15                                          0
#[Out]# 3  Rotterdam      13                                          0
#[Out]# 4    Tilburg      10                                          0
#[Out]# 5    Utrecht      12                                          0
# Sun, 06 Dec 2020 12:48:30
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 12:49:11
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:49:21
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  COUNT(cID)
#[Out]# 0   Amsterdam          10
#[Out]# 1   Amsterdam          26
#[Out]# 2       Breda           9
#[Out]# 3       Breda          27
#[Out]# 4   Eindhoven          15
#[Out]# 5   Eindhoven          33
#[Out]# 6         Oss           1
#[Out]# 7   Rotterdam          13
#[Out]# 8   Rotterdam          29
#[Out]# 9     Tilburg          10
#[Out]# 10    Tilburg          38
#[Out]# 11    Utrecht          12
#[Out]# 12    Utrecht          36
# Sun, 06 Dec 2020 12:49:33
query4_5 = '''
    SELECT city, 0
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city   0
#[Out]# 0   Amsterdam   0
#[Out]# 1   Amsterdam  10
#[Out]# 2       Breda   0
#[Out]# 3       Breda   9
#[Out]# 4   Eindhoven   0
#[Out]# 5   Eindhoven  15
#[Out]# 6         Oss   0
#[Out]# 7   Rotterdam   0
#[Out]# 8   Rotterdam  13
#[Out]# 9     Tilburg   0
#[Out]# 10    Tilburg  10
#[Out]# 11    Utrecht   0
#[Out]# 12    Utrecht  12
# Sun, 06 Dec 2020 12:49:45
query4_5 = '''
    SELECT DISTINCT city, 0
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city   0
#[Out]# 0   Amsterdam   0
#[Out]# 1   Amsterdam  10
#[Out]# 2       Breda   0
#[Out]# 3       Breda   9
#[Out]# 4   Eindhoven   0
#[Out]# 5   Eindhoven  15
#[Out]# 6         Oss   0
#[Out]# 7   Rotterdam   0
#[Out]# 8   Rotterdam  13
#[Out]# 9     Tilburg   0
#[Out]# 10    Tilburg  10
#[Out]# 11    Utrecht   0
#[Out]# 12    Utrecht  12
# Sun, 06 Dec 2020 12:50:12
query4_5 = '''
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  number
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Sun, 06 Dec 2020 12:50:22
query4_5 = '''
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT DISTINCT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  number
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Sun, 06 Dec 2020 12:50:45
query4_5 = '''
    SELECT DISTINCT city FROM(
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 12:50:49
query4_5 = '''
    SELECT DISTINCT city, number FROM(
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  number
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Sun, 06 Dec 2020 12:51:24
query4_5 = '''
    SELECT DISTINCT city, SUM(number) FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  SUM(number)
#[Out]# 0  Amsterdam           10
#[Out]# 1      Breda            9
#[Out]# 2  Eindhoven           15
#[Out]# 3        Oss            0
#[Out]# 4  Rotterdam           13
#[Out]# 5    Tilburg           10
#[Out]# 6    Utrecht           12
# Sun, 06 Dec 2020 12:52:04
query4_5 = '''
    SELECT DISTINCT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 12:54:15
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:56:59
query4_5 = '''
    SELECT city, COUNT(*) as number
    FROM customer
    WHERE cID IN (
      SELECT cID
      FROM purchase as p, store as s
      WHERE p.sID = s.sID AND s.city = 'Eindhoven')
     GROUP BY city;
    


'''
#     SELECT *
#     FROM [dbo].[CountData] CD
#     JOIN [dbo].[Count] C
#       ON CD.CountId = C.CountId
#     WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Leg] L
#                       WHERE C.IntersectionId = L.IntersectionId 
#                         AND CD.ApproachId = L.ApproachId)
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:57:04
query4_5 = '''
    SELECT city, COUNT(*) as number
    FROM customer
    WHERE EXISTS (
      SELECT cID
      FROM purchase as p, store as s
      WHERE p.sID = s.sID AND s.city = 'Eindhoven')
     GROUP BY city;
    


'''
#     SELECT *
#     FROM [dbo].[CountData] CD
#     JOIN [dbo].[Count] C
#       ON CD.CountId = C.CountId
#     WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Leg] L
#                       WHERE C.IntersectionId = L.IntersectionId 
#                         AND CD.ApproachId = L.ApproachId)
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 12:57:11
query4_5 = '''
    SELECT city, COUNT(*) as number
    FROM customer
    WHERE cID IN (
      SELECT cID
      FROM purchase as p, store as s
      WHERE p.sID = s.sID AND s.city = 'Eindhoven')
     GROUP BY city;
    


'''
#     SELECT *
#     FROM [dbo].[CountData] CD
#     JOIN [dbo].[Count] C
#       ON CD.CountId = C.CountId
#     WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Leg] L
#                       WHERE C.IntersectionId = L.IntersectionId 
#                         AND CD.ApproachId = L.ApproachId)
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:57:16
query4_5 = '''
    SELECT city, COUNT(*) as number
    FROM customer
    WHERE cID NOT IN (
      SELECT cID
      FROM purchase as p, store as s
      WHERE p.sID = s.sID AND s.city = 'Eindhoven')
     GROUP BY city;
    


'''
#     SELECT *
#     FROM [dbo].[CountData] CD
#     JOIN [dbo].[Count] C
#       ON CD.CountId = C.CountId
#     WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Leg] L
#                       WHERE C.IntersectionId = L.IntersectionId 
#                         AND CD.ApproachId = L.ApproachId)
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      16
#[Out]# 1      Breda      18
#[Out]# 2  Eindhoven      18
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      16
#[Out]# 5    Tilburg      28
#[Out]# 6    Utrecht      24
# Sun, 06 Dec 2020 12:57:18
query4_5 = '''
    SELECT city, COUNT(*) as number
    FROM customer
    WHERE cID IN (
      SELECT cID
      FROM purchase as p, store as s
      WHERE p.sID = s.sID AND s.city = 'Eindhoven')
     GROUP BY city;
    


'''
#     SELECT *
#     FROM [dbo].[CountData] CD
#     JOIN [dbo].[Count] C
#       ON CD.CountId = C.CountId
#     WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Leg] L
#                       WHERE C.IntersectionId = L.IntersectionId 
#                         AND CD.ApproachId = L.ApproachId)
pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 12:59:52
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT 1
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Sun, 06 Dec 2020 12:59:55
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:00:03
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# ..         ...
#[Out]# 185  Eindhoven
#[Out]# 186  Eindhoven
#[Out]# 187  Rotterdam
#[Out]# 188        Oss
#[Out]# 189    Utrecht
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Sun, 06 Dec 2020 13:00:06
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:00:14
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1      Utrecht
#[Out]# 2        Breda
#[Out]# 3    Amsterdam
#[Out]# 4      Tilburg
#[Out]# ..         ...
#[Out]# 116  Amsterdam
#[Out]# 117  Eindhoven
#[Out]# 118    Utrecht
#[Out]# 119  Eindhoven
#[Out]# 120        Oss
#[Out]# 
#[Out]# [121 rows x 1 columns]
# Sun, 06 Dec 2020 13:00:25
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT 1
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1      Utrecht
#[Out]# 2        Breda
#[Out]# 3    Amsterdam
#[Out]# 4      Tilburg
#[Out]# ..         ...
#[Out]# 116  Amsterdam
#[Out]# 117  Eindhoven
#[Out]# 118    Utrecht
#[Out]# 119  Eindhoven
#[Out]# 120        Oss
#[Out]# 
#[Out]# [121 rows x 1 columns]
# Sun, 06 Dec 2020 13:00:27
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1      Utrecht
#[Out]# 2        Breda
#[Out]# 3    Amsterdam
#[Out]# 4      Tilburg
#[Out]# ..         ...
#[Out]# 116  Amsterdam
#[Out]# 117  Eindhoven
#[Out]# 118    Utrecht
#[Out]# 119  Eindhoven
#[Out]# 120        Oss
#[Out]# 
#[Out]# [121 rows x 1 columns]
# Sun, 06 Dec 2020 13:00:37
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:00:42
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# ..         ...
#[Out]# 152  Amsterdam
#[Out]# 153    Utrecht
#[Out]# 154  Rotterdam
#[Out]# 155        Oss
#[Out]# 156    Utrecht
#[Out]# 
#[Out]# [157 rows x 1 columns]
# Sun, 06 Dec 2020 13:00:44
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:01:15
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1      Utrecht
#[Out]# 2        Breda
#[Out]# 3    Amsterdam
#[Out]# 4      Tilburg
#[Out]# ..         ...
#[Out]# 116  Amsterdam
#[Out]# 117  Eindhoven
#[Out]# 118    Utrecht
#[Out]# 119  Eindhoven
#[Out]# 120        Oss
#[Out]# 
#[Out]# [121 rows x 1 columns]
# Sun, 06 Dec 2020 13:01:24
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT DISTINCT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1      Utrecht
#[Out]# 2        Breda
#[Out]# 3    Amsterdam
#[Out]# 4      Tilburg
#[Out]# ..         ...
#[Out]# 116  Amsterdam
#[Out]# 117  Eindhoven
#[Out]# 118    Utrecht
#[Out]# 119  Eindhoven
#[Out]# 120        Oss
#[Out]# 
#[Out]# [121 rows x 1 columns]
# Sun, 06 Dec 2020 13:01:28
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT DISTINCT city
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1      Utrecht
#[Out]# 2        Breda
#[Out]# 3    Amsterdam
#[Out]# 4      Tilburg
#[Out]# ..         ...
#[Out]# 116  Amsterdam
#[Out]# 117  Eindhoven
#[Out]# 118    Utrecht
#[Out]# 119  Eindhoven
#[Out]# 120        Oss
#[Out]# 
#[Out]# [121 rows x 1 columns]
# Sun, 06 Dec 2020 13:01:33
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT DISTINCT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT DISTINCT city
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3    Tilburg
#[Out]# 4  Eindhoven
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Sun, 06 Dec 2020 13:01:36
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT DISTINCT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3    Tilburg
#[Out]# 4  Eindhoven
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Sun, 06 Dec 2020 13:01:47
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT DISTINCT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 13:01:49
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 13:02:02
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY city

'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:02:04
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT city
    FROM customer
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY city

'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:02:10
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT city
    FROM customer
    WHERE NOT EXISTS (SELECT *
                      FROM customer c, store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY city

'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:02:26
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 13:03:24
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 13:03:37
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    OR c.city = "Oss"
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:04:00
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    (WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven")
    OR
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:04:01
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    OR
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:04:14
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    OR NOT EXISTS
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:06:37
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT 1
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1      Utrecht
#[Out]# 2        Breda
#[Out]# 3    Amsterdam
#[Out]# 4      Tilburg
#[Out]# ..         ...
#[Out]# 116  Amsterdam
#[Out]# 117  Eindhoven
#[Out]# 118    Utrecht
#[Out]# 119  Eindhoven
#[Out]# 120        Oss
#[Out]# 
#[Out]# [121 rows x 1 columns]
# Sun, 06 Dec 2020 13:07:32
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT *
    FROM customer c
    WHERE NOT EXISTS (SELECT 1
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#      cID   cName         street       city
#[Out]# 0      0    Noah      Koestraat    Utrecht
#[Out]# 1      6   Milan    Parallelweg    Utrecht
#[Out]# 2      8    Liam  Rijsbergseweg      Breda
#[Out]# 3      9  Thomas    Parallelweg  Amsterdam
#[Out]# 4     10     Sam    Langestraat    Tilburg
#[Out]# ..   ...     ...            ...        ...
#[Out]# 116  177   Eline   Kalverstraat  Amsterdam
#[Out]# 117  181    Liva    Fredriklaan  Eindhoven
#[Out]# 118  183   Nikki  Julianastraat    Utrecht
#[Out]# 119  184   Wilko   Onbekendeweg  Eindhoven
#[Out]# 120  189    Koen       Akkerweg        Oss
#[Out]# 
#[Out]# [121 rows x 4 columns]
# Sun, 06 Dec 2020 13:07:40
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city
    FROM customer c
    WHERE NOT EXISTS (SELECT 1
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1      Utrecht
#[Out]# 2        Breda
#[Out]# 3    Amsterdam
#[Out]# 4      Tilburg
#[Out]# ..         ...
#[Out]# 116  Amsterdam
#[Out]# 117  Eindhoven
#[Out]# 118    Utrecht
#[Out]# 119  Eindhoven
#[Out]# 120        Oss
#[Out]# 
#[Out]# [121 rows x 1 columns]
# Sun, 06 Dec 2020 13:07:44
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(*)
    FROM customer c
    WHERE NOT EXISTS (SELECT 1
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#       city  COUNT(*)
#[Out]# 0  Utrecht       121
# Sun, 06 Dec 2020 13:07:51
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(*)
    FROM customer c
    WHERE NOT EXISTS (SELECT 1
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(*)
#[Out]# 0  Amsterdam        16
#[Out]# 1      Breda        18
#[Out]# 2  Eindhoven        18
#[Out]# 3        Oss         1
#[Out]# 4  Rotterdam        16
#[Out]# 5    Tilburg        28
#[Out]# 6    Utrecht        24
# Sun, 06 Dec 2020 13:08:01
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(*)
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(*)
#[Out]# 0  Amsterdam        16
#[Out]# 1      Breda        18
#[Out]# 2  Eindhoven        18
#[Out]# 3        Oss         1
#[Out]# 4  Rotterdam        16
#[Out]# 5    Tilburg        28
#[Out]# 6    Utrecht        24
# Sun, 06 Dec 2020 13:08:03
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(*)
    FROM customer c
    WHERE NOT EXISTS (SELECT 1
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(*)
#[Out]# 0  Amsterdam        16
#[Out]# 1      Breda        18
#[Out]# 2  Eindhoven        18
#[Out]# 3        Oss         1
#[Out]# 4  Rotterdam        16
#[Out]# 5    Tilburg        28
#[Out]# 6    Utrecht        24
# Sun, 06 Dec 2020 13:08:06
query4_5 = '''
    SELECT DISTINCT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:08:20
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(*)
    FROM customer c
    WHERE NOT EXISTS (SELECT p.cID
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(*)
#[Out]# 0  Amsterdam        16
#[Out]# 1      Breda        18
#[Out]# 2  Eindhoven        18
#[Out]# 3        Oss         1
#[Out]# 4  Rotterdam        16
#[Out]# 5    Tilburg        28
#[Out]# 6    Utrecht        24
# Sun, 06 Dec 2020 13:08:23
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(*)
    FROM customer c
    WHERE NOT EXISTS (SELECT DISTINCT p.cID
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(*)
#[Out]# 0  Amsterdam        16
#[Out]# 1      Breda        18
#[Out]# 2  Eindhoven        18
#[Out]# 3        Oss         1
#[Out]# 4  Rotterdam        16
#[Out]# 5    Tilburg        28
#[Out]# 6    Utrecht        24
# Sun, 06 Dec 2020 13:08:43
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     16
#[Out]# 1      Breda                     18
#[Out]# 2  Eindhoven                     18
#[Out]# 3        Oss                      1
#[Out]# 4  Rotterdam                     16
#[Out]# 5    Tilburg                     28
#[Out]# 6    Utrecht                     24
# Sun, 06 Dec 2020 13:08:48
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#       city  COUNT(DISTINCT c.cID)
#[Out]# 0  Utrecht                    121
# Sun, 06 Dec 2020 13:08:49
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     16
#[Out]# 1      Breda                     18
#[Out]# 2  Eindhoven                     18
#[Out]# 3        Oss                      1
#[Out]# 4  Rotterdam                     16
#[Out]# 5    Tilburg                     28
#[Out]# 6    Utrecht                     24
# Sun, 06 Dec 2020 13:09:24
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, purchase p
    WHERE c.cID = p.cID
    AND NOT EXISTS (SELECT *
                      FROM store s
                          WHERE s.sID = p.sID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     19
#[Out]# 1      Breda                     15
#[Out]# 2  Eindhoven                     18
#[Out]# 3        Oss                      1
#[Out]# 4  Rotterdam                     21
#[Out]# 5    Tilburg                     25
#[Out]# 6    Utrecht                     22
# Sun, 06 Dec 2020 13:09:32
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     16
#[Out]# 1      Breda                     18
#[Out]# 2  Eindhoven                     18
#[Out]# 3        Oss                      1
#[Out]# 4  Rotterdam                     16
#[Out]# 5    Tilburg                     28
#[Out]# 6    Utrecht                     24
# Sun, 06 Dec 2020 13:09:35
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c, purchase p
    WHERE c.cID = p.cID
    AND NOT EXISTS (SELECT *
                      FROM store s
                          WHERE s.sID = p.sID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     19
#[Out]# 1      Breda                     15
#[Out]# 2  Eindhoven                     18
#[Out]# 3        Oss                      1
#[Out]# 4  Rotterdam                     21
#[Out]# 5    Tilburg                     25
#[Out]# 6    Utrecht                     22
# Sun, 06 Dec 2020 13:09:44
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     OR NOT EXISTS (SELECT *)
#     GROUP BY c.city
# '''

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID)
    FROM customer c
    WHERE NOT EXISTS (SELECT *
                      FROM store s, purchase p
                          WHERE s.sID = p.sID
                          AND c.cID = p.cID
                          AND s.city = "Eindhoven")
    GROUP BY c.city

'''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT c.cID)
#[Out]# 0  Amsterdam                     16
#[Out]# 1      Breda                     18
#[Out]# 2  Eindhoven                     18
#[Out]# 3        Oss                      1
#[Out]# 4  Rotterdam                     16
#[Out]# 5    Tilburg                     28
#[Out]# 6    Utrecht                     24
# Sun, 06 Dec 2020 13:10:56
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    OR p.sID IS NULL
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    OR NOT EXISTS (SELECT *)
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:11:07
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    OR p.sID IS NULL
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 13:11:17
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    OR p.cID IS NULL
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      26
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      33
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      29
#[Out]# 5    Tilburg      38
#[Out]# 6    Utrecht      36
# Sun, 06 Dec 2020 13:11:33
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    OR p.cID IS NULL
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      20
#[Out]# 1      Breda      16
#[Out]# 2  Eindhoven      22
#[Out]# 3        Oss       1
#[Out]# 4  Rotterdam      25
#[Out]# 5    Tilburg      26
#[Out]# 6    Utrecht      22
# Sun, 06 Dec 2020 13:12:00
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 13:12:02
query4_5 = '''
    SELECT DISTINCT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:13:28
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND p.cID IS NULL
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, number]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:13:39
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE p.cID IS NULL
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, number]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:13:52
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 13:14:35
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID IS NULL OR p.sID IS NULL OR p.cID IS NULL
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, number]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:14:48
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID IS NULL OR p.sID IS NULL OR p.cID IS NULL
    AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    city  number
#[Out]# 0  None       0
# Sun, 06 Dec 2020 13:15:01
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT c.city, COUNT(c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID IS NULL OR p.sID IS NULL OR p.cID IS NULL
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city, number]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:15:04
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT c.city, COUNT(c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID IS NULL OR p.sID IS NULL OR p.cID IS NULL
    AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    city  number
#[Out]# 0  None       0
# Sun, 06 Dec 2020 13:15:40
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

pd.read_sql_query(query4_5, conn)
#[Out]#    city  number
#[Out]# 0  None       0
# Sun, 06 Dec 2020 13:15:42
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Sun, 06 Dec 2020 13:15:50
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#       number
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3  Rotterdam
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
# Sun, 06 Dec 2020 13:15:59
query4_5 = '''
    SELECT city
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 13:16:13
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city
#[Out]# 0  Oss
# Sun, 06 Dec 2020 13:16:39
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    WITH city_no_customer(value) as (SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:16:51
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city
#[Out]# 0  Oss
# Sun, 06 Dec 2020 13:16:56
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT city, COUNT(*)
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:17:07
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT city, COUNT(*)
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city, COUNT(*) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(*)
#[Out]# 0  Amsterdam        26
#[Out]# 1  Eindhoven        33
#[Out]# 2        Oss         1
#[Out]# 3  Rotterdam        29
#[Out]# 4    Tilburg        38
#[Out]# 5    Utrecht        36
# Sun, 06 Dec 2020 13:17:10
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city
#[Out]# 0  Oss
# Sun, 06 Dec 2020 13:17:20
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:17:34
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT city, 0 as number FROM (SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   city  number
#[Out]# 0  Oss       0
# Sun, 06 Dec 2020 13:18:00
# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID) as number
#     FROM customer c, store s, purchase p
#     WHERE s.sID = p.sID
#     AND c.cID = p.cID
#     AND s.city = "Eindhoven"
#     GROUP BY c.city
# '''

# query4_5 = '''
#     SELECT c.city, COUNT(DISTINCT c.cID)
#     FROM customer c
#     WHERE NOT EXISTS (SELECT *
#                       FROM store s, purchase p
#                           WHERE s.sID = p.sID
#                           AND c.cID = p.cID
#                           AND s.city = "Eindhoven")
#     GROUP BY c.city

# '''

# SELECT *
# FROM dbo.A
#     LEFT JOIN dbo.B ON A.A_ID = B.B_ID
# WHERE B.B_ID IS NULL;

# SELECT *
# FROM dbo.A
# WHERE NOT EXISTS (SELECT 1
#     FROM dbo.B
#     WHERE b.B_ID = a.A_ID);

query4_5 = '''
    SELECT city, 0 as number FROM (SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:20:20
query4_5 = '''
    SELECT DISTINCT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:21:10
query4_5 = '''
    SELECT city, 0 as number FROM (SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:21:13
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:21:17
query4_5 = '''
    SELECT DISTINCT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:21:19
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:21:21
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT( c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      16
#[Out]# 5    Tilburg      18
#[Out]# 6    Utrecht      31
# Sun, 06 Dec 2020 13:21:23
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:21:46
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      69
# Sun, 06 Dec 2020 13:21:47
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:22:49
query4_5 = '''
SELECT city, SUM(number) as number FROM (
SELECT city, 0 as number
FROM customer
GROUP BY city
UNION
SELECT c.city, COUNT(DISTINCT c.cID) as number
FROM customer c, store s, purchase p
WHERE s.sID = p.sID
AND c.cID = p.cID
AND s.city = "Eindhoven"
GROUP BY c.city)
GROUP BY city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:22:50
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12

# IPython log file

# Sun, 06 Dec 2020 13:35:57
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 06 Dec 2020 13:36:00
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 06 Dec 2020 13:36:04
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city
    FROM store s2
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:36:04
query4_4 = '''
    SELECT MAX(sum)
    FROM (SELECT cID, date, SUM(price*quantity) sum
    FROM purchase
    GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0    171.25
# Sun, 06 Dec 2020 13:36:04
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price*quantity) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cName
    FROM purchase p, customer c, max_money mm
    WHERE p.cID = c.cID
    GROUP BY p.cID, date
    HAVING SUM(price*quantity) >= 0.75*mm.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Sun, 06 Dec 2020 13:36:04
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sun, 06 Dec 2020 13:36:04
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Sun, 06 Dec 2020 13:36:04
query4_5 = '''
    SELECT city, 0 as number FROM (SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:36:04
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Sun, 06 Dec 2020 13:37:00
query4_7 = '''
select cID from customer
except
select cID from (
select cID, sID
from customer, store
where customer.city = store.city
except
select cID, sID
from purchase)
'''

pd.read_sql_query(query4_7, conn)
#[Out]#    cID
#[Out]# 0  189
#[Out]# 1  190
# Sun, 06 Dec 2020 13:37:17
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''

select cID, sID
from customer, store
where customer.city = store.city
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1963  190   35
#[Out]# 1964  190   43
#[Out]# 1965  190   44
#[Out]# 1966  190   51
#[Out]# 1967  190   53
#[Out]# 
#[Out]# [1968 rows x 2 columns]
# Sun, 06 Dec 2020 13:37:20
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''

select cID, sID
from customer, store
where customer.city = store.city
except
select cID, sID
from purchase
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:38:00
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''
select cID, sID
from customer, store
where customer.city = store.city
except
select cID, sID
from purchase
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:38:05
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''
select cID, sID
from customer, store
where customer.city = store.city

'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1963  190   35
#[Out]# 1964  190   43
#[Out]# 1965  190   44
#[Out]# 1966  190   51
#[Out]# 1967  190   53
#[Out]# 
#[Out]# [1968 rows x 2 columns]
# Sun, 06 Dec 2020 13:38:07
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''
select cID, sID
from customer, store
where customer.city = store.city
except
select cID, sID
from purchase
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:38:09
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''
select cID, sID
from customer, store
where customer.city = store.city
except
select cID
from purchase
'''

pd.read_sql_query(query4_7, conn)
# Sun, 06 Dec 2020 13:38:11
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''
select cID, sID
from customer, store
where customer.city = store.city
except
select cID, sID
from purchase
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:39:04
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''
select cID, sID
from customer, store
where customer.city = store.city
except
select cID, sID
from purchase
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:39:10
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''
select cID, sID
from customer, store
where customer.city = store.city
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1963  190   35
#[Out]# 1964  190   43
#[Out]# 1965  190   44
#[Out]# 1966  190   51
#[Out]# 1967  190   53
#[Out]# 
#[Out]# [1968 rows x 2 columns]
# Sun, 06 Dec 2020 13:39:12
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''
select cID, sID
from customer, store
where customer.city = store.city
except
select cID, sID
from purchase
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:45:54
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID in (

                        select sID

                        from inventory_size

                        where size <= 20);
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:48:37
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size > 20);
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:48:42
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID in (

                        select sID

                        from inventory_size

                        where size <= 20);
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:48:45
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size > 20);
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:49:00
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size <= 20);
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:50:36
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size > 20);
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:50:44
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size > 10);
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:50:47
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size > 2);
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:50:50
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size > 1);
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:51:19
# query4_6 = '''
# with inventory_size(sID, date, size) as (

#                         select sID, date, count(distinct pID)

#                         from inventory

#                         group by sID, date

#             )

#             select sID, sName

#             from store

#             where sID not in (

#                         select sID

#                         from inventory_size

#                         where size > 1);
# '''

query4_6 = '''

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Sun, 06 Dec 2020 13:51:29
# query4_6 = '''
# with inventory_size(sID, date, size) as (

#                         select sID, date, count(distinct pID)

#                         from inventory

#                         group by sID, date

#             )

#             select sID, sName

#             from store

#             where sID not in (

#                         select sID

#                         from inventory_size

#                         where size > 1);
# '''

query4_6 = '''
                        select sID, date, count(distinct pID)
                        from inventory
                        group by sID, date

'''

pd.read_sql_query(query4_6, conn)
#[Out]#      sID        date  count(distinct pID)
#[Out]# 0      0  2018-07-18                    1
#[Out]# 1      0  2018-08-15                    3
#[Out]# 2      0  2018-08-16                    2
#[Out]# 3      0  2018-08-17                    1
#[Out]# 4      0  2018-08-18                    1
#[Out]# ..   ...         ...                  ...
#[Out]# 517   59  2018-08-24                    1
#[Out]# 518   59  2018-08-25                    2
#[Out]# 519   59  2018-08-26                    2
#[Out]# 520   59  2018-08-27                    1
#[Out]# 521   60  2018-07-10                    1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Sun, 06 Dec 2020 13:51:43
# query4_6 = '''
# with inventory_size(sID, date, size) as (

#                         select sID, date, count(distinct pID)

#                         from inventory

#                         group by sID, date

#             )

#             select sID, sName

#             from store

#             where sID not in (

#                         select sID

#                         from inventory_size

#                         where size > 1);
# '''

query4_6 = '''
    select sID, date, count(distinct pID)
    from inventory
    group by sID, date
'''

pd.read_sql_query(query4_6, conn)
#[Out]#      sID        date  count(distinct pID)
#[Out]# 0      0  2018-07-18                    1
#[Out]# 1      0  2018-08-15                    3
#[Out]# 2      0  2018-08-16                    2
#[Out]# 3      0  2018-08-17                    1
#[Out]# 4      0  2018-08-18                    1
#[Out]# ..   ...         ...                  ...
#[Out]# 517   59  2018-08-24                    1
#[Out]# 518   59  2018-08-25                    2
#[Out]# 519   59  2018-08-26                    2
#[Out]# 520   59  2018-08-27                    1
#[Out]# 521   60  2018-07-10                    1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Sun, 06 Dec 2020 13:52:14
query4_6 = '''
with inventory_size(sID, date, size) as (
            select sID, date, count(distinct pID)
            from inventory
            group by sID, date)
            select sID, sName
            from store
            where sID not in (
                        select sID
                        from inventory_size
                        where size > 1);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#    sID  sName
#[Out]# 0   60   Lidl
#[Out]# 1   61   Lidl
#[Out]# 2   62  Jumbo
#[Out]# 3   63  Jumbo
# Sun, 06 Dec 2020 13:52:19
query4_6 = '''
with inventory_size(sID, date, size) as (
            select sID, date, count(distinct pID)
            from inventory
            group by sID, date)
            select sID, sName
            from store
            where sID not in (
                        select sID
                        from inventory_size
                        where size > 0);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#    sID  sName
#[Out]# 0   61   Lidl
#[Out]# 1   62  Jumbo
#[Out]# 2   63  Jumbo
# Sun, 06 Dec 2020 13:52:24
query4_6 = '''
with inventory_size(sID, date, size) as (
            select sID, date, count(distinct pID)
            from inventory
            group by sID, date)
            select sID, sName
            from store
            where sID not in (
                        select sID
                        from inventory_size
                        where size >= 0);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#    sID  sName
#[Out]# 0   61   Lidl
#[Out]# 1   62  Jumbo
#[Out]# 2   63  Jumbo
# Sun, 06 Dec 2020 13:52:30
query4_6 = '''
with inventory_size(sID, date, size) as (
            select sID, date, count(distinct pID)
            from inventory
            group by sID, date)
            select sID, sName
            from store
            where sID not in (
                        select sID
                        from inventory_size
                        where size > 20);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 61   61       Lidl
#[Out]# 62   62      Jumbo
#[Out]# 63   63      Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sun, 06 Dec 2020 13:52:43
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID in (

                        select sID

                        from inventory_size

                        where size <= 20);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 56   56      Jumbo
#[Out]# 57   57       Dirk
#[Out]# 58   58       Dirk
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 
#[Out]# [61 rows x 2 columns]
# Sun, 06 Dec 2020 13:52:46
query4_6 = '''
with inventory_size(sID, date, size) as (
            select sID, date, count(distinct pID)
            from inventory
            group by sID, date)
            select sID, sName
            from store
            where sID not in (
                        select sID
                        from inventory_size
                        where size > 20);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 61   61       Lidl
#[Out]# 62   62      Jumbo
#[Out]# 63   63      Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sun, 06 Dec 2020 14:01:59
query4_6 = '''
with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID in (

                        select sID

                        from inventory_size

                        where size <= 20);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 56   56      Jumbo
#[Out]# 57   57       Dirk
#[Out]# 58   58       Dirk
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 
#[Out]# [61 rows x 2 columns]
# Sun, 06 Dec 2020 14:02:01
query4_6 = '''
with inventory_size(sID, date, size) as (
            select sID, date, count(distinct pID)
            from inventory
            group by sID, date)
            select sID, sName
            from store
            where sID not in (
                        select sID
                        from inventory_size
                        where size > 20);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 61   61       Lidl
#[Out]# 62   62      Jumbo
#[Out]# 63   63      Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sun, 06 Dec 2020 14:03:03
query4_6 = '''
with inventory_size(sID, date, size) as (
            select sID, date, count(distinct pID)
            from inventory
            group by sID, date)
            select sID, sName
            from store s
            where s.sID not in (
                        select i.sID
                        from inventory_size i
                        where size > 20
                        AND i.sID = s.sID);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 61   61       Lidl
#[Out]# 62   62      Jumbo
#[Out]# 63   63      Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sun, 06 Dec 2020 14:03:08
query4_6 = '''
with inventory_size(sID, date, size) as (
            select sID, date, count(distinct pID)
            from inventory
            group by sID, date)
            select sID, sName
            from store
            where sID not in (
                        select sID
                        from inventory_size
                        where size > 20);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 61   61       Lidl
#[Out]# 62   62      Jumbo
#[Out]# 63   63      Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]

# IPython log file

# Tue, 08 Dec 2020 20:36:13
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 20:36:21
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 08 Dec 2020 20:36:28
query4_3 = '''
    SELECT DISTINCT sName 
    FROM store s1
    WHERE NOT EXISTS (
    SELECT city 
    FROM customer
    UNION 
    SELECT city 
    FROM store
    EXCEPT
    SELECT s2.city
    FROM store s2
    WHERE s2.sName = s1.sName);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 20:36:28
query4_4 = '''
    SELECT MAX(sum)
    FROM (SELECT cID, date, SUM(price*quantity) sum
    FROM purchase
    GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0    171.25
# Tue, 08 Dec 2020 20:36:28
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cName
    FROM purchase p, customer c, max_money mm
    WHERE p.cID = c.cID
    GROUP BY p.cID, date
    HAVING SUM(price) >= 0.75*mm.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 20:36:28
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Tue, 08 Dec 2020 20:36:29
query4_5 = '''
    SELECT city, COUNT(cID)
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Tue, 08 Dec 2020 20:36:29
query4_5 = '''
    SELECT city, 0 as number FROM (SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 20:36:29
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 20:36:29
# query4_7 = '''
# select cID from customer
# except
# select cID from (
# select cID, sID
# from customer, store
# where customer.city = store.city
# except
# select cID, sID
# from purchase)
# '''

query4_7 = '''
select cID, sID
from customer, store
where customer.city = store.city
except
select cID, sID
from purchase
'''

pd.read_sql_query(query4_7, conn)
#[Out]#       cID  sID
#[Out]# 0       0   16
#[Out]# 1       0   31
#[Out]# 2       0   32
#[Out]# 3       0   35
#[Out]# 4       0   43
#[Out]# ...   ...  ...
#[Out]# 1886  188   41
#[Out]# 1887  188   46
#[Out]# 1888  188   47
#[Out]# 1889  188   49
#[Out]# 1890  188   58
#[Out]# 
#[Out]# [1891 rows x 2 columns]
# Tue, 08 Dec 2020 20:36:29
query4_6 = '''
with inventory_size(sID, date, size) as (
            select sID, date, count(distinct pID)
            from inventory
            group by sID, date)
            select sID, sName
            from store
            where sID not in (
                        select sID
                        from inventory_size
                        where size > 20);
'''

# query4_6 = '''
#     select sID, date, count(distinct pID)
#     from inventory
#     group by sID, date
# '''

pd.read_sql_query(query4_6, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 61   61       Lidl
#[Out]# 62   62      Jumbo
#[Out]# 63   63      Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 20:37:41
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cName
    FROM purchase p, customer c, max_money mm
    WHERE p.cID = c.cID
    GROUP BY p.cID, date
    HAVING SUM(price) >= 0.5*mm.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cName
#[Out]# 0    Luca
#[Out]# 1    Dean
#[Out]# 2   Dylan
#[Out]# 3    Noor
#[Out]# 4   Milou
#[Out]# 5   Sofie
#[Out]# 6   Floor
#[Out]# 7  Kostas
# Tue, 08 Dec 2020 20:37:43
query4_4 = '''
    WITH max_money(value) as (
       SELECT MAX(sum)
       FROM (SELECT cID, date, SUM(price) sum
       FROM purchase
       GROUP BY cID, date))
    SELECT DISTINCT cName
    FROM purchase p, customer c, max_money mm
    WHERE p.cID = c.cID
    GROUP BY p.cID, date
    HAVING SUM(price) >= 0.75*mm.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 20:39:10
query4_5 = '''
with ineind(city, number) as (SELECT c.city, COUNT(DISTINCT c.cID) as number
FROM store s, purchase p, customer c
WHERE s.sID = p.sID AND c.cID = p.cID AND s.city = 'Eindhoven'
GROUP BY c.city)
SELECT s.city, 0 as number
FROM store s
UNION 
SELECT i.city, i.number
FROM ineind i
EXCEPT 
SELECT i.city, 0 as number
FROM ineind i
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 20:39:12
query4_5 = '''
    SELECT city, 0 as number FROM (SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 20:39:40
query4_5 = '''
    SELECT city, 0 as number FROM (SELECT city
    FROM customer
    GROUP BY city
    EXCEPT 
    SELECT c.city as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 20:39:47
query4_5 = '''
    SELECT city, SUM(number) as number FROM (
    SELECT city, 0 as number
    FROM customer
    GROUP BY city
    UNION
    SELECT c.city, COUNT(DISTINCT c.cID) as number
    FROM customer c, store s, purchase p
    WHERE s.sID = p.sID
    AND c.cID = p.cID
    AND s.city = "Eindhoven"
    GROUP BY c.city)
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12


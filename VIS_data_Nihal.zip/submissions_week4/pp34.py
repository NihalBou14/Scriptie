# IPython log file

# Tue, 08 Dec 2020 13:10:20
get_ipython().system('conda install sqlvis')
# Tue, 08 Dec 2020 13:11:01
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().system('conda install sqlvis')
# Tue, 08 Dec 2020 13:11:03
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 13:11:04
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x2c4542c7880>
# Tue, 08 Dec 2020 13:33:07
query4_3 = '''
    SELECT *
    FROM store AS s
    WHERE NOT EXISTS {
    SELECT c.city
    FROM (SELECT DISTINCT city
    FROM customer
    UNION
    SELECT DISTINCT city
    FROM store) AS c
    WHERE NOT EXISTS ( SELECT store.city
    FROM store
    WHERE store.sName = s.sName
    )
    }
    
'''
# Tue, 08 Dec 2020 13:33:07
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 13:33:08
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 13:33:24
query4_3 = '''
    SELECT *
    FROM store AS s
    WHERE NOT EXISTS (
    SELECT c.city
    FROM (SELECT DISTINCT city
    FROM customer
    UNION
    SELECT DISTINCT city
    FROM store) AS c
    WHERE NOT EXISTS ( SELECT store.city
    FROM store
    WHERE store.sName = s.sName
    )
    )
    
'''
# Tue, 08 Dec 2020 13:33:24
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 13:33:25
pd.read_sql_query(query4_3, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     0         Coop      Kalverstraat  Amsterdam
#[Out]# 1     1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 5     5       Sligro     Stationsplein      Breda
#[Out]# 6     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 7     7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 8     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 9     9  Albert Hein         Koestraat    Tilburg
#[Out]# 10   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 11   11  Albert Hein          Hofplein  Rotterdam
#[Out]# 12   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 13   13         Coop         Koestraat    Tilburg
#[Out]# 14   14         Coop     Keizersgracht  Amsterdam
#[Out]# 15   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 16   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 17   17    Hoogvliet        Kerkstraat  Eindhoven
#[Out]# 18   18       Sligro       Parallelweg    Tilburg
#[Out]# 19   19         Coop       Karrestraat      Breda
#[Out]# 20   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 21   21         Coop      Kasteeldreef    Tilburg
#[Out]# 22   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 23   23         Dirk     Stationsplein      Breda
#[Out]# 24   24  Albert Hein     Stationsplein      Breda
#[Out]# 25   25  Albert Hein     Stationsplein      Breda
#[Out]# 26   26    Hoogvliet   Sint Annastraat      Breda
#[Out]# 27   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 28   28    Hoogvliet         Koestraat    Tilburg
#[Out]# 29   29       Sligro      Marnixstraat  Amsterdam
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   34         Coop          Bierkaai  Amsterdam
#[Out]# 35   35         Lidl     Julianastraat    Utrecht
#[Out]# 36   36         Lidl     Julianastraat  Eindhoven
#[Out]# 37   37        Jumbo          Molenweg  Eindhoven
#[Out]# 38   38    Hoogvliet          Hofplein  Rotterdam
#[Out]# 39   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 40   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 41   41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 42   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 43   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 44   44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 45   45         Coop      Kasteeldreef    Tilburg
#[Out]# 46   46         Lidl        Bergselaan  Rotterdam
#[Out]# 47   47         Coop     Julianastraat  Rotterdam
#[Out]# 48   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 49   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 50   50       Sligro     Stationsplein      Breda
#[Out]# 51   51         Coop       Parallelweg    Utrecht
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   53         Coop        Hoogstraat    Utrecht
#[Out]# 54   54         Dirk     Julianastraat  Eindhoven
#[Out]# 55   55         Coop   Sint Annastraat      Breda
#[Out]# 56   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 57   57         Dirk       Molenstraat  Eindhoven
#[Out]# 58   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 59   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60         Lidl      Pannekoekweg      Breda
#[Out]# 61   61         Lidl      Pannekoekweg      Breda
#[Out]# 62   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63        Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Tue, 08 Dec 2020 13:33:49
query4_3 = '''
    SELECT DISTINCT sName
    FROM store AS s
    WHERE NOT EXISTS (
    SELECT c.city
    FROM (SELECT DISTINCT city
    FROM customer
    UNION
    SELECT DISTINCT city
    FROM store) AS c
    WHERE NOT EXISTS ( SELECT store.city
    FROM store
    WHERE store.sName = s.sName
    )
    )
    
'''
# Tue, 08 Dec 2020 13:33:50
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 13:33:57
query4_3 = '''
    SELECT DISTINCT sName
    FROM store AS s
    WHERE NOT EXISTS (
    SELECT c.city
    FROM (SELECT DISTINCT city
    FROM customer
    UNION
    SELECT DISTINCT city
    FROM store) AS c
    WHERE NOT EXISTS ( SELECT store.city
    FROM store
    WHERE store.sName = s.sName
    )
    )
    
'''
# Tue, 08 Dec 2020 13:33:58
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 13:33:58
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 13:35:59
query4_3 = '''
    SELECT DISTINCT sName
    FROM store
    WHERE NOT EXISTS (
    SELECT c.city
    FROM (SELECT DISTINCT city
    FROM customer
    UNION
    SELECT DISTINCT city
    FROM store) AS c
    WHERE NOT EXISTS ( SELECT store.city
    FROM store, store AS s
    WHERE store.sName = s.sName
    )
    )
    
'''
# Tue, 08 Dec 2020 13:36:00
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 13:36:00
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 13:42:01
query4_3 = '''
    SELECT DISTINCT sName
    FROM store
    WHERE NOT EXISTS (
    SELECT c.city
    FROM (SELECT DISTINCT city
    FROM customer
    UNION
    SELECT DISTINCT city
    FROM store) AS c
    WHERE NOT EXISTS ( SELECT store.city
    FROM store, store AS s
    WHERE store.sName = s.sName
    )
    )
    
'''
# Tue, 08 Dec 2020 13:42:01
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 13:42:01
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 13:58:09
query4_4 = '''
    SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID, date
    )
'''
# Tue, 08 Dec 2020 13:58:09
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 13:58:09
pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(Sum)
#[Out]# 0      39.1
# Tue, 08 Dec 2020 13:58:20
query4_4 = '''
    SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID
    )
'''
# Tue, 08 Dec 2020 13:58:21
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 13:58:21
pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(Sum)
#[Out]# 0    163.65
# Tue, 08 Dec 2020 13:58:27
query4_4 = '''
    SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID, date
    )
'''
# Tue, 08 Dec 2020 13:58:27
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 13:58:28
pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(Sum)
#[Out]# 0      39.1
# Tue, 08 Dec 2020 14:04:43
query4_4 = '''
    SELECT cName
    FROM customer, (SELECT cId, SUM(price) as cTotal
    FROM purchase
    GROUP BY cID, date) as total
    WHERE customer.cID = total.cID AND cTotal >= 0.75 *
    (SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID, date
    ))
'''
# Tue, 08 Dec 2020 14:04:43
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:04:43
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 14:05:19
query4_4 = '''
    SELECT cName
    FROM customer, (SELECT cId, SUM(price) as cTotal
    FROM purchase
    GROUP BY cID, date) as total
    WHERE customer.cID = total.cID
'''
# Tue, 08 Dec 2020 14:05:19
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:05:20
pd.read_sql_query(query4_4, conn)
#[Out]#        cName
#[Out]# 0       Noah
#[Out]# 1        Sem
#[Out]# 2        Sem
#[Out]# 3      Lucas
#[Out]# 4      Lucas
#[Out]# 5       Finn
#[Out]# 6       Finn
#[Out]# 7       Daan
#[Out]# 8       Daan
#[Out]# 9       Levi
#[Out]# 10      Levi
#[Out]# 11      Levi
#[Out]# 12      Bram
#[Out]# 13      Bram
#[Out]# 14      Bram
#[Out]# 15      Bram
#[Out]# 16      Liam
#[Out]# 17       Sam
#[Out]# 18     Thijs
#[Out]# 19     James
#[Out]# 20     James
#[Out]# 21     James
#[Out]# 22     James
#[Out]# 23      Noud
#[Out]# 24    Julian
#[Out]# 25    Julian
#[Out]# 26    Julian
#[Out]# 27    Julian
#[Out]# 28    Julian
#[Out]# 29    Julian
#[Out]# ..       ...
#[Out]# 255     Elif
#[Out]# 256     Juul
#[Out]# 257     Juul
#[Out]# 258     Juul
#[Out]# 259    Merel
#[Out]# 260    Merel
#[Out]# 261     Liva
#[Out]# 262     Liva
#[Out]# 263  Johanna
#[Out]# 264  Johanna
#[Out]# 265    Wilko
#[Out]# 266     Nick
#[Out]# 267   Angela
#[Out]# 268     Pino
#[Out]# 269     Pino
#[Out]# 270     Koen
#[Out]# 271     Koen
#[Out]# 272   Kostas
#[Out]# 273   Kostas
#[Out]# 274   Kostas
#[Out]# 275   Kostas
#[Out]# 276   Kostas
#[Out]# 277   Kostas
#[Out]# 278   Kostas
#[Out]# 279   Kostas
#[Out]# 280   Kostas
#[Out]# 281   Kostas
#[Out]# 282   Kostas
#[Out]# 283   Kostas
#[Out]# 284   Kostas
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Tue, 08 Dec 2020 14:05:41
query4_4 = '''
    SELECT DISTINCT cName
    FROM customer, (SELECT cId, SUM(price) as cTotal
    FROM purchase
    GROUP BY cID, date) as total
    WHERE customer.cID = total.cID 
'''
# Tue, 08 Dec 2020 14:05:41
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:05:42
pd.read_sql_query(query4_4, conn)
#[Out]#         cName
#[Out]# 0        Noah
#[Out]# 1         Sem
#[Out]# 2       Lucas
#[Out]# 3        Finn
#[Out]# 4        Daan
#[Out]# 5        Levi
#[Out]# 6        Bram
#[Out]# 7        Liam
#[Out]# 8         Sam
#[Out]# 9       Thijs
#[Out]# 10      James
#[Out]# 11       Noud
#[Out]# 12     Julian
#[Out]# 13        Dex
#[Out]# 14       Hugo
#[Out]# 15       Lars
#[Out]# 16       Gijs
#[Out]# 17   Benjamin
#[Out]# 18       Mats
#[Out]# 19       Luca
#[Out]# 20      Mason
#[Out]# 21     Jayden
#[Out]# 22        Tim
#[Out]# 23       Siem
#[Out]# 24      Ruben
#[Out]# 25       Teun
#[Out]# 26    Olivier
#[Out]# 27       Sven
#[Out]# 28      David
#[Out]# 29      Stijn
#[Out]# ..        ...
#[Out]# 101      Fien
#[Out]# 102    Isabel
#[Out]# 103     Lizzy
#[Out]# 104      Jill
#[Out]# 105      Anne
#[Out]# 106      Puck
#[Out]# 107     Fenne
#[Out]# 108     Floor
#[Out]# 109     Elena
#[Out]# 110      Cato
#[Out]# 111     Hanna
#[Out]# 112    Veerle
#[Out]# 113      Kiki
#[Out]# 114      Lily
#[Out]# 115      Iris
#[Out]# 116     Tessa
#[Out]# 117      Lana
#[Out]# 118     Amira
#[Out]# 119     Eline
#[Out]# 120      Elif
#[Out]# 121      Juul
#[Out]# 122     Merel
#[Out]# 123      Liva
#[Out]# 124   Johanna
#[Out]# 125     Wilko
#[Out]# 126      Nick
#[Out]# 127    Angela
#[Out]# 128      Pino
#[Out]# 129      Koen
#[Out]# 130    Kostas
#[Out]# 
#[Out]# [131 rows x 1 columns]
# Tue, 08 Dec 2020 14:06:07
query4_4 = '''
    SELECT DISTINCT cName
    FROM customer, (SELECT cId, SUM(price) as cTotal
    FROM purchase
    GROUP BY cID, date) as total
    WHERE customer.cID = total.cID AND cTotal < 0.75 *
    (SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID, date
    ))
'''
# Tue, 08 Dec 2020 14:06:07
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:06:07
pd.read_sql_query(query4_4, conn)
#[Out]#         cName
#[Out]# 0        Noah
#[Out]# 1         Sem
#[Out]# 2       Lucas
#[Out]# 3        Finn
#[Out]# 4        Daan
#[Out]# 5        Levi
#[Out]# 6        Bram
#[Out]# 7        Liam
#[Out]# 8         Sam
#[Out]# 9       Thijs
#[Out]# 10      James
#[Out]# 11       Noud
#[Out]# 12     Julian
#[Out]# 13        Dex
#[Out]# 14       Hugo
#[Out]# 15       Lars
#[Out]# 16       Gijs
#[Out]# 17   Benjamin
#[Out]# 18       Mats
#[Out]# 19       Luca
#[Out]# 20      Mason
#[Out]# 21     Jayden
#[Out]# 22        Tim
#[Out]# 23       Siem
#[Out]# 24      Ruben
#[Out]# 25       Teun
#[Out]# 26    Olivier
#[Out]# 27       Sven
#[Out]# 28      David
#[Out]# 29      Stijn
#[Out]# ..        ...
#[Out]# 100       Ivy
#[Out]# 101      Fien
#[Out]# 102    Isabel
#[Out]# 103     Lizzy
#[Out]# 104      Jill
#[Out]# 105      Anne
#[Out]# 106      Puck
#[Out]# 107     Fenne
#[Out]# 108     Elena
#[Out]# 109      Cato
#[Out]# 110     Hanna
#[Out]# 111    Veerle
#[Out]# 112      Kiki
#[Out]# 113      Lily
#[Out]# 114      Iris
#[Out]# 115     Tessa
#[Out]# 116      Lana
#[Out]# 117     Amira
#[Out]# 118     Eline
#[Out]# 119      Elif
#[Out]# 120      Juul
#[Out]# 121     Merel
#[Out]# 122      Liva
#[Out]# 123   Johanna
#[Out]# 124     Wilko
#[Out]# 125      Nick
#[Out]# 126    Angela
#[Out]# 127      Pino
#[Out]# 128      Koen
#[Out]# 129    Kostas
#[Out]# 
#[Out]# [130 rows x 1 columns]
# Tue, 08 Dec 2020 14:06:30
query4_4 = '''
    SELECT DISTINCT cName
    FROM customer, (SELECT cId, SUM(price) as cTotal
    FROM purchase
    GROUP BY cID, date) as total
    WHERE customer.cID = total.cID AND cTotal < 0.75 *
    (SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID, date
    ))
'''
# Tue, 08 Dec 2020 14:06:31
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:06:31
pd.read_sql_query(query4_4, conn)
#[Out]#         cName
#[Out]# 0        Noah
#[Out]# 1         Sem
#[Out]# 2       Lucas
#[Out]# 3        Finn
#[Out]# 4        Daan
#[Out]# 5        Levi
#[Out]# 6        Bram
#[Out]# 7        Liam
#[Out]# 8         Sam
#[Out]# 9       Thijs
#[Out]# 10      James
#[Out]# 11       Noud
#[Out]# 12     Julian
#[Out]# 13        Dex
#[Out]# 14       Hugo
#[Out]# 15       Lars
#[Out]# 16       Gijs
#[Out]# 17   Benjamin
#[Out]# 18       Mats
#[Out]# 19       Luca
#[Out]# 20      Mason
#[Out]# 21     Jayden
#[Out]# 22        Tim
#[Out]# 23       Siem
#[Out]# 24      Ruben
#[Out]# 25       Teun
#[Out]# 26    Olivier
#[Out]# 27       Sven
#[Out]# 28      David
#[Out]# 29      Stijn
#[Out]# ..        ...
#[Out]# 100       Ivy
#[Out]# 101      Fien
#[Out]# 102    Isabel
#[Out]# 103     Lizzy
#[Out]# 104      Jill
#[Out]# 105      Anne
#[Out]# 106      Puck
#[Out]# 107     Fenne
#[Out]# 108     Elena
#[Out]# 109      Cato
#[Out]# 110     Hanna
#[Out]# 111    Veerle
#[Out]# 112      Kiki
#[Out]# 113      Lily
#[Out]# 114      Iris
#[Out]# 115     Tessa
#[Out]# 116      Lana
#[Out]# 117     Amira
#[Out]# 118     Eline
#[Out]# 119      Elif
#[Out]# 120      Juul
#[Out]# 121     Merel
#[Out]# 122      Liva
#[Out]# 123   Johanna
#[Out]# 124     Wilko
#[Out]# 125      Nick
#[Out]# 126    Angela
#[Out]# 127      Pino
#[Out]# 128      Koen
#[Out]# 129    Kostas
#[Out]# 
#[Out]# [130 rows x 1 columns]
# Tue, 08 Dec 2020 14:06:38
query4_4 = '''
    SELECT DISTINCT cName
    FROM customer, (SELECT cId, SUM(price) as cTotal
    FROM purchase
    GROUP BY cID, date) as total
    WHERE customer.cID = total.cID AND cTotal >= 0.75 *
    (SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID, date
    ))
'''
# Tue, 08 Dec 2020 14:06:39
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:06:40
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 14:06:57
query4_5 = '''
    PUT YOUR QUERY HERE
'''
# Tue, 08 Dec 2020 14:19:13
query4_5 = '''
    SELECT COUNT(DISTINCT cID)
    FROM store, purchase
    WHERE store.sID = purchase.sID AND city = "Eindhoven"
'''
# Tue, 08 Dec 2020 14:19:14
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:19:14
pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(DISTINCT cID)
#[Out]# 0                   69
# Tue, 08 Dec 2020 14:19:56
query4_5 = '''
    SELECT COUNT(DISTINCT cID) AS CustomerNumber, city
    FROM store, purchase
    WHERE store.sID = purchase.sID AND city = "Eindhoven"
    GROUP BY city
'''
# Tue, 08 Dec 2020 14:19:56
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:19:57
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       city
#[Out]# 0              69  Eindhoven
# Tue, 08 Dec 2020 14:20:58
query4_5 = '''
    SELECT COUNT(DISTINCT cID) AS CustomerNumber, city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 14:20:58
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:20:59
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 14:21:28
query4_5 = '''
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 14:21:28
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:21:29
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 14:21:47
query4_5 = '''
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 14:21:47
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:21:48
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       city
#[Out]# 0              10  Amsterdam
#[Out]# 1               9      Breda
#[Out]# 2              15  Eindhoven
#[Out]# 3              13  Rotterdam
#[Out]# 4              10    Tilburg
#[Out]# 5              12    Utrecht
# Tue, 08 Dec 2020 14:21:59
query4_5 = '''
    SELECT COUNT(DISTINCT purchase.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 14:21:59
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:21:59
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       city
#[Out]# 0              10  Amsterdam
#[Out]# 1               9      Breda
#[Out]# 2              15  Eindhoven
#[Out]# 3              13  Rotterdam
#[Out]# 4              10    Tilburg
#[Out]# 5              12    Utrecht
# Tue, 08 Dec 2020 14:22:04
query4_5 = '''
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 14:22:05
vis.visualize(query4_5, schema)

# IPython log file

query4_5 = '''
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
vis.visualize(query4_5, schema)
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:27:02
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 08 Dec 2020 18:27:03
query4_3 = '''
    SELECT DISTINCT sName
    FROM store
    WHERE NOT EXISTS (
    SELECT c.city
    FROM (SELECT DISTINCT city
    FROM customer
    UNION
    SELECT DISTINCT city
    FROM store) AS c
    WHERE NOT EXISTS ( SELECT store.city
    FROM store, store AS s
    WHERE store.sName = s.sName
    )
    )
    
'''
# Tue, 08 Dec 2020 18:27:03
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 18:27:03
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 18:27:04
query4_4 = '''
    SELECT DISTINCT cName
    FROM customer, (SELECT cId, SUM(price) as cTotal
    FROM purchase
    GROUP BY cID, date) as total
    WHERE customer.cID = total.cID AND cTotal >= 0.75 *
    (SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID, date
    ))
'''
# Tue, 08 Dec 2020 18:27:04
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 18:27:04
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 18:27:05
query4_5 = '''
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 18:27:05
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:27:05
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:27:22
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

query4_5 = '''
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
vis.visualize(query4_5, schema)
pd.read_sql_query(query4_5, conn)
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
query4_3 = '''
    SELECT DISTINCT sName
    FROM store
    WHERE NOT EXISTS (
    SELECT c.city
    FROM (SELECT DISTINCT city
    FROM customer
    UNION
    SELECT DISTINCT city
    FROM store) AS c
    WHERE NOT EXISTS ( SELECT store.city
    FROM store, store AS s
    WHERE store.sName = s.sName
    )
    )
    
'''
vis.visualize(query4_3, schema)
pd.read_sql_query(query4_3, conn)
query4_4 = '''
    SELECT DISTINCT cName
    FROM customer, (SELECT cId, SUM(price) as cTotal
    FROM purchase
    GROUP BY cID, date) as total
    WHERE customer.cID = total.cID AND cTotal >= 0.75 *
    (SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID, date
    ))
'''
vis.visualize(query4_4, schema)
pd.read_sql_query(query4_4, conn)
query4_5 = '''
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
vis.visualize(query4_5, schema)
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:27:25
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 18:27:27
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Tue, 08 Dec 2020 18:27:29
query4_3 = '''
    SELECT DISTINCT sName
    FROM store
    WHERE NOT EXISTS (
    SELECT c.city
    FROM (SELECT DISTINCT city
    FROM customer
    UNION
    SELECT DISTINCT city
    FROM store) AS c
    WHERE NOT EXISTS ( SELECT store.city
    FROM store, store AS s
    WHERE store.sName = s.sName
    )
    )
    
'''
# Tue, 08 Dec 2020 18:27:30
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 18:27:30
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 18:27:50
query4_4 = '''
    SELECT DISTINCT cName
    FROM customer, (SELECT cId, SUM(price) as cTotal
    FROM purchase
    GROUP BY cID, date) as total
    WHERE customer.cID = total.cID AND cTotal >= 0.75 *
    (SELECT MAX(Sum)
    FROM (
    SELECT DISTINCT SUM(price) as Sum
    FROM purchase
    GROUP BY cID, date
    ))
'''
# Tue, 08 Dec 2020 18:27:51
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 18:27:52
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 18:27:55
query4_5 = '''
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 18:27:56
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:27:56
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       city
#[Out]# 0              10  Amsterdam
#[Out]# 1               9      Breda
#[Out]# 2              15  Eindhoven
#[Out]# 3              13  Rotterdam
#[Out]# 4              10    Tilburg
#[Out]# 5              12    Utrecht
# Tue, 08 Dec 2020 18:36:24
query4_5 = '''
    WHERE cities (ct) AS (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, ct AS City
    FROM store, purchase, customer, cities
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID AND customer.city = ct
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 18:36:24
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:36:24
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:38:47
query4_5 = '''
    WITH cities (ct) AS (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, ct AS City
    FROM store, purchase, customer, cities
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID AND customer.city = ct
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 18:38:48
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:38:48
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       City
#[Out]# 0              10  Amsterdam
#[Out]# 1               9      Breda
#[Out]# 2              15  Eindhoven
#[Out]# 3              13  Rotterdam
#[Out]# 4              10    Tilburg
#[Out]# 5              12    Utrecht
# Tue, 08 Dec 2020 18:39:01
query4_5 = '''
    
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, ct AS City
    FROM store, purchase, customer, cities
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID AND customer.city = ct
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 18:39:02
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:39:02
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:39:06
query4_5 = '''
    WITH cities (ct) AS (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, ct AS City
    FROM store, purchase, customer, cities
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID AND customer.city = ct
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 18:39:07
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:39:07
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       City
#[Out]# 0              10  Amsterdam
#[Out]# 1               9      Breda
#[Out]# 2              15  Eindhoven
#[Out]# 3              13  Rotterdam
#[Out]# 4              10    Tilburg
#[Out]# 5              12    Utrecht
# Tue, 08 Dec 2020 18:41:21
query4_5 = '''
    WITH cities (ct) AS (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, ct AS City
    FROM store, purchase, customer, cities
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID AND customer.city = ct
    GROUP BY ct
'''
# Tue, 08 Dec 2020 18:41:21
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:41:22
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       City
#[Out]# 0              10  Amsterdam
#[Out]# 1               9      Breda
#[Out]# 2              15  Eindhoven
#[Out]# 3              13  Rotterdam
#[Out]# 4              10    Tilburg
#[Out]# 5              12    Utrecht
# Tue, 08 Dec 2020 18:52:49
query4_5 = '''
    WITH cities (ct) AS (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, ct AS City, 0
    FROM store, purchase, customer, cities
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID AND customer.city = ct
    GROUP BY ct
'''
# Tue, 08 Dec 2020 18:52:49
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:52:49
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       City  0
#[Out]# 0              10  Amsterdam  0
#[Out]# 1               9      Breda  0
#[Out]# 2              15  Eindhoven  0
#[Out]# 3              13  Rotterdam  0
#[Out]# 4              10    Tilburg  0
#[Out]# 5              12    Utrecht  0
# Tue, 08 Dec 2020 18:53:20
query4_5 = '''
    
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city
'''
# Tue, 08 Dec 2020 18:53:20
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:53:20
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       city
#[Out]# 0              10  Amsterdam
#[Out]# 1               9      Breda
#[Out]# 2              15  Eindhoven
#[Out]# 3              13  Rotterdam
#[Out]# 4              10    Tilburg
#[Out]# 5              12    Utrecht
# Tue, 08 Dec 2020 18:55:40
query4_5 = '''
    WHERE custnum (CustomerNumber, city) AS (
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city)
    SELECT *
    FROM custnum
    UNION
    SELECT city, 0
    FROM customer
    WHERE city NOT IN (SELECT city FROM custnum)
'''
# Tue, 08 Dec 2020 18:55:40
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:55:41
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:57:16
query4_5 = '''
    WHERE custnum (CustomerNumber, city) AS (
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city)
    SELECT *
    FROM custnum
    UNION
    SELECT city, 0
    FROM customer
    WHERE customer.city NOT IN (SELECT city FROM custnum)
'''
# Tue, 08 Dec 2020 18:57:16
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:57:16
pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 18:59:08
query4_5 = '''
    WITH custnum (CustomerNumber, city) AS (
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city)
    SELECT *
    FROM custnum
    UNION
    SELECT city, 0
    FROM customer
    WHERE city IN (SELECT city FROM custnum)
'''
# Tue, 08 Dec 2020 18:59:08
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:59:09
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       city
#[Out]# 0               9      Breda
#[Out]# 1              10  Amsterdam
#[Out]# 2              10    Tilburg
#[Out]# 3              12    Utrecht
#[Out]# 4              13  Rotterdam
#[Out]# 5              15  Eindhoven
#[Out]# 6       Amsterdam          0
#[Out]# 7           Breda          0
#[Out]# 8       Eindhoven          0
#[Out]# 9       Rotterdam          0
#[Out]# 10        Tilburg          0
#[Out]# 11        Utrecht          0
# Tue, 08 Dec 2020 18:59:15
query4_5 = '''
    WITH custnum (CustomerNumber, city) AS (
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS city
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city)
    SELECT *
    FROM custnum
    UNION
    SELECT city, 0
    FROM customer
    WHERE city NOT IN (SELECT city FROM custnum)
'''
# Tue, 08 Dec 2020 18:59:15
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:59:15
pd.read_sql_query(query4_5, conn)
#[Out]#   CustomerNumber       city
#[Out]# 0              9      Breda
#[Out]# 1             10  Amsterdam
#[Out]# 2             10    Tilburg
#[Out]# 3             12    Utrecht
#[Out]# 4             13  Rotterdam
#[Out]# 5             15  Eindhoven
#[Out]# 6            Oss          0
# Tue, 08 Dec 2020 18:59:40
query4_5 = '''
    WITH custnum (CustomerNumber, city) AS (
    SELECT COUNT(DISTINCT customer.cID) AS CustomerNumber, customer.city AS City
    FROM store, purchase, customer
    WHERE store.sID = purchase.sID AND store.city = "Eindhoven" AND customer.cID = purchase.cID
    GROUP BY customer.city)
    SELECT *
    FROM custnum
    UNION
    SELECT 0, city
    FROM customer
    WHERE city NOT IN (SELECT city FROM custnum)
'''
# Tue, 08 Dec 2020 18:59:40
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 18:59:40
pd.read_sql_query(query4_5, conn)
#[Out]#    CustomerNumber       city
#[Out]# 0               0        Oss
#[Out]# 1               9      Breda
#[Out]# 2              10  Amsterdam
#[Out]# 3              10    Tilburg
#[Out]# 4              12    Utrecht
#[Out]# 5              13  Rotterdam
#[Out]# 6              15  Eindhoven


# IPython log file

# Tue, 08 Dec 2020 15:12:40
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 15:12:43
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x24def72e110>

# IPython log file

# Wed, 09 Dec 2020 09:49:04
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 09:49:06
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 09 Dec 2020 09:52:03
query4_3 = '''
    SELECT city
    FROM customer
    UNION
    SELECT city
    FROM store
'''
# Wed, 09 Dec 2020 09:52:03
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 09:52:04
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht

# IPython log file

# Wed, 09 Dec 2020 09:54:24
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 09:54:26
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1bd0ec57650>
# Wed, 09 Dec 2020 09:55:50
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Wed, 09 Dec 2020 09:55:52
query4_3 = '''
    SELECT city
    FROM customer
    UNION
    SELECT city
    FROM store
'''
# Wed, 09 Dec 2020 09:55:52
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 09:56:00
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 10:01:49
query4_3 = '''
    WITH allpossible(city) AS (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ),
    WITH allactual(sName, city) (
        SELECT sName, city
        FROM store
    )
    SELECT sName, city
    FROM allpossible
    EXCEPT
    SELECT sName, city
    FROM allactual

'''
# Wed, 09 Dec 2020 10:01:49
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:01:50
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:02:15
query4_3 = '''
    WITH allpossible(city) AS (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ),
    WITH allactual(sName, city) AS (
        SELECT sName, city
        FROM store
    )
    SELECT sName, city
    FROM allpossible
    EXCEPT
    SELECT sName, city
    FROM allactual

'''
# Wed, 09 Dec 2020 10:02:15
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:02:16
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:02:50
query4_3 = '''
    WITH allpossible(city) AS (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ),
    WITH allactual(sName, city) AS (
        SELECT sName, city
        FROM store
    )
    SELECT sName, city
    FROM allpossible

'''
# Wed, 09 Dec 2020 10:02:51
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:02:51
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:06:00
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
    ),
    WITH allcities(ccount) AS (
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:06:00
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:06:01
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:06:19
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
    )
    WITH allcities(ccount) AS (
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:06:19
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:06:20
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:06:32
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
    ),
    WITH allcities(ccount) AS (
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:06:32
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:06:33
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:06:49
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
    ),
    allcities(ccount) AS (
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:06:49
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:06:49
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:06:58
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
    ),
    WITH allcities(ccount) AS (
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:06:59
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:06:59
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:07:58
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
    ),
   allcities(ccount) AS (
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:07:58
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:07:59
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:08:04
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
    ),
       allcities(ccount) AS (
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:08:04
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:08:05
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:08:08
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
    ,
       allcities(ccount) AS (
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:08:08
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:08:09
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:08:14
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
    ,
       allcities(ccount) AS
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:08:14
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:08:14
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:08:30
query4_3 = '''
    WITH storecitycount(scount) AS (
        SELECT sName, count(DISTINCT city)
        FROM store
       allcities(ccount) AS
        SELECT count(DISTINCT city)
        FROM customer
        UNION
        SELECT count(DISTINCT city)
        FROM store
    )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:08:30
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:08:32
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:09:07
query4_3 = '''
    WITH storecitycount(scount) AS (
            SELECT sName, count(DISTINCT city)
            FROM store)
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:09:07
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:09:08
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:09:17
query4_3 = '''
    WITH storecitycount(scount) AS (
            SELECT sName, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT sName, city
    FROM store
    WHERE storecitycountscount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:09:17
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:09:18
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:09:25
query4_3 = '''
    WITH storecitycount(scount) AS (
            SELECT sName, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT sName, city
    FROM store
    WHERE storecitycount.scount == allcities.ccount

'''
# Wed, 09 Dec 2020 10:09:26
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:09:26
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:10:32
query4_3 = '''
    WITH storecitycount(scount) AS (
            SELECT sName, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT sName, city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:10:33
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:10:33
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:10:46
query4_3 = '''
    WITH storecitycount(scount) AS (
            SELECT count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT sName, city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:10:46
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:10:46
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:11:02
query4_3 = '''
    WITH storecitycount(sName, scount) AS (
            SELECT sName, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT sName, city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:11:02
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:11:03
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:11:23
query4_3 = '''
    WITH storecitycount(sName, scount) AS (
            SELECT sName, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:11:23
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:11:24
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:11:40
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:11:41
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:11:41
pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Coop  Amsterdam
# Wed, 09 Dec 2020 10:12:14
query4_3 = '''
    SELECT sName, city
    FROM store

'''
# Wed, 09 Dec 2020 10:12:18
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:12:19
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 10:12:36
query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY city
'''
# Wed, 09 Dec 2020 10:12:38
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:12:39
pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city
#[Out]# 0         Coop  Amsterdam
#[Out]# 1    Hoogvliet      Breda
#[Out]# 2    Hoogvliet  Eindhoven
#[Out]# 3        Jumbo        Oss
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5  Albert Hein    Tilburg
#[Out]# 6         Lidl    Utrecht
# Wed, 09 Dec 2020 10:12:55
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:12:55
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:12:56
pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Coop  Amsterdam
# Wed, 09 Dec 2020 10:13:48
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT UNIQUE sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:13:49
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:13:49
pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:15:33
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT DISTINCT sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:15:33
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:15:34
pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Coop  Amsterdam
# Wed, 09 Dec 2020 10:16:46
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(city)
            FROM customer
            UNION
            SELECT count(city)
            FROM store
        )
    SELECT DISTINCT sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:16:46
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:16:47
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 10:16:51
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT DISTINCT sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:16:51
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:16:52
pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Coop  Amsterdam
# Wed, 09 Dec 2020 10:17:09
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer

        )
    SELECT DISTINCT sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:17:09
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:17:10
pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Coop  Amsterdam
# Wed, 09 Dec 2020 10:17:14
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT DISTINCT sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 10:17:14
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 10:17:15
pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Coop  Amsterdam
# Wed, 09 Dec 2020 10:21:16
query4_4 = '''
    WITH maxamount(money) AS (
        SELECT max(price)
        FROM purchase
    )
    SELECT cName
    FROM customer AS c, purchase AS p, maxamount AS max
    WHERE c.cID = p.cID AND p.price >= (0.75 * maxamount.max)
'''
# Wed, 09 Dec 2020 10:21:17
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 10:21:17
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:21:25
query4_4 = '''
    WITH maxamount(money) AS (
        SELECT max(price)
        FROM purchase
    )
    SELECT cName
    FROM customer AS c, purchase AS p, maxamount AS max
    WHERE c.cID = p.cID AND p.price >= (0.75 * max.max)
'''
# Wed, 09 Dec 2020 10:21:26
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 10:21:27
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:21:33
query4_4 = '''
    WITH maxamount(money) AS (
        SELECT max(price)
        FROM purchase
    )
    SELECT cName
    FROM customer AS c, purchase AS p, maxamount AS max
    WHERE c.cID = p.cID AND p.price >= (0.75 * max.money)
'''
# Wed, 09 Dec 2020 10:21:34
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 10:21:34
pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9     Dylan
#[Out]# 10  Thijmen
#[Out]# 11    Lotte
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Lieke
#[Out]# 15    Sofie
#[Out]# 16      Ivy
#[Out]# 17    Fenne
#[Out]# 18    Elena
# Wed, 09 Dec 2020 10:28:36
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT sName, city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        city(city, count) AS (
        SELECT city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
'''
# Wed, 09 Dec 2020 10:28:36
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:28:37
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:29:14
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT sName, city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        city(city, count) AS (
        SELECT city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
        SELECT city, count
        FROM city AS c
'''
# Wed, 09 Dec 2020 10:29:14
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:29:16
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:29:20
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:29:31
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT sName, city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        city(city, count) AS (
        SELECT city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
        SELECT c.city, count
        FROM city AS c
'''
# Wed, 09 Dec 2020 10:29:31
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:29:32
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:29:50
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT sName, city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        city(stad, count) AS (
        SELECT city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
        SELECT c.stad, count
        FROM city AS c
'''
# Wed, 09 Dec 2020 10:29:50
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:29:50
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:30:14
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT sName, city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        citycount(city, count) AS (
        SELECT city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
        SELECT c.city, count
        FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:30:15
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:30:15
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:30:35
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT sName, city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        citycount(stad, count) AS (
        SELECT city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
        SELECT c.stad, count
        FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:30:36
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:30:36
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:30:54
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT sName, city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        citycount(stad, count) AS (
        SELECT city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
        SELECT count
        FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:30:54
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:30:55
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:31:12
query4_5 = '''
    WITH peoplebuyEHV(sName, stad) AS (
        SELECT sName, city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        citycount(stad, count) AS (
        SELECT city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
        SELECT c.stad, count
        FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:31:12
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:31:13
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:31:37
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT sName, city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        citycount(city, count) AS (
        SELECT c.city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
        SELECT c.city, count
        FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:31:38
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:31:39
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:31:48
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT sName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY sName
    ),
        citycount(city, count) AS (
        SELECT c.city, count(sName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.sName = ehv.sName
        GROUP BY city
        )
        SELECT c.city, count
        FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:31:49
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:31:49
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:32:18
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(city, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
        SELECT c.city, count
        FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:32:18
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:32:18
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:32:37
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(stad, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
        SELECT c.stad, count
        FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:32:37
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:32:37
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:32:51
query4_5 = '''
    WITH peoplebuyEHV(sName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(stad, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
        SELECT c.stad, count
        FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:32:52
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:32:52
pd.read_sql_query(query4_5, conn)
#[Out]#         stad  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 10:34:09
query4_5 = '''
    WITH peoplebuyEHV(sName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
    ),
        citycount(stad, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
    SELECT c.stad, count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:34:09
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:34:10
pd.read_sql_query(query4_5, conn)
#[Out]#         stad  count
#[Out]# 0  Amsterdam     17
#[Out]# 1      Breda     27
#[Out]# 2  Eindhoven     24
#[Out]# 3  Rotterdam     16
#[Out]# 4    Tilburg     18
#[Out]# 5    Utrecht     31
# Wed, 09 Dec 2020 10:34:19
query4_5 = '''
    WITH peoplebuyEHV(sName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(stad, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
    SELECT c.stad, count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:34:20
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:34:21
pd.read_sql_query(query4_5, conn)
#[Out]#         stad  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 10:34:52
query4_5 = '''
    WITH peoplebuyEHV(sName, City) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(City, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
    SELECT c.stad, count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:34:52
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:34:52
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:35:03
query4_5 = '''
    WITH peoplebuyEHV(sName, City) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
    SELECT c.stad, count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:35:04
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:35:04
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:35:08
query4_5 = '''
    WITH peoplebuyEHV(sName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
    SELECT c.stad, count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:35:08
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:35:09
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:35:14
query4_5 = '''
    WITH peoplebuyEHV(sName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
    SELECT c.cities, count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:35:14
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:35:14
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 10:35:22
query4_5 = '''
    WITH peoplebuyEHV(sName, city) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
    SELECT c.cities, count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:35:23
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:35:23
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:35:26
query4_5 = '''
    WITH peoplebuyEHV(sName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
    SELECT c.cities, count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:35:26
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:35:27
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 10:35:44
query4_5 = '''
    WITH peoplebuyEHV(sName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.sName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:35:45
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:35:45
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 10:36:02
query4_5 = '''
    WITH peoplebuyEHV(sName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.cName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:36:02
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:36:02
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:36:12
query4_5 = '''
    WITH peoplebuyEHV(cName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.cName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:36:12
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:36:13
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:36:26
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:36:26
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:36:27
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 10:37:07
query4_5 = '''
    SELECT count(*)
    FROM store
'''
# Wed, 09 Dec 2020 10:37:07
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:37:08
pd.read_sql_query(query4_5, conn)
#[Out]#    count(*)
#[Out]# 0        64
# Wed, 09 Dec 2020 10:37:12
query4_5 = '''
    SELECT count(city)
    FROM store
'''
# Wed, 09 Dec 2020 10:37:13
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:37:13
pd.read_sql_query(query4_5, conn)
#[Out]#    count(city)
#[Out]# 0           64
# Wed, 09 Dec 2020 10:37:19
query4_5 = '''
    SELECT count(DISTINCT city)
    FROM store
'''
# Wed, 09 Dec 2020 10:37:20
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:37:20
pd.read_sql_query(query4_5, conn)
#[Out]#    count(DISTINCT city)
#[Out]# 0                     7
# Wed, 09 Dec 2020 10:37:26
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:37:27
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:37:27
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 10:38:08
query4_6 = '''
    SELECT city
    FROM store
'''
# Wed, 09 Dec 2020 10:38:09
pd.read_sql_query(query4_6, conn)
#[Out]#          city
#[Out]# 0   Amsterdam
#[Out]# 1       Breda
#[Out]# 2   Rotterdam
#[Out]# 3   Rotterdam
#[Out]# 4   Eindhoven
#[Out]# ..        ...
#[Out]# 59      Breda
#[Out]# 60      Breda
#[Out]# 61      Breda
#[Out]# 62  Eindhoven
#[Out]# 63        Oss
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Wed, 09 Dec 2020 10:38:13
query4_6 = '''
    SELECT DISTINCT city
    FROM store
'''
# Wed, 09 Dec 2020 10:38:13
pd.read_sql_query(query4_6, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Wed, 09 Dec 2020 10:39:37
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT city, c.count
    FROM customer AS cust, citycount AS c
    GROUP BY city
'''
# Wed, 09 Dec 2020 10:39:37
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:39:38
pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda     10
#[Out]# 2  Eindhoven     10
#[Out]# 3        Oss     10
#[Out]# 4  Rotterdam     10
#[Out]# 5    Tilburg     10
#[Out]# 6    Utrecht     10
# Wed, 09 Dec 2020 10:39:49
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT city, c.count
    FROM customer AS cust, citycount AS c
'''
# Wed, 09 Dec 2020 10:39:50
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:39:50
pd.read_sql_query(query4_5, conn)
#[Out]#          city  count
#[Out]# 0     Utrecht     10
#[Out]# 1     Utrecht      9
#[Out]# 2     Utrecht     15
#[Out]# 3     Utrecht     13
#[Out]# 4     Utrecht     10
#[Out]# ...       ...    ...
#[Out]# 1135  Utrecht      9
#[Out]# 1136  Utrecht     15
#[Out]# 1137  Utrecht     13
#[Out]# 1138  Utrecht     10
#[Out]# 1139  Utrecht     12
#[Out]# 
#[Out]# [1140 rows x 2 columns]
# Wed, 09 Dec 2020 10:39:57
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT DISTINCT city, c.count
    FROM customer AS cust, citycount AS c
'''
# Wed, 09 Dec 2020 10:39:57
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:39:58
pd.read_sql_query(query4_5, conn)
#[Out]#          city  count
#[Out]# 0     Utrecht     10
#[Out]# 1     Utrecht      9
#[Out]# 2     Utrecht     15
#[Out]# 3     Utrecht     13
#[Out]# 4     Utrecht     12
#[Out]# 5       Breda     10
#[Out]# 6       Breda      9
#[Out]# 7       Breda     15
#[Out]# 8       Breda     13
#[Out]# 9       Breda     12
#[Out]# 10  Amsterdam     10
#[Out]# 11  Amsterdam      9
#[Out]# 12  Amsterdam     15
#[Out]# 13  Amsterdam     13
#[Out]# 14  Amsterdam     12
#[Out]# 15  Eindhoven     10
#[Out]# 16  Eindhoven      9
#[Out]# 17  Eindhoven     15
#[Out]# 18  Eindhoven     13
#[Out]# 19  Eindhoven     12
#[Out]# 20    Tilburg     10
#[Out]# 21    Tilburg      9
#[Out]# 22    Tilburg     15
#[Out]# 23    Tilburg     13
#[Out]# 24    Tilburg     12
#[Out]# 25  Rotterdam     10
#[Out]# 26  Rotterdam      9
#[Out]# 27  Rotterdam     15
#[Out]# 28  Rotterdam     13
#[Out]# 29  Rotterdam     12
#[Out]# 30        Oss     10
#[Out]# 31        Oss      9
#[Out]# 32        Oss     15
#[Out]# 33        Oss     13
#[Out]# 34        Oss     12
# Wed, 09 Dec 2020 10:40:20
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        )
    SELECT city, c.count
    FROM customer AS cust, citycount AS c
    GROUP BY city
'''
# Wed, 09 Dec 2020 10:40:20
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:40:21
pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     69
#[Out]# 1      Breda     69
#[Out]# 2  Eindhoven     69
#[Out]# 3        Oss     69
#[Out]# 4  Rotterdam     69
#[Out]# 5    Tilburg     69
#[Out]# 6    Utrecht     69
# Wed, 09 Dec 2020 10:41:06
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        )
    SELECT city, c.count
    FROM customer AS cust, citycount AS c
    WHERE cust.city = c.cities
    GROUP BY city
'''
# Wed, 09 Dec 2020 10:41:06
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:41:07
pd.read_sql_query(query4_5, conn)
#[Out]#     city  count
#[Out]# 0  Breda     69
# Wed, 09 Dec 2020 10:41:18
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT city, c.count
    FROM customer AS cust, citycount AS c
'''
# Wed, 09 Dec 2020 10:41:18
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:41:18
pd.read_sql_query(query4_5, conn)
#[Out]#          city  count
#[Out]# 0     Utrecht     10
#[Out]# 1     Utrecht      9
#[Out]# 2     Utrecht     15
#[Out]# 3     Utrecht     13
#[Out]# 4     Utrecht     10
#[Out]# ...       ...    ...
#[Out]# 1135  Utrecht      9
#[Out]# 1136  Utrecht     15
#[Out]# 1137  Utrecht     13
#[Out]# 1138  Utrecht     10
#[Out]# 1139  Utrecht     12
#[Out]# 
#[Out]# [1140 rows x 2 columns]
# Wed, 09 Dec 2020 10:41:25
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT DISTINCT city, c.count
    FROM customer AS cust, citycount AS c
'''
# Wed, 09 Dec 2020 10:41:25
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:41:26
pd.read_sql_query(query4_5, conn)
#[Out]#          city  count
#[Out]# 0     Utrecht     10
#[Out]# 1     Utrecht      9
#[Out]# 2     Utrecht     15
#[Out]# 3     Utrecht     13
#[Out]# 4     Utrecht     12
#[Out]# 5       Breda     10
#[Out]# 6       Breda      9
#[Out]# 7       Breda     15
#[Out]# 8       Breda     13
#[Out]# 9       Breda     12
#[Out]# 10  Amsterdam     10
#[Out]# 11  Amsterdam      9
#[Out]# 12  Amsterdam     15
#[Out]# 13  Amsterdam     13
#[Out]# 14  Amsterdam     12
#[Out]# 15  Eindhoven     10
#[Out]# 16  Eindhoven      9
#[Out]# 17  Eindhoven     15
#[Out]# 18  Eindhoven     13
#[Out]# 19  Eindhoven     12
#[Out]# 20    Tilburg     10
#[Out]# 21    Tilburg      9
#[Out]# 22    Tilburg     15
#[Out]# 23    Tilburg     13
#[Out]# 24    Tilburg     12
#[Out]# 25  Rotterdam     10
#[Out]# 26  Rotterdam      9
#[Out]# 27  Rotterdam     15
#[Out]# 28  Rotterdam     13
#[Out]# 29  Rotterdam     12
#[Out]# 30        Oss     10
#[Out]# 31        Oss      9
#[Out]# 32        Oss     15
#[Out]# 33        Oss     13
#[Out]# 34        Oss     12
# Wed, 09 Dec 2020 10:41:39
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 10:41:39
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 10:41:40
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 11:51:59
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT DISTINCT sName, s.city
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 11:51:59
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 11:52:00
pd.read_sql_query(query4_3, conn)
#[Out]#   sName       city
#[Out]# 0  Coop  Amsterdam
# Wed, 09 Dec 2020 11:59:36
query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY city
'''
# Wed, 09 Dec 2020 11:59:38
pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city
#[Out]# 0         Coop  Amsterdam
#[Out]# 1    Hoogvliet      Breda
#[Out]# 2    Hoogvliet  Eindhoven
#[Out]# 3        Jumbo        Oss
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5  Albert Hein    Tilburg
#[Out]# 6         Lidl    Utrecht
# Wed, 09 Dec 2020 11:59:49
query4_3 = '''
    SELECT sName, city
    FROM store
    GROUP BY sName
'''
# Wed, 09 Dec 2020 11:59:52
pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city
#[Out]# 0  Albert Hein  Eindhoven
#[Out]# 1         Coop  Amsterdam
#[Out]# 2         Dirk      Breda
#[Out]# 3    Hoogvliet      Breda
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5         Lidl  Eindhoven
#[Out]# 6       Sligro  Rotterdam
# Wed, 09 Dec 2020 12:00:09
query4_3 = '''
    SELECT sName, city
    FROM store
'''
# Wed, 09 Dec 2020 12:00:15
query4_3 = '''
    SELECT sName, city
    FROM store
'''
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 12:01:18
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(DISTINCT city)
            FROM customer
            UNION
            SELECT count(DISTINCT city)
            FROM store
        )
    SELECT DISTINCT sName
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 12:01:21
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 12:01:21
pd.read_sql_query(query4_3, conn)
#[Out]#   sName
#[Out]# 0  Coop
# Wed, 09 Dec 2020 12:03:29
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(city)
            FROM customer
            UNION
            SELECT count(city)
            FROM store
        )
    SELECT DISTINCT sName
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 12:03:30
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 12:03:30
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:06:26
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(city)
            FROM customer
            UNION
            SELECT count(city)
            FROM store
        )
    SELECT DISTINCT sName
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 12:06:26
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 12:06:27
pd.read_sql_query(query4_3, conn)
#[Out]#   sName
#[Out]# 0  Coop
# Wed, 09 Dec 2020 12:06:35
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(city)
            FROM customer
            UNION
            SELECT count(city)
            FROM store
        )
    SELECT DISTINCT sName
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 12:06:35
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 12:06:36
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:06:41
query4_4 = '''
    WITH maxamount(money) AS (
        SELECT max(price)
        FROM purchase
    )
    SELECT cName
    FROM customer AS c, purchase AS p, maxamount AS max
    WHERE c.cID = p.cID AND p.price >= (0.75 * max.money)
'''
# Wed, 09 Dec 2020 12:06:41
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 12:06:42
pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9     Dylan
#[Out]# 10  Thijmen
#[Out]# 11    Lotte
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Lieke
#[Out]# 15    Sofie
#[Out]# 16      Ivy
#[Out]# 17    Fenne
#[Out]# 18    Elena
# Wed, 09 Dec 2020 12:07:30
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(city)
            FROM customer
            UNION
            SELECT count(city)
            FROM store
        )
    SELECT DISTINCT sName
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount

'''
# Wed, 09 Dec 2020 12:07:30
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 12:07:31
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:10:38
query4_4 = '''
    WITH maxamount(money) AS (
        SELECT max(price)
        FROM purchase
    ),
        datebuy(cID, date, price) AS (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date
        )
    SELECT cName
    FROM customer AS c, purchase AS p, maxamount AS max
    WHERE c.cID = p.cID AND p.price >= (0.75 * max.money)
'''
# Wed, 09 Dec 2020 12:10:38
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 12:10:39
pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0      Daan
#[Out]# 1      Bram
#[Out]# 2      Luca
#[Out]# 3      Teun
#[Out]# 4      Sven
#[Out]# 5      Ties
#[Out]# 6    Willem
#[Out]# 7      Dean
#[Out]# 8     Dylan
#[Out]# 9     Dylan
#[Out]# 10  Thijmen
#[Out]# 11    Lotte
#[Out]# 12     Lynn
#[Out]# 13    Fenna
#[Out]# 14    Lieke
#[Out]# 15    Sofie
#[Out]# 16      Ivy
#[Out]# 17    Fenne
#[Out]# 18    Elena
# Wed, 09 Dec 2020 12:11:01
query4_4 = '''
    WITH maxamount(money) AS (
        SELECT max(price)
        FROM purchase
    ),
        datebuy(cID, date, price) AS (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date
        )
    SELECT cName
    FROM customer AS c, datebuy AS d, maxamount AS max
    WHERE c.cID = p.cID AND d.price >= (0.75 * max.money)
'''
# Wed, 09 Dec 2020 12:11:01
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 12:11:02
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:11:10
query4_4 = '''
    WITH maxamount(money) AS (
        SELECT max(price)
        FROM purchase
    ),
        datebuy(cID, date, price) AS (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date
        )
    SELECT cName
    FROM customer AS c, datebuy AS d, maxamount AS max
    WHERE c.cID = d.cID AND d.price >= (0.75 * max.money)
'''
# Wed, 09 Dec 2020 12:11:10
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 12:11:10
pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0       Sem
#[Out]# 1      Daan
#[Out]# 2      Daan
#[Out]# 3      Bram
#[Out]# 4     James
#[Out]# 5    Julian
#[Out]# 6      Gijs
#[Out]# 7      Luca
#[Out]# 8      Teun
#[Out]# 9      Sven
#[Out]# 10    Stijn
#[Out]# 11     Jack
#[Out]# 12     Jack
#[Out]# 13     Jens
#[Out]# 14     Ties
#[Out]# 15   Willem
#[Out]# 16     Joep
#[Out]# 17      Kai
#[Out]# 18     Dean
#[Out]# 19     Jace
#[Out]# 20    Dylan
#[Out]# 21    Dylan
#[Out]# 22     Stef
#[Out]# 23  Thijmen
#[Out]# 24     Emma
#[Out]# 25    Lotte
#[Out]# 26     Noor
#[Out]# 27     Lynn
#[Out]# 28    Fenna
#[Out]# 29    Lieke
#[Out]# 30    Milou
#[Out]# 31    Sofie
#[Out]# 32      Ivy
#[Out]# 33    Fenne
#[Out]# 34    Floor
#[Out]# 35    Elena
#[Out]# 36    Elena
#[Out]# 37     Iris
#[Out]# 38     Juul
#[Out]# 39  Johanna
#[Out]# 40   Kostas
#[Out]# 41   Kostas
#[Out]# 42   Kostas
#[Out]# 43   Kostas
#[Out]# 44   Kostas
#[Out]# 45   Kostas
#[Out]# 46   Kostas
#[Out]# 47   Kostas
#[Out]# 48   Kostas
# Wed, 09 Dec 2020 12:12:20
query4_4 = '''
    WITH datebuy(cID, date, price) AS (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date
        ),
        maxamount(money) AS (
        SELECT max(0,75*price)
        FROM datebuy
    )
    SELECT cName
    FROM customer AS c, datebuy AS d, maxamount AS max
    WHERE c.cID = d.cID AND d.price >= (0.75 * max.money)
'''
# Wed, 09 Dec 2020 12:12:20
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 12:12:21
pd.read_sql_query(query4_4, conn)
#[Out]#     cName
#[Out]# 0    Noor
#[Out]# 1   Sofie
#[Out]# 2   Sofie
#[Out]# 3   Sofie
#[Out]# 4   Sofie
#[Out]# 5   Sofie
#[Out]# 6   Sofie
#[Out]# 7   Sofie
#[Out]# 8   Floor
#[Out]# 9   Floor
#[Out]# 10  Floor
#[Out]# 11  Floor
#[Out]# 12  Floor
#[Out]# 13  Floor
#[Out]# 14  Floor
#[Out]# 15  Floor
#[Out]# 16  Floor
#[Out]# 17  Floor
# Wed, 09 Dec 2020 12:12:49
query4_4 = '''
    WITH datebuy(cID, date, price) AS (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date
        ),
        maxamount(money) AS (
        SELECT max(0,75*price)
        FROM datebuy
        )
    SELECT cName
    FROM customer AS c, datebuy AS d, maxamount AS max
    WHERE c.cID = d.cID AND d.price >= (max.money)
'''
# Wed, 09 Dec 2020 12:12:49
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 12:12:50
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
#[Out]# 1  Floor
#[Out]# 2  Floor
#[Out]# 3  Floor
#[Out]# 4  Floor
#[Out]# 5  Floor
#[Out]# 6  Floor
# Wed, 09 Dec 2020 12:12:55
query4_4 = '''
    WITH datebuy(cID, date, price) AS (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date
        ),
        maxamount(money) AS (
        SELECT max(0,75*price)
        FROM datebuy
        )
    SELECT DISTINCT cName
    FROM customer AS c, datebuy AS d, maxamount AS max
    WHERE c.cID = d.cID AND d.price >= (max.money)
'''
# Wed, 09 Dec 2020 12:12:55
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 12:12:56
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 12:14:39
query4_4 = '''
    WITH datebuy(cID, date, price) AS (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date
        ),
        maxamount(money) AS (
        SELECT max(price)
        FROM datebuy
        )
    SELECT cName
    FROM customer AS c, datebuy AS d, maxamount AS max
    WHERE c.cID = d.cID AND d.price >= (0.75 * max.money)
'''
# Wed, 09 Dec 2020 12:14:40
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 12:14:40
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 12:16:43
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 12:16:44
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:16:45
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 12:17:26
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
    UNION
    SELECT city
    FROM customer
'''
# Wed, 09 Dec 2020 12:17:26
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:17:27
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:17:47
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
    UNION
    SELECT city, c.count
    FROM customer, citycount AS c
'''
# Wed, 09 Dec 2020 12:17:47
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:17:48
pd.read_sql_query(query4_5, conn)
#[Out]#        cities  count
#[Out]# 0   Amsterdam      9
#[Out]# 1   Amsterdam     10
#[Out]# 2   Amsterdam     12
#[Out]# 3   Amsterdam     13
#[Out]# 4   Amsterdam     15
#[Out]# 5       Breda      9
#[Out]# 6       Breda     10
#[Out]# 7       Breda     12
#[Out]# 8       Breda     13
#[Out]# 9       Breda     15
#[Out]# 10  Eindhoven      9
#[Out]# 11  Eindhoven     10
#[Out]# 12  Eindhoven     12
#[Out]# 13  Eindhoven     13
#[Out]# 14  Eindhoven     15
#[Out]# 15        Oss      9
#[Out]# 16        Oss     10
#[Out]# 17        Oss     12
#[Out]# 18        Oss     13
#[Out]# 19        Oss     15
#[Out]# 20  Rotterdam      9
#[Out]# 21  Rotterdam     10
#[Out]# 22  Rotterdam     12
#[Out]# 23  Rotterdam     13
#[Out]# 24  Rotterdam     15
#[Out]# 25    Tilburg      9
#[Out]# 26    Tilburg     10
#[Out]# 27    Tilburg     12
#[Out]# 28    Tilburg     13
#[Out]# 29    Tilburg     15
#[Out]# 30    Utrecht      9
#[Out]# 31    Utrecht     10
#[Out]# 32    Utrecht     12
#[Out]# 33    Utrecht     13
#[Out]# 34    Utrecht     15
# Wed, 09 Dec 2020 12:18:05
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, count) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.count
    FROM citycount AS c
    UNION
    SELECT city, c.count
    FROM customer, citycount AS c
    GROUP BY city
'''
# Wed, 09 Dec 2020 12:18:05
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:18:07
pd.read_sql_query(query4_5, conn)
#[Out]#        cities  count
#[Out]# 0   Amsterdam     10
#[Out]# 1       Breda      9
#[Out]# 2       Breda     10
#[Out]# 3   Eindhoven     10
#[Out]# 4   Eindhoven     15
#[Out]# 5         Oss     10
#[Out]# 6   Rotterdam     10
#[Out]# 7   Rotterdam     13
#[Out]# 8     Tilburg     10
#[Out]# 9     Utrecht     10
#[Out]# 10    Utrecht     12
# Wed, 09 Dec 2020 12:20:00
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
'''
# Wed, 09 Dec 2020 12:20:01
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:20:01
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Wed, 09 Dec 2020 12:21:37
query4_5 = '''
    WITH peoplebuyEHV(custName, stad) AS (
        SELECT cName, c.city
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY cName
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM store
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:21:37
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:21:37
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Wed, 09 Dec 2020 12:24:37
query4_5 = '''
    WITH peoplebuyEHV(city, value) AS (
        SELECT c.city, count(c.cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM store
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:24:38
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:24:38
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:24:52
query4_5 = '''
    WITH peoplebuyEHV(stad, value) AS (
        SELECT c.stad, count(c.cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM store
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:24:53
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:24:53
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:25:26
query4_5 = '''
    WITH peoplebuyEHV(stad, value) AS (
        SELECT c.stad, count(c.cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(cName)
        FROM customer AS c, peoplebuyEHV AS ehv
        WHERE c.cName = ehv.custName
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM store
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:25:26
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:25:27
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:27:10
query4_5 = '''
    WITH citiesthatexist(city) AS (
        SELECT city
        FROM customer
        SELECT city
        FROM store
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM store
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:27:11
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:27:11
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:27:43
query4_5 = '''
    WITH citiesthatexist(city) AS (
        SELECT city
        FROM customer
        SELECT city
        FROM store
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM citiesthatexist
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:27:43
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:27:44
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:28:25
query4_5 = '''
    WITH citiesthatexist(city) AS (
        SELECT city
        FROM customer
        SELECT city
        FROM store
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM citiesthatexist
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:28:25
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:28:26
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:28:35
query4_5 = '''
    WITH citiesthatexist(city) AS (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM citiesthatexist
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:28:36
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:28:36
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:28:45
query4_5 = '''
    WITH citiesthatexist(city) AS (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(c.cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM citiesthatexist
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:28:45
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:28:46
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:28:53
query4_5 = '''
    WITH citiesthatexist(city) AS (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(p.cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT city, 0
    FROM citiesthatexist
    WHERE city NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:28:54
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:28:54
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:29:13
query4_5 = '''
    WITH citiesthatexist(stad) AS (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(p.cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT stad, 0
    FROM citiesthatexist
    WHERE stad NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:29:13
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:29:13
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:29:27
query4_5 = '''
    WITH citiesthatexist(stad) AS (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(p.cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY c.city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT stad, 0
    FROM citiesthatexist
    WHERE stad NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:29:27
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:29:28
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  number
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      16
#[Out]# 5    Tilburg      18
#[Out]# 6    Utrecht      31
# Wed, 09 Dec 2020 12:48:10
query4_3 = '''
    WITH storecitycount(sName, city, scount) AS (
            SELECT sName, city, count(DISTINCT city)
            FROM store),
        allcities(ccount) AS (
            SELECT count(city)
            FROM customer
            UNION
            SELECT count(city)
            FROM store
        )
    SELECT DISTINCT sName
    FROM storecitycount AS s, allcities AS a
    WHERE s.scount == a.ccount
'''
# Wed, 09 Dec 2020 12:48:10
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 12:48:11
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:48:34
query4_4 = '''
    WITH datebuy(cID, date, price) AS (
        SELECT cID, date, sum(price)
        FROM purchase
        GROUP BY cID, date
        ),
        maxamount(money) AS (
        SELECT max(price)
        FROM datebuy
        )
    SELECT cName
    FROM customer AS c, datebuy AS d, maxamount AS max
    WHERE c.cID = d.cID AND d.price >= (0.75 * max.money)
'''
# Wed, 09 Dec 2020 12:48:35
vis.visualize(query4_4, schema)
# Wed, 09 Dec 2020 12:48:35
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 12:48:42
query4_5 = '''
    WITH citiesthatexist(stad) AS (
        SELECT city
        FROM customer
        UNION
        SELECT city
        FROM store
    ),
        citycount(cities, number) AS (
        SELECT c.city, count(p.cID)
        FROM customer AS c, purchase AS p, store AS s
        WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
        GROUP BY c.city
        )
    SELECT c.cities, c.number
    FROM citycount AS c
    UNION
    SELECT stad, 0
    FROM citiesthatexist
    WHERE stad NOT IN (SELECT c.cities FROM citycount AS c)
'''
# Wed, 09 Dec 2020 12:48:42
vis.visualize(query4_5, schema)
# Wed, 09 Dec 2020 12:48:43
pd.read_sql_query(query4_5, conn)
#[Out]#       cities  number
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      16
#[Out]# 5    Tilburg      18
#[Out]# 6    Utrecht      31


# IPython log file

# Sun, 06 Dec 2020 11:19:48
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Sun, 06 Dec 2020 11:19:51
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x200d0ddfb20>
# Sun, 06 Dec 2020 11:33:08
query4_3 = '''
    SELECT *
    FROM customer, store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#        cID   cName     street     city  sID        sName            street  \
#[Out]# 0        0    Noah  Koestraat  Utrecht    0         Coop      Kalverstraat   
#[Out]# 1        0    Noah  Koestraat  Utrecht    1    Hoogvliet  Rozemarijnstraat   
#[Out]# 2        0    Noah  Koestraat  Utrecht    2        Jumbo    Stadhoudersweg   
#[Out]# 3        0    Noah  Koestraat  Utrecht    3       Sligro    Stadhoudersweg   
#[Out]# 4        0    Noah  Koestraat  Utrecht    4    Hoogvliet       Molenstraat   
#[Out]# 5        0    Noah  Koestraat  Utrecht    5       Sligro     Stationsplein   
#[Out]# 6        0    Noah  Koestraat  Utrecht    6         Coop    Stadhoudersweg   
#[Out]# 7        0    Noah  Koestraat  Utrecht    7       Sligro  Wilhelminastraat   
#[Out]# 8        0    Noah  Koestraat  Utrecht    8  Albert Hein       Molenstraat   
#[Out]# 9        0    Noah  Koestraat  Utrecht    9  Albert Hein         Koestraat   
#[Out]# 10       0    Noah  Koestraat  Utrecht   10        Jumbo        Bergselaan   
#[Out]# 11       0    Noah  Koestraat  Utrecht   11  Albert Hein          Hofplein   
#[Out]# 12       0    Noah  Koestraat  Utrecht   12         Lidl  Wilhelminastraat   
#[Out]# 13       0    Noah  Koestraat  Utrecht   13         Coop         Koestraat   
#[Out]# 14       0    Noah  Koestraat  Utrecht   14         Coop     Keizersgracht   
#[Out]# 15       0    Noah  Koestraat  Utrecht   15         Lidl     Prinsengracht   
#[Out]# 16       0    Noah  Koestraat  Utrecht   16         Lidl     Ambachtstraat   
#[Out]# 17       0    Noah  Koestraat  Utrecht   17    Hoogvliet        Kerkstraat   
#[Out]# 18       0    Noah  Koestraat  Utrecht   18       Sligro       Parallelweg   
#[Out]# 19       0    Noah  Koestraat  Utrecht   19         Coop       Karrestraat   
#[Out]# 20       0    Noah  Koestraat  Utrecht   20        Jumbo      Kasteeldreef   
#[Out]# 21       0    Noah  Koestraat  Utrecht   21         Coop      Kasteeldreef   
#[Out]# 22       0    Noah  Koestraat  Utrecht   22         Lidl     Prinsengracht   
#[Out]# 23       0    Noah  Koestraat  Utrecht   23         Dirk     Stationsplein   
#[Out]# 24       0    Noah  Koestraat  Utrecht   24  Albert Hein     Stationsplein   
#[Out]# 25       0    Noah  Koestraat  Utrecht   25  Albert Hein     Stationsplein   
#[Out]# 26       0    Noah  Koestraat  Utrecht   26    Hoogvliet   Sint Annastraat   
#[Out]# 27       0    Noah  Koestraat  Utrecht   27       Sligro      Kalverstraat   
#[Out]# 28       0    Noah  Koestraat  Utrecht   28    Hoogvliet         Koestraat   
#[Out]# 29       0    Noah  Koestraat  Utrecht   29       Sligro      Marnixstraat   
#[Out]# ...    ...     ...        ...      ...  ...          ...               ...   
#[Out]# 12130  190  Kostas   Eindeweg  Utrecht   34         Coop          Bierkaai   
#[Out]# 12131  190  Kostas   Eindeweg  Utrecht   35         Lidl     Julianastraat   
#[Out]# 12132  190  Kostas   Eindeweg  Utrecht   36         Lidl     Julianastraat   
#[Out]# 12133  190  Kostas   Eindeweg  Utrecht   37        Jumbo          Molenweg   
#[Out]# 12134  190  Kostas   Eindeweg  Utrecht   38    Hoogvliet          Hofplein   
#[Out]# 12135  190  Kostas   Eindeweg  Utrecht   39       Sligro       Dorpsstraat   
#[Out]# 12136  190  Kostas   Eindeweg  Utrecht   40    Hoogvliet          Hofplein   
#[Out]# 12137  190  Kostas   Eindeweg  Utrecht   41  Albert Hein        Bergselaan   
#[Out]# 12138  190  Kostas   Eindeweg  Utrecht   42       Sligro      Kalverstraat   
#[Out]# 12139  190  Kostas   Eindeweg  Utrecht   43         Coop    Gasthuisstraat   
#[Out]# 12140  190  Kostas   Eindeweg  Utrecht   44  Albert Hein     Ambachtstraat   
#[Out]# 12141  190  Kostas   Eindeweg  Utrecht   45         Coop      Kasteeldreef   
#[Out]# 12142  190  Kostas   Eindeweg  Utrecht   46         Lidl        Bergselaan   
#[Out]# 12143  190  Kostas   Eindeweg  Utrecht   47         Coop     Julianastraat   
#[Out]# 12144  190  Kostas   Eindeweg  Utrecht   48    Hoogvliet      Kasteeldreef   
#[Out]# 12145  190  Kostas   Eindeweg  Utrecht   49    Hoogvliet      Keizerstraat   
#[Out]# 12146  190  Kostas   Eindeweg  Utrecht   50       Sligro     Stationsplein   
#[Out]# 12147  190  Kostas   Eindeweg  Utrecht   51         Coop       Parallelweg   
#[Out]# 12148  190  Kostas   Eindeweg  Utrecht   52         Lidl       Nieuwstraat   
#[Out]# 12149  190  Kostas   Eindeweg  Utrecht   53         Coop        Hoogstraat   
#[Out]# 12150  190  Kostas   Eindeweg  Utrecht   54         Dirk     Julianastraat   
#[Out]# 12151  190  Kostas   Eindeweg  Utrecht   55         Coop   Sint Annastraat   
#[Out]# 12152  190  Kostas   Eindeweg  Utrecht   56        Jumbo       Parallelweg   
#[Out]# 12153  190  Kostas   Eindeweg  Utrecht   57         Dirk       Molenstraat   
#[Out]# 12154  190  Kostas   Eindeweg  Utrecht   58         Dirk      Keizerstraat   
#[Out]# 12155  190  Kostas   Eindeweg  Utrecht   59        Jumbo  Rozemarijnstraat   
#[Out]# 12156  190  Kostas   Eindeweg  Utrecht   60         Lidl      Pannekoekweg   
#[Out]# 12157  190  Kostas   Eindeweg  Utrecht   61         Lidl      Pannekoekweg   
#[Out]# 12158  190  Kostas   Eindeweg  Utrecht   62        Jumbo     Poffertjesweg   
#[Out]# 12159  190  Kostas   Eindeweg  Utrecht   63        Jumbo     Stationstraat   
#[Out]# 
#[Out]#             city  
#[Out]# 0      Amsterdam  
#[Out]# 1          Breda  
#[Out]# 2      Rotterdam  
#[Out]# 3      Rotterdam  
#[Out]# 4      Eindhoven  
#[Out]# 5          Breda  
#[Out]# 6      Rotterdam  
#[Out]# 7      Eindhoven  
#[Out]# 8      Eindhoven  
#[Out]# 9        Tilburg  
#[Out]# 10     Rotterdam  
#[Out]# 11     Rotterdam  
#[Out]# 12     Eindhoven  
#[Out]# 13       Tilburg  
#[Out]# 14     Amsterdam  
#[Out]# 15     Amsterdam  
#[Out]# 16       Utrecht  
#[Out]# 17     Eindhoven  
#[Out]# 18       Tilburg  
#[Out]# 19         Breda  
#[Out]# 20       Tilburg  
#[Out]# 21       Tilburg  
#[Out]# 22     Amsterdam  
#[Out]# 23         Breda  
#[Out]# 24         Breda  
#[Out]# 25         Breda  
#[Out]# 26         Breda  
#[Out]# 27     Amsterdam  
#[Out]# 28       Tilburg  
#[Out]# 29     Amsterdam  
#[Out]# ...          ...  
#[Out]# 12130  Amsterdam  
#[Out]# 12131    Utrecht  
#[Out]# 12132  Eindhoven  
#[Out]# 12133  Eindhoven  
#[Out]# 12134  Rotterdam  
#[Out]# 12135  Eindhoven  
#[Out]# 12136  Rotterdam  
#[Out]# 12137  Rotterdam  
#[Out]# 12138  Amsterdam  
#[Out]# 12139    Utrecht  
#[Out]# 12140    Utrecht  
#[Out]# 12141    Tilburg  
#[Out]# 12142  Rotterdam  
#[Out]# 12143  Rotterdam  
#[Out]# 12144    Tilburg  
#[Out]# 12145  Rotterdam  
#[Out]# 12146      Breda  
#[Out]# 12147    Utrecht  
#[Out]# 12148  Eindhoven  
#[Out]# 12149    Utrecht  
#[Out]# 12150  Eindhoven  
#[Out]# 12151      Breda  
#[Out]# 12152  Eindhoven  
#[Out]# 12153  Eindhoven  
#[Out]# 12154  Rotterdam  
#[Out]# 12155      Breda  
#[Out]# 12156      Breda  
#[Out]# 12157      Breda  
#[Out]# 12158  Eindhoven  
#[Out]# 12159        Oss  
#[Out]# 
#[Out]# [12160 rows x 8 columns]
# Sun, 06 Dec 2020 11:37:16
query4_3 = '''
    SELECT city
    FROM customer
    UNION
    SELECT city 
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 13:01:07
query4_3 = '''
SELECT sName, city
FROM store as s
WHERE NOT EXISTS ((SELECT city FROM customer
    UNION
    SELECT city FROM store)
    EXCEPT
    SELECT store.city FROM store WHERE s.city = store.city
    )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:02:04
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS ((SELECT city FROM customer
    UNION
    SELECT city FROM store)
    EXCEPT
    SELECT store.city FROM store WHERE s.city = store.city
    )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:03:16
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS ((SELECT city FROM customer
    UNION
    SELECT city FROM store)
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)
    )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:03:39
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS (
    (SELECT city FROM customer
    UNION
    SELECT city FROM store)
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)
    )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:08:16
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS (
    ((SELECT city FROM customer)
    UNION
    (SELECT city FROM store))
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)
    )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:08:22
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXIST (
    ((SELECT city FROM customer)
    UNION
    (SELECT city FROM store))
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)
    )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:08:39
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS (
    ((SELECT city FROM customer)
    UNION
    (SELECT city FROM store))
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)
    )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:17:47
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
  (
    (
       (SELECT city FROM customer)
       UNION
       (SELECT city FROM store)
    )
--    EXCEPT
--    (SELECT store.city FROM store WHERE s.city = store.city)
  )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:19:08
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
  (
    (
       (SELECT city FROM customer)
       UNION
       (SELECT city FROM store)
    )
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)
  )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:20:18
query4_3 = '''
SELECT s.sName, s.city
FROM store as s

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Sun, 06 Dec 2020 13:21:01
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
  (
    (
       (SELECT city FROM customer)
       UNION
       (SELECT city FROM store)
    )

  )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:22:15
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
  (
    (
       (SELECT city FROM store)
       UNION
       (SELECT city FROM store)
    )
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)
  )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:22:47
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
select city from story
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:23:04
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
(select city from story)
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:23:15
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
(select city from store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:24:03
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
 (select city from customer)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:24:34
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (
       (SELECT city FROM customer)
       UNION
       (SELECT city FROM store)
    )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:25:09
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
(
(SELECT city FROM customer)
UNION
(SELECT city FROM store)
)
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:25:56
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
  (
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
    )
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)
  )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:26:19
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
  (
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
    )
  )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:26:39
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
    )
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:28:33
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
    )
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)   
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:29:22
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
( select city from 
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
    )
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)   
 )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:29:55
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
( select city from 
  (  (SELECT city FROM customer
     UNION
     SELECT city FROM store
    )
    EXCEPT
    (SELECT store.city FROM store WHERE s.city = store.city)   
   )
 )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:30:17
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
( select city from 
  (  (SELECT city FROM customer
     UNION
     SELECT city FROM store
    )
    EXCEPT
    SELECT store.city FROM store WHERE s.city = store.city
   )
 )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:31:29
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
    EXCEPT
    SELECT store.city FROM store WHERE s.city = store.city
   )
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:32:21
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM customer
     UNION
     ( SELECT city FROM store
       EXCEPT
       SELECT store.city FROM store WHERE s.city = store.city
    )
   )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:32:47
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
     EXCEPT
     SELECT store.city FROM store WHERE s.city = store.city
   )
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:34:12
query4_5 = '''
    SELECT city FROM customer
     UNION
     SELECT city FROM store
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Sun, 06 Dec 2020 13:39:32
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
(select city from t
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
    ) t
)

'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:39:55
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
(select city from t
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
    ) as t
)

'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:41:44
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
(select city from
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
     EXCEPT
     SELECT store.city FROM store WHERE s.city = store.city
   )
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:42:05
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
(select city from t
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
     EXCEPT
     SELECT store.city FROM store WHERE s.city = store.city
   ) t
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:42:21
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
(select t.city from t
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
     EXCEPT
     SELECT store.city FROM store WHERE s.city = store.city
   ) t
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:42:37
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
(select t.city from 
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
     EXCEPT
     SELECT store.city FROM store WHERE s.city = store.city
   ) t
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:42:54
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM customer
     UNION
     SELECT city FROM store
     EXCEPT
     SELECT store.city FROM store WHERE s.city = store.city
   ) 
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:43:25
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM store
     EXCEPT
     SELECT store.city FROM store WHERE s.city = store.city
SELECT city FROM customer
     UNION
        ) 
'''

pd.read_sql_query(query4_3, conn)
# Sun, 06 Dec 2020 13:43:49
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM store
     EXCEPT
     SELECT store.city FROM store WHERE s.city = store.city
     UNION
     SELECT city FROM customer
        ) 
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Sun, 06 Dec 2020 13:47:53
query4_5 = '''
     (SELECT city FROM customer
     UNION
     SELECT city FROM store)
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:48:38
query4_5 = '''
     (SELECT city FROM customer
     UNION
     SELECT city FROM store)
     EXCEPT store.city FROM store
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:48:46
query4_5 = '''
     SELECT city FROM customer
     UNION
     SELECT city FROM store
     EXCEPT store.city FROM store
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 13:52:16
query4_4 = '''
select price from purchare
'''

pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 13:52:26
query4_4 = '''
select price from purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.45
#[Out]# 1     4.65
#[Out]# 2     1.60
#[Out]# 3     1.25
#[Out]# 4     3.95
#[Out]# 5     2.75
#[Out]# 6     0.90
#[Out]# 7     9.10
#[Out]# 8     2.45
#[Out]# 9     1.35
#[Out]# 10    1.10
#[Out]# 11    3.70
#[Out]# 12    1.55
#[Out]# 13    4.30
#[Out]# 14    2.75
#[Out]# 15    1.45
#[Out]# 16    4.15
#[Out]# 17    9.05
#[Out]# 18   13.60
#[Out]# 19    1.05
#[Out]# 20    3.05
#[Out]# 21    2.75
#[Out]# 22    4.70
#[Out]# 23    8.25
#[Out]# 24    1.10
#[Out]# 25    1.55
#[Out]# 26    1.85
#[Out]# 27    2.20
#[Out]# 28    2.10
#[Out]# 29    1.70
#[Out]# ..     ...
#[Out]# 479   2.80
#[Out]# 480   0.50
#[Out]# 481   2.55
#[Out]# 482   0.65
#[Out]# 483   0.70
#[Out]# 484   3.70
#[Out]# 485   3.50
#[Out]# 486   2.95
#[Out]# 487   2.75
#[Out]# 488   1.50
#[Out]# 489   0.85
#[Out]# 490   3.55
#[Out]# 491   2.60
#[Out]# 492   3.25
#[Out]# 493   4.30
#[Out]# 494   3.05
#[Out]# 495   4.05
#[Out]# 496   1.50
#[Out]# 497   2.50
#[Out]# 498   3.95
#[Out]# 499   3.50
#[Out]# 500   2.95
#[Out]# 501   1.60
#[Out]# 502   3.25
#[Out]# 503   0.75
#[Out]# 504   3.80
#[Out]# 505   4.35
#[Out]# 506   2.85
#[Out]# 507   3.15
#[Out]# 508   3.30
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Sun, 06 Dec 2020 13:52:58
query4_4 = '''
select price * quantity from purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price * quantity
#[Out]# 0                0.45
#[Out]# 1                9.30
#[Out]# 2                4.80
#[Out]# 3                2.50
#[Out]# 4               15.80
#[Out]# 5               11.00
#[Out]# 6                7.20
#[Out]# 7               54.60
#[Out]# 8                2.45
#[Out]# 9                9.45
#[Out]# 10               6.60
#[Out]# 11              14.80
#[Out]# 12               1.55
#[Out]# 13               8.60
#[Out]# 14               5.50
#[Out]# 15               8.70
#[Out]# 16               8.30
#[Out]# 17              81.45
#[Out]# 18              68.00
#[Out]# 19               2.10
#[Out]# 20              27.45
#[Out]# 21              11.00
#[Out]# 22              28.20
#[Out]# 23              49.50
#[Out]# 24               9.90
#[Out]# 25               3.10
#[Out]# 26               3.70
#[Out]# 27               2.20
#[Out]# 28               4.20
#[Out]# 29              10.20
#[Out]# ..                ...
#[Out]# 479             11.20
#[Out]# 480              2.50
#[Out]# 481              7.65
#[Out]# 482              2.60
#[Out]# 483              2.80
#[Out]# 484             14.80
#[Out]# 485              7.00
#[Out]# 486             14.75
#[Out]# 487             13.75
#[Out]# 488             10.50
#[Out]# 489              4.25
#[Out]# 490              7.10
#[Out]# 491             10.40
#[Out]# 492             13.00
#[Out]# 493             25.80
#[Out]# 494              9.15
#[Out]# 495             24.30
#[Out]# 496              1.50
#[Out]# 497             12.50
#[Out]# 498             15.80
#[Out]# 499             21.00
#[Out]# 500             20.65
#[Out]# 501              6.40
#[Out]# 502             16.25
#[Out]# 503              5.25
#[Out]# 504              7.60
#[Out]# 505             26.10
#[Out]# 506             14.25
#[Out]# 507              6.30
#[Out]# 508              3.30
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Sun, 06 Dec 2020 13:53:33
query4_4 = '''
select max(price * quantity) from purchase group by cid
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      max(price * quantity)
#[Out]# 0                     0.45
#[Out]# 1                    54.60
#[Out]# 2                    14.80
#[Out]# 3                     8.70
#[Out]# 4                    81.45
#[Out]# 5                    49.50
#[Out]# 6                    21.50
#[Out]# 7                    26.50
#[Out]# 8                    16.00
#[Out]# 9                    32.80
#[Out]# 10                   26.75
#[Out]# 11                    4.50
#[Out]# 12                   24.00
#[Out]# 13                   34.20
#[Out]# 14                   17.80
#[Out]# 15                    6.40
#[Out]# 16                   63.90
#[Out]# 17                   63.45
#[Out]# 18                   24.15
#[Out]# 19                   20.00
#[Out]# 20                   22.95
#[Out]# 21                   12.60
#[Out]# 22                   31.95
#[Out]# 23                    2.20
#[Out]# 24                   15.60
#[Out]# 25                   91.60
#[Out]# 26                   15.60
#[Out]# 27                  115.20
#[Out]# 28                   27.60
#[Out]# 29                   66.15
#[Out]# ..                     ...
#[Out]# 102                  49.95
#[Out]# 103                  14.40
#[Out]# 104                  10.50
#[Out]# 105                  10.00
#[Out]# 106                  12.60
#[Out]# 107                  36.90
#[Out]# 108                  34.75
#[Out]# 109                 118.35
#[Out]# 110                  13.95
#[Out]# 111                  21.30
#[Out]# 112                  36.00
#[Out]# 113                  33.90
#[Out]# 114                  61.60
#[Out]# 115                  27.65
#[Out]# 116                   4.70
#[Out]# 117                   7.40
#[Out]# 118                   8.10
#[Out]# 119                  34.65
#[Out]# 120                  20.70
#[Out]# 121                  32.40
#[Out]# 122                  72.00
#[Out]# 123                  32.40
#[Out]# 124                  10.80
#[Out]# 125                  37.80
#[Out]# 126                   7.00
#[Out]# 127                   1.00
#[Out]# 128                   5.00
#[Out]# 129                   1.00
#[Out]# 130                   7.50
#[Out]# 131                  26.25
#[Out]# 
#[Out]# [132 rows x 1 columns]
# Sun, 06 Dec 2020 13:53:55
query4_4 = '''
select cid, max(price * quantity) from purchase group by cid
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID  max(price * quantity)
#[Out]# 0      0                   0.45
#[Out]# 1      1                  54.60
#[Out]# 2      2                  14.80
#[Out]# 3      3                   8.70
#[Out]# 4      4                  81.45
#[Out]# 5      5                  49.50
#[Out]# 6      7                  21.50
#[Out]# 7      8                  26.50
#[Out]# 8     10                  16.00
#[Out]# 9     11                  32.80
#[Out]# 10    13                  26.75
#[Out]# 11    15                   4.50
#[Out]# 12    16                  24.00
#[Out]# 13    17                  34.20
#[Out]# 14    18                  17.80
#[Out]# 15    19                   6.40
#[Out]# 16    20                  63.90
#[Out]# 17    21                  63.45
#[Out]# 18    22                  24.15
#[Out]# 19    24                  20.00
#[Out]# 20    25                  22.95
#[Out]# 21    26                  12.60
#[Out]# 22    27                  31.95
#[Out]# 23    28                   2.20
#[Out]# 24    29                  15.60
#[Out]# 25    30                  91.60
#[Out]# 26    31                  15.60
#[Out]# 27    33                 115.20
#[Out]# 28    34                  27.60
#[Out]# 29    35                  66.15
#[Out]# ..   ...                    ...
#[Out]# 102  147                  49.95
#[Out]# 103  149                  14.40
#[Out]# 104  151                  10.50
#[Out]# 105  152                  10.00
#[Out]# 106  157                  12.60
#[Out]# 107  159                  36.90
#[Out]# 108  161                  34.75
#[Out]# 109  162                 118.35
#[Out]# 110  163                  13.95
#[Out]# 111  165                  21.30
#[Out]# 112  167                  36.00
#[Out]# 113  168                  33.90
#[Out]# 114  169                  61.60
#[Out]# 115  170                  27.65
#[Out]# 116  171                   4.70
#[Out]# 117  172                   7.40
#[Out]# 118  175                   8.10
#[Out]# 119  176                  34.65
#[Out]# 120  177                  20.70
#[Out]# 121  178                  32.40
#[Out]# 122  179                  72.00
#[Out]# 123  180                  32.40
#[Out]# 124  181                  10.80
#[Out]# 125  182                  37.80
#[Out]# 126  184                   7.00
#[Out]# 127  185                   1.00
#[Out]# 128  186                   5.00
#[Out]# 129  188                   1.00
#[Out]# 130  189                   7.50
#[Out]# 131  190                  26.25
#[Out]# 
#[Out]# [132 rows x 2 columns]
# Sun, 06 Dec 2020 13:54:39
query4_4 = '''
select date,cid, max(price * quantity) from purchase group by date,cid
'''

pd.read_sql_query(query4_4, conn)
#[Out]#            date  cID  max(price * quantity)
#[Out]# 0    2018-08-15   21                  10.35
#[Out]# 1    2018-08-15   30                   5.40
#[Out]# 2    2018-08-15   37                  18.00
#[Out]# 3    2018-08-15   42                   4.80
#[Out]# 4    2018-08-15   59                  13.20
#[Out]# 5    2018-08-15  108                  33.60
#[Out]# 6    2018-08-15  167                  18.45
#[Out]# 7    2018-08-15  190                  26.25
#[Out]# 8    2018-08-16    2                   2.45
#[Out]# 9    2018-08-16    8                  26.50
#[Out]# 10   2018-08-16   18                  10.80
#[Out]# 11   2018-08-16   21                   7.20
#[Out]# 12   2018-08-16   27                   9.60
#[Out]# 13   2018-08-16   33                   6.90
#[Out]# 14   2018-08-16   40                  86.40
#[Out]# 15   2018-08-16   45                  12.60
#[Out]# 16   2018-08-16   55                  10.35
#[Out]# 17   2018-08-16   57                   5.60
#[Out]# 18   2018-08-16   59                   5.25
#[Out]# 19   2018-08-16   66                  18.25
#[Out]# 20   2018-08-16   80                  49.95
#[Out]# 21   2018-08-16   96                   1.30
#[Out]# 22   2018-08-16  162                   3.30
#[Out]# 23   2018-08-16  168                  33.90
#[Out]# 24   2018-08-16  169                   3.80
#[Out]# 25   2018-08-16  170                  27.65
#[Out]# 26   2018-08-16  190                  22.75
#[Out]# 27   2018-08-17    2                  14.80
#[Out]# 28   2018-08-17    5                  28.20
#[Out]# 29   2018-08-17   13                  26.75
#[Out]# ..          ...  ...                    ...
#[Out]# 255  2018-08-27   16                  14.80
#[Out]# 256  2018-08-27   22                  24.15
#[Out]# 257  2018-08-27   27                   9.90
#[Out]# 258  2018-08-27   28                   2.20
#[Out]# 259  2018-08-27   31                   8.10
#[Out]# 260  2018-08-27   33                 115.20
#[Out]# 261  2018-08-27   58                   4.95
#[Out]# 262  2018-08-27   67                  15.40
#[Out]# 263  2018-08-27   68                   4.95
#[Out]# 264  2018-08-27   91                  12.00
#[Out]# 265  2018-08-27   92                  27.00
#[Out]# 266  2018-08-27  110                  13.80
#[Out]# 267  2018-08-27  157                  12.60
#[Out]# 268  2018-08-27  163                  13.95
#[Out]# 269  2018-08-27  169                   3.85
#[Out]# 270  2018-08-27  172                   3.60
#[Out]# 271  2018-08-27  178                  32.40
#[Out]# 272  2018-08-27  180                  32.40
#[Out]# 273  2018-08-27  181                  10.00
#[Out]# 274  2018-08-27  190                  26.10
#[Out]# 275  2018-08-28   22                   2.70
#[Out]# 276  2018-08-28   25                  22.95
#[Out]# 277  2018-08-28   31                  15.60
#[Out]# 278  2018-08-28   39                  15.00
#[Out]# 279  2018-08-28   69                  48.40
#[Out]# 280  2018-08-28  157                  12.60
#[Out]# 281  2018-08-28  169                  32.55
#[Out]# 282  2018-08-28  182                  31.20
#[Out]# 283  2018-08-29   39                  21.15
#[Out]# 284  2018-09-20  188                   1.00
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Sun, 06 Dec 2020 13:56:55
query4_4 = '''
select max(subtotals.total) from 
(select date,cid, max(price * quantity) totals from purchase group by date,cid) subtotals
'''

pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 13:57:04
query4_4 = '''
select max(subtotals.total) from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    max(subtotals.total)
#[Out]# 0                150.15
# Sun, 06 Dec 2020 14:00:33
query4_4 = '''
select cname 
from customer
join purchase on purchase.cid = customer.id
where purchase.price * purchase.quantity * 0.75 >
(
select max(subtotals.total) from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 14:00:56
query4_4 = '''
select cname 
from customer
join purchase on purchase.cid = customer.cid
where purchase.price * purchase.quantity * 0.75 >
(
select max(subtotals.total) from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cName]
#[Out]# Index: []
# Sun, 06 Dec 2020 14:02:03
query4_4 = '''
select cname 
from customer
join purchase on purchase.cid = customer.cid
where purchase.price * purchase.quantity  >
(
select max(subtotals.total) * 0.75 from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Lynn
#[Out]# 2    Ivy
#[Out]# 3  Elena
# Sun, 06 Dec 2020 14:02:26
query4_4 = '''
select cname 
from customer
join purchase on purchase.cid = customer.cid
where purchase.price * purchase.quantity  >=
(
select max(subtotals.total) * 0.75 from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Lynn
#[Out]# 2    Ivy
#[Out]# 3  Elena
# Sun, 06 Dec 2020 14:05:28
query4_4 = '''
select cname 
from customer
join purchase on purchase.cid = customer.cid
where purchase.price * purchase.quantity  =>
(
select max(subtotals.total) * 0.75 from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 14:05:36
query4_4 = '''
select cname 
from customer
join purchase on purchase.cid = customer.cid
where purchase.price * purchase.quantity  >=
(
select max(subtotals.total) * 0.75 from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Lynn
#[Out]# 2    Ivy
#[Out]# 3  Elena
# Sun, 06 Dec 2020 14:06:17
query4_5 = '''
     select max(subtotals.total) * 0.75 from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    max(subtotals.total) * 0.75
#[Out]# 0                     112.6125
# Sun, 06 Dec 2020 14:06:27
query4_5 = '''
     select max(subtotals.total), cid from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    max(subtotals.total)  cid
#[Out]# 0                150.15  109
# Sun, 06 Dec 2020 14:06:35
query4_4 = '''
select cname, cid
from customer
join purchase on purchase.cid = customer.cid
where purchase.price * purchase.quantity  >=
(
select max(subtotals.total) * 0.75 from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_4, conn)
# Sun, 06 Dec 2020 14:06:41
query4_4 = '''
select cname, customer.cid
from customer
join purchase on purchase.cid = customer.cid
where purchase.price * purchase.quantity  >=
(
select max(subtotals.total) * 0.75 from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName  cID
#[Out]# 0   Sven   33
#[Out]# 1   Lynn  109
#[Out]# 2    Ivy  144
#[Out]# 3  Elena  162
# Sun, 06 Dec 2020 18:43:37
query4_5 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >=
(
select max(subtotals.total) * 0.75 from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Lynn
#[Out]# 2    Ivy
#[Out]# 3  Elena
# Sun, 06 Dec 2020 18:45:08
query4_5 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >=
(
select max(max(price * quantity)) * 0.75 from 
(select date,cid, max(price * quantity) total from purchase group by date,cid) subtotals
)
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 18:46:16
query4_5 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >=
(
select max(total)
from (select date,cid, max(price * quantity) as total from purchase group by date,cid)
)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#   cName
#[Out]# 0  Lynn
# Sun, 06 Dec 2020 18:46:34
query4_5 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >= 0.75 *
(
select max(total)
from (select date,cid, max(price * quantity) as total from purchase group by date,cid)
)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Lynn
#[Out]# 2    Ivy
#[Out]# 3  Elena
# Sun, 06 Dec 2020 18:46:55
query4_5 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >= 0.75 *
(
select max(maximum)
from (select date,cid, max(price * quantity) as maximum from purchase group by date,cid)
)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Lynn
#[Out]# 2    Ivy
#[Out]# 3  Elena
# Sun, 06 Dec 2020 18:47:36
query4_4 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >= 0.74 *
(
select max(maximum)
from (select date,cid, max(price * quantity) as maximum from purchase group by date,cid)
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Lynn
#[Out]# 2    Ivy
#[Out]# 3  Elena
# Sun, 06 Dec 2020 18:47:38
query4_4 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >= 0.70 *
(
select max(maximum)
from (select date,cid, max(price * quantity) as maximum from purchase group by date,cid)
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1  Dylan
#[Out]# 2   Lynn
#[Out]# 3    Ivy
#[Out]# 4  Elena
# Sun, 06 Dec 2020 18:47:45
query4_4 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >= 0.75 *
(
select max(maximum)
from (select date,cid, max(price * quantity) as maximum from purchase group by date,cid)
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Lynn
#[Out]# 2    Ivy
#[Out]# 3  Elena
# Sun, 06 Dec 2020 18:51:55
query4_5 = '''
select max(maximum)
from (select date,cid, max(price * quantity) as maximum from purchase group by date,cid)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    max(maximum)
#[Out]# 0        150.15
# Sun, 06 Dec 2020 18:54:24
query4_4 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >= 0.75 *
(
select max(maximum)
from (select date,cid, max(price * quantity) as maximum from purchase group by date,cid)
)
group by date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Lynn
#[Out]# 1    Ivy
#[Out]# 2  Elena
#[Out]# 3   Sven
# Sun, 06 Dec 2020 18:54:59
query4_4 = '''
select cname
from customer, purchase
where purchase.cid = customer.cid
and purchase.price * purchase.quantity  >= 0.75 *
(
select max(maximum)
from (select date,cid, max(price * quantity) as maximum from purchase group by date,cid)
)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Lynn
#[Out]# 2    Ivy
#[Out]# 3  Elena
# Sun, 06 Dec 2020 18:55:47
query4_5 = '''

'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 18:57:39
query4_5 = '''
    select count(customer.cID)
    from customer, store
    where customer.cid = store.cid 
    and store.city = 'Eindhoven'
    group by city
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 18:58:44
query4_5 = '''
    select city, count(customer.cID)
    from customer, store, purchase
    where customer.cid = purchase.cid 
    and purchase.sid = store.sid
    and store.city = 'Eindhoven'
    group by city
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 18:58:51
query4_5 = '''
    select city, count(customer.cID)
    from customer, store, purchase
    where customer.cid = purchase.cid 
    and purchase.sid = store.sid
    and store.city = 'Eindhoven'
    group by store.city
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 18:58:58
query4_5 = '''
    select store.city, count(customer.cID)
    from customer, store, purchase
    where customer.cid = purchase.cid 
    and purchase.sid = store.sid
    and store.city = 'Eindhoven'
    group by store.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cID)
#[Out]# 0  Eindhoven                  133
# Sun, 06 Dec 2020 18:59:56
query4_5 = '''
    select store.city, count(customer.cID)
    from customer, store, purchase
    where exists customer.cid = purchase.cid 
    and purchase.sid = store.sid
    and store.city = 'Eindhoven'
    group by store.city
'''

pd.read_sql_query(query4_5, conn)
# Sun, 06 Dec 2020 19:00:02
query4_5 = '''
    select store.city, count(customer.cID)
    from customer, store, purchase
    where customer.cid = purchase.cid 
    and purchase.sid = store.sid
    and store.city = 'Eindhoven'
    group by store.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cID)
#[Out]# 0  Eindhoven                  133
# Sun, 06 Dec 2020 19:03:52
query4_5 = '''
select customer.city, count(customer.cid)
from customer
where exists (select 1 from store
              , purchase
              where purchase.cid = customer.cid
              and purchase.sid = store.sid
              and store.city = 'Eindhoven')
group by customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cid)
#[Out]# 0  Amsterdam                   10
#[Out]# 1      Breda                    9
#[Out]# 2  Eindhoven                   15
#[Out]# 3  Rotterdam                   13
#[Out]# 4    Tilburg                   10
#[Out]# 5    Utrecht                   12

# IPython log file

query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM store
     UNION
     SELECT city FROM customer
     UNION
     SELECT store.city FROM store WHERE s.city = store.city
     ) 
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 09:32:37
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 09:32:46
query4_3 = '''
SELECT s.sName, s.city
FROM store as s
WHERE NOT EXISTS 
    (SELECT city FROM store
     UNION
     SELECT city FROM customer
     UNION
     SELECT store.city FROM store WHERE s.city = store.city
     ) 
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 10:23:29
query4_5 = '''
select customer.city, count(customer.cid)
from customer
where exists (select 1 from store, purchase
              where purchase.cid = customer.cid
              and purchase.sid = store.sid
              and store.city = 'Eindhoven')
    or not exists (select 1 from store, purchase
              where purchase.cid = customer.cid
              and purchase.sid = store.sid
              and store.city = 'Eindhoven')
group by customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cid)
#[Out]# 0  Amsterdam                   26
#[Out]# 1      Breda                   27
#[Out]# 2  Eindhoven                   33
#[Out]# 3        Oss                    1
#[Out]# 4  Rotterdam                   29
#[Out]# 5    Tilburg                   38
#[Out]# 6    Utrecht                   36
# Tue, 08 Dec 2020 10:23:55
query4_5 = '''
select customer.city, count(customer.cid)
from customer
where exists (select 1 from store, purchase
              where purchase.cid = customer.cid
              and purchase.sid = store.sid
              and store.city = 'Eindhoven')
    or exists (select 1 from store, purchase
              where purchase.cid = customer.cid
              and purchase.sid = store.sid
              and store.city != 'Eindhoven')
group by customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cid)
#[Out]# 0  Amsterdam                   20
#[Out]# 1      Breda                   16
#[Out]# 2  Eindhoven                   22
#[Out]# 3        Oss                    1
#[Out]# 4  Rotterdam                   25
#[Out]# 5    Tilburg                   26
#[Out]# 6    Utrecht                   22
# Tue, 08 Dec 2020 10:24:24
query4_5 = '''
select customer.city, count(customer.cid)
from customer
where exists (select 1 from store, purchase
              where purchase.cid = customer.cid
              and purchase.sid = store.sid
              and store.city = 'Eindhoven')

group by customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(customer.cid)
#[Out]# 0  Amsterdam                   10
#[Out]# 1      Breda                    9
#[Out]# 2  Eindhoven                   15
#[Out]# 3  Rotterdam                   13
#[Out]# 4    Tilburg                   10
#[Out]# 5    Utrecht                   12


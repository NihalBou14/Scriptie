# IPython log file

# Tue, 08 Dec 2020 15:36:46
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 15:36:53
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x163779aed50>
# Tue, 08 Dec 2020 15:49:17
query4_3 = '''
    SELECT c.city, s.city
    FROM customer c, store s
'''
# Tue, 08 Dec 2020 15:49:18
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:50:19
schema = vis.schema_from_conn(conn)
# Tue, 08 Dec 2020 15:50:23
query4_3 = '''
    SELECT c.city, s.city
    FROM customer c, store s
'''
# Tue, 08 Dec 2020 15:50:23
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:50:32
pd.read_sql_query(query4_3, conn)
#[Out]#           city       city
#[Out]# 0      Utrecht  Amsterdam
#[Out]# 1      Utrecht      Breda
#[Out]# 2      Utrecht  Rotterdam
#[Out]# 3      Utrecht  Rotterdam
#[Out]# 4      Utrecht  Eindhoven
#[Out]# ...        ...        ...
#[Out]# 12155  Utrecht      Breda
#[Out]# 12156  Utrecht      Breda
#[Out]# 12157  Utrecht      Breda
#[Out]# 12158  Utrecht  Eindhoven
#[Out]# 12159  Utrecht        Oss
#[Out]# 
#[Out]# [12160 rows x 2 columns]
# Tue, 08 Dec 2020 15:52:19
query4_3 = '''
    SELECT c.city, s.city
    FROM customer c, store s
    WHERE c.city NOT IS 'Utrecht'
'''
# Tue, 08 Dec 2020 15:52:20
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:52:36
query4_3 = '''
    SELECT c.city, s.city
    FROM customer c, store s
    WHERE NOT c.city = 'Utrecht'
'''
# Tue, 08 Dec 2020 15:52:37
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:52:41
pd.read_sql_query(query4_3, conn)
#[Out]#        city       city
#[Out]# 0     Breda  Amsterdam
#[Out]# 1     Breda      Breda
#[Out]# 2     Breda  Rotterdam
#[Out]# 3     Breda  Rotterdam
#[Out]# 4     Breda  Eindhoven
#[Out]# ...     ...        ...
#[Out]# 9851    Oss      Breda
#[Out]# 9852    Oss      Breda
#[Out]# 9853    Oss      Breda
#[Out]# 9854    Oss  Eindhoven
#[Out]# 9855    Oss        Oss
#[Out]# 
#[Out]# [9856 rows x 2 columns]
# Tue, 08 Dec 2020 15:52:56
query4_3 = '''
    SELECT c.city, s.city
    FROM customer c, store s
'''
# Tue, 08 Dec 2020 15:52:56
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:52:57
pd.read_sql_query(query4_3, conn)
#[Out]#           city       city
#[Out]# 0      Utrecht  Amsterdam
#[Out]# 1      Utrecht      Breda
#[Out]# 2      Utrecht  Rotterdam
#[Out]# 3      Utrecht  Rotterdam
#[Out]# 4      Utrecht  Eindhoven
#[Out]# ...        ...        ...
#[Out]# 12155  Utrecht      Breda
#[Out]# 12156  Utrecht      Breda
#[Out]# 12157  Utrecht      Breda
#[Out]# 12158  Utrecht  Eindhoven
#[Out]# 12159  Utrecht        Oss
#[Out]# 
#[Out]# [12160 rows x 2 columns]
# Tue, 08 Dec 2020 15:56:25
query4_3 = '''
    (SELECT city FROM customer)
    UNION
    (SELECT city FROM store)
'''
# Tue, 08 Dec 2020 15:56:26
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:56:31
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 15:56:41
query4_3 = '''
    (SELECT city 
    FROM customer)
    UNION
    (SELECT city 
    FROM store)
'''
# Tue, 08 Dec 2020 15:56:41
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:56:42
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 15:58:08
query4_3 = '''
    SELECT city
    FROM (
        (SELECT city 
        FROM customer)
        UNION
        (SELECT city 
        FROM store)
        )
'''
# Tue, 08 Dec 2020 15:58:08
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:59:08
query4_3 = '''
    SELECT city 
    FROM customer
'''
# Tue, 08 Dec 2020 15:59:09
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:59:12
pd.read_sql_query(query4_3, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# ..         ...
#[Out]# 185  Eindhoven
#[Out]# 186  Eindhoven
#[Out]# 187  Rotterdam
#[Out]# 188        Oss
#[Out]# 189    Utrecht
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 08 Dec 2020 15:59:20
query4_3 = '''
    SELECT city 
    FROM stor
'''
# Tue, 08 Dec 2020 15:59:22
query4_3 = '''
    SELECT city 
    FROM store
'''
# Tue, 08 Dec 2020 15:59:23
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:59:24
pd.read_sql_query(query4_3, conn)
#[Out]#          city
#[Out]# 0   Amsterdam
#[Out]# 1       Breda
#[Out]# 2   Rotterdam
#[Out]# 3   Rotterdam
#[Out]# 4   Eindhoven
#[Out]# ..        ...
#[Out]# 59      Breda
#[Out]# 60      Breda
#[Out]# 61      Breda
#[Out]# 62  Eindhoven
#[Out]# 63        Oss
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 08 Dec 2020 15:59:57
query4_3 = '''
    (SELECT city 
    FROM customer)
    UNION
    (SELECT city 
    FROM store)
    )
'''
# Tue, 08 Dec 2020 15:59:58
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:00:11
query4_3 = '''
    SELECT city 
    FROM customer)
    UNION
    (SELECT city 
    FROM store)
'''
# Tue, 08 Dec 2020 16:00:12
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:00:25
query4_3 = '''
    SELECT city 
    FROM customer)
    UNION
    SELECT city 
    FROM store
'''
# Tue, 08 Dec 2020 16:00:26
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:00:32
query4_3 = '''
    SELECT city 
    FROM customer
    UNION
    SELECT city 
    FROM store
'''
# Tue, 08 Dec 2020 16:00:32
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:00:36
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 16:00:49
query4_3 = '''
    (SELECT city 
    FROM customer)
    UNION
    SELECT city 
    FROM store
'''
# Tue, 08 Dec 2020 16:00:50
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:00:53
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:01:13
query4_3 = '''
    SELECT city
    FROM 
        SELECT city 
        FROM customer
        UNION
        SELECT city 
        FROM store
'''
# Tue, 08 Dec 2020 16:01:15
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:01:28
query4_3 = '''
    SELECT city
    FROM SELECT city 
        FROM customer
        UNION
        SELECT city 
        FROM store
'''
# Tue, 08 Dec 2020 16:01:30
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:01:39
query4_3 = '''
    SELECT city
    FROM (SELECT city 
        FROM customer
        UNION
        SELECT city 
        FROM store)
'''
# Tue, 08 Dec 2020 16:01:42
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:02:09
query4_3 = '''
    SELECT city 
    FROM customer
    UNION
    SELECT city 
    FROM store
'''
# Tue, 08 Dec 2020 16:02:11
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:02:14
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 16:03:54
query4_3 = '''
    SELECT DISTINCT city 
    FROM store
'''
# Tue, 08 Dec 2020 16:03:54
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:03:57
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Tue, 08 Dec 2020 16:04:08
query4_3 = '''
    SELECT DISTINCT city 
    FROM customer
'''
# Tue, 08 Dec 2020 16:04:08
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:04:12
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Tue, 08 Dec 2020 16:06:43
query4_3 = '''
    SELECT city 
    FROM customer
    UNION ALL
    SELECT city 
    FROM store
'''
# Tue, 08 Dec 2020 16:06:48
pd.read_sql_query(query4_3, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# ..         ...
#[Out]# 249      Breda
#[Out]# 250      Breda
#[Out]# 251      Breda
#[Out]# 252  Eindhoven
#[Out]# 253        Oss
#[Out]# 
#[Out]# [254 rows x 1 columns]
# Tue, 08 Dec 2020 16:06:58
query4_3 = '''
    SELECT city 
    FROM customer
    UNION
    SELECT city 
    FROM store
'''
# Tue, 08 Dec 2020 16:07:06
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 16:29:50
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName
        FROM store,
    cities(city) AS
        SELECT city 
        FROM customer
        UNION
        SELECT city 
        FROM store,
    allPoss(sName, city) AS
        SELECT sName, city
        FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city
        FROM store
    missing(sName) AS
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN
        SELECT *
        FROM 
'''
# Tue, 08 Dec 2020 16:30:54
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName
        FROM store,
    cities(city) AS
        SELECT city 
        FROM customer
        UNION
        SELECT city 
        FROM store,
    allPoss(sName, city) AS
        SELECT sName, city
        FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city
        FROM store
    missing(sName) AS
        SELECT sName
        FROM allPoss
        WHERE sName, city NOT IN allAct
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN
        SELECT *
        FROM missing
'''
# Tue, 08 Dec 2020 16:30:57
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:31:01
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:31:17
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName
        FROM store,
    cities(city) AS
        SELECT city 
        FROM customer
        UNION
        SELECT city 
        FROM store,
    allPoss(sName, city) AS
        SELECT sName, city
        FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city
        FROM store,
    missing(sName) AS
        SELECT sName
        FROM allPoss
        WHERE sName, city NOT IN allAct
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN
        SELECT *
        FROM missing
'''
# Tue, 08 Dec 2020 16:31:18
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:31:19
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:32:08
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        SELECT city FROM customer
        UNION
        SELECT city FROM store,
    allPoss(sName, city) AS
        SELECT sName, city FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city FROM store,
    missing(sName) AS
        SELECT sName FROM allPoss
        WHERE sName, city NOT IN allAct
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN
        SELECT *
        FROM missing
'''
# Tue, 08 Dec 2020 16:32:11
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:32:27
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        SELECT city FROM customer
        UNION
        SELECT city FROM store,
    allPoss(sName, city) AS
        SELECT sName, city FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city FROM store,
    missing(sName) AS
        SELECT sName FROM allPoss
        WHERE sName, city NOT IN allAct
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 16:32:27
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:32:39
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        SELECT city FROM customer
        UNION
        SELECT city FROM store,
    allPoss(sName, city) AS
        SELECT sName, city FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city FROM store,
    missing(sName) AS
        SELECT sName FROM allPoss
        WHERE sName, city NOT IN allAct
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN (sELECT * FROM missing)
'''
# Tue, 08 Dec 2020 16:32:40
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:32:47
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        SELECT city FROM customer
        UNION
        SELECT city FROM store,
    allPoss(sName, city) AS
        SELECT sName, city FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city FROM store,
    missing(sName) AS
        SELECT sName FROM allPoss
        WHERE sName, city NOT IN allAct
    
    sELECT sName, city
    FROM stores
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 16:32:47
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:33:37
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        SELECT city FROM customer
        UNION
        SELECT city FROM store,
    allPoss(sName, city) AS
        SELECT sName, city FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city FROM store,
    missing(sName) AS
        SELECT sName FROM allPoss
        WHERE sName, city NOT IN allAct
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN (SELECT /* FROM missing)
'''
# Tue, 08 Dec 2020 16:33:37
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:34:01
query4_3 = '''
    WITH stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        SELECT city FROM customer
        UNION
        SELECT city FROM store,
    allPoss(sName, city) AS
        SELECT sName, city FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city FROM store,
    missing(sName) AS
        SELECT sName FROM allPoss
        WHERE sName, city NOT IN allAct
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 16:34:02
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:34:53
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        SELECT city FROM customer
        UNION
        SELECT city FROM store,
    SELECT sName, city FROM stores, cities
'''
# Tue, 08 Dec 2020 16:34:56
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:34:57
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:35:26
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        SELECT city FROM customer
        UNION
        SELECT city FROM store
    SELECT sName, city FROM stores, cities
'''
# Tue, 08 Dec 2020 16:35:29
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:35:31
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:36:05
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        SELECT city FROM customer
        UNION
        SELECT city FROM store
    SELECT stores.sName, cities.city FROM stores, cities
'''
# Tue, 08 Dec 2020 16:36:08
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:36:10
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:37:26
query4_3 = '''
    WITH 
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        SELECT sName, city FROM stores, cities,
    allAct(sName, city) AS
        SELECT sName, city FROM store,
    missing(sName) AS
        SELECT sName FROM allPoss
        WHERE sName, city NOT IN allAct
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 16:37:28
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:37:45
query4_3 = '''
    WITH
    stores(sName) AS
        SELECT DISTINCT sName FROM store,
    SELECT sName FROM stores
'''
# Tue, 08 Dec 2020 16:37:48
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:37:49
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:38:00
query4_3 = '''
    WITH stores(sName) AS SELECT DISTINCT sName FROM store,
    SELECT sName FROM stores
'''
# Tue, 08 Dec 2020 16:38:04
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:38:12
query4_3 = '''
    WITH stores(sName) AS (SELECT DISTINCT sName FROM store)
    SELECT sName FROM stores
'''
# Tue, 08 Dec 2020 16:38:15
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:38:19
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 16:38:35
query4_3 = '''
    WITH
    stores(sName) AS (SELECT DISTINCT sName FROM store)
    SELECT sName FROM stores
'''
# Tue, 08 Dec 2020 16:38:38
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:38:46
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store)
    SELECT sName FROM stores
'''
# Tue, 08 Dec 2020 16:38:48
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:38:52
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 16:39:18
query4_3 = '''
    WITH 
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS
        (SELECT sName FROM allPoss
        WHERE sName, city NOT IN allAct)
    
    SELECT sName, city
    FROM stores
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 16:39:21
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:39:53
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store)
    SELECT sName, city FROM stores, cities
'''
# Tue, 08 Dec 2020 16:39:55
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:39:58
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Tue, 08 Dec 2020 16:41:12
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store)
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
    SELECT sName FROM allPoss
    WHERE sName, city NOT IN allAct
'''
# Tue, 08 Dec 2020 16:41:15
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:41:31
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store)
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
    SELECT sName FROM allPoss
    WHERE (sName, city) NOT IN allAct
'''
# Tue, 08 Dec 2020 16:41:33
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:41:45
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
    SELECT sName FROM allPoss
    WHERE (sName, city) NOT IN allAct
'''
# Tue, 08 Dec 2020 16:41:47
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:42:13
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
    SELECT sName FROM .allPoss
    WHERE (sName, city) NOT IN allAct
'''
# Tue, 08 Dec 2020 16:42:16
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:42:37
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
    SELECT sName FROM allPoss
    WHERE (sName, city) NOT IN (allAct)
'''
# Tue, 08 Dec 2020 16:42:39
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:42:47
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:43:34
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
    SELECT sName FROM allPoss
    WHERE sName, city NOT IN allAct
'''
# Tue, 08 Dec 2020 16:43:36
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:43:58
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
    SELECT sName FROM allPoss
    WHERE (sName, city) NOT IN allAct
'''
# Tue, 08 Dec 2020 16:44:00
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:44:57
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName FROM allPoss
    WHERE (sName, city) NOT IN allAct
'''
# Tue, 08 Dec 2020 16:45:00
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:46:23
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    SELECT sName, city FROM store
'''
# Tue, 08 Dec 2020 16:46:25
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:46:34
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities)
    
    SELECT sName, city FROM store
'''
# Tue, 08 Dec 2020 16:46:36
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities)
    
    SELECT sName, city FROM store
'''
# Tue, 08 Dec 2020 16:46:38
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:46:43
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 16:47:26
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName FROM allPoss
    WHERE (sName, city) IN allAct
'''
# Tue, 08 Dec 2020 16:47:29
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:48:01
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName FROM allPoss
    WHERE (sName, city) NOT IN (SELECT * FROM allAct)
'''
# Tue, 08 Dec 2020 16:48:03
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:48:08
pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1          Coop
#[Out]# 2     Hoogvliet
#[Out]# 3     Hoogvliet
#[Out]# 4     Hoogvliet
#[Out]# 5         Jumbo
#[Out]# 6         Jumbo
#[Out]# 7        Sligro
#[Out]# 8        Sligro
#[Out]# 9   Albert Hein
#[Out]# 10  Albert Hein
#[Out]# 11         Lidl
#[Out]# 12         Lidl
#[Out]# 13         Dirk
#[Out]# 14         Dirk
#[Out]# 15         Dirk
#[Out]# 16         Dirk
# Tue, 08 Dec 2020 16:48:13
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:48:17
pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1          Coop
#[Out]# 2     Hoogvliet
#[Out]# 3     Hoogvliet
#[Out]# 4     Hoogvliet
#[Out]# 5         Jumbo
#[Out]# 6         Jumbo
#[Out]# 7        Sligro
#[Out]# 8        Sligro
#[Out]# 9   Albert Hein
#[Out]# 10  Albert Hein
#[Out]# 11         Lidl
#[Out]# 12         Lidl
#[Out]# 13         Dirk
#[Out]# 14         Dirk
#[Out]# 15         Dirk
#[Out]# 16         Dirk
# Tue, 08 Dec 2020 16:48:28
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName FROM allPoss
    WHERE (sName, city) NOT IN (SELECT sName, city FROM allAct)
'''
# Tue, 08 Dec 2020 16:48:32
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:48:50
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT allPoss.sName FROM allPoss
    WHERE (sName, city) NOT IN (SELECT sName, city FROM allAct)
'''
# Tue, 08 Dec 2020 16:48:55
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:52:26
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
    
    SELECT sName, city FROM allAct
    '''
# Tue, 08 Dec 2020 16:52:29
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:52:32
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 16:53:05
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName FROM allPoss
'''
# Tue, 08 Dec 2020 16:53:08
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:53:13
pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1          Coop
#[Out]# 2          Coop
#[Out]# 3          Coop
#[Out]# 4          Coop
#[Out]# 5          Coop
#[Out]# 6          Coop
#[Out]# 7     Hoogvliet
#[Out]# 8     Hoogvliet
#[Out]# 9     Hoogvliet
#[Out]# 10    Hoogvliet
#[Out]# 11    Hoogvliet
#[Out]# 12    Hoogvliet
#[Out]# 13    Hoogvliet
#[Out]# 14        Jumbo
#[Out]# 15        Jumbo
#[Out]# 16        Jumbo
#[Out]# 17        Jumbo
#[Out]# 18        Jumbo
#[Out]# 19        Jumbo
#[Out]# 20        Jumbo
#[Out]# 21       Sligro
#[Out]# 22       Sligro
#[Out]# 23       Sligro
#[Out]# 24       Sligro
#[Out]# 25       Sligro
#[Out]# 26       Sligro
#[Out]# 27       Sligro
#[Out]# 28  Albert Hein
#[Out]# 29  Albert Hein
#[Out]# 30  Albert Hein
#[Out]# 31  Albert Hein
#[Out]# 32  Albert Hein
#[Out]# 33  Albert Hein
#[Out]# 34  Albert Hein
#[Out]# 35         Lidl
#[Out]# 36         Lidl
#[Out]# 37         Lidl
#[Out]# 38         Lidl
#[Out]# 39         Lidl
#[Out]# 40         Lidl
#[Out]# 41         Lidl
#[Out]# 42         Dirk
#[Out]# 43         Dirk
#[Out]# 44         Dirk
#[Out]# 45         Dirk
#[Out]# 46         Dirk
#[Out]# 47         Dirk
#[Out]# 48         Dirk
# Tue, 08 Dec 2020 16:53:59
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName
    FROM allPoss
    WHERE (sName, city) NOT IN (SELECT sName, city FROM allAct)
'''
# Tue, 08 Dec 2020 16:54:01
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:54:20
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName
    FROM allPoss
    WHERE (sName, city) NOT IN (allAct)
'''
# Tue, 08 Dec 2020 16:54:23
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:57:05
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName
    FROM allPoss
    WHERE (sName, city) NOT IN (SELECT sName, city FROM store)
'''
# Tue, 08 Dec 2020 16:57:07
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:57:13
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName
    FROM allPoss
    WHERE (sName, city) NOT IN SELECT sName, city FROM store
'''
# Tue, 08 Dec 2020 16:57:16
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:57:36
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName
    FROM allPoss
    WHERE (sName, city) NOT IN (SELECT sName, city FROM store)
'''
# Tue, 08 Dec 2020 16:57:38
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:57:43
pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1          Coop
#[Out]# 2     Hoogvliet
#[Out]# 3     Hoogvliet
#[Out]# 4     Hoogvliet
#[Out]# 5         Jumbo
#[Out]# 6         Jumbo
#[Out]# 7        Sligro
#[Out]# 8        Sligro
#[Out]# 9   Albert Hein
#[Out]# 10  Albert Hein
#[Out]# 11         Lidl
#[Out]# 12         Lidl
#[Out]# 13         Dirk
#[Out]# 14         Dirk
#[Out]# 15         Dirk
#[Out]# 16         Dirk
# Tue, 08 Dec 2020 16:58:07
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName
    FROM allPoss
    WHERE (sName, city) NOT IN (SELECT sName, city FROM allAct)
'''
# Tue, 08 Dec 2020 16:58:09
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:58:12
pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1          Coop
#[Out]# 2     Hoogvliet
#[Out]# 3     Hoogvliet
#[Out]# 4     Hoogvliet
#[Out]# 5         Jumbo
#[Out]# 6         Jumbo
#[Out]# 7        Sligro
#[Out]# 8        Sligro
#[Out]# 9   Albert Hein
#[Out]# 10  Albert Hein
#[Out]# 11         Lidl
#[Out]# 12         Lidl
#[Out]# 13         Dirk
#[Out]# 14         Dirk
#[Out]# 15         Dirk
#[Out]# 16         Dirk
# Tue, 08 Dec 2020 16:58:27
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName
    FROM allPoss
    WHERE (sName, city) NOT IN (allAct)
'''
# Tue, 08 Dec 2020 16:58:30
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 16:58:33
pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:59:13
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store)
        
    SELECT sName
    FROM allPoss
    WHERE (sName, city) NOT IN (SELECT * FROM allAct)
'''
# Tue, 08 Dec 2020 16:59:17
pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1          Coop
#[Out]# 2     Hoogvliet
#[Out]# 3     Hoogvliet
#[Out]# 4     Hoogvliet
#[Out]# 5         Jumbo
#[Out]# 6         Jumbo
#[Out]# 7        Sligro
#[Out]# 8        Sligro
#[Out]# 9   Albert Hein
#[Out]# 10  Albert Hein
#[Out]# 11         Lidl
#[Out]# 12         Lidl
#[Out]# 13         Dirk
#[Out]# 14         Dirk
#[Out]# 15         Dirk
#[Out]# 16         Dirk
# Tue, 08 Dec 2020 17:00:21
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS 
        (SELECT sName FROM allPoss
        WHERE (sName, city) NOT IN (SELECT * FROM allAct))
        
    SELECT sName, city
    FROM store
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 17:00:24
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:01:03
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS 
        (SELECT sName FROM allPoss
        WHERE (sName, city) NOT IN (SELECT * FROM allAct))
        
    SELECT sName
    FROM stores
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 17:01:06
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:01:16
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS 
        (SELECT sName FROM allPoss
        WHERE (sName, city) NOT IN (SELECT * FROM allAct))
        
    SELECT sName, city
    FROM store
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 17:01:20
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:01:36
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS 
        (SELECT sName FROM allPoss
        WHERE (sName, city) NOT IN (SELECT * FROM allAct))
        
    SELECT sName, city
    FROM store
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 17:01:40
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:01:46
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS 
        (SELECT sName FROM allPoss
        WHERE (sName, city) NOT IN (SELECT * FROM allAct))
        
    SELECT sName, city
    FROM store
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 17:02:12
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS 
        (SELECT sName FROM allPoss
        WHERE (sName, city) NOT IN (SELECT * FROM allAct))
        
    SELECT sName, city
    FROM store
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 17:02:15
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:04:38
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS 
        (SELECT sName FROM allPoss
        WHERE (sName, city) NOT IN (SELECT * FROM allAct))
        
    SELECT sName, city
    FROM store
    WHERE sName IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 17:04:40
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 17:05:10
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS 
        (SELECT sName FROM allPoss
        WHERE (sName, city) NOT IN (SELECT * FROM allAct))
        
    SELECT DISTINCT sName, city
    FROM store
    WHERE sName IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 17:05:13
pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Tue, 08 Dec 2020 17:05:31
query4_3 = '''
    WITH
    stores(sName) AS
        (SELECT DISTINCT sName FROM store),
    cities(city) AS
        (SELECT city FROM customer
        UNION
        SELECT city FROM store),
    allPoss(sName, city) AS
        (SELECT sName, city FROM stores, cities),
    allAct(sName, city) AS
        (SELECT sName, city FROM store),
    missing(sName) AS 
        (SELECT sName FROM allPoss
        WHERE (sName, city) NOT IN (SELECT * FROM allAct))
        
    SELECT sName, city
    FROM store
    WHERE sName NOT IN (SELECT * FROM missing)
'''
# Tue, 08 Dec 2020 17:05:33
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:06:10
query4_4 = '''
    SELECT sName, city FROM store
'''
# Tue, 08 Dec 2020 17:06:12
pd.read_sql_query(query4_4, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 17:06:20
query4_4 = '''
    SELECT DISTINCT sName, city FROM store
'''
# Tue, 08 Dec 2020 17:06:22
pd.read_sql_query(query4_4, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Tue, 08 Dec 2020 17:06:41
query4_4 = '''
    SELECT DISTINCT sName, city FROM store
    WHERE sName = "Coop"
'''
# Tue, 08 Dec 2020 17:06:43
pd.read_sql_query(query4_4, conn)
#[Out]#   sName       city
#[Out]# 0  Coop  Amsterdam
#[Out]# 1  Coop  Rotterdam
#[Out]# 2  Coop    Tilburg
#[Out]# 3  Coop      Breda
#[Out]# 4  Coop    Utrecht
# Tue, 08 Dec 2020 17:06:49
query4_4 = '''
    SELECT DISTINCT sName, city FROM store
    WHERE sName = "Jumbo"
'''
# Tue, 08 Dec 2020 17:06:50
pd.read_sql_query(query4_4, conn)
#[Out]#    sName       city
#[Out]# 0  Jumbo  Rotterdam
#[Out]# 1  Jumbo    Tilburg
#[Out]# 2  Jumbo  Eindhoven
#[Out]# 3  Jumbo      Breda
#[Out]# 4  Jumbo        Oss
# Tue, 08 Dec 2020 17:06:56
query4_4 = '''
    SELECT DISTINCT sName, city FROM store
    WHERE sName = "Dirk"
'''
# Tue, 08 Dec 2020 17:06:58
pd.read_sql_query(query4_4, conn)
#[Out]#   sName       city
#[Out]# 0  Dirk      Breda
#[Out]# 1  Dirk  Eindhoven
#[Out]# 2  Dirk  Rotterdam
# Tue, 08 Dec 2020 17:07:18
query4_4 = '''
    SELECT DISTINCT city FROM store
'''
# Tue, 08 Dec 2020 17:07:20
pd.read_sql_query(query4_4, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Tue, 08 Dec 2020 17:07:39
query4_4 = '''
    SELECT DISTINCT sName, city FROM store
    WHERE city = "Oss"
'''
# Tue, 08 Dec 2020 17:07:42
pd.read_sql_query(query4_4, conn)
#[Out]#    sName city
#[Out]# 0  Jumbo  Oss
# Tue, 08 Dec 2020 17:07:47
query4_4 = '''
    SELECT DISTINCT sName, city FROM store
    WHERE city = "Amsterdam"
'''
# Tue, 08 Dec 2020 17:07:49
pd.read_sql_query(query4_4, conn)
#[Out]#     sName       city
#[Out]# 0    Coop  Amsterdam
#[Out]# 1    Lidl  Amsterdam
#[Out]# 2  Sligro  Amsterdam
# Tue, 08 Dec 2020 17:07:55
query4_4 = '''
    SELECT DISTINCT sName, city FROM store
    WHERE city = "Eindhoven"
'''
# Tue, 08 Dec 2020 17:07:59
pd.read_sql_query(query4_4, conn)
#[Out]#          sName       city
#[Out]# 0    Hoogvliet  Eindhoven
#[Out]# 1       Sligro  Eindhoven
#[Out]# 2  Albert Hein  Eindhoven
#[Out]# 3         Lidl  Eindhoven
#[Out]# 4         Dirk  Eindhoven
#[Out]# 5        Jumbo  Eindhoven
# Tue, 08 Dec 2020 20:21:24
query4_4 = '''
    WITH
    maxAmountPerCust AS
    maxAmountEver AS 
        (SELECT max(amount) from )
    
    SELECT cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID AND maxAmountPerCust >= 0.75 * maxAmountEver
'''
# Tue, 08 Dec 2020 20:39:37
query4_4 = '''
    SELECT sum(cID) FROM purchase
            GROUP_BY cID, date
'''
# Tue, 08 Dec 2020 20:39:39
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:39:41
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 20:39:55
query4_4 = '''
    SELECT sum(cID) 
    FROM purchase
    GROUP cID, date
'''
# Tue, 08 Dec 2020 20:39:56
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:40:01
query4_4 = '''
    SELECT sum(cID) 
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:40:02
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:40:06
pd.read_sql_query(query4_4, conn)
#[Out]#      sum(cID)
#[Out]# 0           0
#[Out]# 1           5
#[Out]# 2           2
#[Out]# 3           2
#[Out]# 4           8
#[Out]# ..        ...
#[Out]# 280      1140
#[Out]# 281       380
#[Out]# 282       570
#[Out]# 283      1330
#[Out]# 284       380
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Tue, 08 Dec 2020 20:40:39
query4_4 = '''
    SELECT cID, date 
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:40:40
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:40:51
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date
#[Out]# 0      0  2018-08-22
#[Out]# 1      1  2018-08-20
#[Out]# 2      1  2018-08-21
#[Out]# 3      2  2018-08-16
#[Out]# 4      2  2018-08-17
#[Out]# ..   ...         ...
#[Out]# 280  190  2018-08-23
#[Out]# 281  190  2018-08-24
#[Out]# 282  190  2018-08-25
#[Out]# 283  190  2018-08-26
#[Out]# 284  190  2018-08-27
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 20:41:13
query4_4 = '''
    SELECT cID, date, sum(price)
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:41:13
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:41:20
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sum(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 20:42:03
query4_4 = '''
    SELECT max(price)
    SELECT cID, date, sum(price) as sum
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:42:08
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 20:42:31
query4_4 = '''
    SELECT max(sumPrice)
    SELECT cID, date, sum(price) as sumPrice
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:42:39
query4_4 = '''
    SELECT max(sumPrice)
    FROM
    SELECT cID, date, sum(price) as sumPrice
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:42:43
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 20:42:50
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:43:20
query4_4 = '''
    
    SELECT cID, date, sum(price) as sumPrice
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:43:21
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sumPrice
#[Out]# 0      0  2018-08-22      0.45
#[Out]# 1      1  2018-08-20     14.20
#[Out]# 2      1  2018-08-21     10.00
#[Out]# 3      2  2018-08-16      2.45
#[Out]# 4      2  2018-08-17      7.70
#[Out]# ..   ...         ...       ...
#[Out]# 280  190  2018-08-23     10.60
#[Out]# 281  190  2018-08-24      3.25
#[Out]# 282  190  2018-08-25      9.80
#[Out]# 283  190  2018-08-26     21.90
#[Out]# 284  190  2018-08-27      5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 20:43:37
query4_4 = '''
    SELECT max(sumPrice)
    FROM SELECT cID, date, sum(price) as sumPrice
        FROM purchase
        GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:43:39
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 20:43:41
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:45:12
query4_4 = '''
    max(
    SELECT cID, date, SUM(price) as sumPrice
    FROM purchase
    GROUP BY cID, date)
'''
# Tue, 08 Dec 2020 20:45:13
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:45:43
query4_4 = '''
    SELECT cID, date, price
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:45:45
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:45:54
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   4.65
#[Out]# 2      1  2018-08-21   0.90
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   1.35
#[Out]# ..   ...         ...    ...
#[Out]# 280  190  2018-08-23   0.50
#[Out]# 281  190  2018-08-24   2.55
#[Out]# 282  190  2018-08-25   3.70
#[Out]# 283  190  2018-08-26   1.30
#[Out]# 284  190  2018-08-27   1.20
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 20:46:23
query4_4 = '''
    SELECT cID, date, price
    FROM purchase
    
'''
# Tue, 08 Dec 2020 20:46:25
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   4.65
#[Out]# 2      1  2018-08-20   1.60
#[Out]# 3      1  2018-08-20   1.25
#[Out]# 4      1  2018-08-20   3.95
#[Out]# ..   ...         ...    ...
#[Out]# 504  190  2018-08-26   3.80
#[Out]# 505  190  2018-08-27   4.35
#[Out]# 506  190  2018-08-23   2.85
#[Out]# 507  190  2018-08-16   3.15
#[Out]# 508  190  2018-08-21   3.30
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 08 Dec 2020 20:46:49
query4_4 = '''
    SELECT cID, date, price
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:46:53
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   4.65
#[Out]# 2      1  2018-08-21   0.90
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   1.35
#[Out]# ..   ...         ...    ...
#[Out]# 280  190  2018-08-23   0.50
#[Out]# 281  190  2018-08-24   2.55
#[Out]# 282  190  2018-08-25   3.70
#[Out]# 283  190  2018-08-26   1.30
#[Out]# 284  190  2018-08-27   1.20
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 20:47:01
query4_4 = '''
    SELECT cID, date, SUM(price) as sumPrice
    FROM purchase
    GROUP BY cID, date
'''
# Tue, 08 Dec 2020 20:47:03
pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sumPrice
#[Out]# 0      0  2018-08-22      0.45
#[Out]# 1      1  2018-08-20     14.20
#[Out]# 2      1  2018-08-21     10.00
#[Out]# 3      2  2018-08-16      2.45
#[Out]# 4      2  2018-08-17      7.70
#[Out]# ..   ...         ...       ...
#[Out]# 280  190  2018-08-23     10.60
#[Out]# 281  190  2018-08-24      3.25
#[Out]# 282  190  2018-08-25      9.80
#[Out]# 283  190  2018-08-26     21.90
#[Out]# 284  190  2018-08-27      5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 20:47:25
query4_4 = '''
    SELECT MAX(sumPrice)
    FROM(
    SELECT cID, date, SUM(price) as sumPrice
    FROM purchase
    GROUP BY cID, date)
'''
# Tue, 08 Dec 2020 20:47:27
pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sumPrice)
#[Out]# 0           39.1
# Tue, 08 Dec 2020 20:50:21
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver AS 
        (SELECT MAX(sumPrice) FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID AND maxAmountPerCust >= 0.75 * maxAmountEver
'''
# Tue, 08 Dec 2020 20:50:43
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date)
    SELECT MAX(sumPrice) FROM amountPerDayPerCust
'''
# Tue, 08 Dec 2020 20:50:45
pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sumPrice)
#[Out]# 0           39.1
# Tue, 08 Dec 2020 20:50:55
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver AS 
        (SELECT MAX(sumPrice) FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID AND maxAmountPerCust >= 0.75 * maxAmountEver
'''
# Tue, 08 Dec 2020 20:50:57
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 20:51:11
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver AS 
        (SELECT MAX(sumPrice) FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID AND amountPerDayPerCust >= 0.75 * maxAmountEver
'''
# Tue, 08 Dec 2020 20:51:13
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 20:53:15
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date)
    SELECT MAX(sumPrice) FROM amountPerDayPerCust
'''
# Tue, 08 Dec 2020 20:53:17
pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sumPrice)
#[Out]# 0           39.1
# Tue, 08 Dec 2020 20:53:52
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) as sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID AND amountPerDayPerCust >= 0.75 * (SELECT maximum FROM maxAmountEver)
'''
# Tue, 08 Dec 2020 20:53:54
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 20:54:34
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID AND amountPerDayPerCust >= 0.75 * (SELECT maximum FROM maxAmountEver)
'''
# Tue, 08 Dec 2020 20:54:36
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 20:55:13
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    SELECT maximum FROM maxAmountEve
'''
# Tue, 08 Dec 2020 20:55:16
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    SELECT maximum FROM maxAmountEver
'''
# Tue, 08 Dec 2020 20:55:18
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 20:55:49
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:59:53
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    SELECT maximum
    FROM maxAmountEver
'''
# Tue, 08 Dec 2020 20:59:54
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 20:59:59
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    SELECT maximum FROM maxAmountEver
'''
# Tue, 08 Dec 2020 20:59:59
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 21:00:07
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
        
    SELECT maximum FROM maxAmountEver
'''
# Tue, 08 Dec 2020 21:00:07
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 21:00:14
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
        
    SELECT maximum FROM MaxAmountEver
'''
# Tue, 08 Dec 2020 21:00:15
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 21:00:25
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
        
    SELECT Maximum FROM maxAmountEver
'''
# Tue, 08 Dec 2020 21:00:26
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 21:00:35
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) FROM amountPerDayPerCust)
        
    SELECT maximum FROM maxAmountEver
'''
# Tue, 08 Dec 2020 21:00:36
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 21:01:03
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(test) AS 
        (SELECT MAX(sumPrice) FROM amountPerDayPerCust)
        
    SELECT maximum FROM maxAmountEver
'''
# Tue, 08 Dec 2020 21:01:03
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 21:01:08
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date)
    maxAmountEver(test) AS 
        (SELECT MAX(sumPrice) FROM amountPerDayPerCust)
        
    SELECT test FROM maxAmountEver
'''
# Tue, 08 Dec 2020 21:01:09
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 21:01:28
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date),
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) FROM amountPerDayPerCust)
        
    SELECT maximum FROM maxAmountEver
'''
# Tue, 08 Dec 2020 21:01:29
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 21:01:35
pd.read_sql_query(query4_4, conn)
#[Out]#    maximum
#[Out]# 0     39.1
# Tue, 08 Dec 2020 21:01:40
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date),
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, purchase p
    WHERE c.cID = p.cID AND amountPerDayPerCust >= 0.75 * (SELECT maximum FROM maxAmountEver)
'''
# Tue, 08 Dec 2020 21:01:44
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 21:03:03
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date),
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, amountPerDayPerCust am
    WHERE c.cID = am.cID AND am.sumPrice >= 0.75 * (SELECT maximum FROM maxAmountEver)
'''
# Tue, 08 Dec 2020 21:03:05
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 21:03:07
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 21:04:43
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date),
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, amountPerDayPerCust am
    WHERE c.cID = am.cID AND am.sumPrice >= 0.5 * (SELECT maximum FROM maxAmountEver)
'''
# Tue, 08 Dec 2020 21:04:47
pd.read_sql_query(query4_4, conn)
#[Out]#     cName
#[Out]# 0    Luca
#[Out]# 1    Dean
#[Out]# 2   Dylan
#[Out]# 3    Noor
#[Out]# 4   Milou
#[Out]# 5   Sofie
#[Out]# 6   Floor
#[Out]# 7  Kostas
#[Out]# 8  Kostas
#[Out]# 9  Kostas
# Tue, 08 Dec 2020 21:04:55
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date),
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, amountPerDayPerCust am
    WHERE c.cID = am.cID AND am.sumPrice >= 0.75 * (SELECT maximum FROM maxAmountEver)
'''
# Tue, 08 Dec 2020 21:04:56
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 21:09:47
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date),
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, amountPerDayPerCust am
    WHERE c.cID = am.cID AND am.sumPrice >= 0.25 * (SELECT maximum FROM maxAmountEver)
'''
# Tue, 08 Dec 2020 21:09:50
pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0       Sem
#[Out]# 1       Sem
#[Out]# 2      Daan
#[Out]# 3      Daan
#[Out]# 4      Bram
#[Out]# 5     James
#[Out]# 6    Julian
#[Out]# 7      Gijs
#[Out]# 8      Luca
#[Out]# 9      Teun
#[Out]# 10     Sven
#[Out]# 11    Stijn
#[Out]# 12     Jack
#[Out]# 13     Jack
#[Out]# 14     Jens
#[Out]# 15     Ties
#[Out]# 16   Willem
#[Out]# 17     Joep
#[Out]# 18      Kai
#[Out]# 19     Dean
#[Out]# 20     Jace
#[Out]# 21    Dylan
#[Out]# 22    Dylan
#[Out]# 23     Stef
#[Out]# 24  Thijmen
#[Out]# 25    Jelte
#[Out]# 26     Emma
#[Out]# 27    Lotte
#[Out]# 28     Noor
#[Out]# 29     Lynn
#[Out]# 30     Lynn
#[Out]# 31    Fenna
#[Out]# 32    Fenna
#[Out]# 33    Lieke
#[Out]# 34    Milou
#[Out]# 35    Sofie
#[Out]# 36      Ivy
#[Out]# 37    Fenne
#[Out]# 38    Floor
#[Out]# 39    Elena
#[Out]# 40    Elena
#[Out]# 41     Iris
#[Out]# 42     Juul
#[Out]# 43  Johanna
#[Out]# 44   Kostas
#[Out]# 45   Kostas
#[Out]# 46   Kostas
#[Out]# 47   Kostas
#[Out]# 48   Kostas
#[Out]# 49   Kostas
#[Out]# 50   Kostas
#[Out]# 51   Kostas
#[Out]# 52   Kostas
#[Out]# 53   Kostas
# Tue, 08 Dec 2020 21:10:00
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date),
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, amountPerDayPerCust am
    WHERE c.cID = am.cID AND am.sumPrice >= 0.65 * (SELECT maximum FROM maxAmountEver)
'''
# Tue, 08 Dec 2020 21:10:03
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Sofie
#[Out]# 1  Floor
# Tue, 08 Dec 2020 21:10:11
query4_4 = '''
    WITH
    amountPerDayPerCust(cID, date, sumPrice) AS
        (SELECT cID, date, SUM(price) AS sumPrice
        FROM purchase
        GROUP BY cID, date),
    maxAmountEver(maximum) AS 
        (SELECT MAX(sumPrice) AS maximum FROM amountPerDayPerCust)
    
    SELECT cName
    FROM customer c, amountPerDayPerCust am
    WHERE c.cID = am.cID AND am.sumPrice >= 0.75 * (SELECT maximum FROM maxAmountEver)
'''
# Tue, 08 Dec 2020 21:10:15
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 21:13:19
query4_5 = '''
    SELECT COUNT(c.cID), c.city
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
    GROUP BY c.city
'''
# Tue, 08 Dec 2020 21:13:20
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 21:13:27
pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(c.cID)       city
#[Out]# 0            17  Amsterdam
#[Out]# 1            27      Breda
#[Out]# 2            24  Eindhoven
#[Out]# 3            16  Rotterdam
#[Out]# 4            18    Tilburg
#[Out]# 5            31    Utrecht
# Tue, 08 Dec 2020 21:16:34
query4_5 = '''
    SELECT COUNT(DISTINCT c.cID), c.city
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = 'Eindhoven'
    GROUP BY c.city
'''
# Tue, 08 Dec 2020 21:16:35
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 21:16:40
pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(DISTINCT c.cID)       city
#[Out]# 0                     10  Amsterdam
#[Out]# 1                      9      Breda
#[Out]# 2                     15  Eindhoven
#[Out]# 3                     13  Rotterdam
#[Out]# 4                     10    Tilburg
#[Out]# 5                     12    Utrecht


# IPython log file

# Wed, 09 Dec 2020 11:04:33
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 11:04:42
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1816230fb20>
# Wed, 09 Dec 2020 11:18:12
query4_3 = '''
    with allCustCity(city) as (select distinct city from customer)
         allStoreCity(city) as (select distinct city from store)
         sNameNotInAll(sName) as (select s.sName
                                  from store s, allStoreCity asc, allCustCity acc
                                  where s.city not in asc.city or s.city not in acc.city)
    select sName
    from store s2, sNameNotInAll del
    where s2.sName not in del
'''
# Wed, 09 Dec 2020 11:18:12
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 11:19:40
schema = vis.schema_from_conn(conn)
# Wed, 09 Dec 2020 11:19:43
query4_3 = '''
    with allCustCity(city) as (select distinct city from customer)
         allStoreCity(city) as (select distinct city from store)
         sNameNotInAll(sName) as (select s.sName
                                  from store s, allStoreCity asc, allCustCity acc
                                  where s.city not in asc.city or s.city not in acc.city)
    select sName
    from store s2, sNameNotInAll del
    where s2.sName not in del
'''
# Wed, 09 Dec 2020 11:19:44
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 11:21:23
query4_3 = '''
    WITH allCustCity(city) AS (SELECT DISTINCT city FROM customer)
         allStoreCity(city) AS (SELECT DISTINCT city FROM store)
         sNameNotInAll(sName) AS (SELECT s.sName
                                  FROM store s, allStoreCity asc, allCustCity acc
                                  WHERE s.city NOT IN asc.city OR s.city NOT IN acc.city)
    SELECT sName
    FROM store s2, sNameNotInAll del
    WHERE s2.sName not in del.sName
'''
# Wed, 09 Dec 2020 11:21:23
vis.visualize(query4_3, schema)
# Wed, 09 Dec 2020 11:21:35
pd.read_sql_query(query4_3, conn)

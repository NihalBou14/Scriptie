# IPython log file

# Wed, 09 Dec 2020 11:21:03
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 11:21:04
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1b481e96c70>
# Wed, 09 Dec 2020 11:30:48
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities)
SELECT *
FROM all_cities
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 11:33:08
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac)
SELECT *
FROM all_cities
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 11:33:15
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac)
SELECT *
FROM all_possible
'''

pd.read_sql_query(query4_3, conn)
#[Out]#      sName       city
#[Out]# 0     Coop  Amsterdam
#[Out]# 1     Coop      Breda
#[Out]# 2     Coop  Eindhoven
#[Out]# 3     Coop        Oss
#[Out]# 4     Coop  Rotterdam
#[Out]# ..     ...        ...
#[Out]# 443  Jumbo  Eindhoven
#[Out]# 444  Jumbo        Oss
#[Out]# 445  Jumbo  Rotterdam
#[Out]# 446  Jumbo    Tilburg
#[Out]# 447  Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Wed, 09 Dec 2020 11:33:53
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store)
SELECT *
FROM actual
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 11:38:59
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT sName
FROM store
WHERE sName NOT IN missing
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:39:20
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT sName
FROM store
WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:39:29
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT sName
FROM missing
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1         Coop
#[Out]# 2    Hoogvliet
#[Out]# 3    Hoogvliet
#[Out]# 4    Hoogvliet
#[Out]# ..         ...
#[Out]# 144       Lidl
#[Out]# 145      Jumbo
#[Out]# 146      Jumbo
#[Out]# 147      Jumbo
#[Out]# 148      Jumbo
#[Out]# 
#[Out]# [149 rows x 1 columns]
# Wed, 09 Dec 2020 11:40:25
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT sName
FROM store
WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:42:11
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM all_cities;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 11:42:43
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM actual;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 11:43:06
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT DISTINCT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Wed, 09 Dec 2020 11:43:23
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT DISTINCT sName, city FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:43:39
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName, city FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:44:12
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName, city FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:44:18
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sNameFROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:44:23
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1         Coop
#[Out]# 2    Hoogvliet
#[Out]# 3    Hoogvliet
#[Out]# 4    Hoogvliet
#[Out]# ..         ...
#[Out]# 144       Lidl
#[Out]# 145      Jumbo
#[Out]# 146      Jumbo
#[Out]# 147      Jumbo
#[Out]# 148      Jumbo
#[Out]# 
#[Out]# [149 rows x 1 columns]
# Wed, 09 Dec 2020 11:44:28
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName, city FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:44:42
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName,city FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:44:45
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName, city FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:44:47
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1         Coop
#[Out]# 2    Hoogvliet
#[Out]# 3    Hoogvliet
#[Out]# 4    Hoogvliet
#[Out]# ..         ...
#[Out]# 144       Lidl
#[Out]# 145      Jumbo
#[Out]# 146      Jumbo
#[Out]# 147      Jumbo
#[Out]# 148      Jumbo
#[Out]# 
#[Out]# [149 rows x 1 columns]
# Wed, 09 Dec 2020 11:44:57
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT city FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0    Eindhoven
#[Out]# 1          Oss
#[Out]# 2    Amsterdam
#[Out]# 3          Oss
#[Out]# 4      Utrecht
#[Out]# ..         ...
#[Out]# 144    Tilburg
#[Out]# 145  Amsterdam
#[Out]# 146    Utrecht
#[Out]# 147  Amsterdam
#[Out]# 148    Utrecht
#[Out]# 
#[Out]# [149 rows x 1 columns]
# Wed, 09 Dec 2020 11:45:09
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName, city) AS (SELECT sName, city FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT *
FROM missing;
--WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city
#[Out]# 0         Coop  Eindhoven
#[Out]# 1         Coop        Oss
#[Out]# 2    Hoogvliet  Amsterdam
#[Out]# 3    Hoogvliet        Oss
#[Out]# 4    Hoogvliet    Utrecht
#[Out]# ..         ...        ...
#[Out]# 144       Lidl    Tilburg
#[Out]# 145      Jumbo  Amsterdam
#[Out]# 146      Jumbo    Utrecht
#[Out]# 147      Jumbo  Amsterdam
#[Out]# 148      Jumbo    Utrecht
#[Out]# 
#[Out]# [149 rows x 2 columns]
# Wed, 09 Dec 2020 11:46:20
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT sName
FROM store;
WHERE sName NOT IN (SELECT * FROM missing)
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:46:34
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT sName
FROM store
WHERE sName NOT IN (SELECT * FROM missing);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:00:48
query4_4 = '''
WITH max_spending(amount) AS (SELECT 
                              FROM purchase
                              GROUP BY cID,date
                              HAVING sum(quantity * price))
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:01:33
query4_4 = '''
WITH max_spending(amount) AS (SELECT cID, date, amt
                              FROM purchase
                              GROUP BY cID, date
                              HAVING sum(quantity * price) as amt)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:04:16
query4_4 = '''
WITH max_spending(amount) AS (SELECT cID, date, amt
                              FROM purchase
                              GROUP BY cID, date
                              HAVING sum(quantity * price) AS amt)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:04:51
query4_4 = '''
WITH max_spending(amount) AS (SELECT cID, date, sum(quantity * price)
                              FROM purchase
                              GROUP BY cID, date)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:05:04
query4_4 = '''
WITH max_spending(amount) AS (SELECT cID, date
                              FROM purchase
                              GROUP BY cID, date)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:05:26
query4_4 = '''
WITH max_spending(cID, date, total) AS (SELECT cID, date, sum(quantity * price)
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  total
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  43.40
#[Out]# 2      1  2018-08-21  61.80
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17  32.40
#[Out]# ..   ...         ...    ...
#[Out]# 280  190  2018-08-23  52.85
#[Out]# 281  190  2018-08-24  18.10
#[Out]# 282  190  2018-08-25  46.20
#[Out]# 283  190  2018-08-26  89.55
#[Out]# 284  190  2018-08-27  32.10
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:06:35
query4_4 = '''
WITH max_spending(cID, date, total) AS (SELECT cID, date, total
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:06:46
query4_4 = '''
WITH max_spending(cID, date, total) AS (SELECT cID, date, quantity*price
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  total
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20   9.30
#[Out]# 2      1  2018-08-21   7.20
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   9.45
#[Out]# ..   ...         ...    ...
#[Out]# 280  190  2018-08-23   2.50
#[Out]# 281  190  2018-08-24  15.30
#[Out]# 282  190  2018-08-25  14.80
#[Out]# 283  190  2018-08-26   9.10
#[Out]# 284  190  2018-08-27   6.00
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:13:39
query4_4 = '''
WITH max_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  total
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  43.40
#[Out]# 2      1  2018-08-21  61.80
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17  32.40
#[Out]# ..   ...         ...    ...
#[Out]# 280  190  2018-08-23  52.85
#[Out]# 281  190  2018-08-24  18.10
#[Out]# 282  190  2018-08-25  46.20
#[Out]# 283  190  2018-08-26  89.55
#[Out]# 284  190  2018-08-27  32.10
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:14:21
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM dat_spending;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:14:24
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM day_spending;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  total
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  43.40
#[Out]# 2      1  2018-08-21  61.80
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17  32.40
#[Out]# ..   ...         ...    ...
#[Out]# 280  190  2018-08-23  52.85
#[Out]# 281  190  2018-08-24  18.10
#[Out]# 282  190  2018-08-25  46.20
#[Out]# 283  190  2018-08-26  89.55
#[Out]# 284  190  2018-08-27  32.10
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:14:45
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT max(total)
FROM day_spending;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    max(total)
#[Out]# 0      171.25
# Wed, 09 Dec 2020 12:16:13
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM day_spending ds, customer c 
WHERE cs.cID = c.cID;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:16:25
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM day_spending ds, customer c 
WHERE ds.cID = c.cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  total  cID   cName            street       city
#[Out]# 0      0  2018-08-22   0.45    0    Noah         Koestraat    Utrecht
#[Out]# 1      1  2018-08-20  43.40    1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      1  2018-08-21  61.80    1     Sem  Rozemarijnstraat      Breda
#[Out]# 3      2  2018-08-16   2.45    2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 4      2  2018-08-17  32.40    2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# ..   ...         ...    ...  ...     ...               ...        ...
#[Out]# 280  190  2018-08-23  52.85  190  Kostas          Eindeweg    Utrecht
#[Out]# 281  190  2018-08-24  18.10  190  Kostas          Eindeweg    Utrecht
#[Out]# 282  190  2018-08-25  46.20  190  Kostas          Eindeweg    Utrecht
#[Out]# 283  190  2018-08-26  89.55  190  Kostas          Eindeweg    Utrecht
#[Out]# 284  190  2018-08-27  32.10  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [285 rows x 7 columns]
# Wed, 09 Dec 2020 12:18:44
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM day_spending ds, customer c 
WHERE ds.cID = c.cID AND ds.total >= max(total)*0.75;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:19:47
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
SELECT *
FROM day_spending ds, customer c 
WHERE ds.cID = c.cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  total  cID   cName            street       city
#[Out]# 0      0  2018-08-22   0.45    0    Noah         Koestraat    Utrecht
#[Out]# 1      1  2018-08-20  43.40    1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      1  2018-08-21  61.80    1     Sem  Rozemarijnstraat      Breda
#[Out]# 3      2  2018-08-16   2.45    2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 4      2  2018-08-17  32.40    2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# ..   ...         ...    ...  ...     ...               ...        ...
#[Out]# 280  190  2018-08-23  52.85  190  Kostas          Eindeweg    Utrecht
#[Out]# 281  190  2018-08-24  18.10  190  Kostas          Eindeweg    Utrecht
#[Out]# 282  190  2018-08-25  46.20  190  Kostas          Eindeweg    Utrecht
#[Out]# 283  190  2018-08-26  89.55  190  Kostas          Eindeweg    Utrecht
#[Out]# 284  190  2018-08-27  32.10  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [285 rows x 7 columns]
# Wed, 09 Dec 2020 12:22:19
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
     max_spending(cID, date, total) AS (SELECT max(total)
                                        FROM day_spending)
SELECT *
FROM max_spending
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:22:24
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
     max_spending(total) AS (SELECT max(total)
                                        FROM day_spending)
SELECT *
FROM max_spending
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:22:39
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date)
     max_spending(total) AS (SELECT max(total)
                             FROM day_spending)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:22:46
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date),
     max_spending(total) AS (SELECT max(total)
                             FROM day_spending)
SELECT *
FROM max_spending;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     total
#[Out]# 0  171.25
# Wed, 09 Dec 2020 12:23:29
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date),
     max_spending(total) AS (SELECT max(total)
                             FROM day_spending)
SELECT *
FROM day_spending ds, max_spending ms, customer c
WHERE ds.cID = c.cID;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  total   total  cID   cName            street       city
#[Out]# 0      0  2018-08-22   0.45  171.25    0    Noah         Koestraat    Utrecht
#[Out]# 1      1  2018-08-20  43.40  171.25    1     Sem  Rozemarijnstraat      Breda
#[Out]# 2      1  2018-08-21  61.80  171.25    1     Sem  Rozemarijnstraat      Breda
#[Out]# 3      2  2018-08-16   2.45  171.25    2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# 4      2  2018-08-17  32.40  171.25    2   Lucas  Oude Leliestraat  Amsterdam
#[Out]# ..   ...         ...    ...     ...  ...     ...               ...        ...
#[Out]# 280  190  2018-08-23  52.85  171.25  190  Kostas          Eindeweg    Utrecht
#[Out]# 281  190  2018-08-24  18.10  171.25  190  Kostas          Eindeweg    Utrecht
#[Out]# 282  190  2018-08-25  46.20  171.25  190  Kostas          Eindeweg    Utrecht
#[Out]# 283  190  2018-08-26  89.55  171.25  190  Kostas          Eindeweg    Utrecht
#[Out]# 284  190  2018-08-27  32.10  171.25  190  Kostas          Eindeweg    Utrecht
#[Out]# 
#[Out]# [285 rows x 8 columns]
# Wed, 09 Dec 2020 12:24:00
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date),
     max_spending(total) AS (SELECT max(total)
                             FROM day_spending)
SELECT *
FROM day_spending ds, max_spending ms, customer c
WHERE ds.cID = c.cID AND ds.total >= 0.75*ms.total;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date   total   total  cID  cName          street       city
#[Out]# 0   33  2018-08-27  138.90  171.25   33   Sven  Ginnekenstraat      Breda
#[Out]# 1   71  2018-08-24  145.00  171.25   71   Dean      Pompenburg  Rotterdam
#[Out]# 2  109  2018-08-18  150.15  171.25  109   Lynn   Stationsplein      Breda
#[Out]# 3  124  2018-08-26  134.90  171.25  124  Sofie   Keizersgracht  Amsterdam
#[Out]# 4  161  2018-08-26  171.25  171.25  161  Floor       Eikenlaan    Tilburg
# Wed, 09 Dec 2020 12:24:33
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date),
     max_spending(total) AS (SELECT max(total)
                             FROM day_spending)
SELECT cName
FROM day_spending ds, max_spending ms, customer c
WHERE ds.cID = c.cID AND ds.total >= 0.75*ms.total;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Wed, 09 Dec 2020 12:27:32
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchases p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT *
FROM eind_purchaser;
'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:27:53
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT *
FROM eind_purchaser;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Wed, 09 Dec 2020 12:28:27
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT *
FROM eind_purchaser;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# ..   ...
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Wed, 09 Dec 2020 12:28:30
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT *
FROM eind_purchaser;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Wed, 09 Dec 2020 12:28:36
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT *
FROM eind_purchaser;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# ..   ...
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Wed, 09 Dec 2020 12:28:43
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT *
FROM eind_purchaser;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# ..   ...
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Wed, 09 Dec 2020 12:29:04
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT *
FROM customer c
GROUP BY city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    cID  cName            street       city
#[Out]# 0    2  Lucas  Oude Leliestraat  Amsterdam
#[Out]# 1    1    Sem  Rozemarijnstraat      Breda
#[Out]# 2    7   Bram      Schoolstraat  Eindhoven
#[Out]# 3  189   Koen          Akkerweg        Oss
#[Out]# 4   25  Mason      Keizerstraat  Rotterdam
#[Out]# 5   10    Sam       Langestraat    Tilburg
#[Out]# 6    0   Noah         Koestraat    Utrecht
# Wed, 09 Dec 2020 12:29:57
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT count(cID)
FROM customer c
GROUP BY city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    count(cID)
#[Out]# 0          26
#[Out]# 1          27
#[Out]# 2          33
#[Out]# 3           1
#[Out]# 4          29
#[Out]# 5          38
#[Out]# 6          36
# Wed, 09 Dec 2020 12:30:04
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(cID)
FROM customer c
GROUP BY city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(cID)
#[Out]# 0  Amsterdam          26
#[Out]# 1      Breda          27
#[Out]# 2  Eindhoven          33
#[Out]# 3        Oss           1
#[Out]# 4  Rotterdam          29
#[Out]# 5    Tilburg          38
#[Out]# 6    Utrecht          36
# Wed, 09 Dec 2020 12:32:13
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY city;


'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:32:19
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY c.city;


'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:32:24
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(c.cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY c.city;


'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(c.cID)
#[Out]# 0  Amsterdam            10
#[Out]# 1      Breda             9
#[Out]# 2  Eindhoven            15
#[Out]# 3  Rotterdam            13
#[Out]# 4    Tilburg            10
#[Out]# 5    Utrecht            12
# Wed, 09 Dec 2020 12:32:31
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(c.cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY c.city;


'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(c.cID)
#[Out]# 0  Amsterdam            10
#[Out]# 1      Breda             9
#[Out]# 2  Eindhoven            15
#[Out]# 3  Rotterdam            13
#[Out]# 4    Tilburg            10
#[Out]# 5    Utrecht            12
# Wed, 09 Dec 2020 12:33:07
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(c.cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY c.city;

UNION

SELECT city, 0
FROM customer c
WHERE c.cID NOT IN eind_purchaser
'''

pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 12:33:14
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(c.cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY c.city

UNION

SELECT city, 0
FROM customer c
WHERE c.cID NOT IN eind_purchaser;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#          city  count(c.cID)
#[Out]# 0   Amsterdam             0
#[Out]# 1   Amsterdam            10
#[Out]# 2       Breda             0
#[Out]# 3       Breda             9
#[Out]# 4   Eindhoven             0
#[Out]# 5   Eindhoven            15
#[Out]# 6         Oss             0
#[Out]# 7   Rotterdam             0
#[Out]# 8   Rotterdam            13
#[Out]# 9     Tilburg             0
#[Out]# 10    Tilburg            10
#[Out]# 11    Utrecht             0
#[Out]# 12    Utrecht            12
# Wed, 09 Dec 2020 12:38:20
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(c.cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY c.city

UNION

SELECT city, 0
FROM customer c
WHERE c.city NOT IN (SELECT city
                     FROM eind_purchaser e, customer c
                     WHERE c.cID = e.cID
                     GROUP BY c.city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(c.cID)
#[Out]# 0  Amsterdam            10
#[Out]# 1      Breda             9
#[Out]# 2  Eindhoven            15
#[Out]# 3        Oss             0
#[Out]# 4  Rotterdam            13
#[Out]# 5    Tilburg            10
#[Out]# 6    Utrecht            12
# Wed, 09 Dec 2020 12:38:27
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(c.cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY c.city

UNION

SELECT city, 0
FROM customer c
WHERE c.city NOT IN (SELECT city
                     FROM eind_purchaser e, customer c
                     WHERE c.cID = e.cID
                     GROUP BY c.city);
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(c.cID)
#[Out]# 0  Amsterdam            10
#[Out]# 1      Breda             9
#[Out]# 2  Eindhoven            15
#[Out]# 3        Oss             0
#[Out]# 4  Rotterdam            13
#[Out]# 5    Tilburg            10
#[Out]# 6    Utrecht            12
# Wed, 09 Dec 2020 12:38:34
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(c.cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY c.city
/*
UNION

SELECT city, 0
FROM customer c
WHERE c.city NOT IN (SELECT city
                     FROM eind_purchaser e, customer c
                     WHERE c.cID = e.cID
                     GROUP BY c.city);*/
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(c.cID)
#[Out]# 0  Amsterdam            10
#[Out]# 1      Breda             9
#[Out]# 2  Eindhoven            15
#[Out]# 3  Rotterdam            13
#[Out]# 4    Tilburg            10
#[Out]# 5    Utrecht            12
# Wed, 09 Dec 2020 12:38:40
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven')
SELECT city, count(c.cID)
FROM eind_purchaser e, customer c
WHERE c.cID = e.cID
GROUP BY c.city

UNION

SELECT city, 0
FROM customer c
WHERE c.city NOT IN (SELECT city
                     FROM eind_purchaser e, customer c
                     WHERE c.cID = e.cID
                     GROUP BY c.city);
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(c.cID)
#[Out]# 0  Amsterdam            10
#[Out]# 1      Breda             9
#[Out]# 2  Eindhoven            15
#[Out]# 3        Oss             0
#[Out]# 4  Rotterdam            13
#[Out]# 5    Tilburg            10
#[Out]# 6    Utrecht            12
# Wed, 09 Dec 2020 12:40:58
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven'),
     count_per_city(city, count) AS (SELECT city, count(c.cID)
                                     FROM eind_purchaser e, customer c
                                     WHERE c.cID = e.cID
                                     GROUP BY c.city)
SELECT *
FROM count_per_city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 12:41:00
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven'),
     count_per_city(city, count) AS (SELECT city, count(c.cID)
                                     FROM eind_purchaser e, customer c
                                     WHERE c.cID = e.cID
                                     GROUP BY c.city)
SELECT *
FROM count_per_city

'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Wed, 09 Dec 2020 12:41:54
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven'),
     count_per_city(city, count) AS (SELECT city, count(c.cID)
                                     FROM eind_purchaser e, customer c
                                     WHERE c.cID = e.cID
                                     GROUP BY c.city)
SELECT *
FROM count_per_city
UNION
SELECT DISTINCT city, 0
FROM customer 
WHERE city NOT IN (SELECT city FROM count_per_city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3        Oss      0
#[Out]# 4  Rotterdam     13
#[Out]# 5    Tilburg     10
#[Out]# 6    Utrecht     12
# Wed, 09 Dec 2020 12:42:02
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven'),
     count_per_city(city, count) AS (SELECT city, count(c.cID)
                                     FROM eind_purchaser e, customer c
                                     WHERE c.cID = e.cID
                                     GROUP BY c.city)
SELECT *
FROM count_per_city

UNION

SELECT DISTINCT city, 0
FROM customer 
WHERE city NOT IN (SELECT city FROM count_per_city)
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3        Oss      0
#[Out]# 4  Rotterdam     13
#[Out]# 5    Tilburg     10
#[Out]# 6    Utrecht     12
# Wed, 09 Dec 2020 12:42:39
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven'),
     count_per_city(city, count) AS (SELECT city, count(c.cID)
                                     FROM eind_purchaser e, customer c
                                     WHERE c.cID = e.cID
                                     GROUP BY c.city)
SELECT *
FROM count_per_city

UNION

SELECT DISTINCT city, 0
FROM customer 
WHERE city NOT IN (SELECT city FROM count_per_city);
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3        Oss      0
#[Out]# 4  Rotterdam     13
#[Out]# 5    Tilburg     10
#[Out]# 6    Utrecht     12
# Wed, 09 Dec 2020 12:43:43
query4_3 = '''
/* List all names of stores that has locations in the 
   same city as every customer and every other store.*/
   
WITH cust_cities(city) AS (SELECT city FROM customer),
     store_cities(city) AS (SELECT city FROM store),
     all_cities(city) AS (SELECT * FROM cust_cities
                          UNION
                          SELECT * FROM store_cities),
     all_possible(sName,city) AS (SELECT s.sName, ac.city FROM store s, all_cities ac),
     actual(sName, city) AS (SELECT sName, city FROM store),
     missing(sName) AS (SELECT sName FROM all_possible WHERE (sName, city) NOT IN actual)
SELECT sName
FROM store
WHERE sName NOT IN (SELECT * FROM missing);
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:43:45
query4_4 = '''
WITH day_spending(cID, date, total) AS (SELECT cID, date, sum(quantity*price)
                                        FROM purchase
                                        GROUP BY cID, date),
     max_spending(total) AS (SELECT max(total)
                             FROM day_spending)
SELECT cName
FROM day_spending ds, max_spending ms, customer c
WHERE ds.cID = c.cID AND ds.total >= 0.75*ms.total;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0   Sven
#[Out]# 1   Dean
#[Out]# 2   Lynn
#[Out]# 3  Sofie
#[Out]# 4  Floor
# Wed, 09 Dec 2020 12:43:47
query4_5 = '''
WITH eind_purchaser(cID) AS (SELECT DISTINCT p.cID 
                             FROM purchase p, store s 
                             WHERE p.sID = s.sID AND s.city = 'Eindhoven'),
     count_per_city(city, count) AS (SELECT city, count(c.cID)
                                     FROM eind_purchaser e, customer c
                                     WHERE c.cID = e.cID
                                     GROUP BY c.city)
SELECT *
FROM count_per_city

UNION

SELECT DISTINCT city, 0
FROM customer 
WHERE city NOT IN (SELECT city FROM count_per_city);
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3        Oss      0
#[Out]# 4  Rotterdam     13
#[Out]# 5    Tilburg     10
#[Out]# 6    Utrecht     12


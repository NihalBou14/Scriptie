# IPython log file

# Wed, 09 Dec 2020 09:44:01
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 09:44:01
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1f25ca397a0>
# Wed, 09 Dec 2020 09:44:29
query4_3 = '''
    PUT YOUR QUERY HERE
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 09:44:56
query4_3 = '''
    SELECT customerId from customer c

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 09:45:00
query4_3 = '''
    SELECT customerId from customer

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 09:45:06
query4_3 = '''
    SELECT *

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 09:45:20
query4_3 = '''
    SELECT * from store

'''

pd.read_sql_query(query4_3, conn)
#[Out]#     sID      sName            street       city
#[Out]# 0     0       Coop      Kalverstraat  Amsterdam
#[Out]# 1     1  Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2      Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3     Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4  Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...        ...               ...        ...
#[Out]# 59   59      Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60       Lidl      Pannekoekweg      Breda
#[Out]# 61   61       Lidl      Pannekoekweg      Breda
#[Out]# 62   62      Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63      Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Wed, 09 Dec 2020 09:50:49
query4_4 = '''
    SELECT customerId
    FROM customer c
    WHERE
    GROUPBY
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 09:50:54
query4_4 = '''
    SELECT customerId
    FROM customer c

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 09:51:07
query4_4 = '''
    SELECT cId
    FROM customer c

'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 185  185
#[Out]# 186  186
#[Out]# 187  188
#[Out]# 188  189
#[Out]# 189  190
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Wed, 09 Dec 2020 09:58:35
query4_3 = '''
    SELECT price, cId, date
    FROM purchase
    WHERE cId = cId and
    date = date

'''

pd.read_sql_query(query4_3, conn)
#[Out]#      price  cID        date
#[Out]# 0     0.45    0  2018-08-22
#[Out]# 1     4.65    1  2018-08-20
#[Out]# 2     1.60    1  2018-08-20
#[Out]# 3     1.25    1  2018-08-20
#[Out]# 4     3.95    1  2018-08-20
#[Out]# ..     ...  ...         ...
#[Out]# 504   3.80  190  2018-08-26
#[Out]# 505   4.35  190  2018-08-27
#[Out]# 506   2.85  190  2018-08-23
#[Out]# 507   3.15  190  2018-08-16
#[Out]# 508   3.30  190  2018-08-21
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Wed, 09 Dec 2020 09:59:06
query4_3 = '''
    SELECT price, cId, date
    FROM purchase


'''

pd.read_sql_query(query4_3, conn)
#[Out]#      price  cID        date
#[Out]# 0     0.45    0  2018-08-22
#[Out]# 1     4.65    1  2018-08-20
#[Out]# 2     1.60    1  2018-08-20
#[Out]# 3     1.25    1  2018-08-20
#[Out]# 4     3.95    1  2018-08-20
#[Out]# ..     ...  ...         ...
#[Out]# 504   3.80  190  2018-08-26
#[Out]# 505   4.35  190  2018-08-27
#[Out]# 506   2.85  190  2018-08-23
#[Out]# 507   3.15  190  2018-08-16
#[Out]# 508   3.30  190  2018-08-21
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Wed, 09 Dec 2020 09:59:47
query4_3 = '''
    SELECT price, cId, date
    FROM purchase
    GROUPBY cId


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:00:31
query4_3 = '''
    SELECT price, cId, date
    FROM purchase
    GROUP BY cId


'''

pd.read_sql_query(query4_3, conn)
#[Out]#      price  cID        date
#[Out]# 0     0.45    0  2018-08-22
#[Out]# 1     4.65    1  2018-08-20
#[Out]# 2     2.45    2  2018-08-16
#[Out]# 3     4.30    3  2018-08-18
#[Out]# 4     4.15    4  2018-08-24
#[Out]# ..     ...  ...         ...
#[Out]# 127   1.00  185  2018-08-20
#[Out]# 128   1.00  186  2018-08-21
#[Out]# 129   1.00  188  2018-08-20
#[Out]# 130   1.25  189  2018-08-25
#[Out]# 131   4.45  190  2018-08-19
#[Out]# 
#[Out]# [132 rows x 3 columns]
# Wed, 09 Dec 2020 10:02:57
query4_3 = '''
    SELECT sum(price), cId, date
    FROM purchase p1, purchase p2
    WHERE p1.cId = p2.cId and
    
    GROUP BY price


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:03:02
query4_3 = '''
    SELECT sum(price), cId, date
    FROM purchase p1, purchase p2
    WHERE p1.cId = p2.cId
    
    GROUP BY price


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:03:13
query4_3 = '''
    SELECT sum(price), cId, date
    FROM purchase p1, purchase p2
    WHERE p1.cId = p2.cId
    
    GROUP BY p1.price


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 10:08:32
query4_4 = '''
    
    SELECT sum(price)
    FROM purchase
    GROUP BY cId, date

'''

pd.read_sql_query(query4_4, conn)
#[Out]#      sum(price)
#[Out]# 0          0.45
#[Out]# 1         14.20
#[Out]# 2         10.00
#[Out]# 3          2.45
#[Out]# 4          7.70
#[Out]# ..          ...
#[Out]# 280       10.60
#[Out]# 281        3.25
#[Out]# 282        9.80
#[Out]# 283       21.90
#[Out]# 284        5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 10:08:45
query4_4 = '''
    
    SELECT price
    FROM purchase
    GROUP BY cId, date

'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.45
#[Out]# 1     4.65
#[Out]# 2     0.90
#[Out]# 3     2.45
#[Out]# 4     1.35
#[Out]# ..     ...
#[Out]# 280   0.50
#[Out]# 281   2.55
#[Out]# 282   3.70
#[Out]# 283   1.30
#[Out]# 284   1.20
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 10:09:05
query4_4 = '''
    
    SELECT max(sum(price))
    FROM purchase
    GROUP BY cId, date

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:09:17
query4_4 = '''
    
    SELECT sum(price)
    FROM purchase
    GROUP BY cId, date

'''

pd.read_sql_query(query4_4, conn)
#[Out]#      sum(price)
#[Out]# 0          0.45
#[Out]# 1         14.20
#[Out]# 2         10.00
#[Out]# 3          2.45
#[Out]# 4          7.70
#[Out]# ..          ...
#[Out]# 280       10.60
#[Out]# 281        3.25
#[Out]# 282        9.80
#[Out]# 283       21.90
#[Out]# 284        5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 10:10:09
query4_4 = '''
    SELECT price
    FROM purchase
    GROUP BY cId, date


'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.45
#[Out]# 1     4.65
#[Out]# 2     0.90
#[Out]# 3     2.45
#[Out]# 4     1.35
#[Out]# ..     ...
#[Out]# 280   0.50
#[Out]# 281   2.55
#[Out]# 282   3.70
#[Out]# 283   1.30
#[Out]# 284   1.20
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 10:10:15
query4_4 = '''
    SELECT price
    FROM purchase



'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.45
#[Out]# 1     4.65
#[Out]# 2     1.60
#[Out]# 3     1.25
#[Out]# 4     3.95
#[Out]# ..     ...
#[Out]# 504   3.80
#[Out]# 505   4.35
#[Out]# 506   2.85
#[Out]# 507   3.15
#[Out]# 508   3.30
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Wed, 09 Dec 2020 10:10:37
query4_4 = '''
    SELECT sum(price)
    FROM purchase
    GROUP BY cId, date



'''

pd.read_sql_query(query4_4, conn)
#[Out]#      sum(price)
#[Out]# 0          0.45
#[Out]# 1         14.20
#[Out]# 2         10.00
#[Out]# 3          2.45
#[Out]# 4          7.70
#[Out]# ..          ...
#[Out]# 280       10.60
#[Out]# 281        3.25
#[Out]# 282        9.80
#[Out]# 283       21.90
#[Out]# 284        5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 10:10:48
query4_4 = '''

    max(SELECT sum(price)
    FROM purchase
    GROUP BY cId, date)



'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:11:57
query4_4 = '''
    SELECT max(totalPerDay.price)
    FROM (SELECT sum(price)
        FROM purchase
        GROUP BY cId, date) totalPerDay



'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:12:17
query4_4 = '''
    SELECT max(price)
    FROM (SELECT sum(price)
        FROM purchase
        GROUP BY cId, date) totalPerDay



'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:12:31
query4_4 = '''
        SELECT sum(price)
        FROM purchase
        GROUP BY cId, date) totalPerDay



'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:12:37
query4_4 = '''
        SELECT sum(price)
        FROM purchase
        GROUP BY cId, date


'''

pd.read_sql_query(query4_4, conn)
#[Out]#      sum(price)
#[Out]# 0          0.45
#[Out]# 1         14.20
#[Out]# 2         10.00
#[Out]# 3          2.45
#[Out]# 4          7.70
#[Out]# ..          ...
#[Out]# 280       10.60
#[Out]# 281        3.25
#[Out]# 282        9.80
#[Out]# 283       21.90
#[Out]# 284        5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 10:12:53
query4_4 = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date


'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID  sum(price)
#[Out]# 0      0        0.45
#[Out]# 1      1       14.20
#[Out]# 2      1       10.00
#[Out]# 3      2        2.45
#[Out]# 4      2        7.70
#[Out]# ..   ...         ...
#[Out]# 280  190       10.60
#[Out]# 281  190        3.25
#[Out]# 282  190        9.80
#[Out]# 283  190       21.90
#[Out]# 284  190        5.55
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Wed, 09 Dec 2020 10:13:38
query4_4 = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date
'''

querytest = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date
'''

pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#      cID  sum(price)
#[Out]# 0      0        0.45
#[Out]# 1      1       14.20
#[Out]# 2      1       10.00
#[Out]# 3      2        2.45
#[Out]# 4      2        7.70
#[Out]# ..   ...         ...
#[Out]# 280  190       10.60
#[Out]# 281  190        3.25
#[Out]# 282  190        9.80
#[Out]# 283  190       21.90
#[Out]# 284  190        5.55
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Wed, 09 Dec 2020 10:13:49
query4_4 = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date
'''

querytest = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_4, conn)
#[Out]#      cID  sum(price)
#[Out]# 0      0        0.45
#[Out]# 1      1       14.20
#[Out]# 2      1       10.00
#[Out]# 3      2        2.45
#[Out]# 4      2        7.70
#[Out]# ..   ...         ...
#[Out]# 280  190       10.60
#[Out]# 281  190        3.25
#[Out]# 282  190        9.80
#[Out]# 283  190       21.90
#[Out]# 284  190        5.55
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Wed, 09 Dec 2020 10:14:12
query4_4 = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date
'''

querytest = '''
        SELECT cId, price
        FROM purchase
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_4, conn)
#[Out]#      cID  price
#[Out]# 0      0   0.45
#[Out]# 1      1   4.65
#[Out]# 2      1   1.60
#[Out]# 3      1   1.25
#[Out]# 4      1   3.95
#[Out]# ..   ...    ...
#[Out]# 504  190   3.80
#[Out]# 505  190   4.35
#[Out]# 506  190   2.85
#[Out]# 507  190   3.15
#[Out]# 508  190   3.30
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Wed, 09 Dec 2020 10:14:20
query4_4 = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date
'''

querytest = '''
        SELECT cId, price, date
        FROM purchase
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_4, conn)
#[Out]#      cID  price        date
#[Out]# 0      0   0.45  2018-08-22
#[Out]# 1      1   4.65  2018-08-20
#[Out]# 2      1   1.60  2018-08-20
#[Out]# 3      1   1.25  2018-08-20
#[Out]# 4      1   3.95  2018-08-20
#[Out]# ..   ...    ...         ...
#[Out]# 504  190   3.80  2018-08-26
#[Out]# 505  190   4.35  2018-08-27
#[Out]# 506  190   2.85  2018-08-23
#[Out]# 507  190   3.15  2018-08-16
#[Out]# 508  190   3.30  2018-08-21
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Wed, 09 Dec 2020 10:14:36
query4_4 = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date
'''

querytest = '''
        SELECT cId, price, date
        FROM purchase
        WHERE cId = 1
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_4, conn)
#[Out]#    cID  price        date
#[Out]# 0    1   4.65  2018-08-20
#[Out]# 1    1   1.60  2018-08-20
#[Out]# 2    1   1.25  2018-08-20
#[Out]# 3    1   3.95  2018-08-20
#[Out]# 4    1   2.75  2018-08-20
#[Out]# 5    1   0.90  2018-08-21
#[Out]# 6    1   9.10  2018-08-21
# Wed, 09 Dec 2020 10:14:54
query4_4 = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date
'''

querytest = '''
        SELECT cId, price, date
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#      cID  sum(price)
#[Out]# 0      0        0.45
#[Out]# 1      1       14.20
#[Out]# 2      1       10.00
#[Out]# 3      2        2.45
#[Out]# 4      2        7.70
#[Out]# ..   ...         ...
#[Out]# 280  190       10.60
#[Out]# 281  190        3.25
#[Out]# 282  190        9.80
#[Out]# 283  190       21.90
#[Out]# 284  190        5.55
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Wed, 09 Dec 2020 10:15:06
query4_4 = '''
        SELECT cId, sum(price)
        FROM purchase
        WHERE cId = 1
        GROUP BY cId, date
'''

querytest = '''
        SELECT cId, price, date
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#    cID  sum(price)
#[Out]# 0    1        14.2
#[Out]# 1    1        10.0
# Wed, 09 Dec 2020 10:15:29
query4_4 = '''
        SELECT cId, sum(price)
        FROM purchase
        GROUP BY cId, date
'''

querytest = '''
        SELECT cId, price, date
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#      cID  sum(price)
#[Out]# 0      0        0.45
#[Out]# 1      1       14.20
#[Out]# 2      1       10.00
#[Out]# 3      2        2.45
#[Out]# 4      2        7.70
#[Out]# ..   ...         ...
#[Out]# 280  190       10.60
#[Out]# 281  190        3.25
#[Out]# 282  190        9.80
#[Out]# 283  190       21.90
#[Out]# 284  190        5.55
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Wed, 09 Dec 2020 10:16:33
query4_4 = '''
        SELECT max(sum(price)) 
        FROM (SELECT cId, sum(price)
              FROM purchase
              GROUP BY cId, date)
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_4, conn)
#[Out]#    cID  price       datoe
#[Out]# 0    1   4.65  2018-08-20
#[Out]# 1    1   1.60  2018-08-20
#[Out]# 2    1   1.25  2018-08-20
#[Out]# 3    1   3.95  2018-08-20
#[Out]# 4    1   2.75  2018-08-20
#[Out]# 5    1   0.90  2018-08-21
#[Out]# 6    1   9.10  2018-08-21
# Wed, 09 Dec 2020 10:16:54
query4_4 = '''
        SELECT max(totalDay) 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_4, conn)
#[Out]#    cID  price       datoe
#[Out]# 0    1   4.65  2018-08-20
#[Out]# 1    1   1.60  2018-08-20
#[Out]# 2    1   1.25  2018-08-20
#[Out]# 3    1   3.95  2018-08-20
#[Out]# 4    1   2.75  2018-08-20
#[Out]# 5    1   0.90  2018-08-21
#[Out]# 6    1   9.10  2018-08-21
# Wed, 09 Dec 2020 10:17:03
query4_4 = '''
        SELECT max(totalDay) 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#    max(totalDay)
#[Out]# 0           39.1
# Wed, 09 Dec 2020 10:19:20
query4_4 = '''
        SELECT cId
        FROM purchase
        WHERE (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:20:43
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= 0.75*(SELECT max(totalDay) FROM totalPerDay)
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:21:29
query4_4 = '''
        SELECT DISTINCT cId, totalDay
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#      cId  totalDay
#[Out]# 0      0      0.45
#[Out]# 1      1     14.20
#[Out]# 2      1     10.00
#[Out]# 3      2      2.45
#[Out]# 4      2      7.70
#[Out]# ..   ...       ...
#[Out]# 279  190     10.60
#[Out]# 280  190      3.25
#[Out]# 281  190      9.80
#[Out]# 282  190     21.90
#[Out]# 283  190      5.55
#[Out]# 
#[Out]# [284 rows x 2 columns]
# Wed, 09 Dec 2020 10:23:21
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= (0.75*(SELECT max(totalDay) FROM totalPerDay))
        
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:23:42
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#    cId
#[Out]# 0  161
# Wed, 09 Dec 2020 10:24:00
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= ((SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#    cId
#[Out]# 0  161
# Wed, 09 Dec 2020 10:24:10
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= (0.001*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT cId, price, date datoe
        FROM purchase
        WHERE cId = 1
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#      cId
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      3
#[Out]# 4      4
#[Out]# ..   ...
#[Out]# 127  185
#[Out]# 128  186
#[Out]# 129  188
#[Out]# 130  189
#[Out]# 131  190
#[Out]# 
#[Out]# [132 rows x 1 columns]
# Wed, 09 Dec 2020 10:24:38
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= (0.001*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay) 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_4, conn)
#[Out]#    max(totalDay)
#[Out]# 0           39.1
# Wed, 09 Dec 2020 10:24:47
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= (0.001*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_4, conn)
#[Out]#    max(totalDay)  cId
#[Out]# 0           39.1  161
# Wed, 09 Dec 2020 10:25:57
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_4, conn)
#[Out]#    max(totalDay)  cId
#[Out]# 0           39.1  161
# Wed, 09 Dec 2020 10:26:05
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#    cId
#[Out]# 0  161
# Wed, 09 Dec 2020 10:27:19
query4_4 = '''
        SELECT DISTINCT customer.cId, customer.name
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase, customer
              GROUP BY cId, date) totalPerDay
        WHERE totalPerDay.cId = customer.cId and        
              totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:27:33
query4_4 = '''
        SELECT DISTINCT customer.cId, customer.name
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase, customer
              GROUP BY cId, date) totalPerDay
        WHERE totalPerDay.cId = customer.cId and        
              totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY purchase.cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:28:13
query4_4 = '''
        SELECT DISTINCT customer.cId, customer.name
        FROM (SELECT purchase.cId, sum(price) totalDay
              FROM purchase, customer
              GROUP BY purchase.cId, date) totalPerDay
        WHERE totalPerDay.cId = customer.cId and        
              totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY purchase.cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:28:34
query4_4 = '''
        SELECT DISTINCT cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
        WHERE totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#    cId
#[Out]# 0  161
# Wed, 09 Dec 2020 10:29:21
query4_4 = '''
        SELECT DISTINCT customer.cId
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay, customer
        WHERE customer.cId = totalPerDay.cId and
              totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0  161
# Wed, 09 Dec 2020 10:29:30
query4_4 = '''
        SELECT DISTINCT customer.cId, customer.name
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay, customer
        WHERE customer.cId = totalPerDay.cId and
              totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 10:29:47
query4_4 = '''
        SELECT DISTINCT customer.cId, customer.cName
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay, customer
        WHERE customer.cId = totalPerDay.cId and
              totalDay >= (0.75*(SELECT max(totalDay) FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date)))
        
'''

querytest = '''
        SELECT max(totalDay), cId 
        FROM (SELECT cId, sum(price) totalDay
              FROM purchase
              GROUP BY cId, date) totalPerDay
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_4, conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Wed, 09 Dec 2020 10:35:31
query4_5 = '''
    SELECT DISTINCT cId
    FROM purchase, store
    WHERE sID = sID and
        city='Eindhoven'
    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 10:35:43
query4_5 = '''
    SELECT DISTINCT cId
    FROM purchase, store
    WHERE store.sID = purchase.sID and
        city='Eindhoven'
    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Wed, 09 Dec 2020 10:39:34
query4_5 = '''
    SELECT wasInEindhoven.cId
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#    cId
#[Out]# 0    2
#[Out]# 1    1
#[Out]# 2    7
#[Out]# 3   25
#[Out]# 4   24
#[Out]# 5    5
# Wed, 09 Dec 2020 10:40:21
query4_5 = '''
    SELECT wasInEindhoven.cId, customer.city
    FROM     (SELECT DISTINCT cId, city
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#    cId       city
#[Out]# 0    2  Amsterdam
#[Out]# 1    1      Breda
#[Out]# 2    7  Eindhoven
#[Out]# 3   25  Rotterdam
#[Out]# 4   24    Tilburg
#[Out]# 5    5    Utrecht
# Wed, 09 Dec 2020 10:40:50
query4_5 = '''
    SELECT wasInEindhoven.cId, customer.city
    FROM     (SELECT cId, city
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#    cId       city
#[Out]# 0    2  Amsterdam
#[Out]# 1    1      Breda
#[Out]# 2    7  Eindhoven
#[Out]# 3   25  Rotterdam
#[Out]# 4   24    Tilburg
#[Out]# 5    5    Utrecht
# Wed, 09 Dec 2020 10:41:02
query4_5 = '''
    SELECT wasInEindhoven.cId, customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#    cId       city
#[Out]# 0    2  Amsterdam
#[Out]# 1    1      Breda
#[Out]# 2    7  Eindhoven
#[Out]# 3   25  Rotterdam
#[Out]# 4   24    Tilburg
#[Out]# 5    5    Utrecht
# Wed, 09 Dec 2020 10:41:22
query4_5 = '''
    SELECT count(wasInEindhoven.cId), customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#    count(wasInEindhoven.cId)       city
#[Out]# 0                         10  Amsterdam
#[Out]# 1                          9      Breda
#[Out]# 2                         15  Eindhoven
#[Out]# 3                         13  Rotterdam
#[Out]# 4                         10    Tilburg
#[Out]# 5                         12    Utrecht
# Wed, 09 Dec 2020 10:52:30
query4_5 = '''
    SELECT count(wasInEindhoven.cId), customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
        LEFT JOIN wasInEindhoven ON customer.city = wasInEindhoven.city
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 11:01:36
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId), customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    UNION
    SELECT DISTINCT customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCTcustomer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 11:01:51
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId), customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    UNION
    SELECT DISTINCT customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
# Wed, 09 Dec 2020 11:04:24
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId), customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT DISTINCT customer.city, 0
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#   count(wasInEindhoven.cId)       city
#[Out]# 0                         9      Breda
#[Out]# 1                        10  Amsterdam
#[Out]# 2                        10    Tilburg
#[Out]# 3                        12    Utrecht
#[Out]# 4                        13  Rotterdam
#[Out]# 5                        15  Eindhoven
#[Out]# 6                       Oss          0
# Wed, 09 Dec 2020 11:04:54
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId), customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT 0, customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = '''
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#    count(wasInEindhoven.cId)       city
#[Out]# 0                          0        Oss
#[Out]# 1                          9      Breda
#[Out]# 2                         10  Amsterdam
#[Out]# 3                         10    Tilburg
#[Out]# 4                         12    Utrecht
#[Out]# 5                         13  Rotterdam
#[Out]# 6                         15  Eindhoven
# Wed, 09 Dec 2020 11:05:26
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId), customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT 0, customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = ''' SELECT DISTINCT customer.city
                FROM customer
        
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_5, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Wed, 09 Dec 2020 11:05:45
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId), customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT 0, customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = ''' SELECT DISTINCT customer.city
                FROM customer
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#    count(wasInEindhoven.cId)       city
#[Out]# 0                          0        Oss
#[Out]# 1                          9      Breda
#[Out]# 2                         10  Amsterdam
#[Out]# 3                         10    Tilburg
#[Out]# 4                         12    Utrecht
#[Out]# 5                         13  Rotterdam
#[Out]# 6                         15  Eindhoven
# Wed, 09 Dec 2020 11:06:36
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId) customersWithPurchInEhv, customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT 0, customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = ''' SELECT DISTINCT customer.city
                FROM customer
        
'''

#pd.read_sql_query(querytest, conn)
pd.read_sql_query(query4_5, conn)
#[Out]#    customersWithPurchInEhv       city
#[Out]# 0                        0        Oss
#[Out]# 1                        9      Breda
#[Out]# 2                       10  Amsterdam
#[Out]# 3                       10    Tilburg
#[Out]# 4                       12    Utrecht
#[Out]# 5                       13  Rotterdam
#[Out]# 6                       15  Eindhoven
# Wed, 09 Dec 2020 11:35:22
query4_3 = '''
SELECT store.sName
FROM store, customer
WHERE store.city IS IN (customer.city UNION store.city)


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:36:04
query4_3 = '''
SELECT store.sName
FROM store, customer
WHERE store.city IN (customer.city UNION store.city)


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:37:14
query4_3 = '''
SELECT store.sName
FROM store, customer
WHERE store.city IN customer.city UNION store.city


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:37:37
query4_3 = '''
SELECT store.sName
FROM store, customer


'''

pd.read_sql_query(query4_3, conn)
#[Out]#        sName
#[Out]# 0       Coop
#[Out]# 1       Coop
#[Out]# 2       Coop
#[Out]# 3       Coop
#[Out]# 4       Coop
#[Out]# ...      ...
#[Out]# 12155  Jumbo
#[Out]# 12156  Jumbo
#[Out]# 12157  Jumbo
#[Out]# 12158  Jumbo
#[Out]# 12159  Jumbo
#[Out]# 
#[Out]# [12160 rows x 1 columns]
# Wed, 09 Dec 2020 11:38:09
query4_3 = '''
SELECT store.sName
FROM store, customer
WHERE store.sName IN store.sName


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:38:21
query4_3 = '''
SELECT store.sName
FROM store, customer
WHERE store.sName IN (store.sName)


'''

pd.read_sql_query(query4_3, conn)
#[Out]#        sName
#[Out]# 0       Coop
#[Out]# 1       Coop
#[Out]# 2       Coop
#[Out]# 3       Coop
#[Out]# 4       Coop
#[Out]# ...      ...
#[Out]# 12155  Jumbo
#[Out]# 12156  Jumbo
#[Out]# 12157  Jumbo
#[Out]# 12158  Jumbo
#[Out]# 12159  Jumbo
#[Out]# 
#[Out]# [12160 rows x 1 columns]
# Wed, 09 Dec 2020 11:38:33
query4_3 = '''
SELECT store.sName
FROM store, customer
WHERE store.sName IN (store.sName = 'Jumbo')


'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 11:39:02
query4_3 = '''
SELECT store.sName
FROM store, customer
WHERE store.city IN (store.city UNION customer.city)


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:40:22
query4_3 = '''
SELECT store.sName
FROM store, customer
WHERE store.city IN (SELECT store.city FROM store UNION SELECT customer.city FROM customer)


'''

pd.read_sql_query(query4_3, conn)
#[Out]#        sName
#[Out]# 0       Coop
#[Out]# 1       Coop
#[Out]# 2       Coop
#[Out]# 3       Coop
#[Out]# 4       Coop
#[Out]# ...      ...
#[Out]# 12155  Jumbo
#[Out]# 12156  Jumbo
#[Out]# 12157  Jumbo
#[Out]# 12158  Jumbo
#[Out]# 12159  Jumbo
#[Out]# 
#[Out]# [12160 rows x 1 columns]
# Wed, 09 Dec 2020 11:42:02
query4_3 = '''
SELECT DISTINCT store.sName
FROM store, customer
WHERE store.city IN (SELECT store.city FROM store UNION SELECT customer.city FROM customer)


'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Wed, 09 Dec 2020 11:42:09
query4_3 = '''
SELECT DISTINCT store.sName, store.city
FROM store, customer
WHERE store.city IN (SELECT store.city FROM store UNION SELECT customer.city FROM customer)


'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Wed, 09 Dec 2020 11:43:42
query4_3 = '''
SELECT DISTINCT store.sName
FROM store, customer
WHERE store.city IN (SELECT store.city FROM store UNION SELECT customer.city FROM customer)
GROUP BY store.name


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:43:58
query4_3 = '''
SELECT DISTINCT store.sName
FROM store, customer
WHERE store.city IN (SELECT store.city FROM store UNION SELECT customer.city FROM customer)
GROUP BY sName


'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Wed, 09 Dec 2020 11:45:11
query4_3 = '''
SELECT DISTINCT store.sName, store.city



'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:45:18
query4_3 = '''
SELECT DISTINCT store.sName, store.city
FROM store


'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Wed, 09 Dec 2020 11:45:39
query4_3 = '''
SELECT DISTINCT store.sName, store.city
FROM store
GROUP BY store.sName


'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city
#[Out]# 0  Albert Hein  Eindhoven
#[Out]# 1         Coop  Amsterdam
#[Out]# 2         Dirk      Breda
#[Out]# 3    Hoogvliet      Breda
#[Out]# 4        Jumbo  Rotterdam
#[Out]# 5         Lidl  Eindhoven
#[Out]# 6       Sligro  Rotterdam
# Wed, 09 Dec 2020 11:46:14
query4_3 = '''
SELECT DISTINCT store.sName, store.city
FROM store
WHERE store.


'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 11:46:18
query4_3 = '''
SELECT DISTINCT store.sName, store.city
FROM store



'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Wed, 09 Dec 2020 11:50:27
query4_3 = '''
SELECT DISTINCT store.sName, store.city
FROM store
WHERE store.sName, store.city IN (SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
SELECT DISTINCT city
FROM customer

UNION

SELECT DISTINCT city FROM STORE



'''

#pd.read_sql_query(query4_3, conn)

querytest = '''

                                    
SELECT DISTINCT city
FROM customer

UNION

SELECT DISTINCT city FROM STORE



'''

pd.read_sql_query(querytest, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 11:50:42
query4_3 = '''
SELECT DISTINCT store.sName, store.city
FROM store
WHERE store.sName, store.city IN (SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
SELECT DISTINCT city
FROM customer

UNION

SELECT DISTINCT city FROM STORE



'''

#pd.read_sql_query(query4_3, conn)

querytest = '''

                                    
SELECT DISTINCT city
FROM customer





'''

pd.read_sql_query(querytest, conn)
#[Out]#         city
#[Out]# 0    Utrecht
#[Out]# 1      Breda
#[Out]# 2  Amsterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5  Rotterdam
#[Out]# 6        Oss
# Wed, 09 Dec 2020 11:50:50
query4_3 = '''
SELECT DISTINCT store.sName, store.city
FROM store
WHERE store.sName, store.city IN (SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
SELECT DISTINCT city
FROM customer

UNION

SELECT DISTINCT city FROM STORE



'''

#pd.read_sql_query(query4_3, conn)

querytest = '''

                                    


SELECT DISTINCT city FROM STORE



'''

pd.read_sql_query(querytest, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Rotterdam
#[Out]# 3  Eindhoven
#[Out]# 4    Tilburg
#[Out]# 5    Utrecht
#[Out]# 6        Oss
# Wed, 09 Dec 2020 11:51:39
query4_3 = '''
SELECT DISTINCT store.sName, store.city
FROM store
WHERE store.sName, store.city IN (SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
SELECT DISTINCT city
FROM customer

UNION

SELECT DISTINCT city FROM STORE



'''

#pd.read_sql_query(query4_3, conn)

querytest = '''

SELECT DISTINCT city
FROM customer

UNION

SELECT DISTINCT city FROM STORE



'''

pd.read_sql_query(querytest, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 11:53:44
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE store.sName, store.city IN (store,SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT * FROM
store, SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE 



'''

pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 11:54:04
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE store.sName, store.city IN (store,SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT * FROM
store, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

pd.read_sql_query(querytest, conn)
#[Out]#      sID  sName         street       city       city
#[Out]# 0      0   Coop   Kalverstraat  Amsterdam  Amsterdam
#[Out]# 1      0   Coop   Kalverstraat  Amsterdam      Breda
#[Out]# 2      0   Coop   Kalverstraat  Amsterdam  Eindhoven
#[Out]# 3      0   Coop   Kalverstraat  Amsterdam        Oss
#[Out]# 4      0   Coop   Kalverstraat  Amsterdam  Rotterdam
#[Out]# ..   ...    ...            ...        ...        ...
#[Out]# 443   63  Jumbo  Stationstraat        Oss  Eindhoven
#[Out]# 444   63  Jumbo  Stationstraat        Oss        Oss
#[Out]# 445   63  Jumbo  Stationstraat        Oss  Rotterdam
#[Out]# 446   63  Jumbo  Stationstraat        Oss    Tilburg
#[Out]# 447   63  Jumbo  Stationstraat        Oss    Utrecht
#[Out]# 
#[Out]# [448 rows x 5 columns]
# Wed, 09 Dec 2020 11:54:20
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE store.sName, store.city IN (store,SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT * FROM
store.sName, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 11:54:50
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE store.sName, store.city IN (store,SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT * FROM
(SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

pd.read_sql_query(querytest, conn)
#[Out]#      sName       city
#[Out]# 0     Coop  Amsterdam
#[Out]# 1     Coop      Breda
#[Out]# 2     Coop  Eindhoven
#[Out]# 3     Coop        Oss
#[Out]# 4     Coop  Rotterdam
#[Out]# ..     ...        ...
#[Out]# 443  Jumbo  Eindhoven
#[Out]# 444  Jumbo        Oss
#[Out]# 445  Jumbo  Rotterdam
#[Out]# 446  Jumbo    Tilburg
#[Out]# 447  Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Wed, 09 Dec 2020 11:56:30
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE store.sName, store.city IN (store,SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT FROM
(SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 11:56:35
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE store.sName, store.city IN (store,SELECT store.sName, 
                                    FROM store.city UNION customer.city)
                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM
(SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

pd.read_sql_query(querytest, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Wed, 09 Dec 2020 12:00:50
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE store.sName, store.city NOT IN (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

pd.read_sql_query(querytest, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Wed, 09 Dec 2020 12:01:18
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE store.sName, store.city NOT IN (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:01:52
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE (store.sName, store.city) NOT IN (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:01:59
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE (store.sName, store.city) NOT IN (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:02:06
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE (store.sName, store.city)  IN (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:02:11
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE (store.sName, store.city)  IN (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:02:20
query4_3 = '''
SELECT DISTINCT store.sName
FROM store
WHERE store.sName, store.city IN (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:04:46
query4_3 = '''
SELECT DISTINCT store.sName
FROM store INTERSECT (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities) 

                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:06:32
query4_3 = '''
SELECT *
FROM SELECT(store.sName, store.city FROM store) INTERSECT (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities) 

                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:07:16
query4_3 = '''
SELECT *
FROM (SELECT(store.sName, store.city FROM store)) INTERSECT (SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE)) 

                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:08:47
query4_3 = '''
SELECTstore.sName, store.city FROM store
INTERSECT 
SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE)) 


                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:08:53
query4_3 = '''
SELECT store.sName, store.city FROM store
INTERSECT 
SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE)) 


                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:09:20
query4_3 = '''
SELECT store.sName, store.city FROM store
INTERSECT 
SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE)


                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:09:31
query4_3 = '''
SELECT store.sName, store.city FROM store
UNION
SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE)


                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:09:40
query4_3 = '''
SELECT store.sName, store.city FROM store
INTERSECT
SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE)


                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:11:42
query4_3 = '''

SELECT store.sName 
FROM (SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE))

                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:11:57
query4_3 = '''

SELECT sName 
FROM (SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE))

                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:12:02
query4_3 = '''

SELECT sName 
FROM (SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE))

                                    
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:12:28
query4_3 = '''

SELECT sName 
FROM (SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE))

                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities 



'''

pd.read_sql_query(querytest, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Wed, 09 Dec 2020 12:14:40
query4_3 = '''

SELECT sName 
FROM (SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE))

                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
WITH combos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities) 
SELECT * FROM combos


'''

pd.read_sql_query(querytest, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Wed, 09 Dec 2020 12:15:57
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities) 
WITH actualCombos AS ()

SELECT sName 
FROM (SELECT DISTINCT * FROM (SELECT store.sName FROM store), (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE))

                                    
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT sName, city FROM store


'''

pd.read_sql_query(querytest, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Wed, 09 Dec 2020 12:19:19
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities) 
WITH actualCombos AS (SELECT DISTINCT sName, city FROM store)

SELECT * 
FROM allcombos
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT sName, city FROM store


'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:19:55
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities), 
WITH actualCombos AS (SELECT DISTINCT sName, city FROM store)

SELECT * 
FROM allcombos
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT sName, city FROM store


'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:20:16
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities), actualCombos AS (SELECT DISTINCT sName, city FROM store)

SELECT * 
FROM allcombos
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT sName, city FROM store


'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:20:39
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities), actualCombos AS (SELECT DISTINCT sName, city FROM store)

SELECT city
FROM allcombos
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
SELECT DISTINCT sName, city FROM store


'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:21:54
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities), 
actualCombos AS (SELECT DISTINCT sName, city FROM store)

SELECT city
FROM allcombos
'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
SELECT * FROM allCombos


'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:22:00
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities), 
actualCombos AS (SELECT DISTINCT sName, city FROM store)

SELECT city
FROM allcombos
'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
SELECT * FROM allCombos


'''

pd.read_sql_query(querytest, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Wed, 09 Dec 2020 12:24:28
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)

SELECT *
FROM allcombos

'''

#pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
SELECT * FROM allCombos


'''

pd.read_sql_query(querytest, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Wed, 09 Dec 2020 12:24:35
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)

SELECT *
FROM allcombos

'''

pd.read_sql_query(query4_3, conn)

# ALL CITIES
querytest = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)
SELECT * FROM allCombos


'''

#pd.read_sql_query(querytest, conn)
# Wed, 09 Dec 2020 12:24:55
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)

SELECT *
FROM allcombos

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Wed, 09 Dec 2020 12:26:27
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)

SELECT *
FROM allcombos
WHERE CONCAT(allCombos.sName, allCombos.city) NOT IN (SELECT CONCAT(store.sName, store.city) FROM store)

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:28:16
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)

SELECT *
FROM allcombos
WHERE (SELECT allCombos.sName, allCombos.city) NOT IN (SELECT store.sName, store.city FROM store)

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Eindhoven
#[Out]# 1          Coop        Oss
#[Out]# 2     Hoogvliet  Amsterdam
#[Out]# 3     Hoogvliet        Oss
#[Out]# 4     Hoogvliet    Utrecht
#[Out]# 5         Jumbo  Amsterdam
#[Out]# 6         Jumbo    Utrecht
#[Out]# 7        Sligro        Oss
#[Out]# 8        Sligro    Utrecht
#[Out]# 9   Albert Hein  Amsterdam
#[Out]# 10  Albert Hein        Oss
#[Out]# 11         Lidl        Oss
#[Out]# 12         Lidl    Tilburg
#[Out]# 13         Dirk  Amsterdam
#[Out]# 14         Dirk        Oss
#[Out]# 15         Dirk    Tilburg
#[Out]# 16         Dirk    Utrecht
# Wed, 09 Dec 2020 12:29:04
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)

SELECT DISTINCT sName
FROM store
WHERE sName NOT IN(
SELECT *
FROM allcombos
WHERE (SELECT allCombos.sName, allCombos.city) NOT IN (SELECT store.sName, store.city FROM store))

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:29:25
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)

SELECT DISTINCT sName
FROM store
WHERE sName NOT IN(
SELECT sName
FROM allcombos
WHERE (SELECT allCombos.sName, allCombos.city) NOT IN (SELECT store.sName, store.city FROM store))

'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:29:52
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)


SELECT sName
FROM allcombos
WHERE (SELECT allCombos.sName, allCombos.city) NOT IN (SELECT store.sName, store.city FROM store)

'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1          Coop
#[Out]# 2     Hoogvliet
#[Out]# 3     Hoogvliet
#[Out]# 4     Hoogvliet
#[Out]# 5         Jumbo
#[Out]# 6         Jumbo
#[Out]# 7        Sligro
#[Out]# 8        Sligro
#[Out]# 9   Albert Hein
#[Out]# 10  Albert Hein
#[Out]# 11         Lidl
#[Out]# 12         Lidl
#[Out]# 13         Dirk
#[Out]# 14         Dirk
#[Out]# 15         Dirk
#[Out]# 16         Dirk
# Wed, 09 Dec 2020 12:30:00
query4_3 = '''
WITH allCombos AS (SELECT DISTINCT * FROM (SELECT store.sName FROM store) storeNames, (SELECT DISTINCT city FROM customer UNION SELECT DISTINCT city FROM STORE) cities)

SELECT DISTINCT sName
FROM store
WHERE sName NOT IN(
SELECT sName
FROM allcombos
WHERE (SELECT allCombos.sName, allCombos.city) NOT IN (SELECT store.sName, store.city FROM store))

'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:37:31
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId) customersWithPurchInEhv, customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT 0, customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = ''' 
                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date
        
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_5, conn)
#[Out]#      sID        date  count(distinct pID)
#[Out]# 0      0  2018-07-18                    1
#[Out]# 1      0  2018-08-15                    3
#[Out]# 2      0  2018-08-16                    2
#[Out]# 3      0  2018-08-17                    1
#[Out]# 4      0  2018-08-18                    1
#[Out]# ..   ...         ...                  ...
#[Out]# 517   59  2018-08-24                    1
#[Out]# 518   59  2018-08-25                    2
#[Out]# 519   59  2018-08-26                    2
#[Out]# 520   59  2018-08-27                    1
#[Out]# 521   60  2018-07-10                    1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Wed, 09 Dec 2020 12:44:28
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId) customersWithPurchInEhv, customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT 0, customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = ''' 
           with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size > 20)
        
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_5, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 61   61       Lidl
#[Out]# 62   62      Jumbo
#[Out]# 63   63      Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Wed, 09 Dec 2020 12:45:54
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId) customersWithPurchInEhv, customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT 0, customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = ''' 
           with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select *

            from inventory_size

          
        
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_5, conn)
#[Out]#      sID        date  size
#[Out]# 0      0  2018-07-18     1
#[Out]# 1      0  2018-08-15     3
#[Out]# 2      0  2018-08-16     2
#[Out]# 3      0  2018-08-17     1
#[Out]# 4      0  2018-08-18     1
#[Out]# ..   ...         ...   ...
#[Out]# 517   59  2018-08-24     1
#[Out]# 518   59  2018-08-25     2
#[Out]# 519   59  2018-08-26     2
#[Out]# 520   59  2018-08-27     1
#[Out]# 521   60  2018-07-10     1
#[Out]# 
#[Out]# [522 rows x 3 columns]
# Wed, 09 Dec 2020 12:46:29
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId) customersWithPurchInEhv, customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT 0, customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = ''' 
           with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select *

            from inventory_size
            
            where size > 10

          
        
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sID, date, size]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:47:05
query4_5 = '''
    SELECT DISTINCT count(wasInEindhoven.cId) customersWithPurchInEhv, customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city
    
    UNION
    
    SELECT 0, customer.city
    FROM customer
    WHERE customer.city NOT IN (SELECT DISTINCT customer.city
    FROM     (SELECT DISTINCT cId
              FROM purchase, store
              WHERE store.sID = purchase.sID and
                city='Eindhoven') wasInEindhoven, customer
    WHERE customer.cId = wasInEindhoven.cId
    GROUP BY customer.city)



    
'''

querytest = ''' 
           with inventory_size(sID, date, size) as (

                        select sID, date, count(distinct pID)

                        from inventory

                        group by sID, date

            )

            select sID, sName

            from store

            where sID not in (

                        select sID

                        from inventory_size

                        where size > 20)
            

          
        
'''

pd.read_sql_query(querytest, conn)
#pd.read_sql_query(query4_5, conn)
#[Out]#     sID      sName
#[Out]# 0     0       Coop
#[Out]# 1     1  Hoogvliet
#[Out]# 2     2      Jumbo
#[Out]# 3     3     Sligro
#[Out]# 4     4  Hoogvliet
#[Out]# ..  ...        ...
#[Out]# 59   59      Jumbo
#[Out]# 60   60       Lidl
#[Out]# 61   61       Lidl
#[Out]# 62   62      Jumbo
#[Out]# 63   63      Jumbo
#[Out]# 
#[Out]# [64 rows x 2 columns]

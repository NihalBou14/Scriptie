# IPython log file

# Tue, 08 Dec 2020 14:24:03
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 14:24:04
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x230c3eff500>
# Tue, 08 Dec 2020 14:26:22
query4_5 = '''
    SELECT *
    FROM purchase AS P,store AS S
    WHERE P.sId = S.sId AND S.sName = 'Eindhoven'
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [tID, cID, sID, pID, date, quantity, price, sID, sName, street, city]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:26:34
query4_5 = '''
    SELECT *
    FROM purchase AS P,store AS S
    WHERE P.sId = S.sId 
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  sID        sName  \
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45    3       Sligro   
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65   23         Dirk   
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60    3       Sligro   
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25   17    Hoogvliet   
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95   32  Albert Hein   
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75   16         Lidl   
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90   46         Lidl   
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10   36         Lidl   
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45   12         Lidl   
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35   39       Sligro   
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10   13         Coop   
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70   51         Coop   
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55   47         Coop   
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30   44  Albert Hein   
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75   30         Dirk   
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45   29       Sligro   
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15   17    Hoogvliet   
#[Out]# 17    17    4   10   27  2018-08-24         9   9.05   10        Jumbo   
#[Out]# 18    18    4   53   12  2018-08-25         5  13.60   53         Coop   
#[Out]# 19    19    4   21    6  2018-08-24         2   1.05   21         Coop   
#[Out]# 20    20    4    7   13  2018-08-25         9   3.05    7       Sligro   
#[Out]# 21    21    4   44   26  2018-08-25         4   2.75   44  Albert Hein   
#[Out]# 22    22    5    4   14  2018-08-17         6   4.70    4    Hoogvliet   
#[Out]# 23    23    5   36   28  2018-08-22         6   8.25   36         Lidl   
#[Out]# 24    24    5   55    6  2018-08-23         9   1.10   55         Coop   
#[Out]# 25    25    5   51   22  2018-08-23         2   1.55   51         Coop   
#[Out]# 26    26    5    6   16  2018-08-23         2   1.85    6         Coop   
#[Out]# 27    27    5   17   19  2018-08-23         1   2.20   17    Hoogvliet   
#[Out]# 28    28    7    3   19  2018-08-23         2   2.10    3       Sligro   
#[Out]# 29    29    7   12    2  2018-08-23         6   1.70   12         Lidl   
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  ...          ...   
#[Out]# 479  818  190   34   28  2018-08-20         4   2.80   34         Coop   
#[Out]# 480  819  190   35   27  2018-08-15         5   0.50   35         Lidl   
#[Out]# 481  820  190   36    5  2018-08-23         3   2.55   36         Lidl   
#[Out]# 482  821  190   37   28  2018-08-15         4   0.65   37        Jumbo   
#[Out]# 483  822  190   38    7  2018-08-24         4   0.70   38    Hoogvliet   
#[Out]# 484  823  190   39    0  2018-08-25         4   3.70   39       Sligro   
#[Out]# 485  824  190   40   11  2018-08-15         2   3.50   40    Hoogvliet   
#[Out]# 486  825  190   41    6  2018-08-15         5   2.95   41  Albert Hein   
#[Out]# 487  826  190   42   19  2018-08-22         5   2.75   42       Sligro   
#[Out]# 488  827  190   43   17  2018-08-17         7   1.50   43         Coop   
#[Out]# 489  828  190   44    9  2018-08-18         5   0.85   44  Albert Hein   
#[Out]# 490  829  190   45   11  2018-08-19         2   3.55   45         Coop   
#[Out]# 491  830  190   46   22  2018-08-25         4   2.60   46         Lidl   
#[Out]# 492  831  190   47   17  2018-08-17         4   3.25   47         Coop   
#[Out]# 493  832  190   48   20  2018-08-26         6   4.30   48    Hoogvliet   
#[Out]# 494  833  190   49   11  2018-08-17         3   3.05   49    Hoogvliet   
#[Out]# 495  834  190   50   21  2018-08-22         6   4.05   50       Sligro   
#[Out]# 496  835  190   51   23  2018-08-19         1   1.50   51         Coop   
#[Out]# 497  836  190   52   23  2018-08-15         5   2.50   52         Lidl   
#[Out]# 498  837  190   53    8  2018-08-18         4   3.95   53         Coop   
#[Out]# 499  838  190   54    0  2018-08-25         6   3.50   54         Dirk   
#[Out]# 500  839  190   55    8  2018-08-18         7   2.95   55         Coop   
#[Out]# 501  840  190   56   11  2018-08-15         4   1.60   56        Jumbo   
#[Out]# 502  841  190   57   15  2018-08-22         5   3.25   57         Dirk   
#[Out]# 503  842  190   58    2  2018-08-19         7   0.75   58         Dirk   
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80   59        Jumbo   
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35   60         Lidl   
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85   61         Lidl   
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15   62        Jumbo   
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30   63        Jumbo   
#[Out]# 
#[Out]#                street       city  
#[Out]# 0      Stadhoudersweg  Rotterdam  
#[Out]# 1       Stationsplein      Breda  
#[Out]# 2      Stadhoudersweg  Rotterdam  
#[Out]# 3          Kerkstraat  Eindhoven  
#[Out]# 4          Hoogstraat    Utrecht  
#[Out]# 5       Ambachtstraat    Utrecht  
#[Out]# 6          Bergselaan  Rotterdam  
#[Out]# 7       Julianastraat  Eindhoven  
#[Out]# 8    Wilhelminastraat  Eindhoven  
#[Out]# 9         Dorpsstraat  Eindhoven  
#[Out]# 10          Koestraat    Tilburg  
#[Out]# 11        Parallelweg    Utrecht  
#[Out]# 12      Julianastraat  Rotterdam  
#[Out]# 13      Ambachtstraat    Utrecht  
#[Out]# 14        Nieuwstraat  Eindhoven  
#[Out]# 15       Marnixstraat  Amsterdam  
#[Out]# 16         Kerkstraat  Eindhoven  
#[Out]# 17         Bergselaan  Rotterdam  
#[Out]# 18         Hoogstraat    Utrecht  
#[Out]# 19       Kasteeldreef    Tilburg  
#[Out]# 20   Wilhelminastraat  Eindhoven  
#[Out]# 21      Ambachtstraat    Utrecht  
#[Out]# 22        Molenstraat  Eindhoven  
#[Out]# 23      Julianastraat  Eindhoven  
#[Out]# 24    Sint Annastraat      Breda  
#[Out]# 25        Parallelweg    Utrecht  
#[Out]# 26     Stadhoudersweg  Rotterdam  
#[Out]# 27         Kerkstraat  Eindhoven  
#[Out]# 28     Stadhoudersweg  Rotterdam  
#[Out]# 29   Wilhelminastraat  Eindhoven  
#[Out]# ..                ...        ...  
#[Out]# 479          Bierkaai  Amsterdam  
#[Out]# 480     Julianastraat    Utrecht  
#[Out]# 481     Julianastraat  Eindhoven  
#[Out]# 482          Molenweg  Eindhoven  
#[Out]# 483          Hofplein  Rotterdam  
#[Out]# 484       Dorpsstraat  Eindhoven  
#[Out]# 485          Hofplein  Rotterdam  
#[Out]# 486        Bergselaan  Rotterdam  
#[Out]# 487      Kalverstraat  Amsterdam  
#[Out]# 488    Gasthuisstraat    Utrecht  
#[Out]# 489     Ambachtstraat    Utrecht  
#[Out]# 490      Kasteeldreef    Tilburg  
#[Out]# 491        Bergselaan  Rotterdam  
#[Out]# 492     Julianastraat  Rotterdam  
#[Out]# 493      Kasteeldreef    Tilburg  
#[Out]# 494      Keizerstraat  Rotterdam  
#[Out]# 495     Stationsplein      Breda  
#[Out]# 496       Parallelweg    Utrecht  
#[Out]# 497       Nieuwstraat  Eindhoven  
#[Out]# 498        Hoogstraat    Utrecht  
#[Out]# 499     Julianastraat  Eindhoven  
#[Out]# 500   Sint Annastraat      Breda  
#[Out]# 501       Parallelweg  Eindhoven  
#[Out]# 502       Molenstraat  Eindhoven  
#[Out]# 503      Keizerstraat  Rotterdam  
#[Out]# 504  Rozemarijnstraat      Breda  
#[Out]# 505      Pannekoekweg      Breda  
#[Out]# 506      Pannekoekweg      Breda  
#[Out]# 507     Poffertjesweg  Eindhoven  
#[Out]# 508     Stationstraat        Oss  
#[Out]# 
#[Out]# [509 rows x 11 columns]
# Tue, 08 Dec 2020 14:26:52
query4_5 = '''
    SELECT *
    FROM purchase AS P,store AS S
    WHERE P.sId = S.sId AND S.city = 'Eindhoven'
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price  sID        sName  \
#[Out]# 0      3    1   17    9  2018-08-20         2   1.25   17    Hoogvliet   
#[Out]# 1      7    1   36   27  2018-08-21         6   9.10   36         Lidl   
#[Out]# 2      8    2   12   20  2018-08-16         1   2.45   12         Lidl   
#[Out]# 3      9    2   39    9  2018-08-17         7   1.35   39       Sligro   
#[Out]# 4     14    3   30   26  2018-08-19         2   2.75   30         Dirk   
#[Out]# 5     16    4   17    8  2018-08-24         2   4.15   17    Hoogvliet   
#[Out]# 6     20    4    7   13  2018-08-25         9   3.05    7       Sligro   
#[Out]# 7     22    5    4   14  2018-08-17         6   4.70    4    Hoogvliet   
#[Out]# 8     23    5   36   28  2018-08-22         6   8.25   36         Lidl   
#[Out]# 9     27    5   17   19  2018-08-23         1   2.20   17    Hoogvliet   
#[Out]# 10    29    7   12    2  2018-08-23         6   1.70   12         Lidl   
#[Out]# 11    38   13   33    0  2018-08-17         5   5.35   33         Dirk   
#[Out]# 12    39   13    4   23  2018-08-17         6   2.55    4    Hoogvliet   
#[Out]# 13    40   13   36    8  2018-08-17         3   5.40   36         Lidl   
#[Out]# 14    41   13   33   17  2018-08-25         5   2.00   33         Dirk   
#[Out]# 15    44   13    4    3  2018-08-25         1   1.70    4    Hoogvliet   
#[Out]# 16    46   13    8    5  2018-08-27         6   0.50    8  Albert Hein   
#[Out]# 17    55   16   36   13  2018-08-18         1   2.90   36         Lidl   
#[Out]# 18    78   24   17    5  2018-08-20         7   0.55   17    Hoogvliet   
#[Out]# 19    82   24   36    6  2018-08-20         3   1.15   36         Lidl   
#[Out]# 20    84   25   12   26  2018-08-28         9   2.55   12         Lidl   
#[Out]# 21    86   27    8    6  2018-08-26         1   0.95    8  Albert Hein   
#[Out]# 22    96   30    7   16  2018-08-18         4   1.90    7       Sligro   
#[Out]# 23    97   30   57   12  2018-08-18         8  11.45   57         Dirk   
#[Out]# 24    99   31   39   24  2018-08-28         4   3.90   39       Sligro   
#[Out]# 25   100   33   39    6  2018-08-26         6   1.05   39       Sligro   
#[Out]# 26   101   33   57   19  2018-08-26         4   2.60   57         Dirk   
#[Out]# 27   102   33   54   16  2018-08-26         1   2.05   54         Dirk   
#[Out]# 28   103   33   17    9  2018-08-26         9   1.30   17    Hoogvliet   
#[Out]# 29   104   33   36    0  2018-08-27         6   3.95   36         Lidl   
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...  ...          ...   
#[Out]# 103  437  169   52   14  2018-08-28         7   4.65   52         Lidl   
#[Out]# 104  439  170   52    0  2018-08-16         7   3.95   52         Lidl   
#[Out]# 105  441  171   56    3  2018-08-20         1   1.50   56        Jumbo   
#[Out]# 106  447  176   52    4  2018-08-22         7   0.90   52         Lidl   
#[Out]# 107  448  176   12   24  2018-08-25         9   3.85   12         Lidl   
#[Out]# 108  451  176    4   21  2018-08-26         8   2.15    4    Hoogvliet   
#[Out]# 109  459  178   39   24  2018-08-27         1   3.90   39       Sligro   
#[Out]# 110  462  179   57   17  2018-08-24         2   2.40   57         Dirk   
#[Out]# 111  468  180   56   10  2018-08-27         3   0.60   56        Jumbo   
#[Out]# 112  472  182   17   25  2018-08-28         8   3.90   17    Hoogvliet   
#[Out]# 113  474  182    4   13  2018-08-23         9   4.20    4    Hoogvliet   
#[Out]# 114  778  185   62   29  2018-08-20         1   1.00   62        Jumbo   
#[Out]# 115  779  186   62   29  2018-08-21         5   1.00   62        Jumbo   
#[Out]# 116  780  188   62   30  2018-08-20         1   1.00   62        Jumbo   
#[Out]# 117  781  188   62   30  2018-09-20         1   1.00   62        Jumbo   
#[Out]# 118  788  190    4    7  2018-08-26         7   1.30    4    Hoogvliet   
#[Out]# 119  791  190    7   22  2018-08-20         4   3.20    7       Sligro   
#[Out]# 120  792  190    8   20  2018-08-16         7   3.25    8  Albert Hein   
#[Out]# 121  796  190   12   26  2018-08-17         6   2.75   12         Lidl   
#[Out]# 122  801  190   17   10  2018-08-23         6   0.95   17    Hoogvliet   
#[Out]# 123  814  190   30   10  2018-08-18         4   4.35   30         Dirk   
#[Out]# 124  817  190   33   19  2018-08-19         5   4.25   33         Dirk   
#[Out]# 125  820  190   36    5  2018-08-23         3   2.55   36         Lidl   
#[Out]# 126  821  190   37   28  2018-08-15         4   0.65   37        Jumbo   
#[Out]# 127  823  190   39    0  2018-08-25         4   3.70   39       Sligro   
#[Out]# 128  836  190   52   23  2018-08-15         5   2.50   52         Lidl   
#[Out]# 129  838  190   54    0  2018-08-25         6   3.50   54         Dirk   
#[Out]# 130  840  190   56   11  2018-08-15         4   1.60   56        Jumbo   
#[Out]# 131  841  190   57   15  2018-08-22         5   3.25   57         Dirk   
#[Out]# 132  846  190   62    9  2018-08-16         2   3.15   62        Jumbo   
#[Out]# 
#[Out]#                street       city  
#[Out]# 0          Kerkstraat  Eindhoven  
#[Out]# 1       Julianastraat  Eindhoven  
#[Out]# 2    Wilhelminastraat  Eindhoven  
#[Out]# 3         Dorpsstraat  Eindhoven  
#[Out]# 4         Nieuwstraat  Eindhoven  
#[Out]# 5          Kerkstraat  Eindhoven  
#[Out]# 6    Wilhelminastraat  Eindhoven  
#[Out]# 7         Molenstraat  Eindhoven  
#[Out]# 8       Julianastraat  Eindhoven  
#[Out]# 9          Kerkstraat  Eindhoven  
#[Out]# 10   Wilhelminastraat  Eindhoven  
#[Out]# 11        Nieuwstraat  Eindhoven  
#[Out]# 12        Molenstraat  Eindhoven  
#[Out]# 13      Julianastraat  Eindhoven  
#[Out]# 14        Nieuwstraat  Eindhoven  
#[Out]# 15        Molenstraat  Eindhoven  
#[Out]# 16        Molenstraat  Eindhoven  
#[Out]# 17      Julianastraat  Eindhoven  
#[Out]# 18         Kerkstraat  Eindhoven  
#[Out]# 19      Julianastraat  Eindhoven  
#[Out]# 20   Wilhelminastraat  Eindhoven  
#[Out]# 21        Molenstraat  Eindhoven  
#[Out]# 22   Wilhelminastraat  Eindhoven  
#[Out]# 23        Molenstraat  Eindhoven  
#[Out]# 24        Dorpsstraat  Eindhoven  
#[Out]# 25        Dorpsstraat  Eindhoven  
#[Out]# 26        Molenstraat  Eindhoven  
#[Out]# 27      Julianastraat  Eindhoven  
#[Out]# 28         Kerkstraat  Eindhoven  
#[Out]# 29      Julianastraat  Eindhoven  
#[Out]# ..                ...        ...  
#[Out]# 103       Nieuwstraat  Eindhoven  
#[Out]# 104       Nieuwstraat  Eindhoven  
#[Out]# 105       Parallelweg  Eindhoven  
#[Out]# 106       Nieuwstraat  Eindhoven  
#[Out]# 107  Wilhelminastraat  Eindhoven  
#[Out]# 108       Molenstraat  Eindhoven  
#[Out]# 109       Dorpsstraat  Eindhoven  
#[Out]# 110       Molenstraat  Eindhoven  
#[Out]# 111       Parallelweg  Eindhoven  
#[Out]# 112        Kerkstraat  Eindhoven  
#[Out]# 113       Molenstraat  Eindhoven  
#[Out]# 114     Poffertjesweg  Eindhoven  
#[Out]# 115     Poffertjesweg  Eindhoven  
#[Out]# 116     Poffertjesweg  Eindhoven  
#[Out]# 117     Poffertjesweg  Eindhoven  
#[Out]# 118       Molenstraat  Eindhoven  
#[Out]# 119  Wilhelminastraat  Eindhoven  
#[Out]# 120       Molenstraat  Eindhoven  
#[Out]# 121  Wilhelminastraat  Eindhoven  
#[Out]# 122        Kerkstraat  Eindhoven  
#[Out]# 123       Nieuwstraat  Eindhoven  
#[Out]# 124       Nieuwstraat  Eindhoven  
#[Out]# 125     Julianastraat  Eindhoven  
#[Out]# 126          Molenweg  Eindhoven  
#[Out]# 127       Dorpsstraat  Eindhoven  
#[Out]# 128       Nieuwstraat  Eindhoven  
#[Out]# 129     Julianastraat  Eindhoven  
#[Out]# 130       Parallelweg  Eindhoven  
#[Out]# 131       Molenstraat  Eindhoven  
#[Out]# 132     Poffertjesweg  Eindhoven  
#[Out]# 
#[Out]# [133 rows x 11 columns]
# Tue, 08 Dec 2020 14:27:52
query4_5 = '''
    SELECT cId,s.city AS sCity
    FROM purchase AS P,store AS S
    WHERE P.sId = S.sId AND S.city = 'Eindhoven'
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID      sCity
#[Out]# 0      1  Eindhoven
#[Out]# 1      1  Eindhoven
#[Out]# 2      2  Eindhoven
#[Out]# 3      2  Eindhoven
#[Out]# 4      3  Eindhoven
#[Out]# 5      4  Eindhoven
#[Out]# 6      4  Eindhoven
#[Out]# 7      5  Eindhoven
#[Out]# 8      5  Eindhoven
#[Out]# 9      5  Eindhoven
#[Out]# 10     7  Eindhoven
#[Out]# 11    13  Eindhoven
#[Out]# 12    13  Eindhoven
#[Out]# 13    13  Eindhoven
#[Out]# 14    13  Eindhoven
#[Out]# 15    13  Eindhoven
#[Out]# 16    13  Eindhoven
#[Out]# 17    16  Eindhoven
#[Out]# 18    24  Eindhoven
#[Out]# 19    24  Eindhoven
#[Out]# 20    25  Eindhoven
#[Out]# 21    27  Eindhoven
#[Out]# 22    30  Eindhoven
#[Out]# 23    30  Eindhoven
#[Out]# 24    31  Eindhoven
#[Out]# 25    33  Eindhoven
#[Out]# 26    33  Eindhoven
#[Out]# 27    33  Eindhoven
#[Out]# 28    33  Eindhoven
#[Out]# 29    33  Eindhoven
#[Out]# ..   ...        ...
#[Out]# 103  169  Eindhoven
#[Out]# 104  170  Eindhoven
#[Out]# 105  171  Eindhoven
#[Out]# 106  176  Eindhoven
#[Out]# 107  176  Eindhoven
#[Out]# 108  176  Eindhoven
#[Out]# 109  178  Eindhoven
#[Out]# 110  179  Eindhoven
#[Out]# 111  180  Eindhoven
#[Out]# 112  182  Eindhoven
#[Out]# 113  182  Eindhoven
#[Out]# 114  185  Eindhoven
#[Out]# 115  186  Eindhoven
#[Out]# 116  188  Eindhoven
#[Out]# 117  188  Eindhoven
#[Out]# 118  190  Eindhoven
#[Out]# 119  190  Eindhoven
#[Out]# 120  190  Eindhoven
#[Out]# 121  190  Eindhoven
#[Out]# 122  190  Eindhoven
#[Out]# 123  190  Eindhoven
#[Out]# 124  190  Eindhoven
#[Out]# 125  190  Eindhoven
#[Out]# 126  190  Eindhoven
#[Out]# 127  190  Eindhoven
#[Out]# 128  190  Eindhoven
#[Out]# 129  190  Eindhoven
#[Out]# 130  190  Eindhoven
#[Out]# 131  190  Eindhoven
#[Out]# 132  190  Eindhoven
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 08 Dec 2020 14:28:34
query4_5 = '''
    SELECT cId,s.city AS sCity
    FROM purchase AS P,store AS S
    WHERE P.sId = S.sId --AND S.city = 'Eindhoven'
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID      sCity
#[Out]# 0      0  Rotterdam
#[Out]# 1      1      Breda
#[Out]# 2      1  Rotterdam
#[Out]# 3      1  Eindhoven
#[Out]# 4      1    Utrecht
#[Out]# 5      1    Utrecht
#[Out]# 6      1  Rotterdam
#[Out]# 7      1  Eindhoven
#[Out]# 8      2  Eindhoven
#[Out]# 9      2  Eindhoven
#[Out]# 10     2    Tilburg
#[Out]# 11     2    Utrecht
#[Out]# 12     2  Rotterdam
#[Out]# 13     3    Utrecht
#[Out]# 14     3  Eindhoven
#[Out]# 15     3  Amsterdam
#[Out]# 16     4  Eindhoven
#[Out]# 17     4  Rotterdam
#[Out]# 18     4    Utrecht
#[Out]# 19     4    Tilburg
#[Out]# 20     4  Eindhoven
#[Out]# 21     4    Utrecht
#[Out]# 22     5  Eindhoven
#[Out]# 23     5  Eindhoven
#[Out]# 24     5      Breda
#[Out]# 25     5    Utrecht
#[Out]# 26     5  Rotterdam
#[Out]# 27     5  Eindhoven
#[Out]# 28     7  Rotterdam
#[Out]# 29     7  Eindhoven
#[Out]# ..   ...        ...
#[Out]# 479  190  Amsterdam
#[Out]# 480  190    Utrecht
#[Out]# 481  190  Eindhoven
#[Out]# 482  190  Eindhoven
#[Out]# 483  190  Rotterdam
#[Out]# 484  190  Eindhoven
#[Out]# 485  190  Rotterdam
#[Out]# 486  190  Rotterdam
#[Out]# 487  190  Amsterdam
#[Out]# 488  190    Utrecht
#[Out]# 489  190    Utrecht
#[Out]# 490  190    Tilburg
#[Out]# 491  190  Rotterdam
#[Out]# 492  190  Rotterdam
#[Out]# 493  190    Tilburg
#[Out]# 494  190  Rotterdam
#[Out]# 495  190      Breda
#[Out]# 496  190    Utrecht
#[Out]# 497  190  Eindhoven
#[Out]# 498  190    Utrecht
#[Out]# 499  190  Eindhoven
#[Out]# 500  190      Breda
#[Out]# 501  190  Eindhoven
#[Out]# 502  190  Eindhoven
#[Out]# 503  190  Rotterdam
#[Out]# 504  190      Breda
#[Out]# 505  190      Breda
#[Out]# 506  190      Breda
#[Out]# 507  190  Eindhoven
#[Out]# 508  190        Oss
#[Out]# 
#[Out]# [509 rows x 2 columns]
# Tue, 08 Dec 2020 14:29:26
query4_5 = '''
    SELECT cId,s.city AS sCity, C.city AS Ccity
    FROM purchase AS P,store AS S, customer AS C
    WHERE P.sId = S.sId AND C.cId = P.cID--AND S.city = 'Eindhoven'
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 14:29:53
query4_5 = '''
    SELECT cId,s.city AS sCity, C.city AS Ccity
    FROM purchase AS P,store AS S, customer AS C
    WHERE P.sId = S.sId AND C.cID = P.cID--AND S.city = 'Eindhoven'
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 14:30:08
query4_5 = '''
    SELECT P.cId,s.city AS sCity, C.city AS Ccity
    FROM purchase AS P,store AS S, customer AS C
    WHERE P.sId = S.sId AND C.cID = P.cID--AND S.city = 'Eindhoven'
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID      sCity      Ccity
#[Out]# 0      0  Rotterdam    Utrecht
#[Out]# 1      1      Breda      Breda
#[Out]# 2      1  Rotterdam      Breda
#[Out]# 3      1  Eindhoven      Breda
#[Out]# 4      1    Utrecht      Breda
#[Out]# 5      1    Utrecht      Breda
#[Out]# 6      1  Rotterdam      Breda
#[Out]# 7      1  Eindhoven      Breda
#[Out]# 8      2  Eindhoven  Amsterdam
#[Out]# 9      2  Eindhoven  Amsterdam
#[Out]# 10     2    Tilburg  Amsterdam
#[Out]# 11     2    Utrecht  Amsterdam
#[Out]# 12     2  Rotterdam  Amsterdam
#[Out]# 13     3    Utrecht      Breda
#[Out]# 14     3  Eindhoven      Breda
#[Out]# 15     3  Amsterdam      Breda
#[Out]# 16     4  Eindhoven  Amsterdam
#[Out]# 17     4  Rotterdam  Amsterdam
#[Out]# 18     4    Utrecht  Amsterdam
#[Out]# 19     4    Tilburg  Amsterdam
#[Out]# 20     4  Eindhoven  Amsterdam
#[Out]# 21     4    Utrecht  Amsterdam
#[Out]# 22     5  Eindhoven    Utrecht
#[Out]# 23     5  Eindhoven    Utrecht
#[Out]# 24     5      Breda    Utrecht
#[Out]# 25     5    Utrecht    Utrecht
#[Out]# 26     5  Rotterdam    Utrecht
#[Out]# 27     5  Eindhoven    Utrecht
#[Out]# 28     7  Rotterdam  Eindhoven
#[Out]# 29     7  Eindhoven  Eindhoven
#[Out]# ..   ...        ...        ...
#[Out]# 479  190  Amsterdam    Utrecht
#[Out]# 480  190    Utrecht    Utrecht
#[Out]# 481  190  Eindhoven    Utrecht
#[Out]# 482  190  Eindhoven    Utrecht
#[Out]# 483  190  Rotterdam    Utrecht
#[Out]# 484  190  Eindhoven    Utrecht
#[Out]# 485  190  Rotterdam    Utrecht
#[Out]# 486  190  Rotterdam    Utrecht
#[Out]# 487  190  Amsterdam    Utrecht
#[Out]# 488  190    Utrecht    Utrecht
#[Out]# 489  190    Utrecht    Utrecht
#[Out]# 490  190    Tilburg    Utrecht
#[Out]# 491  190  Rotterdam    Utrecht
#[Out]# 492  190  Rotterdam    Utrecht
#[Out]# 493  190    Tilburg    Utrecht
#[Out]# 494  190  Rotterdam    Utrecht
#[Out]# 495  190      Breda    Utrecht
#[Out]# 496  190    Utrecht    Utrecht
#[Out]# 497  190  Eindhoven    Utrecht
#[Out]# 498  190    Utrecht    Utrecht
#[Out]# 499  190  Eindhoven    Utrecht
#[Out]# 500  190      Breda    Utrecht
#[Out]# 501  190  Eindhoven    Utrecht
#[Out]# 502  190  Eindhoven    Utrecht
#[Out]# 503  190  Rotterdam    Utrecht
#[Out]# 504  190      Breda    Utrecht
#[Out]# 505  190      Breda    Utrecht
#[Out]# 506  190      Breda    Utrecht
#[Out]# 507  190  Eindhoven    Utrecht
#[Out]# 508  190        Oss    Utrecht
#[Out]# 
#[Out]# [509 rows x 3 columns]
# Tue, 08 Dec 2020 14:31:30
query4_4 = '''
    SELECT * FROM customer
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID     cName                street       city
#[Out]# 0      0      Noah             Koestraat    Utrecht
#[Out]# 1      1       Sem      Rozemarijnstraat      Breda
#[Out]# 2      2     Lucas      Oude Leliestraat  Amsterdam
#[Out]# 3      3      Finn         Stationsplein      Breda
#[Out]# 4      4      Daan          Kalverstraat  Amsterdam
#[Out]# 5      5      Levi        Gasthuisstraat    Utrecht
#[Out]# 6      6     Milan           Parallelweg    Utrecht
#[Out]# 7      7      Bram          Schoolstraat  Eindhoven
#[Out]# 8      8      Liam         Rijsbergseweg      Breda
#[Out]# 9      9    Thomas           Parallelweg  Amsterdam
#[Out]# 10    10       Sam           Langestraat    Tilburg
#[Out]# 11    11     Thijs             Koestraat    Tilburg
#[Out]# 12    12      Adam           Nieuwstraat  Eindhoven
#[Out]# 13    13     James       Sint Annastraat      Breda
#[Out]# 14    14       Max             Eikenlaan    Tilburg
#[Out]# 15    15      Noud          Koningshoeve    Tilburg
#[Out]# 16    16    Julian  Prins Bernhardstraat  Eindhoven
#[Out]# 17    17       Dex          Kasteeldreef    Tilburg
#[Out]# 18    18      Hugo          Kasteeldreef    Tilburg
#[Out]# 19    19      Lars         Rijsbergseweg      Breda
#[Out]# 20    20      Gijs            Heiligeweg  Amsterdam
#[Out]# 21    21  Benjamin           Stationsweg    Tilburg
#[Out]# 22    22      Mats           Molenstraat  Eindhoven
#[Out]# 23    23       Jan       Sint Annastraat      Breda
#[Out]# 24    24      Luca          Kasteeldreef    Tilburg
#[Out]# 25    25     Mason          Keizerstraat  Rotterdam
#[Out]# 26    26    Jayden          Schoolstraat  Eindhoven
#[Out]# 27    27       Tim             Koestraat    Utrecht
#[Out]# 28    28      Siem           Langestraat    Tilburg
#[Out]# 29    29     Ruben              Hofplein  Rotterdam
#[Out]# ..   ...       ...                   ...        ...
#[Out]# 160  160      Lara           Langestraat    Tilburg
#[Out]# 161  161     Floor             Eikenlaan    Tilburg
#[Out]# 162  162     Elena            Bergselaan  Rotterdam
#[Out]# 163  163      Cato          Kastanjelaan    Tilburg
#[Out]# 164  164       Evy      Rozemarijnstraat      Breda
#[Out]# 165  165     Hanna             Eikenlaan    Tilburg
#[Out]# 166  166   Rosalie           Stationsweg  Eindhoven
#[Out]# 167  167    Veerle        Ginnekenstraat      Breda
#[Out]# 168  168      Kiki          Keizerstraat  Rotterdam
#[Out]# 169  169      Lily        Gasthuisstraat    Utrecht
#[Out]# 170  170      Iris          Kastanjelaan  Eindhoven
#[Out]# 171  171     Tessa           Haringvliet  Rotterdam
#[Out]# 172  172      Lana             Eikenlaan    Tilburg
#[Out]# 173  173     Livia      Vierwindenstraat      Breda
#[Out]# 174  174      Romy           Parallelweg  Eindhoven
#[Out]# 175  175       Sam             Bredalaan  Eindhoven
#[Out]# 176  176     Amira           Parallelweg  Amsterdam
#[Out]# 177  177     Eline          Kalverstraat  Amsterdam
#[Out]# 178  178      Elif           Parallelweg    Utrecht
#[Out]# 179  179      Juul        Wilhelminapark    Tilburg
#[Out]# 180  180     Merel          Kalverstraat  Amsterdam
#[Out]# 181  181      Liva           Fredriklaan  Eindhoven
#[Out]# 182  182   Johanna         Beatrixstraat  Eindhoven
#[Out]# 183  183     Nikki         Julianastraat    Utrecht
#[Out]# 184  184     Wilko          Onbekendeweg  Eindhoven
#[Out]# 185  185      Nick                Verweg  Eindhoven
#[Out]# 186  186    Angela              Dichtweg  Eindhoven
#[Out]# 187  188      Pino            Maanstraat  Rotterdam
#[Out]# 188  189      Koen              Akkerweg        Oss
#[Out]# 189  190    Kostas              Eindeweg    Utrecht
#[Out]# 
#[Out]# [190 rows x 4 columns]
# Tue, 08 Dec 2020 14:33:36
query4_4 = '''
    SELECT city FROM customer
'''

pd.read_sql_query(query4_4, conn)
#[Out]#           city
#[Out]# 0      Utrecht
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3        Breda
#[Out]# 4    Amsterdam
#[Out]# 5      Utrecht
#[Out]# 6      Utrecht
#[Out]# 7    Eindhoven
#[Out]# 8        Breda
#[Out]# 9    Amsterdam
#[Out]# 10     Tilburg
#[Out]# 11     Tilburg
#[Out]# 12   Eindhoven
#[Out]# 13       Breda
#[Out]# 14     Tilburg
#[Out]# 15     Tilburg
#[Out]# 16   Eindhoven
#[Out]# 17     Tilburg
#[Out]# 18     Tilburg
#[Out]# 19       Breda
#[Out]# 20   Amsterdam
#[Out]# 21     Tilburg
#[Out]# 22   Eindhoven
#[Out]# 23       Breda
#[Out]# 24     Tilburg
#[Out]# 25   Rotterdam
#[Out]# 26   Eindhoven
#[Out]# 27     Utrecht
#[Out]# 28     Tilburg
#[Out]# 29   Rotterdam
#[Out]# ..         ...
#[Out]# 160    Tilburg
#[Out]# 161    Tilburg
#[Out]# 162  Rotterdam
#[Out]# 163    Tilburg
#[Out]# 164      Breda
#[Out]# 165    Tilburg
#[Out]# 166  Eindhoven
#[Out]# 167      Breda
#[Out]# 168  Rotterdam
#[Out]# 169    Utrecht
#[Out]# 170  Eindhoven
#[Out]# 171  Rotterdam
#[Out]# 172    Tilburg
#[Out]# 173      Breda
#[Out]# 174  Eindhoven
#[Out]# 175  Eindhoven
#[Out]# 176  Amsterdam
#[Out]# 177  Amsterdam
#[Out]# 178    Utrecht
#[Out]# 179    Tilburg
#[Out]# 180  Amsterdam
#[Out]# 181  Eindhoven
#[Out]# 182  Eindhoven
#[Out]# 183    Utrecht
#[Out]# 184  Eindhoven
#[Out]# 185  Eindhoven
#[Out]# 186  Eindhoven
#[Out]# 187  Rotterdam
#[Out]# 188        Oss
#[Out]# 189    Utrecht
#[Out]# 
#[Out]# [190 rows x 1 columns]
# Tue, 08 Dec 2020 14:34:47
query4_5 = '''
    SELECT P.cId,s.city AS sCity, C.city AS Ccity, P.pID
    FROM purchase AS P,store AS S, customer AS C
    WHERE P.sId = S.sId AND C.cID = P.cID
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID      sCity      Ccity  pID
#[Out]# 0      0  Rotterdam    Utrecht   10
#[Out]# 1      1      Breda      Breda   14
#[Out]# 2      1  Rotterdam      Breda   16
#[Out]# 3      1  Eindhoven      Breda    9
#[Out]# 4      1    Utrecht      Breda   25
#[Out]# 5      1    Utrecht      Breda   26
#[Out]# 6      1  Rotterdam      Breda   11
#[Out]# 7      1  Eindhoven      Breda   27
#[Out]# 8      2  Eindhoven  Amsterdam   20
#[Out]# 9      2  Eindhoven  Amsterdam    9
#[Out]# 10     2    Tilburg  Amsterdam    4
#[Out]# 11     2    Utrecht  Amsterdam   13
#[Out]# 12     2  Rotterdam  Amsterdam   22
#[Out]# 13     3    Utrecht      Breda   14
#[Out]# 14     3  Eindhoven      Breda   26
#[Out]# 15     3  Amsterdam      Breda    9
#[Out]# 16     4  Eindhoven  Amsterdam    8
#[Out]# 17     4  Rotterdam  Amsterdam   27
#[Out]# 18     4    Utrecht  Amsterdam   12
#[Out]# 19     4    Tilburg  Amsterdam    6
#[Out]# 20     4  Eindhoven  Amsterdam   13
#[Out]# 21     4    Utrecht  Amsterdam   26
#[Out]# 22     5  Eindhoven    Utrecht   14
#[Out]# 23     5  Eindhoven    Utrecht   28
#[Out]# 24     5      Breda    Utrecht    6
#[Out]# 25     5    Utrecht    Utrecht   22
#[Out]# 26     5  Rotterdam    Utrecht   16
#[Out]# 27     5  Eindhoven    Utrecht   19
#[Out]# 28     7  Rotterdam  Eindhoven   19
#[Out]# 29     7  Eindhoven  Eindhoven    2
#[Out]# ..   ...        ...        ...  ...
#[Out]# 479  190  Amsterdam    Utrecht   28
#[Out]# 480  190    Utrecht    Utrecht   27
#[Out]# 481  190  Eindhoven    Utrecht    5
#[Out]# 482  190  Eindhoven    Utrecht   28
#[Out]# 483  190  Rotterdam    Utrecht    7
#[Out]# 484  190  Eindhoven    Utrecht    0
#[Out]# 485  190  Rotterdam    Utrecht   11
#[Out]# 486  190  Rotterdam    Utrecht    6
#[Out]# 487  190  Amsterdam    Utrecht   19
#[Out]# 488  190    Utrecht    Utrecht   17
#[Out]# 489  190    Utrecht    Utrecht    9
#[Out]# 490  190    Tilburg    Utrecht   11
#[Out]# 491  190  Rotterdam    Utrecht   22
#[Out]# 492  190  Rotterdam    Utrecht   17
#[Out]# 493  190    Tilburg    Utrecht   20
#[Out]# 494  190  Rotterdam    Utrecht   11
#[Out]# 495  190      Breda    Utrecht   21
#[Out]# 496  190    Utrecht    Utrecht   23
#[Out]# 497  190  Eindhoven    Utrecht   23
#[Out]# 498  190    Utrecht    Utrecht    8
#[Out]# 499  190  Eindhoven    Utrecht    0
#[Out]# 500  190      Breda    Utrecht    8
#[Out]# 501  190  Eindhoven    Utrecht   11
#[Out]# 502  190  Eindhoven    Utrecht   15
#[Out]# 503  190  Rotterdam    Utrecht    2
#[Out]# 504  190      Breda    Utrecht   17
#[Out]# 505  190      Breda    Utrecht    5
#[Out]# 506  190      Breda    Utrecht   19
#[Out]# 507  190  Eindhoven    Utrecht    9
#[Out]# 508  190        Oss    Utrecht   18
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Tue, 08 Dec 2020 14:35:46
query4_5 = '''
    SELECT CPUNT(P.pID),C.city AS Ccity
    FROM purchase AS P,store AS S, customer AS C
    WHERE P.sId = S.sId AND C.cID = P.cID 
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 14:35:52
query4_5 = '''
    SELECT COUNT(P.pID),C.city AS Ccity
    FROM purchase AS P,store AS S, customer AS C
    WHERE P.sId = S.sId AND C.cID = P.cID 
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(P.pID)      Ccity
#[Out]# 0            76  Amsterdam
#[Out]# 1            67      Breda
#[Out]# 2            84  Eindhoven
#[Out]# 3             2        Oss
#[Out]# 4            68  Rotterdam
#[Out]# 5            90    Tilburg
#[Out]# 6           122    Utrecht
# Tue, 08 Dec 2020 14:36:22
query4_4 = '''
    SELECT city FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_4, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:36:40
query4_5 = '''
    SELECT COUNT(P.pID),C.city AS Ccity
    FROM purchase AS P,store AS S, customer AS C
    WHERE P.sId = S.sId AND C.cID = P.cID AND S.city = 'Eindhoven'
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(P.pID)      Ccity
#[Out]# 0            17  Amsterdam
#[Out]# 1            27      Breda
#[Out]# 2            24  Eindhoven
#[Out]# 3            16  Rotterdam
#[Out]# 4            18    Tilburg
#[Out]# 5            31    Utrecht
# Tue, 08 Dec 2020 14:36:54
query4_5 = '''
    SELECT COUNT(P.pID),C.city AS Ccity
    FROM purchase AS P,store AS S, customer AS C
    WHERE P.sId = S.sId AND C.cID = P.cID --AND S.city = 'Eindhoven'
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(P.pID)      Ccity
#[Out]# 0            76  Amsterdam
#[Out]# 1            67      Breda
#[Out]# 2            84  Eindhoven
#[Out]# 3             2        Oss
#[Out]# 4            68  Rotterdam
#[Out]# 5            90    Tilburg
#[Out]# 6           122    Utrecht
# Tue, 08 Dec 2020 14:38:17
query4_5 = '''
    SELECT COUNT(C.cId),C.city AS Ccity
    FROM purchase AS P,store AS S, customer AS C
    WHERE P.sId = S.sId AND C.cID = P.cID AND S.city = 'Eindhoven'
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(C.cId)      Ccity
#[Out]# 0            17  Amsterdam
#[Out]# 1            27      Breda
#[Out]# 2            24  Eindhoven
#[Out]# 3            16  Rotterdam
#[Out]# 4            18    Tilburg
#[Out]# 5            31    Utrecht
# Tue, 08 Dec 2020 14:38:56
query4_4 = '''
    SELECT COUNT(c.Cid),city FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 14:39:04
query4_4 = '''
    SELECT COUNT(cid),city FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    COUNT(cid)       city
#[Out]# 0          26  Amsterdam
#[Out]# 1          27      Breda
#[Out]# 2          33  Eindhoven
#[Out]# 3           1        Oss
#[Out]# 4          29  Rotterdam
#[Out]# 5          38    Tilburg
#[Out]# 6          36    Utrecht
# Tue, 08 Dec 2020 14:40:54
query4_5 = '''
    SELECT COUNT(C.cId),C.city AS Ccity
    FROM purchase AS P
    LEFT JOIN store AS S ON P.sId = S.sId 
    LEFT JOIN customer AS C ON C.cID = P.cID
    WHERE S.city = 'Eindhoven'
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(C.cId)      Ccity
#[Out]# 0            17  Amsterdam
#[Out]# 1            27      Breda
#[Out]# 2            24  Eindhoven
#[Out]# 3            16  Rotterdam
#[Out]# 4            18    Tilburg
#[Out]# 5            31    Utrecht
# Tue, 08 Dec 2020 14:41:18
query4_5 = '''
    SELECT COUNT(C.cId),C.city AS Ccity
    FROM purchase AS P
    LEFT JOIN store AS S ON P.sId = S.sId AND s.city = 'Eindhoven'
    LEFT JOIN customer AS C ON C.cID = P.cID
    WHERE 
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
# Tue, 08 Dec 2020 14:41:27
query4_5 = '''
    SELECT COUNT(C.cId),C.city AS Ccity
    FROM purchase AS P
    LEFT JOIN store AS S ON P.sId = S.sId AND s.city = 'Eindhoven'
    LEFT JOIN customer AS C ON C.cID = P.cID

    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(C.cId)      Ccity
#[Out]# 0            76  Amsterdam
#[Out]# 1            67      Breda
#[Out]# 2            84  Eindhoven
#[Out]# 3             2        Oss
#[Out]# 4            68  Rotterdam
#[Out]# 5            90    Tilburg
#[Out]# 6           122    Utrecht
# Tue, 08 Dec 2020 14:41:54
query4_5 = '''
    SELECT COUNT(C.cId),C.city AS Ccity
    FROM purchase AS P
    LEFT JOIN store AS S ON P.sId = S.sId 
    LEFT JOIN customer AS C ON C.cID = P.cID
    WHERE S.city = 'Eindhoven'
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(C.cId)      Ccity
#[Out]# 0            17  Amsterdam
#[Out]# 1            27      Breda
#[Out]# 2            24  Eindhoven
#[Out]# 3            16  Rotterdam
#[Out]# 4            18    Tilburg
#[Out]# 5            31    Utrecht
# Tue, 08 Dec 2020 14:42:44
query4_5 = '''
    SELECT COUNT(C.cId),C.city AS Ccity
    FROM purchase AS P
    LEFT JOIN store AS S ON S.sId = P.sId 
    LEFT JOIN customer AS C ON C.cID = P.cID
    WHERE S.city = 'Eindhoven'
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(C.cId)      Ccity
#[Out]# 0            17  Amsterdam
#[Out]# 1            27      Breda
#[Out]# 2            24  Eindhoven
#[Out]# 3            16  Rotterdam
#[Out]# 4            18    Tilburg
#[Out]# 5            31    Utrecht
# Tue, 08 Dec 2020 14:43:20
query4_5 = '''
    SELECT COUNT(C.cId),C.city AS Ccity
    FROM store AS S
    LEFT JOIN purchase AS P ON P.sId = S.sId
    LEFT JOIN customer AS C ON C.cID = P.cID
    WHERE S.city = 'Eindhoven'
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(C.cId)      Ccity
#[Out]# 0            17  Amsterdam
#[Out]# 1            27      Breda
#[Out]# 2            24  Eindhoven
#[Out]# 3            16  Rotterdam
#[Out]# 4            18    Tilburg
#[Out]# 5            31    Utrecht
# Tue, 08 Dec 2020 14:43:23
query4_5 = '''
    SELECT COUNT(C.cId),C.city AS Ccity
    FROM store AS S
    LEFT JOIN purchase AS P ON P.sId = S.sId
    LEFT JOIN customer AS C ON C.cID = P.cID
    WHERE S.city = 'Eindhoven'
    GROUP BY C.City
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(C.cId)      Ccity
#[Out]# 0            17  Amsterdam
#[Out]# 1            27      Breda
#[Out]# 2            24  Eindhoven
#[Out]# 3            16  Rotterdam
#[Out]# 4            18    Tilburg
#[Out]# 5            31    Utrecht
# Tue, 08 Dec 2020 14:47:31
query4_4 = '''
    SELECT city 
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_4, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:48:43
query4_4 = '''
    WITH allcities (city) AS (
    SELECT city 
    FROM customer
    GROUP BY city )
    
    SELECT * FROM allcities
'''

pd.read_sql_query(query4_4, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:50:15
query4_4 = '''
    WITH allcities (city) AS (
    SELECT city 
    FROM customer
    GROUP BY city )
    
    SELECT * 
    FROM allcities AS AC
    LEFT JOIN    ( SELECT COUNT(C.cId),C.city AS Ccity
    FROM store AS S
    LEFT JOIN purchase AS P ON P.sId = S.sId
    LEFT JOIN customer AS C ON C.cID = P.cID
    WHERE S.city = 'Eindhoven'
    GROUP BY C.City) AS CitiesXCustomers
    ON AC.city = CitiesXCustomers Ccity
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 14:50:54
query4_4 = '''
    WITH allcities (city) AS (
    SELECT city 
    FROM customer
    GROUP BY city )
    
    SELECT * 
    FROM allcities AS AC
    LEFT JOIN    ( SELECT COUNT(C.cId),C.city AS Ccity
                    FROM store AS S
                    LEFT JOIN purchase AS P ON P.sId = S.sId
                    LEFT JOIN customer AS C ON C.cID = P.cID
                    WHERE S.city = 'Eindhoven'
                    GROUP BY C.City) AS CitiesXCustomers
    ON AC.city = CitiesXCustomers.Ccity
'''

pd.read_sql_query(query4_4, conn)
#[Out]#         city  COUNT(C.cId)      Ccity
#[Out]# 0  Amsterdam          17.0  Amsterdam
#[Out]# 1      Breda          27.0      Breda
#[Out]# 2  Eindhoven          24.0  Eindhoven
#[Out]# 3        Oss           NaN       None
#[Out]# 4  Rotterdam          16.0  Rotterdam
#[Out]# 5    Tilburg          18.0    Tilburg
#[Out]# 6    Utrecht          31.0    Utrecht
# Tue, 08 Dec 2020 14:51:30
query4_4 = '''
    WITH allcities (city) AS (
    SELECT city 
    FROM customer
    GROUP BY city )
    
    SELECT AC.city,CustomerAmount
    FROM allcities AS AC
    LEFT JOIN    ( SELECT COUNT(C.cId) AS CustomerAmount,C.city AS Ccity
                    FROM store AS S
                    LEFT JOIN purchase AS P ON P.sId = S.sId
                    LEFT JOIN customer AS C ON C.cID = P.cID
                    WHERE S.city = 'Eindhoven'
                    GROUP BY C.City) AS CitiesXCustomers
    ON AC.city = CitiesXCustomers.Ccity
'''

pd.read_sql_query(query4_4, conn)
#[Out]#         city  CustomerAmount
#[Out]# 0  Amsterdam            17.0
#[Out]# 1      Breda            27.0
#[Out]# 2  Eindhoven            24.0
#[Out]# 3        Oss             NaN
#[Out]# 4  Rotterdam            16.0
#[Out]# 5    Tilburg            18.0
#[Out]# 6    Utrecht            31.0
# Tue, 08 Dec 2020 14:52:40
query4_4 = '''
    WITH allcities (city) AS (
    SELECT city 
    FROM customer
    GROUP BY city )
    
    SELECT AC.city,ISNULL(CustomerAmount,0) AS Customers
    FROM allcities AS AC
    LEFT JOIN    ( SELECT COUNT(C.cId) AS CustomerAmount,C.city AS Ccity
                    FROM store AS S
                    LEFT JOIN purchase AS P ON P.sId = S.sId
                    LEFT JOIN customer AS C ON C.cID = P.cID
                    WHERE S.city = 'Eindhoven'
                    GROUP BY C.City) AS CitiesXCustomers
    ON AC.city = CitiesXCustomers.Ccity
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 14:52:49
query4_4 = '''
    WITH allcities (city) AS (
    SELECT city 
    FROM customer
    GROUP BY city )
    
    SELECT AC.city,CustomerAmount
    FROM allcities AS AC
    LEFT JOIN    ( SELECT COUNT(C.cId) AS CustomerAmount,C.city AS Ccity
                    FROM store AS S
                    LEFT JOIN purchase AS P ON P.sId = S.sId
                    LEFT JOIN customer AS C ON C.cID = P.cID
                    WHERE S.city = 'Eindhoven'
                    GROUP BY C.City) AS CitiesXCustomers
    ON AC.city = CitiesXCustomers.Ccity
'''

pd.read_sql_query(query4_4, conn)
#[Out]#         city  CustomerAmount
#[Out]# 0  Amsterdam            17.0
#[Out]# 1      Breda            27.0
#[Out]# 2  Eindhoven            24.0
#[Out]# 3        Oss             NaN
#[Out]# 4  Rotterdam            16.0
#[Out]# 5    Tilburg            18.0
#[Out]# 6    Utrecht            31.0
# Tue, 08 Dec 2020 14:53:01
query4_5 = '''
    WITH allcities (city) AS (
    SELECT city 
    FROM customer
    GROUP BY city )
    
    SELECT AC.city,CustomerAmount
    FROM allcities AS AC
    LEFT JOIN    ( SELECT COUNT(C.cId) AS CustomerAmount,C.city AS Ccity
                    FROM store AS S
                    LEFT JOIN purchase AS P ON P.sId = S.sId
                    LEFT JOIN customer AS C ON C.cID = P.cID
                    WHERE S.city = 'Eindhoven'
                    GROUP BY C.City) AS CitiesXCustomers
    ON AC.city = CitiesXCustomers.Ccity
    
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  CustomerAmount
#[Out]# 0  Amsterdam            17.0
#[Out]# 1      Breda            27.0
#[Out]# 2  Eindhoven            24.0
#[Out]# 3        Oss             NaN
#[Out]# 4  Rotterdam            16.0
#[Out]# 5    Tilburg            18.0
#[Out]# 6    Utrecht            31.0
# Tue, 08 Dec 2020 15:40:22
query4_3 = '''
    SELECT sName
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1     Hoogvliet
#[Out]# 2         Jumbo
#[Out]# 3        Sligro
#[Out]# 4     Hoogvliet
#[Out]# 5        Sligro
#[Out]# 6          Coop
#[Out]# 7        Sligro
#[Out]# 8   Albert Hein
#[Out]# 9   Albert Hein
#[Out]# 10        Jumbo
#[Out]# 11  Albert Hein
#[Out]# 12         Lidl
#[Out]# 13         Coop
#[Out]# 14         Coop
#[Out]# 15         Lidl
#[Out]# 16         Lidl
#[Out]# 17    Hoogvliet
#[Out]# 18       Sligro
#[Out]# 19         Coop
#[Out]# 20        Jumbo
#[Out]# 21         Coop
#[Out]# 22         Lidl
#[Out]# 23         Dirk
#[Out]# 24  Albert Hein
#[Out]# 25  Albert Hein
#[Out]# 26    Hoogvliet
#[Out]# 27       Sligro
#[Out]# 28    Hoogvliet
#[Out]# 29       Sligro
#[Out]# ..          ...
#[Out]# 34         Coop
#[Out]# 35         Lidl
#[Out]# 36         Lidl
#[Out]# 37        Jumbo
#[Out]# 38    Hoogvliet
#[Out]# 39       Sligro
#[Out]# 40    Hoogvliet
#[Out]# 41  Albert Hein
#[Out]# 42       Sligro
#[Out]# 43         Coop
#[Out]# 44  Albert Hein
#[Out]# 45         Coop
#[Out]# 46         Lidl
#[Out]# 47         Coop
#[Out]# 48    Hoogvliet
#[Out]# 49    Hoogvliet
#[Out]# 50       Sligro
#[Out]# 51         Coop
#[Out]# 52         Lidl
#[Out]# 53         Coop
#[Out]# 54         Dirk
#[Out]# 55         Coop
#[Out]# 56        Jumbo
#[Out]# 57         Dirk
#[Out]# 58         Dirk
#[Out]# 59        Jumbo
#[Out]# 60         Lidl
#[Out]# 61         Lidl
#[Out]# 62        Jumbo
#[Out]# 63        Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Tue, 08 Dec 2020 15:41:54
query4_4 = '''
        SELECT * 
        FROM purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15
#[Out]# 17    17    4   10   27  2018-08-24         9   9.05
#[Out]# 18    18    4   53   12  2018-08-25         5  13.60
#[Out]# 19    19    4   21    6  2018-08-24         2   1.05
#[Out]# 20    20    4    7   13  2018-08-25         9   3.05
#[Out]# 21    21    4   44   26  2018-08-25         4   2.75
#[Out]# 22    22    5    4   14  2018-08-17         6   4.70
#[Out]# 23    23    5   36   28  2018-08-22         6   8.25
#[Out]# 24    24    5   55    6  2018-08-23         9   1.10
#[Out]# 25    25    5   51   22  2018-08-23         2   1.55
#[Out]# 26    26    5    6   16  2018-08-23         2   1.85
#[Out]# 27    27    5   17   19  2018-08-23         1   2.20
#[Out]# 28    28    7    3   19  2018-08-23         2   2.10
#[Out]# 29    29    7   12    2  2018-08-23         6   1.70
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 479  818  190   34   28  2018-08-20         4   2.80
#[Out]# 480  819  190   35   27  2018-08-15         5   0.50
#[Out]# 481  820  190   36    5  2018-08-23         3   2.55
#[Out]# 482  821  190   37   28  2018-08-15         4   0.65
#[Out]# 483  822  190   38    7  2018-08-24         4   0.70
#[Out]# 484  823  190   39    0  2018-08-25         4   3.70
#[Out]# 485  824  190   40   11  2018-08-15         2   3.50
#[Out]# 486  825  190   41    6  2018-08-15         5   2.95
#[Out]# 487  826  190   42   19  2018-08-22         5   2.75
#[Out]# 488  827  190   43   17  2018-08-17         7   1.50
#[Out]# 489  828  190   44    9  2018-08-18         5   0.85
#[Out]# 490  829  190   45   11  2018-08-19         2   3.55
#[Out]# 491  830  190   46   22  2018-08-25         4   2.60
#[Out]# 492  831  190   47   17  2018-08-17         4   3.25
#[Out]# 493  832  190   48   20  2018-08-26         6   4.30
#[Out]# 494  833  190   49   11  2018-08-17         3   3.05
#[Out]# 495  834  190   50   21  2018-08-22         6   4.05
#[Out]# 496  835  190   51   23  2018-08-19         1   1.50
#[Out]# 497  836  190   52   23  2018-08-15         5   2.50
#[Out]# 498  837  190   53    8  2018-08-18         4   3.95
#[Out]# 499  838  190   54    0  2018-08-25         6   3.50
#[Out]# 500  839  190   55    8  2018-08-18         7   2.95
#[Out]# 501  840  190   56   11  2018-08-15         4   1.60
#[Out]# 502  841  190   57   15  2018-08-22         5   3.25
#[Out]# 503  842  190   58    2  2018-08-19         7   0.75
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Tue, 08 Dec 2020 15:43:28
query4_4 = '''
        SELECT SUM(price) 
        FROM purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    SUM(price)
#[Out]# 0      1675.2
# Tue, 08 Dec 2020 15:43:44
query4_4 = '''
        SELECT SUM(price),date 
        FROM purchase
        GROUP BY date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     SUM(price)        date
#[Out]# 0        59.65  2018-08-15
#[Out]# 1        88.25  2018-08-16
#[Out]# 2       139.15  2018-08-17
#[Out]# 3       126.40  2018-08-18
#[Out]# 4       121.55  2018-08-19
#[Out]# 5       103.75  2018-08-20
#[Out]# 6        80.40  2018-08-21
#[Out]# 7       115.80  2018-08-22
#[Out]# 8       127.25  2018-08-23
#[Out]# 9       167.50  2018-08-24
#[Out]# 10      167.65  2018-08-25
#[Out]# 11      217.20  2018-08-26
#[Out]# 12      100.65  2018-08-27
#[Out]# 13       47.10  2018-08-28
#[Out]# 14       11.90  2018-08-29
#[Out]# 15        1.00  2018-09-20
# Tue, 08 Dec 2020 15:43:58
query4_4 = '''
        SELECT MAX(SUM(price)),date 
        FROM purchase
        GROUP BY date
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:44:05
query4_4 = '''
        SELECT SUM(price),date 
        FROM purchase
        GROUP BY date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     SUM(price)        date
#[Out]# 0        59.65  2018-08-15
#[Out]# 1        88.25  2018-08-16
#[Out]# 2       139.15  2018-08-17
#[Out]# 3       126.40  2018-08-18
#[Out]# 4       121.55  2018-08-19
#[Out]# 5       103.75  2018-08-20
#[Out]# 6        80.40  2018-08-21
#[Out]# 7       115.80  2018-08-22
#[Out]# 8       127.25  2018-08-23
#[Out]# 9       167.50  2018-08-24
#[Out]# 10      167.65  2018-08-25
#[Out]# 11      217.20  2018-08-26
#[Out]# 12      100.65  2018-08-27
#[Out]# 13       47.10  2018-08-28
#[Out]# 14       11.90  2018-08-29
#[Out]# 15        1.00  2018-09-20
# Tue, 08 Dec 2020 15:44:15
query4_4 = '''
        SELECT SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      SUM(price)        date  cID
#[Out]# 0          3.45  2018-08-15   21
#[Out]# 1          0.60  2018-08-15   30
#[Out]# 2          4.90  2018-08-15   37
#[Out]# 3          1.20  2018-08-15   42
#[Out]# 4          2.20  2018-08-15   59
#[Out]# 5         23.95  2018-08-15  108
#[Out]# 6          3.75  2018-08-15  167
#[Out]# 7         19.60  2018-08-15  190
#[Out]# 8          2.45  2018-08-16    2
#[Out]# 9          6.25  2018-08-16    8
#[Out]# 10         4.40  2018-08-16   18
#[Out]# 11         2.40  2018-08-16   21
#[Out]# 12         1.20  2018-08-16   27
#[Out]# 13         2.30  2018-08-16   33
#[Out]# 14        11.50  2018-08-16   40
#[Out]# 15         1.80  2018-08-16   45
#[Out]# 16         3.45  2018-08-16   55
#[Out]# 17         0.80  2018-08-16   57
#[Out]# 18         1.75  2018-08-16   59
#[Out]# 19         5.25  2018-08-16   66
#[Out]# 20         5.55  2018-08-16   80
#[Out]# 21         1.30  2018-08-16   96
#[Out]# 22         1.65  2018-08-16  162
#[Out]# 23         5.65  2018-08-16  168
#[Out]# 24         1.90  2018-08-16  169
#[Out]# 25        15.85  2018-08-16  170
#[Out]# 26        12.80  2018-08-16  190
#[Out]# 27         7.70  2018-08-17    2
#[Out]# 28         4.70  2018-08-17    5
#[Out]# 29        13.30  2018-08-17   13
#[Out]# ..          ...         ...  ...
#[Out]# 255        1.85  2018-08-27   16
#[Out]# 256        8.05  2018-08-27   22
#[Out]# 257        1.65  2018-08-27   27
#[Out]# 258        1.10  2018-08-27   28
#[Out]# 259        0.90  2018-08-27   31
#[Out]# 260       16.75  2018-08-27   33
#[Out]# 261        0.55  2018-08-27   58
#[Out]# 262        6.35  2018-08-27   67
#[Out]# 263        1.65  2018-08-27   68
#[Out]# 264        6.60  2018-08-27   91
#[Out]# 265        9.85  2018-08-27   92
#[Out]# 266        5.15  2018-08-27  110
#[Out]# 267        6.25  2018-08-27  157
#[Out]# 268        8.20  2018-08-27  163
#[Out]# 269        0.55  2018-08-27  169
#[Out]# 270        0.90  2018-08-27  172
#[Out]# 271        7.50  2018-08-27  178
#[Out]# 272        4.65  2018-08-27  180
#[Out]# 273        2.00  2018-08-27  181
#[Out]# 274        5.55  2018-08-27  190
#[Out]# 275        0.45  2018-08-28   22
#[Out]# 276        2.55  2018-08-28   25
#[Out]# 277        3.90  2018-08-28   31
#[Out]# 278       12.80  2018-08-28   39
#[Out]# 279        6.05  2018-08-28   69
#[Out]# 280        1.80  2018-08-28  157
#[Out]# 281        4.65  2018-08-28  169
#[Out]# 282       14.90  2018-08-28  182
#[Out]# 283       11.90  2018-08-29   39
#[Out]# 284        1.00  2018-09-20  188
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 15:44:36
query4_4 = '''
        SELECT SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
        order by Cid
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      SUM(price)        date  cID
#[Out]# 0          0.45  2018-08-22    0
#[Out]# 1         14.20  2018-08-20    1
#[Out]# 2         10.00  2018-08-21    1
#[Out]# 3          2.45  2018-08-16    2
#[Out]# 4          7.70  2018-08-17    2
#[Out]# 5          4.30  2018-08-18    3
#[Out]# 6          4.20  2018-08-19    3
#[Out]# 7         14.25  2018-08-24    4
#[Out]# 8         19.40  2018-08-25    4
#[Out]# 9          4.70  2018-08-17    5
#[Out]# 10         8.25  2018-08-22    5
#[Out]# 11         6.70  2018-08-23    5
#[Out]# 12         3.80  2018-08-23    7
#[Out]# 13         1.90  2018-08-24    7
#[Out]# 14        10.75  2018-08-25    7
#[Out]# 15         3.10  2018-08-26    7
#[Out]# 16         6.25  2018-08-16    8
#[Out]# 17         3.20  2018-08-27   10
#[Out]# 18         4.10  2018-08-25   11
#[Out]# 19        13.30  2018-08-17   13
#[Out]# 20         6.50  2018-08-25   13
#[Out]# 21         1.65  2018-08-26   13
#[Out]# 22         0.50  2018-08-27   13
#[Out]# 23         0.90  2018-08-27   15
#[Out]# 24         2.90  2018-08-18   16
#[Out]# 25        11.05  2018-08-19   16
#[Out]# 26         6.05  2018-08-24   16
#[Out]# 27         4.95  2018-08-25   16
#[Out]# 28         3.00  2018-08-26   16
#[Out]# 29         1.85  2018-08-27   16
#[Out]# ..          ...         ...  ...
#[Out]# 255        7.50  2018-08-27  178
#[Out]# 256       10.85  2018-08-22  179
#[Out]# 257        0.45  2018-08-23  179
#[Out]# 258        6.95  2018-08-24  179
#[Out]# 259        3.10  2018-08-26  180
#[Out]# 260        4.65  2018-08-27  180
#[Out]# 261        3.60  2018-08-24  181
#[Out]# 262        2.00  2018-08-27  181
#[Out]# 263        4.20  2018-08-23  182
#[Out]# 264       14.90  2018-08-28  182
#[Out]# 265        3.50  2018-08-20  184
#[Out]# 266        1.00  2018-08-20  185
#[Out]# 267        1.00  2018-08-21  186
#[Out]# 268        1.00  2018-08-20  188
#[Out]# 269        1.00  2018-09-20  188
#[Out]# 270        1.25  2018-08-25  189
#[Out]# 271        2.50  2018-08-26  189
#[Out]# 272       19.60  2018-08-15  190
#[Out]# 273       12.80  2018-08-16  190
#[Out]# 274       15.75  2018-08-17  190
#[Out]# 275       14.85  2018-08-18  190
#[Out]# 276       20.30  2018-08-19  190
#[Out]# 277       10.85  2018-08-20  190
#[Out]# 278        3.85  2018-08-21  190
#[Out]# 279       14.55  2018-08-22  190
#[Out]# 280       10.60  2018-08-23  190
#[Out]# 281        3.25  2018-08-24  190
#[Out]# 282        9.80  2018-08-25  190
#[Out]# 283       21.90  2018-08-26  190
#[Out]# 284        5.55  2018-08-27  190
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 15:44:52
query4_4 = '''
        SELECT SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
        order by SUM(price)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      SUM(price)        date  cID
#[Out]# 0          0.40  2018-08-21   72
#[Out]# 1          0.45  2018-08-22    0
#[Out]# 2          0.45  2018-08-23   77
#[Out]# 3          0.45  2018-08-23  179
#[Out]# 4          0.45  2018-08-28   22
#[Out]# 5          0.50  2018-08-17   55
#[Out]# 6          0.50  2018-08-27   13
#[Out]# 7          0.55  2018-08-27   58
#[Out]# 8          0.55  2018-08-27  169
#[Out]# 9          0.60  2018-08-15   30
#[Out]# 10         0.80  2018-08-16   57
#[Out]# 11         0.85  2018-08-18   85
#[Out]# 12         0.90  2018-08-22  176
#[Out]# 13         0.90  2018-08-27   15
#[Out]# 14         0.90  2018-08-27   31
#[Out]# 15         0.90  2018-08-27  172
#[Out]# 16         0.95  2018-08-25  128
#[Out]# 17         0.95  2018-08-22  163
#[Out]# 18         1.00  2018-08-18  167
#[Out]# 19         1.00  2018-08-19  135
#[Out]# 20         1.00  2018-08-20  185
#[Out]# 21         1.00  2018-08-20  188
#[Out]# 22         1.00  2018-08-21  186
#[Out]# 23         1.00  2018-08-22  118
#[Out]# 24         1.00  2018-08-22  126
#[Out]# 25         1.00  2018-09-20  188
#[Out]# 26         1.05  2018-08-21  162
#[Out]# 27         1.05  2018-08-25   59
#[Out]# 28         1.10  2018-08-24  129
#[Out]# 29         1.10  2018-08-27   28
#[Out]# ..          ...         ...  ...
#[Out]# 255       13.30  2018-08-17   13
#[Out]# 256       13.35  2018-08-18   30
#[Out]# 257       13.40  2018-08-24   82
#[Out]# 258       13.55  2018-08-26   91
#[Out]# 259       13.65  2018-08-18  109
#[Out]# 260       14.20  2018-08-20    1
#[Out]# 261       14.25  2018-08-24    4
#[Out]# 262       14.55  2018-08-22  190
#[Out]# 263       14.85  2018-08-18  190
#[Out]# 264       14.90  2018-08-28  182
#[Out]# 265       15.10  2018-08-17   86
#[Out]# 266       15.20  2018-08-25   52
#[Out]# 267       15.55  2018-08-21  113
#[Out]# 268       15.75  2018-08-17  190
#[Out]# 269       15.75  2018-08-19   51
#[Out]# 270       15.75  2018-08-26  159
#[Out]# 271       15.85  2018-08-16  170
#[Out]# 272       16.75  2018-08-27   33
#[Out]# 273       18.35  2018-08-22  162
#[Out]# 274       19.40  2018-08-25    4
#[Out]# 275       19.60  2018-08-15  190
#[Out]# 276       20.20  2018-08-17  123
#[Out]# 277       20.30  2018-08-19  190
#[Out]# 278       20.70  2018-08-20   24
#[Out]# 279       21.30  2018-08-23   82
#[Out]# 280       21.90  2018-08-26  190
#[Out]# 281       22.25  2018-08-24   71
#[Out]# 282       23.95  2018-08-15  108
#[Out]# 283       28.80  2018-08-26  124
#[Out]# 284       39.10  2018-08-26  161
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 15:44:56
query4_4 = '''
        SELECT SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
        order by SUM(price) desc
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      SUM(price)        date  cID
#[Out]# 0         39.10  2018-08-26  161
#[Out]# 1         28.80  2018-08-26  124
#[Out]# 2         23.95  2018-08-15  108
#[Out]# 3         22.25  2018-08-24   71
#[Out]# 4         21.90  2018-08-26  190
#[Out]# 5         21.30  2018-08-23   82
#[Out]# 6         20.70  2018-08-20   24
#[Out]# 7         20.30  2018-08-19  190
#[Out]# 8         20.20  2018-08-17  123
#[Out]# 9         19.60  2018-08-15  190
#[Out]# 10        19.40  2018-08-25    4
#[Out]# 11        18.35  2018-08-22  162
#[Out]# 12        16.75  2018-08-27   33
#[Out]# 13        15.85  2018-08-16  170
#[Out]# 14        15.75  2018-08-17  190
#[Out]# 15        15.75  2018-08-19   51
#[Out]# 16        15.75  2018-08-26  159
#[Out]# 17        15.55  2018-08-21  113
#[Out]# 18        15.20  2018-08-25   52
#[Out]# 19        15.10  2018-08-17   86
#[Out]# 20        14.90  2018-08-28  182
#[Out]# 21        14.85  2018-08-18  190
#[Out]# 22        14.55  2018-08-22  190
#[Out]# 23        14.25  2018-08-24    4
#[Out]# 24        14.20  2018-08-20    1
#[Out]# 25        13.65  2018-08-18  109
#[Out]# 26        13.55  2018-08-26   91
#[Out]# 27        13.40  2018-08-24   82
#[Out]# 28        13.35  2018-08-18   30
#[Out]# 29        13.30  2018-08-17   13
#[Out]# ..          ...         ...  ...
#[Out]# 255        1.10  2018-08-24  129
#[Out]# 256        1.10  2018-08-27   28
#[Out]# 257        1.05  2018-08-21  162
#[Out]# 258        1.05  2018-08-25   59
#[Out]# 259        1.00  2018-08-18  167
#[Out]# 260        1.00  2018-08-19  135
#[Out]# 261        1.00  2018-08-20  185
#[Out]# 262        1.00  2018-08-20  188
#[Out]# 263        1.00  2018-08-21  186
#[Out]# 264        1.00  2018-08-22  118
#[Out]# 265        1.00  2018-08-22  126
#[Out]# 266        1.00  2018-09-20  188
#[Out]# 267        0.95  2018-08-22  163
#[Out]# 268        0.95  2018-08-25  128
#[Out]# 269        0.90  2018-08-22  176
#[Out]# 270        0.90  2018-08-27   15
#[Out]# 271        0.90  2018-08-27   31
#[Out]# 272        0.90  2018-08-27  172
#[Out]# 273        0.85  2018-08-18   85
#[Out]# 274        0.80  2018-08-16   57
#[Out]# 275        0.60  2018-08-15   30
#[Out]# 276        0.55  2018-08-27   58
#[Out]# 277        0.55  2018-08-27  169
#[Out]# 278        0.50  2018-08-17   55
#[Out]# 279        0.50  2018-08-27   13
#[Out]# 280        0.45  2018-08-22    0
#[Out]# 281        0.45  2018-08-23   77
#[Out]# 282        0.45  2018-08-23  179
#[Out]# 283        0.45  2018-08-28   22
#[Out]# 284        0.40  2018-08-21   72
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 15:45:05
query4_4 = '''
        SELECT TOP 1 SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
        order by SUM(price) desc
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:45:10
query4_4 = '''
        SELECT SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
        order by SUM(price) desc
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      SUM(price)        date  cID
#[Out]# 0         39.10  2018-08-26  161
#[Out]# 1         28.80  2018-08-26  124
#[Out]# 2         23.95  2018-08-15  108
#[Out]# 3         22.25  2018-08-24   71
#[Out]# 4         21.90  2018-08-26  190
#[Out]# 5         21.30  2018-08-23   82
#[Out]# 6         20.70  2018-08-20   24
#[Out]# 7         20.30  2018-08-19  190
#[Out]# 8         20.20  2018-08-17  123
#[Out]# 9         19.60  2018-08-15  190
#[Out]# 10        19.40  2018-08-25    4
#[Out]# 11        18.35  2018-08-22  162
#[Out]# 12        16.75  2018-08-27   33
#[Out]# 13        15.85  2018-08-16  170
#[Out]# 14        15.75  2018-08-17  190
#[Out]# 15        15.75  2018-08-19   51
#[Out]# 16        15.75  2018-08-26  159
#[Out]# 17        15.55  2018-08-21  113
#[Out]# 18        15.20  2018-08-25   52
#[Out]# 19        15.10  2018-08-17   86
#[Out]# 20        14.90  2018-08-28  182
#[Out]# 21        14.85  2018-08-18  190
#[Out]# 22        14.55  2018-08-22  190
#[Out]# 23        14.25  2018-08-24    4
#[Out]# 24        14.20  2018-08-20    1
#[Out]# 25        13.65  2018-08-18  109
#[Out]# 26        13.55  2018-08-26   91
#[Out]# 27        13.40  2018-08-24   82
#[Out]# 28        13.35  2018-08-18   30
#[Out]# 29        13.30  2018-08-17   13
#[Out]# ..          ...         ...  ...
#[Out]# 255        1.10  2018-08-24  129
#[Out]# 256        1.10  2018-08-27   28
#[Out]# 257        1.05  2018-08-21  162
#[Out]# 258        1.05  2018-08-25   59
#[Out]# 259        1.00  2018-08-18  167
#[Out]# 260        1.00  2018-08-19  135
#[Out]# 261        1.00  2018-08-20  185
#[Out]# 262        1.00  2018-08-20  188
#[Out]# 263        1.00  2018-08-21  186
#[Out]# 264        1.00  2018-08-22  118
#[Out]# 265        1.00  2018-08-22  126
#[Out]# 266        1.00  2018-09-20  188
#[Out]# 267        0.95  2018-08-22  163
#[Out]# 268        0.95  2018-08-25  128
#[Out]# 269        0.90  2018-08-22  176
#[Out]# 270        0.90  2018-08-27   15
#[Out]# 271        0.90  2018-08-27   31
#[Out]# 272        0.90  2018-08-27  172
#[Out]# 273        0.85  2018-08-18   85
#[Out]# 274        0.80  2018-08-16   57
#[Out]# 275        0.60  2018-08-15   30
#[Out]# 276        0.55  2018-08-27   58
#[Out]# 277        0.55  2018-08-27  169
#[Out]# 278        0.50  2018-08-17   55
#[Out]# 279        0.50  2018-08-27   13
#[Out]# 280        0.45  2018-08-22    0
#[Out]# 281        0.45  2018-08-23   77
#[Out]# 282        0.45  2018-08-23  179
#[Out]# 283        0.45  2018-08-28   22
#[Out]# 284        0.40  2018-08-21   72
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 15:48:42
query4_4 = '''
        SELECT TOP 1 SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:49:29
query4_4 = '''
        SELECT TOP (1) SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
        ORDER BY SUM(price) desc
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:49:39
query4_4 = '''
        SELECT TOP 1, SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
        ORDER BY SUM(price) desc
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:49:49
query4_4 = '''
        SELECT SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
        ORDER BY SUM(price) desc
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      SUM(price)        date  cID
#[Out]# 0         39.10  2018-08-26  161
#[Out]# 1         28.80  2018-08-26  124
#[Out]# 2         23.95  2018-08-15  108
#[Out]# 3         22.25  2018-08-24   71
#[Out]# 4         21.90  2018-08-26  190
#[Out]# 5         21.30  2018-08-23   82
#[Out]# 6         20.70  2018-08-20   24
#[Out]# 7         20.30  2018-08-19  190
#[Out]# 8         20.20  2018-08-17  123
#[Out]# 9         19.60  2018-08-15  190
#[Out]# 10        19.40  2018-08-25    4
#[Out]# 11        18.35  2018-08-22  162
#[Out]# 12        16.75  2018-08-27   33
#[Out]# 13        15.85  2018-08-16  170
#[Out]# 14        15.75  2018-08-17  190
#[Out]# 15        15.75  2018-08-19   51
#[Out]# 16        15.75  2018-08-26  159
#[Out]# 17        15.55  2018-08-21  113
#[Out]# 18        15.20  2018-08-25   52
#[Out]# 19        15.10  2018-08-17   86
#[Out]# 20        14.90  2018-08-28  182
#[Out]# 21        14.85  2018-08-18  190
#[Out]# 22        14.55  2018-08-22  190
#[Out]# 23        14.25  2018-08-24    4
#[Out]# 24        14.20  2018-08-20    1
#[Out]# 25        13.65  2018-08-18  109
#[Out]# 26        13.55  2018-08-26   91
#[Out]# 27        13.40  2018-08-24   82
#[Out]# 28        13.35  2018-08-18   30
#[Out]# 29        13.30  2018-08-17   13
#[Out]# ..          ...         ...  ...
#[Out]# 255        1.10  2018-08-24  129
#[Out]# 256        1.10  2018-08-27   28
#[Out]# 257        1.05  2018-08-21  162
#[Out]# 258        1.05  2018-08-25   59
#[Out]# 259        1.00  2018-08-18  167
#[Out]# 260        1.00  2018-08-19  135
#[Out]# 261        1.00  2018-08-20  185
#[Out]# 262        1.00  2018-08-20  188
#[Out]# 263        1.00  2018-08-21  186
#[Out]# 264        1.00  2018-08-22  118
#[Out]# 265        1.00  2018-08-22  126
#[Out]# 266        1.00  2018-09-20  188
#[Out]# 267        0.95  2018-08-22  163
#[Out]# 268        0.95  2018-08-25  128
#[Out]# 269        0.90  2018-08-22  176
#[Out]# 270        0.90  2018-08-27   15
#[Out]# 271        0.90  2018-08-27   31
#[Out]# 272        0.90  2018-08-27  172
#[Out]# 273        0.85  2018-08-18   85
#[Out]# 274        0.80  2018-08-16   57
#[Out]# 275        0.60  2018-08-15   30
#[Out]# 276        0.55  2018-08-27   58
#[Out]# 277        0.55  2018-08-27  169
#[Out]# 278        0.50  2018-08-17   55
#[Out]# 279        0.50  2018-08-27   13
#[Out]# 280        0.45  2018-08-22    0
#[Out]# 281        0.45  2018-08-23   77
#[Out]# 282        0.45  2018-08-23  179
#[Out]# 283        0.45  2018-08-28   22
#[Out]# 284        0.40  2018-08-21   72
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 15:53:13
query4_4 = '''
CREATE VIEW CustomersXPrice AS (
        SELECT SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId)
        
        SELECT * FROM CustomersXPrice
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:53:33
query4_4 = '''
CREATE VIEW CustomersXPrice AS 
        (SELECT SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId)
        
        SELECT * FROM CustomersXPrice
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:54:17
query4_4 = '''
CREATE VIEW CustomersXPrice AS 
        SELECT SUM(price),date,cId
        FROM purchase
        GROUP BY date,cId
        
        SELECT * FROM CustomersXPrice
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:54:56
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS 
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId
        
        SELECT * FROM CustomersXPrice
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:55:07
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId)
        
        SELECT * FROM CustomersXPrice
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      Price  CustomerId
#[Out]# 0     3.45          21
#[Out]# 1     0.60          30
#[Out]# 2     4.90          37
#[Out]# 3     1.20          42
#[Out]# 4     2.20          59
#[Out]# 5    23.95         108
#[Out]# 6     3.75         167
#[Out]# 7    19.60         190
#[Out]# 8     2.45           2
#[Out]# 9     6.25           8
#[Out]# 10    4.40          18
#[Out]# 11    2.40          21
#[Out]# 12    1.20          27
#[Out]# 13    2.30          33
#[Out]# 14   11.50          40
#[Out]# 15    1.80          45
#[Out]# 16    3.45          55
#[Out]# 17    0.80          57
#[Out]# 18    1.75          59
#[Out]# 19    5.25          66
#[Out]# 20    5.55          80
#[Out]# 21    1.30          96
#[Out]# 22    1.65         162
#[Out]# 23    5.65         168
#[Out]# 24    1.90         169
#[Out]# 25   15.85         170
#[Out]# 26   12.80         190
#[Out]# 27    7.70           2
#[Out]# 28    4.70           5
#[Out]# 29   13.30          13
#[Out]# ..     ...         ...
#[Out]# 255   1.85          16
#[Out]# 256   8.05          22
#[Out]# 257   1.65          27
#[Out]# 258   1.10          28
#[Out]# 259   0.90          31
#[Out]# 260  16.75          33
#[Out]# 261   0.55          58
#[Out]# 262   6.35          67
#[Out]# 263   1.65          68
#[Out]# 264   6.60          91
#[Out]# 265   9.85          92
#[Out]# 266   5.15         110
#[Out]# 267   6.25         157
#[Out]# 268   8.20         163
#[Out]# 269   0.55         169
#[Out]# 270   0.90         172
#[Out]# 271   7.50         178
#[Out]# 272   4.65         180
#[Out]# 273   2.00         181
#[Out]# 274   5.55         190
#[Out]# 275   0.45          22
#[Out]# 276   2.55          25
#[Out]# 277   3.90          31
#[Out]# 278  12.80          39
#[Out]# 279   6.05          69
#[Out]# 280   1.80         157
#[Out]# 281   4.65         169
#[Out]# 282  14.90         182
#[Out]# 283  11.90          39
#[Out]# 284   1.00         188
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 15:56:18
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId)

WITH MaxCustomersXprice (Price,CustomerId) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice
        
        SELECT * FROM MaxCustomersXprice
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:58:24
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price,CustomerId) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice
        
        SELECT * FROM MaxPrice
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:58:32
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price,CustomerId) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * FROM MaxPrice
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:58:44
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * FROM MaxPrice
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    Price
#[Out]# 0   39.1
# Tue, 08 Dec 2020 15:58:59
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * FROM CustomersXPrice
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      Price  CustomerId
#[Out]# 0     3.45          21
#[Out]# 1     0.60          30
#[Out]# 2     4.90          37
#[Out]# 3     1.20          42
#[Out]# 4     2.20          59
#[Out]# 5    23.95         108
#[Out]# 6     3.75         167
#[Out]# 7    19.60         190
#[Out]# 8     2.45           2
#[Out]# 9     6.25           8
#[Out]# 10    4.40          18
#[Out]# 11    2.40          21
#[Out]# 12    1.20          27
#[Out]# 13    2.30          33
#[Out]# 14   11.50          40
#[Out]# 15    1.80          45
#[Out]# 16    3.45          55
#[Out]# 17    0.80          57
#[Out]# 18    1.75          59
#[Out]# 19    5.25          66
#[Out]# 20    5.55          80
#[Out]# 21    1.30          96
#[Out]# 22    1.65         162
#[Out]# 23    5.65         168
#[Out]# 24    1.90         169
#[Out]# 25   15.85         170
#[Out]# 26   12.80         190
#[Out]# 27    7.70           2
#[Out]# 28    4.70           5
#[Out]# 29   13.30          13
#[Out]# ..     ...         ...
#[Out]# 255   1.85          16
#[Out]# 256   8.05          22
#[Out]# 257   1.65          27
#[Out]# 258   1.10          28
#[Out]# 259   0.90          31
#[Out]# 260  16.75          33
#[Out]# 261   0.55          58
#[Out]# 262   6.35          67
#[Out]# 263   1.65          68
#[Out]# 264   6.60          91
#[Out]# 265   9.85          92
#[Out]# 266   5.15         110
#[Out]# 267   6.25         157
#[Out]# 268   8.20         163
#[Out]# 269   0.55         169
#[Out]# 270   0.90         172
#[Out]# 271   7.50         178
#[Out]# 272   4.65         180
#[Out]# 273   2.00         181
#[Out]# 274   5.55         190
#[Out]# 275   0.45          22
#[Out]# 276   2.55          25
#[Out]# 277   3.90          31
#[Out]# 278  12.80          39
#[Out]# 279   6.05          69
#[Out]# 280   1.80         157
#[Out]# 281   4.65         169
#[Out]# 282  14.90         182
#[Out]# 283  11.90          39
#[Out]# 284   1.00         188
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 15:59:08
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId
        order by id desc),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * FROM CustomersXPrice
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:59:14
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId
        order by SUM(price) desc),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * FROM CustomersXPrice
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      Price  CustomerId
#[Out]# 0    39.10         161
#[Out]# 1    28.80         124
#[Out]# 2    23.95         108
#[Out]# 3    22.25          71
#[Out]# 4    21.90         190
#[Out]# 5    21.30          82
#[Out]# 6    20.70          24
#[Out]# 7    20.30         190
#[Out]# 8    20.20         123
#[Out]# 9    19.60         190
#[Out]# 10   19.40           4
#[Out]# 11   18.35         162
#[Out]# 12   16.75          33
#[Out]# 13   15.85         170
#[Out]# 14   15.75         190
#[Out]# 15   15.75          51
#[Out]# 16   15.75         159
#[Out]# 17   15.55         113
#[Out]# 18   15.20          52
#[Out]# 19   15.10          86
#[Out]# 20   14.90         182
#[Out]# 21   14.85         190
#[Out]# 22   14.55         190
#[Out]# 23   14.25           4
#[Out]# 24   14.20           1
#[Out]# 25   13.65         109
#[Out]# 26   13.55          91
#[Out]# 27   13.40          82
#[Out]# 28   13.35          30
#[Out]# 29   13.30          13
#[Out]# ..     ...         ...
#[Out]# 255   1.10         129
#[Out]# 256   1.10          28
#[Out]# 257   1.05         162
#[Out]# 258   1.05          59
#[Out]# 259   1.00         167
#[Out]# 260   1.00         135
#[Out]# 261   1.00         185
#[Out]# 262   1.00         188
#[Out]# 263   1.00         186
#[Out]# 264   1.00         118
#[Out]# 265   1.00         126
#[Out]# 266   1.00         188
#[Out]# 267   0.95         163
#[Out]# 268   0.95         128
#[Out]# 269   0.90         176
#[Out]# 270   0.90          15
#[Out]# 271   0.90          31
#[Out]# 272   0.90         172
#[Out]# 273   0.85          85
#[Out]# 274   0.80          57
#[Out]# 275   0.60          30
#[Out]# 276   0.55          58
#[Out]# 277   0.55         169
#[Out]# 278   0.50          55
#[Out]# 279   0.50          13
#[Out]# 280   0.45           0
#[Out]# 281   0.45          77
#[Out]# 282   0.45         179
#[Out]# 283   0.45          22
#[Out]# 284   0.40          72
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 15:59:26
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * FROM MaxPrice
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    Price
#[Out]# 0   39.1
# Tue, 08 Dec 2020 16:01:09
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * FROM customersxprice
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      Price  CustomerId
#[Out]# 0     3.45          21
#[Out]# 1     0.60          30
#[Out]# 2     4.90          37
#[Out]# 3     1.20          42
#[Out]# 4     2.20          59
#[Out]# 5    23.95         108
#[Out]# 6     3.75         167
#[Out]# 7    19.60         190
#[Out]# 8     2.45           2
#[Out]# 9     6.25           8
#[Out]# 10    4.40          18
#[Out]# 11    2.40          21
#[Out]# 12    1.20          27
#[Out]# 13    2.30          33
#[Out]# 14   11.50          40
#[Out]# 15    1.80          45
#[Out]# 16    3.45          55
#[Out]# 17    0.80          57
#[Out]# 18    1.75          59
#[Out]# 19    5.25          66
#[Out]# 20    5.55          80
#[Out]# 21    1.30          96
#[Out]# 22    1.65         162
#[Out]# 23    5.65         168
#[Out]# 24    1.90         169
#[Out]# 25   15.85         170
#[Out]# 26   12.80         190
#[Out]# 27    7.70           2
#[Out]# 28    4.70           5
#[Out]# 29   13.30          13
#[Out]# ..     ...         ...
#[Out]# 255   1.85          16
#[Out]# 256   8.05          22
#[Out]# 257   1.65          27
#[Out]# 258   1.10          28
#[Out]# 259   0.90          31
#[Out]# 260  16.75          33
#[Out]# 261   0.55          58
#[Out]# 262   6.35          67
#[Out]# 263   1.65          68
#[Out]# 264   6.60          91
#[Out]# 265   9.85          92
#[Out]# 266   5.15         110
#[Out]# 267   6.25         157
#[Out]# 268   8.20         163
#[Out]# 269   0.55         169
#[Out]# 270   0.90         172
#[Out]# 271   7.50         178
#[Out]# 272   4.65         180
#[Out]# 273   2.00         181
#[Out]# 274   5.55         190
#[Out]# 275   0.45          22
#[Out]# 276   2.55          25
#[Out]# 277   3.90          31
#[Out]# 278  12.80          39
#[Out]# 279   6.05          69
#[Out]# 280   1.80         157
#[Out]# 281   4.65         169
#[Out]# 282  14.90         182
#[Out]# 283  11.90          39
#[Out]# 284   1.00         188
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 16:01:55
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * 
        FROM customersxprice,maxprice
        
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      Price  CustomerId  Price
#[Out]# 0     3.45          21   39.1
#[Out]# 1     0.60          30   39.1
#[Out]# 2     4.90          37   39.1
#[Out]# 3     1.20          42   39.1
#[Out]# 4     2.20          59   39.1
#[Out]# 5    23.95         108   39.1
#[Out]# 6     3.75         167   39.1
#[Out]# 7    19.60         190   39.1
#[Out]# 8     2.45           2   39.1
#[Out]# 9     6.25           8   39.1
#[Out]# 10    4.40          18   39.1
#[Out]# 11    2.40          21   39.1
#[Out]# 12    1.20          27   39.1
#[Out]# 13    2.30          33   39.1
#[Out]# 14   11.50          40   39.1
#[Out]# 15    1.80          45   39.1
#[Out]# 16    3.45          55   39.1
#[Out]# 17    0.80          57   39.1
#[Out]# 18    1.75          59   39.1
#[Out]# 19    5.25          66   39.1
#[Out]# 20    5.55          80   39.1
#[Out]# 21    1.30          96   39.1
#[Out]# 22    1.65         162   39.1
#[Out]# 23    5.65         168   39.1
#[Out]# 24    1.90         169   39.1
#[Out]# 25   15.85         170   39.1
#[Out]# 26   12.80         190   39.1
#[Out]# 27    7.70           2   39.1
#[Out]# 28    4.70           5   39.1
#[Out]# 29   13.30          13   39.1
#[Out]# ..     ...         ...    ...
#[Out]# 255   1.85          16   39.1
#[Out]# 256   8.05          22   39.1
#[Out]# 257   1.65          27   39.1
#[Out]# 258   1.10          28   39.1
#[Out]# 259   0.90          31   39.1
#[Out]# 260  16.75          33   39.1
#[Out]# 261   0.55          58   39.1
#[Out]# 262   6.35          67   39.1
#[Out]# 263   1.65          68   39.1
#[Out]# 264   6.60          91   39.1
#[Out]# 265   9.85          92   39.1
#[Out]# 266   5.15         110   39.1
#[Out]# 267   6.25         157   39.1
#[Out]# 268   8.20         163   39.1
#[Out]# 269   0.55         169   39.1
#[Out]# 270   0.90         172   39.1
#[Out]# 271   7.50         178   39.1
#[Out]# 272   4.65         180   39.1
#[Out]# 273   2.00         181   39.1
#[Out]# 274   5.55         190   39.1
#[Out]# 275   0.45          22   39.1
#[Out]# 276   2.55          25   39.1
#[Out]# 277   3.90          31   39.1
#[Out]# 278  12.80          39   39.1
#[Out]# 279   6.05          69   39.1
#[Out]# 280   1.80         157   39.1
#[Out]# 281   4.65         169   39.1
#[Out]# 282  14.90         182   39.1
#[Out]# 283  11.90          39   39.1
#[Out]# 284   1.00         188   39.1
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 16:02:33
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * 
        FROM customersxprice,maxprice
        WHERE customersxprice.price = 0,75*(maxprice.price)
'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 16:02:43
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * 
        FROM customersxprice,maxprice

'''

pd.read_sql_query(query4_4, conn)
#[Out]#      Price  CustomerId  Price
#[Out]# 0     3.45          21   39.1
#[Out]# 1     0.60          30   39.1
#[Out]# 2     4.90          37   39.1
#[Out]# 3     1.20          42   39.1
#[Out]# 4     2.20          59   39.1
#[Out]# 5    23.95         108   39.1
#[Out]# 6     3.75         167   39.1
#[Out]# 7    19.60         190   39.1
#[Out]# 8     2.45           2   39.1
#[Out]# 9     6.25           8   39.1
#[Out]# 10    4.40          18   39.1
#[Out]# 11    2.40          21   39.1
#[Out]# 12    1.20          27   39.1
#[Out]# 13    2.30          33   39.1
#[Out]# 14   11.50          40   39.1
#[Out]# 15    1.80          45   39.1
#[Out]# 16    3.45          55   39.1
#[Out]# 17    0.80          57   39.1
#[Out]# 18    1.75          59   39.1
#[Out]# 19    5.25          66   39.1
#[Out]# 20    5.55          80   39.1
#[Out]# 21    1.30          96   39.1
#[Out]# 22    1.65         162   39.1
#[Out]# 23    5.65         168   39.1
#[Out]# 24    1.90         169   39.1
#[Out]# 25   15.85         170   39.1
#[Out]# 26   12.80         190   39.1
#[Out]# 27    7.70           2   39.1
#[Out]# 28    4.70           5   39.1
#[Out]# 29   13.30          13   39.1
#[Out]# ..     ...         ...    ...
#[Out]# 255   1.85          16   39.1
#[Out]# 256   8.05          22   39.1
#[Out]# 257   1.65          27   39.1
#[Out]# 258   1.10          28   39.1
#[Out]# 259   0.90          31   39.1
#[Out]# 260  16.75          33   39.1
#[Out]# 261   0.55          58   39.1
#[Out]# 262   6.35          67   39.1
#[Out]# 263   1.65          68   39.1
#[Out]# 264   6.60          91   39.1
#[Out]# 265   9.85          92   39.1
#[Out]# 266   5.15         110   39.1
#[Out]# 267   6.25         157   39.1
#[Out]# 268   8.20         163   39.1
#[Out]# 269   0.55         169   39.1
#[Out]# 270   0.90         172   39.1
#[Out]# 271   7.50         178   39.1
#[Out]# 272   4.65         180   39.1
#[Out]# 273   2.00         181   39.1
#[Out]# 274   5.55         190   39.1
#[Out]# 275   0.45          22   39.1
#[Out]# 276   2.55          25   39.1
#[Out]# 277   3.90          31   39.1
#[Out]# 278  12.80          39   39.1
#[Out]# 279   6.05          69   39.1
#[Out]# 280   1.80         157   39.1
#[Out]# 281   4.65         169   39.1
#[Out]# 282  14.90         182   39.1
#[Out]# 283  11.90          39   39.1
#[Out]# 284   1.00         188   39.1
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 16:02:54
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT 0,75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * 
        FROM customersxprice,maxprice

'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 16:03:01
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * 
        FROM customersxprice,maxprice

'''

pd.read_sql_query(query4_4, conn)
#[Out]#      Price  CustomerId  Price
#[Out]# 0     3.45          21   39.1
#[Out]# 1     0.60          30   39.1
#[Out]# 2     4.90          37   39.1
#[Out]# 3     1.20          42   39.1
#[Out]# 4     2.20          59   39.1
#[Out]# 5    23.95         108   39.1
#[Out]# 6     3.75         167   39.1
#[Out]# 7    19.60         190   39.1
#[Out]# 8     2.45           2   39.1
#[Out]# 9     6.25           8   39.1
#[Out]# 10    4.40          18   39.1
#[Out]# 11    2.40          21   39.1
#[Out]# 12    1.20          27   39.1
#[Out]# 13    2.30          33   39.1
#[Out]# 14   11.50          40   39.1
#[Out]# 15    1.80          45   39.1
#[Out]# 16    3.45          55   39.1
#[Out]# 17    0.80          57   39.1
#[Out]# 18    1.75          59   39.1
#[Out]# 19    5.25          66   39.1
#[Out]# 20    5.55          80   39.1
#[Out]# 21    1.30          96   39.1
#[Out]# 22    1.65         162   39.1
#[Out]# 23    5.65         168   39.1
#[Out]# 24    1.90         169   39.1
#[Out]# 25   15.85         170   39.1
#[Out]# 26   12.80         190   39.1
#[Out]# 27    7.70           2   39.1
#[Out]# 28    4.70           5   39.1
#[Out]# 29   13.30          13   39.1
#[Out]# ..     ...         ...    ...
#[Out]# 255   1.85          16   39.1
#[Out]# 256   8.05          22   39.1
#[Out]# 257   1.65          27   39.1
#[Out]# 258   1.10          28   39.1
#[Out]# 259   0.90          31   39.1
#[Out]# 260  16.75          33   39.1
#[Out]# 261   0.55          58   39.1
#[Out]# 262   6.35          67   39.1
#[Out]# 263   1.65          68   39.1
#[Out]# 264   6.60          91   39.1
#[Out]# 265   9.85          92   39.1
#[Out]# 266   5.15         110   39.1
#[Out]# 267   6.25         157   39.1
#[Out]# 268   8.20         163   39.1
#[Out]# 269   0.55         169   39.1
#[Out]# 270   0.90         172   39.1
#[Out]# 271   7.50         178   39.1
#[Out]# 272   4.65         180   39.1
#[Out]# 273   2.00         181   39.1
#[Out]# 274   5.55         190   39.1
#[Out]# 275   0.45          22   39.1
#[Out]# 276   2.55          25   39.1
#[Out]# 277   3.90          31   39.1
#[Out]# 278  12.80          39   39.1
#[Out]# 279   6.05          69   39.1
#[Out]# 280   1.80         157   39.1
#[Out]# 281   4.65         169   39.1
#[Out]# 282  14.90         182   39.1
#[Out]# 283  11.90          39   39.1
#[Out]# 284   1.00         188   39.1
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Tue, 08 Dec 2020 16:03:15
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT * 
        FROM maxprice

'''

pd.read_sql_query(query4_4, conn)
#[Out]#    Price
#[Out]# 0   39.1
# Tue, 08 Dec 2020 16:03:30
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price
        FROM maxprice AS MP

'''

pd.read_sql_query(query4_4, conn)
#[Out]#    Price
#[Out]# 0   39.1
# Tue, 08 Dec 2020 16:03:35
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price,075
        FROM maxprice AS MP

'''

pd.read_sql_query(query4_4, conn)
#[Out]#    Price  075
#[Out]# 0   39.1   75
# Tue, 08 Dec 2020 16:03:49
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price, 075*MP.Price
        FROM maxprice AS MP

'''

pd.read_sql_query(query4_4, conn)
#[Out]#    Price  075*MP.Price
#[Out]# 0   39.1        2932.5
# Tue, 08 Dec 2020 16:03:57
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price, 0.75*MP.Price
        FROM maxprice AS MP

'''

pd.read_sql_query(query4_4, conn)
#[Out]#    Price  0.75*MP.Price
#[Out]# 0   39.1         29.325
# Tue, 08 Dec 2020 16:04:21
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPrice (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price
        FROM maxprice AS MP

'''

pd.read_sql_query(query4_4, conn)
#[Out]#     Price
#[Out]# 0  29.325
# Tue, 08 Dec 2020 16:05:25
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPriceXThreeQuarters (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price,CP.price,Cp.customerId
        FROM MaxPriceXThreeQuarters AS MP,CustomersXPrice AS CP
        WHERE CP.price => MP.Price

'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 16:05:32
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPriceXThreeQuarters (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price,CP.price,Cp.customerId
        FROM MaxPriceXThreeQuarters AS MP,CustomersXPrice AS CP
        WHERE CP.price > MP.Price

'''

pd.read_sql_query(query4_4, conn)
#[Out]#     Price  Price  CustomerId
#[Out]# 0  29.325   39.1         161
# Tue, 08 Dec 2020 16:06:20
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPriceXThreeQuarters (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT CP.price,Cp.customerId
        FROM CustomersXPrice AS CP


'''

pd.read_sql_query(query4_4, conn)
#[Out]#      CP.price  Cp.customerId
#[Out]# 0        3.45             21
#[Out]# 1        0.60             30
#[Out]# 2        4.90             37
#[Out]# 3        1.20             42
#[Out]# 4        2.20             59
#[Out]# 5       23.95            108
#[Out]# 6        3.75            167
#[Out]# 7       19.60            190
#[Out]# 8        2.45              2
#[Out]# 9        6.25              8
#[Out]# 10       4.40             18
#[Out]# 11       2.40             21
#[Out]# 12       1.20             27
#[Out]# 13       2.30             33
#[Out]# 14      11.50             40
#[Out]# 15       1.80             45
#[Out]# 16       3.45             55
#[Out]# 17       0.80             57
#[Out]# 18       1.75             59
#[Out]# 19       5.25             66
#[Out]# 20       5.55             80
#[Out]# 21       1.30             96
#[Out]# 22       1.65            162
#[Out]# 23       5.65            168
#[Out]# 24       1.90            169
#[Out]# 25      15.85            170
#[Out]# 26      12.80            190
#[Out]# 27       7.70              2
#[Out]# 28       4.70              5
#[Out]# 29      13.30             13
#[Out]# ..        ...            ...
#[Out]# 255      1.85             16
#[Out]# 256      8.05             22
#[Out]# 257      1.65             27
#[Out]# 258      1.10             28
#[Out]# 259      0.90             31
#[Out]# 260     16.75             33
#[Out]# 261      0.55             58
#[Out]# 262      6.35             67
#[Out]# 263      1.65             68
#[Out]# 264      6.60             91
#[Out]# 265      9.85             92
#[Out]# 266      5.15            110
#[Out]# 267      6.25            157
#[Out]# 268      8.20            163
#[Out]# 269      0.55            169
#[Out]# 270      0.90            172
#[Out]# 271      7.50            178
#[Out]# 272      4.65            180
#[Out]# 273      2.00            181
#[Out]# 274      5.55            190
#[Out]# 275      0.45             22
#[Out]# 276      2.55             25
#[Out]# 277      3.90             31
#[Out]# 278     12.80             39
#[Out]# 279      6.05             69
#[Out]# 280      1.80            157
#[Out]# 281      4.65            169
#[Out]# 282     14.90            182
#[Out]# 283     11.90             39
#[Out]# 284      1.00            188
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 16:06:34
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId
        order by SUM(price) desc),

        MaxPriceXThreeQuarters (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT CP.price,Cp.customerId
        FROM CustomersXPrice AS CP


'''

pd.read_sql_query(query4_4, conn)
#[Out]#      CP.price  Cp.customerId
#[Out]# 0       39.10            161
#[Out]# 1       28.80            124
#[Out]# 2       23.95            108
#[Out]# 3       22.25             71
#[Out]# 4       21.90            190
#[Out]# 5       21.30             82
#[Out]# 6       20.70             24
#[Out]# 7       20.30            190
#[Out]# 8       20.20            123
#[Out]# 9       19.60            190
#[Out]# 10      19.40              4
#[Out]# 11      18.35            162
#[Out]# 12      16.75             33
#[Out]# 13      15.85            170
#[Out]# 14      15.75            190
#[Out]# 15      15.75             51
#[Out]# 16      15.75            159
#[Out]# 17      15.55            113
#[Out]# 18      15.20             52
#[Out]# 19      15.10             86
#[Out]# 20      14.90            182
#[Out]# 21      14.85            190
#[Out]# 22      14.55            190
#[Out]# 23      14.25              4
#[Out]# 24      14.20              1
#[Out]# 25      13.65            109
#[Out]# 26      13.55             91
#[Out]# 27      13.40             82
#[Out]# 28      13.35             30
#[Out]# 29      13.30             13
#[Out]# ..        ...            ...
#[Out]# 255      1.10            129
#[Out]# 256      1.10             28
#[Out]# 257      1.05            162
#[Out]# 258      1.05             59
#[Out]# 259      1.00            167
#[Out]# 260      1.00            135
#[Out]# 261      1.00            185
#[Out]# 262      1.00            188
#[Out]# 263      1.00            186
#[Out]# 264      1.00            118
#[Out]# 265      1.00            126
#[Out]# 266      1.00            188
#[Out]# 267      0.95            163
#[Out]# 268      0.95            128
#[Out]# 269      0.90            176
#[Out]# 270      0.90             15
#[Out]# 271      0.90             31
#[Out]# 272      0.90            172
#[Out]# 273      0.85             85
#[Out]# 274      0.80             57
#[Out]# 275      0.60             30
#[Out]# 276      0.55             58
#[Out]# 277      0.55            169
#[Out]# 278      0.50             55
#[Out]# 279      0.50             13
#[Out]# 280      0.45              0
#[Out]# 281      0.45             77
#[Out]# 282      0.45            179
#[Out]# 283      0.45             22
#[Out]# 284      0.40             72
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 16:06:58
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPriceXThreeQuarters (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price,CP.price,Cp.customerId
        FROM MaxPriceXThreeQuarters AS MP,CustomersXPrice AS CP
        WHERE CP.price > MP.Price

'''

pd.read_sql_query(query4_4, conn)
#[Out]#     Price  Price  CustomerId
#[Out]# 0  29.325   39.1         161
# Tue, 08 Dec 2020 16:07:16
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPriceXThreeQuarters (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price,CP.price,Cp.customerId
        FROM MaxPriceXThreeQuarters AS MP,CustomersXPrice AS CP
        WHERE CP.price >= MP.Price

'''

pd.read_sql_query(query4_4, conn)
#[Out]#     Price  Price  CustomerId
#[Out]# 0  29.325   39.1         161
# Tue, 08 Dec 2020 16:07:45
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPriceXThreeQuarters (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price,CP.price,Cp.customerId,c.Cname
        FROM MaxPriceXThreeQuarters AS MP,CustomersXPrice AS CP,customer AS C
        WHERE CP.price >= MP.Price AND C.cID = CP.cId

'''

pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 16:07:54
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPriceXThreeQuarters (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT MP.Price,CP.price,Cp.customerId,c.Cname
        FROM MaxPriceXThreeQuarters AS MP,CustomersXPrice AS CP,customer AS C
        WHERE CP.price >= MP.Price AND C.cID = CP.CustomerId

'''

pd.read_sql_query(query4_4, conn)
#[Out]#     Price  Price  CustomerId  cName
#[Out]# 0  29.325   39.1         161  Floor
# Tue, 08 Dec 2020 16:08:07
query4_4 = '''
WITH CustomersXPrice (Price,CustomerId) AS (
        SELECT SUM(price),cId
        FROM purchase
        GROUP BY date,cId),

        MaxPriceXThreeQuarters (Price) AS (
        SELECT 0.75*MAX(Price)
        FROM CustomersXPrice)
        
        SELECT c.Cname
        FROM MaxPriceXThreeQuarters AS MP,CustomersXPrice AS CP,customer AS C
        WHERE CP.price >= MP.Price AND C.cID = CP.CustomerId

'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 16:16:59
query4_3 = '''
    SELECT sName,city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 16:17:28
query4_3 = '''
    SELECT city
    FROM store
    GORUP BY city
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:17:34
query4_3 = '''
    SELECT city
    FROM store
    GROUP BY city
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 16:17:45
query4_3 = '''
    SELECT city
    FROM store
    GROUP BY city
    
    SELECT city
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:17:51
query4_3 = '''
    SELECT city
    FROM store
    GROUP BY city
    

'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 16:18:21
query4_3 = '''

    SELECT city
    FROM customer
    GROUP BY city
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 16:19:30
query4_3 = '''

    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 16:19:34
query4_3 = '''

    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 16:20:44
query4_3 = '''
SELECT *
FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     0         Coop      Kalverstraat  Amsterdam
#[Out]# 1     1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 5     5       Sligro     Stationsplein      Breda
#[Out]# 6     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 7     7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 8     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 9     9  Albert Hein         Koestraat    Tilburg
#[Out]# 10   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 11   11  Albert Hein          Hofplein  Rotterdam
#[Out]# 12   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 13   13         Coop         Koestraat    Tilburg
#[Out]# 14   14         Coop     Keizersgracht  Amsterdam
#[Out]# 15   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 16   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 17   17    Hoogvliet        Kerkstraat  Eindhoven
#[Out]# 18   18       Sligro       Parallelweg    Tilburg
#[Out]# 19   19         Coop       Karrestraat      Breda
#[Out]# 20   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 21   21         Coop      Kasteeldreef    Tilburg
#[Out]# 22   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 23   23         Dirk     Stationsplein      Breda
#[Out]# 24   24  Albert Hein     Stationsplein      Breda
#[Out]# 25   25  Albert Hein     Stationsplein      Breda
#[Out]# 26   26    Hoogvliet   Sint Annastraat      Breda
#[Out]# 27   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 28   28    Hoogvliet         Koestraat    Tilburg
#[Out]# 29   29       Sligro      Marnixstraat  Amsterdam
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   34         Coop          Bierkaai  Amsterdam
#[Out]# 35   35         Lidl     Julianastraat    Utrecht
#[Out]# 36   36         Lidl     Julianastraat  Eindhoven
#[Out]# 37   37        Jumbo          Molenweg  Eindhoven
#[Out]# 38   38    Hoogvliet          Hofplein  Rotterdam
#[Out]# 39   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 40   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 41   41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 42   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 43   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 44   44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 45   45         Coop      Kasteeldreef    Tilburg
#[Out]# 46   46         Lidl        Bergselaan  Rotterdam
#[Out]# 47   47         Coop     Julianastraat  Rotterdam
#[Out]# 48   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 49   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 50   50       Sligro     Stationsplein      Breda
#[Out]# 51   51         Coop       Parallelweg    Utrecht
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   53         Coop        Hoogstraat    Utrecht
#[Out]# 54   54         Dirk     Julianastraat  Eindhoven
#[Out]# 55   55         Coop   Sint Annastraat      Breda
#[Out]# 56   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 57   57         Dirk       Molenstraat  Eindhoven
#[Out]# 58   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 59   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60         Lidl      Pannekoekweg      Breda
#[Out]# 61   61         Lidl      Pannekoekweg      Breda
#[Out]# 62   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63        Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Tue, 08 Dec 2020 16:21:02
query4_3 = '''
SELECT *
FROM store
order by sname
'''

pd.read_sql_query(query4_3, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 1     9  Albert Hein         Koestraat    Tilburg
#[Out]# 2    11  Albert Hein          Hofplein  Rotterdam
#[Out]# 3    24  Albert Hein     Stationsplein      Breda
#[Out]# 4    25  Albert Hein     Stationsplein      Breda
#[Out]# 5    32  Albert Hein        Hoogstraat    Utrecht
#[Out]# 6    41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 7    44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 8     0         Coop      Kalverstraat  Amsterdam
#[Out]# 9     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 10   13         Coop         Koestraat    Tilburg
#[Out]# 11   14         Coop     Keizersgracht  Amsterdam
#[Out]# 12   19         Coop       Karrestraat      Breda
#[Out]# 13   21         Coop      Kasteeldreef    Tilburg
#[Out]# 14   31         Coop       Parallelweg    Utrecht
#[Out]# 15   34         Coop          Bierkaai  Amsterdam
#[Out]# 16   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 17   45         Coop      Kasteeldreef    Tilburg
#[Out]# 18   47         Coop     Julianastraat  Rotterdam
#[Out]# 19   51         Coop       Parallelweg    Utrecht
#[Out]# 20   53         Coop        Hoogstraat    Utrecht
#[Out]# 21   55         Coop   Sint Annastraat      Breda
#[Out]# 22   23         Dirk     Stationsplein      Breda
#[Out]# 23   30         Dirk       Nieuwstraat  Eindhoven
#[Out]# 24   33         Dirk       Nieuwstraat  Eindhoven
#[Out]# 25   54         Dirk     Julianastraat  Eindhoven
#[Out]# 26   57         Dirk       Molenstraat  Eindhoven
#[Out]# 27   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 28    1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 29    4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 35   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 36   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 37    2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 38   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 39   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 40   37        Jumbo          Molenweg  Eindhoven
#[Out]# 41   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 42   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 43   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 44   63        Jumbo     Stationstraat        Oss
#[Out]# 45   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 46   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 47   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 48   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 49   35         Lidl     Julianastraat    Utrecht
#[Out]# 50   36         Lidl     Julianastraat  Eindhoven
#[Out]# 51   46         Lidl        Bergselaan  Rotterdam
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   60         Lidl      Pannekoekweg      Breda
#[Out]# 54   61         Lidl      Pannekoekweg      Breda
#[Out]# 55    3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 56    5       Sligro     Stationsplein      Breda
#[Out]# 57    7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 58   18       Sligro       Parallelweg    Tilburg
#[Out]# 59   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 60   29       Sligro      Marnixstraat  Amsterdam
#[Out]# 61   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 62   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 63   50       Sligro     Stationsplein      Breda
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Tue, 08 Dec 2020 16:22:16
query4_3 = '''
WITH All_Cities (city) AS (
            SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)
    
    SSELECT * FROM All_Cities
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:22:34
query4_3 = '''
WITH All_Cities (city) AS (
            SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)
    
    SELECT * FROM All_Cities
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 16:23:03
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)
    
    SELECT *
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     0         Coop      Kalverstraat  Amsterdam
#[Out]# 1     1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 5     5       Sligro     Stationsplein      Breda
#[Out]# 6     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 7     7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 8     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 9     9  Albert Hein         Koestraat    Tilburg
#[Out]# 10   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 11   11  Albert Hein          Hofplein  Rotterdam
#[Out]# 12   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 13   13         Coop         Koestraat    Tilburg
#[Out]# 14   14         Coop     Keizersgracht  Amsterdam
#[Out]# 15   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 16   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 17   17    Hoogvliet        Kerkstraat  Eindhoven
#[Out]# 18   18       Sligro       Parallelweg    Tilburg
#[Out]# 19   19         Coop       Karrestraat      Breda
#[Out]# 20   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 21   21         Coop      Kasteeldreef    Tilburg
#[Out]# 22   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 23   23         Dirk     Stationsplein      Breda
#[Out]# 24   24  Albert Hein     Stationsplein      Breda
#[Out]# 25   25  Albert Hein     Stationsplein      Breda
#[Out]# 26   26    Hoogvliet   Sint Annastraat      Breda
#[Out]# 27   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 28   28    Hoogvliet         Koestraat    Tilburg
#[Out]# 29   29       Sligro      Marnixstraat  Amsterdam
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   34         Coop          Bierkaai  Amsterdam
#[Out]# 35   35         Lidl     Julianastraat    Utrecht
#[Out]# 36   36         Lidl     Julianastraat  Eindhoven
#[Out]# 37   37        Jumbo          Molenweg  Eindhoven
#[Out]# 38   38    Hoogvliet          Hofplein  Rotterdam
#[Out]# 39   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 40   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 41   41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 42   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 43   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 44   44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 45   45         Coop      Kasteeldreef    Tilburg
#[Out]# 46   46         Lidl        Bergselaan  Rotterdam
#[Out]# 47   47         Coop     Julianastraat  Rotterdam
#[Out]# 48   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 49   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 50   50       Sligro     Stationsplein      Breda
#[Out]# 51   51         Coop       Parallelweg    Utrecht
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   53         Coop        Hoogstraat    Utrecht
#[Out]# 54   54         Dirk     Julianastraat  Eindhoven
#[Out]# 55   55         Coop   Sint Annastraat      Breda
#[Out]# 56   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 57   57         Dirk       Molenstraat  Eindhoven
#[Out]# 58   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 59   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60         Lidl      Pannekoekweg      Breda
#[Out]# 61   61         Lidl      Pannekoekweg      Breda
#[Out]# 62   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63        Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Tue, 08 Dec 2020 16:23:15
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)
    
    SELECT *
    FROM store
    
    order by sname
'''

pd.read_sql_query(query4_3, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 1     9  Albert Hein         Koestraat    Tilburg
#[Out]# 2    11  Albert Hein          Hofplein  Rotterdam
#[Out]# 3    24  Albert Hein     Stationsplein      Breda
#[Out]# 4    25  Albert Hein     Stationsplein      Breda
#[Out]# 5    32  Albert Hein        Hoogstraat    Utrecht
#[Out]# 6    41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 7    44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 8     0         Coop      Kalverstraat  Amsterdam
#[Out]# 9     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 10   13         Coop         Koestraat    Tilburg
#[Out]# 11   14         Coop     Keizersgracht  Amsterdam
#[Out]# 12   19         Coop       Karrestraat      Breda
#[Out]# 13   21         Coop      Kasteeldreef    Tilburg
#[Out]# 14   31         Coop       Parallelweg    Utrecht
#[Out]# 15   34         Coop          Bierkaai  Amsterdam
#[Out]# 16   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 17   45         Coop      Kasteeldreef    Tilburg
#[Out]# 18   47         Coop     Julianastraat  Rotterdam
#[Out]# 19   51         Coop       Parallelweg    Utrecht
#[Out]# 20   53         Coop        Hoogstraat    Utrecht
#[Out]# 21   55         Coop   Sint Annastraat      Breda
#[Out]# 22   23         Dirk     Stationsplein      Breda
#[Out]# 23   30         Dirk       Nieuwstraat  Eindhoven
#[Out]# 24   33         Dirk       Nieuwstraat  Eindhoven
#[Out]# 25   54         Dirk     Julianastraat  Eindhoven
#[Out]# 26   57         Dirk       Molenstraat  Eindhoven
#[Out]# 27   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 28    1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 29    4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 35   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 36   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 37    2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 38   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 39   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 40   37        Jumbo          Molenweg  Eindhoven
#[Out]# 41   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 42   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 43   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 44   63        Jumbo     Stationstraat        Oss
#[Out]# 45   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 46   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 47   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 48   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 49   35         Lidl     Julianastraat    Utrecht
#[Out]# 50   36         Lidl     Julianastraat  Eindhoven
#[Out]# 51   46         Lidl        Bergselaan  Rotterdam
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   60         Lidl      Pannekoekweg      Breda
#[Out]# 54   61         Lidl      Pannekoekweg      Breda
#[Out]# 55    3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 56    5       Sligro     Stationsplein      Breda
#[Out]# 57    7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 58   18       Sligro       Parallelweg    Tilburg
#[Out]# 59   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 60   29       Sligro      Marnixstraat  Amsterdam
#[Out]# 61   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 62   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 63   50       Sligro     Stationsplein      Breda
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Tue, 08 Dec 2020 16:24:41
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)
    
    SELECT *
    FROM store,All_Cities
    
    order by sname
'''

pd.read_sql_query(query4_3, conn)
#[Out]#      sID        sName         street       city       city
#[Out]# 0      8  Albert Hein    Molenstraat  Eindhoven  Amsterdam
#[Out]# 1      8  Albert Hein    Molenstraat  Eindhoven      Breda
#[Out]# 2      8  Albert Hein    Molenstraat  Eindhoven  Eindhoven
#[Out]# 3      8  Albert Hein    Molenstraat  Eindhoven        Oss
#[Out]# 4      8  Albert Hein    Molenstraat  Eindhoven  Rotterdam
#[Out]# 5      8  Albert Hein    Molenstraat  Eindhoven    Tilburg
#[Out]# 6      8  Albert Hein    Molenstraat  Eindhoven    Utrecht
#[Out]# 7      9  Albert Hein      Koestraat    Tilburg  Amsterdam
#[Out]# 8      9  Albert Hein      Koestraat    Tilburg      Breda
#[Out]# 9      9  Albert Hein      Koestraat    Tilburg  Eindhoven
#[Out]# 10     9  Albert Hein      Koestraat    Tilburg        Oss
#[Out]# 11     9  Albert Hein      Koestraat    Tilburg  Rotterdam
#[Out]# 12     9  Albert Hein      Koestraat    Tilburg    Tilburg
#[Out]# 13     9  Albert Hein      Koestraat    Tilburg    Utrecht
#[Out]# 14    11  Albert Hein       Hofplein  Rotterdam  Amsterdam
#[Out]# 15    11  Albert Hein       Hofplein  Rotterdam      Breda
#[Out]# 16    11  Albert Hein       Hofplein  Rotterdam  Eindhoven
#[Out]# 17    11  Albert Hein       Hofplein  Rotterdam        Oss
#[Out]# 18    11  Albert Hein       Hofplein  Rotterdam  Rotterdam
#[Out]# 19    11  Albert Hein       Hofplein  Rotterdam    Tilburg
#[Out]# 20    11  Albert Hein       Hofplein  Rotterdam    Utrecht
#[Out]# 21    24  Albert Hein  Stationsplein      Breda  Amsterdam
#[Out]# 22    24  Albert Hein  Stationsplein      Breda      Breda
#[Out]# 23    24  Albert Hein  Stationsplein      Breda  Eindhoven
#[Out]# 24    24  Albert Hein  Stationsplein      Breda        Oss
#[Out]# 25    24  Albert Hein  Stationsplein      Breda  Rotterdam
#[Out]# 26    24  Albert Hein  Stationsplein      Breda    Tilburg
#[Out]# 27    24  Albert Hein  Stationsplein      Breda    Utrecht
#[Out]# 28    25  Albert Hein  Stationsplein      Breda  Amsterdam
#[Out]# 29    25  Albert Hein  Stationsplein      Breda      Breda
#[Out]# ..   ...          ...            ...        ...        ...
#[Out]# 418   27       Sligro   Kalverstraat  Amsterdam    Tilburg
#[Out]# 419   27       Sligro   Kalverstraat  Amsterdam    Utrecht
#[Out]# 420   29       Sligro   Marnixstraat  Amsterdam  Amsterdam
#[Out]# 421   29       Sligro   Marnixstraat  Amsterdam      Breda
#[Out]# 422   29       Sligro   Marnixstraat  Amsterdam  Eindhoven
#[Out]# 423   29       Sligro   Marnixstraat  Amsterdam        Oss
#[Out]# 424   29       Sligro   Marnixstraat  Amsterdam  Rotterdam
#[Out]# 425   29       Sligro   Marnixstraat  Amsterdam    Tilburg
#[Out]# 426   29       Sligro   Marnixstraat  Amsterdam    Utrecht
#[Out]# 427   39       Sligro    Dorpsstraat  Eindhoven  Amsterdam
#[Out]# 428   39       Sligro    Dorpsstraat  Eindhoven      Breda
#[Out]# 429   39       Sligro    Dorpsstraat  Eindhoven  Eindhoven
#[Out]# 430   39       Sligro    Dorpsstraat  Eindhoven        Oss
#[Out]# 431   39       Sligro    Dorpsstraat  Eindhoven  Rotterdam
#[Out]# 432   39       Sligro    Dorpsstraat  Eindhoven    Tilburg
#[Out]# 433   39       Sligro    Dorpsstraat  Eindhoven    Utrecht
#[Out]# 434   42       Sligro   Kalverstraat  Amsterdam  Amsterdam
#[Out]# 435   42       Sligro   Kalverstraat  Amsterdam      Breda
#[Out]# 436   42       Sligro   Kalverstraat  Amsterdam  Eindhoven
#[Out]# 437   42       Sligro   Kalverstraat  Amsterdam        Oss
#[Out]# 438   42       Sligro   Kalverstraat  Amsterdam  Rotterdam
#[Out]# 439   42       Sligro   Kalverstraat  Amsterdam    Tilburg
#[Out]# 440   42       Sligro   Kalverstraat  Amsterdam    Utrecht
#[Out]# 441   50       Sligro  Stationsplein      Breda  Amsterdam
#[Out]# 442   50       Sligro  Stationsplein      Breda      Breda
#[Out]# 443   50       Sligro  Stationsplein      Breda  Eindhoven
#[Out]# 444   50       Sligro  Stationsplein      Breda        Oss
#[Out]# 445   50       Sligro  Stationsplein      Breda  Rotterdam
#[Out]# 446   50       Sligro  Stationsplein      Breda    Tilburg
#[Out]# 447   50       Sligro  Stationsplein      Breda    Utrecht
#[Out]# 
#[Out]# [448 rows x 5 columns]
# Tue, 08 Dec 2020 16:26:20
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)
    
    SELECT *
    FROM store AS S,All_Cities AS AC
    WHERE S.city <> AC.city
    
    order by sname
'''

pd.read_sql_query(query4_3, conn)
#[Out]#      sID        sName         street       city       city
#[Out]# 0      8  Albert Hein    Molenstraat  Eindhoven  Amsterdam
#[Out]# 1      8  Albert Hein    Molenstraat  Eindhoven      Breda
#[Out]# 2      8  Albert Hein    Molenstraat  Eindhoven        Oss
#[Out]# 3      8  Albert Hein    Molenstraat  Eindhoven  Rotterdam
#[Out]# 4      8  Albert Hein    Molenstraat  Eindhoven    Tilburg
#[Out]# 5      8  Albert Hein    Molenstraat  Eindhoven    Utrecht
#[Out]# 6      9  Albert Hein      Koestraat    Tilburg  Amsterdam
#[Out]# 7      9  Albert Hein      Koestraat    Tilburg      Breda
#[Out]# 8      9  Albert Hein      Koestraat    Tilburg  Eindhoven
#[Out]# 9      9  Albert Hein      Koestraat    Tilburg        Oss
#[Out]# 10     9  Albert Hein      Koestraat    Tilburg  Rotterdam
#[Out]# 11     9  Albert Hein      Koestraat    Tilburg    Utrecht
#[Out]# 12    11  Albert Hein       Hofplein  Rotterdam  Amsterdam
#[Out]# 13    11  Albert Hein       Hofplein  Rotterdam      Breda
#[Out]# 14    11  Albert Hein       Hofplein  Rotterdam  Eindhoven
#[Out]# 15    11  Albert Hein       Hofplein  Rotterdam        Oss
#[Out]# 16    11  Albert Hein       Hofplein  Rotterdam    Tilburg
#[Out]# 17    11  Albert Hein       Hofplein  Rotterdam    Utrecht
#[Out]# 18    24  Albert Hein  Stationsplein      Breda  Amsterdam
#[Out]# 19    24  Albert Hein  Stationsplein      Breda  Eindhoven
#[Out]# 20    24  Albert Hein  Stationsplein      Breda        Oss
#[Out]# 21    24  Albert Hein  Stationsplein      Breda  Rotterdam
#[Out]# 22    24  Albert Hein  Stationsplein      Breda    Tilburg
#[Out]# 23    24  Albert Hein  Stationsplein      Breda    Utrecht
#[Out]# 24    25  Albert Hein  Stationsplein      Breda  Amsterdam
#[Out]# 25    25  Albert Hein  Stationsplein      Breda  Eindhoven
#[Out]# 26    25  Albert Hein  Stationsplein      Breda        Oss
#[Out]# 27    25  Albert Hein  Stationsplein      Breda  Rotterdam
#[Out]# 28    25  Albert Hein  Stationsplein      Breda    Tilburg
#[Out]# 29    25  Albert Hein  Stationsplein      Breda    Utrecht
#[Out]# ..   ...          ...            ...        ...        ...
#[Out]# 354   27       Sligro   Kalverstraat  Amsterdam      Breda
#[Out]# 355   27       Sligro   Kalverstraat  Amsterdam  Eindhoven
#[Out]# 356   27       Sligro   Kalverstraat  Amsterdam        Oss
#[Out]# 357   27       Sligro   Kalverstraat  Amsterdam  Rotterdam
#[Out]# 358   27       Sligro   Kalverstraat  Amsterdam    Tilburg
#[Out]# 359   27       Sligro   Kalverstraat  Amsterdam    Utrecht
#[Out]# 360   29       Sligro   Marnixstraat  Amsterdam      Breda
#[Out]# 361   29       Sligro   Marnixstraat  Amsterdam  Eindhoven
#[Out]# 362   29       Sligro   Marnixstraat  Amsterdam        Oss
#[Out]# 363   29       Sligro   Marnixstraat  Amsterdam  Rotterdam
#[Out]# 364   29       Sligro   Marnixstraat  Amsterdam    Tilburg
#[Out]# 365   29       Sligro   Marnixstraat  Amsterdam    Utrecht
#[Out]# 366   39       Sligro    Dorpsstraat  Eindhoven  Amsterdam
#[Out]# 367   39       Sligro    Dorpsstraat  Eindhoven      Breda
#[Out]# 368   39       Sligro    Dorpsstraat  Eindhoven        Oss
#[Out]# 369   39       Sligro    Dorpsstraat  Eindhoven  Rotterdam
#[Out]# 370   39       Sligro    Dorpsstraat  Eindhoven    Tilburg
#[Out]# 371   39       Sligro    Dorpsstraat  Eindhoven    Utrecht
#[Out]# 372   42       Sligro   Kalverstraat  Amsterdam      Breda
#[Out]# 373   42       Sligro   Kalverstraat  Amsterdam  Eindhoven
#[Out]# 374   42       Sligro   Kalverstraat  Amsterdam        Oss
#[Out]# 375   42       Sligro   Kalverstraat  Amsterdam  Rotterdam
#[Out]# 376   42       Sligro   Kalverstraat  Amsterdam    Tilburg
#[Out]# 377   42       Sligro   Kalverstraat  Amsterdam    Utrecht
#[Out]# 378   50       Sligro  Stationsplein      Breda  Amsterdam
#[Out]# 379   50       Sligro  Stationsplein      Breda  Eindhoven
#[Out]# 380   50       Sligro  Stationsplein      Breda        Oss
#[Out]# 381   50       Sligro  Stationsplein      Breda  Rotterdam
#[Out]# 382   50       Sligro  Stationsplein      Breda    Tilburg
#[Out]# 383   50       Sligro  Stationsplein      Breda    Utrecht
#[Out]# 
#[Out]# [384 rows x 5 columns]
# Tue, 08 Dec 2020 16:27:28
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)
    
    SELECT S.sName,S.city,AC.City AS AllCities
    FROM store AS S,All_Cities AS AC
    
    order by sname
'''

pd.read_sql_query(query4_3, conn)
#[Out]#            sName       city  AllCities
#[Out]# 0    Albert Hein  Eindhoven  Amsterdam
#[Out]# 1    Albert Hein  Eindhoven      Breda
#[Out]# 2    Albert Hein  Eindhoven  Eindhoven
#[Out]# 3    Albert Hein  Eindhoven        Oss
#[Out]# 4    Albert Hein  Eindhoven  Rotterdam
#[Out]# 5    Albert Hein  Eindhoven    Tilburg
#[Out]# 6    Albert Hein  Eindhoven    Utrecht
#[Out]# 7    Albert Hein    Tilburg  Amsterdam
#[Out]# 8    Albert Hein    Tilburg      Breda
#[Out]# 9    Albert Hein    Tilburg  Eindhoven
#[Out]# 10   Albert Hein    Tilburg        Oss
#[Out]# 11   Albert Hein    Tilburg  Rotterdam
#[Out]# 12   Albert Hein    Tilburg    Tilburg
#[Out]# 13   Albert Hein    Tilburg    Utrecht
#[Out]# 14   Albert Hein  Rotterdam  Amsterdam
#[Out]# 15   Albert Hein  Rotterdam      Breda
#[Out]# 16   Albert Hein  Rotterdam  Eindhoven
#[Out]# 17   Albert Hein  Rotterdam        Oss
#[Out]# 18   Albert Hein  Rotterdam  Rotterdam
#[Out]# 19   Albert Hein  Rotterdam    Tilburg
#[Out]# 20   Albert Hein  Rotterdam    Utrecht
#[Out]# 21   Albert Hein      Breda  Amsterdam
#[Out]# 22   Albert Hein      Breda      Breda
#[Out]# 23   Albert Hein      Breda  Eindhoven
#[Out]# 24   Albert Hein      Breda        Oss
#[Out]# 25   Albert Hein      Breda  Rotterdam
#[Out]# 26   Albert Hein      Breda    Tilburg
#[Out]# 27   Albert Hein      Breda    Utrecht
#[Out]# 28   Albert Hein      Breda  Amsterdam
#[Out]# 29   Albert Hein      Breda      Breda
#[Out]# ..           ...        ...        ...
#[Out]# 418       Sligro  Amsterdam    Tilburg
#[Out]# 419       Sligro  Amsterdam    Utrecht
#[Out]# 420       Sligro  Amsterdam  Amsterdam
#[Out]# 421       Sligro  Amsterdam      Breda
#[Out]# 422       Sligro  Amsterdam  Eindhoven
#[Out]# 423       Sligro  Amsterdam        Oss
#[Out]# 424       Sligro  Amsterdam  Rotterdam
#[Out]# 425       Sligro  Amsterdam    Tilburg
#[Out]# 426       Sligro  Amsterdam    Utrecht
#[Out]# 427       Sligro  Eindhoven  Amsterdam
#[Out]# 428       Sligro  Eindhoven      Breda
#[Out]# 429       Sligro  Eindhoven  Eindhoven
#[Out]# 430       Sligro  Eindhoven        Oss
#[Out]# 431       Sligro  Eindhoven  Rotterdam
#[Out]# 432       Sligro  Eindhoven    Tilburg
#[Out]# 433       Sligro  Eindhoven    Utrecht
#[Out]# 434       Sligro  Amsterdam  Amsterdam
#[Out]# 435       Sligro  Amsterdam      Breda
#[Out]# 436       Sligro  Amsterdam  Eindhoven
#[Out]# 437       Sligro  Amsterdam        Oss
#[Out]# 438       Sligro  Amsterdam  Rotterdam
#[Out]# 439       Sligro  Amsterdam    Tilburg
#[Out]# 440       Sligro  Amsterdam    Utrecht
#[Out]# 441       Sligro      Breda  Amsterdam
#[Out]# 442       Sligro      Breda      Breda
#[Out]# 443       Sligro      Breda  Eindhoven
#[Out]# 444       Sligro      Breda        Oss
#[Out]# 445       Sligro      Breda  Rotterdam
#[Out]# 446       Sligro      Breda    Tilburg
#[Out]# 447       Sligro      Breda    Utrecht
#[Out]# 
#[Out]# [448 rows x 3 columns]
# Tue, 08 Dec 2020 16:27:38
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)
    
    SELECT S.sName,S.city,AC.City AS AllCities
    FROM store AS S,All_Cities AS AC
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city  AllCities
#[Out]# 0         Coop  Amsterdam  Amsterdam
#[Out]# 1         Coop  Amsterdam      Breda
#[Out]# 2         Coop  Amsterdam  Eindhoven
#[Out]# 3         Coop  Amsterdam        Oss
#[Out]# 4         Coop  Amsterdam  Rotterdam
#[Out]# 5         Coop  Amsterdam    Tilburg
#[Out]# 6         Coop  Amsterdam    Utrecht
#[Out]# 7    Hoogvliet      Breda  Amsterdam
#[Out]# 8    Hoogvliet      Breda      Breda
#[Out]# 9    Hoogvliet      Breda  Eindhoven
#[Out]# 10   Hoogvliet      Breda        Oss
#[Out]# 11   Hoogvliet      Breda  Rotterdam
#[Out]# 12   Hoogvliet      Breda    Tilburg
#[Out]# 13   Hoogvliet      Breda    Utrecht
#[Out]# 14       Jumbo  Rotterdam  Amsterdam
#[Out]# 15       Jumbo  Rotterdam      Breda
#[Out]# 16       Jumbo  Rotterdam  Eindhoven
#[Out]# 17       Jumbo  Rotterdam        Oss
#[Out]# 18       Jumbo  Rotterdam  Rotterdam
#[Out]# 19       Jumbo  Rotterdam    Tilburg
#[Out]# 20       Jumbo  Rotterdam    Utrecht
#[Out]# 21      Sligro  Rotterdam  Amsterdam
#[Out]# 22      Sligro  Rotterdam      Breda
#[Out]# 23      Sligro  Rotterdam  Eindhoven
#[Out]# 24      Sligro  Rotterdam        Oss
#[Out]# 25      Sligro  Rotterdam  Rotterdam
#[Out]# 26      Sligro  Rotterdam    Tilburg
#[Out]# 27      Sligro  Rotterdam    Utrecht
#[Out]# 28   Hoogvliet  Eindhoven  Amsterdam
#[Out]# 29   Hoogvliet  Eindhoven      Breda
#[Out]# ..         ...        ...        ...
#[Out]# 418      Jumbo      Breda    Tilburg
#[Out]# 419      Jumbo      Breda    Utrecht
#[Out]# 420       Lidl      Breda  Amsterdam
#[Out]# 421       Lidl      Breda      Breda
#[Out]# 422       Lidl      Breda  Eindhoven
#[Out]# 423       Lidl      Breda        Oss
#[Out]# 424       Lidl      Breda  Rotterdam
#[Out]# 425       Lidl      Breda    Tilburg
#[Out]# 426       Lidl      Breda    Utrecht
#[Out]# 427       Lidl      Breda  Amsterdam
#[Out]# 428       Lidl      Breda      Breda
#[Out]# 429       Lidl      Breda  Eindhoven
#[Out]# 430       Lidl      Breda        Oss
#[Out]# 431       Lidl      Breda  Rotterdam
#[Out]# 432       Lidl      Breda    Tilburg
#[Out]# 433       Lidl      Breda    Utrecht
#[Out]# 434      Jumbo  Eindhoven  Amsterdam
#[Out]# 435      Jumbo  Eindhoven      Breda
#[Out]# 436      Jumbo  Eindhoven  Eindhoven
#[Out]# 437      Jumbo  Eindhoven        Oss
#[Out]# 438      Jumbo  Eindhoven  Rotterdam
#[Out]# 439      Jumbo  Eindhoven    Tilburg
#[Out]# 440      Jumbo  Eindhoven    Utrecht
#[Out]# 441      Jumbo        Oss  Amsterdam
#[Out]# 442      Jumbo        Oss      Breda
#[Out]# 443      Jumbo        Oss  Eindhoven
#[Out]# 444      Jumbo        Oss        Oss
#[Out]# 445      Jumbo        Oss  Rotterdam
#[Out]# 446      Jumbo        Oss    Tilburg
#[Out]# 447      Jumbo        Oss    Utrecht
#[Out]# 
#[Out]# [448 rows x 3 columns]
# Tue, 08 Dec 2020 16:33:19
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)
    
    SELECT S.sName,S.city,AC.City AS AllCities
    FROM store AS S,All_Cities AS AC
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city  AllCities
#[Out]# 0         Coop  Amsterdam  Amsterdam
#[Out]# 1         Coop  Amsterdam      Breda
#[Out]# 2         Coop  Amsterdam  Eindhoven
#[Out]# 3         Coop  Amsterdam        Oss
#[Out]# 4         Coop  Amsterdam  Rotterdam
#[Out]# 5         Coop  Amsterdam    Tilburg
#[Out]# 6         Coop  Amsterdam    Utrecht
#[Out]# 7    Hoogvliet      Breda  Amsterdam
#[Out]# 8    Hoogvliet      Breda      Breda
#[Out]# 9    Hoogvliet      Breda  Eindhoven
#[Out]# 10   Hoogvliet      Breda        Oss
#[Out]# 11   Hoogvliet      Breda  Rotterdam
#[Out]# 12   Hoogvliet      Breda    Tilburg
#[Out]# 13   Hoogvliet      Breda    Utrecht
#[Out]# 14       Jumbo  Rotterdam  Amsterdam
#[Out]# 15       Jumbo  Rotterdam      Breda
#[Out]# 16       Jumbo  Rotterdam  Eindhoven
#[Out]# 17       Jumbo  Rotterdam        Oss
#[Out]# 18       Jumbo  Rotterdam  Rotterdam
#[Out]# 19       Jumbo  Rotterdam    Tilburg
#[Out]# 20       Jumbo  Rotterdam    Utrecht
#[Out]# 21      Sligro  Rotterdam  Amsterdam
#[Out]# 22      Sligro  Rotterdam      Breda
#[Out]# 23      Sligro  Rotterdam  Eindhoven
#[Out]# 24      Sligro  Rotterdam        Oss
#[Out]# 25      Sligro  Rotterdam  Rotterdam
#[Out]# 26      Sligro  Rotterdam    Tilburg
#[Out]# 27      Sligro  Rotterdam    Utrecht
#[Out]# 28   Hoogvliet  Eindhoven  Amsterdam
#[Out]# 29   Hoogvliet  Eindhoven      Breda
#[Out]# ..         ...        ...        ...
#[Out]# 418      Jumbo      Breda    Tilburg
#[Out]# 419      Jumbo      Breda    Utrecht
#[Out]# 420       Lidl      Breda  Amsterdam
#[Out]# 421       Lidl      Breda      Breda
#[Out]# 422       Lidl      Breda  Eindhoven
#[Out]# 423       Lidl      Breda        Oss
#[Out]# 424       Lidl      Breda  Rotterdam
#[Out]# 425       Lidl      Breda    Tilburg
#[Out]# 426       Lidl      Breda    Utrecht
#[Out]# 427       Lidl      Breda  Amsterdam
#[Out]# 428       Lidl      Breda      Breda
#[Out]# 429       Lidl      Breda  Eindhoven
#[Out]# 430       Lidl      Breda        Oss
#[Out]# 431       Lidl      Breda  Rotterdam
#[Out]# 432       Lidl      Breda    Tilburg
#[Out]# 433       Lidl      Breda    Utrecht
#[Out]# 434      Jumbo  Eindhoven  Amsterdam
#[Out]# 435      Jumbo  Eindhoven      Breda
#[Out]# 436      Jumbo  Eindhoven  Eindhoven
#[Out]# 437      Jumbo  Eindhoven        Oss
#[Out]# 438      Jumbo  Eindhoven  Rotterdam
#[Out]# 439      Jumbo  Eindhoven    Tilburg
#[Out]# 440      Jumbo  Eindhoven    Utrecht
#[Out]# 441      Jumbo        Oss  Amsterdam
#[Out]# 442      Jumbo        Oss      Breda
#[Out]# 443      Jumbo        Oss  Eindhoven
#[Out]# 444      Jumbo        Oss        Oss
#[Out]# 445      Jumbo        Oss  Rotterdam
#[Out]# 446      Jumbo        Oss    Tilburg
#[Out]# 447      Jumbo        Oss    Utrecht
#[Out]# 
#[Out]# [448 rows x 3 columns]
# Tue, 08 Dec 2020 16:35:02
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT * FROM StoresxCities
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store       City
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 16:35:27
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT * FROM StoresxCities order by store
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store       City
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein      Breda
#[Out]# 5   Albert Hein    Utrecht
#[Out]# 6   Albert Hein  Rotterdam
#[Out]# 7   Albert Hein    Utrecht
#[Out]# 8          Coop  Amsterdam
#[Out]# 9          Coop  Rotterdam
#[Out]# 10         Coop    Tilburg
#[Out]# 11         Coop  Amsterdam
#[Out]# 12         Coop      Breda
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop    Utrecht
#[Out]# 15         Coop  Amsterdam
#[Out]# 16         Coop    Utrecht
#[Out]# 17         Coop    Tilburg
#[Out]# 18         Coop  Rotterdam
#[Out]# 19         Coop    Utrecht
#[Out]# 20         Coop    Utrecht
#[Out]# 21         Coop      Breda
#[Out]# 22         Dirk      Breda
#[Out]# 23         Dirk  Eindhoven
#[Out]# 24         Dirk  Eindhoven
#[Out]# 25         Dirk  Eindhoven
#[Out]# 26         Dirk  Eindhoven
#[Out]# 27         Dirk  Rotterdam
#[Out]# 28    Hoogvliet      Breda
#[Out]# 29    Hoogvliet  Eindhoven
#[Out]# ..          ...        ...
#[Out]# 34    Hoogvliet  Rotterdam
#[Out]# 35    Hoogvliet    Tilburg
#[Out]# 36    Hoogvliet  Rotterdam
#[Out]# 37        Jumbo  Rotterdam
#[Out]# 38        Jumbo  Rotterdam
#[Out]# 39        Jumbo    Tilburg
#[Out]# 40        Jumbo  Eindhoven
#[Out]# 41        Jumbo  Eindhoven
#[Out]# 42        Jumbo      Breda
#[Out]# 43        Jumbo  Eindhoven
#[Out]# 44        Jumbo        Oss
#[Out]# 45         Lidl  Eindhoven
#[Out]# 46         Lidl  Amsterdam
#[Out]# 47         Lidl    Utrecht
#[Out]# 48         Lidl  Amsterdam
#[Out]# 49         Lidl    Utrecht
#[Out]# 50         Lidl  Eindhoven
#[Out]# 51         Lidl  Rotterdam
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Lidl      Breda
#[Out]# 54         Lidl      Breda
#[Out]# 55       Sligro  Rotterdam
#[Out]# 56       Sligro      Breda
#[Out]# 57       Sligro  Eindhoven
#[Out]# 58       Sligro    Tilburg
#[Out]# 59       Sligro  Amsterdam
#[Out]# 60       Sligro  Amsterdam
#[Out]# 61       Sligro  Eindhoven
#[Out]# 62       Sligro  Amsterdam
#[Out]# 63       Sligro      Breda
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 16:37:16
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT *
    FROM StoresxCities AS SC
    WHERE SC.city NOT IN All_Cities.city
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:37:38
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT *
    FROM StoresxCities AS SC,All_Cities AS AC
    WHERE SC.city NOT IN AC.city
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:37:59
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT *
    FROM StoresxCities AS SC,All_Cities AS AC

    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          Store       City       city
#[Out]# 0         Coop  Amsterdam  Amsterdam
#[Out]# 1         Coop  Amsterdam      Breda
#[Out]# 2         Coop  Amsterdam  Eindhoven
#[Out]# 3         Coop  Amsterdam        Oss
#[Out]# 4         Coop  Amsterdam  Rotterdam
#[Out]# 5         Coop  Amsterdam    Tilburg
#[Out]# 6         Coop  Amsterdam    Utrecht
#[Out]# 7    Hoogvliet      Breda  Amsterdam
#[Out]# 8    Hoogvliet      Breda      Breda
#[Out]# 9    Hoogvliet      Breda  Eindhoven
#[Out]# 10   Hoogvliet      Breda        Oss
#[Out]# 11   Hoogvliet      Breda  Rotterdam
#[Out]# 12   Hoogvliet      Breda    Tilburg
#[Out]# 13   Hoogvliet      Breda    Utrecht
#[Out]# 14       Jumbo  Rotterdam  Amsterdam
#[Out]# 15       Jumbo  Rotterdam      Breda
#[Out]# 16       Jumbo  Rotterdam  Eindhoven
#[Out]# 17       Jumbo  Rotterdam        Oss
#[Out]# 18       Jumbo  Rotterdam  Rotterdam
#[Out]# 19       Jumbo  Rotterdam    Tilburg
#[Out]# 20       Jumbo  Rotterdam    Utrecht
#[Out]# 21      Sligro  Rotterdam  Amsterdam
#[Out]# 22      Sligro  Rotterdam      Breda
#[Out]# 23      Sligro  Rotterdam  Eindhoven
#[Out]# 24      Sligro  Rotterdam        Oss
#[Out]# 25      Sligro  Rotterdam  Rotterdam
#[Out]# 26      Sligro  Rotterdam    Tilburg
#[Out]# 27      Sligro  Rotterdam    Utrecht
#[Out]# 28   Hoogvliet  Eindhoven  Amsterdam
#[Out]# 29   Hoogvliet  Eindhoven      Breda
#[Out]# ..         ...        ...        ...
#[Out]# 418      Jumbo      Breda    Tilburg
#[Out]# 419      Jumbo      Breda    Utrecht
#[Out]# 420       Lidl      Breda  Amsterdam
#[Out]# 421       Lidl      Breda      Breda
#[Out]# 422       Lidl      Breda  Eindhoven
#[Out]# 423       Lidl      Breda        Oss
#[Out]# 424       Lidl      Breda  Rotterdam
#[Out]# 425       Lidl      Breda    Tilburg
#[Out]# 426       Lidl      Breda    Utrecht
#[Out]# 427       Lidl      Breda  Amsterdam
#[Out]# 428       Lidl      Breda      Breda
#[Out]# 429       Lidl      Breda  Eindhoven
#[Out]# 430       Lidl      Breda        Oss
#[Out]# 431       Lidl      Breda  Rotterdam
#[Out]# 432       Lidl      Breda    Tilburg
#[Out]# 433       Lidl      Breda    Utrecht
#[Out]# 434      Jumbo  Eindhoven  Amsterdam
#[Out]# 435      Jumbo  Eindhoven      Breda
#[Out]# 436      Jumbo  Eindhoven  Eindhoven
#[Out]# 437      Jumbo  Eindhoven        Oss
#[Out]# 438      Jumbo  Eindhoven  Rotterdam
#[Out]# 439      Jumbo  Eindhoven    Tilburg
#[Out]# 440      Jumbo  Eindhoven    Utrecht
#[Out]# 441      Jumbo        Oss  Amsterdam
#[Out]# 442      Jumbo        Oss      Breda
#[Out]# 443      Jumbo        Oss  Eindhoven
#[Out]# 444      Jumbo        Oss        Oss
#[Out]# 445      Jumbo        Oss  Rotterdam
#[Out]# 446      Jumbo        Oss    Tilburg
#[Out]# 447      Jumbo        Oss    Utrecht
#[Out]# 
#[Out]# [448 rows x 3 columns]
# Tue, 08 Dec 2020 16:38:21
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT SC.store,SC.city,AC.city
    FROM StoresxCities AS SC,All_Cities AS AC

    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       SC.store    SC.city    AC.city
#[Out]# 0         Coop  Amsterdam  Amsterdam
#[Out]# 1         Coop  Amsterdam      Breda
#[Out]# 2         Coop  Amsterdam  Eindhoven
#[Out]# 3         Coop  Amsterdam        Oss
#[Out]# 4         Coop  Amsterdam  Rotterdam
#[Out]# 5         Coop  Amsterdam    Tilburg
#[Out]# 6         Coop  Amsterdam    Utrecht
#[Out]# 7    Hoogvliet      Breda  Amsterdam
#[Out]# 8    Hoogvliet      Breda      Breda
#[Out]# 9    Hoogvliet      Breda  Eindhoven
#[Out]# 10   Hoogvliet      Breda        Oss
#[Out]# 11   Hoogvliet      Breda  Rotterdam
#[Out]# 12   Hoogvliet      Breda    Tilburg
#[Out]# 13   Hoogvliet      Breda    Utrecht
#[Out]# 14       Jumbo  Rotterdam  Amsterdam
#[Out]# 15       Jumbo  Rotterdam      Breda
#[Out]# 16       Jumbo  Rotterdam  Eindhoven
#[Out]# 17       Jumbo  Rotterdam        Oss
#[Out]# 18       Jumbo  Rotterdam  Rotterdam
#[Out]# 19       Jumbo  Rotterdam    Tilburg
#[Out]# 20       Jumbo  Rotterdam    Utrecht
#[Out]# 21      Sligro  Rotterdam  Amsterdam
#[Out]# 22      Sligro  Rotterdam      Breda
#[Out]# 23      Sligro  Rotterdam  Eindhoven
#[Out]# 24      Sligro  Rotterdam        Oss
#[Out]# 25      Sligro  Rotterdam  Rotterdam
#[Out]# 26      Sligro  Rotterdam    Tilburg
#[Out]# 27      Sligro  Rotterdam    Utrecht
#[Out]# 28   Hoogvliet  Eindhoven  Amsterdam
#[Out]# 29   Hoogvliet  Eindhoven      Breda
#[Out]# ..         ...        ...        ...
#[Out]# 418      Jumbo      Breda    Tilburg
#[Out]# 419      Jumbo      Breda    Utrecht
#[Out]# 420       Lidl      Breda  Amsterdam
#[Out]# 421       Lidl      Breda      Breda
#[Out]# 422       Lidl      Breda  Eindhoven
#[Out]# 423       Lidl      Breda        Oss
#[Out]# 424       Lidl      Breda  Rotterdam
#[Out]# 425       Lidl      Breda    Tilburg
#[Out]# 426       Lidl      Breda    Utrecht
#[Out]# 427       Lidl      Breda  Amsterdam
#[Out]# 428       Lidl      Breda      Breda
#[Out]# 429       Lidl      Breda  Eindhoven
#[Out]# 430       Lidl      Breda        Oss
#[Out]# 431       Lidl      Breda  Rotterdam
#[Out]# 432       Lidl      Breda    Tilburg
#[Out]# 433       Lidl      Breda    Utrecht
#[Out]# 434      Jumbo  Eindhoven  Amsterdam
#[Out]# 435      Jumbo  Eindhoven      Breda
#[Out]# 436      Jumbo  Eindhoven  Eindhoven
#[Out]# 437      Jumbo  Eindhoven        Oss
#[Out]# 438      Jumbo  Eindhoven  Rotterdam
#[Out]# 439      Jumbo  Eindhoven    Tilburg
#[Out]# 440      Jumbo  Eindhoven    Utrecht
#[Out]# 441      Jumbo        Oss  Amsterdam
#[Out]# 442      Jumbo        Oss      Breda
#[Out]# 443      Jumbo        Oss  Eindhoven
#[Out]# 444      Jumbo        Oss        Oss
#[Out]# 445      Jumbo        Oss  Rotterdam
#[Out]# 446      Jumbo        Oss    Tilburg
#[Out]# 447      Jumbo        Oss    Utrecht
#[Out]# 
#[Out]# [448 rows x 3 columns]
# Tue, 08 Dec 2020 16:38:37
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT SC.store,SC.city,AC.city
    FROM StoresxCities AS SC,All_Cities AS AC
    WHERE SC.city NOT IN AC.city
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:38:47
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT SC.store,SC.city,AC.city
    FROM StoresxCities AS SC,All_Cities AS AC
    WHERE SC.city NOT IN All_Cities.city
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:39:01
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT SC.store,SC.city,AC.city
    FROM StoresxCities AS SC,All_Cities AS AC
  
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#       SC.store    SC.city    AC.city
#[Out]# 0         Coop  Amsterdam  Amsterdam
#[Out]# 1         Coop  Amsterdam      Breda
#[Out]# 2         Coop  Amsterdam  Eindhoven
#[Out]# 3         Coop  Amsterdam        Oss
#[Out]# 4         Coop  Amsterdam  Rotterdam
#[Out]# 5         Coop  Amsterdam    Tilburg
#[Out]# 6         Coop  Amsterdam    Utrecht
#[Out]# 7    Hoogvliet      Breda  Amsterdam
#[Out]# 8    Hoogvliet      Breda      Breda
#[Out]# 9    Hoogvliet      Breda  Eindhoven
#[Out]# 10   Hoogvliet      Breda        Oss
#[Out]# 11   Hoogvliet      Breda  Rotterdam
#[Out]# 12   Hoogvliet      Breda    Tilburg
#[Out]# 13   Hoogvliet      Breda    Utrecht
#[Out]# 14       Jumbo  Rotterdam  Amsterdam
#[Out]# 15       Jumbo  Rotterdam      Breda
#[Out]# 16       Jumbo  Rotterdam  Eindhoven
#[Out]# 17       Jumbo  Rotterdam        Oss
#[Out]# 18       Jumbo  Rotterdam  Rotterdam
#[Out]# 19       Jumbo  Rotterdam    Tilburg
#[Out]# 20       Jumbo  Rotterdam    Utrecht
#[Out]# 21      Sligro  Rotterdam  Amsterdam
#[Out]# 22      Sligro  Rotterdam      Breda
#[Out]# 23      Sligro  Rotterdam  Eindhoven
#[Out]# 24      Sligro  Rotterdam        Oss
#[Out]# 25      Sligro  Rotterdam  Rotterdam
#[Out]# 26      Sligro  Rotterdam    Tilburg
#[Out]# 27      Sligro  Rotterdam    Utrecht
#[Out]# 28   Hoogvliet  Eindhoven  Amsterdam
#[Out]# 29   Hoogvliet  Eindhoven      Breda
#[Out]# ..         ...        ...        ...
#[Out]# 418      Jumbo      Breda    Tilburg
#[Out]# 419      Jumbo      Breda    Utrecht
#[Out]# 420       Lidl      Breda  Amsterdam
#[Out]# 421       Lidl      Breda      Breda
#[Out]# 422       Lidl      Breda  Eindhoven
#[Out]# 423       Lidl      Breda        Oss
#[Out]# 424       Lidl      Breda  Rotterdam
#[Out]# 425       Lidl      Breda    Tilburg
#[Out]# 426       Lidl      Breda    Utrecht
#[Out]# 427       Lidl      Breda  Amsterdam
#[Out]# 428       Lidl      Breda      Breda
#[Out]# 429       Lidl      Breda  Eindhoven
#[Out]# 430       Lidl      Breda        Oss
#[Out]# 431       Lidl      Breda  Rotterdam
#[Out]# 432       Lidl      Breda    Tilburg
#[Out]# 433       Lidl      Breda    Utrecht
#[Out]# 434      Jumbo  Eindhoven  Amsterdam
#[Out]# 435      Jumbo  Eindhoven      Breda
#[Out]# 436      Jumbo  Eindhoven  Eindhoven
#[Out]# 437      Jumbo  Eindhoven        Oss
#[Out]# 438      Jumbo  Eindhoven  Rotterdam
#[Out]# 439      Jumbo  Eindhoven    Tilburg
#[Out]# 440      Jumbo  Eindhoven    Utrecht
#[Out]# 441      Jumbo        Oss  Amsterdam
#[Out]# 442      Jumbo        Oss      Breda
#[Out]# 443      Jumbo        Oss  Eindhoven
#[Out]# 444      Jumbo        Oss        Oss
#[Out]# 445      Jumbo        Oss  Rotterdam
#[Out]# 446      Jumbo        Oss    Tilburg
#[Out]# 447      Jumbo        Oss    Utrecht
#[Out]# 
#[Out]# [448 rows x 3 columns]
# Tue, 08 Dec 2020 16:40:02
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store)
    
    SELECT *
    FROM StoresxCities AS SC
  
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store       City
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 16:42:23
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib'(store,City) AS (
    SELECY sName,AC.City
    FROM store,ALl_Citites AS AC
    )
    
  SELECT * FROM allpossib
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:42:45
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib'(store,City) AS (
    SELECY sName,AC.City
    FROM store,All_Cities AS AC
    )
    
  SELECT * FROM allpossib
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:42:56
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib'(store,City) AS (
    SELECT sName,AC.City
    FROM store,All_Cities AS AC
    )
    
  SELECT * FROM allpossib
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:43:19
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib'(store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities
    )
    
  SELECT * FROM allpossib
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:43:32
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities
    )
    
  SELECT * FROM allpossib
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          store       City
#[Out]# 0         Coop  Amsterdam
#[Out]# 1         Coop      Breda
#[Out]# 2         Coop  Eindhoven
#[Out]# 3         Coop        Oss
#[Out]# 4         Coop  Rotterdam
#[Out]# 5         Coop    Tilburg
#[Out]# 6         Coop    Utrecht
#[Out]# 7    Hoogvliet  Amsterdam
#[Out]# 8    Hoogvliet      Breda
#[Out]# 9    Hoogvliet  Eindhoven
#[Out]# 10   Hoogvliet        Oss
#[Out]# 11   Hoogvliet  Rotterdam
#[Out]# 12   Hoogvliet    Tilburg
#[Out]# 13   Hoogvliet    Utrecht
#[Out]# 14       Jumbo  Amsterdam
#[Out]# 15       Jumbo      Breda
#[Out]# 16       Jumbo  Eindhoven
#[Out]# 17       Jumbo        Oss
#[Out]# 18       Jumbo  Rotterdam
#[Out]# 19       Jumbo    Tilburg
#[Out]# 20       Jumbo    Utrecht
#[Out]# 21      Sligro  Amsterdam
#[Out]# 22      Sligro      Breda
#[Out]# 23      Sligro  Eindhoven
#[Out]# 24      Sligro        Oss
#[Out]# 25      Sligro  Rotterdam
#[Out]# 26      Sligro    Tilburg
#[Out]# 27      Sligro    Utrecht
#[Out]# 28   Hoogvliet  Amsterdam
#[Out]# 29   Hoogvliet      Breda
#[Out]# ..         ...        ...
#[Out]# 418      Jumbo    Tilburg
#[Out]# 419      Jumbo    Utrecht
#[Out]# 420       Lidl  Amsterdam
#[Out]# 421       Lidl      Breda
#[Out]# 422       Lidl  Eindhoven
#[Out]# 423       Lidl        Oss
#[Out]# 424       Lidl  Rotterdam
#[Out]# 425       Lidl    Tilburg
#[Out]# 426       Lidl    Utrecht
#[Out]# 427       Lidl  Amsterdam
#[Out]# 428       Lidl      Breda
#[Out]# 429       Lidl  Eindhoven
#[Out]# 430       Lidl        Oss
#[Out]# 431       Lidl  Rotterdam
#[Out]# 432       Lidl    Tilburg
#[Out]# 433       Lidl    Utrecht
#[Out]# 434      Jumbo  Amsterdam
#[Out]# 435      Jumbo      Breda
#[Out]# 436      Jumbo  Eindhoven
#[Out]# 437      Jumbo        Oss
#[Out]# 438      Jumbo  Rotterdam
#[Out]# 439      Jumbo    Tilburg
#[Out]# 440      Jumbo    Utrecht
#[Out]# 441      Jumbo  Amsterdam
#[Out]# 442      Jumbo      Breda
#[Out]# 443      Jumbo  Eindhoven
#[Out]# 444      Jumbo        Oss
#[Out]# 445      Jumbo  Rotterdam
#[Out]# 446      Jumbo    Tilburg
#[Out]# 447      Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Tue, 08 Dec 2020 16:43:46
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities
    )
    
  SELECT * FROM allpossib order by store
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#            store       City
#[Out]# 0    Albert Hein  Amsterdam
#[Out]# 1    Albert Hein      Breda
#[Out]# 2    Albert Hein  Eindhoven
#[Out]# 3    Albert Hein        Oss
#[Out]# 4    Albert Hein  Rotterdam
#[Out]# 5    Albert Hein    Tilburg
#[Out]# 6    Albert Hein    Utrecht
#[Out]# 7    Albert Hein  Amsterdam
#[Out]# 8    Albert Hein      Breda
#[Out]# 9    Albert Hein  Eindhoven
#[Out]# 10   Albert Hein        Oss
#[Out]# 11   Albert Hein  Rotterdam
#[Out]# 12   Albert Hein    Tilburg
#[Out]# 13   Albert Hein    Utrecht
#[Out]# 14   Albert Hein  Amsterdam
#[Out]# 15   Albert Hein      Breda
#[Out]# 16   Albert Hein  Eindhoven
#[Out]# 17   Albert Hein        Oss
#[Out]# 18   Albert Hein  Rotterdam
#[Out]# 19   Albert Hein    Tilburg
#[Out]# 20   Albert Hein    Utrecht
#[Out]# 21   Albert Hein  Amsterdam
#[Out]# 22   Albert Hein      Breda
#[Out]# 23   Albert Hein  Eindhoven
#[Out]# 24   Albert Hein        Oss
#[Out]# 25   Albert Hein  Rotterdam
#[Out]# 26   Albert Hein    Tilburg
#[Out]# 27   Albert Hein    Utrecht
#[Out]# 28   Albert Hein  Amsterdam
#[Out]# 29   Albert Hein      Breda
#[Out]# ..           ...        ...
#[Out]# 418       Sligro    Tilburg
#[Out]# 419       Sligro    Utrecht
#[Out]# 420       Sligro  Amsterdam
#[Out]# 421       Sligro      Breda
#[Out]# 422       Sligro  Eindhoven
#[Out]# 423       Sligro        Oss
#[Out]# 424       Sligro  Rotterdam
#[Out]# 425       Sligro    Tilburg
#[Out]# 426       Sligro    Utrecht
#[Out]# 427       Sligro  Amsterdam
#[Out]# 428       Sligro      Breda
#[Out]# 429       Sligro  Eindhoven
#[Out]# 430       Sligro        Oss
#[Out]# 431       Sligro  Rotterdam
#[Out]# 432       Sligro    Tilburg
#[Out]# 433       Sligro    Utrecht
#[Out]# 434       Sligro  Amsterdam
#[Out]# 435       Sligro      Breda
#[Out]# 436       Sligro  Eindhoven
#[Out]# 437       Sligro        Oss
#[Out]# 438       Sligro  Rotterdam
#[Out]# 439       Sligro    Tilburg
#[Out]# 440       Sligro    Utrecht
#[Out]# 441       Sligro  Amsterdam
#[Out]# 442       Sligro      Breda
#[Out]# 443       Sligro  Eindhoven
#[Out]# 444       Sligro        Oss
#[Out]# 445       Sligro  Rotterdam
#[Out]# 446       Sligro    Tilburg
#[Out]# 447       Sligro    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Tue, 08 Dec 2020 16:45:45
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities),
    Missing (Store,City) AS (
    SELECT Store,City
    FROM StoresxCities,AllPossib
    WHERE StoresxCities.city NOT IN AllPossib.city
    ) 
    
    
    SELECT * FROM missing
    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:46:54
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
    SELECT * FROM Allpossib
    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          store       City
#[Out]# 0         Coop  Amsterdam
#[Out]# 1         Coop      Breda
#[Out]# 2         Coop  Eindhoven
#[Out]# 3         Coop        Oss
#[Out]# 4         Coop  Rotterdam
#[Out]# 5         Coop    Tilburg
#[Out]# 6         Coop    Utrecht
#[Out]# 7    Hoogvliet  Amsterdam
#[Out]# 8    Hoogvliet      Breda
#[Out]# 9    Hoogvliet  Eindhoven
#[Out]# 10   Hoogvliet        Oss
#[Out]# 11   Hoogvliet  Rotterdam
#[Out]# 12   Hoogvliet    Tilburg
#[Out]# 13   Hoogvliet    Utrecht
#[Out]# 14       Jumbo  Amsterdam
#[Out]# 15       Jumbo      Breda
#[Out]# 16       Jumbo  Eindhoven
#[Out]# 17       Jumbo        Oss
#[Out]# 18       Jumbo  Rotterdam
#[Out]# 19       Jumbo    Tilburg
#[Out]# 20       Jumbo    Utrecht
#[Out]# 21      Sligro  Amsterdam
#[Out]# 22      Sligro      Breda
#[Out]# 23      Sligro  Eindhoven
#[Out]# 24      Sligro        Oss
#[Out]# 25      Sligro  Rotterdam
#[Out]# 26      Sligro    Tilburg
#[Out]# 27      Sligro    Utrecht
#[Out]# 28   Hoogvliet  Amsterdam
#[Out]# 29   Hoogvliet      Breda
#[Out]# ..         ...        ...
#[Out]# 418      Jumbo    Tilburg
#[Out]# 419      Jumbo    Utrecht
#[Out]# 420       Lidl  Amsterdam
#[Out]# 421       Lidl      Breda
#[Out]# 422       Lidl  Eindhoven
#[Out]# 423       Lidl        Oss
#[Out]# 424       Lidl  Rotterdam
#[Out]# 425       Lidl    Tilburg
#[Out]# 426       Lidl    Utrecht
#[Out]# 427       Lidl  Amsterdam
#[Out]# 428       Lidl      Breda
#[Out]# 429       Lidl  Eindhoven
#[Out]# 430       Lidl        Oss
#[Out]# 431       Lidl  Rotterdam
#[Out]# 432       Lidl    Tilburg
#[Out]# 433       Lidl    Utrecht
#[Out]# 434      Jumbo  Amsterdam
#[Out]# 435      Jumbo      Breda
#[Out]# 436      Jumbo  Eindhoven
#[Out]# 437      Jumbo        Oss
#[Out]# 438      Jumbo  Rotterdam
#[Out]# 439      Jumbo    Tilburg
#[Out]# 440      Jumbo    Utrecht
#[Out]# 441      Jumbo  Amsterdam
#[Out]# 442      Jumbo      Breda
#[Out]# 443      Jumbo  Eindhoven
#[Out]# 444      Jumbo        Oss
#[Out]# 445      Jumbo  Rotterdam
#[Out]# 446      Jumbo    Tilburg
#[Out]# 447      Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Tue, 08 Dec 2020 16:47:03
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
    SELECT * FROM StoresxCities
    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store       City
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 16:48:13
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT * 
FROM StoresxCities
WHERE StoresxCities.City = 'Breda'
    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store   City
#[Out]# 0     Hoogvliet  Breda
#[Out]# 1        Sligro  Breda
#[Out]# 2          Coop  Breda
#[Out]# 3          Dirk  Breda
#[Out]# 4   Albert Hein  Breda
#[Out]# 5   Albert Hein  Breda
#[Out]# 6     Hoogvliet  Breda
#[Out]# 7        Sligro  Breda
#[Out]# 8          Coop  Breda
#[Out]# 9         Jumbo  Breda
#[Out]# 10         Lidl  Breda
#[Out]# 11         Lidl  Breda
# Tue, 08 Dec 2020 16:52:53
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT * 
FROM StoresxCities



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store       City
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 16:53:09
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT * 
FROM AllPossib



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          store       City
#[Out]# 0         Coop  Amsterdam
#[Out]# 1         Coop      Breda
#[Out]# 2         Coop  Eindhoven
#[Out]# 3         Coop        Oss
#[Out]# 4         Coop  Rotterdam
#[Out]# 5         Coop    Tilburg
#[Out]# 6         Coop    Utrecht
#[Out]# 7    Hoogvliet  Amsterdam
#[Out]# 8    Hoogvliet      Breda
#[Out]# 9    Hoogvliet  Eindhoven
#[Out]# 10   Hoogvliet        Oss
#[Out]# 11   Hoogvliet  Rotterdam
#[Out]# 12   Hoogvliet    Tilburg
#[Out]# 13   Hoogvliet    Utrecht
#[Out]# 14       Jumbo  Amsterdam
#[Out]# 15       Jumbo      Breda
#[Out]# 16       Jumbo  Eindhoven
#[Out]# 17       Jumbo        Oss
#[Out]# 18       Jumbo  Rotterdam
#[Out]# 19       Jumbo    Tilburg
#[Out]# 20       Jumbo    Utrecht
#[Out]# 21      Sligro  Amsterdam
#[Out]# 22      Sligro      Breda
#[Out]# 23      Sligro  Eindhoven
#[Out]# 24      Sligro        Oss
#[Out]# 25      Sligro  Rotterdam
#[Out]# 26      Sligro    Tilburg
#[Out]# 27      Sligro    Utrecht
#[Out]# 28   Hoogvliet  Amsterdam
#[Out]# 29   Hoogvliet      Breda
#[Out]# ..         ...        ...
#[Out]# 418      Jumbo    Tilburg
#[Out]# 419      Jumbo    Utrecht
#[Out]# 420       Lidl  Amsterdam
#[Out]# 421       Lidl      Breda
#[Out]# 422       Lidl  Eindhoven
#[Out]# 423       Lidl        Oss
#[Out]# 424       Lidl  Rotterdam
#[Out]# 425       Lidl    Tilburg
#[Out]# 426       Lidl    Utrecht
#[Out]# 427       Lidl  Amsterdam
#[Out]# 428       Lidl      Breda
#[Out]# 429       Lidl  Eindhoven
#[Out]# 430       Lidl        Oss
#[Out]# 431       Lidl  Rotterdam
#[Out]# 432       Lidl    Tilburg
#[Out]# 433       Lidl    Utrecht
#[Out]# 434      Jumbo  Amsterdam
#[Out]# 435      Jumbo      Breda
#[Out]# 436      Jumbo  Eindhoven
#[Out]# 437      Jumbo        Oss
#[Out]# 438      Jumbo  Rotterdam
#[Out]# 439      Jumbo    Tilburg
#[Out]# 440      Jumbo    Utrecht
#[Out]# 441      Jumbo  Amsterdam
#[Out]# 442      Jumbo      Breda
#[Out]# 443      Jumbo  Eindhoven
#[Out]# 444      Jumbo        Oss
#[Out]# 445      Jumbo  Rotterdam
#[Out]# 446      Jumbo    Tilburg
#[Out]# 447      Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Tue, 08 Dec 2020 16:54:17
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT * 
FROM AllPossib
WHERE City IS NOT IN (SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store)



    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:54:33
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT * 
FROM AllPossib
WHERE City IS NOT IN (SELECT city
    FROM customer)



    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 16:55:07
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT *
FROM AllPossib




    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       City
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Tue, 08 Dec 2020 16:55:38
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT *
FROM store




    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     0         Coop      Kalverstraat  Amsterdam
#[Out]# 1     1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 5     5       Sligro     Stationsplein      Breda
#[Out]# 6     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 7     7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 8     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 9     9  Albert Hein         Koestraat    Tilburg
#[Out]# 10   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 11   11  Albert Hein          Hofplein  Rotterdam
#[Out]# 12   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 13   13         Coop         Koestraat    Tilburg
#[Out]# 14   14         Coop     Keizersgracht  Amsterdam
#[Out]# 15   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 16   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 17   17    Hoogvliet        Kerkstraat  Eindhoven
#[Out]# 18   18       Sligro       Parallelweg    Tilburg
#[Out]# 19   19         Coop       Karrestraat      Breda
#[Out]# 20   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 21   21         Coop      Kasteeldreef    Tilburg
#[Out]# 22   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 23   23         Dirk     Stationsplein      Breda
#[Out]# 24   24  Albert Hein     Stationsplein      Breda
#[Out]# 25   25  Albert Hein     Stationsplein      Breda
#[Out]# 26   26    Hoogvliet   Sint Annastraat      Breda
#[Out]# 27   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 28   28    Hoogvliet         Koestraat    Tilburg
#[Out]# 29   29       Sligro      Marnixstraat  Amsterdam
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   34         Coop          Bierkaai  Amsterdam
#[Out]# 35   35         Lidl     Julianastraat    Utrecht
#[Out]# 36   36         Lidl     Julianastraat  Eindhoven
#[Out]# 37   37        Jumbo          Molenweg  Eindhoven
#[Out]# 38   38    Hoogvliet          Hofplein  Rotterdam
#[Out]# 39   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 40   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 41   41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 42   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 43   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 44   44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 45   45         Coop      Kasteeldreef    Tilburg
#[Out]# 46   46         Lidl        Bergselaan  Rotterdam
#[Out]# 47   47         Coop     Julianastraat  Rotterdam
#[Out]# 48   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 49   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 50   50       Sligro     Stationsplein      Breda
#[Out]# 51   51         Coop       Parallelweg    Utrecht
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   53         Coop        Hoogstraat    Utrecht
#[Out]# 54   54         Dirk     Julianastraat  Eindhoven
#[Out]# 55   55         Coop   Sint Annastraat      Breda
#[Out]# 56   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 57   57         Dirk       Molenstraat  Eindhoven
#[Out]# 58   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 59   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60         Lidl      Pannekoekweg      Breda
#[Out]# 61   61         Lidl      Pannekoekweg      Breda
#[Out]# 62   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63        Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Tue, 08 Dec 2020 16:55:44
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT sName
FROM store




    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 16:55:52
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT sName,city
FROM store




    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Tue, 08 Dec 2020 16:56:05
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT *
FROM Allpossib




    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       City
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Tue, 08 Dec 2020 16:56:41
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT *
FROM Allpossib
EXCEPT 
SELECT DISTINCT sName, city
FROM store




    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       City
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 16:56:55
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT *
FROM Allpossib





    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       City
#[Out]# 0          Coop  Amsterdam
#[Out]# 1          Coop      Breda
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Coop  Rotterdam
#[Out]# 5          Coop    Tilburg
#[Out]# 6          Coop    Utrecht
#[Out]# 7     Hoogvliet  Amsterdam
#[Out]# 8     Hoogvliet      Breda
#[Out]# 9     Hoogvliet  Eindhoven
#[Out]# 10    Hoogvliet        Oss
#[Out]# 11    Hoogvliet  Rotterdam
#[Out]# 12    Hoogvliet    Tilburg
#[Out]# 13    Hoogvliet    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21       Sligro  Amsterdam
#[Out]# 22       Sligro      Breda
#[Out]# 23       Sligro  Eindhoven
#[Out]# 24       Sligro        Oss
#[Out]# 25       Sligro  Rotterdam
#[Out]# 26       Sligro    Tilburg
#[Out]# 27       Sligro    Utrecht
#[Out]# 28  Albert Hein  Amsterdam
#[Out]# 29  Albert Hein      Breda
#[Out]# 30  Albert Hein  Eindhoven
#[Out]# 31  Albert Hein        Oss
#[Out]# 32  Albert Hein  Rotterdam
#[Out]# 33  Albert Hein    Tilburg
#[Out]# 34  Albert Hein    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42         Dirk  Amsterdam
#[Out]# 43         Dirk      Breda
#[Out]# 44         Dirk  Eindhoven
#[Out]# 45         Dirk        Oss
#[Out]# 46         Dirk  Rotterdam
#[Out]# 47         Dirk    Tilburg
#[Out]# 48         Dirk    Utrecht
# Tue, 08 Dec 2020 16:57:07
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT *
FROM Allpossib

order by store desc



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       City
#[Out]# 0        Sligro  Amsterdam
#[Out]# 1        Sligro      Breda
#[Out]# 2        Sligro  Eindhoven
#[Out]# 3        Sligro        Oss
#[Out]# 4        Sligro  Rotterdam
#[Out]# 5        Sligro    Tilburg
#[Out]# 6        Sligro    Utrecht
#[Out]# 7          Lidl  Amsterdam
#[Out]# 8          Lidl      Breda
#[Out]# 9          Lidl  Eindhoven
#[Out]# 10         Lidl        Oss
#[Out]# 11         Lidl  Rotterdam
#[Out]# 12         Lidl    Tilburg
#[Out]# 13         Lidl    Utrecht
#[Out]# 14        Jumbo  Amsterdam
#[Out]# 15        Jumbo      Breda
#[Out]# 16        Jumbo  Eindhoven
#[Out]# 17        Jumbo        Oss
#[Out]# 18        Jumbo  Rotterdam
#[Out]# 19        Jumbo    Tilburg
#[Out]# 20        Jumbo    Utrecht
#[Out]# 21    Hoogvliet  Amsterdam
#[Out]# 22    Hoogvliet      Breda
#[Out]# 23    Hoogvliet  Eindhoven
#[Out]# 24    Hoogvliet        Oss
#[Out]# 25    Hoogvliet  Rotterdam
#[Out]# 26    Hoogvliet    Tilburg
#[Out]# 27    Hoogvliet    Utrecht
#[Out]# 28         Dirk  Amsterdam
#[Out]# 29         Dirk      Breda
#[Out]# 30         Dirk  Eindhoven
#[Out]# 31         Dirk        Oss
#[Out]# 32         Dirk  Rotterdam
#[Out]# 33         Dirk    Tilburg
#[Out]# 34         Dirk    Utrecht
#[Out]# 35         Coop  Amsterdam
#[Out]# 36         Coop      Breda
#[Out]# 37         Coop  Eindhoven
#[Out]# 38         Coop        Oss
#[Out]# 39         Coop  Rotterdam
#[Out]# 40         Coop    Tilburg
#[Out]# 41         Coop    Utrecht
#[Out]# 42  Albert Hein  Amsterdam
#[Out]# 43  Albert Hein      Breda
#[Out]# 44  Albert Hein  Eindhoven
#[Out]# 45  Albert Hein        Oss
#[Out]# 46  Albert Hein  Rotterdam
#[Out]# 47  Albert Hein    Tilburg
#[Out]# 48  Albert Hein    Utrecht
# Tue, 08 Dec 2020 16:57:13
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT *
FROM Allpossib

order by store asc



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       City
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein      Breda
#[Out]# 2   Albert Hein  Eindhoven
#[Out]# 3   Albert Hein        Oss
#[Out]# 4   Albert Hein  Rotterdam
#[Out]# 5   Albert Hein    Tilburg
#[Out]# 6   Albert Hein    Utrecht
#[Out]# 7          Coop  Amsterdam
#[Out]# 8          Coop      Breda
#[Out]# 9          Coop  Eindhoven
#[Out]# 10         Coop        Oss
#[Out]# 11         Coop  Rotterdam
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Coop    Utrecht
#[Out]# 14         Dirk  Amsterdam
#[Out]# 15         Dirk      Breda
#[Out]# 16         Dirk  Eindhoven
#[Out]# 17         Dirk        Oss
#[Out]# 18         Dirk  Rotterdam
#[Out]# 19         Dirk    Tilburg
#[Out]# 20         Dirk    Utrecht
#[Out]# 21    Hoogvliet  Amsterdam
#[Out]# 22    Hoogvliet      Breda
#[Out]# 23    Hoogvliet  Eindhoven
#[Out]# 24    Hoogvliet        Oss
#[Out]# 25    Hoogvliet  Rotterdam
#[Out]# 26    Hoogvliet    Tilburg
#[Out]# 27    Hoogvliet    Utrecht
#[Out]# 28        Jumbo  Amsterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30        Jumbo  Eindhoven
#[Out]# 31        Jumbo        Oss
#[Out]# 32        Jumbo  Rotterdam
#[Out]# 33        Jumbo    Tilburg
#[Out]# 34        Jumbo    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43       Sligro      Breda
#[Out]# 44       Sligro  Eindhoven
#[Out]# 45       Sligro        Oss
#[Out]# 46       Sligro  Rotterdam
#[Out]# 47       Sligro    Tilburg
#[Out]# 48       Sligro    Utrecht
# Tue, 08 Dec 2020 16:57:44
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT DISTINCT *
FROM StoresxCities

order by store asc



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store       City
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop  Rotterdam
#[Out]# 7          Coop    Tilburg
#[Out]# 8          Coop      Breda
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet    Tilburg
#[Out]# 16    Hoogvliet  Rotterdam
#[Out]# 17        Jumbo  Rotterdam
#[Out]# 18        Jumbo    Tilburg
#[Out]# 19        Jumbo  Eindhoven
#[Out]# 20        Jumbo      Breda
#[Out]# 21        Jumbo        Oss
#[Out]# 22         Lidl  Eindhoven
#[Out]# 23         Lidl  Amsterdam
#[Out]# 24         Lidl    Utrecht
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl      Breda
#[Out]# 27       Sligro  Rotterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro    Tilburg
#[Out]# 31       Sligro  Amsterdam
# Tue, 08 Dec 2020 17:02:02
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT  *
FROM StoresxCities

order by store asc



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store       City
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein      Breda
#[Out]# 5   Albert Hein    Utrecht
#[Out]# 6   Albert Hein  Rotterdam
#[Out]# 7   Albert Hein    Utrecht
#[Out]# 8          Coop  Amsterdam
#[Out]# 9          Coop  Rotterdam
#[Out]# 10         Coop    Tilburg
#[Out]# 11         Coop  Amsterdam
#[Out]# 12         Coop      Breda
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop    Utrecht
#[Out]# 15         Coop  Amsterdam
#[Out]# 16         Coop    Utrecht
#[Out]# 17         Coop    Tilburg
#[Out]# 18         Coop  Rotterdam
#[Out]# 19         Coop    Utrecht
#[Out]# 20         Coop    Utrecht
#[Out]# 21         Coop      Breda
#[Out]# 22         Dirk      Breda
#[Out]# 23         Dirk  Eindhoven
#[Out]# 24         Dirk  Eindhoven
#[Out]# 25         Dirk  Eindhoven
#[Out]# 26         Dirk  Eindhoven
#[Out]# 27         Dirk  Rotterdam
#[Out]# 28    Hoogvliet      Breda
#[Out]# 29    Hoogvliet  Eindhoven
#[Out]# ..          ...        ...
#[Out]# 34    Hoogvliet  Rotterdam
#[Out]# 35    Hoogvliet    Tilburg
#[Out]# 36    Hoogvliet  Rotterdam
#[Out]# 37        Jumbo  Rotterdam
#[Out]# 38        Jumbo  Rotterdam
#[Out]# 39        Jumbo    Tilburg
#[Out]# 40        Jumbo  Eindhoven
#[Out]# 41        Jumbo  Eindhoven
#[Out]# 42        Jumbo      Breda
#[Out]# 43        Jumbo  Eindhoven
#[Out]# 44        Jumbo        Oss
#[Out]# 45         Lidl  Eindhoven
#[Out]# 46         Lidl  Amsterdam
#[Out]# 47         Lidl    Utrecht
#[Out]# 48         Lidl  Amsterdam
#[Out]# 49         Lidl    Utrecht
#[Out]# 50         Lidl  Eindhoven
#[Out]# 51         Lidl  Rotterdam
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Lidl      Breda
#[Out]# 54         Lidl      Breda
#[Out]# 55       Sligro  Rotterdam
#[Out]# 56       Sligro      Breda
#[Out]# 57       Sligro  Eindhoven
#[Out]# 58       Sligro    Tilburg
#[Out]# 59       Sligro  Amsterdam
#[Out]# 60       Sligro  Amsterdam
#[Out]# 61       Sligro  Eindhoven
#[Out]# 62       Sligro  Amsterdam
#[Out]# 63       Sligro      Breda
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 17:02:57
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT  sName,city
FROM store

order by sName asc



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein      Breda
#[Out]# 5   Albert Hein    Utrecht
#[Out]# 6   Albert Hein  Rotterdam
#[Out]# 7   Albert Hein    Utrecht
#[Out]# 8          Coop  Amsterdam
#[Out]# 9          Coop  Rotterdam
#[Out]# 10         Coop    Tilburg
#[Out]# 11         Coop  Amsterdam
#[Out]# 12         Coop      Breda
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop    Utrecht
#[Out]# 15         Coop  Amsterdam
#[Out]# 16         Coop    Utrecht
#[Out]# 17         Coop    Tilburg
#[Out]# 18         Coop  Rotterdam
#[Out]# 19         Coop    Utrecht
#[Out]# 20         Coop    Utrecht
#[Out]# 21         Coop      Breda
#[Out]# 22         Dirk      Breda
#[Out]# 23         Dirk  Eindhoven
#[Out]# 24         Dirk  Eindhoven
#[Out]# 25         Dirk  Eindhoven
#[Out]# 26         Dirk  Eindhoven
#[Out]# 27         Dirk  Rotterdam
#[Out]# 28    Hoogvliet      Breda
#[Out]# 29    Hoogvliet  Eindhoven
#[Out]# ..          ...        ...
#[Out]# 34    Hoogvliet  Rotterdam
#[Out]# 35    Hoogvliet    Tilburg
#[Out]# 36    Hoogvliet  Rotterdam
#[Out]# 37        Jumbo  Rotterdam
#[Out]# 38        Jumbo  Rotterdam
#[Out]# 39        Jumbo    Tilburg
#[Out]# 40        Jumbo  Eindhoven
#[Out]# 41        Jumbo  Eindhoven
#[Out]# 42        Jumbo      Breda
#[Out]# 43        Jumbo  Eindhoven
#[Out]# 44        Jumbo        Oss
#[Out]# 45         Lidl  Eindhoven
#[Out]# 46         Lidl  Amsterdam
#[Out]# 47         Lidl    Utrecht
#[Out]# 48         Lidl  Amsterdam
#[Out]# 49         Lidl    Utrecht
#[Out]# 50         Lidl  Eindhoven
#[Out]# 51         Lidl  Rotterdam
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Lidl      Breda
#[Out]# 54         Lidl      Breda
#[Out]# 55       Sligro  Rotterdam
#[Out]# 56       Sligro      Breda
#[Out]# 57       Sligro  Eindhoven
#[Out]# 58       Sligro    Tilburg
#[Out]# 59       Sligro  Amsterdam
#[Out]# 60       Sligro  Amsterdam
#[Out]# 61       Sligro  Eindhoven
#[Out]# 62       Sligro  Amsterdam
#[Out]# 63       Sligro      Breda
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 17:04:35
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT sName
FROM store
GROUP BY sname



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Tue, 08 Dec 2020 17:05:30
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT sName,All_Cities.City
    FROM store,All_Cities)
    
SELECT * FROM allstores



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          store
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Tue, 08 Dec 2020 17:05:47
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,All_Cities.City
    FROM AllStores,All_Cities)
    
SELECT * FROM allstores



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          store
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Tue, 08 Dec 2020 17:05:52
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,All_Cities.City
    FROM AllStores,All_Cities)
    
SELECT * FROM AllPossib



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       City
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein      Breda
#[Out]# 2   Albert Hein  Eindhoven
#[Out]# 3   Albert Hein        Oss
#[Out]# 4   Albert Hein  Rotterdam
#[Out]# 5   Albert Hein    Tilburg
#[Out]# 6   Albert Hein    Utrecht
#[Out]# 7          Coop  Amsterdam
#[Out]# 8          Coop      Breda
#[Out]# 9          Coop  Eindhoven
#[Out]# 10         Coop        Oss
#[Out]# 11         Coop  Rotterdam
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Coop    Utrecht
#[Out]# 14         Dirk  Amsterdam
#[Out]# 15         Dirk      Breda
#[Out]# 16         Dirk  Eindhoven
#[Out]# 17         Dirk        Oss
#[Out]# 18         Dirk  Rotterdam
#[Out]# 19         Dirk    Tilburg
#[Out]# 20         Dirk    Utrecht
#[Out]# 21    Hoogvliet  Amsterdam
#[Out]# 22    Hoogvliet      Breda
#[Out]# 23    Hoogvliet  Eindhoven
#[Out]# 24    Hoogvliet        Oss
#[Out]# 25    Hoogvliet  Rotterdam
#[Out]# 26    Hoogvliet    Tilburg
#[Out]# 27    Hoogvliet    Utrecht
#[Out]# 28        Jumbo  Amsterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30        Jumbo  Eindhoven
#[Out]# 31        Jumbo        Oss
#[Out]# 32        Jumbo  Rotterdam
#[Out]# 33        Jumbo    Tilburg
#[Out]# 34        Jumbo    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43       Sligro      Breda
#[Out]# 44       Sligro  Eindhoven
#[Out]# 45       Sligro        Oss
#[Out]# 46       Sligro  Rotterdam
#[Out]# 47       Sligro    Tilburg
#[Out]# 48       Sligro    Utrecht
# Tue, 08 Dec 2020 17:06:00
query4_3 = '''
WITH All_Cities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,All_Cities.City
    FROM AllStores,All_Cities)
    
SELECT * FROM allstores



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          store
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Tue, 08 Dec 2020 17:06:15
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
SELECT * FROM AllCities



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 17:06:30
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
SELECT * FROM AllStores



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          store
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Tue, 08 Dec 2020 17:06:38
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
SELECT * FROM AllPossib



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       City
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein      Breda
#[Out]# 2   Albert Hein  Eindhoven
#[Out]# 3   Albert Hein        Oss
#[Out]# 4   Albert Hein  Rotterdam
#[Out]# 5   Albert Hein    Tilburg
#[Out]# 6   Albert Hein    Utrecht
#[Out]# 7          Coop  Amsterdam
#[Out]# 8          Coop      Breda
#[Out]# 9          Coop  Eindhoven
#[Out]# 10         Coop        Oss
#[Out]# 11         Coop  Rotterdam
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Coop    Utrecht
#[Out]# 14         Dirk  Amsterdam
#[Out]# 15         Dirk      Breda
#[Out]# 16         Dirk  Eindhoven
#[Out]# 17         Dirk        Oss
#[Out]# 18         Dirk  Rotterdam
#[Out]# 19         Dirk    Tilburg
#[Out]# 20         Dirk    Utrecht
#[Out]# 21    Hoogvliet  Amsterdam
#[Out]# 22    Hoogvliet      Breda
#[Out]# 23    Hoogvliet  Eindhoven
#[Out]# 24    Hoogvliet        Oss
#[Out]# 25    Hoogvliet  Rotterdam
#[Out]# 26    Hoogvliet    Tilburg
#[Out]# 27    Hoogvliet    Utrecht
#[Out]# 28        Jumbo  Amsterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30        Jumbo  Eindhoven
#[Out]# 31        Jumbo        Oss
#[Out]# 32        Jumbo  Rotterdam
#[Out]# 33        Jumbo    Tilburg
#[Out]# 34        Jumbo    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43       Sligro      Breda
#[Out]# 44       Sligro  Eindhoven
#[Out]# 45       Sligro        Oss
#[Out]# 46       Sligro  Rotterdam
#[Out]# 47       Sligro    Tilburg
#[Out]# 48       Sligro    Utrecht
# Tue, 08 Dec 2020 17:06:49
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
SELECT * FROM StoresxCities



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store       City
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Tue, 08 Dec 2020 17:07:06
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
SELECT * FROM StoresxCities



    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           Store       City
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 17:08:10
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
SELECT * 
FROM StoresxCities
EXCEPT 
SELECT * 
FROM AllPossib


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [Store, City]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:08:27
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
SELECT sName 
FROM StoresxCities
EXCEPT 
SELECT sName 
FROM AllPossib


    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:08:35
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
SELECT store 
FROM StoresxCities
EXCEPT 
SELECT store 
FROM AllPossib


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [store]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:08:59
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
 
SELECT store 
FROM AllPossib
except
SELECT store 
FROM StoresxCities

    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [store]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:09:09
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
 
SELECT store,city
FROM AllPossib
except
SELECT store,city
FROM StoresxCities

    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 17:11:03
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
 
SELECT *

    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:11:11
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
 
SELECT *
FROM Allposib
    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:11:17
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
 
SELECT *
FROM Allpossib
    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       City
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein      Breda
#[Out]# 2   Albert Hein  Eindhoven
#[Out]# 3   Albert Hein        Oss
#[Out]# 4   Albert Hein  Rotterdam
#[Out]# 5   Albert Hein    Tilburg
#[Out]# 6   Albert Hein    Utrecht
#[Out]# 7          Coop  Amsterdam
#[Out]# 8          Coop      Breda
#[Out]# 9          Coop  Eindhoven
#[Out]# 10         Coop        Oss
#[Out]# 11         Coop  Rotterdam
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Coop    Utrecht
#[Out]# 14         Dirk  Amsterdam
#[Out]# 15         Dirk      Breda
#[Out]# 16         Dirk  Eindhoven
#[Out]# 17         Dirk        Oss
#[Out]# 18         Dirk  Rotterdam
#[Out]# 19         Dirk    Tilburg
#[Out]# 20         Dirk    Utrecht
#[Out]# 21    Hoogvliet  Amsterdam
#[Out]# 22    Hoogvliet      Breda
#[Out]# 23    Hoogvliet  Eindhoven
#[Out]# 24    Hoogvliet        Oss
#[Out]# 25    Hoogvliet  Rotterdam
#[Out]# 26    Hoogvliet    Tilburg
#[Out]# 27    Hoogvliet    Utrecht
#[Out]# 28        Jumbo  Amsterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30        Jumbo  Eindhoven
#[Out]# 31        Jumbo        Oss
#[Out]# 32        Jumbo  Rotterdam
#[Out]# 33        Jumbo    Tilburg
#[Out]# 34        Jumbo    Utrecht
#[Out]# 35         Lidl  Amsterdam
#[Out]# 36         Lidl      Breda
#[Out]# 37         Lidl  Eindhoven
#[Out]# 38         Lidl        Oss
#[Out]# 39         Lidl  Rotterdam
#[Out]# 40         Lidl    Tilburg
#[Out]# 41         Lidl    Utrecht
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43       Sligro      Breda
#[Out]# 44       Sligro  Eindhoven
#[Out]# 45       Sligro        Oss
#[Out]# 46       Sligro  Rotterdam
#[Out]# 47       Sligro    Tilburg
#[Out]# 48       Sligro    Utrecht
# Tue, 08 Dec 2020 17:13:50
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities)
    
 
SELECT store,city
FROM AllPossib
except
SELECT store,city
FROM StoresxCities

    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 17:14:50
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities)
    
 SELECT * FROM missingstores


    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:14:58
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities)
    
 SELECT * FROM missingstores


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 17:32:04
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities),
    FinalStores (store) AS (
    SELECT allstores.store
    FROM AllStores,MissingStores
    WHERE Missingstores.store NOT IN AllStores.store)
     
    SELECT * FROM FinalStores
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:33:25
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities),
    FinalStores (store) AS (
    SELECT allstores.store
    FROM AllStores,MissingStores
    WHERE Missingstores.store NOT IN SELECT sName
    FROM store
    GROUP BY sname)
     
    SELECT * FROM FinalStores
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:33:37
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities),
    FinalStores (store) AS (
    SELECT allstores.store
    FROM AllStores,MissingStores
    WHERE Missingstores.store NOT IN (SELECT sName
    FROM store
    GROUP BY sname))
     
    SELECT * FROM FinalStores
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [store]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:33:44
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities),
    FinalStores (store) AS (
    SELECT allstores.store
    FROM AllStores,MissingStores
    WHERE Missingstores.store IN (SELECT sName
    FROM store
    GROUP BY sname))
     
    SELECT * FROM FinalStores
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#            store
#[Out]# 0    Albert Hein
#[Out]# 1           Coop
#[Out]# 2           Dirk
#[Out]# 3      Hoogvliet
#[Out]# 4          Jumbo
#[Out]# 5           Lidl
#[Out]# 6         Sligro
#[Out]# 7    Albert Hein
#[Out]# 8           Coop
#[Out]# 9           Dirk
#[Out]# 10     Hoogvliet
#[Out]# 11         Jumbo
#[Out]# 12          Lidl
#[Out]# 13        Sligro
#[Out]# 14   Albert Hein
#[Out]# 15          Coop
#[Out]# 16          Dirk
#[Out]# 17     Hoogvliet
#[Out]# 18         Jumbo
#[Out]# 19          Lidl
#[Out]# 20        Sligro
#[Out]# 21   Albert Hein
#[Out]# 22          Coop
#[Out]# 23          Dirk
#[Out]# 24     Hoogvliet
#[Out]# 25         Jumbo
#[Out]# 26          Lidl
#[Out]# 27        Sligro
#[Out]# 28   Albert Hein
#[Out]# 29          Coop
#[Out]# ..           ...
#[Out]# 89          Lidl
#[Out]# 90        Sligro
#[Out]# 91   Albert Hein
#[Out]# 92          Coop
#[Out]# 93          Dirk
#[Out]# 94     Hoogvliet
#[Out]# 95         Jumbo
#[Out]# 96          Lidl
#[Out]# 97        Sligro
#[Out]# 98   Albert Hein
#[Out]# 99          Coop
#[Out]# 100         Dirk
#[Out]# 101    Hoogvliet
#[Out]# 102        Jumbo
#[Out]# 103         Lidl
#[Out]# 104       Sligro
#[Out]# 105  Albert Hein
#[Out]# 106         Coop
#[Out]# 107         Dirk
#[Out]# 108    Hoogvliet
#[Out]# 109        Jumbo
#[Out]# 110         Lidl
#[Out]# 111       Sligro
#[Out]# 112  Albert Hein
#[Out]# 113         Coop
#[Out]# 114         Dirk
#[Out]# 115    Hoogvliet
#[Out]# 116        Jumbo
#[Out]# 117         Lidl
#[Out]# 118       Sligro
#[Out]# 
#[Out]# [119 rows x 1 columns]
# Tue, 08 Dec 2020 17:34:08
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities),
    FinalStores (store) AS (
    SELECT allstores.store
    FROM MissingStores
    WHERE Missingstores.store IN (SELECT sName
    FROM store
    GROUP BY sname))
     
    SELECT * FROM FinalStores
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:34:17
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities),
    FinalStores (store) AS (
    SELECT MissingStores.store
    FROM MissingStores
    WHERE Missingstores.store IN (SELECT sName
    FROM store
    GROUP BY sname))
     
    SELECT * FROM FinalStores
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store
#[Out]# 0   Albert Hein
#[Out]# 1   Albert Hein
#[Out]# 2          Coop
#[Out]# 3          Coop
#[Out]# 4          Dirk
#[Out]# 5          Dirk
#[Out]# 6          Dirk
#[Out]# 7          Dirk
#[Out]# 8     Hoogvliet
#[Out]# 9     Hoogvliet
#[Out]# 10    Hoogvliet
#[Out]# 11        Jumbo
#[Out]# 12        Jumbo
#[Out]# 13         Lidl
#[Out]# 14         Lidl
#[Out]# 15       Sligro
#[Out]# 16       Sligro
# Tue, 08 Dec 2020 17:35:10
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities),
    FinalStores (store) AS (
    SELECT store.sname
    FROM MissingStores
    WHERE Missingstores.store NOT IN (SELECT sName
    FROM store
    GROUP BY sname))
     
    SELECT * FROM FinalStores
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:35:45
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities)
     
    SELECT * FROM missinsstores
    
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
# Tue, 08 Dec 2020 17:35:51
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities)
     
    SELECT * FROM missingstores
    
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           store       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 17:37:17
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities)
     
SELECT * FROM AllStores
    
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          store
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Tue, 08 Dec 2020 17:37:36
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities)
     
SELECT store
FROM AllStores
EXCEPT
SELECT store
FROM Missingstores
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [store]
#[Out]# Index: []
# Tue, 08 Dec 2020 17:38:03
query4_3 = '''
WITH AllCities (city) AS (
    SELECT city
    FROM customer
    UNION 
    SELECT city
    FROM store),
    StoresxCities (Store,City) AS (
    SELECT sName,City
    FROM store
    GROUP BY sName,city),
    AllStores (store) AS (
    SELECT sName
    FROM store
    GROUP BY sname),
    AllPossib (store,City) AS (
    SELECT store,AllCities.City
    FROM AllStores,AllCities),
    MissingStores (store,city) AS (
    SELECT store,city
    FROM AllPossib
    except
    SELECT store,city
    FROM StoresxCities)
     
SELECT store
FROM AllStores
EXCEPT
SELECT store
FROM Missingstores
 


    
 
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [store]
#[Out]# Index: []

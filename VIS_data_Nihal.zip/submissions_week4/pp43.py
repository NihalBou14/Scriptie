# IPython log file

# Thu, 03 Dec 2020 10:11:32
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Thu, 03 Dec 2020 10:11:33
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Thu, 03 Dec 2020 10:11:42
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Thu, 03 Dec 2020 10:21:46
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk(./):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()
# Thu, 03 Dec 2020 10:22:00
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()

# IPython log file

# Mon, 07 Dec 2020 14:53:24
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 14:53:24
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Mon, 07 Dec 2020 14:53:24
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Mon, 07 Dec 2020 14:53:24
query4_3 = '''
WITH cities(city) AS (
           (
               SELECT customer.city
               FROM   customer
           )
           UNION
           (
               SELECT s.city
               FROM   store AS s
           )
)
'''
demo = '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       (
           SELECT customer.city
           FROM   customer
       )
       UNION
       (
           SELECT s.city
           FROM   store AS s
       )
       WHERE store.city IN
)
'''
# Mon, 07 Dec 2020 14:53:24
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 14:53:24
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 14:54:27
query4_3 = '''
WITH cities(city) AS (
           (
               SELECT customer.city
               FROM   customer
           )
           UNION
           (
               SELECT s.city
               FROM   store AS s
           )
)
'''
demo = '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       
           SELECT customer.city
           FROM   customer
       
       UNION
       
           SELECT s.city
           FROM   store AS s
       
       WHERE store.city IN
)
'''
# Mon, 07 Dec 2020 14:54:37
query4_3 = '''
WITH cities(city) AS (
           
               SELECT customer.city
               FROM   customer
           
           UNION
           
               SELECT s.city
               FROM   store AS s
           
)
'''
demo = '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       (
           SELECT customer.city
           FROM   customer
       )
       UNION
       (
           SELECT s.city
           FROM   store AS s
       )
       WHERE store.city IN
)
'''
# Mon, 07 Dec 2020 14:54:37
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 14:54:38
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 14:56:14
query4_3 = '''
WITH cities(city) AS (
           
               SELECT customer.city
               FROM   customer
           
           UNION
           
               SELECT s.city
               FROM   store AS s
           
)
SELECT cities.city
'''
demo = '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       (
           SELECT customer.city
           FROM   customer
       )
       UNION
       (
           SELECT s.city
           FROM   store AS s
       )
       WHERE store.city IN
)
'''
# Mon, 07 Dec 2020 14:56:14
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 14:56:14
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 14:56:39
query4_3 = '''
WITH cities AS (
           
               SELECT customer.city
               FROM   customer
           
           UNION
           
               SELECT s.city
               FROM   store AS s
           
)
SELECT cities.city
'''
demo = '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       (
           SELECT customer.city
           FROM   customer
       )
       UNION
       (
           SELECT s.city
           FROM   store AS s
       )
       WHERE store.city IN
)
'''
# Mon, 07 Dec 2020 14:56:39
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 14:56:40
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 14:59:20
query4_3 = '''
WITH cities(city) AS (
           
               SELECT customer.city
               FROM   customer
           
           UNION
           
               SELECT s.city
               FROM   store AS s
           
)
SELECT cities.city
FROM cities
'''
demo = '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       (
           SELECT customer.city
           FROM   customer
       )
       UNION
       (
           SELECT s.city
           FROM   store AS s
       )
       WHERE store.city IN
)
'''
# Mon, 07 Dec 2020 14:59:20
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 14:59:20
pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 15:00:24
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 15:01:20
query4_3 = query4_3_union + '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       (
           SELECT customer.city
           FROM   customer
       )
       UNION
       (
           SELECT s.city
           FROM   store AS s
       )
       WHERE store.city IN
)
'''

query4_3
#[Out]# '\nWITH cities(city) AS (\n               SELECT customer.city\n               FROM   customer\n           UNION\n               SELECT s.city\n               FROM   store AS s\n)\nSELECT cities.city\nFROM cities\n\nSELECT store.sName\nFROM   store\nWHERE  NOT EXISTS (\n       (\n           SELECT customer.city\n           FROM   customer\n       )\n       UNION\n       (\n           SELECT s.city\n           FROM   store AS s\n       )\n       WHERE store.city IN\n)\n'
# Mon, 07 Dec 2020 15:01:28
query4_3 = query4_3_union + '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       (
           SELECT customer.city
           FROM   customer
       )
       UNION
       (
           SELECT s.city
           FROM   store AS s
       )
       WHERE store.city IN
)
'''

print(query4_3)
# Mon, 07 Dec 2020 15:02:00
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
displayer = '''
SELECT cities.city
FROM cities
'''
pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 15:02:04
query4_3 = query4_3_union + '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       (
           SELECT customer.city
           FROM   customer
       )
       UNION
       (
           SELECT s.city
           FROM   store AS s
       )
       WHERE store.city IN
)
'''

print(query4_3)
# Mon, 07 Dec 2020 15:02:04
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:02:27
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Mon, 07 Dec 2020 15:02:41
# Display the results in a separate cell
displayer = '''
SELECT cities.city
FROM cities
'''
pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 15:02:47
# Display the results in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 15:02:55
query4_3 = query4_3_union + '''
SELECT store.sName
FROM   store
WHERE  NOT EXISTS (
       (
           SELECT customer.city
           FROM   customer
       )
       UNION
       (
           SELECT s.city
           FROM   store AS s
       )
       WHERE store.city IN
)
'''

print(query4_3)
# Mon, 07 Dec 2020 15:05:12
import os

output_filename = 'exc3.txt'

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query4_3)
output_file.close()
# Mon, 07 Dec 2020 15:05:27
import os

output_filename = 'exc3.txt'

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query4_3)
output_file.close()
# Mon, 07 Dec 2020 15:05:54
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

output_filename = 'exc3.txt'

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query4_3)
output_file.close()
# Mon, 07 Dec 2020 15:06:21
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 15:06:54
query4_4 = '''
    PUT YOUR QUERY HERE
'''
# Mon, 07 Dec 2020 15:06:54
#vis.visualize(query4_4, schema)
# Mon, 07 Dec 2020 15:06:54
pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 15:06:55
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 15:07:07
query4_4 = '''
    PUT YOUR  HERE
'''
# Mon, 07 Dec 2020 15:07:07
#vis.visualize(query4_4, schema)
# Mon, 07 Dec 2020 15:07:07
pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 15:07:08
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 15:14:21
query4_3 = query4_3_union + '''
SELECT *
       FROM   store.sName, cities.city
'''
'''
SELECT store.sName
FROM   store
WHERE  store.city NOT IN (
       SELECT city
       FROM   
       WHERE store.sName, store.city NOT IN
       
       
       
       
)
'''
#[Out]# '\nSELECT store.sName\nFROM   store\nWHERE  store.city NOT IN (\n       SELECT city\n       FROM   \n       WHERE store.sName, store.city NOT IN\n       \n       \n       \n       \n)\n'
# Mon, 07 Dec 2020 15:14:24
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:14:25
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 15:14:39
query4_3 = query4_3_union + '''
SELECT *
       FROM   (SELECT store.sName FROM STORE), cities.city
'''
'''
SELECT store.sName
FROM   store
WHERE  store.city NOT IN (
       SELECT city
       FROM   
       WHERE store.sName, store.city NOT IN
       
       
       
       
)
'''
#[Out]# '\nSELECT store.sName\nFROM   store\nWHERE  store.city NOT IN (\n       SELECT city\n       FROM   \n       WHERE store.sName, store.city NOT IN\n       \n       \n       \n       \n)\n'
# Mon, 07 Dec 2020 15:14:40
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:14:40
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 15:14:55
query4_3 = query4_3_union + '''
SELECT *
       FROM   (SELECT store.sName FROM STORE), cities
'''
'''
SELECT store.sName
FROM   store
WHERE  store.city NOT IN (
       SELECT city
       FROM   
       WHERE store.sName, store.city NOT IN
       
       
       
       
)
'''
#[Out]# '\nSELECT store.sName\nFROM   store\nWHERE  store.city NOT IN (\n       SELECT city\n       FROM   \n       WHERE store.sName, store.city NOT IN\n       \n       \n       \n       \n)\n'
# Mon, 07 Dec 2020 15:14:55
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:14:55
pd.read_sql_query(query4_3, conn)
#[Out]#      sName       city
#[Out]# 0     Coop  Amsterdam
#[Out]# 1     Coop      Breda
#[Out]# 2     Coop  Eindhoven
#[Out]# 3     Coop        Oss
#[Out]# 4     Coop  Rotterdam
#[Out]# ..     ...        ...
#[Out]# 443  Jumbo  Eindhoven
#[Out]# 444  Jumbo        Oss
#[Out]# 445  Jumbo  Rotterdam
#[Out]# 446  Jumbo    Tilburg
#[Out]# 447  Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Mon, 07 Dec 2020 15:21:58
query4_3 = query4_3_union + '''
WITH PiRminusSrcrossS(sName, city) AS (
       SELECT *
       FROM   (SELECT store.sName FROM STORE), cities
)

WITH PiRminusSSr(sName, city) AS (
       SELECT store.sName, cities.city
       FROM store, cities
)

WITH insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  PiRminusSrcrossS.sName, PiRminusSrcrossS.city NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

WITH projectionouterbrackets(sName) AS (
       SELECT PiRminusSrcrossS.sName
       FROM PiRminusSrcrossS
)



'''
'''
SELECT store.sName
FROM   store
WHERE  store.city NOT IN (
       SELECT city
       FROM   
       WHERE store.sName, store.city NOT IN
       
       
       
       
)
'''
#[Out]# '\nSELECT store.sName\nFROM   store\nWHERE  store.city NOT IN (\n       SELECT city\n       FROM   \n       WHERE store.sName, store.city NOT IN\n       \n       \n       \n       \n)\n'
# Mon, 07 Dec 2020 15:23:20
query4_3 = query4_3_union + '''
WITH PiRminusSrcrossS(sName, city) AS (
       SELECT *
       FROM   (SELECT store.sName FROM STORE), cities
)

WITH PiRminusSSr(sName, city) AS (
       SELECT store.sName, cities.city
       FROM store, cities
)

WITH insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  PiRminusSrcrossS.sName, PiRminusSrcrossS.city NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

WITH projectionouterbrackets(sName) AS (
       SELECT PiRminusSrcrossS.sName
       FROM PiRminusSrcrossS
)

SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 15:23:21
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:23:21
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 15:23:53
query4_3 = query4_3_union + '''
WITH PiRminusSrcrossS(sName, city) AS (
       SELECT *
       FROM   (SELECT store.sName FROM STORE), cities
)

WITH PiRminusSSr(sName, city) AS (
       SELECT store.sName, cities.city
       FROM store, cities
)

WITH insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  PiRminusSrcrossS.sName, PiRminusSrcrossS.city NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

WITH projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)

SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 15:23:53
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:23:54
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 15:24:20
print(query4_3)
# Mon, 07 Dec 2020 15:24:22
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 15:24:23
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 15:25:40
query4_3 = query4_3_union + '''
WITH PiRminusSrcrossS(sName, city) AS (
       SELECT *
       FROM   (SELECT store.sName FROM STORE) AS s, cities
)

WITH PiRminusSSr(sName, city) AS (
       SELECT store.sName, cities.city
       FROM store, cities
)

WITH insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  PiRminusSrcrossS.sName, PiRminusSrcrossS.city NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

WITH projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)

SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 15:25:41
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:25:41
print(query4_3)
# Mon, 07 Dec 2020 15:25:43
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 15:26:00
query4_3 = query4_3_union + '''
WITH PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

WITH PiRminusSSr(sName, city) AS (
       SELECT store.sName, cities.city
       FROM store, cities
)

WITH insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  PiRminusSrcrossS.sName, PiRminusSrcrossS.city NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

WITH projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)

SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 15:26:00
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:26:00
print(query4_3)
# Mon, 07 Dec 2020 15:26:00
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 15:26:03
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 15:27:08
query4_3 = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, cities.city
       FROM store, cities
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  PiRminusSrcrossS.sName, PiRminusSrcrossS.city NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)

SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 15:27:09
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:27:09
print(query4_3)
# Mon, 07 Dec 2020 15:27:11
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 15:28:32
query4_3 = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, cities.city
       FROM store, cities
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)

SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 15:28:33
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:28:33
print(query4_3)
# Mon, 07 Dec 2020 15:28:33
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 15:28:37
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 15:29:55
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, cities.city
       FROM store, cities
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''

query4_3 = withs + '''
SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 15:29:55
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:29:56
print(query4_3)
# Mon, 07 Dec 2020 15:30:45
displayer = '''
SELECT * FROM projectionouterbrackets
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 15:31:03
displayer = '''
SELECT projectionouterbrackets.sName FROM projectionouterbrackets
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 15:31:07
displayer = '''
SELECT projectionouterbrackets.* FROM projectionouterbrackets
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 15:31:12
displayer = '''
SELECT * FROM projectionouterbrackets
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 15:31:26
displayer = '''
SELECT * FROM PiRminusSrcrossS
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#      sName       city
#[Out]# 0     Coop  Amsterdam
#[Out]# 1     Coop      Breda
#[Out]# 2     Coop  Eindhoven
#[Out]# 3     Coop        Oss
#[Out]# 4     Coop  Rotterdam
#[Out]# ..     ...        ...
#[Out]# 443  Jumbo  Eindhoven
#[Out]# 444  Jumbo        Oss
#[Out]# 445  Jumbo  Rotterdam
#[Out]# 446  Jumbo    Tilburg
#[Out]# 447  Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Mon, 07 Dec 2020 15:31:46
displayer = '''
SELECT * FROM PiRminusSSr
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#      sName       city
#[Out]# 0     Coop  Amsterdam
#[Out]# 1     Coop      Breda
#[Out]# 2     Coop  Eindhoven
#[Out]# 3     Coop        Oss
#[Out]# 4     Coop  Rotterdam
#[Out]# ..     ...        ...
#[Out]# 443  Jumbo  Eindhoven
#[Out]# 444  Jumbo        Oss
#[Out]# 445  Jumbo  Rotterdam
#[Out]# 446  Jumbo    Tilburg
#[Out]# 447  Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Mon, 07 Dec 2020 15:31:54
displayer = '''
SELECT * FROM insideouterbrackets
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Mon, 07 Dec 2020 15:33:21
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''

query4_3 = withs + '''
SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 15:33:21
displayer = '''
SELECT * FROM insideouterbrackets
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#       sName       city
#[Out]# 0      Coop  Eindhoven
#[Out]# 1      Coop  Eindhoven
#[Out]# 2      Coop  Eindhoven
#[Out]# 3      Coop  Eindhoven
#[Out]# 4      Coop  Eindhoven
#[Out]# ...     ...        ...
#[Out]# 9531  Jumbo    Utrecht
#[Out]# 9532  Jumbo    Utrecht
#[Out]# 9533  Jumbo    Utrecht
#[Out]# 9534  Jumbo    Utrecht
#[Out]# 9535  Jumbo    Utrecht
#[Out]# 
#[Out]# [9536 rows x 2 columns]
# Mon, 07 Dec 2020 15:33:26
displayer = '''
SELECT * FROM insideouterbrackets
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#       sName       city
#[Out]# 0      Coop  Eindhoven
#[Out]# 1      Coop  Eindhoven
#[Out]# 2      Coop  Eindhoven
#[Out]# 3      Coop  Eindhoven
#[Out]# 4      Coop  Eindhoven
#[Out]# ...     ...        ...
#[Out]# 9531  Jumbo    Utrecht
#[Out]# 9532  Jumbo    Utrecht
#[Out]# 9533  Jumbo    Utrecht
#[Out]# 9534  Jumbo    Utrecht
#[Out]# 9535  Jumbo    Utrecht
#[Out]# 
#[Out]# [9536 rows x 2 columns]
# Mon, 07 Dec 2020 15:33:27
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:33:28
print(query4_3)
# Mon, 07 Dec 2020 15:33:28
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 15:34:29
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Eindhoven
#[Out]# 1          Coop        Oss
#[Out]# 2     Hoogvliet  Amsterdam
#[Out]# 3     Hoogvliet        Oss
#[Out]# 4     Hoogvliet    Utrecht
#[Out]# 5         Jumbo  Amsterdam
#[Out]# 6         Jumbo    Utrecht
#[Out]# 7        Sligro        Oss
#[Out]# 8        Sligro    Utrecht
#[Out]# 9   Albert Hein  Amsterdam
#[Out]# 10  Albert Hein        Oss
#[Out]# 11         Lidl        Oss
#[Out]# 12         Lidl    Tilburg
#[Out]# 13         Dirk  Amsterdam
#[Out]# 14         Dirk        Oss
#[Out]# 15         Dirk    Tilburg
#[Out]# 16         Dirk    Utrecht
# Mon, 07 Dec 2020 15:35:15
list_stores = '''
SELECT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Mon, 07 Dec 2020 15:35:21
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Mon, 07 Dec 2020 15:36:31
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)

list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Mon, 07 Dec 2020 15:36:54
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)

list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop  Rotterdam
#[Out]# 7          Coop    Tilburg
#[Out]# 8          Coop      Breda
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet    Tilburg
#[Out]# 16    Hoogvliet  Rotterdam
#[Out]# 17        Jumbo  Rotterdam
#[Out]# 18        Jumbo    Tilburg
#[Out]# 19        Jumbo  Eindhoven
#[Out]# 20        Jumbo      Breda
#[Out]# 21        Jumbo        Oss
#[Out]# 22         Lidl  Eindhoven
#[Out]# 23         Lidl  Amsterdam
#[Out]# 24         Lidl    Utrecht
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl      Breda
#[Out]# 27       Sligro  Rotterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro    Tilburg
#[Out]# 31       Sligro  Amsterdam
# Mon, 07 Dec 2020 15:37:51
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)

list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Mon, 07 Dec 2020 15:37:54
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)

list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Mon, 07 Dec 2020 15:38:04
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Mon, 07 Dec 2020 15:38:04
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Mon, 07 Dec 2020 15:40:19
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY store.sName, store.city
'''

pd.read_sql_query(withs + displayer, conn)
# Mon, 07 Dec 2020 15:40:48
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Mon, 07 Dec 2020 15:42:29
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Mon, 07 Dec 2020 15:44:32
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Mon, 07 Dec 2020 15:49:46
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Mon, 07 Dec 2020 15:49:46
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 15:49:47
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Mon, 07 Dec 2020 15:49:48
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Mon, 07 Dec 2020 15:49:49
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Mon, 07 Dec 2020 15:49:51
# The rest of the final query

withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''

query4_3 = withs + '''
SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 15:49:51
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 15:49:52
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 15:49:53
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 15:57:07
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
SELECT sum(price)
FROM   purchase
GROUP BY cID, date
)
'''

displayer = '''
SELECT * FROM sumday
'''
# Mon, 07 Dec 2020 15:57:15
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
SELECT sum(price)
FROM   purchase
GROUP BY cID, date
)
'''
pd.read_sql_query(query4_4_maxmoney, conn)

displayer = '''
SELECT * FROM sumday
'''
# Mon, 07 Dec 2020 15:57:25
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
SELECT sum(price)
FROM   purchase
GROUP BY cID, date
)
'''


displayer = '''
SELECT * FROM sumday
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#        sum
#[Out]# 0     0.45
#[Out]# 1    14.20
#[Out]# 2    10.00
#[Out]# 3     2.45
#[Out]# 4     7.70
#[Out]# ..     ...
#[Out]# 280  10.60
#[Out]# 281   3.25
#[Out]# 282   9.80
#[Out]# 283  21.90
#[Out]# 284   5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Mon, 07 Dec 2020 15:57:40
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
SELECT sum(price)
FROM   purchase
GROUP BY cID, date
)
'''


displayer = '''
SELECT max(sumday.sum) FROM sumday
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#    max(sumday.sum)
#[Out]# 0             39.1
# Mon, 07 Dec 2020 15:59:18
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
'''


displayer = '''
SELECT max(sumday.sum) FROM sumday
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#    max(sumday.sum)
#[Out]# 0             39.1
# Mon, 07 Dec 2020 15:59:26
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
'''


displayer = '''
SELECT maximum(max) FROM sumday
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
# Mon, 07 Dec 2020 15:59:38
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sums) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(maxs) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
'''


displayer = '''
SELECT maximum(max) FROM sumday
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
# Mon, 07 Dec 2020 15:59:42
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sums) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(maxs) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
'''


displayer = '''
SELECT maximum(maxs) FROM sumday
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
# Mon, 07 Dec 2020 15:59:52
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
'''


displayer = '''
SELECT maximum(max) FROM maximum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
# Mon, 07 Dec 2020 15:59:56
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
'''


displayer = '''
SELECT maximum.max FROM maximum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#     max
#[Out]# 0  39.1
# Mon, 07 Dec 2020 16:00:44
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, 75percentmaximum(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''


displayer = '''
SELECT maximum.max FROM maximum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
# Mon, 07 Dec 2020 16:00:53
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmaximum(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''


displayer = '''
SELECT maximum.max FROM maximum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#     max
#[Out]# 0  39.1
# Mon, 07 Dec 2020 16:00:56
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''


displayer = '''
SELECT maximum.max FROM maximum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#     max
#[Out]# 0  39.1
# Mon, 07 Dec 2020 16:01:08
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''


displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Mon, 07 Dec 2020 16:01:24
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Mon, 07 Dec 2020 16:01:36
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Mon, 07 Dec 2020 16:01:59
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(sum) AS (
    SELECT   sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Mon, 07 Dec 2020 16:02:41
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(cID, sum) AS (
    SELECT   cID, sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Mon, 07 Dec 2020 16:04:18
query4_4 = '''
    SELECT customer.custName
    FROM   customer NATURAL JOIN sumday
    WHERE  sumday.sum >= partmax(pmax)
'''
# Mon, 07 Dec 2020 16:04:26
query4_4 = query4_4_maxmoney + '''
    SELECT customer.custName
    FROM   customer NATURAL JOIN sumday
    WHERE  sumday.sum >= partmax(pmax)
'''
# Mon, 07 Dec 2020 16:04:27
#vis.visualize(query4_4, schema)
# Mon, 07 Dec 2020 16:04:27
pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 16:04:49
query4_4 = query4_4_maxmoney + '''
    SELECT customer.cName
    FROM   customer NATURAL JOIN sumday
    WHERE  sumday.sum >= partmax(pmax)
'''
# Mon, 07 Dec 2020 16:04:49
#vis.visualize(query4_4, schema)
# Mon, 07 Dec 2020 16:04:49
pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 16:05:56
query4_4 = query4_4_maxmoney + '''
    SELECT customer.cName
    FROM   partmax, customer NATURAL JOIN sumday
    WHERE  sumday.sum >= partmax.pmax
'''
# Mon, 07 Dec 2020 16:05:57
#vis.visualize(query4_4, schema)
# Mon, 07 Dec 2020 16:05:57
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Mon, 07 Dec 2020 16:06:21
query4_4 = query4_4_maxmoney + '''
    SELECT customer.cName
    FROM   partmax, customer, sumday
    WHERE  sumday.sum >= partmax.pmax
      AND  customer.cID = sumday.cID
'''
# Mon, 07 Dec 2020 16:06:22
#vis.visualize(query4_4, schema)
# Mon, 07 Dec 2020 16:06:22
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Mon, 07 Dec 2020 16:06:56
# Display the sum of expenditures per day per customer
displayer = '''
SELECT sumday.* FROM sumday
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0      0   0.45
#[Out]# 1      1  14.20
#[Out]# 2      1  10.00
#[Out]# 3      2   2.45
#[Out]# 4      2   7.70
#[Out]# ..   ...    ...
#[Out]# 280  190  10.60
#[Out]# 281  190   3.25
#[Out]# 282  190   9.80
#[Out]# 283  190  21.90
#[Out]# 284  190   5.55
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Mon, 07 Dec 2020 16:07:13
# Display the sum of expenditures per day per customer
displayer = '''
SELECT sumday.sum FROM sumday
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#        sum
#[Out]# 0     0.45
#[Out]# 1    14.20
#[Out]# 2    10.00
#[Out]# 3     2.45
#[Out]# 4     7.70
#[Out]# ..     ...
#[Out]# 280  10.60
#[Out]# 281   3.25
#[Out]# 282   9.80
#[Out]# 283  21.90
#[Out]# 284   5.55
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Mon, 07 Dec 2020 16:07:18
# Display the sum of expenditures per day per customer
displayer = '''
SELECT DISTINCT sumday.sum FROM sumday
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#        sum
#[Out]# 0     0.45
#[Out]# 1    14.20
#[Out]# 2    10.00
#[Out]# 3     2.45
#[Out]# 4     7.70
#[Out]# ..     ...
#[Out]# 180  10.85
#[Out]# 181  14.55
#[Out]# 182  10.60
#[Out]# 183   9.80
#[Out]# 184  21.90
#[Out]# 
#[Out]# [185 rows x 1 columns]
# Mon, 07 Dec 2020 16:07:24
# Display the sum of expenditures per day per customer
displayer = '''
SELECT DISTINCT sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#        sum
#[Out]# 0     0.40
#[Out]# 1     0.45
#[Out]# 2     0.50
#[Out]# 3     0.55
#[Out]# 4     0.60
#[Out]# ..     ...
#[Out]# 180  21.90
#[Out]# 181  22.25
#[Out]# 182  23.95
#[Out]# 183  28.80
#[Out]# 184  39.10
#[Out]# 
#[Out]# [185 rows x 1 columns]
# Mon, 07 Dec 2020 16:09:28
displayer = '''
SELECT DISTINCT sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#        sum
#[Out]# 0     0.40
#[Out]# 1     0.45
#[Out]# 2     0.50
#[Out]# 3     0.55
#[Out]# 4     0.60
#[Out]# ..     ...
#[Out]# 180  21.90
#[Out]# 181  22.25
#[Out]# 182  23.95
#[Out]# 183  28.80
#[Out]# 184  39.10
#[Out]# 
#[Out]# [185 rows x 1 columns]
# Mon, 07 Dec 2020 16:10:04
displayer = '''
SELECT sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#        sum
#[Out]# 0     0.40
#[Out]# 1     0.45
#[Out]# 2     0.45
#[Out]# 3     0.45
#[Out]# 4     0.45
#[Out]# ..     ...
#[Out]# 280  21.90
#[Out]# 281  22.25
#[Out]# 282  23.95
#[Out]# 283  28.80
#[Out]# 284  39.10
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Mon, 07 Dec 2020 16:10:23
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 16:20:25
displayer = '''
SELECT sumday.cID, sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0     72   0.40
#[Out]# 1      0   0.45
#[Out]# 2     22   0.45
#[Out]# 3     77   0.45
#[Out]# 4    179   0.45
#[Out]# ..   ...    ...
#[Out]# 280  190  21.90
#[Out]# 281   71  22.25
#[Out]# 282  108  23.95
#[Out]# 283  124  28.80
#[Out]# 284  161  39.10
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Mon, 07 Dec 2020 16:21:15
pd.read_sql_query('SELECT cID, cName FROM customer WHERE cID = 161', conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Mon, 07 Dec 2020 16:32:40
query4_5 = '''
SELECT count(DISTINCT cID)
FROM purchase NATURAL JOIN store
WHERE store.city = "Eindhoven"
GROUP BY city
'''
# Mon, 07 Dec 2020 16:32:40
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:32:40
pd.read_sql_query(query4_5, conn)
#[Out]#    count(DISTINCT cID)
#[Out]# 0                   69
# Mon, 07 Dec 2020 16:33:58
query4_5 = '''
SELECT count(DISTINCT cID)
FROM purchase NATURAL JOIN store, customer
WHERE store.city = "Eindhoven"
GROUP BY city, customer.city
'''
# Mon, 07 Dec 2020 16:33:58
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:33:58
pd.read_sql_query(query4_5, conn)
# Mon, 07 Dec 2020 16:34:04
query4_5 = '''
SELECT count(DISTINCT product.cID)
FROM purchase NATURAL JOIN store, customer
WHERE store.city = "Eindhoven"
GROUP BY city, customer.city
'''
# Mon, 07 Dec 2020 16:34:04
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:34:04
pd.read_sql_query(query4_5, conn)
# Mon, 07 Dec 2020 16:34:10
query4_5 = '''
SELECT count(DISTINCT purchase.cID)
FROM purchase NATURAL JOIN store, customer
WHERE store.city = "Eindhoven"
GROUP BY city, customer.city
'''
# Mon, 07 Dec 2020 16:34:10
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:34:11
pd.read_sql_query(query4_5, conn)
# Mon, 07 Dec 2020 16:34:28
query4_5 = '''
SELECT count(DISTINCT purchase.cID)
FROM purchase NATURAL JOIN store, customer
WHERE store.city = "Eindhoven"
GROUP BY customer.city
'''
# Mon, 07 Dec 2020 16:34:29
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:34:29
pd.read_sql_query(query4_5, conn)
#[Out]#    count(DISTINCT purchase.cID)
#[Out]# 0                            69
#[Out]# 1                            69
#[Out]# 2                            69
#[Out]# 3                            69
#[Out]# 4                            69
#[Out]# 5                            69
#[Out]# 6                            69
# Mon, 07 Dec 2020 16:34:55
query4_5 = '''
SELECT customer.city, count(DISTINCT purchase.cID)
FROM purchase NATURAL JOIN store, customer
WHERE store.city = "Eindhoven"
GROUP BY customer.city
'''
# Mon, 07 Dec 2020 16:34:56
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:34:56
pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(DISTINCT purchase.cID)
#[Out]# 0  Amsterdam                            69
#[Out]# 1      Breda                            69
#[Out]# 2  Eindhoven                            69
#[Out]# 3        Oss                            69
#[Out]# 4  Rotterdam                            69
#[Out]# 5    Tilburg                            69
#[Out]# 6    Utrecht                            69
# Mon, 07 Dec 2020 16:36:49
query4_5 = '''
SELECT customer.city, count(DISTINCT purchase.cID)
FROM purchase NATURAL JOIN store, customer
WHERE store.city = "Eindhoven"
GROUP BY customer.city
'''

query4_5 = '''
SELECT customer.city, count(DISTINCT purchase.cID)
FROM purchase, store, customer
WHERE store.city = "Eindhoven"
  AND purchase.cID = customer.cID
  AND store.sID = purchase.sID
GROUP BY customer.city
'''
# Mon, 07 Dec 2020 16:36:49
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:36:49
pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(DISTINCT purchase.cID)
#[Out]# 0  Amsterdam                            10
#[Out]# 1      Breda                             9
#[Out]# 2  Eindhoven                            15
#[Out]# 3  Rotterdam                            13
#[Out]# 4    Tilburg                            10
#[Out]# 5    Utrecht                            12
# Mon, 07 Dec 2020 16:36:54
query4_5 = '''
SELECT customer.city, count(DISTINCT purchase.cID)
FROM purchase, store, customer
WHERE store.city = "Eindhoven"
  AND purchase.cID = customer.cID
  AND store.sID = purchase.sID
GROUP BY customer.city
'''
# Mon, 07 Dec 2020 16:36:55
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:36:55
pd.read_sql_query(query4_5, conn)
#[Out]#         city  count(DISTINCT purchase.cID)
#[Out]# 0  Amsterdam                            10
#[Out]# 1      Breda                             9
#[Out]# 2  Eindhoven                            15
#[Out]# 3  Rotterdam                            13
#[Out]# 4    Tilburg                            10
#[Out]# 5    Utrecht                            12
# Mon, 07 Dec 2020 16:37:13
query4_5 = '''
SELECT customer.city, count(DISTINCT purchase.cID) AS amount
FROM purchase, store, customer
WHERE store.city = "Eindhoven"
  AND purchase.cID = customer.cID
  AND store.sID = purchase.sID
GROUP BY customer.city
'''
# Mon, 07 Dec 2020 16:37:14
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:37:14
pd.read_sql_query(query4_5, conn)
#[Out]#         city  amount
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3  Rotterdam      13
#[Out]# 4    Tilburg      10
#[Out]# 5    Utrecht      12
# Mon, 07 Dec 2020 16:38:20
query4_5 = '''
WITH cities(city, amount) AS (
    SELECT customer.city, 0
    FROM   customer
)

SELECT customer.city, count(DISTINCT purchase.cID) AS amount
FROM purchase, store, customer
WHERE store.city = "Eindhoven"
  AND purchase.cID = customer.cID
  AND store.sID = purchase.sID
GROUP BY customer.city
'''
# Mon, 07 Dec 2020 16:38:54
query4_5 = '''
WITH cities(city, amount) AS (
    SELECT customer.city, 0
    FROM   customer
)

(
SELECT customer.city, count(DISTINCT purchase.cID) AS amount
FROM purchase, store, customer
WHERE store.city = "Eindhoven"
  AND purchase.cID = customer.cID
  AND store.sID = purchase.sID
GROUP BY customer.city
)
UNION
(
SELECT cities.city, cities.amount FROM cities
)
'''
# Mon, 07 Dec 2020 16:38:55
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:38:55
pd.read_sql_query(query4_5, conn)
# Mon, 07 Dec 2020 16:39:03
query4_5 = '''
WITH cities(city, amount) AS (
    SELECT customer.city, 0
    FROM   customer
)


SELECT customer.city, count(DISTINCT purchase.cID) AS amount
FROM purchase, store, customer
WHERE store.city = "Eindhoven"
  AND purchase.cID = customer.cID
  AND store.sID = purchase.sID
GROUP BY customer.city

UNION

SELECT cities.city, cities.amount FROM cities

'''
# Mon, 07 Dec 2020 16:39:04
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:39:04
pd.read_sql_query(query4_5, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Mon, 07 Dec 2020 16:39:42
query4_5 = '''
WITH cities(city, amount) AS (
    SELECT customer.city, 0
    FROM   customer
)

(
SELECT customer.city, count(DISTINCT purchase.cID) AS amount
FROM purchase, store, customer
WHERE store.city = "Eindhoven"
  AND purchase.cID = customer.cID
  AND store.sID = purchase.sID
GROUP BY customer.city

UNION

SELECT customer.city, 0 FROM customer
)
'''
# Mon, 07 Dec 2020 16:39:43
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:39:43
pd.read_sql_query(query4_5, conn)
# Mon, 07 Dec 2020 16:39:49
query4_5 = '''



SELECT customer.city, count(DISTINCT purchase.cID) AS amount
FROM purchase, store, customer
WHERE store.city = "Eindhoven"
  AND purchase.cID = customer.cID
  AND store.sID = purchase.sID
GROUP BY customer.city

UNION

SELECT customer.city, 0 FROM customer

'''
# Mon, 07 Dec 2020 16:39:50
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:39:50
pd.read_sql_query(query4_5, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Mon, 07 Dec 2020 16:41:06
query4_5 = '''

WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)

SELECT city, max(amount)
FROM citiesduplicates
'''
# Mon, 07 Dec 2020 16:41:07
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:41:07
pd.read_sql_query(query4_5, conn)
#[Out]#         city  max(amount)
#[Out]# 0  Eindhoven           15
# Mon, 07 Dec 2020 16:41:15
query4_5 = '''

WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)

SELECT city, max(amount)
FROM citiesduplicates
GROUP BY city
'''
# Mon, 07 Dec 2020 16:41:15
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:41:16
pd.read_sql_query(query4_5, conn)
#[Out]#         city  max(amount)
#[Out]# 0  Amsterdam           10
#[Out]# 1      Breda            9
#[Out]# 2  Eindhoven           15
#[Out]# 3        Oss            0
#[Out]# 4  Rotterdam           13
#[Out]# 5    Tilburg           10
#[Out]# 6    Utrecht           12
# Mon, 07 Dec 2020 16:41:47
query4_5_with = '''
WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)
'''

query4_5 = query4_5_with + '''
SELECT city, max(amount)
FROM citiesduplicates
GROUP BY city
'''
# Mon, 07 Dec 2020 16:41:47
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:41:47
pd.read_sql_query(query4_5, conn)
#[Out]#         city  max(amount)
#[Out]# 0  Amsterdam           10
#[Out]# 1      Breda            9
#[Out]# 2  Eindhoven           15
#[Out]# 3        Oss            0
#[Out]# 4  Rotterdam           13
#[Out]# 5    Tilburg           10
#[Out]# 6    Utrecht           12
# Mon, 07 Dec 2020 16:42:47
displayer = '''
SELECT city, amount
FROM citiesduplicates
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Mon, 07 Dec 2020 16:45:24
datadump = '''
     SELECT customer.city, count(purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Mon, 07 Dec 2020 16:45:32
datadump = '''
     SELECT customer.city, count(purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
'''
pd.read_sql_query(datadump, conn)
#[Out]#         city  amount
#[Out]# 0  Amsterdam      17
#[Out]# 1      Breda      27
#[Out]# 2  Eindhoven      24
#[Out]# 3  Rotterdam      16
#[Out]# 4    Tilburg      18
#[Out]# 5    Utrecht      31
# Mon, 07 Dec 2020 16:45:57
datadump = '''
     SELECT customer.city, purchase.price AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
'''
pd.read_sql_query(datadump, conn)
#[Out]#         city  amount
#[Out]# 0  Amsterdam    2.45
#[Out]# 1      Breda    1.25
#[Out]# 2  Eindhoven    1.70
#[Out]# 3  Rotterdam    2.55
#[Out]# 4    Tilburg    0.55
#[Out]# 5    Utrecht    4.70
# Mon, 07 Dec 2020 16:46:05
datadump = '''
     SELECT customer.city, purchase.price,purchase.quantity AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
'''
pd.read_sql_query(datadump, conn)
#[Out]#         city  price  amount
#[Out]# 0  Amsterdam   2.45       1
#[Out]# 1      Breda   1.25       2
#[Out]# 2  Eindhoven   1.70       6
#[Out]# 3  Rotterdam   2.55       9
#[Out]# 4    Tilburg   0.55       7
#[Out]# 5    Utrecht   4.70       6
# Mon, 07 Dec 2020 16:47:14
datadump = '''
     SELECT customer.city, purchase.pID, store.city AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
'''
pd.read_sql_query(datadump, conn)
#[Out]#         city  pID     amount
#[Out]# 0  Amsterdam   20  Eindhoven
#[Out]# 1      Breda    9  Eindhoven
#[Out]# 2  Eindhoven    2  Eindhoven
#[Out]# 3  Rotterdam   26  Eindhoven
#[Out]# 4    Tilburg    5  Eindhoven
#[Out]# 5    Utrecht   14  Eindhoven
# Mon, 07 Dec 2020 16:47:27
datadump = '''
     SELECT customer.city, purchase.pID, store.city AS
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
'''
pd.read_sql_query(datadump, conn)
# Mon, 07 Dec 2020 16:47:28
datadump = '''
     SELECT customer.city, purchase.pID, store.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
'''
pd.read_sql_query(datadump, conn)
#[Out]#         city  pID       city
#[Out]# 0  Amsterdam   20  Eindhoven
#[Out]# 1      Breda    9  Eindhoven
#[Out]# 2  Eindhoven    2  Eindhoven
#[Out]# 3  Rotterdam   26  Eindhoven
#[Out]# 4    Tilburg    5  Eindhoven
#[Out]# 5    Utrecht   14  Eindhoven
# Mon, 07 Dec 2020 16:47:34
datadump = '''
     SELECT customer.city, purchase.pID, store.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
'''
pd.read_sql_query(datadump, conn)
#[Out]#           city  pID       city
#[Out]# 0        Breda    9  Eindhoven
#[Out]# 1        Breda   27  Eindhoven
#[Out]# 2    Amsterdam   20  Eindhoven
#[Out]# 3    Amsterdam    9  Eindhoven
#[Out]# 4        Breda   26  Eindhoven
#[Out]# ..         ...  ...        ...
#[Out]# 128    Utrecht   23  Eindhoven
#[Out]# 129    Utrecht    0  Eindhoven
#[Out]# 130    Utrecht   11  Eindhoven
#[Out]# 131    Utrecht   15  Eindhoven
#[Out]# 132    Utrecht    9  Eindhoven
#[Out]# 
#[Out]# [133 rows x 3 columns]
# Mon, 07 Dec 2020 16:47:43
datadump = '''
     SELECT customer.city, purchase.pID
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
'''
pd.read_sql_query(datadump, conn)
#[Out]#           city  pID
#[Out]# 0        Breda    9
#[Out]# 1        Breda   27
#[Out]# 2    Amsterdam   20
#[Out]# 3    Amsterdam    9
#[Out]# 4        Breda   26
#[Out]# ..         ...  ...
#[Out]# 128    Utrecht   23
#[Out]# 129    Utrecht    0
#[Out]# 130    Utrecht   11
#[Out]# 131    Utrecht   15
#[Out]# 132    Utrecht    9
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Mon, 07 Dec 2020 16:48:43
datadump = '''
     SELECT purchase.pID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
'''
pd.read_sql_query(datadump, conn)
#[Out]#      pID  cID       city
#[Out]# 0      9    1      Breda
#[Out]# 1     27    1      Breda
#[Out]# 2     20    2  Amsterdam
#[Out]# 3      9    2  Amsterdam
#[Out]# 4     26    3      Breda
#[Out]# ..   ...  ...        ...
#[Out]# 128   23  190    Utrecht
#[Out]# 129    0  190    Utrecht
#[Out]# 130   11  190    Utrecht
#[Out]# 131   15  190    Utrecht
#[Out]# 132    9  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 3 columns]
# Mon, 07 Dec 2020 16:48:55
datadump = '''
     SELECT purchase.pID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
'''
pd.read_sql_query(datadump, conn)
pd.set_index(pID)
# Mon, 07 Dec 2020 16:49:13
datadump = '''
     SELECT purchase.pID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index(pID)
# Mon, 07 Dec 2020 16:49:18
datadump = '''
     SELECT purchase.pID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("pID")
#[Out]#      cID       city
#[Out]# pID                
#[Out]# 9      1      Breda
#[Out]# 27     1      Breda
#[Out]# 20     2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 26     3      Breda
#[Out]# ..   ...        ...
#[Out]# 23   190    Utrecht
#[Out]# 0    190    Utrecht
#[Out]# 11   190    Utrecht
#[Out]# 15   190    Utrecht
#[Out]# 9    190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Mon, 07 Dec 2020 16:50:05
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID")
# Mon, 07 Dec 2020 16:50:10
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purhcase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID")
# Mon, 07 Dec 2020 16:50:16
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID")
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Mon, 07 Dec 2020 16:50:53
datadump = '''
     SELECT DISTINCT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID")
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [131 rows x 2 columns]
# Mon, 07 Dec 2020 16:51:05
datadump = '''
     SELECT purchase.tID, DISTINCT customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID")
# Mon, 07 Dec 2020 16:51:09
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID")
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Mon, 07 Dec 2020 16:51:42
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID")
df.drop_duplicates(subset="cID")
#[Out]#      tID  cID       city
#[Out]# 0      3    1      Breda
#[Out]# 2      8    2  Amsterdam
#[Out]# 4     14    3      Breda
#[Out]# 5     16    4  Amsterdam
#[Out]# 7     22    5    Utrecht
#[Out]# ..   ...  ...        ...
#[Out]# 112  472  182  Eindhoven
#[Out]# 114  778  185  Eindhoven
#[Out]# 115  779  186  Eindhoven
#[Out]# 116  780  188  Rotterdam
#[Out]# 118  788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 3 columns]
# Mon, 07 Dec 2020 16:51:59
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID",inplace=True)
df.drop_duplicates(subset="cID",inplace=True)
# Mon, 07 Dec 2020 16:52:03
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID",inplace=True)
df.drop_duplicates(subset="cID",inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Mon, 07 Dec 2020 16:52:15
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Mon, 07 Dec 2020 16:52:20
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df.drop_duplicates(subset="cID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Mon, 07 Dec 2020 16:52:55
df_result.sum("max(amount)")
# Mon, 07 Dec 2020 16:52:58
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  max(amount)
#[Out]# 0  Amsterdam           10
#[Out]# 1      Breda            9
#[Out]# 2  Eindhoven           15
#[Out]# 3        Oss            0
#[Out]# 4  Rotterdam           13
#[Out]# 5    Tilburg           10
#[Out]# 6    Utrecht           12
# Mon, 07 Dec 2020 16:52:58
df_result.sum("max(amount)")
# Mon, 07 Dec 2020 16:53:43
df_result['max(amount)'].sum
#[Out]# <bound method Series.sum of 0    10
#[Out]# 1     9
#[Out]# 2    15
#[Out]# 3     0
#[Out]# 4    13
#[Out]# 5    10
#[Out]# 6    12
#[Out]# Name: max(amount), dtype: int64>
# Mon, 07 Dec 2020 16:53:48
df_result['max(amount)'].sum()
#[Out]# 69
# Mon, 07 Dec 2020 16:56:14
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  max(amount)
#[Out]# 0  Amsterdam           10
#[Out]# 1      Breda            9
#[Out]# 2  Eindhoven           15
#[Out]# 3        Oss            0
#[Out]# 4  Rotterdam           13
#[Out]# 5    Tilburg           10
#[Out]# 6    Utrecht           12
# Mon, 07 Dec 2020 16:56:15
df_result['max(amount)'].sum()
#[Out]# 69
# Mon, 07 Dec 2020 16:56:16
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc5.txt'
query = query4_5

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 16:56:25
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

if os.path.exists('logs.zip'):
    os.remove('logs.zip')

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()

# IPython log file

# Mon, 07 Dec 2020 16:58:14
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 16:58:15
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Mon, 07 Dec 2020 16:58:15
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Mon, 07 Dec 2020 16:58:15
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Mon, 07 Dec 2020 16:58:15
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 16:58:15
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Mon, 07 Dec 2020 16:58:15
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Mon, 07 Dec 2020 16:58:15
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
# Mon, 07 Dec 2020 16:58:56
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''

# IPython log file

# Mon, 07 Dec 2020 16:59:04
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 16:59:04
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Mon, 07 Dec 2020 16:59:04
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Mon, 07 Dec 2020 16:59:04
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''

# IPython log file

# Mon, 07 Dec 2020 16:59:20
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 16:59:20
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Mon, 07 Dec 2020 16:59:20
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Mon, 07 Dec 2020 16:59:20
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Mon, 07 Dec 2020 16:59:21
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''
# Mon, 07 Dec 2020 16:59:21
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Mon, 07 Dec 2020 16:59:21
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Mon, 07 Dec 2020 16:59:21
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Mon, 07 Dec 2020 16:59:21
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Mon, 07 Dec 2020 16:59:21
# The rest of the final query
query4_3 = withs + '''
SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Mon, 07 Dec 2020 16:59:21
#vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 16:59:21
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 16:59:21
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 16:59:21
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(cID, sum) AS (
    SELECT   cID, sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Mon, 07 Dec 2020 16:59:21
query4_4 = query4_4_maxmoney + '''
    SELECT customer.cName
    FROM   partmax, customer, sumday
    WHERE  sumday.sum >= partmax.pmax
      AND  customer.cID = sumday.cID
'''
# Mon, 07 Dec 2020 16:59:21
#vis.visualize(query4_4, schema)
# Mon, 07 Dec 2020 16:59:21
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Mon, 07 Dec 2020 16:59:21
displayer = '''
SELECT sumday.cID, sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0     72   0.40
#[Out]# 1      0   0.45
#[Out]# 2     22   0.45
#[Out]# 3     77   0.45
#[Out]# 4    179   0.45
#[Out]# ..   ...    ...
#[Out]# 280  190  21.90
#[Out]# 281   71  22.25
#[Out]# 282  108  23.95
#[Out]# 283  124  28.80
#[Out]# 284  161  39.10
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Mon, 07 Dec 2020 16:59:21
pd.read_sql_query('SELECT cID, cName FROM customer WHERE cID = 161', conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Mon, 07 Dec 2020 16:59:21
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 16:59:21
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Mon, 07 Dec 2020 16:59:21
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df.drop_duplicates(subset="cID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Mon, 07 Dec 2020 16:59:21
query4_5_with = '''
WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)
'''

query4_5 = query4_5_with + '''
SELECT city, max(amount) AS number
FROM citiesduplicates
GROUP BY city
'''
# Mon, 07 Dec 2020 16:59:21
displayer = '''
SELECT city, amount
FROM citiesduplicates
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Mon, 07 Dec 2020 16:59:21
#vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 16:59:21
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Mon, 07 Dec 2020 16:59:21
df_result['number'].sum()
#[Out]# 69
# Mon, 07 Dec 2020 16:59:21
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc5.txt'
query = query4_5

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Mon, 07 Dec 2020 16:59:21
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

if os.path.exists('logs.zip'):
    os.remove('logs.zip')

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()

# IPython log file

# Tue, 08 Dec 2020 14:20:36
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 14:20:36
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Tue, 08 Dec 2020 14:20:36
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 08 Dec 2020 14:20:36
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Tue, 08 Dec 2020 14:20:36
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''
# Tue, 08 Dec 2020 14:20:36
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:20:36
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 14:20:36
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 14:20:36
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 14:20:36
# The rest of the final query
query4_3 = withs + '''
SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Tue, 08 Dec 2020 14:20:36
#vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 14:20:36
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:20:36
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:20:36
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(cID, sum) AS (
    SELECT   cID, sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.3 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#     pmax
#[Out]# 0  11.73
# Tue, 08 Dec 2020 14:20:36
query4_4 = query4_4_maxmoney + '''
    SELECT customer.cName
    FROM   partmax, customer, sumday
    WHERE  sumday.sum >= partmax.pmax
      AND  customer.cID = sumday.cID
'''
# Tue, 08 Dec 2020 14:20:36
#vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:20:36
pd.read_sql_query(query4_4, conn)
#[Out]#       cName
#[Out]# 0       Sem
#[Out]# 1      Daan
#[Out]# 2      Daan
#[Out]# 3     James
#[Out]# 4      Gijs
#[Out]# 5      Luca
#[Out]# 6      Teun
#[Out]# 7      Sven
#[Out]# 8     Stijn
#[Out]# 9      Jack
#[Out]# 10     Jack
#[Out]# 11     Ties
#[Out]# 12   Willem
#[Out]# 13     Joep
#[Out]# 14      Kai
#[Out]# 15     Dean
#[Out]# 16    Dylan
#[Out]# 17    Dylan
#[Out]# 18     Stef
#[Out]# 19  Thijmen
#[Out]# 20     Emma
#[Out]# 21     Noor
#[Out]# 22     Lynn
#[Out]# 23    Fenna
#[Out]# 24    Lieke
#[Out]# 25    Milou
#[Out]# 26    Sofie
#[Out]# 27      Ivy
#[Out]# 28    Fenne
#[Out]# 29    Floor
#[Out]# 30    Elena
#[Out]# 31    Elena
#[Out]# 32     Iris
#[Out]# 33  Johanna
#[Out]# 34   Kostas
#[Out]# 35   Kostas
#[Out]# 36   Kostas
#[Out]# 37   Kostas
#[Out]# 38   Kostas
#[Out]# 39   Kostas
#[Out]# 40   Kostas
# Tue, 08 Dec 2020 14:20:36
displayer = '''
SELECT sumday.cID, sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0     72   0.40
#[Out]# 1      0   0.45
#[Out]# 2     22   0.45
#[Out]# 3     77   0.45
#[Out]# 4    179   0.45
#[Out]# ..   ...    ...
#[Out]# 280  190  21.90
#[Out]# 281   71  22.25
#[Out]# 282  108  23.95
#[Out]# 283  124  28.80
#[Out]# 284  161  39.10
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 14:20:36
pd.read_sql_query('SELECT cID, cName FROM customer WHERE cID = 161', conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Tue, 08 Dec 2020 14:20:36
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:20:36
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 08 Dec 2020 14:20:36
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df.drop_duplicates(subset="cID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Tue, 08 Dec 2020 14:20:37
query4_5_with = '''
WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)
'''

query4_5 = query4_5_with + '''
SELECT city, max(amount) AS number
FROM citiesduplicates
GROUP BY city
'''
# Tue, 08 Dec 2020 14:20:37
displayer = '''
SELECT city, amount
FROM citiesduplicates
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Tue, 08 Dec 2020 14:20:37
#vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:20:37
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 14:20:37
answer = df_result['number'].sum()
answer
answer == 69
#[Out]# True
# Tue, 08 Dec 2020 14:20:37
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc5.txt'
query = query4_5

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:20:37
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

if os.path.exists('logs.zip'):
    os.remove('logs.zip')

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()

# IPython log file

# Tue, 08 Dec 2020 14:23:12
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 14:23:12
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Tue, 08 Dec 2020 14:23:12
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 08 Dec 2020 14:23:12
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Tue, 08 Dec 2020 14:23:12
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''
# Tue, 08 Dec 2020 14:23:12
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:23:12
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 14:23:12
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 14:23:12
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 14:23:12
# The rest of the final query
query4_3 = withs + '''
SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Tue, 08 Dec 2020 14:23:12
#vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 14:23:12
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:23:12
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:23:12
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(cID, sum) AS (
    SELECT   cID, sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Tue, 08 Dec 2020 14:23:12
query4_4 = query4_4_maxmoney + '''
    SELECT DISTINCT customer.cName
    FROM   partmax, customer, sumday
    WHERE  sumday.sum >= partmax.pmax
      AND  customer.cID = sumday.cID
'''
# Tue, 08 Dec 2020 14:23:12
#vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:23:12
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 14:23:13
displayer = '''
SELECT sumday.cID, sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0     72   0.40
#[Out]# 1      0   0.45
#[Out]# 2     22   0.45
#[Out]# 3     77   0.45
#[Out]# 4    179   0.45
#[Out]# ..   ...    ...
#[Out]# 280  190  21.90
#[Out]# 281   71  22.25
#[Out]# 282  108  23.95
#[Out]# 283  124  28.80
#[Out]# 284  161  39.10
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 14:23:13
pd.read_sql_query('SELECT cID, cName FROM customer WHERE cID = 161', conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Tue, 08 Dec 2020 14:23:13
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:23:13
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 08 Dec 2020 14:23:13
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df.drop_duplicates(subset="cID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Tue, 08 Dec 2020 14:23:13
query4_5_with = '''
WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)
'''

query4_5 = query4_5_with + '''
SELECT city, max(amount) AS number
FROM citiesduplicates
GROUP BY city
'''
# Tue, 08 Dec 2020 14:23:13
displayer = '''
SELECT city, amount
FROM citiesduplicates
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Tue, 08 Dec 2020 14:23:13
#vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:23:13
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 14:23:13
answer = df_result['number'].sum()
answer
answer == 69
#[Out]# True
# Tue, 08 Dec 2020 14:23:13
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc5.txt'
query = query4_5

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:23:13
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

if os.path.exists('logs.zip'):
    os.remove('logs.zip')

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()

# IPython log file

# Tue, 08 Dec 2020 14:23:59
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 14:23:59
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Tue, 08 Dec 2020 14:23:59
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 08 Dec 2020 14:23:59
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Tue, 08 Dec 2020 14:23:59
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''
# Tue, 08 Dec 2020 14:23:59
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:23:59
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 14:23:59
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 14:23:59
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 14:23:59
# The rest of the final query
query4_3 = withs + '''
SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Tue, 08 Dec 2020 14:23:59
#vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 14:23:59
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:23:59
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:23:59
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(cID, sum) AS (
    SELECT   cID, sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Tue, 08 Dec 2020 14:23:59
query4_4 = query4_4_maxmoney + '''
    SELECT DISTINCT customer.cName
    FROM   partmax, customer, sumday
    WHERE  sumday.sum >= partmax.pmax
      AND  customer.cID = sumday.cID
'''
# Tue, 08 Dec 2020 14:23:59
#vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:23:59
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 14:23:59
displayer = '''
SELECT sumday.cID, sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0     72   0.40
#[Out]# 1      0   0.45
#[Out]# 2     22   0.45
#[Out]# 3     77   0.45
#[Out]# 4    179   0.45
#[Out]# ..   ...    ...
#[Out]# 280  190  21.90
#[Out]# 281   71  22.25
#[Out]# 282  108  23.95
#[Out]# 283  124  28.80
#[Out]# 284  161  39.10
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 14:23:59
pd.read_sql_query('SELECT cID, cName FROM customer WHERE cID = 161', conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Tue, 08 Dec 2020 14:23:59
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:23:59
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 08 Dec 2020 14:24:00
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df.drop_duplicates(subset="cID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Tue, 08 Dec 2020 14:24:00
query4_5_with = '''
WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)
'''

query4_5 = query4_5_with + '''
SELECT city, max(amount) AS number
FROM citiesduplicates
GROUP BY city
'''
# Tue, 08 Dec 2020 14:24:00
displayer = '''
SELECT city, amount
FROM citiesduplicates
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Tue, 08 Dec 2020 14:24:00
#vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:24:00
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 14:24:00
answer = df_result['number'].sum()
answer
#[Out]# 69
# Tue, 08 Dec 2020 14:24:00
# Does this meet expectations?
answer == 69
#[Out]# True
# Tue, 08 Dec 2020 14:24:00
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc5.txt'
query = query4_5

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:24:00
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

if os.path.exists('logs.zip'):
    os.remove('logs.zip')

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()

# IPython log file

# Tue, 08 Dec 2020 14:24:35
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 14:24:35
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Tue, 08 Dec 2020 14:24:35
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 08 Dec 2020 14:24:35
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Tue, 08 Dec 2020 14:24:35
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''
# Tue, 08 Dec 2020 14:24:35
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:24:35
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 14:24:35
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 14:24:35
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 14:24:35
# The rest of the final query
query4_3 = withs + '''
SELECT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Tue, 08 Dec 2020 14:24:35
#vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 14:24:35
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:24:35
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:24:35
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(cID, sum) AS (
    SELECT   cID, sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Tue, 08 Dec 2020 14:24:35
query4_4 = query4_4_maxmoney + '''
    SELECT DISTINCT customer.cName
    FROM   partmax, customer, sumday
    WHERE  sumday.sum >= partmax.pmax
      AND  customer.cID = sumday.cID
'''
# Tue, 08 Dec 2020 14:24:35
#vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:24:35
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 14:24:36
displayer = '''
SELECT sumday.cID, sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0     72   0.40
#[Out]# 1      0   0.45
#[Out]# 2     22   0.45
#[Out]# 3     77   0.45
#[Out]# 4    179   0.45
#[Out]# ..   ...    ...
#[Out]# 280  190  21.90
#[Out]# 281   71  22.25
#[Out]# 282  108  23.95
#[Out]# 283  124  28.80
#[Out]# 284  161  39.10
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 14:24:36
pd.read_sql_query('SELECT cID, cName FROM customer WHERE cID = 161', conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Tue, 08 Dec 2020 14:24:36
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:24:36
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 08 Dec 2020 14:24:36
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df.drop_duplicates(subset="cID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Tue, 08 Dec 2020 14:24:36
query4_5_with = '''
WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)
'''

query4_5 = query4_5_with + '''
SELECT city, max(amount) AS number
FROM citiesduplicates
GROUP BY city
'''
# Tue, 08 Dec 2020 14:24:36
displayer = '''
SELECT city, amount
FROM citiesduplicates
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Tue, 08 Dec 2020 14:24:36
#vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:24:36
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 14:24:36
answer = df_result['number'].sum()
answer
#[Out]# 69
# Tue, 08 Dec 2020 14:24:36
# Does this meet expectations?
answer == 69
#[Out]# True
# Tue, 08 Dec 2020 14:24:36
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc5.txt'
query = query4_5

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:24:36
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

if os.path.exists('logs.zip'):
    os.remove('logs.zip')

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()

# IPython log file

# Tue, 08 Dec 2020 14:38:11
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 14:38:12
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Tue, 08 Dec 2020 14:38:12
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 08 Dec 2020 14:38:12
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Tue, 08 Dec 2020 14:38:12
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''
# Tue, 08 Dec 2020 14:38:12
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:38:12
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 14:38:12
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 14:38:12
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 14:38:12
# The rest of the final query
query4_3 = withs + '''
SELECT DISTINCT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Tue, 08 Dec 2020 14:38:12
#vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 14:38:12
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:38:12
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:38:12
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(cID, sum) AS (
    SELECT   cID, sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Tue, 08 Dec 2020 14:38:12
query4_4 = query4_4_maxmoney + '''
    SELECT DISTINCT customer.cName
    FROM   partmax, customer, sumday
    WHERE  sumday.sum >= partmax.pmax
      AND  customer.cID = sumday.cID
'''
# Tue, 08 Dec 2020 14:38:12
#vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:38:12
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 14:38:12
displayer = '''
SELECT sumday.cID, sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0     72   0.40
#[Out]# 1      0   0.45
#[Out]# 2     22   0.45
#[Out]# 3     77   0.45
#[Out]# 4    179   0.45
#[Out]# ..   ...    ...
#[Out]# 280  190  21.90
#[Out]# 281   71  22.25
#[Out]# 282  108  23.95
#[Out]# 283  124  28.80
#[Out]# 284  161  39.10
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 14:38:12
pd.read_sql_query('SELECT cID, cName FROM customer WHERE cID = 161', conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Tue, 08 Dec 2020 14:38:12
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:38:12
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 08 Dec 2020 14:38:12
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df.drop_duplicates(subset="cID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Tue, 08 Dec 2020 14:38:12
query4_5_with = '''
WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)
'''

query4_5 = query4_5_with + '''
SELECT city, max(amount) AS number
FROM citiesduplicates
GROUP BY city
'''
# Tue, 08 Dec 2020 14:38:12
displayer = '''
SELECT city, amount
FROM citiesduplicates
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Tue, 08 Dec 2020 14:38:12
#vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:38:12
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 14:38:12
answer = df_result['number'].sum()
answer
#[Out]# 69
# Tue, 08 Dec 2020 14:38:12
# Does this meet expectations?
answer == 69
#[Out]# True
# Tue, 08 Dec 2020 14:38:12
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc5.txt'
query = query4_5

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:38:12
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

if os.path.exists('logs.zip'):
    os.remove('logs.zip')

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()

# IPython log file

# Tue, 08 Dec 2020 14:38:44
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 14:38:44
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Tue, 08 Dec 2020 14:38:44
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 08 Dec 2020 14:38:44
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Tue, 08 Dec 2020 14:38:44
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''
# Tue, 08 Dec 2020 14:38:44
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:38:44
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 14:38:45
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 14:38:45
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 14:38:45
# The rest of the final query
query4_3 = withs + '''
SELECT DISTINCT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Tue, 08 Dec 2020 14:38:45
#vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 14:38:45
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:38:45
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:38:45
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(cID, sum) AS (
    SELECT   cID, sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Tue, 08 Dec 2020 14:38:45
query4_4 = query4_4_maxmoney + '''
    SELECT DISTINCT customer.cName
    FROM   partmax, customer, sumday
    WHERE  sumday.sum >= partmax.pmax
      AND  customer.cID = sumday.cID
'''
# Tue, 08 Dec 2020 14:38:45
#vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:38:45
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 14:38:45
displayer = '''
SELECT sumday.cID, sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0     72   0.40
#[Out]# 1      0   0.45
#[Out]# 2     22   0.45
#[Out]# 3     77   0.45
#[Out]# 4    179   0.45
#[Out]# ..   ...    ...
#[Out]# 280  190  21.90
#[Out]# 281   71  22.25
#[Out]# 282  108  23.95
#[Out]# 283  124  28.80
#[Out]# 284  161  39.10
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 14:38:45
pd.read_sql_query('SELECT cID, cName FROM customer WHERE cID = 161', conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Tue, 08 Dec 2020 14:38:45
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:38:45
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 08 Dec 2020 14:38:45
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df.drop_duplicates(subset="cID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Tue, 08 Dec 2020 14:38:45
query4_5_with = '''
WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)
'''

query4_5 = query4_5_with + '''
SELECT city, max(amount) AS number
FROM citiesduplicates
GROUP BY city
'''
# Tue, 08 Dec 2020 14:38:45
displayer = '''
SELECT city, amount
FROM citiesduplicates
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Tue, 08 Dec 2020 14:38:45
#vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:38:45
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 14:38:45
answer = df_result['number'].sum()
answer
#[Out]# 69
# Tue, 08 Dec 2020 14:38:45
# Does this meet expectations?
answer == 69
#[Out]# True
# Tue, 08 Dec 2020 14:38:45
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc5.txt'
query = query4_5

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:38:45
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

if os.path.exists('logs.zip'):
    os.remove('logs.zip')

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()

# IPython log file

# Tue, 08 Dec 2020 14:39:18
# This connects a database instance on your local machine, make the name of the database descriptive!
db_location = 'shopping.db'
conn = sqlite3.connect(db_location)
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 14:39:18
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
sql_location = 'shoppingDB.sql'


# needed to check for empty db file
import os

if (os.stat(db_location).st_size == 0) :
    f = open(sql_location,'r')
    sql = f.read()
    cur.executescript(sql)
# Tue, 08 Dec 2020 14:39:18
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Tue, 08 Dec 2020 14:39:18
# First, let us define a query which takes care of the union on the right hand side
query4_3_union = '''
WITH cities(city) AS (
               SELECT customer.city
               FROM   customer
           UNION
               SELECT s.city
               FROM   store AS s
)
'''
# Tue, 08 Dec 2020 14:39:18
# Some auxiliary tables
withs = query4_3_union + '''
, PiRminusSrcrossS(sName, city) AS (
       SELECT b.sName, cities.city
       FROM   (SELECT store.sName FROM STORE) AS b, cities
)

, PiRminusSSr(sName, city) AS (
       SELECT store.sName, store.city
       FROM store
)

, insideouterbrackets(sName, city) AS (
       SELECT PiRminusSrcrossS.sName, PiRminusSrcrossS.city
       FROM   PiRminusSrcrossS, PiRminusSSr
       WHERE  (PiRminusSrcrossS.sName, PiRminusSrcrossS.city) NOT IN (
              SELECT PiRminusSSr.sName, PiRminusSSr.city
              FROM   PiRminusSSr
       )
)

, projectionouterbrackets(sName) AS (
       SELECT insideouterbrackets.sName
       FROM insideouterbrackets
)
'''
# Tue, 08 Dec 2020 14:39:18
# Display the list of cities in a separate cell

displayer = '''
SELECT cities.city
FROM cities
'''

pd.read_sql_query(query4_3_union + displayer, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Tue, 08 Dec 2020 14:39:18
# Display the list of stores
list_stores = '''
SELECT DISTINCT store.sName FROM store
'''

pd.read_sql_query(list_stores, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Tue, 08 Dec 2020 14:39:18
# Display the list of tuples of stores and cities such that that store has a branch in that city
list_stores_and_cities = '''
SELECT DISTINCT store.sName, store.city FROM store ORDER BY store.sName, store.city
'''

pd.read_sql_query(list_stores_and_cities, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein      Breda
#[Out]# 1   Albert Hein  Eindhoven
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein    Tilburg
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop      Breda
#[Out]# 7          Coop  Rotterdam
#[Out]# 8          Coop    Tilburg
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet  Rotterdam
#[Out]# 16    Hoogvliet    Tilburg
#[Out]# 17        Jumbo      Breda
#[Out]# 18        Jumbo  Eindhoven
#[Out]# 19        Jumbo        Oss
#[Out]# 20        Jumbo  Rotterdam
#[Out]# 21        Jumbo    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Lidl      Breda
#[Out]# 24         Lidl  Eindhoven
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl    Utrecht
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro  Rotterdam
#[Out]# 31       Sligro    Tilburg
# Tue, 08 Dec 2020 14:39:18
# Shows tuples of store and city in which no branch exists
displayer = '''
SELECT DISTINCT * FROM insideouterbrackets ORDER BY insideouterbrackets.sName, insideouterbrackets.city
'''

pd.read_sql_query(withs + displayer, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Tue, 08 Dec 2020 14:39:18
# The rest of the final query
query4_3 = withs + '''
SELECT DISTINCT store.sName
FROM   store, projectionouterbrackets
WHERE  store.sName NOT IN (
       SELECT projectionouterbrackets.sName
       FROM   projectionouterbrackets
)
'''
# Tue, 08 Dec 2020 14:39:18
#vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 14:39:18
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 14:39:18
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc3.txt'
query = query4_3

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:39:18
# As a reference, the schema of the purchase table
# purchase(tID, cID, sID, pID, date, quantity, price)

query4_4_maxmoney = '''
WITH sumday(cID, sum) AS (
    SELECT   cID, sum(price)
    FROM     purchase
    GROUP BY cID, date
)
, maximum(max) AS (
    SELECT   max(sumday.sum)
    FROM     sumday
)
, partmax(pmax) AS (
    SELECT   0.75 * maximum.max
    FROM     maximum
)
'''

# Display the boundary value: 75% of the max amount spent by a single customer on a single day
displayer = '''
SELECT partmax.pmax FROM partmax
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      pmax
#[Out]# 0  29.325
# Tue, 08 Dec 2020 14:39:19
query4_4 = query4_4_maxmoney + '''
    SELECT DISTINCT customer.cName
    FROM   partmax, customer, sumday
    WHERE  sumday.sum >= partmax.pmax
      AND  customer.cID = sumday.cID
'''
# Tue, 08 Dec 2020 14:39:19
#vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 14:39:19
pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Tue, 08 Dec 2020 14:39:19
displayer = '''
SELECT sumday.cID, sumday.sum FROM sumday ORDER BY sum
'''
pd.read_sql_query(query4_4_maxmoney + displayer, conn)
#[Out]#      cID    sum
#[Out]# 0     72   0.40
#[Out]# 1      0   0.45
#[Out]# 2     22   0.45
#[Out]# 3     77   0.45
#[Out]# 4    179   0.45
#[Out]# ..   ...    ...
#[Out]# 280  190  21.90
#[Out]# 281   71  22.25
#[Out]# 282  108  23.95
#[Out]# 283  124  28.80
#[Out]# 284  161  39.10
#[Out]# 
#[Out]# [285 rows x 2 columns]
# Tue, 08 Dec 2020 14:39:19
pd.read_sql_query('SELECT cID, cName FROM customer WHERE cID = 161', conn)
#[Out]#    cID  cName
#[Out]# 0  161  Floor
# Tue, 08 Dec 2020 14:39:19
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc4.txt'
query = query4_4

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:39:19
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 7      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 9      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# ..   ...        ...
#[Out]# 836  190    Utrecht
#[Out]# 838  190    Utrecht
#[Out]# 840  190    Utrecht
#[Out]# 841  190    Utrecht
#[Out]# 846  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Tue, 08 Dec 2020 14:39:19
datadump = '''
     SELECT purchase.tID, customer.cID, customer.city
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     ORDER BY purchase.cID
'''
df = pd.read_sql_query(datadump, conn)
df.set_index("tID", inplace=True)
df.drop_duplicates(subset="cID", inplace=True)
df
#[Out]#      cID       city
#[Out]# tID                
#[Out]# 3      1      Breda
#[Out]# 8      2  Amsterdam
#[Out]# 14     3      Breda
#[Out]# 16     4  Amsterdam
#[Out]# 22     5    Utrecht
#[Out]# ..   ...        ...
#[Out]# 472  182  Eindhoven
#[Out]# 778  185  Eindhoven
#[Out]# 779  186  Eindhoven
#[Out]# 780  188  Rotterdam
#[Out]# 788  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Tue, 08 Dec 2020 14:39:19
query4_5_with = '''
WITH citiesduplicates(city, amount) AS (
     SELECT customer.city, count(DISTINCT purchase.cID) AS amount
     FROM purchase, store, customer
     WHERE store.city = "Eindhoven"
       AND purchase.cID = customer.cID
       AND store.sID = purchase.sID
     GROUP BY customer.city
 UNION
     SELECT customer.city, 0 FROM customer
)
'''

query4_5 = query4_5_with + '''
SELECT city, max(amount) AS number
FROM citiesduplicates
GROUP BY city
'''
# Tue, 08 Dec 2020 14:39:19
displayer = '''
SELECT city, amount
FROM citiesduplicates
'''
pd.read_sql_query(query4_5_with + displayer, conn)
#[Out]#          city  amount
#[Out]# 0   Amsterdam       0
#[Out]# 1   Amsterdam      10
#[Out]# 2       Breda       0
#[Out]# 3       Breda       9
#[Out]# 4   Eindhoven       0
#[Out]# 5   Eindhoven      15
#[Out]# 6         Oss       0
#[Out]# 7   Rotterdam       0
#[Out]# 8   Rotterdam      13
#[Out]# 9     Tilburg       0
#[Out]# 10    Tilburg      10
#[Out]# 11    Utrecht       0
#[Out]# 12    Utrecht      12
# Tue, 08 Dec 2020 14:39:19
#vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 14:39:19
df_result = pd.read_sql_query(query4_5, conn)
df_result
#[Out]#         city  number
#[Out]# 0  Amsterdam      10
#[Out]# 1      Breda       9
#[Out]# 2  Eindhoven      15
#[Out]# 3        Oss       0
#[Out]# 4  Rotterdam      13
#[Out]# 5    Tilburg      10
#[Out]# 6    Utrecht      12
# Tue, 08 Dec 2020 14:39:19
answer = df_result['number'].sum()
answer
#[Out]# 69
# Tue, 08 Dec 2020 14:39:19
# Does this meet expectations?
answer == 69
#[Out]# True
# Tue, 08 Dec 2020 14:39:19
# Script which helps to write the file to be submitted.
# Prevents copy-and-paste errors
import os

# Parameters
output_filename = 'exc5.txt'
query = query4_5

if os.path.exists(output_filename):
    os.remove(output_filename)

output_file = open(output_filename, "w")
output_file.write(query)
output_file.close()
# Tue, 08 Dec 2020 14:39:19
get_ipython().run_line_magic('logstop', '')

import os
import zipfile

if os.path.exists('logs.zip'):
    os.remove('logs.zip')

zipf = zipfile.ZipFile('logs.zip', 'w', zipfile.ZIP_DEFLATED)

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.startswith('ipython_log'):
            zipf.write(os.path.join(root, file))

zipf.close()


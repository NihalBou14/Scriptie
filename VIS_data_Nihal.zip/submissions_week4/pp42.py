# IPython log file

# Mon, 07 Dec 2020 16:09:02
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# Mon, 07 Dec 2020 16:09:37
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 16:09:39
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x1dea5240730>
# Mon, 07 Dec 2020 16:17:02
query4_3 = '''
SELECT store.sName, store.city
FROM store
WHERE store.city IN 

SELECT customer.city
FROM customer
UNION
SELECT store.city
FROM store

'''
# Mon, 07 Dec 2020 16:17:02
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 16:17:27
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis

# IPython log file

get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
get_ipython().run_line_magic('logstop', '')
get_ipython().run_line_magic('logstart', '-o -t')
import sqlite3
import pandas as pd
from sqlvis import vis
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file.
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor object at 0x000001DEA5240730>
query4_3 = '''
SELECT store.sName, store.city
FROM store
WHERE store.city IN 

SELECT customer.city
FROM customer
UNION
SELECT store.city
FROM store

'''
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 16:17:28
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 16:17:28
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 07 Dec 2020 16:17:32
query4_3 = '''
SELECT store.sName, store.city
FROM store
WHERE store.city IN 

SELECT customer.city
FROM customer
UNION
SELECT store.city
FROM store

'''
# Mon, 07 Dec 2020 16:17:33
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 16:17:36
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 16:17:52
query4_3 = '''
SELECT store.sName, store.city
FROM store
WHERE store.city IN 

(SELECT customer.city
FROM customer
UNION
SELECT store.city
FROM store)

'''
# Mon, 07 Dec 2020 16:17:53
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 16:17:53
pd.read_sql_query(query4_3, conn)
#[Out]#         sName       city
#[Out]# 0        Coop  Amsterdam
#[Out]# 1   Hoogvliet      Breda
#[Out]# 2       Jumbo  Rotterdam
#[Out]# 3      Sligro  Rotterdam
#[Out]# 4   Hoogvliet  Eindhoven
#[Out]# ..        ...        ...
#[Out]# 59      Jumbo      Breda
#[Out]# 60       Lidl      Breda
#[Out]# 61       Lidl      Breda
#[Out]# 62      Jumbo  Eindhoven
#[Out]# 63      Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]


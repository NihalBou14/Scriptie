# IPython log file

# Mon, 07 Dec 2020 16:31:57
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Mon, 07 Dec 2020 16:32:01
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Mon, 07 Dec 2020 16:59:05
query4_3 = '''
    SELECT s.sName 
    FROM store s
    WHERE NOT EXISTS(
        SELECT city
        FROM customer
        WHERE NOT EXISTS(
            select city
            FROM store))
    
'''
# Mon, 07 Dec 2020 16:59:05
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 16:59:54
# In order to allow for visualization, we need to extract the schema.

schema = vis.schema_from_conn(conn)
# Mon, 07 Dec 2020 16:59:58
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:00:01
pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Mon, 07 Dec 2020 17:04:07
query4_3 = '''
    SELECT city
    FROM store s1
    WHERE NOT EXISTS (
        SELECT *
        FROM store s2
        WHERE s1.sID = s2.sID
        AND s1.city = s2.city)
'''
# Mon, 07 Dec 2020 17:04:08
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:04:09
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [city]
#[Out]# Index: []
# Mon, 07 Dec 2020 17:04:52
query4_3 = '''
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS(
    SELECT city
    FROM store s1
    WHERE NOT EXISTS (
        SELECT *
        FROM store s2
        WHERE s1.sID = s2.sID
        AND s1.city = s2.city))
'''
# Mon, 07 Dec 2020 17:04:52
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:04:53
pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Mon, 07 Dec 2020 17:05:28
query4_3 = '''
    SELECT DISTINCT s.sName
    FROM store s
    WHERE NOT EXISTS(
    SELECT city
    FROM store s1
    WHERE NOT EXISTS (
        SELECT *
        FROM store s2
        WHERE s1.sID = s2.sID
        AND s1.city = s2.city))
'''
# Mon, 07 Dec 2020 17:05:29
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:05:30
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Mon, 07 Dec 2020 17:07:31
query4_3 = '''
    SELECT DISTINCT s.sName
    FROM store s
    WHERE NOT EXISTS(
    SELECT city
    FROM store s1
    WHERE NOT EXISTS (
        SELECT *
        FROM store s2
        WHERE s1.sID = s2.sID))
'''
# Mon, 07 Dec 2020 17:07:31
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:07:31
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Mon, 07 Dec 2020 17:19:14
query4_3 = '''
    WITH all_cities(city) as (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT s1.sName
        FROM store s1, all_cities
        WHERE s1.city = all_cities.city NOT EXISTS(
            SELECT s2.sName, s2.city
            FROM store s2
            WHERE s2.sID = s.sID))
'''
# Mon, 07 Dec 2020 17:19:14
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:19:14
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 17:19:24
query4_3 = '''
    WITH all_cities(city) as (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT s1.sName
        FROM store s1, all_cities
        WHERE s1.city = all_cities.city AND NOT EXISTS(
            SELECT s2.sName, s2.city
            FROM store s2
            WHERE s2.sID = s.sID))
'''
# Mon, 07 Dec 2020 17:19:25
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:19:25
pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Mon, 07 Dec 2020 17:21:24
query4_3 = '''
    WITH all_cities(city) as (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT s1.sName
        FROM store s1, all_cities
        WHERE s1.city = all_cities.city AND NOT EXISTS(
            SELECT s2.sName, s2.city
            FROM store s2
            WHERE s2.city = s.city))
'''
# Mon, 07 Dec 2020 17:21:25
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:21:25
pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Mon, 07 Dec 2020 17:23:26
query4_3 = '''
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT s1.city
        FROM store s1
        WHERE NOT EXISTS(
            SELECT s2.city
            FROM store s2
            WHERE s2.city = s.city))
'''
# Mon, 07 Dec 2020 17:23:27
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:23:27
pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Mon, 07 Dec 2020 17:24:33
query4_3 = '''
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT s1.city
        FROM store s1
        WHERE NOT EXISTS(
            SELECT s2.city
            FROM store s2
            WHERE s2.city = s1.city))
'''
# Mon, 07 Dec 2020 17:24:33
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:24:33
pd.read_sql_query(query4_3, conn)
#[Out]#         sName
#[Out]# 0        Coop
#[Out]# 1   Hoogvliet
#[Out]# 2       Jumbo
#[Out]# 3      Sligro
#[Out]# 4   Hoogvliet
#[Out]# ..        ...
#[Out]# 59      Jumbo
#[Out]# 60       Lidl
#[Out]# 61       Lidl
#[Out]# 62      Jumbo
#[Out]# 63      Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Mon, 07 Dec 2020 17:27:14
query4_3 = '''
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT s1.city
        FROM store s1
        WHERE NOT EXISTS(
            SELECT s2.city
            FROM store s2
            WHERE s2.city = s1.city
            AND s.sID = s2.sID))
'''
# Mon, 07 Dec 2020 17:27:14
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:27:14
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 17:27:30
query4_3 = '''
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT s1.city
        FROM store s1
        WHERE NOT EXISTS(
            SELECT s2.city
            FROM store s2
            WHERE s2.city = s1.city
            AND s.sName = s2.sName))
'''
# Mon, 07 Dec 2020 17:27:30
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:27:30
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 17:28:24
query4_3 = '''
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT *
        FROM store s1
        WHERE NOT EXISTS(
            SELECT *
            FROM store s2
            WHERE s2.city = s1.city
            AND s.sName = s2.sName))
'''
# Mon, 07 Dec 2020 17:28:24
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:28:25
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 17:36:19
query4_3 = '''
    SELECT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT *
        FROM store s1
        WHERE NOT EXISTS(
            SELECT *
            FROM store s2
            WHERE s2.city = s1.city
            AND s.sName = s2.sName))
'''
# Mon, 07 Dec 2020 17:36:19
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:36:20
pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
#[Out]# 1  Jumbo
#[Out]# 2  Jumbo
#[Out]# 3  Jumbo
#[Out]# 4  Jumbo
#[Out]# 5  Jumbo
#[Out]# 6  Jumbo
#[Out]# 7  Jumbo
#[Out]# 8  Jumbo
#[Out]# 9  Jumbo
# Mon, 07 Dec 2020 17:36:56
query4_3 = '''
    SELECT DISTINCT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT *
        FROM store s1
        WHERE NOT EXISTS(
            SELECT *
            FROM store s2
            WHERE s2.city = s1.city
            AND s.sName = s2.sName))
'''
# Mon, 07 Dec 2020 17:36:56
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:36:57
pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
# Mon, 07 Dec 2020 17:41:02
query4_3 = '''
    WITH all_cities(city) AS SELECT city FROM customer UNION SELECT city FROM store
    SELECT DISTINCT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT *
        FROM all_cities
        WHERE NOT EXISTS(
            SELECT *
            FROM store s2
            WHERE s2.city = all_cities.city
            AND s.sName = s2.sName));
'''
# Mon, 07 Dec 2020 17:41:02
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:41:02
pd.read_sql_query(query4_3, conn)
# Mon, 07 Dec 2020 17:41:54
query4_3 = '''
    WITH all_cities(city) AS (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT DISTINCT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT *
        FROM all_cities
        WHERE NOT EXISTS(
            SELECT *
            FROM store s2
            WHERE s2.city = all_cities.city
            AND s.sName = s2.sName));
'''
# Mon, 07 Dec 2020 17:41:54
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:41:55
pd.read_sql_query(query4_3, conn)
#[Out]#    sName
#[Out]# 0  Jumbo
# Mon, 07 Dec 2020 17:43:18
query4_3 = '''
    WITH all_cities(city) AS (SELECT city FROM customer UNION SELECT city FROM store)
    SELECT DISTINCT s.sName
    FROM store s
    WHERE NOT EXISTS (
        SELECT *
        FROM all_cities
        WHERE NOT EXISTS(
            SELECT *
            FROM store s2
            WHERE s2.city = all_cities.city
            AND s.sName = s2.sName));
'''
# Mon, 07 Dec 2020 17:43:18
vis.visualize(query4_3, schema)
# Mon, 07 Dec 2020 17:43:18
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Mon, 07 Dec 2020 18:33:36
query4_4 = '''
    WITH max_spent(value) AS (SELECT MAX(spent) FROM (SELECT cID, date, SUM(quantity*price) AS spent FROM purchase GROUP BY cID, date)),
         spent_per_day(cID, date, spent) AS (SELECT cID, date, SUM(quantity*price) AS spent FROM purchase GROUP BY cID, date)
    SELECT DISTINCT spent_per_day.cID
    FROM spent_per_day, max_spent
    WHERE spent_per_day.spent >= 0.75*max_spent;
'''
# Mon, 07 Dec 2020 18:33:36
vis.visualize(query4_4, schema)
# Mon, 07 Dec 2020 18:33:36
pd.read_sql_query(query4_4, conn)
# Mon, 07 Dec 2020 18:33:48
query4_4 = '''
    WITH max_spent(value) AS (SELECT MAX(spent) FROM (SELECT cID, date, SUM(quantity*price) AS spent FROM purchase GROUP BY cID, date)),
         spent_per_day(cID, date, spent) AS (SELECT cID, date, SUM(quantity*price) AS spent FROM purchase GROUP BY cID, date)
    SELECT DISTINCT spent_per_day.cID
    FROM spent_per_day, max_spent
    WHERE spent_per_day.spent >= 0.75*max_spent.value;
'''
# Mon, 07 Dec 2020 18:33:48
vis.visualize(query4_4, schema)
# Mon, 07 Dec 2020 18:33:48
pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0   33
#[Out]# 1   71
#[Out]# 2  109
#[Out]# 3  124
#[Out]# 4  161
# Mon, 07 Dec 2020 18:37:53
query4_5 = '''
    SELECT p.cID
    FROM purchase p, store s
    WHERE p.SID = s.sID AND s.city = 'Eindhoven'
'''
# Mon, 07 Dec 2020 18:37:53
vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 18:37:53
pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# ..   ...
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Mon, 07 Dec 2020 18:38:00
query4_5 = '''
    SELECT DISTINCT p.cID
    FROM purchase p, store s
    WHERE p.SID = s.sID AND s.city = 'Eindhoven'
'''
# Mon, 07 Dec 2020 18:38:00
vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 18:38:01
pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# ..  ...
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Mon, 07 Dec 2020 18:38:46
query4_5 = '''
    SELECT DISTINCT p.cID, c.city
    FROM purchase p, store s, customer c
    WHERE p.SID = s.sID AND s.city = 'Eindhoven' AND p.cID = c.cID
'''
# Mon, 07 Dec 2020 18:38:46
vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 18:38:46
pd.read_sql_query(query4_5, conn)
#[Out]#     cID       city
#[Out]# 0     1      Breda
#[Out]# 1     2  Amsterdam
#[Out]# 2     3      Breda
#[Out]# 3     4  Amsterdam
#[Out]# 4     5    Utrecht
#[Out]# ..  ...        ...
#[Out]# 64  182  Eindhoven
#[Out]# 65  185  Eindhoven
#[Out]# 66  186  Eindhoven
#[Out]# 67  188  Rotterdam
#[Out]# 68  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Mon, 07 Dec 2020 18:39:39
query4_5 = '''
    SELECT COUNT(DISTINCT p.cID), c.city
    FROM purchase p, store s, customer c
    WHERE p.SID = s.sID AND s.city = 'Eindhoven' AND p.cID = c.cID
    GROUP BY c.city
'''
# Mon, 07 Dec 2020 18:39:39
vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 18:39:39
pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(DISTINCT p.cID)       city
#[Out]# 0                     10  Amsterdam
#[Out]# 1                      9      Breda
#[Out]# 2                     15  Eindhoven
#[Out]# 3                     13  Rotterdam
#[Out]# 4                     10    Tilburg
#[Out]# 5                     12    Utrecht
# Mon, 07 Dec 2020 18:39:47
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT p.cID)
    FROM purchase p, store s, customer c
    WHERE p.SID = s.sID AND s.city = 'Eindhoven' AND p.cID = c.cID
    GROUP BY c.city
'''
# Mon, 07 Dec 2020 18:39:47
vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 18:39:47
pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(DISTINCT p.cID)
#[Out]# 0  Amsterdam                     10
#[Out]# 1      Breda                      9
#[Out]# 2  Eindhoven                     15
#[Out]# 3  Rotterdam                     13
#[Out]# 4    Tilburg                     10
#[Out]# 5    Utrecht                     12
# Mon, 07 Dec 2020 18:39:57
query4_5 = '''
    SELECT c.city, COUNT(DISTINCT p.cID) as count
    FROM purchase p, store s, customer c
    WHERE p.SID = s.sID AND s.city = 'Eindhoven' AND p.cID = c.cID
    GROUP BY c.city
'''
# Mon, 07 Dec 2020 18:39:57
vis.visualize(query4_5, schema)
# Mon, 07 Dec 2020 18:39:57
pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12


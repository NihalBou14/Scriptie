# IPython log file

# Wed, 09 Dec 2020 02:27:32
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 02:27:36
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x2f22e9c8960>
# Wed, 09 Dec 2020 03:53:41
query4_3 = '''
    SELECT sName, city 
    
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 03:56:02
query4_3 = '''
    SELECT sName, city 
    FROM store
    WHERE city not IN (customer.city or store.city)
    
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 03:59:35
query4_3 = '''
    SELECT sName, city 
    FROM store
    WHERE city not IN (SELECT city FROM customer) or city not IN (SELECT city FROM store)
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 04:01:02
query4_3 = '''
    SELECT sName, city 
    FROM store
    WHERE city not IN (SELECT city FROM customer) AND city not IN (SELECT city FROM store)
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 04:01:06
query4_3 = '''
    SELECT sName, city 
    FROM store
    WHERE city not IN (SELECT city FROM customer) OR city not IN (SELECT city FROM store)
    
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []


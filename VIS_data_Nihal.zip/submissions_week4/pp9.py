# IPython log file

# Wed, 09 Dec 2020 11:14:53
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 11:14:56
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x7a283a3077a0>
# Wed, 09 Dec 2020 11:49:52
query4_3 = '''
SELECT city FROM customer
UNION
SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 11:51:44
query4_3 = '''

SELECT city FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          city
#[Out]# 0   Amsterdam
#[Out]# 1       Breda
#[Out]# 2   Rotterdam
#[Out]# 3   Rotterdam
#[Out]# 4   Eindhoven
#[Out]# ..        ...
#[Out]# 59      Breda
#[Out]# 60      Breda
#[Out]# 61      Breda
#[Out]# 62  Eindhoven
#[Out]# 63        Oss
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Wed, 09 Dec 2020 11:51:54
query4_3 = '''

SELECT city FROM store, customer
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:00:17
query4_3 = '''
CREATE TEMP TABLE allCities as
SELECT city FROM customer
union
SELECT city FROM store;

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:01:23
query4_3 = '''
CREATE TEMP TABLE allCities as
SELECT city FROM customer
union
SELECT city FROM store;
SELECT DISTINCT store.sName, allCities.city
FROM store, allCities;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:02:24
query4_3 = '''
DROP TABLE IF EXISTS allCities;
CREATE TEMP TABLE allCities as
SELECT city FROM customer
union
SELECT city FROM store;
SELECT DISTINCT store.sName, allCities.city
FROM store, allCities;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:05:40
query4_3 = '''
SELECT DISTINCT x.sName
FROM store AS x
WHERE NOT EXISTS (
    SELECT *
    FROM (SELECT city FROM store UNION SELECT city FROM customer) AS y
    WHERE NOT EXISTS (
        SELECT *
        FROM store AS z
        WHERE (z.sName = x.sName)
        AND (z.city = x.city)));
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Wed, 09 Dec 2020 12:06:10
query4_3 = '''
SELECT DISTINCT x.sName, x.city
FROM store AS x
WHERE NOT EXISTS (
    SELECT *
    FROM (SELECT city FROM store UNION SELECT city FROM customer) AS y
    WHERE NOT EXISTS (
        SELECT *
        FROM store AS z
        WHERE (z.sName = x.sName)
        AND (z.city = x.city)));
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Wed, 09 Dec 2020 12:06:55
query4_3 = '''
SELECT DISTINCT x.sName, x.city
FROM store AS x
WHERE NOT EXISTS (
    SELECT *
    FROM (SELECT city FROM store UNION SELECT city FROM customer) AS y
    WHERE NOT EXISTS (
        SELECT *
        FROM store AS z
        WHERE (z.sName = x.sName)
        AND (z.city = x.city)))
ORDER BY x.sName;
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Eindhoven
#[Out]# 1   Albert Hein    Tilburg
#[Out]# 2   Albert Hein  Rotterdam
#[Out]# 3   Albert Hein      Breda
#[Out]# 4   Albert Hein    Utrecht
#[Out]# 5          Coop  Amsterdam
#[Out]# 6          Coop  Rotterdam
#[Out]# 7          Coop    Tilburg
#[Out]# 8          Coop      Breda
#[Out]# 9          Coop    Utrecht
#[Out]# 10         Dirk      Breda
#[Out]# 11         Dirk  Eindhoven
#[Out]# 12         Dirk  Rotterdam
#[Out]# 13    Hoogvliet      Breda
#[Out]# 14    Hoogvliet  Eindhoven
#[Out]# 15    Hoogvliet    Tilburg
#[Out]# 16    Hoogvliet  Rotterdam
#[Out]# 17        Jumbo  Rotterdam
#[Out]# 18        Jumbo    Tilburg
#[Out]# 19        Jumbo  Eindhoven
#[Out]# 20        Jumbo      Breda
#[Out]# 21        Jumbo        Oss
#[Out]# 22         Lidl  Eindhoven
#[Out]# 23         Lidl  Amsterdam
#[Out]# 24         Lidl    Utrecht
#[Out]# 25         Lidl  Rotterdam
#[Out]# 26         Lidl      Breda
#[Out]# 27       Sligro  Rotterdam
#[Out]# 28       Sligro      Breda
#[Out]# 29       Sligro  Eindhoven
#[Out]# 30       Sligro    Tilburg
#[Out]# 31       Sligro  Amsterdam
# Wed, 09 Dec 2020 12:08:26
query4_3 = '''
SELECT DISTINCT x.sName, x.city
FROM store AS x
WHERE NOT EXISTS (
    SELECT *
    FROM (SELECT city FROM store UNION SELECT city FROM customer) AS y
    WHERE NOT EXISTS (
        SELECT *
        FROM store AS z
        WHERE (z.sName = x.sName)
        AND (z.city = x=y.city)))
ORDER BY x.sName;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:08:36
query4_3 = '''
SELECT DISTINCT x.sName, x.city
FROM store AS x
WHERE NOT EXISTS (
    SELECT *
    FROM (SELECT city FROM store UNION SELECT city FROM customer) AS y
    WHERE NOT EXISTS (
        SELECT *
        FROM store AS z
        WHERE (z.sName = x.sName)
        AND (z.city = y.city)))
ORDER BY x.sName;
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:08:47
query4_3 = '''
SELECT DISTINCT x.sName, x.city
FROM store AS x
WHERE NOT EXISTS (
    SELECT *
    FROM (SELECT city FROM store UNION SELECT city FROM customer) AS y
    WHERE NOT EXISTS (
        SELECT *
        FROM store AS z
        WHERE (z.sName = x.sName)
        AND (z.city = y.city)))
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:08:56
query4_3 = '''
SELECT DISTINCT x.sName, x.city
FROM store AS x
WHERE NOT EXISTS (
    SELECT city
    FROM (SELECT city FROM store UNION SELECT city FROM customer) AS y
    WHERE NOT EXISTS (
        SELECT city
        FROM store AS z
        WHERE (z.sName = x.sName)
        AND (z.city = y.city)))
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:09:37
query4_4 = '''
SELECT city FROM store UNION SELECT city FROM customer
'''

pd.read_sql_query(query4_4, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 12:14:39
query4_5 = '''
SELECT count(customer.cID), customer.city
FROM customer, purchase, store
WHERE store.city = "eindhoven"
        AND
      store.sID = purchase.cID
        AND
      purchase.cID = customer.cID
GROUP BY customer.city
HAVING count(customer.cID) > 0
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [count(customer.cID), city]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:15:13
query4_5 = '''
SELECT customer.cID
FROM customer, purchase
WHERE customer.cID = purchase.cID
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      0
#[Out]# 1      1
#[Out]# 2      1
#[Out]# 3      1
#[Out]# 4      1
#[Out]# ..   ...
#[Out]# 504  190
#[Out]# 505  190
#[Out]# 506  190
#[Out]# 507  190
#[Out]# 508  190
#[Out]# 
#[Out]# [509 rows x 1 columns]
# Wed, 09 Dec 2020 12:15:52
query4_5 = '''
SELECT customer.cID
FROM customer, purchase, store
WHERE customer.cID = purchase.cID
        AND
      purchase.sID = store.sID
        AND
      store.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID
#[Out]# 0      1
#[Out]# 1      1
#[Out]# 2      2
#[Out]# 3      2
#[Out]# 4      3
#[Out]# ..   ...
#[Out]# 128  190
#[Out]# 129  190
#[Out]# 130  190
#[Out]# 131  190
#[Out]# 132  190
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Wed, 09 Dec 2020 12:16:06
query4_5 = '''
SELECT customer.cID, customer.city
FROM customer, purchase, store
WHERE customer.cID = purchase.cID
        AND
      purchase.sID = store.sID
        AND
      store.city = "Eindhoven"
      
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID       city
#[Out]# 0      1      Breda
#[Out]# 1      1      Breda
#[Out]# 2      2  Amsterdam
#[Out]# 3      2  Amsterdam
#[Out]# 4      3      Breda
#[Out]# ..   ...        ...
#[Out]# 128  190    Utrecht
#[Out]# 129  190    Utrecht
#[Out]# 130  190    Utrecht
#[Out]# 131  190    Utrecht
#[Out]# 132  190    Utrecht
#[Out]# 
#[Out]# [133 rows x 2 columns]
# Wed, 09 Dec 2020 12:16:34
query4_5 = '''
SELECT count(customer.cID), customer.city
FROM customer, purchase, store
WHERE customer.cID = purchase.cID
        AND
      purchase.sID = store.sID
        AND
      store.city = "Eindhoven"
GROUP BY customer.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    count(customer.cID)       city
#[Out]# 0                   17  Amsterdam
#[Out]# 1                   27      Breda
#[Out]# 2                   24  Eindhoven
#[Out]# 3                   16  Rotterdam
#[Out]# 4                   18    Tilburg
#[Out]# 5                   31    Utrecht
# Wed, 09 Dec 2020 12:16:58
query4_5 = '''
SELECT count(customer.cID), customer.city
FROM customer, purchase, store
WHERE customer.cID = purchase.cID
        AND
      purchase.sID = store.sID
        AND
      store.city = "Eindhoven"
GROUP BY customer.city
HAVING count(customer.cID) > 0;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    count(customer.cID)       city
#[Out]# 0                   17  Amsterdam
#[Out]# 1                   27      Breda
#[Out]# 2                   24  Eindhoven
#[Out]# 3                   16  Rotterdam
#[Out]# 4                   18    Tilburg
#[Out]# 5                   31    Utrecht
# Wed, 09 Dec 2020 12:20:39
query4_4 = '''

    SELECT MAX sum(price)
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:21:02
query4_4 = '''

    SELECT max(sum(price))
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:22:24
query4_4 = '''

    SELECT price
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price
#[Out]# 0     0.45
#[Out]# 1     4.65
#[Out]# 2     0.90
#[Out]# 3     2.45
#[Out]# 4     1.35
#[Out]# ..     ...
#[Out]# 280   0.50
#[Out]# 281   2.55
#[Out]# 282   3.70
#[Out]# 283   1.30
#[Out]# 284   1.20
#[Out]# 
#[Out]# [285 rows x 1 columns]
# Wed, 09 Dec 2020 12:22:31
query4_4 = '''

    SELECT price, cID, date
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      price  cID        date
#[Out]# 0     0.45    0  2018-08-22
#[Out]# 1     4.65    1  2018-08-20
#[Out]# 2     0.90    1  2018-08-21
#[Out]# 3     2.45    2  2018-08-16
#[Out]# 4     1.35    2  2018-08-17
#[Out]# ..     ...  ...         ...
#[Out]# 280   0.50  190  2018-08-23
#[Out]# 281   2.55  190  2018-08-24
#[Out]# 282   3.70  190  2018-08-25
#[Out]# 283   1.30  190  2018-08-26
#[Out]# 284   1.20  190  2018-08-27
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:23:37
query4_4 = '''

    SELECT cID, date, COUNT(*)
    FROM purchase
    HAVING COUNT(*) > 1
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:23:50
query4_4 = '''

    SELECT cID, date, COUNT(*)
    FROM purchase
    GROUP BY cID, date
    HAVING COUNT(*) > 1
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  COUNT(*)
#[Out]# 0      1  2018-08-20         5
#[Out]# 1      1  2018-08-21         2
#[Out]# 2      2  2018-08-17         4
#[Out]# 3      3  2018-08-19         2
#[Out]# 4      4  2018-08-24         3
#[Out]# ..   ...         ...       ...
#[Out]# 115  190  2018-08-23         6
#[Out]# 116  190  2018-08-24         2
#[Out]# 117  190  2018-08-25         3
#[Out]# 118  190  2018-08-26         7
#[Out]# 119  190  2018-08-27         2
#[Out]# 
#[Out]# [120 rows x 3 columns]
# Wed, 09 Dec 2020 12:24:23
query4_4 = '''

    SELECT cID, date, sum(price)
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sum(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:24:41
query4_4 = '''

    SELECT cID, date, max(sum(price))
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:25:55
query4_4 = '''

    SELECT cID, date, sum(price)
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  sum(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# ..   ...         ...         ...
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:26:08
query4_4 = '''

    SELECT cID, date, sum(price) as sum
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date    sum
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# ..   ...         ...    ...
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Wed, 09 Dec 2020 12:26:26
query4_4 = '''
SELECT max(sum)
FROM (SELECT cID, date, sum(price) as sum
    FROM purchase
    GROUP BY cID, date);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    max(sum)
#[Out]# 0      39.1
# Wed, 09 Dec 2020 12:28:57
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) as value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT customer.cName
FROM customer, purchase
WHERE cID IN (SELECT cID, date, sum(price) as sum
            FROM purchase
            GROUP BY cID, date
            HAVING sum > max_spent.value)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:29:18
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT customer.cName
FROM customer, purchase
WHERE cID IN (SELECT cID, date, sum(price) as sum
            FROM purchase
            GROUP BY cID, date
            HAVING sum > max_spent.value)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:29:35
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT customer.cName
FROM customer
WHERE cID IN (SELECT cID, date, sum(price) as sum
            FROM purchase
            GROUP BY cID, date
            HAVING sum > max_spent.value)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:29:41
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT customer.cName
FROM customer
WHERE cID IN (SELECT cID, date, sum(price) as sum
            FROM purchase
            GROUP BY cID, date
            HAVING sum > max_spent)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:30:07
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT customer.cName
FROM customer
WHERE cID IN (WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
            FROM purchase
            GROUP BY cID, date
            HAVING sum > max_spent)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:30:08
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT customer.cName
FROM customer
WHERE cID IN (WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
            FROM purchase
            GROUP BY cID, date
            HAVING sum > max_spent)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:30:11
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT customer.cName
FROM customer
WHERE cID IN (WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
            FROM purchase
            GROUP BY cID, date
            HAVING sum > max_spent.value)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:30:55
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
FROM purchase
GROUP BY cID, date
HAVING sum > max_spent
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:31:00
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
FROM purchase
GROUP BY cID, date
HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:32:04
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date)),
SELECT cID, date, sum(price) as sum
FROM purchase
GROUP BY cID, date
HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:32:29
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date)),
    SELECT cID, date, sum(price) as sum
    FROM purchase
    GROUP BY cID, date
    HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:32:46
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date)),
    SELECT cID, date, sum(price)
    FROM purchase
    GROUP BY cID, date
    HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:33:14
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
    SELECT cID, date, sum(price)
    FROM purchase
    GROUP BY cID, date
    HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:33:33
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum)
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
    SELECT cID, date, sum(price) as sum
    FROM purchase
    GROUP BY cID, date
    HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:35:02
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) AS value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
    SELECT cID, date, sum(price) as sum
    FROM purchase
    GROUP BY cID, date
    HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:38:55
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) AS value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date)),
    SELECT cID, date, sum(price) as sum
    FROM purchase
    GROUP BY cID, date
    HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:39:00
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) AS value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
FROM purchase
GROUP BY cID, date
HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:39:27
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) AS value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
FROM purchase, max_spent
GROUP BY cID, date
HAVING sum > max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date, sum]
#[Out]# Index: []
# Wed, 09 Dec 2020 12:39:37
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) AS value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
FROM purchase, max_spent
GROUP BY cID, date
HAVING sum > 0.75 * max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date   sum
#[Out]# 0  161  2018-08-26  39.1
# Wed, 09 Dec 2020 12:40:16
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) AS value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
FROM purchase, max_spent
GROUP BY cID, date
HAVING sum > 0.50 * max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date    sum
#[Out]# 0   24  2018-08-20  20.70
#[Out]# 1   71  2018-08-24  22.25
#[Out]# 2   82  2018-08-23  21.30
#[Out]# 3  108  2018-08-15  23.95
#[Out]# 4  123  2018-08-17  20.20
#[Out]# 5  124  2018-08-26  28.80
#[Out]# 6  161  2018-08-26  39.10
#[Out]# 7  190  2018-08-15  19.60
#[Out]# 8  190  2018-08-19  20.30
#[Out]# 9  190  2018-08-26  21.90
# Wed, 09 Dec 2020 12:40:22
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) AS value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cID, date, sum(price) as sum
FROM purchase, max_spent
GROUP BY cID, date
HAVING sum > 0.75 * max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date   sum
#[Out]# 0  161  2018-08-26  39.1
# Wed, 09 Dec 2020 12:41:07
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) AS value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cName
FROM customer
WHERE cID IN (SELECT cID, date, sum(price) as sum
            FROM purchase, max_spent
            GROUP BY cID, date
            HAVING sum > 0.75 * max_spent.value);
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:42:20
query4_4 = '''
WITH max_spent(value) AS (
    SELECT max(sum) AS value
    FROM (SELECT cID, date, sum(price) as sum
        FROM purchase
        GROUP BY cID, date))
SELECT cName
FROM purchase, max_spent, customer
WHERE purchase.cID = customer.cID
GROUP BY purchase.cID, date
HAVING sum(price) > 0.75 * max_spent.value;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Wed, 09 Dec 2020 12:44:31
query4_3 = '''
SELECT DISTINCT x.sName, x.city
FROM store AS x
WHERE NOT EXISTS (
    SELECT *
    FROM (SELECT city FROM store UNION SELECT city FROM customer) AS y
    WHERE NOT EXISTS (
        SELECT *
        FROM store AS z
        WHERE (z.sName=x.sName)
        AND (z.city=y.city)));
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []

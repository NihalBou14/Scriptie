# IPython log file

# Fri, 04 Dec 2020 09:11:11
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Fri, 04 Dec 2020 09:11:24
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x2cc8af13dc0>
# Fri, 04 Dec 2020 09:18:16
query4_3 = '''
    SELECT sName, city
    FROM store
    WHERE city IN ( SELECT city
                    FROM store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Fri, 04 Dec 2020 09:24:43
query4_3 = '''
    SELECT sName, city
    FROM store
    WHERE city IN ( SELECT city
                    FROM customer
                    UNION
                    SELECT city
                    FROM store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Fri, 04 Dec 2020 11:20:10
query4_3 = '''
    SELECT city
    FROM (SELECT city
          FROM customer
          UNION
          SELECT city
          FROM store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Fri, 04 Dec 2020 11:28:12
query4_3 = '''
    SELECT sName
    FROM store
    EXCEPT
    SELECT sName
    FROM ( SELECT sName, u.city
           FROM store, (SELECT city
                        FROM customer
                        UNION
                        SELECT city
                        FROM store) u
           EXCEPT
           SELECT sName, city
           FROM store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Fri, 04 Dec 2020 11:33:04
query4_3 = '''
    SELECT sName, u.city
    FROM store, (SELECT city
                 FROM customer
                 UNION
                 SELECT city
                 FROM store) u
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName       city
#[Out]# 0         Coop  Amsterdam
#[Out]# 1         Coop      Breda
#[Out]# 2         Coop  Eindhoven
#[Out]# 3         Coop        Oss
#[Out]# 4         Coop  Rotterdam
#[Out]# 5         Coop    Tilburg
#[Out]# 6         Coop    Utrecht
#[Out]# 7    Hoogvliet  Amsterdam
#[Out]# 8    Hoogvliet      Breda
#[Out]# 9    Hoogvliet  Eindhoven
#[Out]# 10   Hoogvliet        Oss
#[Out]# 11   Hoogvliet  Rotterdam
#[Out]# 12   Hoogvliet    Tilburg
#[Out]# 13   Hoogvliet    Utrecht
#[Out]# 14       Jumbo  Amsterdam
#[Out]# 15       Jumbo      Breda
#[Out]# 16       Jumbo  Eindhoven
#[Out]# 17       Jumbo        Oss
#[Out]# 18       Jumbo  Rotterdam
#[Out]# 19       Jumbo    Tilburg
#[Out]# 20       Jumbo    Utrecht
#[Out]# 21      Sligro  Amsterdam
#[Out]# 22      Sligro      Breda
#[Out]# 23      Sligro  Eindhoven
#[Out]# 24      Sligro        Oss
#[Out]# 25      Sligro  Rotterdam
#[Out]# 26      Sligro    Tilburg
#[Out]# 27      Sligro    Utrecht
#[Out]# 28   Hoogvliet  Amsterdam
#[Out]# 29   Hoogvliet      Breda
#[Out]# ..         ...        ...
#[Out]# 418      Jumbo    Tilburg
#[Out]# 419      Jumbo    Utrecht
#[Out]# 420       Lidl  Amsterdam
#[Out]# 421       Lidl      Breda
#[Out]# 422       Lidl  Eindhoven
#[Out]# 423       Lidl        Oss
#[Out]# 424       Lidl  Rotterdam
#[Out]# 425       Lidl    Tilburg
#[Out]# 426       Lidl    Utrecht
#[Out]# 427       Lidl  Amsterdam
#[Out]# 428       Lidl      Breda
#[Out]# 429       Lidl  Eindhoven
#[Out]# 430       Lidl        Oss
#[Out]# 431       Lidl  Rotterdam
#[Out]# 432       Lidl    Tilburg
#[Out]# 433       Lidl    Utrecht
#[Out]# 434      Jumbo  Amsterdam
#[Out]# 435      Jumbo      Breda
#[Out]# 436      Jumbo  Eindhoven
#[Out]# 437      Jumbo        Oss
#[Out]# 438      Jumbo  Rotterdam
#[Out]# 439      Jumbo    Tilburg
#[Out]# 440      Jumbo    Utrecht
#[Out]# 441      Jumbo  Amsterdam
#[Out]# 442      Jumbo      Breda
#[Out]# 443      Jumbo  Eindhoven
#[Out]# 444      Jumbo        Oss
#[Out]# 445      Jumbo  Rotterdam
#[Out]# 446      Jumbo    Tilburg
#[Out]# 447      Jumbo    Utrecht
#[Out]# 
#[Out]# [448 rows x 2 columns]
# Fri, 04 Dec 2020 11:34:49
query4_3 = '''
    SELECT sName, u.city
    FROM store, (SELECT city
                 FROM customer
                 UNION
                 SELECT city
                 FROM store) u
    EXCEPT
    SELECT sName, city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Fri, 04 Dec 2020 11:35:50
query4_3 = '''
    SELECT sName, city
    FROM store
    EXCEPT
    SELECT sName, u.city
    FROM store, (SELECT city
                 FROM customer
                 UNION
                 SELECT city
                 FROM store) u
    EXCEPT
    SELECT sName, city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Fri, 04 Dec 2020 11:36:04
query4_3 = '''
    SELECT sName, city
    FROM store
    EXCEPT
    (SELECT sName, u.city
    FROM store, (SELECT city
                 FROM customer
                 UNION
                 SELECT city
                 FROM store) u
    EXCEPT
    SELECT sName, city
    FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Fri, 04 Dec 2020 11:36:13
query4_3 = '''
    SELECT sName, city
    FROM store
    EXCEPT
    SELECT sName, u.city
    FROM store, (SELECT city
                 FROM customer
                 UNION
                 SELECT city
                 FROM store) u
    EXCEPT
    SELECT sName, city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Fri, 04 Dec 2020 11:36:21
query4_3 = '''
    SELECT sName, u.city
    FROM store, (SELECT city
                 FROM customer
                 UNION
                 SELECT city
                 FROM store) u
    EXCEPT
    SELECT sName, city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Fri, 04 Dec 2020 11:37:02
query4_3 = '''
    SELECT sName, city
    FROM store
    EXCEPT
    SELECT sName, u.city
    FROM store, (SELECT city
                 FROM customer
                 UNION
                 SELECT city
                 FROM store) u
    EXCEPT
    SELECT sName, city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName, city]
#[Out]# Index: []
# Fri, 04 Dec 2020 11:37:08
query4_3 = '''
    SELECT sName, city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10        Jumbo  Rotterdam
#[Out]# 11  Albert Hein  Rotterdam
#[Out]# 12         Lidl  Eindhoven
#[Out]# 13         Coop    Tilburg
#[Out]# 14         Coop  Amsterdam
#[Out]# 15         Lidl  Amsterdam
#[Out]# 16         Lidl    Utrecht
#[Out]# 17    Hoogvliet  Eindhoven
#[Out]# 18       Sligro    Tilburg
#[Out]# 19         Coop      Breda
#[Out]# 20        Jumbo    Tilburg
#[Out]# 21         Coop    Tilburg
#[Out]# 22         Lidl  Amsterdam
#[Out]# 23         Dirk      Breda
#[Out]# 24  Albert Hein      Breda
#[Out]# 25  Albert Hein      Breda
#[Out]# 26    Hoogvliet      Breda
#[Out]# 27       Sligro  Amsterdam
#[Out]# 28    Hoogvliet    Tilburg
#[Out]# 29       Sligro  Amsterdam
#[Out]# ..          ...        ...
#[Out]# 34         Coop  Amsterdam
#[Out]# 35         Lidl    Utrecht
#[Out]# 36         Lidl  Eindhoven
#[Out]# 37        Jumbo  Eindhoven
#[Out]# 38    Hoogvliet  Rotterdam
#[Out]# 39       Sligro  Eindhoven
#[Out]# 40    Hoogvliet  Rotterdam
#[Out]# 41  Albert Hein  Rotterdam
#[Out]# 42       Sligro  Amsterdam
#[Out]# 43         Coop    Utrecht
#[Out]# 44  Albert Hein    Utrecht
#[Out]# 45         Coop    Tilburg
#[Out]# 46         Lidl  Rotterdam
#[Out]# 47         Coop  Rotterdam
#[Out]# 48    Hoogvliet    Tilburg
#[Out]# 49    Hoogvliet  Rotterdam
#[Out]# 50       Sligro      Breda
#[Out]# 51         Coop    Utrecht
#[Out]# 52         Lidl  Eindhoven
#[Out]# 53         Coop    Utrecht
#[Out]# 54         Dirk  Eindhoven
#[Out]# 55         Coop      Breda
#[Out]# 56        Jumbo  Eindhoven
#[Out]# 57         Dirk  Eindhoven
#[Out]# 58         Dirk  Rotterdam
#[Out]# 59        Jumbo      Breda
#[Out]# 60         Lidl      Breda
#[Out]# 61         Lidl      Breda
#[Out]# 62        Jumbo  Eindhoven
#[Out]# 63        Jumbo        Oss
#[Out]# 
#[Out]# [64 rows x 2 columns]
# Fri, 04 Dec 2020 11:38:58
query4_3 = '''
    SELECT sName, u.city
       FROM store, (SELECT city
                    FROM customer
                    UNION
                    SELECT city
                    FROM store) u
       EXCEPT
       SELECT sName, city
       FROM store)
'''

pd.read_sql_query(query4_3, conn)
# Fri, 04 Dec 2020 11:39:02
query4_3 = '''
    SELECT sName, u.city
       FROM store, (SELECT city
                    FROM customer
                    UNION
                    SELECT city
                    FROM store) u
       EXCEPT
       SELECT sName, city
       FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Fri, 04 Dec 2020 11:39:18
query4_3 = '''
    SELECT sName, u.city
    FROM store, (SELECT city
                 FROM customer
                 UNION
                 SELECT city
                 FROM store) u
    EXCEPT
    SELECT sName, city
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName       city
#[Out]# 0   Albert Hein  Amsterdam
#[Out]# 1   Albert Hein        Oss
#[Out]# 2          Coop  Eindhoven
#[Out]# 3          Coop        Oss
#[Out]# 4          Dirk  Amsterdam
#[Out]# 5          Dirk        Oss
#[Out]# 6          Dirk    Tilburg
#[Out]# 7          Dirk    Utrecht
#[Out]# 8     Hoogvliet  Amsterdam
#[Out]# 9     Hoogvliet        Oss
#[Out]# 10    Hoogvliet    Utrecht
#[Out]# 11        Jumbo  Amsterdam
#[Out]# 12        Jumbo    Utrecht
#[Out]# 13         Lidl        Oss
#[Out]# 14         Lidl    Tilburg
#[Out]# 15       Sligro        Oss
#[Out]# 16       Sligro    Utrecht
# Fri, 04 Dec 2020 11:39:38
query4_3 = '''
    SELECT sName
    FROM (
    SELECT sName, u.city
    FROM store, (SELECT city
                 FROM customer
                 UNION
                 SELECT city
                 FROM store) u
    EXCEPT
    SELECT sName, city
    FROM store
    )
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0   Albert Hein
#[Out]# 1   Albert Hein
#[Out]# 2          Coop
#[Out]# 3          Coop
#[Out]# 4          Dirk
#[Out]# 5          Dirk
#[Out]# 6          Dirk
#[Out]# 7          Dirk
#[Out]# 8     Hoogvliet
#[Out]# 9     Hoogvliet
#[Out]# 10    Hoogvliet
#[Out]# 11        Jumbo
#[Out]# 12        Jumbo
#[Out]# 13         Lidl
#[Out]# 14         Lidl
#[Out]# 15       Sligro
#[Out]# 16       Sligro
# Fri, 04 Dec 2020 11:40:43
query4_3 = '''
    SELECT sName
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0          Coop
#[Out]# 1     Hoogvliet
#[Out]# 2         Jumbo
#[Out]# 3        Sligro
#[Out]# 4     Hoogvliet
#[Out]# 5        Sligro
#[Out]# 6          Coop
#[Out]# 7        Sligro
#[Out]# 8   Albert Hein
#[Out]# 9   Albert Hein
#[Out]# 10        Jumbo
#[Out]# 11  Albert Hein
#[Out]# 12         Lidl
#[Out]# 13         Coop
#[Out]# 14         Coop
#[Out]# 15         Lidl
#[Out]# 16         Lidl
#[Out]# 17    Hoogvliet
#[Out]# 18       Sligro
#[Out]# 19         Coop
#[Out]# 20        Jumbo
#[Out]# 21         Coop
#[Out]# 22         Lidl
#[Out]# 23         Dirk
#[Out]# 24  Albert Hein
#[Out]# 25  Albert Hein
#[Out]# 26    Hoogvliet
#[Out]# 27       Sligro
#[Out]# 28    Hoogvliet
#[Out]# 29       Sligro
#[Out]# ..          ...
#[Out]# 34         Coop
#[Out]# 35         Lidl
#[Out]# 36         Lidl
#[Out]# 37        Jumbo
#[Out]# 38    Hoogvliet
#[Out]# 39       Sligro
#[Out]# 40    Hoogvliet
#[Out]# 41  Albert Hein
#[Out]# 42       Sligro
#[Out]# 43         Coop
#[Out]# 44  Albert Hein
#[Out]# 45         Coop
#[Out]# 46         Lidl
#[Out]# 47         Coop
#[Out]# 48    Hoogvliet
#[Out]# 49    Hoogvliet
#[Out]# 50       Sligro
#[Out]# 51         Coop
#[Out]# 52         Lidl
#[Out]# 53         Coop
#[Out]# 54         Dirk
#[Out]# 55         Coop
#[Out]# 56        Jumbo
#[Out]# 57         Dirk
#[Out]# 58         Dirk
#[Out]# 59        Jumbo
#[Out]# 60         Lidl
#[Out]# 61         Lidl
#[Out]# 62        Jumbo
#[Out]# 63        Jumbo
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Fri, 04 Dec 2020 11:40:49
query4_3 = '''
    SELECT DISTINCT sName
    FROM store
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0         Coop
#[Out]# 1    Hoogvliet
#[Out]# 2        Jumbo
#[Out]# 3       Sligro
#[Out]# 4  Albert Hein
#[Out]# 5         Lidl
#[Out]# 6         Dirk
# Fri, 04 Dec 2020 11:41:09
query4_3 = '''
    SELECT sName
    FROM store
    SORT BY sName
'''

pd.read_sql_query(query4_3, conn)
# Fri, 04 Dec 2020 11:41:18
query4_3 = '''
    SELECT sName
    FROM store
    SORTBY sName
'''

pd.read_sql_query(query4_3, conn)
# Fri, 04 Dec 2020 11:41:23
query4_3 = '''
    SELECT sName
    FROM store
    SORT sName
'''

pd.read_sql_query(query4_3, conn)
# Fri, 04 Dec 2020 11:42:06
query4_3 = '''
    SELECT sName
    FROM store
    SORT ON sName
'''

pd.read_sql_query(query4_3, conn)
# Fri, 04 Dec 2020 11:42:52
query4_3 = '''
    SELECT sName
    FROM store
    ORDER BY sName
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName
#[Out]# 0   Albert Hein
#[Out]# 1   Albert Hein
#[Out]# 2   Albert Hein
#[Out]# 3   Albert Hein
#[Out]# 4   Albert Hein
#[Out]# 5   Albert Hein
#[Out]# 6   Albert Hein
#[Out]# 7   Albert Hein
#[Out]# 8          Coop
#[Out]# 9          Coop
#[Out]# 10         Coop
#[Out]# 11         Coop
#[Out]# 12         Coop
#[Out]# 13         Coop
#[Out]# 14         Coop
#[Out]# 15         Coop
#[Out]# 16         Coop
#[Out]# 17         Coop
#[Out]# 18         Coop
#[Out]# 19         Coop
#[Out]# 20         Coop
#[Out]# 21         Coop
#[Out]# 22         Dirk
#[Out]# 23         Dirk
#[Out]# 24         Dirk
#[Out]# 25         Dirk
#[Out]# 26         Dirk
#[Out]# 27         Dirk
#[Out]# 28    Hoogvliet
#[Out]# 29    Hoogvliet
#[Out]# ..          ...
#[Out]# 34    Hoogvliet
#[Out]# 35    Hoogvliet
#[Out]# 36    Hoogvliet
#[Out]# 37        Jumbo
#[Out]# 38        Jumbo
#[Out]# 39        Jumbo
#[Out]# 40        Jumbo
#[Out]# 41        Jumbo
#[Out]# 42        Jumbo
#[Out]# 43        Jumbo
#[Out]# 44        Jumbo
#[Out]# 45         Lidl
#[Out]# 46         Lidl
#[Out]# 47         Lidl
#[Out]# 48         Lidl
#[Out]# 49         Lidl
#[Out]# 50         Lidl
#[Out]# 51         Lidl
#[Out]# 52         Lidl
#[Out]# 53         Lidl
#[Out]# 54         Lidl
#[Out]# 55       Sligro
#[Out]# 56       Sligro
#[Out]# 57       Sligro
#[Out]# 58       Sligro
#[Out]# 59       Sligro
#[Out]# 60       Sligro
#[Out]# 61       Sligro
#[Out]# 62       Sligro
#[Out]# 63       Sligro
#[Out]# 
#[Out]# [64 rows x 1 columns]
# Fri, 04 Dec 2020 11:42:57
query4_3 = '''
    SELECT DISTINCT sName
    FROM store
    ORDER BY sName
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro
# Fri, 04 Dec 2020 11:43:33
query4_3 = '''
    SELECT sName
    FROM store
    EXCEPT
    SELECT sName
    FROM ( SELECT sName, u.city
           FROM store, (SELECT city
                        FROM customer
                        UNION
                        SELECT city
                        FROM store) u
           EXCEPT
           SELECT sName, city
           FROM store)
'''

pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Fri, 04 Dec 2020 11:56:26
query4_4 = '''
    SELECT SUM(price)
    FROM purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    SUM(price)
#[Out]# 0      1675.2
# Fri, 04 Dec 2020 11:56:34
query4_4 = '''
    SELECT *
    FROM purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15
#[Out]# 17    17    4   10   27  2018-08-24         9   9.05
#[Out]# 18    18    4   53   12  2018-08-25         5  13.60
#[Out]# 19    19    4   21    6  2018-08-24         2   1.05
#[Out]# 20    20    4    7   13  2018-08-25         9   3.05
#[Out]# 21    21    4   44   26  2018-08-25         4   2.75
#[Out]# 22    22    5    4   14  2018-08-17         6   4.70
#[Out]# 23    23    5   36   28  2018-08-22         6   8.25
#[Out]# 24    24    5   55    6  2018-08-23         9   1.10
#[Out]# 25    25    5   51   22  2018-08-23         2   1.55
#[Out]# 26    26    5    6   16  2018-08-23         2   1.85
#[Out]# 27    27    5   17   19  2018-08-23         1   2.20
#[Out]# 28    28    7    3   19  2018-08-23         2   2.10
#[Out]# 29    29    7   12    2  2018-08-23         6   1.70
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...
#[Out]# 479  818  190   34   28  2018-08-20         4   2.80
#[Out]# 480  819  190   35   27  2018-08-15         5   0.50
#[Out]# 481  820  190   36    5  2018-08-23         3   2.55
#[Out]# 482  821  190   37   28  2018-08-15         4   0.65
#[Out]# 483  822  190   38    7  2018-08-24         4   0.70
#[Out]# 484  823  190   39    0  2018-08-25         4   3.70
#[Out]# 485  824  190   40   11  2018-08-15         2   3.50
#[Out]# 486  825  190   41    6  2018-08-15         5   2.95
#[Out]# 487  826  190   42   19  2018-08-22         5   2.75
#[Out]# 488  827  190   43   17  2018-08-17         7   1.50
#[Out]# 489  828  190   44    9  2018-08-18         5   0.85
#[Out]# 490  829  190   45   11  2018-08-19         2   3.55
#[Out]# 491  830  190   46   22  2018-08-25         4   2.60
#[Out]# 492  831  190   47   17  2018-08-17         4   3.25
#[Out]# 493  832  190   48   20  2018-08-26         6   4.30
#[Out]# 494  833  190   49   11  2018-08-17         3   3.05
#[Out]# 495  834  190   50   21  2018-08-22         6   4.05
#[Out]# 496  835  190   51   23  2018-08-19         1   1.50
#[Out]# 497  836  190   52   23  2018-08-15         5   2.50
#[Out]# 498  837  190   53    8  2018-08-18         4   3.95
#[Out]# 499  838  190   54    0  2018-08-25         6   3.50
#[Out]# 500  839  190   55    8  2018-08-18         7   2.95
#[Out]# 501  840  190   56   11  2018-08-15         4   1.60
#[Out]# 502  841  190   57   15  2018-08-22         5   3.25
#[Out]# 503  842  190   58    2  2018-08-19         7   0.75
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30
#[Out]# 
#[Out]# [509 rows x 7 columns]
# Fri, 04 Dec 2020 11:57:48
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  SUM(price)
#[Out]# 0    0  2018-08-22      1675.2
# Fri, 04 Dec 2020 11:57:58
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  SUM(price)
#[Out]# 0      0  2018-08-22        0.45
#[Out]# 1      1  2018-08-20       14.20
#[Out]# 2      1  2018-08-21       10.00
#[Out]# 3      2  2018-08-16        2.45
#[Out]# 4      2  2018-08-17        7.70
#[Out]# 5      3  2018-08-18        4.30
#[Out]# 6      3  2018-08-19        4.20
#[Out]# 7      4  2018-08-24       14.25
#[Out]# 8      4  2018-08-25       19.40
#[Out]# 9      5  2018-08-17        4.70
#[Out]# 10     5  2018-08-22        8.25
#[Out]# 11     5  2018-08-23        6.70
#[Out]# 12     7  2018-08-23        3.80
#[Out]# 13     7  2018-08-24        1.90
#[Out]# 14     7  2018-08-25       10.75
#[Out]# 15     7  2018-08-26        3.10
#[Out]# 16     8  2018-08-16        6.25
#[Out]# 17    10  2018-08-27        3.20
#[Out]# 18    11  2018-08-25        4.10
#[Out]# 19    13  2018-08-17       13.30
#[Out]# 20    13  2018-08-25        6.50
#[Out]# 21    13  2018-08-26        1.65
#[Out]# 22    13  2018-08-27        0.50
#[Out]# 23    15  2018-08-27        0.90
#[Out]# 24    16  2018-08-18        2.90
#[Out]# 25    16  2018-08-19       11.05
#[Out]# 26    16  2018-08-24        6.05
#[Out]# 27    16  2018-08-25        4.95
#[Out]# 28    16  2018-08-26        3.00
#[Out]# 29    16  2018-08-27        1.85
#[Out]# ..   ...         ...         ...
#[Out]# 255  178  2018-08-27        7.50
#[Out]# 256  179  2018-08-22       10.85
#[Out]# 257  179  2018-08-23        0.45
#[Out]# 258  179  2018-08-24        6.95
#[Out]# 259  180  2018-08-26        3.10
#[Out]# 260  180  2018-08-27        4.65
#[Out]# 261  181  2018-08-24        3.60
#[Out]# 262  181  2018-08-27        2.00
#[Out]# 263  182  2018-08-23        4.20
#[Out]# 264  182  2018-08-28       14.90
#[Out]# 265  184  2018-08-20        3.50
#[Out]# 266  185  2018-08-20        1.00
#[Out]# 267  186  2018-08-21        1.00
#[Out]# 268  188  2018-08-20        1.00
#[Out]# 269  188  2018-09-20        1.00
#[Out]# 270  189  2018-08-25        1.25
#[Out]# 271  189  2018-08-26        2.50
#[Out]# 272  190  2018-08-15       19.60
#[Out]# 273  190  2018-08-16       12.80
#[Out]# 274  190  2018-08-17       15.75
#[Out]# 275  190  2018-08-18       14.85
#[Out]# 276  190  2018-08-19       20.30
#[Out]# 277  190  2018-08-20       10.85
#[Out]# 278  190  2018-08-21        3.85
#[Out]# 279  190  2018-08-22       14.55
#[Out]# 280  190  2018-08-23       10.60
#[Out]# 281  190  2018-08-24        3.25
#[Out]# 282  190  2018-08-25        9.80
#[Out]# 283  190  2018-08-26       21.90
#[Out]# 284  190  2018-08-27        5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Fri, 04 Dec 2020 11:59:17
query4_4 = '''
    SELECT cID, date, SUM(price) price
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   4.20
#[Out]# 7      4  2018-08-24  14.25
#[Out]# 8      4  2018-08-25  19.40
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   6.70
#[Out]# 12     7  2018-08-23   3.80
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   3.10
#[Out]# 16     8  2018-08-16   6.25
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17  13.30
#[Out]# 20    13  2018-08-25   6.50
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19  11.05
#[Out]# 26    16  2018-08-24   6.05
#[Out]# 27    16  2018-08-25   4.95
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   7.50
#[Out]# 256  179  2018-08-22  10.85
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   6.95
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.65
#[Out]# 261  181  2018-08-24   3.60
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28  14.90
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15  19.60
#[Out]# 273  190  2018-08-16  12.80
#[Out]# 274  190  2018-08-17  15.75
#[Out]# 275  190  2018-08-18  14.85
#[Out]# 276  190  2018-08-19  20.30
#[Out]# 277  190  2018-08-20  10.85
#[Out]# 278  190  2018-08-21   3.85
#[Out]# 279  190  2018-08-22  14.55
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Fri, 04 Dec 2020 12:00:08
query4_4 = '''
    SELECT MAX(price)
    FROM ( SELECT cID, date, SUM(price) price
           FROM purchase
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(price)
#[Out]# 0        39.1
# Fri, 04 Dec 2020 12:00:26
query4_4 = '''
    SELECT cID, date, SUM(price) price
    FROM purchase
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price
#[Out]# 0      0  2018-08-22   0.45
#[Out]# 1      1  2018-08-20  14.20
#[Out]# 2      1  2018-08-21  10.00
#[Out]# 3      2  2018-08-16   2.45
#[Out]# 4      2  2018-08-17   7.70
#[Out]# 5      3  2018-08-18   4.30
#[Out]# 6      3  2018-08-19   4.20
#[Out]# 7      4  2018-08-24  14.25
#[Out]# 8      4  2018-08-25  19.40
#[Out]# 9      5  2018-08-17   4.70
#[Out]# 10     5  2018-08-22   8.25
#[Out]# 11     5  2018-08-23   6.70
#[Out]# 12     7  2018-08-23   3.80
#[Out]# 13     7  2018-08-24   1.90
#[Out]# 14     7  2018-08-25  10.75
#[Out]# 15     7  2018-08-26   3.10
#[Out]# 16     8  2018-08-16   6.25
#[Out]# 17    10  2018-08-27   3.20
#[Out]# 18    11  2018-08-25   4.10
#[Out]# 19    13  2018-08-17  13.30
#[Out]# 20    13  2018-08-25   6.50
#[Out]# 21    13  2018-08-26   1.65
#[Out]# 22    13  2018-08-27   0.50
#[Out]# 23    15  2018-08-27   0.90
#[Out]# 24    16  2018-08-18   2.90
#[Out]# 25    16  2018-08-19  11.05
#[Out]# 26    16  2018-08-24   6.05
#[Out]# 27    16  2018-08-25   4.95
#[Out]# 28    16  2018-08-26   3.00
#[Out]# 29    16  2018-08-27   1.85
#[Out]# ..   ...         ...    ...
#[Out]# 255  178  2018-08-27   7.50
#[Out]# 256  179  2018-08-22  10.85
#[Out]# 257  179  2018-08-23   0.45
#[Out]# 258  179  2018-08-24   6.95
#[Out]# 259  180  2018-08-26   3.10
#[Out]# 260  180  2018-08-27   4.65
#[Out]# 261  181  2018-08-24   3.60
#[Out]# 262  181  2018-08-27   2.00
#[Out]# 263  182  2018-08-23   4.20
#[Out]# 264  182  2018-08-28  14.90
#[Out]# 265  184  2018-08-20   3.50
#[Out]# 266  185  2018-08-20   1.00
#[Out]# 267  186  2018-08-21   1.00
#[Out]# 268  188  2018-08-20   1.00
#[Out]# 269  188  2018-09-20   1.00
#[Out]# 270  189  2018-08-25   1.25
#[Out]# 271  189  2018-08-26   2.50
#[Out]# 272  190  2018-08-15  19.60
#[Out]# 273  190  2018-08-16  12.80
#[Out]# 274  190  2018-08-17  15.75
#[Out]# 275  190  2018-08-18  14.85
#[Out]# 276  190  2018-08-19  20.30
#[Out]# 277  190  2018-08-20  10.85
#[Out]# 278  190  2018-08-21   3.85
#[Out]# 279  190  2018-08-22  14.55
#[Out]# 280  190  2018-08-23  10.60
#[Out]# 281  190  2018-08-24   3.25
#[Out]# 282  190  2018-08-25   9.80
#[Out]# 283  190  2018-08-26  21.90
#[Out]# 284  190  2018-08-27   5.55
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Fri, 04 Dec 2020 12:00:40
query4_4 = '''
    SELECT MAX(price)
    FROM ( SELECT cID, date, SUM(price) price
           FROM purchase
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(price)
#[Out]# 0        39.1
# Fri, 04 Dec 2020 12:00:54
query4_4 = '''
    SELECT MAX(sum) max
    FROM ( SELECT cID, date, SUM(price) sum
           FROM purchase
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     max
#[Out]# 0  39.1
# Fri, 04 Dec 2020 12:01:25
query4_4 = '''
    SELECT MAX(sum) max
    FROM ( SELECT cID, date, SUM(price) sum
           FROM purchase
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     max
#[Out]# 0  39.1
# Fri, 04 Dec 2020 12:03:35
query4_4 = '''
    SELECT cID
    FROM purchase
    
    SELECT MAX(sum) max, sum
    FROM ( SELECT cID, date, SUM(price) sum
           FROM purchase
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
# Fri, 04 Dec 2020 12:03:42
query4_4 = '''
    SELECT MAX(sum) max, sum
    FROM ( SELECT cID, date, SUM(price) sum
           FROM purchase
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     max   sum
#[Out]# 0  39.1  39.1
# Fri, 04 Dec 2020 12:03:50
query4_4 = '''
    SELECT MAX(sum) max, cID
    FROM ( SELECT cID, date, SUM(price) sum
           FROM purchase
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     max  cID
#[Out]# 0  39.1  161
# Fri, 04 Dec 2020 12:03:59
query4_4 = '''
    SELECT MAX(sum) max
    FROM ( SELECT cID, date, SUM(price) sum
           FROM purchase
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     max
#[Out]# 0  39.1
# Fri, 04 Dec 2020 12:06:18
query4_4 = '''
    SELECT cID, date, SUM(price), max
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date)
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
# Fri, 04 Dec 2020 12:06:30
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date)
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
# Fri, 04 Dec 2020 12:06:54
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date)
    GROUP BY cID, date, max
'''

pd.read_sql_query(query4_4, conn)
# Fri, 04 Dec 2020 12:06:59
query4_4 = '''
    SELECT cID, date, SUM(price)
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
# Fri, 04 Dec 2020 12:07:21
query4_4 = '''
    SELECT *
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date) )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      tID  cID  sID  pID        date  quantity  price   max
#[Out]# 0      0    0    3   10  2018-08-22         1   0.45  39.1
#[Out]# 1      1    1   23   14  2018-08-20         2   4.65  39.1
#[Out]# 2      2    1    3   16  2018-08-20         3   1.60  39.1
#[Out]# 3      3    1   17    9  2018-08-20         2   1.25  39.1
#[Out]# 4      4    1   32   25  2018-08-20         4   3.95  39.1
#[Out]# 5      5    1   16   26  2018-08-20         4   2.75  39.1
#[Out]# 6      6    1   46   11  2018-08-21         8   0.90  39.1
#[Out]# 7      7    1   36   27  2018-08-21         6   9.10  39.1
#[Out]# 8      8    2   12   20  2018-08-16         1   2.45  39.1
#[Out]# 9      9    2   39    9  2018-08-17         7   1.35  39.1
#[Out]# 10    10    2   13    4  2018-08-17         6   1.10  39.1
#[Out]# 11    11    2   51   13  2018-08-17         4   3.70  39.1
#[Out]# 12    12    2   47   22  2018-08-17         1   1.55  39.1
#[Out]# 13    13    3   44   14  2018-08-18         2   4.30  39.1
#[Out]# 14    14    3   30   26  2018-08-19         2   2.75  39.1
#[Out]# 15    15    3   29    9  2018-08-19         6   1.45  39.1
#[Out]# 16    16    4   17    8  2018-08-24         2   4.15  39.1
#[Out]# 17    17    4   10   27  2018-08-24         9   9.05  39.1
#[Out]# 18    18    4   53   12  2018-08-25         5  13.60  39.1
#[Out]# 19    19    4   21    6  2018-08-24         2   1.05  39.1
#[Out]# 20    20    4    7   13  2018-08-25         9   3.05  39.1
#[Out]# 21    21    4   44   26  2018-08-25         4   2.75  39.1
#[Out]# 22    22    5    4   14  2018-08-17         6   4.70  39.1
#[Out]# 23    23    5   36   28  2018-08-22         6   8.25  39.1
#[Out]# 24    24    5   55    6  2018-08-23         9   1.10  39.1
#[Out]# 25    25    5   51   22  2018-08-23         2   1.55  39.1
#[Out]# 26    26    5    6   16  2018-08-23         2   1.85  39.1
#[Out]# 27    27    5   17   19  2018-08-23         1   2.20  39.1
#[Out]# 28    28    7    3   19  2018-08-23         2   2.10  39.1
#[Out]# 29    29    7   12    2  2018-08-23         6   1.70  39.1
#[Out]# ..   ...  ...  ...  ...         ...       ...    ...   ...
#[Out]# 479  818  190   34   28  2018-08-20         4   2.80  39.1
#[Out]# 480  819  190   35   27  2018-08-15         5   0.50  39.1
#[Out]# 481  820  190   36    5  2018-08-23         3   2.55  39.1
#[Out]# 482  821  190   37   28  2018-08-15         4   0.65  39.1
#[Out]# 483  822  190   38    7  2018-08-24         4   0.70  39.1
#[Out]# 484  823  190   39    0  2018-08-25         4   3.70  39.1
#[Out]# 485  824  190   40   11  2018-08-15         2   3.50  39.1
#[Out]# 486  825  190   41    6  2018-08-15         5   2.95  39.1
#[Out]# 487  826  190   42   19  2018-08-22         5   2.75  39.1
#[Out]# 488  827  190   43   17  2018-08-17         7   1.50  39.1
#[Out]# 489  828  190   44    9  2018-08-18         5   0.85  39.1
#[Out]# 490  829  190   45   11  2018-08-19         2   3.55  39.1
#[Out]# 491  830  190   46   22  2018-08-25         4   2.60  39.1
#[Out]# 492  831  190   47   17  2018-08-17         4   3.25  39.1
#[Out]# 493  832  190   48   20  2018-08-26         6   4.30  39.1
#[Out]# 494  833  190   49   11  2018-08-17         3   3.05  39.1
#[Out]# 495  834  190   50   21  2018-08-22         6   4.05  39.1
#[Out]# 496  835  190   51   23  2018-08-19         1   1.50  39.1
#[Out]# 497  836  190   52   23  2018-08-15         5   2.50  39.1
#[Out]# 498  837  190   53    8  2018-08-18         4   3.95  39.1
#[Out]# 499  838  190   54    0  2018-08-25         6   3.50  39.1
#[Out]# 500  839  190   55    8  2018-08-18         7   2.95  39.1
#[Out]# 501  840  190   56   11  2018-08-15         4   1.60  39.1
#[Out]# 502  841  190   57   15  2018-08-22         5   3.25  39.1
#[Out]# 503  842  190   58    2  2018-08-19         7   0.75  39.1
#[Out]# 504  843  190   59   17  2018-08-26         2   3.80  39.1
#[Out]# 505  844  190   60    5  2018-08-27         6   4.35  39.1
#[Out]# 506  845  190   61   19  2018-08-23         5   2.85  39.1
#[Out]# 507  846  190   62    9  2018-08-16         2   3.15  39.1
#[Out]# 508  847  190   63   18  2018-08-21         1   3.30  39.1
#[Out]# 
#[Out]# [509 rows x 8 columns]
# Fri, 04 Dec 2020 12:07:34
query4_4 = '''
    SELECT cID, date, price, max
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date) )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price   max
#[Out]# 0      0  2018-08-22   0.45  39.1
#[Out]# 1      1  2018-08-20   4.65  39.1
#[Out]# 2      1  2018-08-20   1.60  39.1
#[Out]# 3      1  2018-08-20   1.25  39.1
#[Out]# 4      1  2018-08-20   3.95  39.1
#[Out]# 5      1  2018-08-20   2.75  39.1
#[Out]# 6      1  2018-08-21   0.90  39.1
#[Out]# 7      1  2018-08-21   9.10  39.1
#[Out]# 8      2  2018-08-16   2.45  39.1
#[Out]# 9      2  2018-08-17   1.35  39.1
#[Out]# 10     2  2018-08-17   1.10  39.1
#[Out]# 11     2  2018-08-17   3.70  39.1
#[Out]# 12     2  2018-08-17   1.55  39.1
#[Out]# 13     3  2018-08-18   4.30  39.1
#[Out]# 14     3  2018-08-19   2.75  39.1
#[Out]# 15     3  2018-08-19   1.45  39.1
#[Out]# 16     4  2018-08-24   4.15  39.1
#[Out]# 17     4  2018-08-24   9.05  39.1
#[Out]# 18     4  2018-08-25  13.60  39.1
#[Out]# 19     4  2018-08-24   1.05  39.1
#[Out]# 20     4  2018-08-25   3.05  39.1
#[Out]# 21     4  2018-08-25   2.75  39.1
#[Out]# 22     5  2018-08-17   4.70  39.1
#[Out]# 23     5  2018-08-22   8.25  39.1
#[Out]# 24     5  2018-08-23   1.10  39.1
#[Out]# 25     5  2018-08-23   1.55  39.1
#[Out]# 26     5  2018-08-23   1.85  39.1
#[Out]# 27     5  2018-08-23   2.20  39.1
#[Out]# 28     7  2018-08-23   2.10  39.1
#[Out]# 29     7  2018-08-23   1.70  39.1
#[Out]# ..   ...         ...    ...   ...
#[Out]# 479  190  2018-08-20   2.80  39.1
#[Out]# 480  190  2018-08-15   0.50  39.1
#[Out]# 481  190  2018-08-23   2.55  39.1
#[Out]# 482  190  2018-08-15   0.65  39.1
#[Out]# 483  190  2018-08-24   0.70  39.1
#[Out]# 484  190  2018-08-25   3.70  39.1
#[Out]# 485  190  2018-08-15   3.50  39.1
#[Out]# 486  190  2018-08-15   2.95  39.1
#[Out]# 487  190  2018-08-22   2.75  39.1
#[Out]# 488  190  2018-08-17   1.50  39.1
#[Out]# 489  190  2018-08-18   0.85  39.1
#[Out]# 490  190  2018-08-19   3.55  39.1
#[Out]# 491  190  2018-08-25   2.60  39.1
#[Out]# 492  190  2018-08-17   3.25  39.1
#[Out]# 493  190  2018-08-26   4.30  39.1
#[Out]# 494  190  2018-08-17   3.05  39.1
#[Out]# 495  190  2018-08-22   4.05  39.1
#[Out]# 496  190  2018-08-19   1.50  39.1
#[Out]# 497  190  2018-08-15   2.50  39.1
#[Out]# 498  190  2018-08-18   3.95  39.1
#[Out]# 499  190  2018-08-25   3.50  39.1
#[Out]# 500  190  2018-08-18   2.95  39.1
#[Out]# 501  190  2018-08-15   1.60  39.1
#[Out]# 502  190  2018-08-22   3.25  39.1
#[Out]# 503  190  2018-08-19   0.75  39.1
#[Out]# 504  190  2018-08-26   3.80  39.1
#[Out]# 505  190  2018-08-27   4.35  39.1
#[Out]# 506  190  2018-08-23   2.85  39.1
#[Out]# 507  190  2018-08-16   3.15  39.1
#[Out]# 508  190  2018-08-21   3.30  39.1
#[Out]# 
#[Out]# [509 rows x 4 columns]
# Fri, 04 Dec 2020 12:07:48
query4_4 = '''
    SELECT cID, date, SUM(price) price, max
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date) )
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date   price   max
#[Out]# 0    0  2018-08-22  1675.2  39.1
# Fri, 04 Dec 2020 12:07:59
query4_4 = '''
    SELECT cID, date, SUM(price) price, max
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date) )
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price   max
#[Out]# 0      0  2018-08-22   0.45  39.1
#[Out]# 1      1  2018-08-20  14.20  39.1
#[Out]# 2      1  2018-08-21  10.00  39.1
#[Out]# 3      2  2018-08-16   2.45  39.1
#[Out]# 4      2  2018-08-17   7.70  39.1
#[Out]# 5      3  2018-08-18   4.30  39.1
#[Out]# 6      3  2018-08-19   4.20  39.1
#[Out]# 7      4  2018-08-24  14.25  39.1
#[Out]# 8      4  2018-08-25  19.40  39.1
#[Out]# 9      5  2018-08-17   4.70  39.1
#[Out]# 10     5  2018-08-22   8.25  39.1
#[Out]# 11     5  2018-08-23   6.70  39.1
#[Out]# 12     7  2018-08-23   3.80  39.1
#[Out]# 13     7  2018-08-24   1.90  39.1
#[Out]# 14     7  2018-08-25  10.75  39.1
#[Out]# 15     7  2018-08-26   3.10  39.1
#[Out]# 16     8  2018-08-16   6.25  39.1
#[Out]# 17    10  2018-08-27   3.20  39.1
#[Out]# 18    11  2018-08-25   4.10  39.1
#[Out]# 19    13  2018-08-17  13.30  39.1
#[Out]# 20    13  2018-08-25   6.50  39.1
#[Out]# 21    13  2018-08-26   1.65  39.1
#[Out]# 22    13  2018-08-27   0.50  39.1
#[Out]# 23    15  2018-08-27   0.90  39.1
#[Out]# 24    16  2018-08-18   2.90  39.1
#[Out]# 25    16  2018-08-19  11.05  39.1
#[Out]# 26    16  2018-08-24   6.05  39.1
#[Out]# 27    16  2018-08-25   4.95  39.1
#[Out]# 28    16  2018-08-26   3.00  39.1
#[Out]# 29    16  2018-08-27   1.85  39.1
#[Out]# ..   ...         ...    ...   ...
#[Out]# 255  178  2018-08-27   7.50  39.1
#[Out]# 256  179  2018-08-22  10.85  39.1
#[Out]# 257  179  2018-08-23   0.45  39.1
#[Out]# 258  179  2018-08-24   6.95  39.1
#[Out]# 259  180  2018-08-26   3.10  39.1
#[Out]# 260  180  2018-08-27   4.65  39.1
#[Out]# 261  181  2018-08-24   3.60  39.1
#[Out]# 262  181  2018-08-27   2.00  39.1
#[Out]# 263  182  2018-08-23   4.20  39.1
#[Out]# 264  182  2018-08-28  14.90  39.1
#[Out]# 265  184  2018-08-20   3.50  39.1
#[Out]# 266  185  2018-08-20   1.00  39.1
#[Out]# 267  186  2018-08-21   1.00  39.1
#[Out]# 268  188  2018-08-20   1.00  39.1
#[Out]# 269  188  2018-09-20   1.00  39.1
#[Out]# 270  189  2018-08-25   1.25  39.1
#[Out]# 271  189  2018-08-26   2.50  39.1
#[Out]# 272  190  2018-08-15  19.60  39.1
#[Out]# 273  190  2018-08-16  12.80  39.1
#[Out]# 274  190  2018-08-17  15.75  39.1
#[Out]# 275  190  2018-08-18  14.85  39.1
#[Out]# 276  190  2018-08-19  20.30  39.1
#[Out]# 277  190  2018-08-20  10.85  39.1
#[Out]# 278  190  2018-08-21   3.85  39.1
#[Out]# 279  190  2018-08-22  14.55  39.1
#[Out]# 280  190  2018-08-23  10.60  39.1
#[Out]# 281  190  2018-08-24   3.25  39.1
#[Out]# 282  190  2018-08-25   9.80  39.1
#[Out]# 283  190  2018-08-26  21.90  39.1
#[Out]# 284  190  2018-08-27   5.55  39.1
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Fri, 04 Dec 2020 12:08:54
query4_4 = '''
    SELECT cID, SUM(price) price, max
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date) )
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID  price   max
#[Out]# 0      0   0.45  39.1
#[Out]# 1      1  14.20  39.1
#[Out]# 2      1  10.00  39.1
#[Out]# 3      2   2.45  39.1
#[Out]# 4      2   7.70  39.1
#[Out]# 5      3   4.30  39.1
#[Out]# 6      3   4.20  39.1
#[Out]# 7      4  14.25  39.1
#[Out]# 8      4  19.40  39.1
#[Out]# 9      5   4.70  39.1
#[Out]# 10     5   8.25  39.1
#[Out]# 11     5   6.70  39.1
#[Out]# 12     7   3.80  39.1
#[Out]# 13     7   1.90  39.1
#[Out]# 14     7  10.75  39.1
#[Out]# 15     7   3.10  39.1
#[Out]# 16     8   6.25  39.1
#[Out]# 17    10   3.20  39.1
#[Out]# 18    11   4.10  39.1
#[Out]# 19    13  13.30  39.1
#[Out]# 20    13   6.50  39.1
#[Out]# 21    13   1.65  39.1
#[Out]# 22    13   0.50  39.1
#[Out]# 23    15   0.90  39.1
#[Out]# 24    16   2.90  39.1
#[Out]# 25    16  11.05  39.1
#[Out]# 26    16   6.05  39.1
#[Out]# 27    16   4.95  39.1
#[Out]# 28    16   3.00  39.1
#[Out]# 29    16   1.85  39.1
#[Out]# ..   ...    ...   ...
#[Out]# 255  178   7.50  39.1
#[Out]# 256  179  10.85  39.1
#[Out]# 257  179   0.45  39.1
#[Out]# 258  179   6.95  39.1
#[Out]# 259  180   3.10  39.1
#[Out]# 260  180   4.65  39.1
#[Out]# 261  181   3.60  39.1
#[Out]# 262  181   2.00  39.1
#[Out]# 263  182   4.20  39.1
#[Out]# 264  182  14.90  39.1
#[Out]# 265  184   3.50  39.1
#[Out]# 266  185   1.00  39.1
#[Out]# 267  186   1.00  39.1
#[Out]# 268  188   1.00  39.1
#[Out]# 269  188   1.00  39.1
#[Out]# 270  189   1.25  39.1
#[Out]# 271  189   2.50  39.1
#[Out]# 272  190  19.60  39.1
#[Out]# 273  190  12.80  39.1
#[Out]# 274  190  15.75  39.1
#[Out]# 275  190  14.85  39.1
#[Out]# 276  190  20.30  39.1
#[Out]# 277  190  10.85  39.1
#[Out]# 278  190   3.85  39.1
#[Out]# 279  190  14.55  39.1
#[Out]# 280  190  10.60  39.1
#[Out]# 281  190   3.25  39.1
#[Out]# 282  190   9.80  39.1
#[Out]# 283  190  21.90  39.1
#[Out]# 284  190   5.55  39.1
#[Out]# 
#[Out]# [285 rows x 3 columns]
# Fri, 04 Dec 2020 12:09:09
query4_4 = '''
    SELECT cID, date, SUM(price) price, max
    FROM purchase, ( SELECT MAX(sum) max
                     FROM ( SELECT cID, date, SUM(price) sum
                            FROM purchase
                            GROUP BY cID, date) )
    GROUP BY cID, date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price   max
#[Out]# 0      0  2018-08-22   0.45  39.1
#[Out]# 1      1  2018-08-20  14.20  39.1
#[Out]# 2      1  2018-08-21  10.00  39.1
#[Out]# 3      2  2018-08-16   2.45  39.1
#[Out]# 4      2  2018-08-17   7.70  39.1
#[Out]# 5      3  2018-08-18   4.30  39.1
#[Out]# 6      3  2018-08-19   4.20  39.1
#[Out]# 7      4  2018-08-24  14.25  39.1
#[Out]# 8      4  2018-08-25  19.40  39.1
#[Out]# 9      5  2018-08-17   4.70  39.1
#[Out]# 10     5  2018-08-22   8.25  39.1
#[Out]# 11     5  2018-08-23   6.70  39.1
#[Out]# 12     7  2018-08-23   3.80  39.1
#[Out]# 13     7  2018-08-24   1.90  39.1
#[Out]# 14     7  2018-08-25  10.75  39.1
#[Out]# 15     7  2018-08-26   3.10  39.1
#[Out]# 16     8  2018-08-16   6.25  39.1
#[Out]# 17    10  2018-08-27   3.20  39.1
#[Out]# 18    11  2018-08-25   4.10  39.1
#[Out]# 19    13  2018-08-17  13.30  39.1
#[Out]# 20    13  2018-08-25   6.50  39.1
#[Out]# 21    13  2018-08-26   1.65  39.1
#[Out]# 22    13  2018-08-27   0.50  39.1
#[Out]# 23    15  2018-08-27   0.90  39.1
#[Out]# 24    16  2018-08-18   2.90  39.1
#[Out]# 25    16  2018-08-19  11.05  39.1
#[Out]# 26    16  2018-08-24   6.05  39.1
#[Out]# 27    16  2018-08-25   4.95  39.1
#[Out]# 28    16  2018-08-26   3.00  39.1
#[Out]# 29    16  2018-08-27   1.85  39.1
#[Out]# ..   ...         ...    ...   ...
#[Out]# 255  178  2018-08-27   7.50  39.1
#[Out]# 256  179  2018-08-22  10.85  39.1
#[Out]# 257  179  2018-08-23   0.45  39.1
#[Out]# 258  179  2018-08-24   6.95  39.1
#[Out]# 259  180  2018-08-26   3.10  39.1
#[Out]# 260  180  2018-08-27   4.65  39.1
#[Out]# 261  181  2018-08-24   3.60  39.1
#[Out]# 262  181  2018-08-27   2.00  39.1
#[Out]# 263  182  2018-08-23   4.20  39.1
#[Out]# 264  182  2018-08-28  14.90  39.1
#[Out]# 265  184  2018-08-20   3.50  39.1
#[Out]# 266  185  2018-08-20   1.00  39.1
#[Out]# 267  186  2018-08-21   1.00  39.1
#[Out]# 268  188  2018-08-20   1.00  39.1
#[Out]# 269  188  2018-09-20   1.00  39.1
#[Out]# 270  189  2018-08-25   1.25  39.1
#[Out]# 271  189  2018-08-26   2.50  39.1
#[Out]# 272  190  2018-08-15  19.60  39.1
#[Out]# 273  190  2018-08-16  12.80  39.1
#[Out]# 274  190  2018-08-17  15.75  39.1
#[Out]# 275  190  2018-08-18  14.85  39.1
#[Out]# 276  190  2018-08-19  20.30  39.1
#[Out]# 277  190  2018-08-20  10.85  39.1
#[Out]# 278  190  2018-08-21   3.85  39.1
#[Out]# 279  190  2018-08-22  14.55  39.1
#[Out]# 280  190  2018-08-23  10.60  39.1
#[Out]# 281  190  2018-08-24   3.25  39.1
#[Out]# 282  190  2018-08-25   9.80  39.1
#[Out]# 283  190  2018-08-26  21.90  39.1
#[Out]# 284  190  2018-08-27   5.55  39.1
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Fri, 04 Dec 2020 12:10:20
query4_4 = '''
    SELECT *
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price   max
#[Out]# 0      0  2018-08-22   0.45  39.1
#[Out]# 1      1  2018-08-20  14.20  39.1
#[Out]# 2      1  2018-08-21  10.00  39.1
#[Out]# 3      2  2018-08-16   2.45  39.1
#[Out]# 4      2  2018-08-17   7.70  39.1
#[Out]# 5      3  2018-08-18   4.30  39.1
#[Out]# 6      3  2018-08-19   4.20  39.1
#[Out]# 7      4  2018-08-24  14.25  39.1
#[Out]# 8      4  2018-08-25  19.40  39.1
#[Out]# 9      5  2018-08-17   4.70  39.1
#[Out]# 10     5  2018-08-22   8.25  39.1
#[Out]# 11     5  2018-08-23   6.70  39.1
#[Out]# 12     7  2018-08-23   3.80  39.1
#[Out]# 13     7  2018-08-24   1.90  39.1
#[Out]# 14     7  2018-08-25  10.75  39.1
#[Out]# 15     7  2018-08-26   3.10  39.1
#[Out]# 16     8  2018-08-16   6.25  39.1
#[Out]# 17    10  2018-08-27   3.20  39.1
#[Out]# 18    11  2018-08-25   4.10  39.1
#[Out]# 19    13  2018-08-17  13.30  39.1
#[Out]# 20    13  2018-08-25   6.50  39.1
#[Out]# 21    13  2018-08-26   1.65  39.1
#[Out]# 22    13  2018-08-27   0.50  39.1
#[Out]# 23    15  2018-08-27   0.90  39.1
#[Out]# 24    16  2018-08-18   2.90  39.1
#[Out]# 25    16  2018-08-19  11.05  39.1
#[Out]# 26    16  2018-08-24   6.05  39.1
#[Out]# 27    16  2018-08-25   4.95  39.1
#[Out]# 28    16  2018-08-26   3.00  39.1
#[Out]# 29    16  2018-08-27   1.85  39.1
#[Out]# ..   ...         ...    ...   ...
#[Out]# 255  178  2018-08-27   7.50  39.1
#[Out]# 256  179  2018-08-22  10.85  39.1
#[Out]# 257  179  2018-08-23   0.45  39.1
#[Out]# 258  179  2018-08-24   6.95  39.1
#[Out]# 259  180  2018-08-26   3.10  39.1
#[Out]# 260  180  2018-08-27   4.65  39.1
#[Out]# 261  181  2018-08-24   3.60  39.1
#[Out]# 262  181  2018-08-27   2.00  39.1
#[Out]# 263  182  2018-08-23   4.20  39.1
#[Out]# 264  182  2018-08-28  14.90  39.1
#[Out]# 265  184  2018-08-20   3.50  39.1
#[Out]# 266  185  2018-08-20   1.00  39.1
#[Out]# 267  186  2018-08-21   1.00  39.1
#[Out]# 268  188  2018-08-20   1.00  39.1
#[Out]# 269  188  2018-09-20   1.00  39.1
#[Out]# 270  189  2018-08-25   1.25  39.1
#[Out]# 271  189  2018-08-26   2.50  39.1
#[Out]# 272  190  2018-08-15  19.60  39.1
#[Out]# 273  190  2018-08-16  12.80  39.1
#[Out]# 274  190  2018-08-17  15.75  39.1
#[Out]# 275  190  2018-08-18  14.85  39.1
#[Out]# 276  190  2018-08-19  20.30  39.1
#[Out]# 277  190  2018-08-20  10.85  39.1
#[Out]# 278  190  2018-08-21   3.85  39.1
#[Out]# 279  190  2018-08-22  14.55  39.1
#[Out]# 280  190  2018-08-23  10.60  39.1
#[Out]# 281  190  2018-08-24   3.25  39.1
#[Out]# 282  190  2018-08-25   9.80  39.1
#[Out]# 283  190  2018-08-26  21.90  39.1
#[Out]# 284  190  2018-08-27   5.55  39.1
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Fri, 04 Dec 2020 12:10:47
query4_4 = '''
    SELECT *
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE 0.75*price >= max
'''

pd.read_sql_query(query4_4, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, date, price, max]
#[Out]# Index: []
# Fri, 04 Dec 2020 12:11:03
query4_4 = '''
    SELECT *
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE price >= max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price   max
#[Out]# 0  161  2018-08-26   39.1  39.1
# Fri, 04 Dec 2020 12:11:52
query4_4 = '''
    SELECT *
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE 2*price >= max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price   max
#[Out]# 0   24  2018-08-20  20.70  39.1
#[Out]# 1   71  2018-08-24  22.25  39.1
#[Out]# 2   82  2018-08-23  21.30  39.1
#[Out]# 3  108  2018-08-15  23.95  39.1
#[Out]# 4  123  2018-08-17  20.20  39.1
#[Out]# 5  124  2018-08-26  28.80  39.1
#[Out]# 6  161  2018-08-26  39.10  39.1
#[Out]# 7  190  2018-08-15  19.60  39.1
#[Out]# 8  190  2018-08-19  20.30  39.1
#[Out]# 9  190  2018-08-26  21.90  39.1
# Fri, 04 Dec 2020 12:12:10
query4_4 = '''
    SELECT *
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price   max
#[Out]# 0  161  2018-08-26   39.1  39.1
# Fri, 04 Dec 2020 12:12:31
query4_4 = '''
    SELECT *
    FROM ( SELECT cID, date, SUM(price) price, 0.75*max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
# Fri, 04 Dec 2020 12:12:40
query4_4 = '''
    SELECT *
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price   max
#[Out]# 0  161  2018-08-26   39.1  39.1
# Fri, 04 Dec 2020 12:12:53
query4_4 = '''
    SELECT cID, date, price, max*0.75
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price  max*0.75
#[Out]# 0  161  2018-08-26   39.1    29.325
# Fri, 04 Dec 2020 12:13:01
query4_4 = '''
    SELECT cID, date, price, max*0.75
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#      cID        date  price  max*0.75
#[Out]# 0      0  2018-08-22   0.45    29.325
#[Out]# 1      1  2018-08-20  14.20    29.325
#[Out]# 2      1  2018-08-21  10.00    29.325
#[Out]# 3      2  2018-08-16   2.45    29.325
#[Out]# 4      2  2018-08-17   7.70    29.325
#[Out]# 5      3  2018-08-18   4.30    29.325
#[Out]# 6      3  2018-08-19   4.20    29.325
#[Out]# 7      4  2018-08-24  14.25    29.325
#[Out]# 8      4  2018-08-25  19.40    29.325
#[Out]# 9      5  2018-08-17   4.70    29.325
#[Out]# 10     5  2018-08-22   8.25    29.325
#[Out]# 11     5  2018-08-23   6.70    29.325
#[Out]# 12     7  2018-08-23   3.80    29.325
#[Out]# 13     7  2018-08-24   1.90    29.325
#[Out]# 14     7  2018-08-25  10.75    29.325
#[Out]# 15     7  2018-08-26   3.10    29.325
#[Out]# 16     8  2018-08-16   6.25    29.325
#[Out]# 17    10  2018-08-27   3.20    29.325
#[Out]# 18    11  2018-08-25   4.10    29.325
#[Out]# 19    13  2018-08-17  13.30    29.325
#[Out]# 20    13  2018-08-25   6.50    29.325
#[Out]# 21    13  2018-08-26   1.65    29.325
#[Out]# 22    13  2018-08-27   0.50    29.325
#[Out]# 23    15  2018-08-27   0.90    29.325
#[Out]# 24    16  2018-08-18   2.90    29.325
#[Out]# 25    16  2018-08-19  11.05    29.325
#[Out]# 26    16  2018-08-24   6.05    29.325
#[Out]# 27    16  2018-08-25   4.95    29.325
#[Out]# 28    16  2018-08-26   3.00    29.325
#[Out]# 29    16  2018-08-27   1.85    29.325
#[Out]# ..   ...         ...    ...       ...
#[Out]# 255  178  2018-08-27   7.50    29.325
#[Out]# 256  179  2018-08-22  10.85    29.325
#[Out]# 257  179  2018-08-23   0.45    29.325
#[Out]# 258  179  2018-08-24   6.95    29.325
#[Out]# 259  180  2018-08-26   3.10    29.325
#[Out]# 260  180  2018-08-27   4.65    29.325
#[Out]# 261  181  2018-08-24   3.60    29.325
#[Out]# 262  181  2018-08-27   2.00    29.325
#[Out]# 263  182  2018-08-23   4.20    29.325
#[Out]# 264  182  2018-08-28  14.90    29.325
#[Out]# 265  184  2018-08-20   3.50    29.325
#[Out]# 266  185  2018-08-20   1.00    29.325
#[Out]# 267  186  2018-08-21   1.00    29.325
#[Out]# 268  188  2018-08-20   1.00    29.325
#[Out]# 269  188  2018-09-20   1.00    29.325
#[Out]# 270  189  2018-08-25   1.25    29.325
#[Out]# 271  189  2018-08-26   2.50    29.325
#[Out]# 272  190  2018-08-15  19.60    29.325
#[Out]# 273  190  2018-08-16  12.80    29.325
#[Out]# 274  190  2018-08-17  15.75    29.325
#[Out]# 275  190  2018-08-18  14.85    29.325
#[Out]# 276  190  2018-08-19  20.30    29.325
#[Out]# 277  190  2018-08-20  10.85    29.325
#[Out]# 278  190  2018-08-21   3.85    29.325
#[Out]# 279  190  2018-08-22  14.55    29.325
#[Out]# 280  190  2018-08-23  10.60    29.325
#[Out]# 281  190  2018-08-24   3.25    29.325
#[Out]# 282  190  2018-08-25   9.80    29.325
#[Out]# 283  190  2018-08-26  21.90    29.325
#[Out]# 284  190  2018-08-27   5.55    29.325
#[Out]# 
#[Out]# [285 rows x 4 columns]
# Fri, 04 Dec 2020 12:13:14
query4_4 = '''
    SELECT cID, date, price, max*0.75
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE price > 20
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price  max*0.75
#[Out]# 0   24  2018-08-20  20.70    29.325
#[Out]# 1   71  2018-08-24  22.25    29.325
#[Out]# 2   82  2018-08-23  21.30    29.325
#[Out]# 3  108  2018-08-15  23.95    29.325
#[Out]# 4  123  2018-08-17  20.20    29.325
#[Out]# 5  124  2018-08-26  28.80    29.325
#[Out]# 6  161  2018-08-26  39.10    29.325
#[Out]# 7  190  2018-08-19  20.30    29.325
#[Out]# 8  190  2018-08-26  21.90    29.325
# Fri, 04 Dec 2020 12:13:34
query4_4 = '''
    SELECT cID, date, price, max*0.75
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price  max*0.75
#[Out]# 0  161  2018-08-26   39.1    29.325
# Fri, 04 Dec 2020 12:13:37
query4_4 = '''
    SELECT cID, date, price, max
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date)
    WHERE price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price   max
#[Out]# 0  161  2018-08-26   39.1  39.1
# Fri, 04 Dec 2020 12:14:44
query4_4 = '''
    SELECT cID, date, price, max
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date) x, customer c
    WHERE x.cID = c.ID AND price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
# Fri, 04 Dec 2020 12:14:55
query4_4 = '''
    SELECT cID, date, price, max
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date) x, customer c
    WHERE x.cID = c.cID AND price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
# Fri, 04 Dec 2020 12:15:10
query4_4 = '''
    SELECT x.cID, date, price, max
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date) x, customer c
    WHERE x.cID = c.cID AND price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID        date  price   max
#[Out]# 0  161  2018-08-26   39.1  39.1
# Fri, 04 Dec 2020 12:15:18
query4_4 = '''
    SELECT cName
    FROM ( SELECT cID, date, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date) x, customer c
    WHERE x.cID = c.cID AND price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Fri, 04 Dec 2020 12:16:30
query4_4 = '''
    SELECT cName
    FROM ( SELECT cID, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT cID, date, SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date) x, customer c
    WHERE x.cID = c.cID AND price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Fri, 04 Dec 2020 12:16:52
query4_4 = '''
    SELECT cName
    FROM ( SELECT cID, SUM(price) price, max
           FROM purchase, ( SELECT MAX(sum) max
                            FROM ( SELECT SUM(price) sum
                                   FROM purchase
                                   GROUP BY cID, date) )
           GROUP BY cID, date) x, customer c
    WHERE x.cID = c.cID AND price >= 0.75*max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cName
#[Out]# 0  Floor
# Fri, 04 Dec 2020 12:24:14
query4_5 = '''
    SELECT *
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.sName = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [cID, cName, street, city, tID, cID, sID, pID, date, quantity, price, sID, sName, street, city]
#[Out]# Index: []
# Fri, 04 Dec 2020 12:25:16
query4_5 = '''
    SELECT *
    FROM store
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     sID        sName            street       city
#[Out]# 0     0         Coop      Kalverstraat  Amsterdam
#[Out]# 1     1    Hoogvliet  Rozemarijnstraat      Breda
#[Out]# 2     2        Jumbo    Stadhoudersweg  Rotterdam
#[Out]# 3     3       Sligro    Stadhoudersweg  Rotterdam
#[Out]# 4     4    Hoogvliet       Molenstraat  Eindhoven
#[Out]# 5     5       Sligro     Stationsplein      Breda
#[Out]# 6     6         Coop    Stadhoudersweg  Rotterdam
#[Out]# 7     7       Sligro  Wilhelminastraat  Eindhoven
#[Out]# 8     8  Albert Hein       Molenstraat  Eindhoven
#[Out]# 9     9  Albert Hein         Koestraat    Tilburg
#[Out]# 10   10        Jumbo        Bergselaan  Rotterdam
#[Out]# 11   11  Albert Hein          Hofplein  Rotterdam
#[Out]# 12   12         Lidl  Wilhelminastraat  Eindhoven
#[Out]# 13   13         Coop         Koestraat    Tilburg
#[Out]# 14   14         Coop     Keizersgracht  Amsterdam
#[Out]# 15   15         Lidl     Prinsengracht  Amsterdam
#[Out]# 16   16         Lidl     Ambachtstraat    Utrecht
#[Out]# 17   17    Hoogvliet        Kerkstraat  Eindhoven
#[Out]# 18   18       Sligro       Parallelweg    Tilburg
#[Out]# 19   19         Coop       Karrestraat      Breda
#[Out]# 20   20        Jumbo      Kasteeldreef    Tilburg
#[Out]# 21   21         Coop      Kasteeldreef    Tilburg
#[Out]# 22   22         Lidl     Prinsengracht  Amsterdam
#[Out]# 23   23         Dirk     Stationsplein      Breda
#[Out]# 24   24  Albert Hein     Stationsplein      Breda
#[Out]# 25   25  Albert Hein     Stationsplein      Breda
#[Out]# 26   26    Hoogvliet   Sint Annastraat      Breda
#[Out]# 27   27       Sligro      Kalverstraat  Amsterdam
#[Out]# 28   28    Hoogvliet         Koestraat    Tilburg
#[Out]# 29   29       Sligro      Marnixstraat  Amsterdam
#[Out]# ..  ...          ...               ...        ...
#[Out]# 34   34         Coop          Bierkaai  Amsterdam
#[Out]# 35   35         Lidl     Julianastraat    Utrecht
#[Out]# 36   36         Lidl     Julianastraat  Eindhoven
#[Out]# 37   37        Jumbo          Molenweg  Eindhoven
#[Out]# 38   38    Hoogvliet          Hofplein  Rotterdam
#[Out]# 39   39       Sligro       Dorpsstraat  Eindhoven
#[Out]# 40   40    Hoogvliet          Hofplein  Rotterdam
#[Out]# 41   41  Albert Hein        Bergselaan  Rotterdam
#[Out]# 42   42       Sligro      Kalverstraat  Amsterdam
#[Out]# 43   43         Coop    Gasthuisstraat    Utrecht
#[Out]# 44   44  Albert Hein     Ambachtstraat    Utrecht
#[Out]# 45   45         Coop      Kasteeldreef    Tilburg
#[Out]# 46   46         Lidl        Bergselaan  Rotterdam
#[Out]# 47   47         Coop     Julianastraat  Rotterdam
#[Out]# 48   48    Hoogvliet      Kasteeldreef    Tilburg
#[Out]# 49   49    Hoogvliet      Keizerstraat  Rotterdam
#[Out]# 50   50       Sligro     Stationsplein      Breda
#[Out]# 51   51         Coop       Parallelweg    Utrecht
#[Out]# 52   52         Lidl       Nieuwstraat  Eindhoven
#[Out]# 53   53         Coop        Hoogstraat    Utrecht
#[Out]# 54   54         Dirk     Julianastraat  Eindhoven
#[Out]# 55   55         Coop   Sint Annastraat      Breda
#[Out]# 56   56        Jumbo       Parallelweg  Eindhoven
#[Out]# 57   57         Dirk       Molenstraat  Eindhoven
#[Out]# 58   58         Dirk      Keizerstraat  Rotterdam
#[Out]# 59   59        Jumbo  Rozemarijnstraat      Breda
#[Out]# 60   60         Lidl      Pannekoekweg      Breda
#[Out]# 61   61         Lidl      Pannekoekweg      Breda
#[Out]# 62   62        Jumbo     Poffertjesweg  Eindhoven
#[Out]# 63   63        Jumbo     Stationstraat        Oss
#[Out]# 
#[Out]# [64 rows x 4 columns]
# Fri, 04 Dec 2020 12:25:36
query4_5 = '''
    SELECT *
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID    cName                street       city  tID  cID  sID  pID  \
#[Out]# 0      1      Sem      Rozemarijnstraat      Breda    3    1   17    9   
#[Out]# 1      1      Sem      Rozemarijnstraat      Breda    7    1   36   27   
#[Out]# 2      2    Lucas      Oude Leliestraat  Amsterdam    8    2   12   20   
#[Out]# 3      2    Lucas      Oude Leliestraat  Amsterdam    9    2   39    9   
#[Out]# 4      3     Finn         Stationsplein      Breda   14    3   30   26   
#[Out]# 5      4     Daan          Kalverstraat  Amsterdam   16    4   17    8   
#[Out]# 6      4     Daan          Kalverstraat  Amsterdam   20    4    7   13   
#[Out]# 7      5     Levi        Gasthuisstraat    Utrecht   22    5    4   14   
#[Out]# 8      5     Levi        Gasthuisstraat    Utrecht   23    5   36   28   
#[Out]# 9      5     Levi        Gasthuisstraat    Utrecht   27    5   17   19   
#[Out]# 10     7     Bram          Schoolstraat  Eindhoven   29    7   12    2   
#[Out]# 11    13    James       Sint Annastraat      Breda   38   13   33    0   
#[Out]# 12    13    James       Sint Annastraat      Breda   39   13    4   23   
#[Out]# 13    13    James       Sint Annastraat      Breda   40   13   36    8   
#[Out]# 14    13    James       Sint Annastraat      Breda   41   13   33   17   
#[Out]# 15    13    James       Sint Annastraat      Breda   44   13    4    3   
#[Out]# 16    13    James       Sint Annastraat      Breda   46   13    8    5   
#[Out]# 17    16   Julian  Prins Bernhardstraat  Eindhoven   55   16   36   13   
#[Out]# 18    24     Luca          Kasteeldreef    Tilburg   78   24   17    5   
#[Out]# 19    24     Luca          Kasteeldreef    Tilburg   82   24   36    6   
#[Out]# 20    25    Mason          Keizerstraat  Rotterdam   84   25   12   26   
#[Out]# 21    27      Tim             Koestraat    Utrecht   86   27    8    6   
#[Out]# 22    30     Teun            Oosterkade  Rotterdam   96   30    7   16   
#[Out]# 23    30     Teun            Oosterkade  Rotterdam   97   30   57   12   
#[Out]# 24    31  Olivier         Julianastraat  Rotterdam   99   31   39   24   
#[Out]# 25    33     Sven        Ginnekenstraat      Breda  100   33   39    6   
#[Out]# 26    33     Sven        Ginnekenstraat      Breda  101   33   57   19   
#[Out]# 27    33     Sven        Ginnekenstraat      Breda  102   33   54   16   
#[Out]# 28    33     Sven        Ginnekenstraat      Breda  103   33   17    9   
#[Out]# 29    33     Sven        Ginnekenstraat      Breda  104   33   36    0   
#[Out]# ..   ...      ...                   ...        ...  ...  ...  ...  ...   
#[Out]# 103  169     Lily        Gasthuisstraat    Utrecht  437  169   52   14   
#[Out]# 104  170     Iris          Kastanjelaan  Eindhoven  439  170   52    0   
#[Out]# 105  171    Tessa           Haringvliet  Rotterdam  441  171   56    3   
#[Out]# 106  176    Amira           Parallelweg  Amsterdam  447  176   52    4   
#[Out]# 107  176    Amira           Parallelweg  Amsterdam  448  176   12   24   
#[Out]# 108  176    Amira           Parallelweg  Amsterdam  451  176    4   21   
#[Out]# 109  178     Elif           Parallelweg    Utrecht  459  178   39   24   
#[Out]# 110  179     Juul        Wilhelminapark    Tilburg  462  179   57   17   
#[Out]# 111  180    Merel          Kalverstraat  Amsterdam  468  180   56   10   
#[Out]# 112  182  Johanna         Beatrixstraat  Eindhoven  472  182   17   25   
#[Out]# 113  182  Johanna         Beatrixstraat  Eindhoven  474  182    4   13   
#[Out]# 114  185     Nick                Verweg  Eindhoven  778  185   62   29   
#[Out]# 115  186   Angela              Dichtweg  Eindhoven  779  186   62   29   
#[Out]# 116  188     Pino            Maanstraat  Rotterdam  780  188   62   30   
#[Out]# 117  188     Pino            Maanstraat  Rotterdam  781  188   62   30   
#[Out]# 118  190   Kostas              Eindeweg    Utrecht  788  190    4    7   
#[Out]# 119  190   Kostas              Eindeweg    Utrecht  791  190    7   22   
#[Out]# 120  190   Kostas              Eindeweg    Utrecht  792  190    8   20   
#[Out]# 121  190   Kostas              Eindeweg    Utrecht  796  190   12   26   
#[Out]# 122  190   Kostas              Eindeweg    Utrecht  801  190   17   10   
#[Out]# 123  190   Kostas              Eindeweg    Utrecht  814  190   30   10   
#[Out]# 124  190   Kostas              Eindeweg    Utrecht  817  190   33   19   
#[Out]# 125  190   Kostas              Eindeweg    Utrecht  820  190   36    5   
#[Out]# 126  190   Kostas              Eindeweg    Utrecht  821  190   37   28   
#[Out]# 127  190   Kostas              Eindeweg    Utrecht  823  190   39    0   
#[Out]# 128  190   Kostas              Eindeweg    Utrecht  836  190   52   23   
#[Out]# 129  190   Kostas              Eindeweg    Utrecht  838  190   54    0   
#[Out]# 130  190   Kostas              Eindeweg    Utrecht  840  190   56   11   
#[Out]# 131  190   Kostas              Eindeweg    Utrecht  841  190   57   15   
#[Out]# 132  190   Kostas              Eindeweg    Utrecht  846  190   62    9   
#[Out]# 
#[Out]#            date  quantity  price  sID        sName            street  \
#[Out]# 0    2018-08-20         2   1.25   17    Hoogvliet        Kerkstraat   
#[Out]# 1    2018-08-21         6   9.10   36         Lidl     Julianastraat   
#[Out]# 2    2018-08-16         1   2.45   12         Lidl  Wilhelminastraat   
#[Out]# 3    2018-08-17         7   1.35   39       Sligro       Dorpsstraat   
#[Out]# 4    2018-08-19         2   2.75   30         Dirk       Nieuwstraat   
#[Out]# 5    2018-08-24         2   4.15   17    Hoogvliet        Kerkstraat   
#[Out]# 6    2018-08-25         9   3.05    7       Sligro  Wilhelminastraat   
#[Out]# 7    2018-08-17         6   4.70    4    Hoogvliet       Molenstraat   
#[Out]# 8    2018-08-22         6   8.25   36         Lidl     Julianastraat   
#[Out]# 9    2018-08-23         1   2.20   17    Hoogvliet        Kerkstraat   
#[Out]# 10   2018-08-23         6   1.70   12         Lidl  Wilhelminastraat   
#[Out]# 11   2018-08-17         5   5.35   33         Dirk       Nieuwstraat   
#[Out]# 12   2018-08-17         6   2.55    4    Hoogvliet       Molenstraat   
#[Out]# 13   2018-08-17         3   5.40   36         Lidl     Julianastraat   
#[Out]# 14   2018-08-25         5   2.00   33         Dirk       Nieuwstraat   
#[Out]# 15   2018-08-25         1   1.70    4    Hoogvliet       Molenstraat   
#[Out]# 16   2018-08-27         6   0.50    8  Albert Hein       Molenstraat   
#[Out]# 17   2018-08-18         1   2.90   36         Lidl     Julianastraat   
#[Out]# 18   2018-08-20         7   0.55   17    Hoogvliet        Kerkstraat   
#[Out]# 19   2018-08-20         3   1.15   36         Lidl     Julianastraat   
#[Out]# 20   2018-08-28         9   2.55   12         Lidl  Wilhelminastraat   
#[Out]# 21   2018-08-26         1   0.95    8  Albert Hein       Molenstraat   
#[Out]# 22   2018-08-18         4   1.90    7       Sligro  Wilhelminastraat   
#[Out]# 23   2018-08-18         8  11.45   57         Dirk       Molenstraat   
#[Out]# 24   2018-08-28         4   3.90   39       Sligro       Dorpsstraat   
#[Out]# 25   2018-08-26         6   1.05   39       Sligro       Dorpsstraat   
#[Out]# 26   2018-08-26         4   2.60   57         Dirk       Molenstraat   
#[Out]# 27   2018-08-26         1   2.05   54         Dirk     Julianastraat   
#[Out]# 28   2018-08-26         9   1.30   17    Hoogvliet        Kerkstraat   
#[Out]# 29   2018-08-27         6   3.95   36         Lidl     Julianastraat   
#[Out]# ..          ...       ...    ...  ...          ...               ...   
#[Out]# 103  2018-08-28         7   4.65   52         Lidl       Nieuwstraat   
#[Out]# 104  2018-08-16         7   3.95   52         Lidl       Nieuwstraat   
#[Out]# 105  2018-08-20         1   1.50   56        Jumbo       Parallelweg   
#[Out]# 106  2018-08-22         7   0.90   52         Lidl       Nieuwstraat   
#[Out]# 107  2018-08-25         9   3.85   12         Lidl  Wilhelminastraat   
#[Out]# 108  2018-08-26         8   2.15    4    Hoogvliet       Molenstraat   
#[Out]# 109  2018-08-27         1   3.90   39       Sligro       Dorpsstraat   
#[Out]# 110  2018-08-24         2   2.40   57         Dirk       Molenstraat   
#[Out]# 111  2018-08-27         3   0.60   56        Jumbo       Parallelweg   
#[Out]# 112  2018-08-28         8   3.90   17    Hoogvliet        Kerkstraat   
#[Out]# 113  2018-08-23         9   4.20    4    Hoogvliet       Molenstraat   
#[Out]# 114  2018-08-20         1   1.00   62        Jumbo     Poffertjesweg   
#[Out]# 115  2018-08-21         5   1.00   62        Jumbo     Poffertjesweg   
#[Out]# 116  2018-08-20         1   1.00   62        Jumbo     Poffertjesweg   
#[Out]# 117  2018-09-20         1   1.00   62        Jumbo     Poffertjesweg   
#[Out]# 118  2018-08-26         7   1.30    4    Hoogvliet       Molenstraat   
#[Out]# 119  2018-08-20         4   3.20    7       Sligro  Wilhelminastraat   
#[Out]# 120  2018-08-16         7   3.25    8  Albert Hein       Molenstraat   
#[Out]# 121  2018-08-17         6   2.75   12         Lidl  Wilhelminastraat   
#[Out]# 122  2018-08-23         6   0.95   17    Hoogvliet        Kerkstraat   
#[Out]# 123  2018-08-18         4   4.35   30         Dirk       Nieuwstraat   
#[Out]# 124  2018-08-19         5   4.25   33         Dirk       Nieuwstraat   
#[Out]# 125  2018-08-23         3   2.55   36         Lidl     Julianastraat   
#[Out]# 126  2018-08-15         4   0.65   37        Jumbo          Molenweg   
#[Out]# 127  2018-08-25         4   3.70   39       Sligro       Dorpsstraat   
#[Out]# 128  2018-08-15         5   2.50   52         Lidl       Nieuwstraat   
#[Out]# 129  2018-08-25         6   3.50   54         Dirk     Julianastraat   
#[Out]# 130  2018-08-15         4   1.60   56        Jumbo       Parallelweg   
#[Out]# 131  2018-08-22         5   3.25   57         Dirk       Molenstraat   
#[Out]# 132  2018-08-16         2   3.15   62        Jumbo     Poffertjesweg   
#[Out]# 
#[Out]#           city  
#[Out]# 0    Eindhoven  
#[Out]# 1    Eindhoven  
#[Out]# 2    Eindhoven  
#[Out]# 3    Eindhoven  
#[Out]# 4    Eindhoven  
#[Out]# 5    Eindhoven  
#[Out]# 6    Eindhoven  
#[Out]# 7    Eindhoven  
#[Out]# 8    Eindhoven  
#[Out]# 9    Eindhoven  
#[Out]# 10   Eindhoven  
#[Out]# 11   Eindhoven  
#[Out]# 12   Eindhoven  
#[Out]# 13   Eindhoven  
#[Out]# 14   Eindhoven  
#[Out]# 15   Eindhoven  
#[Out]# 16   Eindhoven  
#[Out]# 17   Eindhoven  
#[Out]# 18   Eindhoven  
#[Out]# 19   Eindhoven  
#[Out]# 20   Eindhoven  
#[Out]# 21   Eindhoven  
#[Out]# 22   Eindhoven  
#[Out]# 23   Eindhoven  
#[Out]# 24   Eindhoven  
#[Out]# 25   Eindhoven  
#[Out]# 26   Eindhoven  
#[Out]# 27   Eindhoven  
#[Out]# 28   Eindhoven  
#[Out]# 29   Eindhoven  
#[Out]# ..         ...  
#[Out]# 103  Eindhoven  
#[Out]# 104  Eindhoven  
#[Out]# 105  Eindhoven  
#[Out]# 106  Eindhoven  
#[Out]# 107  Eindhoven  
#[Out]# 108  Eindhoven  
#[Out]# 109  Eindhoven  
#[Out]# 110  Eindhoven  
#[Out]# 111  Eindhoven  
#[Out]# 112  Eindhoven  
#[Out]# 113  Eindhoven  
#[Out]# 114  Eindhoven  
#[Out]# 115  Eindhoven  
#[Out]# 116  Eindhoven  
#[Out]# 117  Eindhoven  
#[Out]# 118  Eindhoven  
#[Out]# 119  Eindhoven  
#[Out]# 120  Eindhoven  
#[Out]# 121  Eindhoven  
#[Out]# 122  Eindhoven  
#[Out]# 123  Eindhoven  
#[Out]# 124  Eindhoven  
#[Out]# 125  Eindhoven  
#[Out]# 126  Eindhoven  
#[Out]# 127  Eindhoven  
#[Out]# 128  Eindhoven  
#[Out]# 129  Eindhoven  
#[Out]# 130  Eindhoven  
#[Out]# 131  Eindhoven  
#[Out]# 132  Eindhoven  
#[Out]# 
#[Out]# [133 rows x 15 columns]
# Fri, 04 Dec 2020 12:26:21
query4_5 = '''
    SELECT c.city
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#           city
#[Out]# 0        Breda
#[Out]# 1        Breda
#[Out]# 2    Amsterdam
#[Out]# 3    Amsterdam
#[Out]# 4        Breda
#[Out]# 5    Amsterdam
#[Out]# 6    Amsterdam
#[Out]# 7      Utrecht
#[Out]# 8      Utrecht
#[Out]# 9      Utrecht
#[Out]# 10   Eindhoven
#[Out]# 11       Breda
#[Out]# 12       Breda
#[Out]# 13       Breda
#[Out]# 14       Breda
#[Out]# 15       Breda
#[Out]# 16       Breda
#[Out]# 17   Eindhoven
#[Out]# 18     Tilburg
#[Out]# 19     Tilburg
#[Out]# 20   Rotterdam
#[Out]# 21     Utrecht
#[Out]# 22   Rotterdam
#[Out]# 23   Rotterdam
#[Out]# 24   Rotterdam
#[Out]# 25       Breda
#[Out]# 26       Breda
#[Out]# 27       Breda
#[Out]# 28       Breda
#[Out]# 29       Breda
#[Out]# ..         ...
#[Out]# 103    Utrecht
#[Out]# 104  Eindhoven
#[Out]# 105  Rotterdam
#[Out]# 106  Amsterdam
#[Out]# 107  Amsterdam
#[Out]# 108  Amsterdam
#[Out]# 109    Utrecht
#[Out]# 110    Tilburg
#[Out]# 111  Amsterdam
#[Out]# 112  Eindhoven
#[Out]# 113  Eindhoven
#[Out]# 114  Eindhoven
#[Out]# 115  Eindhoven
#[Out]# 116  Rotterdam
#[Out]# 117  Rotterdam
#[Out]# 118    Utrecht
#[Out]# 119    Utrecht
#[Out]# 120    Utrecht
#[Out]# 121    Utrecht
#[Out]# 122    Utrecht
#[Out]# 123    Utrecht
#[Out]# 124    Utrecht
#[Out]# 125    Utrecht
#[Out]# 126    Utrecht
#[Out]# 127    Utrecht
#[Out]# 128    Utrecht
#[Out]# 129    Utrecht
#[Out]# 130    Utrecht
#[Out]# 131    Utrecht
#[Out]# 132    Utrecht
#[Out]# 
#[Out]# [133 rows x 1 columns]
# Fri, 04 Dec 2020 12:26:44
query4_5 = '''
    SELECT COUNT(c.city)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#    COUNT(c.city)
#[Out]# 0            133
# Fri, 04 Dec 2020 12:27:03
query4_5 = '''
    SELECT c.city, COUNT(c.city)
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
    GROUP BY c.city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(c.city)
#[Out]# 0  Amsterdam             17
#[Out]# 1      Breda             27
#[Out]# 2  Eindhoven             24
#[Out]# 3  Rotterdam             16
#[Out]# 4    Tilburg             18
#[Out]# 5    Utrecht             31
# Fri, 04 Dec 2020 12:27:21
query4_5 = '''
    SELECT *
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#      cID    cName                street       city  tID  cID  sID  pID  \
#[Out]# 0      1      Sem      Rozemarijnstraat      Breda    3    1   17    9   
#[Out]# 1      1      Sem      Rozemarijnstraat      Breda    7    1   36   27   
#[Out]# 2      2    Lucas      Oude Leliestraat  Amsterdam    8    2   12   20   
#[Out]# 3      2    Lucas      Oude Leliestraat  Amsterdam    9    2   39    9   
#[Out]# 4      3     Finn         Stationsplein      Breda   14    3   30   26   
#[Out]# 5      4     Daan          Kalverstraat  Amsterdam   16    4   17    8   
#[Out]# 6      4     Daan          Kalverstraat  Amsterdam   20    4    7   13   
#[Out]# 7      5     Levi        Gasthuisstraat    Utrecht   22    5    4   14   
#[Out]# 8      5     Levi        Gasthuisstraat    Utrecht   23    5   36   28   
#[Out]# 9      5     Levi        Gasthuisstraat    Utrecht   27    5   17   19   
#[Out]# 10     7     Bram          Schoolstraat  Eindhoven   29    7   12    2   
#[Out]# 11    13    James       Sint Annastraat      Breda   38   13   33    0   
#[Out]# 12    13    James       Sint Annastraat      Breda   39   13    4   23   
#[Out]# 13    13    James       Sint Annastraat      Breda   40   13   36    8   
#[Out]# 14    13    James       Sint Annastraat      Breda   41   13   33   17   
#[Out]# 15    13    James       Sint Annastraat      Breda   44   13    4    3   
#[Out]# 16    13    James       Sint Annastraat      Breda   46   13    8    5   
#[Out]# 17    16   Julian  Prins Bernhardstraat  Eindhoven   55   16   36   13   
#[Out]# 18    24     Luca          Kasteeldreef    Tilburg   78   24   17    5   
#[Out]# 19    24     Luca          Kasteeldreef    Tilburg   82   24   36    6   
#[Out]# 20    25    Mason          Keizerstraat  Rotterdam   84   25   12   26   
#[Out]# 21    27      Tim             Koestraat    Utrecht   86   27    8    6   
#[Out]# 22    30     Teun            Oosterkade  Rotterdam   96   30    7   16   
#[Out]# 23    30     Teun            Oosterkade  Rotterdam   97   30   57   12   
#[Out]# 24    31  Olivier         Julianastraat  Rotterdam   99   31   39   24   
#[Out]# 25    33     Sven        Ginnekenstraat      Breda  100   33   39    6   
#[Out]# 26    33     Sven        Ginnekenstraat      Breda  101   33   57   19   
#[Out]# 27    33     Sven        Ginnekenstraat      Breda  102   33   54   16   
#[Out]# 28    33     Sven        Ginnekenstraat      Breda  103   33   17    9   
#[Out]# 29    33     Sven        Ginnekenstraat      Breda  104   33   36    0   
#[Out]# ..   ...      ...                   ...        ...  ...  ...  ...  ...   
#[Out]# 103  169     Lily        Gasthuisstraat    Utrecht  437  169   52   14   
#[Out]# 104  170     Iris          Kastanjelaan  Eindhoven  439  170   52    0   
#[Out]# 105  171    Tessa           Haringvliet  Rotterdam  441  171   56    3   
#[Out]# 106  176    Amira           Parallelweg  Amsterdam  447  176   52    4   
#[Out]# 107  176    Amira           Parallelweg  Amsterdam  448  176   12   24   
#[Out]# 108  176    Amira           Parallelweg  Amsterdam  451  176    4   21   
#[Out]# 109  178     Elif           Parallelweg    Utrecht  459  178   39   24   
#[Out]# 110  179     Juul        Wilhelminapark    Tilburg  462  179   57   17   
#[Out]# 111  180    Merel          Kalverstraat  Amsterdam  468  180   56   10   
#[Out]# 112  182  Johanna         Beatrixstraat  Eindhoven  472  182   17   25   
#[Out]# 113  182  Johanna         Beatrixstraat  Eindhoven  474  182    4   13   
#[Out]# 114  185     Nick                Verweg  Eindhoven  778  185   62   29   
#[Out]# 115  186   Angela              Dichtweg  Eindhoven  779  186   62   29   
#[Out]# 116  188     Pino            Maanstraat  Rotterdam  780  188   62   30   
#[Out]# 117  188     Pino            Maanstraat  Rotterdam  781  188   62   30   
#[Out]# 118  190   Kostas              Eindeweg    Utrecht  788  190    4    7   
#[Out]# 119  190   Kostas              Eindeweg    Utrecht  791  190    7   22   
#[Out]# 120  190   Kostas              Eindeweg    Utrecht  792  190    8   20   
#[Out]# 121  190   Kostas              Eindeweg    Utrecht  796  190   12   26   
#[Out]# 122  190   Kostas              Eindeweg    Utrecht  801  190   17   10   
#[Out]# 123  190   Kostas              Eindeweg    Utrecht  814  190   30   10   
#[Out]# 124  190   Kostas              Eindeweg    Utrecht  817  190   33   19   
#[Out]# 125  190   Kostas              Eindeweg    Utrecht  820  190   36    5   
#[Out]# 126  190   Kostas              Eindeweg    Utrecht  821  190   37   28   
#[Out]# 127  190   Kostas              Eindeweg    Utrecht  823  190   39    0   
#[Out]# 128  190   Kostas              Eindeweg    Utrecht  836  190   52   23   
#[Out]# 129  190   Kostas              Eindeweg    Utrecht  838  190   54    0   
#[Out]# 130  190   Kostas              Eindeweg    Utrecht  840  190   56   11   
#[Out]# 131  190   Kostas              Eindeweg    Utrecht  841  190   57   15   
#[Out]# 132  190   Kostas              Eindeweg    Utrecht  846  190   62    9   
#[Out]# 
#[Out]#            date  quantity  price  sID        sName            street  \
#[Out]# 0    2018-08-20         2   1.25   17    Hoogvliet        Kerkstraat   
#[Out]# 1    2018-08-21         6   9.10   36         Lidl     Julianastraat   
#[Out]# 2    2018-08-16         1   2.45   12         Lidl  Wilhelminastraat   
#[Out]# 3    2018-08-17         7   1.35   39       Sligro       Dorpsstraat   
#[Out]# 4    2018-08-19         2   2.75   30         Dirk       Nieuwstraat   
#[Out]# 5    2018-08-24         2   4.15   17    Hoogvliet        Kerkstraat   
#[Out]# 6    2018-08-25         9   3.05    7       Sligro  Wilhelminastraat   
#[Out]# 7    2018-08-17         6   4.70    4    Hoogvliet       Molenstraat   
#[Out]# 8    2018-08-22         6   8.25   36         Lidl     Julianastraat   
#[Out]# 9    2018-08-23         1   2.20   17    Hoogvliet        Kerkstraat   
#[Out]# 10   2018-08-23         6   1.70   12         Lidl  Wilhelminastraat   
#[Out]# 11   2018-08-17         5   5.35   33         Dirk       Nieuwstraat   
#[Out]# 12   2018-08-17         6   2.55    4    Hoogvliet       Molenstraat   
#[Out]# 13   2018-08-17         3   5.40   36         Lidl     Julianastraat   
#[Out]# 14   2018-08-25         5   2.00   33         Dirk       Nieuwstraat   
#[Out]# 15   2018-08-25         1   1.70    4    Hoogvliet       Molenstraat   
#[Out]# 16   2018-08-27         6   0.50    8  Albert Hein       Molenstraat   
#[Out]# 17   2018-08-18         1   2.90   36         Lidl     Julianastraat   
#[Out]# 18   2018-08-20         7   0.55   17    Hoogvliet        Kerkstraat   
#[Out]# 19   2018-08-20         3   1.15   36         Lidl     Julianastraat   
#[Out]# 20   2018-08-28         9   2.55   12         Lidl  Wilhelminastraat   
#[Out]# 21   2018-08-26         1   0.95    8  Albert Hein       Molenstraat   
#[Out]# 22   2018-08-18         4   1.90    7       Sligro  Wilhelminastraat   
#[Out]# 23   2018-08-18         8  11.45   57         Dirk       Molenstraat   
#[Out]# 24   2018-08-28         4   3.90   39       Sligro       Dorpsstraat   
#[Out]# 25   2018-08-26         6   1.05   39       Sligro       Dorpsstraat   
#[Out]# 26   2018-08-26         4   2.60   57         Dirk       Molenstraat   
#[Out]# 27   2018-08-26         1   2.05   54         Dirk     Julianastraat   
#[Out]# 28   2018-08-26         9   1.30   17    Hoogvliet        Kerkstraat   
#[Out]# 29   2018-08-27         6   3.95   36         Lidl     Julianastraat   
#[Out]# ..          ...       ...    ...  ...          ...               ...   
#[Out]# 103  2018-08-28         7   4.65   52         Lidl       Nieuwstraat   
#[Out]# 104  2018-08-16         7   3.95   52         Lidl       Nieuwstraat   
#[Out]# 105  2018-08-20         1   1.50   56        Jumbo       Parallelweg   
#[Out]# 106  2018-08-22         7   0.90   52         Lidl       Nieuwstraat   
#[Out]# 107  2018-08-25         9   3.85   12         Lidl  Wilhelminastraat   
#[Out]# 108  2018-08-26         8   2.15    4    Hoogvliet       Molenstraat   
#[Out]# 109  2018-08-27         1   3.90   39       Sligro       Dorpsstraat   
#[Out]# 110  2018-08-24         2   2.40   57         Dirk       Molenstraat   
#[Out]# 111  2018-08-27         3   0.60   56        Jumbo       Parallelweg   
#[Out]# 112  2018-08-28         8   3.90   17    Hoogvliet        Kerkstraat   
#[Out]# 113  2018-08-23         9   4.20    4    Hoogvliet       Molenstraat   
#[Out]# 114  2018-08-20         1   1.00   62        Jumbo     Poffertjesweg   
#[Out]# 115  2018-08-21         5   1.00   62        Jumbo     Poffertjesweg   
#[Out]# 116  2018-08-20         1   1.00   62        Jumbo     Poffertjesweg   
#[Out]# 117  2018-09-20         1   1.00   62        Jumbo     Poffertjesweg   
#[Out]# 118  2018-08-26         7   1.30    4    Hoogvliet       Molenstraat   
#[Out]# 119  2018-08-20         4   3.20    7       Sligro  Wilhelminastraat   
#[Out]# 120  2018-08-16         7   3.25    8  Albert Hein       Molenstraat   
#[Out]# 121  2018-08-17         6   2.75   12         Lidl  Wilhelminastraat   
#[Out]# 122  2018-08-23         6   0.95   17    Hoogvliet        Kerkstraat   
#[Out]# 123  2018-08-18         4   4.35   30         Dirk       Nieuwstraat   
#[Out]# 124  2018-08-19         5   4.25   33         Dirk       Nieuwstraat   
#[Out]# 125  2018-08-23         3   2.55   36         Lidl     Julianastraat   
#[Out]# 126  2018-08-15         4   0.65   37        Jumbo          Molenweg   
#[Out]# 127  2018-08-25         4   3.70   39       Sligro       Dorpsstraat   
#[Out]# 128  2018-08-15         5   2.50   52         Lidl       Nieuwstraat   
#[Out]# 129  2018-08-25         6   3.50   54         Dirk     Julianastraat   
#[Out]# 130  2018-08-15         4   1.60   56        Jumbo       Parallelweg   
#[Out]# 131  2018-08-22         5   3.25   57         Dirk       Molenstraat   
#[Out]# 132  2018-08-16         2   3.15   62        Jumbo     Poffertjesweg   
#[Out]# 
#[Out]#           city  
#[Out]# 0    Eindhoven  
#[Out]# 1    Eindhoven  
#[Out]# 2    Eindhoven  
#[Out]# 3    Eindhoven  
#[Out]# 4    Eindhoven  
#[Out]# 5    Eindhoven  
#[Out]# 6    Eindhoven  
#[Out]# 7    Eindhoven  
#[Out]# 8    Eindhoven  
#[Out]# 9    Eindhoven  
#[Out]# 10   Eindhoven  
#[Out]# 11   Eindhoven  
#[Out]# 12   Eindhoven  
#[Out]# 13   Eindhoven  
#[Out]# 14   Eindhoven  
#[Out]# 15   Eindhoven  
#[Out]# 16   Eindhoven  
#[Out]# 17   Eindhoven  
#[Out]# 18   Eindhoven  
#[Out]# 19   Eindhoven  
#[Out]# 20   Eindhoven  
#[Out]# 21   Eindhoven  
#[Out]# 22   Eindhoven  
#[Out]# 23   Eindhoven  
#[Out]# 24   Eindhoven  
#[Out]# 25   Eindhoven  
#[Out]# 26   Eindhoven  
#[Out]# 27   Eindhoven  
#[Out]# 28   Eindhoven  
#[Out]# 29   Eindhoven  
#[Out]# ..         ...  
#[Out]# 103  Eindhoven  
#[Out]# 104  Eindhoven  
#[Out]# 105  Eindhoven  
#[Out]# 106  Eindhoven  
#[Out]# 107  Eindhoven  
#[Out]# 108  Eindhoven  
#[Out]# 109  Eindhoven  
#[Out]# 110  Eindhoven  
#[Out]# 111  Eindhoven  
#[Out]# 112  Eindhoven  
#[Out]# 113  Eindhoven  
#[Out]# 114  Eindhoven  
#[Out]# 115  Eindhoven  
#[Out]# 116  Eindhoven  
#[Out]# 117  Eindhoven  
#[Out]# 118  Eindhoven  
#[Out]# 119  Eindhoven  
#[Out]# 120  Eindhoven  
#[Out]# 121  Eindhoven  
#[Out]# 122  Eindhoven  
#[Out]# 123  Eindhoven  
#[Out]# 124  Eindhoven  
#[Out]# 125  Eindhoven  
#[Out]# 126  Eindhoven  
#[Out]# 127  Eindhoven  
#[Out]# 128  Eindhoven  
#[Out]# 129  Eindhoven  
#[Out]# 130  Eindhoven  
#[Out]# 131  Eindhoven  
#[Out]# 132  Eindhoven  
#[Out]# 
#[Out]# [133 rows x 15 columns]
# Fri, 04 Dec 2020 12:27:37
query4_5 = '''
    SELECT DISTINCT cID
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
# Fri, 04 Dec 2020 12:27:41
query4_5 = '''
    SELECT DISTINCT c.cID
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID
#[Out]# 0     1
#[Out]# 1     2
#[Out]# 2     3
#[Out]# 3     4
#[Out]# 4     5
#[Out]# 5     7
#[Out]# 6    13
#[Out]# 7    16
#[Out]# 8    24
#[Out]# 9    25
#[Out]# 10   27
#[Out]# 11   30
#[Out]# 12   31
#[Out]# 13   33
#[Out]# 14   38
#[Out]# 15   39
#[Out]# 16   40
#[Out]# 17   41
#[Out]# 18   45
#[Out]# 19   51
#[Out]# 20   59
#[Out]# 21   60
#[Out]# 22   70
#[Out]# 23   71
#[Out]# 24   72
#[Out]# 25   75
#[Out]# 26   78
#[Out]# 27   80
#[Out]# 28   82
#[Out]# 29   85
#[Out]# ..  ...
#[Out]# 39  111
#[Out]# 40  116
#[Out]# 41  122
#[Out]# 42  123
#[Out]# 43  124
#[Out]# 44  126
#[Out]# 45  129
#[Out]# 46  134
#[Out]# 47  136
#[Out]# 48  147
#[Out]# 49  149
#[Out]# 50  157
#[Out]# 51  159
#[Out]# 52  161
#[Out]# 53  162
#[Out]# 54  163
#[Out]# 55  165
#[Out]# 56  167
#[Out]# 57  169
#[Out]# 58  170
#[Out]# 59  171
#[Out]# 60  176
#[Out]# 61  178
#[Out]# 62  179
#[Out]# 63  180
#[Out]# 64  182
#[Out]# 65  185
#[Out]# 66  186
#[Out]# 67  188
#[Out]# 68  190
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Fri, 04 Dec 2020 12:28:00
query4_5 = '''
    SELECT DISTINCT c.cID, c.city
    FROM customer c, purchase p, store s
    WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven"
'''

pd.read_sql_query(query4_5, conn)
#[Out]#     cID       city
#[Out]# 0     1      Breda
#[Out]# 1     2  Amsterdam
#[Out]# 2     3      Breda
#[Out]# 3     4  Amsterdam
#[Out]# 4     5    Utrecht
#[Out]# 5     7  Eindhoven
#[Out]# 6    13      Breda
#[Out]# 7    16  Eindhoven
#[Out]# 8    24    Tilburg
#[Out]# 9    25  Rotterdam
#[Out]# 10   27    Utrecht
#[Out]# 11   30  Rotterdam
#[Out]# 12   31  Rotterdam
#[Out]# 13   33      Breda
#[Out]# 14   38  Eindhoven
#[Out]# 15   39  Eindhoven
#[Out]# 16   40  Rotterdam
#[Out]# 17   41    Utrecht
#[Out]# 18   45    Utrecht
#[Out]# 19   51  Eindhoven
#[Out]# 20   59  Amsterdam
#[Out]# 21   60    Utrecht
#[Out]# 22   70  Amsterdam
#[Out]# 23   71  Rotterdam
#[Out]# 24   72      Breda
#[Out]# 25   75      Breda
#[Out]# 26   78  Eindhoven
#[Out]# 27   80      Breda
#[Out]# 28   82  Eindhoven
#[Out]# 29   85    Utrecht
#[Out]# ..  ...        ...
#[Out]# 39  111  Rotterdam
#[Out]# 40  116    Tilburg
#[Out]# 41  122    Tilburg
#[Out]# 42  123  Rotterdam
#[Out]# 43  124  Amsterdam
#[Out]# 44  126  Amsterdam
#[Out]# 45  129    Utrecht
#[Out]# 46  134  Amsterdam
#[Out]# 47  136  Rotterdam
#[Out]# 48  147    Utrecht
#[Out]# 49  149  Eindhoven
#[Out]# 50  157  Amsterdam
#[Out]# 51  159    Utrecht
#[Out]# 52  161    Tilburg
#[Out]# 53  162  Rotterdam
#[Out]# 54  163    Tilburg
#[Out]# 55  165    Tilburg
#[Out]# 56  167      Breda
#[Out]# 57  169    Utrecht
#[Out]# 58  170  Eindhoven
#[Out]# 59  171  Rotterdam
#[Out]# 60  176  Amsterdam
#[Out]# 61  178    Utrecht
#[Out]# 62  179    Tilburg
#[Out]# 63  180  Amsterdam
#[Out]# 64  182  Eindhoven
#[Out]# 65  185  Eindhoven
#[Out]# 66  186  Eindhoven
#[Out]# 67  188  Rotterdam
#[Out]# 68  190    Utrecht
#[Out]# 
#[Out]# [69 rows x 2 columns]
# Fri, 04 Dec 2020 12:29:17
query4_5 = '''
    SELECT city, COUNT(city) count
    FROM ( SELECT DISTINCT c.cID, c.city
           FROM customer c, purchase p, store s
           WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven")
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12
# Fri, 04 Dec 2020 12:30:54
query4_5 = '''
    SELECT city, COUNT(city) count
    FROM ( SELECT DISTINCT c.cID, c.city
           FROM customer c, purchase p, store s
           WHERE c.cID = p.cID AND p.sID = s.sID AND s.city = "Eindhoven")
    GROUP BY city
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  count
#[Out]# 0  Amsterdam     10
#[Out]# 1      Breda      9
#[Out]# 2  Eindhoven     15
#[Out]# 3  Rotterdam     13
#[Out]# 4    Tilburg     10
#[Out]# 5    Utrecht     12


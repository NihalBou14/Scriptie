# IPython log file

# Wed, 09 Dec 2020 12:06:11
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
# Wed, 09 Dec 2020 12:06:20
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Wed, 09 Dec 2020 12:06:22
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x19610754490>
# Wed, 09 Dec 2020 12:23:15
query4_3 = '''SELECT sName, city FROM store
    WHERE sName not in ( SELECT sName FROM (
    (SELECT sName , city FROM (select city from customer ) as p cross join 
    (select distinct sName from store) as sp)
    EXCEPT
    (SELECT sName , city FROM store) ) AS r ); 
    
    UNION
    
        SELECT sName, city FROM store
    WHERE sName not in ( SELECT sName FROM (
    (SELECT sName , city FROM (select city from customer ) as p cross join 
    (select distinct sName from store) as sp)
    EXCEPT
    (SELECT sName , city FROM store) ) AS r ); 
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:23:27
query4_3 = '''SELECT sName, city FROM store
    WHERE sName not in ( SELECT sName FROM (
    (SELECT sName , city FROM (select city from customer ) as p cross join 
    (select distinct sName from store) as sp)
    EXCEPT
    (SELECT sName , city FROM store) ) AS r )
    
    UNION
    
        SELECT sName, city FROM store
    WHERE sName not in ( SELECT sName FROM (
    (SELECT sName , city FROM (select city from customer ) as p cross join 
    (select distinct sName from store) as sp)
    EXCEPT
    (SELECT sName , city FROM store) ) AS r ); 
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:23:56
query4_3 = '''(SELECT sName, city FROM store
    WHERE sName not in ( SELECT sName FROM (
    (SELECT sName , city FROM (select city from customer ) as p cross join 
    (select distinct sName from store) as sp)
    EXCEPT
    (SELECT sName , city FROM store) ) AS r ))
    
    UNION
    
        SELECT sName, city FROM store
    WHERE sName not in ( SELECT sName FROM (
    (SELECT sName , city FROM (select city from customer ) as p cross join 
    (select distinct sName from store) as sp)
    EXCEPT
    (SELECT sName , city FROM store) ) AS r ); 
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:25:39
query4_3 = '''SELECT sName, city FROM store
    WHERE sName not in ( SELECT sName FROM (
    (SELECT sName , city FROM (select city from customer ) as p cross join 
    (select distinct sName from store) as sp)
    EXCEPT
    (SELECT sName , city FROM store) ) AS r )
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:26:36
query4_3 = '''SELECT sName, city FROM store
    WHERE sName not in ( SELECT sName FROM (
    (SELECT sName, city FROM (select city from customer ) AS p cross join 
    (select distinct sName from store) as sp)
    EXCEPT
    (SELECT sName, city FROM store) ) AS r )
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:26:48
query4_3 = '''SELECT sName, city FROM store
    WHERE sName not in ( SELECT sName FROM (
    (SELECT sName, city FROM (select city from customer ) AS p cross join 
    (select distinct sName from store) as sp)
    EXCEPT
    (SELECT sName, city FROM store) ) AS r );
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:28:52
query4_3 = '''SELECT sName, city FROM store as sx
    WHERE NOT EXISTS (
    (SELECT p.cityy FROM customer as p )
    EXCEPT
    (SELECT sp.city FROM  store as sp WHERE sp.sName = sx.sName ) );

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:29:05
query4_3 = '''SELECT sName, city FROM store as sx
    WHERE NOT EXISTS 
    (SELECT p.cityy FROM customer as p )
    EXCEPT
    (SELECT sp.city FROM  store as sp WHERE sp.sName = sx.sName );

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:29:11
query4_3 = '''SELECT sName, city FROM store as sx
    WHERE NOT EXISTS 
    (SELECT p.cityy FROM customer as p )
    EXCEPT
    SELECT sp.city FROM  store as sp WHERE sp.sName = sx.sName ;

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:29:17
query4_3 = '''SELECT sName, city FROM store as sx
    WHERE NOT EXISTS 
    SELECT p.cityy FROM customer as p
    EXCEPT
    SELECT sp.city FROM  store as sp WHERE sp.sName = sx.sName ;

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:29:37
query4_3 = '''SELECT sName, city FROM store as sx
    WHERE NOT EXISTS (
    (SELECT p.city FROM customer as p )
    EXCEPT
    (SELECT sp.city FROM  store as sp WHERE sp.sName = sx.sName ) );

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:30:17
query4_3 = '''
    SELECT sName, city FROM store as sx
    WHERE NOT EXISTS (
    (SELECT p.city FROM customer as p )
    EXCEPT
    (SELECT sp.city FROM  store as sp WHERE sp.sName = sx.sName ) );

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:34:06
query4_5 = '''
SELECT cName FROM customer WHERE cID IN(
SELECT cID FROM purchase WHERE sID IN(
SELECT sID FROM store WHERE city = 'Eindhoven'));
'''

pd.read_sql_query(query4_5, conn)
#[Out]#        cName
#[Out]# 0        Sem
#[Out]# 1      Lucas
#[Out]# 2       Finn
#[Out]# 3       Daan
#[Out]# 4       Levi
#[Out]# 5       Bram
#[Out]# 6      James
#[Out]# 7     Julian
#[Out]# 8       Luca
#[Out]# 9      Mason
#[Out]# 10       Tim
#[Out]# 11      Teun
#[Out]# 12   Olivier
#[Out]# 13      Sven
#[Out]# 14    Floris
#[Out]# 15      Jack
#[Out]# 16      Jens
#[Out]# 17     Quinn
#[Out]# 18      Ryan
#[Out]# 19      Ties
#[Out]# 20      Joep
#[Out]# 21  Mohammed
#[Out]# 22       Kai
#[Out]# 23      Dean
#[Out]# 24      Dani
#[Out]# 25      Jace
#[Out]# 26      Mick
#[Out]# 27      Niek
#[Out]# 28     Dylan
#[Out]# 29    Pieter
#[Out]# ..       ...
#[Out]# 39    Lauren
#[Out]# 40     Lieke
#[Out]# 41      Elin
#[Out]# 42     Milou
#[Out]# 43     Sofie
#[Out]# 44      Lina
#[Out]# 45     Esmee
#[Out]# 46      Ella
#[Out]# 47     Femke
#[Out]# 48    Isabel
#[Out]# 49     Lizzy
#[Out]# 50      Puck
#[Out]# 51     Fenne
#[Out]# 52     Floor
#[Out]# 53     Elena
#[Out]# 54      Cato
#[Out]# 55     Hanna
#[Out]# 56    Veerle
#[Out]# 57      Lily
#[Out]# 58      Iris
#[Out]# 59     Tessa
#[Out]# 60     Amira
#[Out]# 61      Elif
#[Out]# 62      Juul
#[Out]# 63     Merel
#[Out]# 64   Johanna
#[Out]# 65      Nick
#[Out]# 66    Angela
#[Out]# 67      Pino
#[Out]# 68    Kostas
#[Out]# 
#[Out]# [69 rows x 1 columns]
# Wed, 09 Dec 2020 12:36:26
query4_5 = '''
SELECT city, COUNT(cName) FROM customer WHERE cID IN(
SELECT cID FROM purchase WHERE sID IN(
SELECT sID FROM store WHERE city = 'Eindhoven'))
GROUP BY city;
'''

pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT(cName)
#[Out]# 0  Amsterdam            10
#[Out]# 1      Breda             9
#[Out]# 2  Eindhoven            15
#[Out]# 3  Rotterdam            13
#[Out]# 4    Tilburg            10
#[Out]# 5    Utrecht            12
# Wed, 09 Dec 2020 12:37:30
query4_4 = '''
SELECT cID, SUM(price), date FROM purchase
GROUP BY date;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID  SUM(price)        date
#[Out]# 0    21       59.65  2018-08-15
#[Out]# 1     2       88.25  2018-08-16
#[Out]# 2     2      139.15  2018-08-17
#[Out]# 3     3      126.40  2018-08-18
#[Out]# 4     3      121.55  2018-08-19
#[Out]# 5     1      103.75  2018-08-20
#[Out]# 6     1       80.40  2018-08-21
#[Out]# 7     0      115.80  2018-08-22
#[Out]# 8     5      127.25  2018-08-23
#[Out]# 9     4      167.50  2018-08-24
#[Out]# 10    4      167.65  2018-08-25
#[Out]# 11    7      217.20  2018-08-26
#[Out]# 12   10      100.65  2018-08-27
#[Out]# 13   22       47.10  2018-08-28
#[Out]# 14   39       11.90  2018-08-29
#[Out]# 15  188        1.00  2018-09-20
# Wed, 09 Dec 2020 12:39:11
query4_4 = '''
SELECT MAX(SUM(price)) FROM (
SELECT cID, SUM(price), date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:39:33
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID     sum        date
#[Out]# 0    21   59.65  2018-08-15
#[Out]# 1     2   88.25  2018-08-16
#[Out]# 2     2  139.15  2018-08-17
#[Out]# 3     3  126.40  2018-08-18
#[Out]# 4     3  121.55  2018-08-19
#[Out]# 5     1  103.75  2018-08-20
#[Out]# 6     1   80.40  2018-08-21
#[Out]# 7     0  115.80  2018-08-22
#[Out]# 8     5  127.25  2018-08-23
#[Out]# 9     4  167.50  2018-08-24
#[Out]# 10    4  167.65  2018-08-25
#[Out]# 11    7  217.20  2018-08-26
#[Out]# 12   10  100.65  2018-08-27
#[Out]# 13   22   47.10  2018-08-28
#[Out]# 14   39   11.90  2018-08-29
#[Out]# 15  188    1.00  2018-09-20
# Wed, 09 Dec 2020 12:39:52
query4_4 = '''
SELECT MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0     217.2
# Wed, 09 Dec 2020 12:40:05
query4_4 = '''

SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID     sum        date
#[Out]# 0    21   59.65  2018-08-15
#[Out]# 1     2   88.25  2018-08-16
#[Out]# 2     2  139.15  2018-08-17
#[Out]# 3     3  126.40  2018-08-18
#[Out]# 4     3  121.55  2018-08-19
#[Out]# 5     1  103.75  2018-08-20
#[Out]# 6     1   80.40  2018-08-21
#[Out]# 7     0  115.80  2018-08-22
#[Out]# 8     5  127.25  2018-08-23
#[Out]# 9     4  167.50  2018-08-24
#[Out]# 10    4  167.65  2018-08-25
#[Out]# 11    7  217.20  2018-08-26
#[Out]# 12   10  100.65  2018-08-27
#[Out]# 13   22   47.10  2018-08-28
#[Out]# 14   39   11.90  2018-08-29
#[Out]# 15  188    1.00  2018-09-20
# Wed, 09 Dec 2020 12:40:15
query4_4 = '''
SELECT MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0     217.2
# Wed, 09 Dec 2020 12:40:46
query4_4 = '''
0.75 * (SELECT MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 12:50:15
query4_3 = '''
    SELECT sName, city FROM store
    CROSS JOIN
    SELECT city FROM customer;

'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:50:35
query4_3 = '''
    SELECT sName, city FROM store
    CROSS JOIN
customer;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:50:50
query4_3 = '''
    SELECT sName, store.city FROM store
    CROSS JOIN
    SELECT customer.city FROM customer;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:51:27
query4_3 = '''
    SELECT s.sName, s.city FROM store as s
    CROSS JOIN
    SELECT c.city FROM customer as c;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:52:01
query4_3 = '''
    SELECT * FROM
    store CROSS JOIN customer;
'''

pd.read_sql_query(query4_3, conn)
#[Out]#        sID  sName         street       city  cID     cName  \
#[Out]# 0        0   Coop   Kalverstraat  Amsterdam    0      Noah   
#[Out]# 1        0   Coop   Kalverstraat  Amsterdam    1       Sem   
#[Out]# 2        0   Coop   Kalverstraat  Amsterdam    2     Lucas   
#[Out]# 3        0   Coop   Kalverstraat  Amsterdam    3      Finn   
#[Out]# 4        0   Coop   Kalverstraat  Amsterdam    4      Daan   
#[Out]# 5        0   Coop   Kalverstraat  Amsterdam    5      Levi   
#[Out]# 6        0   Coop   Kalverstraat  Amsterdam    6     Milan   
#[Out]# 7        0   Coop   Kalverstraat  Amsterdam    7      Bram   
#[Out]# 8        0   Coop   Kalverstraat  Amsterdam    8      Liam   
#[Out]# 9        0   Coop   Kalverstraat  Amsterdam    9    Thomas   
#[Out]# 10       0   Coop   Kalverstraat  Amsterdam   10       Sam   
#[Out]# 11       0   Coop   Kalverstraat  Amsterdam   11     Thijs   
#[Out]# 12       0   Coop   Kalverstraat  Amsterdam   12      Adam   
#[Out]# 13       0   Coop   Kalverstraat  Amsterdam   13     James   
#[Out]# 14       0   Coop   Kalverstraat  Amsterdam   14       Max   
#[Out]# 15       0   Coop   Kalverstraat  Amsterdam   15      Noud   
#[Out]# 16       0   Coop   Kalverstraat  Amsterdam   16    Julian   
#[Out]# 17       0   Coop   Kalverstraat  Amsterdam   17       Dex   
#[Out]# 18       0   Coop   Kalverstraat  Amsterdam   18      Hugo   
#[Out]# 19       0   Coop   Kalverstraat  Amsterdam   19      Lars   
#[Out]# 20       0   Coop   Kalverstraat  Amsterdam   20      Gijs   
#[Out]# 21       0   Coop   Kalverstraat  Amsterdam   21  Benjamin   
#[Out]# 22       0   Coop   Kalverstraat  Amsterdam   22      Mats   
#[Out]# 23       0   Coop   Kalverstraat  Amsterdam   23       Jan   
#[Out]# 24       0   Coop   Kalverstraat  Amsterdam   24      Luca   
#[Out]# 25       0   Coop   Kalverstraat  Amsterdam   25     Mason   
#[Out]# 26       0   Coop   Kalverstraat  Amsterdam   26    Jayden   
#[Out]# 27       0   Coop   Kalverstraat  Amsterdam   27       Tim   
#[Out]# 28       0   Coop   Kalverstraat  Amsterdam   28      Siem   
#[Out]# 29       0   Coop   Kalverstraat  Amsterdam   29     Ruben   
#[Out]# ...    ...    ...            ...        ...  ...       ...   
#[Out]# 12130   63  Jumbo  Stationstraat        Oss  160      Lara   
#[Out]# 12131   63  Jumbo  Stationstraat        Oss  161     Floor   
#[Out]# 12132   63  Jumbo  Stationstraat        Oss  162     Elena   
#[Out]# 12133   63  Jumbo  Stationstraat        Oss  163      Cato   
#[Out]# 12134   63  Jumbo  Stationstraat        Oss  164       Evy   
#[Out]# 12135   63  Jumbo  Stationstraat        Oss  165     Hanna   
#[Out]# 12136   63  Jumbo  Stationstraat        Oss  166   Rosalie   
#[Out]# 12137   63  Jumbo  Stationstraat        Oss  167    Veerle   
#[Out]# 12138   63  Jumbo  Stationstraat        Oss  168      Kiki   
#[Out]# 12139   63  Jumbo  Stationstraat        Oss  169      Lily   
#[Out]# 12140   63  Jumbo  Stationstraat        Oss  170      Iris   
#[Out]# 12141   63  Jumbo  Stationstraat        Oss  171     Tessa   
#[Out]# 12142   63  Jumbo  Stationstraat        Oss  172      Lana   
#[Out]# 12143   63  Jumbo  Stationstraat        Oss  173     Livia   
#[Out]# 12144   63  Jumbo  Stationstraat        Oss  174      Romy   
#[Out]# 12145   63  Jumbo  Stationstraat        Oss  175       Sam   
#[Out]# 12146   63  Jumbo  Stationstraat        Oss  176     Amira   
#[Out]# 12147   63  Jumbo  Stationstraat        Oss  177     Eline   
#[Out]# 12148   63  Jumbo  Stationstraat        Oss  178      Elif   
#[Out]# 12149   63  Jumbo  Stationstraat        Oss  179      Juul   
#[Out]# 12150   63  Jumbo  Stationstraat        Oss  180     Merel   
#[Out]# 12151   63  Jumbo  Stationstraat        Oss  181      Liva   
#[Out]# 12152   63  Jumbo  Stationstraat        Oss  182   Johanna   
#[Out]# 12153   63  Jumbo  Stationstraat        Oss  183     Nikki   
#[Out]# 12154   63  Jumbo  Stationstraat        Oss  184     Wilko   
#[Out]# 12155   63  Jumbo  Stationstraat        Oss  185      Nick   
#[Out]# 12156   63  Jumbo  Stationstraat        Oss  186    Angela   
#[Out]# 12157   63  Jumbo  Stationstraat        Oss  188      Pino   
#[Out]# 12158   63  Jumbo  Stationstraat        Oss  189      Koen   
#[Out]# 12159   63  Jumbo  Stationstraat        Oss  190    Kostas   
#[Out]# 
#[Out]#                      street       city  
#[Out]# 0                 Koestraat    Utrecht  
#[Out]# 1          Rozemarijnstraat      Breda  
#[Out]# 2          Oude Leliestraat  Amsterdam  
#[Out]# 3             Stationsplein      Breda  
#[Out]# 4              Kalverstraat  Amsterdam  
#[Out]# 5            Gasthuisstraat    Utrecht  
#[Out]# 6               Parallelweg    Utrecht  
#[Out]# 7              Schoolstraat  Eindhoven  
#[Out]# 8             Rijsbergseweg      Breda  
#[Out]# 9               Parallelweg  Amsterdam  
#[Out]# 10              Langestraat    Tilburg  
#[Out]# 11                Koestraat    Tilburg  
#[Out]# 12              Nieuwstraat  Eindhoven  
#[Out]# 13          Sint Annastraat      Breda  
#[Out]# 14                Eikenlaan    Tilburg  
#[Out]# 15             Koningshoeve    Tilburg  
#[Out]# 16     Prins Bernhardstraat  Eindhoven  
#[Out]# 17             Kasteeldreef    Tilburg  
#[Out]# 18             Kasteeldreef    Tilburg  
#[Out]# 19            Rijsbergseweg      Breda  
#[Out]# 20               Heiligeweg  Amsterdam  
#[Out]# 21              Stationsweg    Tilburg  
#[Out]# 22              Molenstraat  Eindhoven  
#[Out]# 23          Sint Annastraat      Breda  
#[Out]# 24             Kasteeldreef    Tilburg  
#[Out]# 25             Keizerstraat  Rotterdam  
#[Out]# 26             Schoolstraat  Eindhoven  
#[Out]# 27                Koestraat    Utrecht  
#[Out]# 28              Langestraat    Tilburg  
#[Out]# 29                 Hofplein  Rotterdam  
#[Out]# ...                     ...        ...  
#[Out]# 12130           Langestraat    Tilburg  
#[Out]# 12131             Eikenlaan    Tilburg  
#[Out]# 12132            Bergselaan  Rotterdam  
#[Out]# 12133          Kastanjelaan    Tilburg  
#[Out]# 12134      Rozemarijnstraat      Breda  
#[Out]# 12135             Eikenlaan    Tilburg  
#[Out]# 12136           Stationsweg  Eindhoven  
#[Out]# 12137        Ginnekenstraat      Breda  
#[Out]# 12138          Keizerstraat  Rotterdam  
#[Out]# 12139        Gasthuisstraat    Utrecht  
#[Out]# 12140          Kastanjelaan  Eindhoven  
#[Out]# 12141           Haringvliet  Rotterdam  
#[Out]# 12142             Eikenlaan    Tilburg  
#[Out]# 12143      Vierwindenstraat      Breda  
#[Out]# 12144           Parallelweg  Eindhoven  
#[Out]# 12145             Bredalaan  Eindhoven  
#[Out]# 12146           Parallelweg  Amsterdam  
#[Out]# 12147          Kalverstraat  Amsterdam  
#[Out]# 12148           Parallelweg    Utrecht  
#[Out]# 12149        Wilhelminapark    Tilburg  
#[Out]# 12150          Kalverstraat  Amsterdam  
#[Out]# 12151           Fredriklaan  Eindhoven  
#[Out]# 12152         Beatrixstraat  Eindhoven  
#[Out]# 12153         Julianastraat    Utrecht  
#[Out]# 12154          Onbekendeweg  Eindhoven  
#[Out]# 12155                Verweg  Eindhoven  
#[Out]# 12156              Dichtweg  Eindhoven  
#[Out]# 12157            Maanstraat  Rotterdam  
#[Out]# 12158              Akkerweg        Oss  
#[Out]# 12159              Eindeweg    Utrecht  
#[Out]# 
#[Out]# [12160 rows x 8 columns]
# Wed, 09 Dec 2020 12:52:29
query4_3 = '''
    SELECT customer.city FROM
    store CROSS JOIN customer;
'''

pd.read_sql_query(query4_3, conn)
#[Out]#             city
#[Out]# 0        Utrecht
#[Out]# 1          Breda
#[Out]# 2      Amsterdam
#[Out]# 3          Breda
#[Out]# 4      Amsterdam
#[Out]# 5        Utrecht
#[Out]# 6        Utrecht
#[Out]# 7      Eindhoven
#[Out]# 8          Breda
#[Out]# 9      Amsterdam
#[Out]# 10       Tilburg
#[Out]# 11       Tilburg
#[Out]# 12     Eindhoven
#[Out]# 13         Breda
#[Out]# 14       Tilburg
#[Out]# 15       Tilburg
#[Out]# 16     Eindhoven
#[Out]# 17       Tilburg
#[Out]# 18       Tilburg
#[Out]# 19         Breda
#[Out]# 20     Amsterdam
#[Out]# 21       Tilburg
#[Out]# 22     Eindhoven
#[Out]# 23         Breda
#[Out]# 24       Tilburg
#[Out]# 25     Rotterdam
#[Out]# 26     Eindhoven
#[Out]# 27       Utrecht
#[Out]# 28       Tilburg
#[Out]# 29     Rotterdam
#[Out]# ...          ...
#[Out]# 12130    Tilburg
#[Out]# 12131    Tilburg
#[Out]# 12132  Rotterdam
#[Out]# 12133    Tilburg
#[Out]# 12134      Breda
#[Out]# 12135    Tilburg
#[Out]# 12136  Eindhoven
#[Out]# 12137      Breda
#[Out]# 12138  Rotterdam
#[Out]# 12139    Utrecht
#[Out]# 12140  Eindhoven
#[Out]# 12141  Rotterdam
#[Out]# 12142    Tilburg
#[Out]# 12143      Breda
#[Out]# 12144  Eindhoven
#[Out]# 12145  Eindhoven
#[Out]# 12146  Amsterdam
#[Out]# 12147  Amsterdam
#[Out]# 12148    Utrecht
#[Out]# 12149    Tilburg
#[Out]# 12150  Amsterdam
#[Out]# 12151  Eindhoven
#[Out]# 12152  Eindhoven
#[Out]# 12153    Utrecht
#[Out]# 12154  Eindhoven
#[Out]# 12155  Eindhoven
#[Out]# 12156  Eindhoven
#[Out]# 12157  Rotterdam
#[Out]# 12158        Oss
#[Out]# 12159    Utrecht
#[Out]# 
#[Out]# [12160 rows x 1 columns]
# Wed, 09 Dec 2020 12:52:35
query4_3 = '''
    SELECT * FROM
    store CROSS JOIN customer;
'''

pd.read_sql_query(query4_3, conn)
#[Out]#        sID  sName         street       city  cID     cName  \
#[Out]# 0        0   Coop   Kalverstraat  Amsterdam    0      Noah   
#[Out]# 1        0   Coop   Kalverstraat  Amsterdam    1       Sem   
#[Out]# 2        0   Coop   Kalverstraat  Amsterdam    2     Lucas   
#[Out]# 3        0   Coop   Kalverstraat  Amsterdam    3      Finn   
#[Out]# 4        0   Coop   Kalverstraat  Amsterdam    4      Daan   
#[Out]# 5        0   Coop   Kalverstraat  Amsterdam    5      Levi   
#[Out]# 6        0   Coop   Kalverstraat  Amsterdam    6     Milan   
#[Out]# 7        0   Coop   Kalverstraat  Amsterdam    7      Bram   
#[Out]# 8        0   Coop   Kalverstraat  Amsterdam    8      Liam   
#[Out]# 9        0   Coop   Kalverstraat  Amsterdam    9    Thomas   
#[Out]# 10       0   Coop   Kalverstraat  Amsterdam   10       Sam   
#[Out]# 11       0   Coop   Kalverstraat  Amsterdam   11     Thijs   
#[Out]# 12       0   Coop   Kalverstraat  Amsterdam   12      Adam   
#[Out]# 13       0   Coop   Kalverstraat  Amsterdam   13     James   
#[Out]# 14       0   Coop   Kalverstraat  Amsterdam   14       Max   
#[Out]# 15       0   Coop   Kalverstraat  Amsterdam   15      Noud   
#[Out]# 16       0   Coop   Kalverstraat  Amsterdam   16    Julian   
#[Out]# 17       0   Coop   Kalverstraat  Amsterdam   17       Dex   
#[Out]# 18       0   Coop   Kalverstraat  Amsterdam   18      Hugo   
#[Out]# 19       0   Coop   Kalverstraat  Amsterdam   19      Lars   
#[Out]# 20       0   Coop   Kalverstraat  Amsterdam   20      Gijs   
#[Out]# 21       0   Coop   Kalverstraat  Amsterdam   21  Benjamin   
#[Out]# 22       0   Coop   Kalverstraat  Amsterdam   22      Mats   
#[Out]# 23       0   Coop   Kalverstraat  Amsterdam   23       Jan   
#[Out]# 24       0   Coop   Kalverstraat  Amsterdam   24      Luca   
#[Out]# 25       0   Coop   Kalverstraat  Amsterdam   25     Mason   
#[Out]# 26       0   Coop   Kalverstraat  Amsterdam   26    Jayden   
#[Out]# 27       0   Coop   Kalverstraat  Amsterdam   27       Tim   
#[Out]# 28       0   Coop   Kalverstraat  Amsterdam   28      Siem   
#[Out]# 29       0   Coop   Kalverstraat  Amsterdam   29     Ruben   
#[Out]# ...    ...    ...            ...        ...  ...       ...   
#[Out]# 12130   63  Jumbo  Stationstraat        Oss  160      Lara   
#[Out]# 12131   63  Jumbo  Stationstraat        Oss  161     Floor   
#[Out]# 12132   63  Jumbo  Stationstraat        Oss  162     Elena   
#[Out]# 12133   63  Jumbo  Stationstraat        Oss  163      Cato   
#[Out]# 12134   63  Jumbo  Stationstraat        Oss  164       Evy   
#[Out]# 12135   63  Jumbo  Stationstraat        Oss  165     Hanna   
#[Out]# 12136   63  Jumbo  Stationstraat        Oss  166   Rosalie   
#[Out]# 12137   63  Jumbo  Stationstraat        Oss  167    Veerle   
#[Out]# 12138   63  Jumbo  Stationstraat        Oss  168      Kiki   
#[Out]# 12139   63  Jumbo  Stationstraat        Oss  169      Lily   
#[Out]# 12140   63  Jumbo  Stationstraat        Oss  170      Iris   
#[Out]# 12141   63  Jumbo  Stationstraat        Oss  171     Tessa   
#[Out]# 12142   63  Jumbo  Stationstraat        Oss  172      Lana   
#[Out]# 12143   63  Jumbo  Stationstraat        Oss  173     Livia   
#[Out]# 12144   63  Jumbo  Stationstraat        Oss  174      Romy   
#[Out]# 12145   63  Jumbo  Stationstraat        Oss  175       Sam   
#[Out]# 12146   63  Jumbo  Stationstraat        Oss  176     Amira   
#[Out]# 12147   63  Jumbo  Stationstraat        Oss  177     Eline   
#[Out]# 12148   63  Jumbo  Stationstraat        Oss  178      Elif   
#[Out]# 12149   63  Jumbo  Stationstraat        Oss  179      Juul   
#[Out]# 12150   63  Jumbo  Stationstraat        Oss  180     Merel   
#[Out]# 12151   63  Jumbo  Stationstraat        Oss  181      Liva   
#[Out]# 12152   63  Jumbo  Stationstraat        Oss  182   Johanna   
#[Out]# 12153   63  Jumbo  Stationstraat        Oss  183     Nikki   
#[Out]# 12154   63  Jumbo  Stationstraat        Oss  184     Wilko   
#[Out]# 12155   63  Jumbo  Stationstraat        Oss  185      Nick   
#[Out]# 12156   63  Jumbo  Stationstraat        Oss  186    Angela   
#[Out]# 12157   63  Jumbo  Stationstraat        Oss  188      Pino   
#[Out]# 12158   63  Jumbo  Stationstraat        Oss  189      Koen   
#[Out]# 12159   63  Jumbo  Stationstraat        Oss  190    Kostas   
#[Out]# 
#[Out]#                      street       city  
#[Out]# 0                 Koestraat    Utrecht  
#[Out]# 1          Rozemarijnstraat      Breda  
#[Out]# 2          Oude Leliestraat  Amsterdam  
#[Out]# 3             Stationsplein      Breda  
#[Out]# 4              Kalverstraat  Amsterdam  
#[Out]# 5            Gasthuisstraat    Utrecht  
#[Out]# 6               Parallelweg    Utrecht  
#[Out]# 7              Schoolstraat  Eindhoven  
#[Out]# 8             Rijsbergseweg      Breda  
#[Out]# 9               Parallelweg  Amsterdam  
#[Out]# 10              Langestraat    Tilburg  
#[Out]# 11                Koestraat    Tilburg  
#[Out]# 12              Nieuwstraat  Eindhoven  
#[Out]# 13          Sint Annastraat      Breda  
#[Out]# 14                Eikenlaan    Tilburg  
#[Out]# 15             Koningshoeve    Tilburg  
#[Out]# 16     Prins Bernhardstraat  Eindhoven  
#[Out]# 17             Kasteeldreef    Tilburg  
#[Out]# 18             Kasteeldreef    Tilburg  
#[Out]# 19            Rijsbergseweg      Breda  
#[Out]# 20               Heiligeweg  Amsterdam  
#[Out]# 21              Stationsweg    Tilburg  
#[Out]# 22              Molenstraat  Eindhoven  
#[Out]# 23          Sint Annastraat      Breda  
#[Out]# 24             Kasteeldreef    Tilburg  
#[Out]# 25             Keizerstraat  Rotterdam  
#[Out]# 26             Schoolstraat  Eindhoven  
#[Out]# 27                Koestraat    Utrecht  
#[Out]# 28              Langestraat    Tilburg  
#[Out]# 29                 Hofplein  Rotterdam  
#[Out]# ...                     ...        ...  
#[Out]# 12130           Langestraat    Tilburg  
#[Out]# 12131             Eikenlaan    Tilburg  
#[Out]# 12132            Bergselaan  Rotterdam  
#[Out]# 12133          Kastanjelaan    Tilburg  
#[Out]# 12134      Rozemarijnstraat      Breda  
#[Out]# 12135             Eikenlaan    Tilburg  
#[Out]# 12136           Stationsweg  Eindhoven  
#[Out]# 12137        Ginnekenstraat      Breda  
#[Out]# 12138          Keizerstraat  Rotterdam  
#[Out]# 12139        Gasthuisstraat    Utrecht  
#[Out]# 12140          Kastanjelaan  Eindhoven  
#[Out]# 12141           Haringvliet  Rotterdam  
#[Out]# 12142             Eikenlaan    Tilburg  
#[Out]# 12143      Vierwindenstraat      Breda  
#[Out]# 12144           Parallelweg  Eindhoven  
#[Out]# 12145             Bredalaan  Eindhoven  
#[Out]# 12146           Parallelweg  Amsterdam  
#[Out]# 12147          Kalverstraat  Amsterdam  
#[Out]# 12148           Parallelweg    Utrecht  
#[Out]# 12149        Wilhelminapark    Tilburg  
#[Out]# 12150          Kalverstraat  Amsterdam  
#[Out]# 12151           Fredriklaan  Eindhoven  
#[Out]# 12152         Beatrixstraat  Eindhoven  
#[Out]# 12153         Julianastraat    Utrecht  
#[Out]# 12154          Onbekendeweg  Eindhoven  
#[Out]# 12155                Verweg  Eindhoven  
#[Out]# 12156              Dichtweg  Eindhoven  
#[Out]# 12157            Maanstraat  Rotterdam  
#[Out]# 12158              Akkerweg        Oss  
#[Out]# 12159              Eindeweg    Utrecht  
#[Out]# 
#[Out]# [12160 rows x 8 columns]
# Wed, 09 Dec 2020 12:53:11
query4_3 = '''
    SELECT store.sName, store.city, customer.city FROM
    store CROSS JOIN customer
    WHERE 
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:53:22
query4_3 = '''
    SELECT store.sName, store.city, customer.city FROM
    store CROSS JOIN customer;
'''

pd.read_sql_query(query4_3, conn)
#[Out]#        sName       city       city
#[Out]# 0       Coop  Amsterdam    Utrecht
#[Out]# 1       Coop  Amsterdam      Breda
#[Out]# 2       Coop  Amsterdam  Amsterdam
#[Out]# 3       Coop  Amsterdam      Breda
#[Out]# 4       Coop  Amsterdam  Amsterdam
#[Out]# 5       Coop  Amsterdam    Utrecht
#[Out]# 6       Coop  Amsterdam    Utrecht
#[Out]# 7       Coop  Amsterdam  Eindhoven
#[Out]# 8       Coop  Amsterdam      Breda
#[Out]# 9       Coop  Amsterdam  Amsterdam
#[Out]# 10      Coop  Amsterdam    Tilburg
#[Out]# 11      Coop  Amsterdam    Tilburg
#[Out]# 12      Coop  Amsterdam  Eindhoven
#[Out]# 13      Coop  Amsterdam      Breda
#[Out]# 14      Coop  Amsterdam    Tilburg
#[Out]# 15      Coop  Amsterdam    Tilburg
#[Out]# 16      Coop  Amsterdam  Eindhoven
#[Out]# 17      Coop  Amsterdam    Tilburg
#[Out]# 18      Coop  Amsterdam    Tilburg
#[Out]# 19      Coop  Amsterdam      Breda
#[Out]# 20      Coop  Amsterdam  Amsterdam
#[Out]# 21      Coop  Amsterdam    Tilburg
#[Out]# 22      Coop  Amsterdam  Eindhoven
#[Out]# 23      Coop  Amsterdam      Breda
#[Out]# 24      Coop  Amsterdam    Tilburg
#[Out]# 25      Coop  Amsterdam  Rotterdam
#[Out]# 26      Coop  Amsterdam  Eindhoven
#[Out]# 27      Coop  Amsterdam    Utrecht
#[Out]# 28      Coop  Amsterdam    Tilburg
#[Out]# 29      Coop  Amsterdam  Rotterdam
#[Out]# ...      ...        ...        ...
#[Out]# 12130  Jumbo        Oss    Tilburg
#[Out]# 12131  Jumbo        Oss    Tilburg
#[Out]# 12132  Jumbo        Oss  Rotterdam
#[Out]# 12133  Jumbo        Oss    Tilburg
#[Out]# 12134  Jumbo        Oss      Breda
#[Out]# 12135  Jumbo        Oss    Tilburg
#[Out]# 12136  Jumbo        Oss  Eindhoven
#[Out]# 12137  Jumbo        Oss      Breda
#[Out]# 12138  Jumbo        Oss  Rotterdam
#[Out]# 12139  Jumbo        Oss    Utrecht
#[Out]# 12140  Jumbo        Oss  Eindhoven
#[Out]# 12141  Jumbo        Oss  Rotterdam
#[Out]# 12142  Jumbo        Oss    Tilburg
#[Out]# 12143  Jumbo        Oss      Breda
#[Out]# 12144  Jumbo        Oss  Eindhoven
#[Out]# 12145  Jumbo        Oss  Eindhoven
#[Out]# 12146  Jumbo        Oss  Amsterdam
#[Out]# 12147  Jumbo        Oss  Amsterdam
#[Out]# 12148  Jumbo        Oss    Utrecht
#[Out]# 12149  Jumbo        Oss    Tilburg
#[Out]# 12150  Jumbo        Oss  Amsterdam
#[Out]# 12151  Jumbo        Oss  Eindhoven
#[Out]# 12152  Jumbo        Oss  Eindhoven
#[Out]# 12153  Jumbo        Oss    Utrecht
#[Out]# 12154  Jumbo        Oss  Eindhoven
#[Out]# 12155  Jumbo        Oss  Eindhoven
#[Out]# 12156  Jumbo        Oss  Eindhoven
#[Out]# 12157  Jumbo        Oss  Rotterdam
#[Out]# 12158  Jumbo        Oss        Oss
#[Out]# 12159  Jumbo        Oss    Utrecht
#[Out]# 
#[Out]# [12160 rows x 3 columns]
# Wed, 09 Dec 2020 12:53:34
query4_3 = '''
    SELECT store.sName, store.city as sCity, customer.city as cCityFROM
    store CROSS JOIN customer;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:53:36
query4_3 = '''
    SELECT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer;
'''

pd.read_sql_query(query4_3, conn)
#[Out]#        sName      sCity      cCity
#[Out]# 0       Coop  Amsterdam    Utrecht
#[Out]# 1       Coop  Amsterdam      Breda
#[Out]# 2       Coop  Amsterdam  Amsterdam
#[Out]# 3       Coop  Amsterdam      Breda
#[Out]# 4       Coop  Amsterdam  Amsterdam
#[Out]# 5       Coop  Amsterdam    Utrecht
#[Out]# 6       Coop  Amsterdam    Utrecht
#[Out]# 7       Coop  Amsterdam  Eindhoven
#[Out]# 8       Coop  Amsterdam      Breda
#[Out]# 9       Coop  Amsterdam  Amsterdam
#[Out]# 10      Coop  Amsterdam    Tilburg
#[Out]# 11      Coop  Amsterdam    Tilburg
#[Out]# 12      Coop  Amsterdam  Eindhoven
#[Out]# 13      Coop  Amsterdam      Breda
#[Out]# 14      Coop  Amsterdam    Tilburg
#[Out]# 15      Coop  Amsterdam    Tilburg
#[Out]# 16      Coop  Amsterdam  Eindhoven
#[Out]# 17      Coop  Amsterdam    Tilburg
#[Out]# 18      Coop  Amsterdam    Tilburg
#[Out]# 19      Coop  Amsterdam      Breda
#[Out]# 20      Coop  Amsterdam  Amsterdam
#[Out]# 21      Coop  Amsterdam    Tilburg
#[Out]# 22      Coop  Amsterdam  Eindhoven
#[Out]# 23      Coop  Amsterdam      Breda
#[Out]# 24      Coop  Amsterdam    Tilburg
#[Out]# 25      Coop  Amsterdam  Rotterdam
#[Out]# 26      Coop  Amsterdam  Eindhoven
#[Out]# 27      Coop  Amsterdam    Utrecht
#[Out]# 28      Coop  Amsterdam    Tilburg
#[Out]# 29      Coop  Amsterdam  Rotterdam
#[Out]# ...      ...        ...        ...
#[Out]# 12130  Jumbo        Oss    Tilburg
#[Out]# 12131  Jumbo        Oss    Tilburg
#[Out]# 12132  Jumbo        Oss  Rotterdam
#[Out]# 12133  Jumbo        Oss    Tilburg
#[Out]# 12134  Jumbo        Oss      Breda
#[Out]# 12135  Jumbo        Oss    Tilburg
#[Out]# 12136  Jumbo        Oss  Eindhoven
#[Out]# 12137  Jumbo        Oss      Breda
#[Out]# 12138  Jumbo        Oss  Rotterdam
#[Out]# 12139  Jumbo        Oss    Utrecht
#[Out]# 12140  Jumbo        Oss  Eindhoven
#[Out]# 12141  Jumbo        Oss  Rotterdam
#[Out]# 12142  Jumbo        Oss    Tilburg
#[Out]# 12143  Jumbo        Oss      Breda
#[Out]# 12144  Jumbo        Oss  Eindhoven
#[Out]# 12145  Jumbo        Oss  Eindhoven
#[Out]# 12146  Jumbo        Oss  Amsterdam
#[Out]# 12147  Jumbo        Oss  Amsterdam
#[Out]# 12148  Jumbo        Oss    Utrecht
#[Out]# 12149  Jumbo        Oss    Tilburg
#[Out]# 12150  Jumbo        Oss  Amsterdam
#[Out]# 12151  Jumbo        Oss  Eindhoven
#[Out]# 12152  Jumbo        Oss  Eindhoven
#[Out]# 12153  Jumbo        Oss    Utrecht
#[Out]# 12154  Jumbo        Oss  Eindhoven
#[Out]# 12155  Jumbo        Oss  Eindhoven
#[Out]# 12156  Jumbo        Oss  Eindhoven
#[Out]# 12157  Jumbo        Oss  Rotterdam
#[Out]# 12158  Jumbo        Oss        Oss
#[Out]# 12159  Jumbo        Oss    Utrecht
#[Out]# 
#[Out]# [12160 rows x 3 columns]
# Wed, 09 Dec 2020 12:54:24
query4_3 = '''
    SELECT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer
    EXCEPT
    SELECT sName, sCity FROM store;
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:54:29
query4_3 = '''
    SELECT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer
    EXCEPT
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:54:34
query4_3 = '''
    SELECT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer;
'''

pd.read_sql_query(query4_3, conn)
#[Out]#        sName      sCity      cCity
#[Out]# 0       Coop  Amsterdam    Utrecht
#[Out]# 1       Coop  Amsterdam      Breda
#[Out]# 2       Coop  Amsterdam  Amsterdam
#[Out]# 3       Coop  Amsterdam      Breda
#[Out]# 4       Coop  Amsterdam  Amsterdam
#[Out]# 5       Coop  Amsterdam    Utrecht
#[Out]# 6       Coop  Amsterdam    Utrecht
#[Out]# 7       Coop  Amsterdam  Eindhoven
#[Out]# 8       Coop  Amsterdam      Breda
#[Out]# 9       Coop  Amsterdam  Amsterdam
#[Out]# 10      Coop  Amsterdam    Tilburg
#[Out]# 11      Coop  Amsterdam    Tilburg
#[Out]# 12      Coop  Amsterdam  Eindhoven
#[Out]# 13      Coop  Amsterdam      Breda
#[Out]# 14      Coop  Amsterdam    Tilburg
#[Out]# 15      Coop  Amsterdam    Tilburg
#[Out]# 16      Coop  Amsterdam  Eindhoven
#[Out]# 17      Coop  Amsterdam    Tilburg
#[Out]# 18      Coop  Amsterdam    Tilburg
#[Out]# 19      Coop  Amsterdam      Breda
#[Out]# 20      Coop  Amsterdam  Amsterdam
#[Out]# 21      Coop  Amsterdam    Tilburg
#[Out]# 22      Coop  Amsterdam  Eindhoven
#[Out]# 23      Coop  Amsterdam      Breda
#[Out]# 24      Coop  Amsterdam    Tilburg
#[Out]# 25      Coop  Amsterdam  Rotterdam
#[Out]# 26      Coop  Amsterdam  Eindhoven
#[Out]# 27      Coop  Amsterdam    Utrecht
#[Out]# 28      Coop  Amsterdam    Tilburg
#[Out]# 29      Coop  Amsterdam  Rotterdam
#[Out]# ...      ...        ...        ...
#[Out]# 12130  Jumbo        Oss    Tilburg
#[Out]# 12131  Jumbo        Oss    Tilburg
#[Out]# 12132  Jumbo        Oss  Rotterdam
#[Out]# 12133  Jumbo        Oss    Tilburg
#[Out]# 12134  Jumbo        Oss      Breda
#[Out]# 12135  Jumbo        Oss    Tilburg
#[Out]# 12136  Jumbo        Oss  Eindhoven
#[Out]# 12137  Jumbo        Oss      Breda
#[Out]# 12138  Jumbo        Oss  Rotterdam
#[Out]# 12139  Jumbo        Oss    Utrecht
#[Out]# 12140  Jumbo        Oss  Eindhoven
#[Out]# 12141  Jumbo        Oss  Rotterdam
#[Out]# 12142  Jumbo        Oss    Tilburg
#[Out]# 12143  Jumbo        Oss      Breda
#[Out]# 12144  Jumbo        Oss  Eindhoven
#[Out]# 12145  Jumbo        Oss  Eindhoven
#[Out]# 12146  Jumbo        Oss  Amsterdam
#[Out]# 12147  Jumbo        Oss  Amsterdam
#[Out]# 12148  Jumbo        Oss    Utrecht
#[Out]# 12149  Jumbo        Oss    Tilburg
#[Out]# 12150  Jumbo        Oss  Amsterdam
#[Out]# 12151  Jumbo        Oss  Eindhoven
#[Out]# 12152  Jumbo        Oss  Eindhoven
#[Out]# 12153  Jumbo        Oss    Utrecht
#[Out]# 12154  Jumbo        Oss  Eindhoven
#[Out]# 12155  Jumbo        Oss  Eindhoven
#[Out]# 12156  Jumbo        Oss  Eindhoven
#[Out]# 12157  Jumbo        Oss  Rotterdam
#[Out]# 12158  Jumbo        Oss        Oss
#[Out]# 12159  Jumbo        Oss    Utrecht
#[Out]# 
#[Out]# [12160 rows x 3 columns]
# Wed, 09 Dec 2020 12:55:57
query4_3 = '''
    SELECT DISTINCT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer;
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName      sCity      cCity
#[Out]# 0         Coop  Amsterdam    Utrecht
#[Out]# 1         Coop  Amsterdam      Breda
#[Out]# 2         Coop  Amsterdam  Amsterdam
#[Out]# 3         Coop  Amsterdam  Eindhoven
#[Out]# 4         Coop  Amsterdam    Tilburg
#[Out]# 5         Coop  Amsterdam  Rotterdam
#[Out]# 6         Coop  Amsterdam        Oss
#[Out]# 7    Hoogvliet      Breda    Utrecht
#[Out]# 8    Hoogvliet      Breda      Breda
#[Out]# 9    Hoogvliet      Breda  Amsterdam
#[Out]# 10   Hoogvliet      Breda  Eindhoven
#[Out]# 11   Hoogvliet      Breda    Tilburg
#[Out]# 12   Hoogvliet      Breda  Rotterdam
#[Out]# 13   Hoogvliet      Breda        Oss
#[Out]# 14       Jumbo  Rotterdam    Utrecht
#[Out]# 15       Jumbo  Rotterdam      Breda
#[Out]# 16       Jumbo  Rotterdam  Amsterdam
#[Out]# 17       Jumbo  Rotterdam  Eindhoven
#[Out]# 18       Jumbo  Rotterdam    Tilburg
#[Out]# 19       Jumbo  Rotterdam  Rotterdam
#[Out]# 20       Jumbo  Rotterdam        Oss
#[Out]# 21      Sligro  Rotterdam    Utrecht
#[Out]# 22      Sligro  Rotterdam      Breda
#[Out]# 23      Sligro  Rotterdam  Amsterdam
#[Out]# 24      Sligro  Rotterdam  Eindhoven
#[Out]# 25      Sligro  Rotterdam    Tilburg
#[Out]# 26      Sligro  Rotterdam  Rotterdam
#[Out]# 27      Sligro  Rotterdam        Oss
#[Out]# 28   Hoogvliet  Eindhoven    Utrecht
#[Out]# 29   Hoogvliet  Eindhoven      Breda
#[Out]# ..         ...        ...        ...
#[Out]# 194       Lidl  Rotterdam  Rotterdam
#[Out]# 195       Lidl  Rotterdam        Oss
#[Out]# 196       Dirk  Rotterdam    Utrecht
#[Out]# 197       Dirk  Rotterdam      Breda
#[Out]# 198       Dirk  Rotterdam  Amsterdam
#[Out]# 199       Dirk  Rotterdam  Eindhoven
#[Out]# 200       Dirk  Rotterdam    Tilburg
#[Out]# 201       Dirk  Rotterdam  Rotterdam
#[Out]# 202       Dirk  Rotterdam        Oss
#[Out]# 203      Jumbo      Breda    Utrecht
#[Out]# 204      Jumbo      Breda      Breda
#[Out]# 205      Jumbo      Breda  Amsterdam
#[Out]# 206      Jumbo      Breda  Eindhoven
#[Out]# 207      Jumbo      Breda    Tilburg
#[Out]# 208      Jumbo      Breda  Rotterdam
#[Out]# 209      Jumbo      Breda        Oss
#[Out]# 210       Lidl      Breda    Utrecht
#[Out]# 211       Lidl      Breda      Breda
#[Out]# 212       Lidl      Breda  Amsterdam
#[Out]# 213       Lidl      Breda  Eindhoven
#[Out]# 214       Lidl      Breda    Tilburg
#[Out]# 215       Lidl      Breda  Rotterdam
#[Out]# 216       Lidl      Breda        Oss
#[Out]# 217      Jumbo        Oss    Utrecht
#[Out]# 218      Jumbo        Oss      Breda
#[Out]# 219      Jumbo        Oss  Amsterdam
#[Out]# 220      Jumbo        Oss  Eindhoven
#[Out]# 221      Jumbo        Oss    Tilburg
#[Out]# 222      Jumbo        Oss  Rotterdam
#[Out]# 223      Jumbo        Oss        Oss
#[Out]# 
#[Out]# [224 rows x 3 columns]
# Wed, 09 Dec 2020 12:56:41
query4_3 = '''
    SELECT DISTINCT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer
    WHERE sCity = cCity
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName      sCity      cCity
#[Out]# 0          Coop  Amsterdam  Amsterdam
#[Out]# 1     Hoogvliet      Breda      Breda
#[Out]# 2         Jumbo  Rotterdam  Rotterdam
#[Out]# 3        Sligro  Rotterdam  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven  Eindhoven
#[Out]# 5        Sligro      Breda      Breda
#[Out]# 6          Coop  Rotterdam  Rotterdam
#[Out]# 7        Sligro  Eindhoven  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven  Eindhoven
#[Out]# 9   Albert Hein    Tilburg    Tilburg
#[Out]# 10  Albert Hein  Rotterdam  Rotterdam
#[Out]# 11         Lidl  Eindhoven  Eindhoven
#[Out]# 12         Coop    Tilburg    Tilburg
#[Out]# 13         Lidl  Amsterdam  Amsterdam
#[Out]# 14         Lidl    Utrecht    Utrecht
#[Out]# 15       Sligro    Tilburg    Tilburg
#[Out]# 16         Coop      Breda      Breda
#[Out]# 17        Jumbo    Tilburg    Tilburg
#[Out]# 18         Dirk      Breda      Breda
#[Out]# 19  Albert Hein      Breda      Breda
#[Out]# 20       Sligro  Amsterdam  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg    Tilburg
#[Out]# 22         Dirk  Eindhoven  Eindhoven
#[Out]# 23         Coop    Utrecht    Utrecht
#[Out]# 24  Albert Hein    Utrecht    Utrecht
#[Out]# 25        Jumbo  Eindhoven  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam  Rotterdam
#[Out]# 27         Lidl  Rotterdam  Rotterdam
#[Out]# 28         Dirk  Rotterdam  Rotterdam
#[Out]# 29        Jumbo      Breda      Breda
#[Out]# 30         Lidl      Breda      Breda
#[Out]# 31        Jumbo        Oss        Oss
# Wed, 09 Dec 2020 12:57:08
query4_3 = '''
    SELECT DISTINCT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName      sCity      cCity
#[Out]# 0         Coop  Amsterdam    Utrecht
#[Out]# 1         Coop  Amsterdam      Breda
#[Out]# 2         Coop  Amsterdam  Amsterdam
#[Out]# 3         Coop  Amsterdam  Eindhoven
#[Out]# 4         Coop  Amsterdam    Tilburg
#[Out]# 5         Coop  Amsterdam  Rotterdam
#[Out]# 6         Coop  Amsterdam        Oss
#[Out]# 7    Hoogvliet      Breda    Utrecht
#[Out]# 8    Hoogvliet      Breda      Breda
#[Out]# 9    Hoogvliet      Breda  Amsterdam
#[Out]# 10   Hoogvliet      Breda  Eindhoven
#[Out]# 11   Hoogvliet      Breda    Tilburg
#[Out]# 12   Hoogvliet      Breda  Rotterdam
#[Out]# 13   Hoogvliet      Breda        Oss
#[Out]# 14       Jumbo  Rotterdam    Utrecht
#[Out]# 15       Jumbo  Rotterdam      Breda
#[Out]# 16       Jumbo  Rotterdam  Amsterdam
#[Out]# 17       Jumbo  Rotterdam  Eindhoven
#[Out]# 18       Jumbo  Rotterdam    Tilburg
#[Out]# 19       Jumbo  Rotterdam  Rotterdam
#[Out]# 20       Jumbo  Rotterdam        Oss
#[Out]# 21      Sligro  Rotterdam    Utrecht
#[Out]# 22      Sligro  Rotterdam      Breda
#[Out]# 23      Sligro  Rotterdam  Amsterdam
#[Out]# 24      Sligro  Rotterdam  Eindhoven
#[Out]# 25      Sligro  Rotterdam    Tilburg
#[Out]# 26      Sligro  Rotterdam  Rotterdam
#[Out]# 27      Sligro  Rotterdam        Oss
#[Out]# 28   Hoogvliet  Eindhoven    Utrecht
#[Out]# 29   Hoogvliet  Eindhoven      Breda
#[Out]# ..         ...        ...        ...
#[Out]# 194       Lidl  Rotterdam  Rotterdam
#[Out]# 195       Lidl  Rotterdam        Oss
#[Out]# 196       Dirk  Rotterdam    Utrecht
#[Out]# 197       Dirk  Rotterdam      Breda
#[Out]# 198       Dirk  Rotterdam  Amsterdam
#[Out]# 199       Dirk  Rotterdam  Eindhoven
#[Out]# 200       Dirk  Rotterdam    Tilburg
#[Out]# 201       Dirk  Rotterdam  Rotterdam
#[Out]# 202       Dirk  Rotterdam        Oss
#[Out]# 203      Jumbo      Breda    Utrecht
#[Out]# 204      Jumbo      Breda      Breda
#[Out]# 205      Jumbo      Breda  Amsterdam
#[Out]# 206      Jumbo      Breda  Eindhoven
#[Out]# 207      Jumbo      Breda    Tilburg
#[Out]# 208      Jumbo      Breda  Rotterdam
#[Out]# 209      Jumbo      Breda        Oss
#[Out]# 210       Lidl      Breda    Utrecht
#[Out]# 211       Lidl      Breda      Breda
#[Out]# 212       Lidl      Breda  Amsterdam
#[Out]# 213       Lidl      Breda  Eindhoven
#[Out]# 214       Lidl      Breda    Tilburg
#[Out]# 215       Lidl      Breda  Rotterdam
#[Out]# 216       Lidl      Breda        Oss
#[Out]# 217      Jumbo        Oss    Utrecht
#[Out]# 218      Jumbo        Oss      Breda
#[Out]# 219      Jumbo        Oss  Amsterdam
#[Out]# 220      Jumbo        Oss  Eindhoven
#[Out]# 221      Jumbo        Oss    Tilburg
#[Out]# 222      Jumbo        Oss  Rotterdam
#[Out]# 223      Jumbo        Oss        Oss
#[Out]# 
#[Out]# [224 rows x 3 columns]
# Wed, 09 Dec 2020 12:58:04
query4_3 = '''
    SELECT sName, sCity FROM
    SELECT DISTINCT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:58:10
query4_3 = '''
    SELECT sName, sCity FROM
    (SELECT DISTINCT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#          sName      sCity
#[Out]# 0         Coop  Amsterdam
#[Out]# 1         Coop  Amsterdam
#[Out]# 2         Coop  Amsterdam
#[Out]# 3         Coop  Amsterdam
#[Out]# 4         Coop  Amsterdam
#[Out]# 5         Coop  Amsterdam
#[Out]# 6         Coop  Amsterdam
#[Out]# 7    Hoogvliet      Breda
#[Out]# 8    Hoogvliet      Breda
#[Out]# 9    Hoogvliet      Breda
#[Out]# 10   Hoogvliet      Breda
#[Out]# 11   Hoogvliet      Breda
#[Out]# 12   Hoogvliet      Breda
#[Out]# 13   Hoogvliet      Breda
#[Out]# 14       Jumbo  Rotterdam
#[Out]# 15       Jumbo  Rotterdam
#[Out]# 16       Jumbo  Rotterdam
#[Out]# 17       Jumbo  Rotterdam
#[Out]# 18       Jumbo  Rotterdam
#[Out]# 19       Jumbo  Rotterdam
#[Out]# 20       Jumbo  Rotterdam
#[Out]# 21      Sligro  Rotterdam
#[Out]# 22      Sligro  Rotterdam
#[Out]# 23      Sligro  Rotterdam
#[Out]# 24      Sligro  Rotterdam
#[Out]# 25      Sligro  Rotterdam
#[Out]# 26      Sligro  Rotterdam
#[Out]# 27      Sligro  Rotterdam
#[Out]# 28   Hoogvliet  Eindhoven
#[Out]# 29   Hoogvliet  Eindhoven
#[Out]# ..         ...        ...
#[Out]# 194       Lidl  Rotterdam
#[Out]# 195       Lidl  Rotterdam
#[Out]# 196       Dirk  Rotterdam
#[Out]# 197       Dirk  Rotterdam
#[Out]# 198       Dirk  Rotterdam
#[Out]# 199       Dirk  Rotterdam
#[Out]# 200       Dirk  Rotterdam
#[Out]# 201       Dirk  Rotterdam
#[Out]# 202       Dirk  Rotterdam
#[Out]# 203      Jumbo      Breda
#[Out]# 204      Jumbo      Breda
#[Out]# 205      Jumbo      Breda
#[Out]# 206      Jumbo      Breda
#[Out]# 207      Jumbo      Breda
#[Out]# 208      Jumbo      Breda
#[Out]# 209      Jumbo      Breda
#[Out]# 210       Lidl      Breda
#[Out]# 211       Lidl      Breda
#[Out]# 212       Lidl      Breda
#[Out]# 213       Lidl      Breda
#[Out]# 214       Lidl      Breda
#[Out]# 215       Lidl      Breda
#[Out]# 216       Lidl      Breda
#[Out]# 217      Jumbo        Oss
#[Out]# 218      Jumbo        Oss
#[Out]# 219      Jumbo        Oss
#[Out]# 220      Jumbo        Oss
#[Out]# 221      Jumbo        Oss
#[Out]# 222      Jumbo        Oss
#[Out]# 223      Jumbo        Oss
#[Out]# 
#[Out]# [224 rows x 2 columns]
# Wed, 09 Dec 2020 12:58:21
query4_3 = '''
    SELECT DISTINCT sName, sCity FROM
    (SELECT DISTINCT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer)
'''

pd.read_sql_query(query4_3, conn)
#[Out]#           sName      sCity
#[Out]# 0          Coop  Amsterdam
#[Out]# 1     Hoogvliet      Breda
#[Out]# 2         Jumbo  Rotterdam
#[Out]# 3        Sligro  Rotterdam
#[Out]# 4     Hoogvliet  Eindhoven
#[Out]# 5        Sligro      Breda
#[Out]# 6          Coop  Rotterdam
#[Out]# 7        Sligro  Eindhoven
#[Out]# 8   Albert Hein  Eindhoven
#[Out]# 9   Albert Hein    Tilburg
#[Out]# 10  Albert Hein  Rotterdam
#[Out]# 11         Lidl  Eindhoven
#[Out]# 12         Coop    Tilburg
#[Out]# 13         Lidl  Amsterdam
#[Out]# 14         Lidl    Utrecht
#[Out]# 15       Sligro    Tilburg
#[Out]# 16         Coop      Breda
#[Out]# 17        Jumbo    Tilburg
#[Out]# 18         Dirk      Breda
#[Out]# 19  Albert Hein      Breda
#[Out]# 20       Sligro  Amsterdam
#[Out]# 21    Hoogvliet    Tilburg
#[Out]# 22         Dirk  Eindhoven
#[Out]# 23         Coop    Utrecht
#[Out]# 24  Albert Hein    Utrecht
#[Out]# 25        Jumbo  Eindhoven
#[Out]# 26    Hoogvliet  Rotterdam
#[Out]# 27         Lidl  Rotterdam
#[Out]# 28         Dirk  Rotterdam
#[Out]# 29        Jumbo      Breda
#[Out]# 30         Lidl      Breda
#[Out]# 31        Jumbo        Oss
# Wed, 09 Dec 2020 12:59:23
query4_3 = '''
    (SELECT DISTINCT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer)
    EXCEPT
    SELECT sName, city FROM STORE
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 12:59:48
query4_3 = '''
    (SELECT DISTINCT store.sName, store.city as sCity, customer.city as cCity FROM
    store CROSS JOIN customer)
    EXCEPT
    SELECT sName, city as sCity FROM STORE
'''

pd.read_sql_query(query4_3, conn)
# Wed, 09 Dec 2020 13:00:53
query4_4 = '''
(SELECT MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:01:00
query4_4 = '''
SELECT MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    MAX(sum)
#[Out]# 0     217.2
# Wed, 09 Dec 2020 13:03:47
query4_4 = '''

SELECT0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:03:56
query4_4 = '''

SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    0.75 *  MAX(sum)
#[Out]# 0             162.9
# Wed, 09 Dec 2020 13:04:54
query4_4 = '''


SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:04:57
query4_4 = '''


SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID     sum        date
#[Out]# 0    21   59.65  2018-08-15
#[Out]# 1     2   88.25  2018-08-16
#[Out]# 2     2  139.15  2018-08-17
#[Out]# 3     3  126.40  2018-08-18
#[Out]# 4     3  121.55  2018-08-19
#[Out]# 5     1  103.75  2018-08-20
#[Out]# 6     1   80.40  2018-08-21
#[Out]# 7     0  115.80  2018-08-22
#[Out]# 8     5  127.25  2018-08-23
#[Out]# 9     4  167.50  2018-08-24
#[Out]# 10    4  167.65  2018-08-25
#[Out]# 11    7  217.20  2018-08-26
#[Out]# 12   10  100.65  2018-08-27
#[Out]# 13   22   47.10  2018-08-28
#[Out]# 14   39   11.90  2018-08-29
#[Out]# 15  188    1.00  2018-09-20
# Wed, 09 Dec 2020 13:05:39
query4_4 = '''

SELECT cID FROM (
SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date)

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:05:58
query4_4 = '''


SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:06:08
query4_4 = '''
SELECT 0.75 *  MAX(sum) FROM (

SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:06:10
query4_4 = '''


SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID     sum        date
#[Out]# 0    21   59.65  2018-08-15
#[Out]# 1     2   88.25  2018-08-16
#[Out]# 2     2  139.15  2018-08-17
#[Out]# 3     3  126.40  2018-08-18
#[Out]# 4     3  121.55  2018-08-19
#[Out]# 5     1  103.75  2018-08-20
#[Out]# 6     1   80.40  2018-08-21
#[Out]# 7     0  115.80  2018-08-22
#[Out]# 8     5  127.25  2018-08-23
#[Out]# 9     4  167.50  2018-08-24
#[Out]# 10    4  167.65  2018-08-25
#[Out]# 11    7  217.20  2018-08-26
#[Out]# 12   10  100.65  2018-08-27
#[Out]# 13   22   47.10  2018-08-28
#[Out]# 14   39   11.90  2018-08-29
#[Out]# 15  188    1.00  2018-09-20
# Wed, 09 Dec 2020 13:06:19
query4_4 = '''
SELECT 0.75 *  MAX(sum) FROM (

SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    0.75 *  MAX(sum)
#[Out]# 0             162.9
# Wed, 09 Dec 2020 13:07:45
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) WHERE sum >= (

SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date));
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:07:54
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:08:01
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID     sum        date
#[Out]# 0    21   59.65  2018-08-15
#[Out]# 1     2   88.25  2018-08-16
#[Out]# 2     2  139.15  2018-08-17
#[Out]# 3     3  126.40  2018-08-18
#[Out]# 4     3  121.55  2018-08-19
#[Out]# 5     1  103.75  2018-08-20
#[Out]# 6     1   80.40  2018-08-21
#[Out]# 7     0  115.80  2018-08-22
#[Out]# 8     5  127.25  2018-08-23
#[Out]# 9     4  167.50  2018-08-24
#[Out]# 10    4  167.65  2018-08-25
#[Out]# 11    7  217.20  2018-08-26
#[Out]# 12   10  100.65  2018-08-27
#[Out]# 13   22   47.10  2018-08-28
#[Out]# 14   39   11.90  2018-08-29
#[Out]# 15  188    1.00  2018-09-20
# Wed, 09 Dec 2020 13:09:22
query4_4 = '''

SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    0.75 *  MAX(sum)
#[Out]# 0             162.9
# Wed, 09 Dec 2020 13:09:45
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date WHERE sum >= 162.9

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:09:48
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date WHERE sum >= 162.9;

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:10:03
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase WHERE sum >= 162.9;
GROUP BY date 

'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:10:20
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID     sum        date
#[Out]# 0    21   59.65  2018-08-15
#[Out]# 1     2   88.25  2018-08-16
#[Out]# 2     2  139.15  2018-08-17
#[Out]# 3     3  126.40  2018-08-18
#[Out]# 4     3  121.55  2018-08-19
#[Out]# 5     1  103.75  2018-08-20
#[Out]# 6     1   80.40  2018-08-21
#[Out]# 7     0  115.80  2018-08-22
#[Out]# 8     5  127.25  2018-08-23
#[Out]# 9     4  167.50  2018-08-24
#[Out]# 10    4  167.65  2018-08-25
#[Out]# 11    7  217.20  2018-08-26
#[Out]# 12   10  100.65  2018-08-27
#[Out]# 13   22   47.10  2018-08-28
#[Out]# 14   39   11.90  2018-08-29
#[Out]# 15  188    1.00  2018-09-20
# Wed, 09 Dec 2020 13:10:42
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase WHERE sum >= 162.9
GROUP BY date
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:10:57
query4_4 = '''
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID     sum        date
#[Out]# 0    21   59.65  2018-08-15
#[Out]# 1     2   88.25  2018-08-16
#[Out]# 2     2  139.15  2018-08-17
#[Out]# 3     3  126.40  2018-08-18
#[Out]# 4     3  121.55  2018-08-19
#[Out]# 5     1  103.75  2018-08-20
#[Out]# 6     1   80.40  2018-08-21
#[Out]# 7     0  115.80  2018-08-22
#[Out]# 8     5  127.25  2018-08-23
#[Out]# 9     4  167.50  2018-08-24
#[Out]# 10    4  167.65  2018-08-25
#[Out]# 11    7  217.20  2018-08-26
#[Out]# 12   10  100.65  2018-08-27
#[Out]# 13   22   47.10  2018-08-28
#[Out]# 14   39   11.90  2018-08-29
#[Out]# 15  188    1.00  2018-09-20
# Wed, 09 Dec 2020 13:11:23
query4_4 = '''
SELECT cID FROM(
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID
#[Out]# 0    21
#[Out]# 1     2
#[Out]# 2     2
#[Out]# 3     3
#[Out]# 4     3
#[Out]# 5     1
#[Out]# 6     1
#[Out]# 7     0
#[Out]# 8     5
#[Out]# 9     4
#[Out]# 10    4
#[Out]# 11    7
#[Out]# 12   10
#[Out]# 13   22
#[Out]# 14   39
#[Out]# 15  188
# Wed, 09 Dec 2020 13:11:34
query4_4 = '''
SELECT cID FROM(
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) WHERE sum >= 162.9
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID
#[Out]# 0    4
#[Out]# 1    4
#[Out]# 2    7
# Wed, 09 Dec 2020 13:11:53
query4_4 = '''
SELECT cName FROM customer WHERE cID IN(
SELECT cID FROM(
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) WHERE sum >= 162.9);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#   cName
#[Out]# 0  Daan
#[Out]# 1  Bram
# Wed, 09 Dec 2020 13:16:00
query4_4 = '''

SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date);
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    0.75 *  MAX(sum)
#[Out]# 0             162.9
# Wed, 09 Dec 2020 13:16:15
query4_4 = '''

SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) as hello;
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    0.75 *  MAX(sum)
#[Out]# 0             162.9
# Wed, 09 Dec 2020 13:16:26
query4_4 = '''
max = hello[0]
SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) as hello;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:16:35
query4_4 = '''
max == hello[0]
SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) as hello;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:16:40
query4_4 = '''
hello[0]
SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) as hello;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:16:47
query4_4 = '''
int max = hello[0]
SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) as hello;
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:20:16
query4_4 = '''
SELECT cID FROM 
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) WHERE sum >= 
(0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date))
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:20:37
query4_4 = '''
SELECT cID FROM 
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) WHERE sum >= 
SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:21:07
query4_4 = '''
SELECT cID FROM 
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) CROSS JOIN
SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date)
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:21:20
query4_4 = '''
SELECT cID FROM 
(SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) CROSS JOIN
(SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date))
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID
#[Out]# 0    21
#[Out]# 1     2
#[Out]# 2     2
#[Out]# 3     3
#[Out]# 4     3
#[Out]# 5     1
#[Out]# 6     1
#[Out]# 7     0
#[Out]# 8     5
#[Out]# 9     4
#[Out]# 10    4
#[Out]# 11    7
#[Out]# 12   10
#[Out]# 13   22
#[Out]# 14   39
#[Out]# 15  188
# Wed, 09 Dec 2020 13:21:27
query4_4 = '''

(SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) CROSS JOIN
(SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date))
'''

pd.read_sql_query(query4_4, conn)
# Wed, 09 Dec 2020 13:21:38
query4_4 = '''
SELECT * FROM 
(SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) CROSS JOIN
(SELECT 0.75 *  MAX(sum) FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date))
'''

pd.read_sql_query(query4_4, conn)
#[Out]#     cID     sum        date  0.75 *  MAX(sum)
#[Out]# 0    21   59.65  2018-08-15             162.9
#[Out]# 1     2   88.25  2018-08-16             162.9
#[Out]# 2     2  139.15  2018-08-17             162.9
#[Out]# 3     3  126.40  2018-08-18             162.9
#[Out]# 4     3  121.55  2018-08-19             162.9
#[Out]# 5     1  103.75  2018-08-20             162.9
#[Out]# 6     1   80.40  2018-08-21             162.9
#[Out]# 7     0  115.80  2018-08-22             162.9
#[Out]# 8     5  127.25  2018-08-23             162.9
#[Out]# 9     4  167.50  2018-08-24             162.9
#[Out]# 10    4  167.65  2018-08-25             162.9
#[Out]# 11    7  217.20  2018-08-26             162.9
#[Out]# 12   10  100.65  2018-08-27             162.9
#[Out]# 13   22   47.10  2018-08-28             162.9
#[Out]# 14   39   11.90  2018-08-29             162.9
#[Out]# 15  188    1.00  2018-09-20             162.9
# Wed, 09 Dec 2020 13:22:05
query4_4 = '''
SELECT * FROM 
(SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) CROSS JOIN
(SELECT 0.75 *  MAX(sum) as max FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date))
WHERE sum >= max
'''

pd.read_sql_query(query4_4, conn)
#[Out]#    cID     sum        date    max
#[Out]# 0    4  167.50  2018-08-24  162.9
#[Out]# 1    4  167.65  2018-08-25  162.9
#[Out]# 2    7  217.20  2018-08-26  162.9
# Wed, 09 Dec 2020 13:22:32
query4_4 = '''
select cName FROM customer WHERE cID IN
(SELECT cID FROM 
(SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date) CROSS JOIN
(SELECT 0.75 *  MAX(sum) as max FROM (
SELECT cID, SUM(price) as sum, date FROM purchase
GROUP BY date))
WHERE sum >= max)
'''

pd.read_sql_query(query4_4, conn)
#[Out]#   cName
#[Out]# 0  Daan
#[Out]# 1  Bram
# Wed, 09 Dec 2020 13:25:55
query4_4 = '''
SELECT city FROM customer
UNION
SELECT city FROM store
'''

pd.read_sql_query(query4_4, conn)
#[Out]#         city
#[Out]# 0  Amsterdam
#[Out]# 1      Breda
#[Out]# 2  Eindhoven
#[Out]# 3        Oss
#[Out]# 4  Rotterdam
#[Out]# 5    Tilburg
#[Out]# 6    Utrecht
# Wed, 09 Dec 2020 13:26:17
query4_4 = '''
(SELECT city FROM customer
UNION
SELECT city FROM store)
as hello
'''

pd.read_sql_query(query4_4, conn)

# IPython log file

# Tue, 08 Dec 2020 14:25:55
# This connects a database instance on your local machine, make the name of the database descriptive!
conn = sqlite3.connect('shopping.db')
cur = conn.cursor()

# The first time you ran this command, it initialized a database instance.
# In the cell below, you fill it with the appropriate sql dump file. 
# Tue, 08 Dec 2020 14:26:14
# Replace this line with the correct location of the SQL dump, 
# and the correct database instance needed for the questions.
db_location = 'shoppingDB.sql'

f = open(db_location,'r')
sql = f.read()
cur.executescript(sql)
#[Out]# <sqlite3.Cursor at 0x2045375d2d0>
# Tue, 08 Dec 2020 15:06:01
query4_3 = '''
SELECT S.sName
FROM (SELECT city FROM customer INTERSECT SELECT city FROM store) as citiesWithStoreAndCust, store S
WHERE S.city = citiesWithStoreAndCust.city
GROUP BY S.sName
HAVING COUNT (S.city) <> COUNT (citiesWithStoreAndCust.city)
'''
# Tue, 08 Dec 2020 15:06:02
vis.visualize(query4_3, schema)
# Tue, 08 Dec 2020 15:06:27
pd.read_sql_query(query4_3, conn)
#[Out]# Empty DataFrame
#[Out]# Columns: [sName]
#[Out]# Index: []
# Tue, 08 Dec 2020 15:18:33
query4_4 = '''
WITH amountSpent (tID, cID, amount) as (
    SELECT tID, cID, SUM (price)
    FROM purchase
    GROUP BY tID)
SELECT DISTINCT C.cName
FROM amountSpent S, customer C
WHERE S.cID = C.cID and S.amount >= 0.75 * MAX (S.amount)
'''
# Tue, 08 Dec 2020 15:18:34
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 15:18:35
pd.read_sql_query(query4_4, conn)
# Tue, 08 Dec 2020 15:20:46
query4_4 = '''
WITH amountSpent (tID, cID, amount) as (
SELECT tID, cID, SUM (price)
FROM purchase
GROUP BY tID)
SELECT DISTINCT C.cName
FROM amountSpent S, customer C
WHERE S.cID = C.cID
GROUP BY C.cName
HAVING S.amount >= 0.75 * MAX (S.amount)
'''
# Tue, 08 Dec 2020 15:20:46
vis.visualize(query4_4, schema)
# Tue, 08 Dec 2020 15:20:47
pd.read_sql_query(query4_4, conn)
#[Out]#          cName
#[Out]# 0        Aiden
#[Out]# 1    Alexander
#[Out]# 2        Amira
#[Out]# 3          Amy
#[Out]# 4       Angela
#[Out]# 5         Anna
#[Out]# 6         Anne
#[Out]# 7     Benjamin
#[Out]# 8        Boris
#[Out]# 9         Bram
#[Out]# 10      Casper
#[Out]# 11        Cato
#[Out]# 12        Daan
#[Out]# 13        Dani
#[Out]# 14       David
#[Out]# 15        Dean
#[Out]# 16         Dex
#[Out]# 17       Dylan
#[Out]# 18       Elena
#[Out]# 19        Elif
#[Out]# 20        Elin
#[Out]# 21       Eline
#[Out]# 22       Elise
#[Out]# 23        Ella
#[Out]# 24       Emily
#[Out]# 25        Emma
#[Out]# 26       Esmee
#[Out]# 27       Femke
#[Out]# 28       Fenna
#[Out]# 29       Fenne
#[Out]# ..         ...
#[Out]# 101      Ruben
#[Out]# 102       Ryan
#[Out]# 103       Saar
#[Out]# 104        Sam
#[Out]# 105       Sara
#[Out]# 106        Sem
#[Out]# 107       Senn
#[Out]# 108       Siem
#[Out]# 109      Sofia
#[Out]# 110      Sofie
#[Out]# 111     Sophia
#[Out]# 112     Sophie
#[Out]# 113       Stan
#[Out]# 114       Stef
#[Out]# 115      Stijn
#[Out]# 116       Sven
#[Out]# 117       Tess
#[Out]# 118      Tessa
#[Out]# 119       Teun
#[Out]# 120    Thijmen
#[Out]# 121      Thijs
#[Out]# 122       Ties
#[Out]# 123       Tijn
#[Out]# 124        Tim
#[Out]# 125        Tom
#[Out]# 126     Veerle
#[Out]# 127      Wilko
#[Out]# 128     Willem
#[Out]# 129       Xavi
#[Out]# 130       Yara
#[Out]# 
#[Out]# [131 rows x 1 columns]
# Tue, 08 Dec 2020 15:31:25
query4_5 = '''
SELECT C.city, COUNT (DISTINCT P.cID)
FROM purchase P, store S, customer C
WHERE P.sID = S.sID and C.cID = P.cID and S.city = 'Eindhoven'
GROUP BY C.city
'''
# Tue, 08 Dec 2020 15:31:25
vis.visualize(query4_5, schema)
# Tue, 08 Dec 2020 15:31:26
pd.read_sql_query(query4_5, conn)
#[Out]#         city  COUNT (DISTINCT P.cID)
#[Out]# 0  Amsterdam                      10
#[Out]# 1      Breda                       9
#[Out]# 2  Eindhoven                      15
#[Out]# 3  Rotterdam                      13
#[Out]# 4    Tilburg                      10
#[Out]# 5    Utrecht                      12
# Tue, 08 Dec 2020 15:32:02
query4_3 = '''
SELECT S.sName
FROM (SELECT city FROM customer INTERSECT SELECT city FROM store) as citiesWithStoreAndCust, store S
WHERE S.city = citiesWithStoreAndCust.city
GROUP BY S.sName
HAVING COUNT (S.city) = COUNT (citiesWithStoreAndCust.city)
'''
# Tue, 08 Dec 2020 15:32:05
pd.read_sql_query(query4_3, conn)
#[Out]#          sName
#[Out]# 0  Albert Hein
#[Out]# 1         Coop
#[Out]# 2         Dirk
#[Out]# 3    Hoogvliet
#[Out]# 4        Jumbo
#[Out]# 5         Lidl
#[Out]# 6       Sligro

